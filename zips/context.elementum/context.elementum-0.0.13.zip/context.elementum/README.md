# Context Menu for Elementum

http://elementum.surge.sh/context/

# Release process

Release is done by running `release.sh` script, that collects zip artifacts and push it as a release (if we are on the tag).

*Note*: Tag version should be the same as the plugin version in `addon.xml`.
