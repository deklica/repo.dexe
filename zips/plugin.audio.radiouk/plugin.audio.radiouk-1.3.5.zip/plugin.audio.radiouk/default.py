# -*- coding: utf-8 -*-
"""Kodi plugin for live UK radio stations."""

import sys
import json
import os
import re
import socket
import time
from urllib.parse import parse_qsl, quote, urlencode
from urllib.request import Request, urlopen

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
from resources.lib import tunein as tunein_source


HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
ADDON = xbmcaddon.Addon()
RADIO_UK_URL = "https://www.radio-uk.co.uk/"
RECENT_FILE = xbmcvfs.translatePath("special://profile/addon_data/plugin.audio.radiouk/recent.json")
CACHE_FOLDER = xbmcvfs.translatePath("special://temp/plugin.audio.radiouk")
CHANGELOG_FILE = os.path.join(ADDON.getAddonInfo("path"), "changelog.txt")
ART_FOLDER = os.path.join(ADDON.getAddonInfo("path"), "images")
MAX_RECENT = 10
DIRECT_STREAM_SLUGS = {
    "radio-x",
    "radio-x-90s",
    "radio-x-00s",
    "heart-80s",
    "heart-90s",
    "virgin-radio-uk",
}

MENU_ART = {
    "recent": os.path.join(ART_FOLDER, "submenu-recent.png"),
    "BBC": os.path.join(ART_FOLDER, "submenu-bbc.png"),
    "Music": os.path.join(ART_FOLDER, "submenu-music.png"),
    "tunein": os.path.join(ART_FOLDER, "submenu-tunein.png"),
    "Talk and sport": os.path.join(ART_FOLDER, "submenu-talk-sport.png"),
    "tools": os.path.join(ART_FOLDER, "submenu-tools.png"),
    "changelog": os.path.join(ART_FOLDER, "submenu-changelog.png"),
}


STATIONS = {
    "BBC": [
        ("BBC Radio 1", "bbc-radio-1", "bbc://BBC Radio 1"),
        ("BBC Radio 2", "bbc-radio-2", "bbc://BBC Radio 2"),
        ("BBC Radio 3", "bbc-radio-3", "bbc://BBC Radio 3"),
        ("BBC Radio 4", "bbc-radio-4", "bbc://BBC Radio 4"),
        ("BBC Radio 5 live", "bbc-radio-5-live", "bbc://BBC Radio 5 live"),
        ("BBC 6 Music", "bbc-6-music", "bbc://BBC 6 Music"),
        ("BBC Live News", "bbc-live-news", "https://as-hls-ww-live.akamaized.net/pool_53367543/live/ww/bbc_sounds_news/bbc_sounds_news.isml/bbc_sounds_news-audio%3d128000.norewind.m3u8"),
    ],
    "Music": [
        ("Capital London", "capital-fm", "https://media-ssl.musicradio.com/Capital"),
        ("Capital Dance", "capital-dance", "https://media-ssl.musicradio.com/CapitalDance"),
        ("Capital XTRA", "capital-xtra", "http://media-the.musicradio.com/CapitalXTRALondonMP3"),
        ("Heart UK", "heart-uk", "https://media-ssl.musicradio.com/HeartLondon"),
        ("Heart 80s", "heart-80s", "https://media-ssl.musicradio.com/Heart80sMP3"),
        ("Heart 90s", "heart-90s", "https://media-ssl.musicradio.com/Heart90sMP3"),
        ("Smooth Radio London", "smooth-radio", "https://media-ssl.musicradio.com/SmoothLondon"),
        ("Gold Radio UK", "gold-radio-uk", "https://media-ssl.musicradio.com/Gold"),
        ("Classic FM", "classic-fm", "https://media-ssl.musicradio.com/ClassicFM"),
        ("Kerrang! Radio", "kerrang-radio", "https://stream-al.hellorayo.co.uk/kerrang.aac?direct=true"),
        ("Planet Rock", "planet-rock", "https://stream-mz.hellorayo.co.uk/planetrock.aac?direct=true&aw_0_1st.playerid=BMUK_Airable&aw_0_1st.skey=6778249992"),
        ("House Nation UK", "house-nation-uk", "https://streaming.radio.co/s06bd9d805/listen"),
        ("Virgin Radio UK", "virgin-radio-uk", "https://virgin.live.stream.broadcasting.news/stream"),
        ("Radio X", "radio-x", "https://media-ssl.musicradio.com/RadioXLondon"),
        ("Radio X 90s", "radio-x-90s", "https://media-ssl.musicradio.com/RadioX90s"),
        ("Radio X 00s", "radio-x-00s", "https://media-ssl.musicradio.com/RadioX00s"),
    ],
    "Talk and sport": [
        ("GB News", "gb-news", "http://listen-gbnews.sharp-stream.com/gbnews.mp3"),
        ("talkSPORT", "talksport", "https://radio.talksport.com/stream"),
        ("talkSPORT 2", "talksport-2", "https://radio.talksport.com/stream2"),
        ("LBC", "lbc", "https://media-ssl.musicradio.com/LBCUK"),
        ("LBC News", "lbc-news", "https://media-ssl.musicradio.com/LBCNewsUK"),
        ("talkRADIO", "talkradio", "https://radio.talkradio.com/stream"),
        ("Times Radio", "times-radio", "https://radio.thetimes.co.uk/stream"),
    ],
}

ICON_URLS = {
    "bbc-radio-1": "https://static.mytuner.mobi/media/tvos_radios/791/bbc-radio-1.e765a9d5.png",
    "bbc-radio-2": "https://static.mytuner.mobi/media/tvos_radios/758/bbc-radio-2.f6883f21.png",
    "bbc-radio-3": "https://static.mytuner.mobi/media/tvos_radios/220/bbc-radio-3.6dc132b3.png",
    "bbc-radio-4": "https://static.mytuner.mobi/media/tvos_radios/795/bbc-radio-4.cf7d8a55.png",
    "bbc-radio-5-live": "https://static.mytuner.mobi/media/tvos_radios/799/bbc-radio-5-live.1f3fd9bc.png",
    "bbc-6-music": "https://static.mytuner.mobi/media/tvos_radios/800/bbc-6-music.c1211abe.png",
    "bbc-live-news": "https://www.radio-uk.co.uk/favicon.ico",
    "heart-uk": "https://static.mytuner.mobi/media/tvos_radios/022/heart-uk.fd98d84b.png",
    "talksport": "https://static.mytuner.mobi/media/tvos_radios/22yeCk65a6.jpg",
    "kerrang-radio": "https://static.mytuner.mobi/media/tvos_radios/605/kerrang-radio.b8e49fce.png",
    "planet-rock": "https://static.mytuner.mobi/media/tvos_radios/626/planet-rock.e97d8e00.png",
    "house-nation-uk": "https://static.mytuner.mobi/media/tvos_radios/aWa7xGKfBh.jpg",
    "capital-fm": "https://static.mytuner.mobi/media/tvos_radios/877/capital-london.ab4eccb5.png",
    "capital-dance": "https://static.mytuner.mobi/media/tvos_radios/991/capital-dance.64c87331.png",
    "capital-xtra": "https://static.mytuner.mobi/media/tvos_radios/891/capital-xtra-national.ee29bd72.png",
    "heart-80s": "https://static.mytuner.mobi/media/tvos_radios/874/heart-80s.82605d89.png",
    "heart-90s": "https://www.heart.co.uk/assets_v4r/heart/img/favicon-196x196.png",
    "smooth-radio": "https://static.mytuner.mobi/media/tvos_radios/442/smooth-radio-london-1022.7a851254.png",
    "gold-radio-uk": "https://static.mytuner.mobi/media/tvos_radios/943/gold-radio-uk.86c3d0d3.jpg",
    "classic-fm": "https://static.mytuner.mobi/media/tvos_radios/942/classic-fm.a14a97e6.png",
    "gb-news": "https://www.gbnews.com/favicon.ico",
    "lbc-news": "https://www.lbc.co.uk/favicon.ico",
    "virgin-radio-uk": "https://static.mytuner.mobi/media/tvos_radios/270/virgin-radio-uk.3138050d.png",
    "radio-x": "https://www.radiox.co.uk/assets_v4r/xfm/img/favicon-196x196.png",
    "radio-x-90s": "https://www.radiox.co.uk/assets_v4r/xfm/img/favicon-196x196.png",
    "radio-x-00s": "https://www.radiox.co.uk/assets_v4r/xfm/img/favicon-196x196.png",
    "talksport-2": "https://static.mytuner.mobi/media/tvos_radios/270/talksport-2.9011352d.png",
    "lbc": "https://www.lbc.co.uk/favicon.ico",
    "talkradio": "https://static.mytuner.mobi/media/tvos_radios/hjpjegwqyac2.png",
    "times-radio": "https://static.mytuner.mobi/media/tvos_radios/248/times-radio.20b98e5e.png",
}


def plugin_url(**kwargs):
    return BASE_URL + "?" + urlencode(kwargs)


def add_folder(label, category):
    item = xbmcgui.ListItem(label=label)
    art = MENU_ART.get(category, "DefaultFolder.png")
    item.setArt({"icon": art, "thumb": art})
    xbmcplugin.addDirectoryItem(HANDLE, plugin_url(action="category", category=category), item, True)


def add_action(label, action, art=None):
    item = xbmcgui.ListItem(label=label)
    art = art or "DefaultAddon.png"
    item.setArt({"icon": art, "thumb": art})
    xbmcplugin.addDirectoryItem(HANDLE, plugin_url(action=action), item, False)


def add_folder_action(label, action, art=None):
    item = xbmcgui.ListItem(label=label)
    art = art or "DefaultFolder.png"
    item.setArt({"icon": art, "thumb": art})
    xbmcplugin.addDirectoryItem(HANDLE, plugin_url(action=action), item, True)


def set_music_info(item, title, artist, album="", genre=""):
    """Set music metadata without Kodi 21's deprecated setInfo warnings."""
    tag = item.getMusicInfoTag()
    if hasattr(tag, "setTitle"):
        tag.setTitle(title)
        tag.setArtist(artist)
        tag.setAlbum(album)
        tag.setGenres([genre] if genre else [])
    else:
        item.setInfo(
            "music",
            {"title": title, "artist": artist, "album": album, "genre": genre},
        )


def add_station(name, slug, stream_url, white_label=False):
    current_station = xbmcgui.Window(10000).getProperty("RadioUK.CurrentStation")
    is_playing = xbmc.Player().isPlayingAudio() and current_station == name
    colour = "yellow" if is_playing else "white"
    label = "[COLOR {}]{}[/COLOR]".format(colour, name)
    item = xbmcgui.ListItem(label=label)
    set_music_info(item, name, "Radio UK", name, "Live radio")
    icon_url = ICON_URLS.get(slug, "DefaultAudio.png")
    item.setArt({"icon": icon_url, "thumb": icon_url})
    item.setProperty("IsPlayable", "true")
    item.setPath(stream_url)
    item.setLabel2("Now playing" if is_playing else "Live")
    item.setProperty("RadioUKPage", RADIO_UK_URL + slug)
    xbmcplugin.addDirectoryItem(
        HANDLE,
        plugin_url(action="play", stream=stream_url, name=name, slug=slug),
        item,
        False,
    )


def show_root():
    add_folder("Recently played", "recent")
    for category in STATIONS:
        add_folder(category, category)
    add_folder_action("TuneIn Radio", "tunein_root", MENU_ART["tunein"])
    add_folder("Tools", "tools")
    add_action("Changelog", "changelog", MENU_ART["changelog"])
    xbmcplugin.setPluginCategory(HANDLE, "Radio UK")
    xbmcplugin.endOfDirectory(HANDLE)


def show_category(category):
    if category == "recent":
        show_recent()
        return
    if category == "tools":
        add_action("Clear Recently Played", "clear_recent")
        add_action("Clear Radio UK Cache", "clear_cache")
        xbmcplugin.setPluginCategory(HANDLE, "Tools")
        xbmcplugin.endOfDirectory(HANDLE)
        return
    for station in STATIONS.get(category, []):
        add_station(*station)
    xbmcplugin.setPluginCategory(HANDLE, category)
    xbmcplugin.endOfDirectory(HANDLE)


def show_recent():
    for station in load_recent():
        add_station(station["name"], station["slug"], station["stream"], white_label=True)
    xbmcplugin.setPluginCategory(HANDLE, "Recently played")
    xbmcplugin.endOfDirectory(HANDLE)


def show_changelog():
    try:
        with xbmcvfs.File(CHANGELOG_FILE, "r") as changelog_file:
            text = changelog_file.read()
        if isinstance(text, bytes):
            text = text.decode("utf-8")
    except (OSError, IOError) as error:
        xbmc.log("Radio UK changelog could not be read: {}".format(error), xbmc.LOGWARNING)
        text = "The changelog is unavailable."
    xbmcgui.Dialog().textviewer("Radio UK Changelog", text)


def clear_recent():
    if not xbmcgui.Dialog().yesno("Radio UK", "Clear Recently played history?"):
        return
    try:
        if xbmcvfs.exists(RECENT_FILE):
            xbmcvfs.delete(RECENT_FILE)
        xbmcgui.Dialog().notification(
            "Radio UK",
            "Recently played history cleared.",
            xbmcgui.NOTIFICATION_INFO,
        )
    except OSError as error:
        xbmc.log("Radio UK recent stations could not be cleared: {}".format(error), xbmc.LOGWARNING)
        xbmcgui.Dialog().notification(
            "Radio UK",
            "Could not clear Recently played history.",
            xbmcgui.NOTIFICATION_ERROR,
        )


def clear_cache():
    if not xbmcgui.Dialog().yesno("Radio UK", "Clear Radio UK cache?"):
        return
    try:
        if xbmcvfs.exists(CACHE_FOLDER):
            xbmcvfs.rmdir(CACHE_FOLDER, True)
        xbmcgui.Dialog().notification(
            "Radio UK",
            "Cache cleared.",
            xbmcgui.NOTIFICATION_INFO,
        )
    except OSError as error:
        xbmc.log("Radio UK cache could not be cleared: {}".format(error), xbmc.LOGWARNING)
        xbmcgui.Dialog().notification(
            "Radio UK",
            "Could not clear cache.",
            xbmcgui.NOTIFICATION_ERROR,
        )


def play_station(stream_url, name, slug):
    candidates = resolve_streams(name, slug, stream_url)
    selected_stream = next((url for url in candidates if stream_is_available(url)), "")
    if not selected_stream:
        xbmc.log("Radio UK: no playable stream found for {}".format(name), xbmc.LOGERROR)
        xbmcgui.Dialog().notification(
            "Radio UK",
            "{} is unavailable. Try again later.".format(name),
            xbmcgui.NOTIFICATION_ERROR,
        )
        return
    record_recent(name, slug, stream_url)
    stream_url = selected_stream
    icon_url = ICON_URLS.get(slug, "DefaultAudio.png")
    item = xbmcgui.ListItem(label=name, path=stream_url)
    set_music_info(item, name, "Radio UK", name, "Live radio")
    item.setArt({"icon": icon_url, "thumb": icon_url})
    item.setProperty("mimetype", stream_mimetype(stream_url))
    window = xbmcgui.Window(10000)
    window.setProperty("RadioUK.CurrentStation", name)
    window.setProperty("RadioUK.CurrentStream", stream_url)
    window.setProperty("RadioUK.CurrentArt", icon_url)
    window.setProperty("RadioUK.CurrentSetAt", str(time.time()))
    if not stream_url.lower().split("?", 1)[0].endswith(".m3u8"):
        item.setPath(stream_url + "|Icy-MetaData=1&User-Agent=RadioUK%20Kodi%20addon")
    xbmcplugin.setResolvedUrl(HANDLE, True, item)


def load_recent():
    try:
        if not xbmcvfs.exists(RECENT_FILE):
            return []
        with xbmcvfs.File(RECENT_FILE, "r") as recent_file:
            data = recent_file.read()
        if isinstance(data, bytes):
            data = data.decode("utf-8")
        recent = json.loads(data)
        return recent if isinstance(recent, list) else []
    except (OSError, ValueError, TypeError) as error:
        xbmc.log("Radio UK recent stations could not be read: {}".format(error), xbmc.LOGWARNING)
        return []


def record_recent(name, slug, stream_url):
    recent = [station for station in load_recent() if station.get("slug") != slug]
    recent.insert(0, {"name": name, "slug": slug, "stream": stream_url})
    recent = recent[:MAX_RECENT]
    try:
        folder = xbmcvfs.translatePath("special://profile/addon_data/plugin.audio.radiouk")
        if not xbmcvfs.exists(folder):
            xbmcvfs.mkdirs(folder)
        with xbmcvfs.File(RECENT_FILE, "w") as recent_file:
            recent_file.write(json.dumps(recent, ensure_ascii=True))
    except OSError as error:
        xbmc.log("Radio UK recent station could not be saved: {}".format(error), xbmc.LOGWARNING)


def resolve_streams(station_name, slug, fallback):
    """Return healthy directory streams first, followed by known fallbacks."""
    if slug in DIRECT_STREAM_SLUGS:
        return [fallback]
    api_url = "https://de1.api.radio-browser.info/json/stations/search?name={}&countrycode=GB&hidebroken=true&limit=50".format(
        quote(station_name)
    )
    candidates = []
    try:
        request = Request(api_url, headers={"User-Agent": "RadioUK Kodi addon"})
        with urlopen(request, timeout=10) as response:
            stations = json.loads(response.read().decode("utf-8"))
        for station in stations:
            stream = station.get("url_resolved", "")
            candidate_name = normalize(station.get("name", ""))
            if (station.get("lastcheckok") == 1 and stream.startswith("http")
                    and (normalize(station_name) in candidate_name or candidate_name in normalize(station_name))):
                candidates.append(stream)
    except Exception as error:
        xbmc.log("Radio UK stream lookup failed for {}: {}".format(station_name, error), xbmc.LOGWARNING)
    candidates.extend(FALLBACK_STREAMS.get(slug, [fallback]))
    return unique(candidates)


def normalize(value):
    return re.sub(r"[^a-z0-9]+", "", value.lower())


def unique(values):
    return list(dict.fromkeys(value for value in values if value))


def stream_is_available(stream_url):
    try:
        request = Request(stream_url, headers={"User-Agent": "RadioUK Kodi addon", "Icy-MetaData": "1"})
        with urlopen(request, timeout=5) as response:
            return response.status < 400
    except (OSError, socket.timeout):
        return False


def stream_mimetype(stream_url):
    path = stream_url.lower().split("?", 1)[0]
    if path.endswith(".m3u8"):
        return "application/vnd.apple.mpegurl"
    if path.endswith(".aac") or "musicradio.com/radiox" in path:
        return "audio/aac"
    return "audio/mpeg"


FALLBACK_STREAMS = {
    "bbc-radio-1": ["https://a.files.bbci.co.uk/ms6/live/3441A116-B12E-4D2F-ACA8-C1984642FA4B/audio/simulcast/hls/nonuk/pc_hd_abr_v2/cf/bbc_radio_one.m3u8"],
    "bbc-radio-2": ["https://a.files.bbci.co.uk/ms6/live/3441A116-B12E-4D2F-ACA8-C1984642FA4B/audio/simulcast/hls/nonuk/pc_hd_abr_v2/cf/bbc_radio_two.m3u8"],
    "planet-rock": ["https://stream-mz.hellorayo.co.uk/planetrock.aac?direct=true"],
    "capital-dance": ["https://icecast.thisisdax.com/CapitalDanceMP3"],
}


params = dict(parse_qsl(sys.argv[2][1:]))
action = params.get("action")

if action and action.startswith("tunein_"):
    tunein_source.run(
        action,
        params,
        HANDLE,
        plugin_url,
        os.path.join(ART_FOLDER, "submenu-tunein.png"),
        os.path.join(ART_FOLDER, "fanart.png"),
    )
elif action == "category":
    show_category(params.get("category", ""))
elif action == "changelog":
    show_changelog()
elif action == "clear_recent":
    clear_recent()
elif action == "clear_cache":
    clear_cache()
elif action == "play":
    play_station(params.get("stream", ""), params.get("name", "Radio UK"), params.get("slug", ""))
else:
    show_root()
