# Radio UK Kodi addon

This Kodi audio plugin provides a curated set of live UK stations listed on
[Radio UK](https://www.radio-uk.co.uk/), grouped into BBC, music, and talk/sport.

The root menu also includes **TuneIn Radio**, using the full TuneIn
browser from Cosmos. It supports station/show/podcast search, browsing by
music, talk, sports, location and language, pagination, favourites, recently
played stations, artwork, programme details, and direct Kodi playback.
TuneIn directory responses are cached briefly for faster navigation. Each
station has a refresh action, and the TuneIn root includes **Refresh TuneIn
Data** and **Stop Radio** actions. Stop Radio clears active playback and
metadata state safely.

Install the repository folder as a Kodi addon, open **Radio UK**, choose a
category, and select a station to start playback.

The station currently playing is highlighted in yellow in station lists and
is labelled **Now playing**. Other stations remain white and labelled **Live**.

The root menu includes **Recently played**. It remembers the 10 most recently
played stations and moves a station to the top when it is played again. Older
entries are removed as new stations are played. The list is stored in Kodi's
addon profile and survives restarts. **Changelog** is available at the bottom
of the root menu.

The **Tools** menu includes **Clear Recently Played**, which asks for
confirmation before deleting the saved history.

For ZIP installation, the archive must contain this top-level folder:

```text
plugin.audio.radiouk/
	addon.xml
	default.py
	resources/
		lib/
			tunein.py
	images/
		icon.png
		fanart.png
		submenu-tunein.png
```

Do not ZIP the parent Downloads folder or add another folder level around
`plugin.audio.radiouk`.

Stream URLs are refreshed from Radio Browser when a station starts. The addon
tries healthy alternatives before using its known fallback URL. Kodi reads
live stream metadata. The bundled service also adds the station to Kodi's
artist line (for example, `Radio X • Take That & Lulu`) and refreshes the
current title, artist, station, and artwork every second in the global
properties `RadioUK.NowPlaying.Title`, `RadioUK.NowPlaying.Artist`,
`RadioUK.NowPlaying.Station`, and `RadioUK.NowPlaying.Art`.
Radio X 00s publishes empty ICY title blocks, so its song details are refreshed
every 15 seconds from the public Radio X Now Playing page instead.
Virgin Radio UK is likewise refreshed from its public station-data feed because
its audio stream does not embed the current song.
