"""Embedded TuneIn radio, programme and podcast browser for Cosmos."""
import json, os, re, time
from urllib.parse import parse_qsl, urlencode, urlsplit
from urllib.request import Request, urlopen
import xbmc, xbmcgui, xbmcplugin
try:
    import xbmcvfs
except ImportError:
    xbmcvfs = None

API_HOST='opml.radiotime.com'; API_ROOT='https://'+API_HOST
USER_AGENT='Mozilla/5.0 (Kodi; Radio UK TuneIn)'; PAGE_SIZE=30
STATE_FILE=''; ACTIVE_FILE=''
CACHE_TTL=60
_CACHE={}

def _profile_file(name):
    folder=xbmcvfs.translatePath('special://profile/addon_data/plugin.audio.radiouk') if xbmcvfs else os.path.join(os.path.expanduser('~'),'.radiouk')
    os.makedirs(folder,exist_ok=True); return os.path.join(folder,name)
def _state_file(): return STATE_FILE or _profile_file('tunein_library.json')
def _active_file(): return ACTIVE_FILE or _profile_file('tunein_active.json')
def _read(url):
    with urlopen(Request(url,headers={'User-Agent':USER_AGENT,'Accept':'application/json,*/*'}),timeout=15) as response: return response.read().decode('utf-8','replace')
def _api_url(path,**params):
    parsed=urlsplit(path)
    if parsed.netloc and parsed.hostname != API_HOST: raise ValueError('Unexpected TuneIn API host')
    query=dict(parse_qsl(parsed.query,keep_blank_values=True)); query.update({k:v for k,v in params.items() if v not in (None,'')}); query['render']='json'
    endpoint=parsed.path if parsed.path.startswith('/') else '/'+parsed.path
    return API_ROOT+endpoint+'?'+urlencode(query)
def _request(path,**params):
    cache_key=_api_url(path,**params)
    cached=_CACHE.get(cache_key)
    if cached and time.time()-cached[0] < CACHE_TTL: return cached[1]
    result=json.loads(_read(cache_key))
    if str((result.get('head') or {}).get('status','200'))!='200': raise RuntimeError('TuneIn returned an error')
    body=result.get('body') or []
    _CACHE[cache_key]=(time.time(),body)
    return body
def _clear_cache(): _CACHE.clear()
def _flatten(elements):
    output=[]
    for element in elements or []:
        if element.get('element')=='outline' and element.get('children'): output.extend(_flatten(element['children']))
        else: output.append(element)
    return output
def _media_id(element):
    ident=str(element.get('guide_id') or element.get('preset_id') or element.get('now_playing_id') or '')
    if re.fullmatch(r'[spt]\d+',ident): return ident
    match=re.search(r'(?:[?&]id=)([spt]\d+)',element.get('URL') or element.get('url') or '')
    return match.group(1) if match else ''
def _station_id(element):
    ident=_media_id(element); return ident if ident.startswith('s') else ''
def _https_art(url):
    parsed=urlsplit(url or ''); host=(parsed.hostname or '').lower()
    if parsed.scheme=='http' and (host.endswith('.tunein.com') or host.endswith('.radiotime.com')):
        return 'https://'+(parsed.netloc or '')+parsed.path+(('?'+parsed.query) if parsed.query else '')
    return url or ''
def _playlist_stream(url):
    parsed=urlsplit(url)
    if parsed.scheme not in ('http','https'): return ''
    lower=parsed.path.lower()
    if lower.endswith('.m3u8'): return url
    if lower.endswith(('.m3u','.pls')):
        try:
            content=_read(url)
            if lower.endswith('.pls'):
                match=re.search(r'(?im)^File\d+=(https?://\S+)\s*$',content); return match.group(1).strip() if match else url
            return next((line.strip() for line in content.splitlines() if line.strip().startswith(('http://','https://'))),url)
        except Exception: return url
    return url
def _resolve_media(media_id):
    if not re.fullmatch(r'[st]\d+',media_id or ''): raise ValueError('Invalid TuneIn media ID')
    streams=sorted(_request('/Tune.ashx',id=media_id),key=lambda row:(str(row.get('url','')).endswith('notcompatible.enUS.mp3'),-int(row.get('reliability') or 0),-int(row.get('bitrate') or 0)))
    for stream in streams:
        url=_playlist_stream(stream.get('url') or '')
        if url and 'notcompatible.enUS.mp3' not in url: return url,stream
    raise RuntimeError('No compatible stream is available for this item.')
def _resolve_station(station_id): return _resolve_media(station_id)
def _load_library():
    try:
        with open(_state_file(),'r',encoding='utf-8') as source: data=json.load(source)
        return {'favourites':data.get('favourites') or [],'recent':data.get('recent') or []}
    except (OSError,ValueError,TypeError): return {'favourites':[],'recent':[]}
def _save_library(data):
    target=_state_file(); temporary=target+'.tmp'
    with open(temporary,'w',encoding='utf-8') as output: json.dump(data,output,ensure_ascii=False,indent=2)
    os.replace(temporary,target)
def _saved_item(params): return {k:params.get(k,'') for k in ('media_id','name','image','description','genre','location','programme')}
def _remember(params,collection='recent'):
    item=_saved_item(params)
    if not item['media_id']: return
    library=_load_library(); rows=[r for r in library[collection] if r.get('media_id')!=item['media_id']]; rows.insert(0,item)
    library[collection]=rows[:30] if collection=='recent' else rows; _save_library(library)
def _forget(media_id):
    library=_load_library(); library['favourites']=[r for r in library['favourites'] if r.get('media_id')!=media_id]; _save_library(library)
def _clear_recent():
    library=_load_library(); library['recent']=[]; _save_library(library)
def _now_playing(station_id):
    programme=''; artwork=''
    for row in _request('/Describe.ashx',c='nowplaying',id=station_id):
        if row.get('key')=='show': programme=row.get('text') or ''
        if row.get('element')=='nowplaying': artwork=row.get('logo') or ''; programme=programme or row.get('line1') or row.get('line2') or ''
    return programme,_https_art(artwork)
def _station_details(station_id): return next((r for r in _request('/Describe.ashx',id=station_id) if r.get('element')=='station'),{})
def _details_text(params,stream=None):
    parts=[]
    if params.get('programme'): parts.append('Now playing: '+str(params['programme']))
    if params.get('location'): parts.append('Location: '+str(params['location']))
    if stream:
        codec=str(stream.get('media_type') or '').upper(); bitrate=str(stream.get('bitrate') or '')
        if codec or bitrate: parts.append('Stream: '+' · '.join(filter(None,(codec,bitrate+' kbps' if bitrate else ''))))
    if params.get('description'): parts.append(str(params['description']))
    return '\n\n'.join(parts)
def _write_active(params,stream_url,stream):
    data=_saved_item(params); data.update({'stream_url':stream_url,'codec':stream.get('media_type') or '','bitrate':stream.get('bitrate') or '','started':int(time.time())})
    with open(_active_file(),'w',encoding='utf-8') as output: json.dump(data,output,ensure_ascii=False)
    try:
        window=xbmcgui.Window(10000); window.setProperty('RadioUK.TuneIn.ActiveId',str(params.get('media_id') or '')); window.setProperty('RadioUK.TuneIn.ActiveName',str(params.get('name') or ''))
    except Exception: pass
def _clear_active():
    try:
        window=xbmcgui.Window(10000)
        window.clearProperty('RadioUK.TuneIn.ActiveId')
        window.clearProperty('RadioUK.TuneIn.ActiveName')
    except Exception: pass
    try:
        if os.path.exists(_active_file()): os.remove(_active_file())
    except OSError: pass
def _active_media_id():
    try:
        if xbmc.Player().isPlayingAudio(): return xbmcgui.Window(10000).getProperty('RadioUK.TuneIn.ActiveId') or ''
    except Exception: pass
    return ''
def refresh_active_metadata():
    try:
        with open(_active_file(),'r',encoding='utf-8') as source: active=json.load(source)
        if not str(active.get('media_id','')).startswith('s'): return {}
        programme,artwork=_now_playing(active['media_id'])
        if programme: active['programme']=programme
        if artwork: active['image']=artwork
        return active
    except (OSError,ValueError,TypeError): return {}

def run(action,params,handle,build_url,icon,fanart):
    def add(label,target,folder=True,art='',info=None,context=None,**kwargs):
        item=xbmcgui.ListItem(label=label); image=_https_art(art) or icon
        item.setArt({'icon':image,'thumb':image,'poster':image,'fanart':fanart})
        if info: item.setInfo('music',info)
        if context: item.addContextMenuItems(context)
        if not folder: item.setProperty('IsPlayable','true')
        xbmcplugin.addDirectoryItem(handle,build_url(action=target,**kwargs),item,isFolder=folder)
    def add_media(row):
        media_id=row.get('media_id') or _media_id(row); label=row.get('name') or row.get('text')
        if not media_id or not label: return False
        image=_https_art(row.get('image') or row.get('logo') or ''); description=row.get('description') or row.get('subtext') or ''
        programme=row.get('programme') or row.get('current_track') or ''; location=row.get('location') or ''; genre=row.get('genre') or row.get('genre_name') or ''
        values=dict(media_id=media_id,name=label,image=image,description=description,programme=programme,location=location,genre=genre)
        if media_id.startswith('p'):
            add(label,'tunein_show',True,image,{'mediatype':'album','title':label,'comment':description},**values); return True
        active=media_id==_active_media_id()
        display_label=('[COLOR deepskyblue]▶ NOW PLAYING[/COLOR]  [B]%s[/B]'%label) if active else label
        favourite=any(r.get('media_id')==media_id for r in _load_library()['favourites'])
        fav_action='tunein_favourite_remove' if favourite else 'tunein_favourite_add'; fav_label='Remove from TuneIn Favourites' if favourite else 'Add to TuneIn Favourites'
        context=[(fav_label,'RunPlugin(%s)'%build_url(action=fav_action,**values)),('Refresh station','RunPlugin(%s)'%build_url(action='tunein_retry',**values))]
        if media_id.startswith('s'): context.append(('Station information','RunPlugin(%s)'%build_url(action='tunein_info',**values)))
        add(display_label,'tunein_play',False,image,{'mediatype':'song','title':label,'genre':genre,'comment':_details_text(values)},context=context,**values); return True
    try:
        if action=='tunein_stop':
            _clear_active()
            try:
                xbmc.Player().stop()
            except RuntimeError: pass
            xbmcgui.Window(10000).clearProperty('RadioUK.CurrentStation')
            xbmcgui.Window(10000).clearProperty('RadioUK.CurrentStream')
            xbmcgui.Window(10000).clearProperty('RadioUK.CurrentArt')
            xbmcgui.Window(10000).clearProperty('RadioUK.CurrentSetAt')
            for key in ('RadioUK.NowPlaying.Title','RadioUK.NowPlaying.Artist','RadioUK.NowPlaying.Station','RadioUK.NowPlaying.Art'):
                xbmcgui.Window(10000).clearProperty(key)
            return
        if action=='tunein_retry':
            _clear_cache()
            retry_params=dict(params)
            retry_params['action']='tunein_play'
            return run('tunein_play',retry_params,handle,build_url,icon,fanart)
        if action=='tunein_refresh':
            _clear_cache()
            xbmc.executebuiltin('Container.Refresh')
            return
        if action=='tunein_recent_clear':
            if xbmcgui.Dialog().yesno('TuneIn Radio','Clear all recently played stations and episodes?'):
                _clear_recent(); xbmcgui.Dialog().notification('TuneIn Radio','Recently played cleared.',xbmcgui.NOTIFICATION_INFO,3000); xbmc.executebuiltin('Container.Refresh')
            return
        if action in ('tunein_favourite_add','tunein_favourite_remove'):
            _remember(params,'favourites') if action.endswith('_add') else _forget(params.get('media_id','')); xbmc.executebuiltin('Container.Refresh'); return
        if action=='tunein_info':
            media_id=params.get('media_id',''); details=_station_details(media_id); programme,artwork=_now_playing(media_id); _,stream=_resolve_media(media_id); merged=dict(params)
            merged.update({'description':details.get('description') or params.get('description',''),'location':details.get('location') or params.get('location',''),'programme':programme or params.get('programme',''),'image':artwork or details.get('logo') or params.get('image','')})
            xbmcgui.Dialog().textviewer(params.get('name','Station information'),_details_text(merged,stream)); return
        if action=='tunein_play':
            media_id=params.get('media_id') or params.get('station_id',''); stream_url,stream=_resolve_media(media_id); params=dict(params)
            if media_id.startswith('s'):
                details=_station_details(media_id); programme,artwork=_now_playing(media_id)
                params.update({'description':details.get('description') or params.get('description',''),'location':details.get('location') or params.get('location',''),'programme':programme or params.get('programme',''),'image':artwork or details.get('logo') or params.get('image','')})
            _remember(dict(params,media_id=media_id),'recent'); item=xbmcgui.ListItem(path=stream_url)
            player_title=params.get('name','TuneIn Radio')
            if params.get('programme'): player_title+=' — '+params['programme']
            item.setInfo('music',{'mediatype':'song','title':player_title,'artist':'TuneIn Radio','album':params.get('name','TuneIn Radio'),'genre':params.get('genre',''),'comment':_details_text(params,stream)}); item.setArt({'thumb':_https_art(params.get('image')) or icon,'fanart':fanart})
            mime={'mp3':'audio/mpeg','aac':'audio/aac','ogg':'audio/ogg','m4a':'audio/mp4'}.get(str(stream.get('media_type') or '').lower())
            if mime: item.setMimeType(mime)
            if media_id.startswith('s'): _write_active(dict(params,media_id=media_id),stream_url,stream)
            xbmcplugin.setResolvedUrl(handle,True,item); return
        xbmcplugin.setContent(handle,'files')
        if action=='tunein_root':
            for args in [('Search Stations, Shows & Podcasts','tunein_search',{}),('Recently Played','tunein_recent',{}),('Favourites','tunein_favourites',{}),('Browse','tunein_browse',{'path':'/Browse.ashx'}),('Local Radio','tunein_browse',{'path':'/Browse.ashx?c=local'}),('Music','tunein_browse',{'path':'/Browse.ashx?c=music'}),('Talk','tunein_browse',{'path':'/Browse.ashx?c=talk'}),('Sports','tunein_browse',{'path':'/Browse.ashx?c=sports'}),('By Location','tunein_browse',{'path':'/Browse.ashx?id=r0'}),('By Language','tunein_browse',{'path':'/Browse.ashx?c=lang'}),('Refresh TuneIn Data','tunein_refresh',{}),('Stop Radio','tunein_stop',{})]: add(args[0],args[1],**args[2])
        else:
            if action=='tunein_search':
                query=params.get('query') or xbmcgui.Dialog().input('Search TuneIn').strip()
                if not query: xbmcplugin.endOfDirectory(handle,succeeded=False); return
                elements=_request('/Search.ashx',query=query)
            elif action=='tunein_browse': elements=_request(params.get('path') or '/Browse.ashx')
            elif action=='tunein_show': elements=_request('/Tune.ashx',c='pbrowse',id=params.get('media_id',''))
            elif action in ('tunein_recent','tunein_favourites'):
                elements=_load_library()['recent' if action=='tunein_recent' else 'favourites']
                if action=='tunein_recent' and elements: add('Clear Recently Played','tunein_recent_clear')
            else: raise ValueError('Unknown TuneIn action')
            all_elements=_flatten(elements)
            try: page=max(1,int(params.get('page','1')))
            except (TypeError,ValueError): page=1
            start,end=(page-1)*PAGE_SIZE,page*PAGE_SIZE
            def nav(direction):
                values={'page':str(page+direction)}
                if action=='tunein_search': values['query']=query
                elif action=='tunein_browse': values['path']=params.get('path') or '/Browse.ashx'
                elif action=='tunein_show': values['media_id']=params.get('media_id','')
                return values
            if page>1: add('« Previous page',action,**nav(-1))
            for element in all_elements[start:end]:
                if add_media(element): continue
                label=element.get('text') or element.get('name'); target_url=element.get('URL') or element.get('url') or ''; parsed=urlsplit(target_url)
                if label and parsed.hostname==API_HOST and parsed.path.endswith(('/Browse.ashx','/Search.ashx')): add(label,'tunein_browse',True,element.get('image') or '',path=target_url)
            if end<len(all_elements): add('Next page »',action,**nav(1))
        xbmcplugin.endOfDirectory(handle,succeeded=True,cacheToDisc=False)
    except Exception as exc:
        xbmc.log('Radio UK TuneIn: %s: %s'%(type(exc).__name__,str(exc)[:160]),xbmc.LOGWARNING); xbmcgui.Dialog().notification('TuneIn Radio',str(exc) or 'Unable to load TuneIn.',xbmcgui.NOTIFICATION_ERROR,5000)
        if action=='tunein_play': xbmcplugin.setResolvedUrl(handle,False,xbmcgui.ListItem())
        elif action not in ('tunein_info','tunein_favourite_add','tunein_favourite_remove','tunein_recent_clear'): xbmcplugin.endOfDirectory(handle,succeeded=False)
