# -*- coding: utf-8 -*-
"""Add the station name to Kodi's live radio metadata."""

import html
import json
import re
import time
from urllib.request import Request, urlopen

import xbmc
import xbmcgui


monitor = xbmc.Monitor()
window = xbmcgui.Window(10000)
player = xbmc.Player()
last_track = ""
remote_metadata = {}
remote_checked = {}

REMOTE_METADATA_URLS = {
    "Radio X 00s": "https://www.radiox.co.uk/00s/",
}
VIRGIN_METADATA_URL = (
    "https://virginradio.co.uk/api/get-station-data"
    "?station=virginradiouk&withSongs=1&hasPrograms={}&numberOfSongs=1"
)


def clean_artist(artist, station):
    prefix = station + " • "
    if artist.startswith(prefix):
        return artist[len(prefix):]
    return artist


def split_stream_title(title, artist, station):
    """Split ICY metadata such as 'James - Sit Down' when artist is empty."""
    if station and title != station and (not artist or artist == "Radio UK") and " - " in title:
        stream_artist, stream_title = title.split(" - ", 1)
        if stream_artist and stream_title:
            return stream_title, stream_artist
    return title, artist


def set_music_info(item, title, artist, station):
    """Set current music metadata using Kodi's supported tag API."""
    tag = item.getMusicInfoTag()
    if hasattr(tag, "setTitle"):
        tag.setTitle(title)
        tag.setArtist(artist)
        tag.setAlbum(station)
        tag.setGenres(["Live radio"])
    else:
        item.setInfo(
            "music",
            {"title": title, "artist": artist, "album": station, "genre": "Live radio"},
        )


def webpage_metadata(station):
    """Fetch metadata for streams which publish empty ICY title blocks."""
    url = REMOTE_METADATA_URLS.get(station)
    if not url:
        return None
    try:
        request = Request(url, headers={"User-Agent": "RadioUK Kodi addon"})
        with urlopen(request, timeout=5) as response:
            page = response.read().decode("utf-8", "replace")
        title_match = re.search(
            r'class="now-playing__text-content__details__track"[^>]*>(.*?)</span>',
            page,
            re.IGNORECASE | re.DOTALL,
        )
        artist_match = re.search(
            r'class="now-playing__text-content__details__artist"[^>]*>(.*?)</span>',
            page,
            re.IGNORECASE | re.DOTALL,
        )
        if title_match and artist_match:
            title = html.unescape(re.sub(r"<[^>]+>", "", title_match.group(1))).strip()
            artist = html.unescape(re.sub(r"<[^>]+>", "", artist_match.group(1))).strip()
            if title and artist:
                return title, artist
    except (OSError, ValueError):
        pass
    return None


def virgin_metadata():
    """Fetch Virgin Radio UK's current track from its public JSON feed."""
    try:
        cache_cycle = int(time.monotonic() // 15) % 9 + 1
        request = Request(
            VIRGIN_METADATA_URL.format(cache_cycle),
            headers={"User-Agent": "RadioUK Kodi addon"},
        )
        with urlopen(request, timeout=5) as response:
            data = json.loads(response.read().decode("utf-8"))
        songs = data.get("recentlyPlayed", [])
        if songs:
            title = (songs[0].get("title") or "").strip()
            artist = (songs[0].get("artist") or "").strip()
            if title and artist:
                return title, artist
    except (KeyError, OSError, TypeError, ValueError):
        pass
    return None


while not monitor.abortRequested():
    if player.isPlayingAudio():
        try:
            tag = player.getMusicInfoTag()
            title = tag.getTitle() or player.getPlayingFile()
        except (RuntimeError, AttributeError):
            # Kodi may invalidate the player object during Stop while this
            # service is between its playback check and metadata read.
            last_track = ""
            monitor.waitForAbort(1)
            continue
        station = window.getProperty("RadioUK.CurrentStation")
        artist = clean_artist(tag.getArtist() or "", station) if station else tag.getArtist() or ""
        title, artist = split_stream_title(title, artist, station)
        if station in REMOTE_METADATA_URLS or station == "Virgin Radio UK":
            now = time.monotonic()
            if now - remote_checked.get(station, 0) >= 15:
                remote_checked[station] = now
                fetched = virgin_metadata() if station == "Virgin Radio UK" else webpage_metadata(station)
                if fetched:
                    remote_metadata[station] = fetched
            if station in remote_metadata:
                title, artist = remote_metadata[station]
        art = xbmc.getInfoLabel("Player.Art(thumb)") or window.getProperty("RadioUK.CurrentArt")
        track = "{}|{}|{}|{}".format(title, artist, station, art)
        if track != last_track:
            window.setProperty("RadioUK.NowPlaying.Title", title)
            window.setProperty("RadioUK.NowPlaying.Artist", artist)
            window.setProperty("RadioUK.NowPlaying.Station", station)
            window.setProperty("RadioUK.NowPlaying.Art", art)
            has_track_metadata = title != station or (artist and artist != "Radio UK")
            still_playing_station = (
                player.isPlayingAudio()
                and window.getProperty("RadioUK.CurrentStation") == station
            )
            if station and has_track_metadata and still_playing_station:
                display_artist = station
                if artist and artist != "Radio UK":
                    display_artist = "{} • {}".format(station, artist)
                item = xbmcgui.ListItem(label=title, path=player.getPlayingFile())
                set_music_info(item, title, display_artist, station)
                if art:
                    item.setArt({"icon": art, "thumb": art})
                try:
                    player.updateInfoTag(item)
                except RuntimeError:
                    # Playback can stop between isPlayingAudio() and this call.
                    pass
            last_track = track
    elif last_track:
        window.clearProperty("RadioUK.NowPlaying.Title")
        window.clearProperty("RadioUK.NowPlaying.Artist")
        window.clearProperty("RadioUK.NowPlaying.Station")
        window.clearProperty("RadioUK.NowPlaying.Art")
        try:
            station_age = time.time() - float(window.getProperty("RadioUK.CurrentSetAt") or 0)
        except ValueError:
            station_age = 60
        # Do not erase a new station marker while Kodi is changing streams.
        if station_age > 10:
            window.clearProperty("RadioUK.CurrentStation")
            window.clearProperty("RadioUK.CurrentStream")
            window.clearProperty("RadioUK.CurrentArt")
            window.clearProperty("RadioUK.CurrentSetAt")
        # TuneIn keeps its own active-station marker for the browser UI.
        # Clear it when Kodi has actually stopped, otherwise a later stop or
        # metadata refresh can target a stale player session.
        window.clearProperty("RadioUK.TuneIn.ActiveId")
        window.clearProperty("RadioUK.TuneIn.ActiveName")
        last_track = ""
    monitor.waitForAbort(1)
