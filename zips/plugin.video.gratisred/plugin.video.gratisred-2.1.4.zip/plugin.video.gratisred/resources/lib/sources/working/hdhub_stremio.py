# -*- coding: utf-8 -*-

import re

from six.moves.urllib_parse import parse_qs, unquote, urlencode

from resources.lib.modules import client
from resources.lib.modules import scrape_sources
from resources.lib.modules import source_utils
#from resources.lib.modules import log_utils

_BASE = ('https://hdhub.thevolecitor.qzz.io/'
         'eyJ0b3Jib3giOiJ1bnNldCIsInF1YWxpdGllcyI6IjIxNjBwLDEwODBwLDcyMHAiLCJzb3J0IjoiZGVzYyJ9')


class source:
    def __init__(self):
        self.results = []
        self.base_link = _BASE
        self.domains = ['hdhub.thevolecitor.qzz.io']
        self.probe_link = _BASE + '/stream/movie/tt0111161.json'
        self.headers = {
            'User-Agent': client.UserAgent,
            'Accept': 'application/json',
            'Referer': 'https://watch.cinewave.qzz.io/',
        }
        self._title = ''
        self._year = ''
        self._season = None
        self._episode = None


    def movie(self, imdb, tmdb, title, localtitle, aliases, year):
        url = {'imdb': imdb, 'tmdb': tmdb or '', 'media': 'movie'}
        return urlencode(url)


    def tvshow(self, imdb, tmdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        url = {
            'imdb': imdb, 'tmdb': tmdb or '', 'media': 'series',
            'title': tvshowtitle or localtvshowtitle or '', 'year': year or '',
        }
        return urlencode(url)


    def episode(self, url, imdb, tmdb, tvdb, title, premiered, season, episode):
        if not url:
            return
        url = parse_qs(url)
        url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
        url['season'], url['episode'] = season, episode
        return urlencode(url)


    def _imdb_id(self, imdb):
        if not imdb or imdb == '0':
            return None
        imdb = str(imdb).strip()
        if not imdb.startswith('tt'):
            imdb = 'tt' + re.sub(r'[^0-9]', '', imdb)
        return imdb if re.fullmatch(r'tt\d+', imdb) else None


    def _resource_id(self, imdb, tmdb):
        ident = self._imdb_id(imdb)
        if ident:
            return ident
        tmdb = str(tmdb or '').strip()
        if tmdb.isdigit() and tmdb not in ('0', 'None'):
            return 'tmdb:' + tmdb
        return None


    def _fetch_streams(self, media_type, resource_id):
        try:
            api_url = '%s/stream/%s/%s.json' % (_BASE, media_type, resource_id)
            data = client.request(
                api_url,
                headers=self.headers,
                timeout='20',
                output='json',
            )
            if isinstance(data, dict):
                return data.get('streams') or []
        except Exception:
            #log_utils.log('_fetch_streams', 1)
            pass
        return []


    def _parse_stream(self, stream):
        name = stream.get('name', '') or ''
        desc = stream.get('description', '') or ''
        url = stream.get('url', '') or ''
        hints = stream.get('behaviorHints', {}) or {}
        if not isinstance(hints, dict):
            hints = {}
        raw_name = hints.get('filename') or ''
        if not raw_name:
            for line in (desc or '').split('\n'):
                cleaned = re.sub(r'\[[^\]]*\]', ' ', line or '').strip()
                cleaned = ' '.join(cleaned.split())
                if re.search(r'(?:s\d{1,2}e\d{1,3}|2160p|1080p|720p|2160)', cleaned, re.I):
                    raw_name = cleaned
                    break
        if not raw_name or raw_name.lower() in ('hdhub', 'hdhub4u', '4khdhub', '4khdhub 4k'):
            from_url = source_utils.filename_from_url(url)
            if from_url:
                raw_name = from_url
            elif name and name.lower() not in ('hdhub', 'hdhub4u'):
                raw_name = name

        size_str = ''
        size_bytes = hints.get('videoSize', 0) or 0
        if size_bytes:
            size_str = self._fmt_size(size_bytes)
        else:
            m = re.search(r'💾\s*([\d.]+\s*(?:GB|MB))', desc, re.I)
            if m:
                size_str = m.group(1).strip()

        quality = (source_utils.advertised_quality(raw_name, desc)
                   or source_utils.advertised_quality(name)
                   or '')

        codec = ''
        if re.search(r'HEVC|x265|H\.265|H265', desc, re.I):
            codec = 'HEVC'
        elif re.search(r'AVC|x264|H\.264|H264', desc, re.I):
            codec = 'AVC'

        audio = ''
        for tag, pat in (
            ('Hindi', r'hindi'), ('Tamil', r'tamil'), ('Telugu', r'telugu'),
            ('Dual', r'dual.?audio'), ('Multi', r'multi.?audio'), ('English', r'english'),
        ):
            if re.search(pat, desc, re.I):
                audio = tag
                break

        hdr = ''
        if re.search(r'HDR10\+', desc, re.I):
            hdr = 'HDR10+'
        elif re.search(r'HDR10', desc, re.I):
            hdr = 'HDR10'
        elif re.search(r'DV|Dolby.?Vision', desc, re.I):
            hdr = 'DV'
        elif re.search(r'\bHDR\b', desc, re.I):
            hdr = 'HDR'

        rtype = ''
        if re.search(r'REMUX', desc, re.I):
            rtype = 'REMUX'
        elif re.search(r'BluRay|BDRip', desc, re.I):
            rtype = 'BluRay'
        elif re.search(r'WEB-?DL', desc, re.I):
            rtype = 'WEB-DL'
        elif re.search(r'WEBRip', desc, re.I):
            rtype = 'WEBRip'

        url_l = url.lower()
        if 'pixeldrain' in url_l:
            server = 'PixelDrain'
        elif 'drive.google' in url_l or 'googleusercontents' in url_l:
            server = 'Drive'
        elif 'telegramcdn' in url_l or 'telegram' in url_l:
            server = 'TG CDN'
        elif 'workers.dev' in url_l or 'fsl-bucket' in url_l:
            server = 'CDN'
        elif url.startswith('magnet:') or url.endswith('.torrent'):
            server = 'Torrent'
        else:
            server = ''
            lines = [l.strip() for l in desc.split('\n') if l.strip()]
            if lines:
                m = re.search(r'^([A-Za-z0-9_\-\.v]+)\s*\|', lines[-1])
                if m:
                    server = m.group(1).strip()

        return {
            'url': url,
            'quality': quality,
            'codec': codec,
            'audio': audio,
            'hdr': hdr,
            'rtype': rtype,
            'size_str': size_str,
            'server': server,
            'raw_name': raw_name or name,
        }


    def _fmt_size(self, nbytes):
        try:
            if nbytes >= 1073741824:
                return '%.1f GB' % (float(nbytes) / 1073741824)
            if nbytes >= 1048576:
                return '%.1f MB' % (float(nbytes) / 1048576)
        except Exception:
            pass
        return ''


    def _stream_hay(self, stream):
        hints = stream.get('behaviorHints') or {}
        if not isinstance(hints, dict):
            hints = {}
        url = stream.get('url') or ''
        parts = [
            stream.get('name') or '',
            stream.get('title') or '',
            stream.get('description') or '',
            url,
            hints.get('filename') or '',
            hints.get('bingeGroup') or '',
        ]
        try:
            if url:
                parts.append(unquote(url))
        except Exception:
            pass
        return source_utils.release_hay(' '.join(str(p) for p in parts if p))


    def _build_info(self, parsed):
        parts = []
        for key in ('server', 'quality', 'codec', 'hdr', 'rtype', 'audio', 'size_str'):
            val = parsed.get(key)
            if val:
                parts.append(val)
        raw = ' '.join((parsed.get('raw_name') or '').split())
        if raw and raw not in parts:
            parts.append(raw)
        if parts:
            return ' | '.join(parts)
        return 'HdHub'


    def _append_stream(self, hostDict, stream):
        try:
            hay = self._stream_hay(stream)
            if self._season is not None and not source_utils.episode_release_matches(
                    hay, self._title, self._season, self._episode, self._year):
                return
            parsed = self._parse_stream(stream)
            url = parsed.get('url')
            if not url or url.startswith('magnet:') or url.endswith('.torrent'):
                return
            if not url.startswith('http'):
                return
            info = self._build_info(parsed)
            quality = parsed.get('quality') or None
            item = scrape_sources.make_direct_item(
                hostDict, url, host='Direct', info=info, prep=True, quality=quality)
            if not item.get('url'):
                return
            raw = ' '.join((parsed.get('raw_name') or '').split())
            if raw and not item.get('name'):
                shown = source_utils.display_filename(raw)
                if shown:
                    item['name'] = shown
            if scrape_sources.check_host_limit(item['source'], self.results):
                return
            self.results.append(item)
        except Exception:
            #log_utils.log('_append_stream', 1)
            pass


    def sources(self, url, hostDict):
        try:
            if not url:
                return self.results
            data = parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
            resource = self._resource_id(data.get('imdb'), data.get('tmdb'))
            if not resource:
                return self.results
            media = data.get('media', 'movie')
            self._title = data.get('title') or ''
            self._year = data.get('year') or ''
            self._season = None
            self._episode = None
            if media == 'series':
                season = data.get('season')
                episode = data.get('episode')
                if not (season and episode):
                    return self.results
                self._season, self._episode = int(season), int(episode)
                streams = self._fetch_streams('series', '%s:%s:%s' % (resource, self._season, self._episode))
            else:
                streams = self._fetch_streams('movie', resource)
            for stream in streams:
                self._append_stream(hostDict, stream)
            return self.results
        except Exception:
            #log_utils.log('sources', 1)
            return self.results


    def resolve(self, url):
        return url
