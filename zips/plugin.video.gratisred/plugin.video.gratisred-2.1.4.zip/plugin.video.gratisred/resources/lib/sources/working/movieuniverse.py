import re
from six.moves.urllib_parse import parse_qs, urlencode, urlparse

from resources.lib.modules import buzz_player
from resources.lib.modules import client
from resources.lib.modules import scrape_sources
from resources.lib.modules import source_utils


BASE = 'https://movieuniverse.skin'
_PLAYER = re.compile(
    r"""(?:data-src|src|go\(\s*['"])(https://videm\.(?:buzz|xyz)/embed/(?:movie|tv)/[^'"\s>]+)""",
    re.I)
_EMBED = re.compile(r'^/embed/(movie|tv)/(tt\d+|\d+)(?:/(\d+)/(\d+))?/?$')


class source:
    def __init__(self):
        self.results = []
        self.domains = ['movieuniverse.skin', 'videm.buzz', 'videm.xyz']
        self.base_link = BASE
        self.headers = {
            'User-Agent': client.UserAgent,
            'Referer': BASE + '/home',
        }


    def movie(self, imdb, tmdb, title, localtitle, aliases, year):
        if not str(tmdb or '').isdigit() or str(tmdb) in ('0', 'None'):
            return
        return urlencode({'tmdb': tmdb, 'media': 'movie'})


    def tvshow(self, imdb, tmdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        if not str(tmdb or '').isdigit() or str(tmdb) in ('0', 'None'):
            return
        return urlencode({'tmdb': tmdb, 'media': 'tv'})


    def episode(self, url, imdb, tmdb, tvdb, title, premiered, season, episode):
        if not url:
            return
        url = parse_qs(url)
        url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
        url['season'], url['episode'] = season, episode
        return urlencode(url)


    def _watch(self, tmdb, media, season=None, episode=None):
        if media == 'tv':
            if not season or not episode:
                return ''
            return '%s/watch-tv-%s&season=%s&episode=%s' % (BASE, tmdb, season, episode)
        return '%s/watch-movieuniverse-%s' % (BASE, tmdb)


    def _player(self, html, tmdb, media, season=None, episode=None):
        for raw in _PLAYER.findall(html or ''):
            parsed = urlparse(raw)
            host = (parsed.hostname or '').lower()
            if host not in buzz_player.HOSTS:
                continue
            match = _EMBED.match(parsed.path)
            ident = match.group(2) if match else ''
            if not match or match.group(1) != media:
                continue
            if ident.isdigit() and ident != str(tmdb):
                continue
            if media == 'tv':
                if match.group(3) != str(season) or match.group(4) != str(episode):
                    continue
            elif match.group(3):
                continue
            return raw
        return ''


    def sources(self, url, hostDict):
        try:
            if not url:
                return self.results
            data = parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
            tmdb = data.get('tmdb')
            media = data.get('media') or 'movie'
            page = self._watch(tmdb, media, data.get('season'), data.get('episode'))
            if not page:
                return self.results
            html = client.request(page, headers=self.headers, timeout='12') or ''
            player = self._player(html, tmdb, media, data.get('season'), data.get('episode'))
            if not player:
                return self.results
            urls, headers = buzz_player.resolve_url(player, referer=page)
            for link in urls:
                play = link + source_utils.append_headers(headers) if headers else link
                item = scrape_sources.make_direct_item(hostDict, play, host='Direct', info='MovieUniverse')
                if item.get('url') and item['url'] not in [row.get('url') for row in self.results]:
                    if not scrape_sources.check_host_limit(item['source'], self.results):
                        self.results.append(item)
            return self.results
        except Exception:
            return self.results


    def resolve(self, url):
        return url
