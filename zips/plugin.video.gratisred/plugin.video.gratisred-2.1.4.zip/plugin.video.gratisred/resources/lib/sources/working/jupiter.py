from six.moves.urllib_parse import parse_qs, urlencode

from resources.lib.modules import client
from resources.lib.modules import scrape_sources
from resources.lib.modules import source_utils


API = 'https://vidrack.created.app/api/sources/movy'


class source:
    def __init__(self):
        self.results = []
        self.domains = ['vidrack.created.app']
        self.base_link = 'https://vidrack.created.app'
        self.headers = {
            'User-Agent': client.UserAgent,
            'Accept': 'application/json',
        }


    def movie(self, imdb, tmdb, title, localtitle, aliases, year):
        if not str(tmdb or '').isdigit() or str(tmdb) in ('0', 'None'):
            return
        return urlencode({'tmdb': tmdb, 'media': 'movie'})


    def tvshow(self, imdb, tmdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        if not str(tmdb or '').isdigit() or str(tmdb) in ('0', 'None'):
            return
        return urlencode({'tmdb': tmdb, 'media': 'tv'})


    def episode(self, url, imdb, tmdb, tvdb, title, premiered, season, episode):
        if not url:
            return
        url = parse_qs(url)
        url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
        url['season'], url['episode'] = season, episode
        return urlencode(url)


    def sources(self, url, hostDict):
        try:
            if not url:
                return self.results
            data = parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
            tmdb = data.get('tmdb')
            if not tmdb:
                return self.results
            query = {'id': tmdb, 'type': data.get('media') or 'movie'}
            if query['type'] == 'tv':
                if not data.get('season') or not data.get('episode'):
                    return self.results
                query['season'], query['episode'] = data['season'], data['episode']
            payload = client.request(API + '?' + urlencode(query), headers=self.headers,
                                     timeout='20', output='json')
            rows = payload.get('sources') if isinstance(payload, dict) else None
            if not isinstance(rows, list):
                return self.results
            rows = [row for row in rows if isinstance(row, dict)]
            preferred = [row for row in rows if 'phoenix-1080p' in str(row.get('provider') or '')
                         or ('Phoenix' in str(row.get('label') or '')
                             and '1080' in str(row.get('quality') or ''))]
            ordered = preferred + [row for row in rows if row not in preferred]
            for row in ordered[:8]:
                link = row.get('url')
                if not isinstance(link, str) or not link.startswith('http'):
                    continue
                headers = dict(self.headers)
                extra = row.get('headers')
                if isinstance(extra, dict):
                    headers.update({k: v for k, v in extra.items()
                                    if isinstance(k, str) and isinstance(v, str)})
                play = link + source_utils.append_headers(headers)
                label = row.get('label') or row.get('quality') or row.get('provider') or ''
                quality = source_utils.advertised_quality(
                    row.get('label'), row.get('quality'), row.get('provider'))
                item = scrape_sources.make_direct_item(
                    hostDict, play, host='Direct', info=('Jupiter %s' % label).strip(), quality=quality)
                if item.get('url') and item['url'] not in [r.get('url') for r in self.results]:
                    if not scrape_sources.check_host_limit(item['source'], self.results):
                        self.results.append(item)
            return self.results
        except Exception:
            return self.results


    def resolve(self, url):
        return url
