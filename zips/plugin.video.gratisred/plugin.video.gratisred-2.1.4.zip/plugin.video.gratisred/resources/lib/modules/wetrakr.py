# -*- coding: utf-8 -*-
"""WeTrakr lists, watched indicators, and playback scrobble.

Device OAuth uses Gratis Red's WeTrakr app key. The device login sends that
key only, with no client secret. Playback is sent only while WeTrakr is the
Watched Indicators provider, and is left to script.wetrakr when that add-on
is authorised and set to scrobble plugin streams.
"""
from __future__ import absolute_import

import json
import re
import threading
import time

import requests

from resources.lib.modules import cache
from resources.lib.modules import control
from resources.lib.modules import log_utils

BASE_URL = 'https://api.wetrakr.com'
# Gratis Red's WeTrakr app key. Device login sends this id only.
WETRAKR_CLIENT_ID = '797d00711ab84225d2963dfc9dffe2cf'
_POLL_STOP = ('expired_token', 'access_denied', 'invalid_code', 'already_used', 'invalid_client', 'locked_client')
_DEAD_GRANT_PROP = 'gratisred.wetrakr_dead_grant'
_REFRESH_PROP = 'gratisred.wetrakr_refresh_lock'
_SYNC_PROP = 'gratisred.wetrakr_sync_lock'
_PLAY_RECORDED_PROP = 'gratisred.wetrakr_play_recorded'
_REFRESH_LOCK = threading.Lock()
_SYNC_LOCK = threading.Lock()
_WATCH_POINT = 92

_MOVIE_STATUSES = (
    ('planning', 'Plan to Watch'),
    ('watched', 'Watched'),
    ('dropped', 'Dropped'),
)
_SHOW_STATUSES = (
    ('planning', 'Plan to Watch'),
    ('watching', 'Watching'),
    ('paused', 'Paused'),
    ('waiting', 'Waiting'),
    ('watched', 'Watched'),
    ('dropped', 'Dropped'),
)
_DISCOVER = {
    'wetrakr_trending': '/discover/trending',
    'wetrakr_popular': '/discover/popular',
    'wetrakr_toprated': '/discover/toprated',
}


def _log(message):
    try:
        log_utils.log('WeTrakr: %s' % message, 1)
    except Exception:
        pass


def _version():
    try:
        return control.addonInfo('version') or '0'
    except Exception:
        return '0'


def _user_agent():
    return 'GratisRed-WeTrakr/%s' % _version()


def _client_id():
    return WETRAKR_CLIENT_ID


def _usable(value):
    return value not in (None, '0', '', 'empty_setting')


def _token():
    return (control.setting('wetrakr.token') or '').strip()


def _refresh_token():
    return (control.setting('wetrakr.refresh') or '').strip()


def _expires_at():
    try:
        return float(control.setting('wetrakr.expires') or 0)
    except (TypeError, ValueError):
        return 0.0


def _user():
    return (control.setting('wetrakr.user') or '').strip() or 'wetrakr'


def getWeTrakrCredentialsInfo():
    return bool(_usable(_token()) and (control.setting('wetrakr.user') or '').strip())


def _grant_expiring():
    expires = _expires_at()
    if expires <= 0:
        return _usable(_refresh_token())
    return time.time() >= (expires - 120)


def _parse_int(value):
    if value in (None, '', 'None', 'empty_setting', 0, '0'):
        return None
    try:
        result = int(value)
    except (TypeError, ValueError):
        return None
    return result if result > 0 else None


def _normalize_imdb(imdb):
    imdb = str(imdb or '').strip()
    if not imdb or imdb in ('0', 'None'):
        return '0'
    if imdb.startswith('tt'):
        return imdb
    digits = re.sub(r'[^0-9]', '', imdb)
    return ('tt' + digits) if digits else '0'


def _year_text(value):
    try:
        year = re.sub(r'[^0-9]', '', str(value or ''))[:4]
    except Exception:
        year = ''
    return year or '0'


def _grant_value(data, names):
    if not isinstance(data, dict):
        return None
    for name in names:
        value = data.get(name)
        if _usable(value) and not isinstance(value, (dict, list)):
            return value
    for nested_key in ('data', 'token', 'tokens', 'grant', 'oauth'):
        nested = data.get(nested_key)
        if isinstance(nested, dict):
            found = _grant_value(nested, names)
            if found:
                return found
    return None


def _grant_expires_in(data):
    raw = data.get('expires_in') if isinstance(data, dict) else None
    if raw in (None, '') and isinstance(data, dict):
        for nested_key in ('data', 'token', 'tokens', 'grant', 'oauth'):
            nested = data.get(nested_key)
            if isinstance(nested, dict) and nested.get('expires_in') not in (None, ''):
                raw = nested.get('expires_in')
                break
    try:
        return int(raw or 604800)
    except (TypeError, ValueError):
        return 604800


def _save_grant(data, require_refresh=True):
    access = _grant_value(data, ('access_token', 'accessToken'))
    refresh = _grant_value(data, ('new_refresh_token', 'newRefreshToken', 'refresh_token', 'refreshToken'))
    if not access or (require_refresh and not refresh):
        return False
    expires_in = _grant_expires_in(data)
    control.setSetting('wetrakr.token', access)
    if refresh:
        control.setSetting('wetrakr.refresh', refresh)
    control.setSetting('wetrakr.expires', str(int(time.time()) + max(120, expires_in)))
    try:
        control.window.clearProperty(_DEAD_GRANT_PROP)
    except Exception:
        pass
    try:
        from resources.lib.modules.meta_auth_alerts import clear_alert
        clear_alert('wetrakr')
    except Exception:
        pass
    return True


def _clear_grant():
    for key, value in (
        ('wetrakr.user', ''),
        ('wetrakr.token', ''),
        ('wetrakr.refresh', ''),
        ('wetrakr.expires', ''),
        ('wetrakr.activities_json', ''),
    ):
        control.setSetting(key, value)
    try:
        control.window.clearProperty(_DEAD_GRANT_PROP)
    except Exception:
        pass


def _mark_dead_grant(status_code, body=None):
    try:
        control.window.setProperty(_DEAD_GRANT_PROP, 'true')
    except Exception:
        pass
    try:
        from resources.lib.modules.meta_auth_alerts import maybe_notify_refresh_failure
        maybe_notify_refresh_failure('wetrakr', status_code, body)
    except Exception:
        pass


def _oauth_headers():
    return {
        'Content-Type': 'application/json',
        'User-Agent': _user_agent(),
        'wetrakr-api-version': '1',
    }


def _api_headers(token=None):
    headers = {
        'Content-Type': 'application/json',
        'User-Agent': _user_agent(),
        'wetrakr-api-key': _client_id(),
        'wetrakr-api-version': '1',
    }
    if token:
        headers['Authorization'] = 'Bearer %s' % token
    return headers


def _claim_refresh_window():
    owner = '%s-%s' % (time.time(), threading.current_thread().ident or 0)
    try:
        raw = str(control.window.getProperty(_REFRESH_PROP) or '')
        if raw:
            try:
                stamp = float(raw.split('-', 1)[0])
            except (TypeError, ValueError):
                stamp = 0
            if stamp and (time.time() - stamp) < 20:
                return ''
        control.window.setProperty(_REFRESH_PROP, owner)
        control.sleep(50)
        if str(control.window.getProperty(_REFRESH_PROP) or '') != owner:
            return ''
    except Exception:
        return owner
    return owner


def _release_refresh_window(owner):
    try:
        if owner and str(control.window.getProperty(_REFRESH_PROP) or '') == owner:
            control.window.clearProperty(_REFRESH_PROP)
    except Exception:
        pass


def _refresh_access_token(force=False):
    if control.window.getProperty(_DEAD_GRANT_PROP) == 'true':
        return False
    refresh = _refresh_token()
    if not _usable(refresh):
        if force:
            _mark_dead_grant(401, 'missing refresh token')
        return False
    with _REFRESH_LOCK:
        if not force and _usable(_token()) and not _grant_expiring():
            return True
        seen_refresh, seen_access = _refresh_token(), _token()
        owner = _claim_refresh_window()
        if not owner:
            for _ in range(25):
                control.sleep(200)
                if (_refresh_token() != seen_refresh or _token() != seen_access) and _usable(_token()):
                    return True
            return False
        try:
            if not force and _usable(_token()) and not _grant_expiring():
                return True
            body = {'refresh_token': _refresh_token(), 'client_id': _client_id()}
            resp = requests.post(
                '%s/oauth/token/refresh' % BASE_URL,
                data=json.dumps(body), headers=_oauth_headers(), timeout=15)
            if resp.status_code == 401:
                _log('refresh failed: HTTP 401')
                _mark_dead_grant(401, resp.text)
                return False
            if resp.status_code != 200:
                _log('refresh failed: HTTP %s' % resp.status_code)
                return False
            try:
                payload = resp.json() or {}
            except Exception:
                payload = {}
            if not _save_grant(payload, require_refresh=True):
                _log('refresh failed: missing rotated tokens')
                return False
            return True
        except Exception as e:
            _log('refresh failed: %s' % e)
            return False
        finally:
            _release_refresh_window(owner)


def _request(method, path, params=None, data=None, user=True, timeout=20, _retried=False, _auth_retried=False):
    if not _client_id():
        return None, {}
    if user:
        if control.window.getProperty(_DEAD_GRANT_PROP) == 'true':
            return None, {}
        if _grant_expiring():
            _refresh_access_token()
        token = _token()
        if not _usable(token):
            return None, {}
    else:
        token = None
    headers = _api_headers(token)
    url = '%s%s' % (BASE_URL, path)
    try:
        if method == 'GET':
            resp = requests.get(url, params=params or {}, headers=headers, timeout=timeout)
        elif method == 'DELETE':
            kwargs = {'headers': headers, 'timeout': timeout}
            if params:
                kwargs['params'] = params
            if data is not None:
                kwargs['data'] = json.dumps(data)
            resp = requests.delete(url, **kwargs)
        else:
            resp = requests.post(url, params=params or {}, data=json.dumps(data or {}), headers=headers, timeout=timeout)
    except Exception as e:
        _log('request failed: %s' % e)
        return None, {}
    if resp.status_code == 429 and not _retried:
        try:
            wait = int(float(resp.headers.get('Retry-After') or resp.headers.get('RateLimit-Reset') or 2))
        except (TypeError, ValueError):
            wait = 2
        control.sleep(max(1, min(wait, 5)) * 1000)
        return _request(method, path, params, data, user, timeout, True, _auth_retried)
    if resp.status_code == 420:
        try:
            body = resp.json()
        except Exception:
            body = {}
        if not isinstance(body, dict):
            body = {}
        body['_locked'] = True
        return body, resp.headers
    if resp.status_code == 404:
        return {'_missing': True}, resp.headers
    if resp.status_code in (401, 403):
        if resp.status_code == 401 and user and not _auth_retried and _refresh_access_token(force=True):
            return _request(method, path, params, data, user, timeout, _retried, True)
        _log('Auth rejected (HTTP %s)' % resp.status_code)
        if user:
            _mark_dead_grant(resp.status_code, resp.text)
        return None, resp.headers
    if not (200 <= resp.status_code < 300):
        message = ''
        try:
            body = resp.json()
            if isinstance(body, dict):
                message = body.get('message') or body.get('error') or ''
        except Exception:
            message = ''
        _log('HTTP %s %s %s' % (resp.status_code, path, message))
        return None, resp.headers
    try:
        return resp.json(), resp.headers
    except Exception:
        return None, resp.headers


def _api(method, path, params=None, data=None, user=True, timeout=20):
    payload, _headers = _request(method, path, params, data, user, timeout)
    return payload


def _rows(payload):
    if isinstance(payload, list):
        return payload
    if isinstance(payload, dict):
        for key in ('data', 'items', 'results'):
            if isinstance(payload.get(key), list):
                return payload[key]
    return []


def _page_count(headers):
    try:
        return int((headers or {}).get('X-Pagination-Page-Count') or 0)
    except (TypeError, ValueError):
        return 0


def _get_pages(path, params=None, limit=100, max_pages=40, user=True):
    base = dict(params or {})
    rows = []
    for page in range(1, max_pages + 1):
        query = dict(base)
        query['page'] = page
        query['limit'] = limit
        payload, headers = _request('GET', path, params=query, user=user)
        if isinstance(payload, dict) and payload.get('_locked'):
            if page == 1:
                control.infoDialog('This WeTrakr list is over the plan limit', sound=True)
            break
        batch = _rows(payload)
        if not batch:
            break
        rows.extend(batch)
        total_pages = _page_count(headers)
        if total_pages and page >= total_pages:
            break
        try:
            actual = int((headers or {}).get('X-Pagination-Limit') or limit)
        except (TypeError, ValueError):
            actual = limit
        if len(batch) < actual:
            break
    return rows


def _external_id(ids, key):
    if not isinstance(ids, dict):
        return None
    value = ids.get(key)
    if isinstance(value, dict):
        value = value.get('id')
    if value in (None, '', 'None', 0, '0'):
        return None
    if key == 'imdb':
        text = _normalize_imdb(value)
        return text if text != '0' else None
    return _parse_int(value) or (str(value).strip() or None)


def _kind_target(media_kind):
    return 'movies' if media_kind in ('movies', 'movie') else 'shows'


def _list_item_kind(entry):
    raw = str((entry or {}).get('type') or (entry or {}).get('media_type') or '').lower()
    if raw in ('movie', 'movies'):
        return 'movie'
    if raw in ('show', 'shows', 'tv', 'tvshow', 'series'):
        return 'show'
    return ''


def _user_rating(entry):
    if not isinstance(entry, dict):
        return None
    direct = entry.get('rating')
    if isinstance(direct, dict):
        nested = direct.get('rating')
        if nested not in (None, ''):
            return nested
    block = entry.get('interactions')
    if isinstance(block, dict):
        user = block.get('user')
        if isinstance(user, dict) and isinstance(user.get('rating'), dict):
            nested = user['rating'].get('rating')
            if nested not in (None, ''):
                return nested
    for key in ('score', 'user_rating', 'userRating'):
        if entry.get(key) not in (None, ''):
            return entry.get(key)
    return None


def _media_rows(entries):
    rows = []
    for entry in entries or []:
        if not isinstance(entry, dict):
            continue
        ids = entry.get('ids') or {}
        tmdb, imdb, tvdb = _external_id(ids, 'tmdb'), _external_id(ids, 'imdb'), _external_id(ids, 'tvdb')
        if not tmdb and not imdb:
            continue
        media_ids = {}
        if tmdb:
            media_ids['tmdb'] = tmdb
        if imdb:
            media_ids['imdb'] = imdb
        if tvdb:
            media_ids['tvdb'] = tvdb
        released = entry.get('release_date') or entry.get('released') or ''
        row = {
            'media_ids': media_ids,
            'title': entry.get('title') or '',
            'year': _year_text(entry.get('year') or released),
            'release_date': str(released or '')[:10],
            'collected_at': entry.get('list_item_created_at') or entry.get('listed_at') or entry.get('created_at')
                or entry.get('added_at') or entry.get('updated_at') or '',
        }
        rating = _user_rating(entry)
        if rating not in (None, ''):
            try:
                row['rating'] = float(rating)
            except (TypeError, ValueError):
                pass
        kind = _list_item_kind(entry)
        if kind:
            row['type'] = kind
        rows.append(row)
    return rows


def _directory_rows(items, media):
    out = []
    for item in items or []:
        ids = item.get('media_ids') or item.get('ids') or {}
        title = item.get('title') or 'Unknown'
        year = _year_text(item.get('year') or item.get('release_date'))
        row = {
            'title': title,
            'originaltitle': title,
            'year': year,
            'imdb': _normalize_imdb(ids.get('imdb')),
            'tmdb': str(ids.get('tmdb') or '0'),
            'tvdb': str(ids.get('tvdb') or '0'),
            'next': '',
            'paused_at': '0',
            'collected_at': item.get('collected_at') or '',
            'release_date': item.get('release_date') or '',
        }
        if item.get('rating') not in (None, ''):
            row['rating'] = item.get('rating')
        if media == 'movies':
            row['paused_at'] = item.get('paused_at') or '0'
            if item.get('progress') not in (None, ''):
                row['progress'] = item.get('progress')
        out.append(row)
    return out


def _sort_directory(rows, media, shelf):
    from resources.lib.modules import shelf_sort
    if shelf == 'rated':
        try:
            rows = sorted(rows, key=lambda i: float(i.get('rating') or 0), reverse=True)
        except Exception:
            pass
    return shelf_sort.sort_items(rows, 'wetrakr', 'movies' if media == 'movies' else 'tvshows', shelf, sortable=shelf_sort.WETRAKR_SORTABLE)


def _api_status(status):
    """Menu shelves use plantowatch, the same name as Simkl. WeTrakr stores that shelf as planning."""
    if status == 'plantowatch':
        return 'planning'
    return status


def _status_entries(status, media_kind):
    if not getWeTrakrCredentialsInfo():
        return []
    target = _kind_target(media_kind)
    return _media_rows(_get_pages('/sync/tracking/%s/%s' % (_api_status(status), target)))


def _favorites_entries(media_kind):
    if not getWeTrakrCredentialsInfo():
        return []
    target = _kind_target(media_kind)
    return _media_rows(_get_pages('/sync/favorites/%s' % target))


def _rated_entries(media_kind):
    if not getWeTrakrCredentialsInfo():
        return []
    target = _kind_target(media_kind)
    wanted = 'movie' if target == 'movies' else 'show'
    unpacked = []
    for entry in _get_pages('/sync/ratings/%s' % target):
        if not isinstance(entry, dict):
            continue
        media = entry.get(wanted) if isinstance(entry.get(wanted), dict) else None
        if media is None and isinstance(entry.get('ids'), dict):
            media = entry
        if not media:
            continue
        row = dict(media)
        rating = _user_rating(entry)
        if rating not in (None, ''):
            row['rating'] = rating
        rated_at = entry.get('rated_at') or ''
        if rated_at and not row.get('list_item_created_at'):
            row['list_item_created_at'] = rated_at
        unpacked.append(row)
    return _media_rows(unpacked)


def _shelf_entries(status, media_kind):
    if status == 'favorites':
        return _favorites_entries(media_kind)
    if status == 'rated':
        return _rated_entries(media_kind)
    return _status_entries(status, media_kind)


def directory_movies(status):
    rows = _directory_rows(_shelf_entries(status, 'movies'), 'movies')
    return _sort_directory(rows, 'movies', status)


def directory_tvshows(status):
    if status == 'paused':
        # Manager writes show "Paused" as hold. The paused shelf also keeps a halfway pause.
        seen = set()
        items = []
        for entry in _status_entries('paused', 'shows') + _status_entries('hold', 'shows'):
            tmdb = str((entry.get('media_ids') or {}).get('tmdb') or '')
            imdb = str((entry.get('media_ids') or {}).get('imdb') or '')
            key = tmdb or imdb
            if key and key in seen:
                continue
            if key:
                seen.add(key)
            items.append(entry)
    else:
        items = _shelf_entries(status, 'shows')
    rows = _directory_rows(items, 'tvshows')
    return _sort_directory(rows, 'tvshows', status)


def directory_playing_movies():
    out = []
    for item in _playing_rows('movies'):
        try:
            percent = float(item.get('progress') or 0)
        except (TypeError, ValueError):
            percent = 0
        if percent <= 1:
            continue
        item = dict(item)
        item['paused_at'] = re.sub(r'[^0-9]+', '', str(item.get('tracked_at') or '')) or '0'
        item['progress'] = percent
        out.append(item)
    rows = _directory_rows(out, 'movies')
    try:
        rows.sort(key=lambda k: int(k.get('paused_at') or 0), reverse=True)
    except Exception:
        pass
    return rows


def directory_discover(media, action, page_no=1):
    target = 'movies' if media == 'movies' else 'shows'
    kind = 'movie' if target == 'movies' else 'show'
    path = _DISCOVER.get(action)
    if not path:
        return []
    try:
        page = max(int(page_no or 1), 1)
    except (TypeError, ValueError):
        page = 1
    payload, headers = _request('GET', path, params={'filter_type': kind, 'page': page, 'limit': 20}, user=False)
    if isinstance(payload, dict) and payload.get('_locked'):
        control.infoDialog('This WeTrakr list is over the plan limit', sound=True)
        return []
    entries = _rows(payload) if not isinstance(payload, list) else payload
    wanted = 'movie' if kind == 'movie' else 'show'
    matched = []
    for entry in entries:
        if not isinstance(entry, dict) or entry.get('type') == 'list':
            continue
        raw = _list_item_kind(entry)
        if raw and raw != wanted:
            continue
        matched.append(entry)
    rows = _directory_rows(_media_rows(matched), media)
    pages = _page_count(headers) or 1
    nxt = '%s|%s' % (action, page + 1) if page < pages else ''
    for row in rows:
        row['next'] = nxt
    return rows


def directory_list(list_id, media, public=False):
    if not public and not getWeTrakrCredentialsInfo():
        return []
    target = 'movies' if media == 'movies' else 'shows'
    wanted = 'movie' if target == 'movies' else 'show'
    query = {'sort_by': 'editor_rank', 'sort_dir': 'asc'}
    path = '/lists/%s/items/%s' % (list_id, target)
    entries = _get_pages(path, query, user=not public, max_pages=20)
    if not entries and not public:
        mixed = _get_pages('/sync/lists/%s/items' % list_id, query)
        entries = [i for i in mixed if _list_item_kind(i) == wanted or (i.get('type') or '').lower() in (wanted, target)]
    rows = _directory_rows(_media_rows(entries), media)
    from resources.lib.modules import shelf_sort
    shelf = shelf_sort.personal_shelf_key(list_id)
    return shelf_sort.sort_items(rows, 'wetrakr', 'movies' if media == 'movies' else 'tvshows', shelf)


def user_lists():
    if not getWeTrakrCredentialsInfo():
        return []
    rows = [i for i in _rows(_api('GET', '/sync/lists', params={'sort': 'name', 'dir': 'asc'})) if isinstance(i, dict) and i.get('id')]
    rows.sort(key=lambda item: (item.get('name') or '').lower())
    return rows


def prepare_user_lists(lists):
    """One row per list. A list opens as movies, shows, or one mixed folder, matching Trakt."""
    rows = [item for item in (lists or []) if isinstance(item, dict) and item.get('id')]
    actions = {}
    lock = threading.Lock()

    def _probe(item):
        list_id = item.get('id')
        has_movie = _list_has_items(list_id, 'movies', user=True)
        has_show = _list_has_items(list_id, 'shows', user=True)
        if has_movie and has_show:
            action = 'wetrakr_mixed'
        elif has_show:
            action = 'tvshows'
        else:
            action = 'movies'
        with lock:
            actions[list_id] = action

    pending = []
    for item in rows:
        thread = threading.Thread(target=_probe, args=(item,))
        thread.daemon = True
        thread.start()
        pending.append(thread)
        if len(pending) >= 8:
            pending.pop(0).join()
    for thread in pending:
        thread.join()
    prepared = []
    for item in rows:
        row = dict(item)
        row['action'] = actions.get(item.get('id')) or 'movies'
        prepared.append(row)
    return prepared


def mixed_directory_rows(list_id):
    """Movies and shows from one of your lists, in that list's order."""
    if not list_id or not getWeTrakrCredentialsInfo():
        return []
    query = {'sort_by': 'editor_rank', 'sort_dir': 'asc'}
    entries = _get_pages('/sync/lists/%s/items' % list_id, query, max_pages=20)
    if not entries:
        movies = _get_pages('/lists/%s/items/movies' % list_id, query, max_pages=20)
        shows = _get_pages('/lists/%s/items/shows' % list_id, query, max_pages=20)
        for entry in movies:
            if isinstance(entry, dict) and not _list_item_kind(entry):
                entry['type'] = 'movie'
        for entry in shows:
            if isinstance(entry, dict) and not _list_item_kind(entry):
                entry['type'] = 'show'
        entries = list(movies or []) + list(shows or [])
    rows = []
    for index, entry in enumerate(entries or []):
        kind = _list_item_kind(entry)
        if kind not in ('movie', 'show'):
            continue
        built = _directory_rows(_media_rows([entry]), 'movies' if kind == 'movie' else 'tvshows')
        if not built:
            continue
        row = built[0]
        row['_mix'] = index
        row['_kind'] = 'movie' if kind == 'movie' else 'tvshow'
        rows.append(row)
    from resources.lib.modules import shelf_sort
    shelf = shelf_sort.personal_shelf_key(list_id)
    return shelf_sort.sort_items(rows, 'wetrakr', 'mixed', shelf, sortable=shelf_sort.WETRAKR_SORTABLE)


def _list_targets(item):
    dyn = item.get('dynamic') if isinstance(item, dict) and isinstance(item.get('dynamic'), dict) else {}
    targets = dyn.get('targets') or (item.get('targets') if isinstance(item, dict) else None) or []
    if isinstance(targets, str):
        targets = [targets]
    if not isinstance(targets, (list, tuple)):
        return []
    return [str(part).lower() for part in targets if part]


def _list_has_items(list_id, target, user=False):
    payload, _headers = _request(
        'GET', '/lists/%s/items/%s' % (list_id, target),
        params={'page': 1, 'limit': 1}, user=user)
    if payload is None:
        return not user
    if isinstance(payload, dict) and (payload.get('_missing') or payload.get('_locked')):
        return False
    rows = payload if isinstance(payload, list) else _rows(payload)
    return bool(rows)


def _keep_lists_for_media(items, media):
    """Movie menus keep lists that contain movies. TV menus keep lists that contain shows."""
    wanted = 'movie' if media == 'movies' else 'show'
    target = 'movies' if wanted == 'movie' else 'shows'
    kept = []
    unknown = []
    for item in items:
        targets = _list_targets(item)
        if targets:
            if wanted in targets:
                kept.append(item)
        else:
            unknown.append(item)
    if unknown:
        found = []
        lock = threading.Lock()

        def _probe(item):
            if _list_has_items(item.get('id'), target):
                with lock:
                    found.append(item)

        pending = []
        for item in unknown:
            thread = threading.Thread(target=_probe, args=(item,))
            thread.daemon = True
            thread.start()
            pending.append(thread)
            if len(pending) >= 8:
                pending.pop(0).join()
        for thread in pending:
            thread.join()
        kept.extend(found)
    order = {}
    for index, item in enumerate(items):
        order[item.get('id')] = index
    kept.sort(key=lambda item: order.get(item.get('id'), 0))
    return kept


def public_lists(kind='trending', page_no=1, media=None):
    try:
        page = max(int(page_no or 1), 1)
    except (TypeError, ValueError):
        page = 1
    if kind == 'latest':
        path, params = '/lists/last', {'page': page, 'limit': 50}
    else:
        path, params = '/lists/trending', {'page': page, 'limit': 50}
    payload, headers = _request('GET', path, params=params, user=False)
    out = []
    for item in _rows(payload) if not isinstance(payload, list) else payload:
        if isinstance(item, dict) and item.get('id') and not item.get('locked'):
            out.append(item)
    full = len(out)
    if media in ('movies', 'tvshows'):
        out = _keep_lists_for_media(out, media)
    pages = _page_count(headers) or page
    if not _page_count(headers) and full >= 50:
        pages = page + 1
    result = []
    for item in out:
        result.append({'id': item.get('id'), 'name': item.get('name') or 'List'})
    return result, max(pages, page)


def choose_list_sort(media, status, label=None):
    from resources.lib.modules import shelf_sort
    shelf_sort.choose_list_sort('wetrakr', media, status, sortable=shelf_sort.WETRAKR_SORTABLE, heading_label=label)


def _playing_rows(target):
    if not getWeTrakrCredentialsInfo():
        return []
    out = []
    for item in _get_pages('/sync/tracking/playing/%s' % target, limit=100, max_pages=5):
        if not isinstance(item, dict):
            continue
        playback = item.get('playback') if isinstance(item.get('playback'), dict) else {}
        if target == 'movies' and isinstance(item.get('movie'), dict):
            node = dict(item['movie'])
            playback = playback or (item['movie'].get('playback') if isinstance(item['movie'].get('playback'), dict) else {})
        elif target == 'episodes' and isinstance(item.get('episode'), dict):
            node = dict(item['episode'])
            playback = playback or (item['episode'].get('playback') if isinstance(item['episode'].get('playback'), dict) else {})
        else:
            node = item
        try:
            percent = float(playback.get('progress_percent') or node.get('progress_percent') or item.get('progress_percent') or 0)
        except (TypeError, ValueError):
            percent = 0
        ids = node.get('ids') or item.get('ids') or {}
        show = node.get('show') if isinstance(node.get('show'), dict) else item.get('show') if isinstance(item.get('show'), dict) else {}
        show_ids = show.get('ids') if isinstance(show, dict) else {}
        out.append({
            'media_ids': {
                'tmdb': _external_id(show_ids or ids, 'tmdb') or _external_id(ids, 'tmdb'),
                'imdb': _external_id(show_ids or ids, 'imdb') or _external_id(ids, 'imdb'),
                'tvdb': _external_id(show_ids or ids, 'tvdb') or _external_id(ids, 'tvdb'),
            },
            'title': (show.get('title') if isinstance(show, dict) else '') or node.get('title') or item.get('title') or '',
            'year': _year_text((show.get('year') if isinstance(show, dict) else None) or node.get('year') or node.get('release_date')),
            'release_date': str(node.get('release_date') or '')[:10],
            'season': node.get('season_number', node.get('season')),
            'episode': node.get('number', node.get('episode')),
            'progress': percent,
            'tracked_at': playback.get('tracked_at') or node.get('tracked_at') or item.get('tracked_at') or '',
        })
    return out


def playback_episode_items():
    dropped = set(str(i) for i in dropped_tmdb_ids())
    out = []
    for item in _playing_rows('episodes'):
        try:
            if float(item.get('progress') or 0) <= 1:
                continue
        except (TypeError, ValueError):
            continue
        season, episode = item.get('season'), item.get('episode')
        if season is None or episode is None:
            continue
        ids = item.get('media_ids') or {}
        tmdb = str(ids.get('tmdb') or '0')
        if tmdb != '0' and tmdb in dropped:
            continue
        out.append({
            'title': item.get('title') or 'Unknown',
            'season': '%01d' % int(season),
            'episode': '%01d' % int(episode),
            'tvshowtitle': item.get('title') or 'Unknown',
            'year': item.get('year') or '0',
            'premiered': '0',
            'status': '0',
            'studio': [],
            'genre': [],
            'duration': '0',
            'rating': '0',
            'votes': '0',
            'mpaa': '0',
            'plot': '0',
            'imdb': _normalize_imdb(ids.get('imdb')),
            'tvdb': str(ids.get('tvdb') or '0'),
            'tmdb': tmdb,
            'poster': '0',
            'thumb': '0',
            'progress': item.get('progress'),
            'paused_at': re.sub(r'[^0-9]+', '', str(item.get('tracked_at') or '')) or '0',
        })
    return out


def progress_seeds():
    """Continue Watching seeds. snum/enum are the episode before WeTrakr's next one."""
    if not getWeTrakrCredentialsInfo():
        return []
    dropped = set(str(i) for i in dropped_tmdb_ids())
    rows, seen = [], set()
    for status in ('watching', 'paused'):
        batch = _get_pages('/sync/tracking/%s/shows' % status, {'extended': 'episode_level_1'})
        for item in batch or []:
            if not isinstance(item, dict):
                continue
            episode = item.get('next_watching_episode')
            if not isinstance(episode, dict):
                continue
            tmdb = _parse_int(_external_id(item.get('ids') or {}, 'tmdb'))
            season = episode.get('season_number', episode.get('season'))
            number = episode.get('number', episode.get('episode'))
            try:
                season, number = int(season), int(number)
            except (TypeError, ValueError):
                continue
            if not tmdb or season < 0 or number < 1 or tmdb in seen:
                continue
            if str(tmdb) in dropped:
                continue
            seen.add(tmdb)
            rows.append({
                'tmdb': str(tmdb),
                'imdb': _normalize_imdb((item.get('ids') or {}).get('imdb')),
                'tvdb': str(_external_id(item.get('ids') or {}, 'tvdb') or '0'),
                'tvshowtitle': item.get('title') or '',
                'year': _year_text(item.get('year') or item.get('release_date')),
                'studio': [],
                'duration': '0',
                'mpaa': '0',
                'status': '0',
                'genre': [],
                'snum': str(season),
                'enum': str(number - 1),
                '_last_watched': '0',
            })
    return rows


def dropped_tmdb_ids():
    ids = []
    for kind in ('shows', 'movies'):
        for item in _status_entries('dropped', kind):
            tmdb = _parse_int((item.get('media_ids') or {}).get('tmdb'))
            if tmdb:
                ids.append(tmdb)
    return ids


def resume_point(media_type, imdb, season, episode, tmdb=None):
    """(offset_seconds, percent). Offset stays 0 when runtime is still unknown."""
    if not getWeTrakrCredentialsInfo():
        return 0, 0
    imdb_n = _normalize_imdb(imdb)
    tmdb_n = str(tmdb or '0')
    target = 'movies' if media_type == 'movie' else 'episodes'
    for item in _playing_rows(target):
        ids = item.get('media_ids') or {}
        if not _same_ids(imdb_n, tmdb_n, ids.get('imdb'), ids.get('tmdb')):
            continue
        if media_type != 'movie':
            try:
                if int(item.get('season')) != int(season) or int(item.get('episode')) != int(episode):
                    continue
            except (TypeError, ValueError):
                continue
        try:
            percent = float(item.get('progress') or 0)
        except (TypeError, ValueError):
            percent = 0
        if not (1 < percent < 92):
            return 0, 0
        return 0, percent
    return 0, 0


def _same_ids(imdb, tmdb, other_imdb, other_tmdb):
    imdb_n = _normalize_imdb(imdb)
    other_imdb = _normalize_imdb(other_imdb)
    if imdb_n != '0' and other_imdb != '0' and imdb_n == other_imdb:
        return True
    try:
        return str(int(tmdb)) == str(int(other_tmdb)) and int(tmdb) > 0
    except (TypeError, ValueError):
        return False


def clearPlayback(imdb=None, tmdb=None, season=None, episode=None, media='movie'):
    if not getWeTrakrCredentialsInfo():
        return
    media_type = 'movie' if media == 'movie' else 'episode'
    _scrobble_cancel(media_type, tmdb, season if media_type == 'episode' else None, episode if media_type == 'episode' else None)


def _account_username(token):
    headers = _api_headers(token)
    try:
        resp = requests.get('%s/account/settings' % BASE_URL, headers=headers, timeout=20)
    except Exception as e:
        _log('account read failed: %s' % e)
        return ''
    if resp.status_code in (401, 403):
        return None
    if not (200 <= resp.status_code < 300):
        return ''
    try:
        payload = resp.json() or {}
    except Exception:
        return ''
    info = payload.get('info') if isinstance(payload, dict) else None
    if not isinstance(info, dict):
        info = {}
    name = info.get('username') or info.get('display_name')
    return str(name) if name else ''


def authWeTrakr(reopen_settings=False):
    from resources.lib.modules import auth_utils
    progress = None
    try:
        if getWeTrakrCredentialsInfo():
            control.infoDialog('WeTrakr is already authorised. Use Revoke WeTrakr Account to sign out.', sound=True)
            return
        progress = auth_utils.auth_progress_dialog('WeTrakr Authorise', '')
        progress.update('Connecting to WeTrakr...')
        resp = requests.post(
            '%s/oauth/device/code' % BASE_URL,
            data=json.dumps({'client_id': _client_id()}),
            headers=_oauth_headers(), timeout=15)
        try:
            code_data = resp.json() if resp.status_code == 200 else {}
        except Exception:
            code_data = {}
        if not isinstance(code_data, dict) or not code_data.get('device_code') or not code_data.get('user_code'):
            control.infoDialog('WeTrakr Authorisation Failed.', sound=True)
            return
        user_code = str(code_data.get('user_code') or '')
        device_code = code_data.get('device_code')
        expires_in = int(code_data.get('expires_in') or 600)
        interval = max(int(code_data.get('interval') or 5), 1)
        auth_url = code_data.get('verification_uri_complete') or code_data.get('verification_url') or ''
        if not auth_url:
            base = code_data.get('verification_uri') or 'https://wetrakr.com/activate'
            auth_url = '%s?code=%s' % (base, user_code) if user_code else base
        progress.update('Preparing QR code...')
        qr_code = auth_utils.make_qrcode(auth_url) or ''
        short_url = auth_utils.make_tinyurl(auth_url)
        auth_utils.copy2clip(auth_url)
        site = code_data.get('verification_uri') or 'https://wetrakr.com/activate'
        insert = '[CR]OR visit [B]%s[/B]' % short_url if short_url else ''
        content = ('Enter [B]%s[/B] at [B]%s[/B][CR]OR scan the [B]QR Code[/B]%s[CR][CR]'
                   'Waiting for authorisation...' % (user_code, site, insert))
        progress.update(content, qr_path=qr_code)
        grant = None
        start = time.time()
        while not progress.iscanceled() and (time.time() - start) < expires_in:
            if auth_utils.auth_progress_wait(progress, interval):
                break
            try:
                poll = requests.post(
                    '%s/oauth/device/token' % BASE_URL,
                    data=json.dumps({'code': device_code, 'client_id': _client_id()}),
                    headers=_oauth_headers(), timeout=12)
                body = poll.json() or {}
            except Exception:
                body = {}
            if isinstance(body, dict) and body.get('access_token'):
                grant = body
                break
            error = str((body or {}).get('error') or '') if isinstance(body, dict) else ''
            if error == 'slow_down':
                interval += 5
            elif error in _POLL_STOP:
                break
        canceled = progress.iscanceled()
        auth_utils.close_auth_progress_dialog(progress)
        progress = None
        if canceled:
            control.infoDialog('WeTrakr Authorisation Canceled.', sound=True)
            return
        if not grant or not _save_grant(grant, require_refresh=True):
            control.infoDialog('WeTrakr Authorisation Failed.', sound=True)
            return
        username = _account_username(grant.get('access_token'))
        if username is None:
            _clear_grant()
            control.infoDialog('WeTrakr Authorisation Failed.', sound=True)
            return
        control.setSetting('wetrakr.user', username or 'WeTrakr User')
        from resources.lib.modules.meta_auth_alerts import clear_alert
        clear_alert('wetrakr')
        if control.yesnoDialog('Set WeTrakr as your Watched Indicators provider?', heading='Watched Status Provider', default_yes=True):
            from resources.lib.modules import simkl
            simkl.set_watched_provider('4', notify=True)
        try:
            syncWeTrakrWatched(silent=True, force_update=True)
        except Exception:
            pass
        control.infoDialog('WeTrakr Account Authorised.', sound=True)
        control.finish_auth_ui(reopen_settings=reopen_settings)
    except Exception:
        control.infoDialog('WeTrakr Authorisation Failed.', sound=True)
    finally:
        if progress is not None:
            auth_utils.close_auth_progress_dialog(progress)


def revokeWeTrakr(reopen_settings=False):
    if not getWeTrakrCredentialsInfo():
        control.infoDialog('No WeTrakr account is authorised.', sound=True)
        control.finish_auth_ui(reopen_settings=reopen_settings)
        return
    if not control.confirm_revoke('WeTrakr', reopen_settings):
        return
    try:
        token, refresh = _token(), _refresh_token()
        if _usable(token) and _usable(refresh):
            headers = _api_headers(token)
            try:
                requests.post(
                    '%s/oauth/logout' % BASE_URL,
                    data=json.dumps({'refresh_token': refresh}),
                    headers=headers, timeout=10)
            except Exception:
                pass
        from resources.lib.modules.meta_auth_alerts import clear_alert
        clear_alert('wetrakr')
        _clear_grant()
        from resources.lib.modules import simkl
        simkl.fallback_indicators_on_revoke('wetrakr')
        _bust_sync_cache()
        control.infoDialog('WeTrakr Account Revoked.', sound=True)
        control.finish_auth_ui(reopen_settings=reopen_settings)
    except Exception:
        control.infoDialog('WeTrakr Revoke Failed.', sound=True)


def wetrakr_scrobble_deferred():
    """True when script.wetrakr will send this plugin:// play itself."""
    addon_id = 'script.wetrakr'
    if not control.condVisibility('System.HasAddon(%s)' % addon_id):
        return False
    try:
        if not control.condVisibility('System.AddonIsEnabled(%s)' % addon_id):
            return False
    except Exception:
        pass
    try:
        inst = control.addon(addon_id)
    except Exception:
        return False
    try:
        if str(inst.getSetting('auth_invalid') or '').strip().lower() == 'true':
            return False
    except Exception:
        pass
    try:
        token = str(inst.getSetting('api_token') or '').strip()
    except Exception:
        token = ''
    if not token or token in ('0', 'empty_setting'):
        return False
    try:
        library_only = str(inst.getSetting('scrobble_library_only') or '').strip().lower()
    except Exception:
        library_only = ''
    if library_only in ('true', '1', 'yes', 'on'):
        return False
    saw = False
    for key in ('track_watched', 'track_playing'):
        try:
            val = str(inst.getSetting(key) or '').strip().lower()
        except Exception:
            continue
        if val in ('false', '0', 'no', 'off'):
            return False
        if val in ('true', '1', 'yes', 'on'):
            saw = True
    return saw


def _indicators_active():
    try:
        from resources.lib.modules import simkl
        return simkl.getIndicatorsProvider() == 'wetrakr' and getWeTrakrCredentialsInfo()
    except Exception:
        return False


def _scrobble_body(media_type, tmdb_id, percent, season=None, episode=None, title='', year=None):
    try:
        progress = float(percent or 0)
        tid = int(tmdb_id)
    except (TypeError, ValueError):
        return None
    year_int = _parse_int(year)
    if year_int in (None, 2050):
        year_int = None
    if media_type == 'movie':
        movie = {'ids': {'tmdb': tid}}
        if title:
            movie['title'] = title
        if year_int:
            movie['year'] = year_int
        body = {'movie': movie}
    else:
        show = {'ids': {'tmdb': tid}}
        if title:
            show['title'] = title
        if year_int:
            show['year'] = year_int
        body = {'show': show, 'episode': {'season': int(season or 0), 'number': int(episode or 0)}}
    body['progress'] = progress
    body['app_version'] = _version()
    return body


def _scrobble_cancel(media_type, tmdb_id, season=None, episode=None, title='', year=None):
    body = _scrobble_body(media_type, tmdb_id, 0, season, episode, title, year)
    if not body:
        return False
    body.pop('progress', None)
    body.pop('app_version', None)
    payload = _api('DELETE', '/scrobble/playing', data=body)
    if payload is None:
        return False
    if isinstance(payload, dict) and payload.get('_missing'):
        return True
    return _batch_ok(payload)


def wetrakr_scrobble(action, media_type, percent=0, tmdb=None, imdb=None, season=None, episode=None, title='', year=None):
    if not _indicators_active() or wetrakr_scrobble_deferred():
        return False
    if action == 'cancel':
        return _scrobble_cancel(media_type, tmdb, season, episode, title, year)
    path = {'start': '/scrobble/start', 'pause': '/scrobble/pause', 'stop': '/scrobble/stop'}.get(action)
    if not path:
        return False
    body = _scrobble_body(media_type, tmdb, percent, season, episode, title, year)
    if not body:
        return False
    ok = _batch_ok(_api('POST', path, params={'min_progress': _WATCH_POINT}, data=body))
    if ok and action == 'stop':
        try:
            percent_n = float(percent or 0)
        except (TypeError, ValueError):
            percent_n = 0
        if percent_n >= _WATCH_POINT:
            try:
                control.window.setProperty(_PLAY_RECORDED_PROP, 'true')
            except Exception:
                pass
    return ok


def play_recorded():
    try:
        return control.window.getProperty(_PLAY_RECORDED_PROP) == 'true'
    except Exception:
        return False


def clear_play_recorded():
    try:
        control.window.clearProperty(_PLAY_RECORDED_PROP)
    except Exception:
        pass


def _write_item(tmdb_id, imdb_id, status=None):
    ids = {}
    tmdb = _parse_int(tmdb_id)
    imdb = _normalize_imdb(imdb_id)
    if tmdb:
        ids['tmdb'] = tmdb
    if imdb != '0':
        ids['imdb'] = imdb
    if not ids:
        return None
    item = {'ids': ids}
    if status:
        item['status'] = status
    return item


def _write_status(status, media_type):
    if status == 'paused' and media_type != 'movie':
        return 'hold'
    return status


def _batch_ok(payload):
    if payload is None or payload is False:
        return False
    if not isinstance(payload, dict):
        return True
    if payload.get('_locked') or payload.get('_missing'):
        return False
    not_found = payload.get('notFound') or {}
    if isinstance(not_found, dict):
        for items in not_found.values():
            if items:
                return False
    return True


def _plays_removed_ok(payload):
    if not _batch_ok(payload) or not isinstance(payload, dict):
        return False
    if payload.get('removed'):
        return True
    errored = payload.get('errored') or {}
    if not isinstance(errored, dict):
        return False
    saw = False
    for items in errored.values():
        if not items:
            continue
        if not isinstance(items, list):
            return False
        for item in items:
            if not isinstance(item, dict) or item.get('error') != 'Nothing to remove':
                return False
            saw = True
    return saw


def _post_group(path, media_type, tmdb_id, imdb_id, status=None):
    if status:
        status = _write_status(status, media_type)
    item = _write_item(tmdb_id, imdb_id, status)
    if not item:
        return False
    key = 'movies' if media_type == 'movie' else 'shows'
    return _batch_ok(_api('POST', path, data={key: [item]}))


def _tracking_has(status, media_type, tmdb_id, imdb_id, title):
    target = 'movies' if media_type == 'movie' else 'shows'
    params = {'page': 1, 'limit': 50}
    if title:
        params['title_search'] = title
    api_status = _write_status(status, media_type)
    for entry in _rows(_api('GET', '/sync/tracking/%s/%s' % (api_status, target), params=params)):
        ids = entry.get('ids') if isinstance(entry, dict) else {}
        if _same_ids(imdb_id, tmdb_id, _external_id(ids or {}, 'imdb'), _external_id(ids or {}, 'tmdb')):
            return True
    return False


def _favorite_has(media_type, tmdb_id, imdb_id):
    target = 'movies' if media_type == 'movie' else 'shows'
    for page in range(1, 4):
        rows = _rows(_api('GET', '/sync/favorites/%s' % target, params={'page': page, 'limit': 100}))
        for entry in rows:
            ids = entry.get('ids') if isinstance(entry, dict) else {}
            if _same_ids(imdb_id, tmdb_id, _external_id(ids or {}, 'imdb'), _external_id(ids or {}, 'tmdb')):
                return True
        if len(rows) < 100:
            break
    return False


def _resolve_media(tmdb_id, media_type):
    tmdb = _parse_int(tmdb_id)
    if not tmdb:
        return None
    kind = 'movie' if media_type == 'movie' else 'show'
    data = _api('GET', '/media/external/tmdb/%s' % tmdb, params={'type': kind})
    if not isinstance(data, dict):
        return None
    return data.get('id') or None


def _lists_for_item(media_type, item_id):
    if not item_id:
        return []
    target = 'movie' if media_type == 'movie' else 'show'
    data = _api('GET', '/sync/lists/item/%s/%s' % (target, item_id))
    if not isinstance(data, list):
        return []
    rows = [i for i in data if isinstance(i, dict) and i.get('id') and not i.get('locked')]
    rows.sort(key=lambda item: (item.get('name') or '').lower())
    return rows


def _tracking_tree(status, media_type, tmdb_id, season=None, episode=None):
    try:
        tid = int(tmdb_id)
    except (TypeError, ValueError):
        return None
    if media_type == 'movie':
        return {'movies': [{'ids': {'tmdb': tid}, 'status': status}]}
    if media_type == 'episode' and season is not None and episode is not None:
        return {'shows': [{'ids': {'tmdb': tid}, 'seasons': [{'number': int(season), 'episodes': [{'number': int(episode), 'status': status}]}]}]}
    if media_type == 'season' and season is not None:
        return {'shows': [{'ids': {'tmdb': tid}, 'seasons': [{'number': int(season), 'status': status}]}]}
    return {'shows': [{'ids': {'tmdb': tid}, 'status': status}]}


def _mark(action, media_type, tmdb_id, season=None, episode=None):
    if not getWeTrakrCredentialsInfo():
        return False
    body = _tracking_tree('watched', media_type, tmdb_id, season, episode)
    if not body:
        return False
    if action == 'mark_as_watched':
        body['allow_rewatch'] = True
        ok = _batch_ok(_api('POST', '/sync/tracking', data=body))
    else:
        ok = _plays_removed_ok(_api('POST', '/sync/tracking/remove/all', data=body))
    if ok and action == 'mark_as_watched':
        try:
            control.window.setProperty(_PLAY_RECORDED_PROP, 'true')
        except Exception:
            pass
    return ok


def markMovieAsWatched(imdb, tmdb=None):
    return _mark('mark_as_watched', 'movie', tmdb)


def markMovieAsNotWatched(imdb, tmdb=None):
    return _mark('mark_as_unwatched', 'movie', tmdb)


def markEpisodeAsWatched(imdb, season, episode, tmdb=None):
    return _mark('mark_as_watched', 'episode', tmdb, season, episode)


def markEpisodeAsNotWatched(imdb, season, episode, tmdb=None):
    return _mark('mark_as_unwatched', 'episode', tmdb, season, episode)


def markSeasonAsWatched(imdb, season, tmdb=None):
    return _mark('mark_as_watched', 'season', tmdb, season)


def markSeasonAsNotWatched(imdb, season, tmdb=None):
    return _mark('mark_as_unwatched', 'season', tmdb, season)


def markTVShowAsWatched(imdb, tmdb=None):
    return _mark('mark_as_watched', 'tvshow', tmdb)


def markTVShowAsNotWatched(imdb, tmdb=None):
    return _mark('mark_as_unwatched', 'tvshow', tmdb)


def manager(name, imdb, tmdb, content):
    try:
        if not getWeTrakrCredentialsInfo():
            return control.infoDialog('Authorise WeTrakr first.', sound=True)
        media_type = 'movie' if content == 'movie' else 'tvshow'
        statuses = _MOVIE_STATUSES if media_type == 'movie' else _SHOW_STATUSES
        choices = []
        for status, label in statuses:
            if _tracking_has(status, media_type, tmdb, imdb, name):
                choices.append(('Remove from [B]%s[/B]' % label, 'remove_status', status))
            else:
                choices.append(('Add to [B]%s[/B]' % label, 'add_status', status))
        if _favorite_has(media_type, tmdb, imdb):
            choices.append(('Remove from [B]Favorites[/B]', 'remove_favorite', ''))
        else:
            choices.append(('Add to [B]Favorites[/B]', 'add_favorite', ''))
        item_id = _resolve_media(tmdb, media_type)
        for entry in _lists_for_item(media_type, item_id):
            label = entry.get('name') or 'List'
            if entry.get('included'):
                choices.append(('Remove from [B]%s[/B]' % label, 'remove_list', entry.get('id')))
            else:
                choices.append(('Add to [B]%s[/B]' % label, 'add_list', entry.get('id')))
        choices.append(('Open [B]WeTrakr Lists[/B]', 'open_lists', ''))
        select = control.selectDialog([c[0] for c in choices], 'WeTrakr Lists Manager')
        if select is None or select < 0:
            return
        _label, action, extra = choices[select]
        if action == 'open_lists':
            control.execute('Container.Update(plugin://plugin.video.gratisred/?action=my_wetrakr_menu)')
            return
        ok = False
        if action == 'add_favorite':
            ok = _post_group('/sync/favorites', media_type, tmdb, imdb)
        elif action == 'remove_favorite':
            ok = _post_group('/sync/favorites/remove', media_type, tmdb, imdb)
        elif action == 'add_status':
            ok = _post_group('/sync/tracking', media_type, tmdb, imdb, extra)
        elif action == 'remove_status':
            if extra == 'watched':
                item = _write_item(tmdb, imdb, 'watched')
                key = 'movies' if media_type == 'movie' else 'shows'
                ok = bool(item) and _plays_removed_ok(_api('POST', '/sync/tracking/remove/all', data={key: [item]}))
            else:
                ok = _post_group('/sync/tracking/remove', media_type, tmdb, imdb, extra)
        elif action == 'add_list':
            ok = _post_group('/sync/lists/%s/items' % extra, media_type, tmdb, imdb)
        elif action == 'remove_list':
            ok = _post_group('/sync/lists/%s/items/remove' % extra, media_type, tmdb, imdb)
        if not ok:
            return control.infoDialog('WeTrakr Lists Manager failed.', heading=str(name), sound=True, icon='ERROR')
        control.infoDialog('WeTrakr updated.', heading=str(name), sound=True, icon=control.infoLabel('ListItem.Icon'))
        try:
            control.refresh_list()
        except Exception:
            pass
    except Exception:
        control.infoDialog('WeTrakr Lists Manager failed.', heading=str(name), sound=True, icon='ERROR')


def _node_tmdb(node):
    if not isinstance(node, dict):
        return None
    found = _external_id(node.get('ids') or {}, 'tmdb') if isinstance(node.get('ids'), dict) else None
    return _parse_int(found) or _parse_int(node.get('tmdb') or node.get('tmdb_id'))


def _node_imdb(node):
    if not isinstance(node, dict):
        return '0'
    ids = node.get('ids') if isinstance(node.get('ids'), dict) else {}
    return _normalize_imdb(_external_id(ids, 'imdb') or node.get('imdb'))


def _history_rows(target):
    path = '/sync/tracking/watched/history/%s' % target
    rows, after = [], None
    for _page in range(1, 41):
        params = {'compact': 'true', 'limit': 5000}
        if after:
            params['after'] = after
        payload, headers = _request('GET', path, params=params, timeout=60)
        if payload is None:
            payload, headers = _request('GET', path, params=params, timeout=60)
        if payload is None or (isinstance(payload, dict) and (payload.get('_locked') or payload.get('_missing'))):
            _log('history page failed for %s' % target)
            return None
        batch = _rows(payload)
        if not batch:
            return rows
        rows.extend(batch)
        after = ''
        try:
            after = str((headers or {}).get('X-Pagination-Next') or '').strip()
        except Exception:
            after = ''
        if not after:
            return rows
    _log('history cursor cap hit for %s' % target)
    return None


def _fetch_show_tmdb(show_id):
    data = _api('GET', '/shows/%s' % show_id, user=False, timeout=30)
    if data is None:
        return None
    if isinstance(data, dict) and (data.get('_missing') or data.get('_locked')):
        return {'tmdb': 0}
    return {'tmdb': _node_tmdb(data) or 0}


def _show_tmdb(show_id, memo):
    key = str(show_id)
    if key in memo:
        return memo[key]
    data = cache.get(_fetch_show_tmdb, 720, key)
    if not isinstance(data, dict):
        memo[key] = False
        return False
    tmdb = _parse_int(data.get('tmdb'))
    memo[key] = tmdb
    return tmdb


def _movie_indicators():
    history = _history_rows('movies')
    if history is None:
        return None
    found = []
    seen = set()
    for item in history:
        if not isinstance(item, dict):
            continue
        movie = item.get('movie') if isinstance(item.get('movie'), dict) else item
        imdb = _node_imdb(movie)
        if imdb == '0' or imdb in seen:
            continue
        seen.add(imdb)
        found.append(imdb)
    return found


def _tv_indicators():
    history = _history_rows('episodes')
    if history is None:
        return None
    shows = {}
    memo = {}
    for item in history:
        if not isinstance(item, dict):
            continue
        episode = item.get('episode') if isinstance(item.get('episode'), dict) else item
        show = episode.get('show') if isinstance(episode.get('show'), dict) else {}
        show_tmdb = _node_tmdb(show)
        if not show_tmdb:
            for src in (item, episode):
                if isinstance(src, dict):
                    show_tmdb = _parse_int(_external_id(src.get('show_ids') or {}, 'tmdb'))
                    if show_tmdb:
                        break
        wetrakr_show = item.get('show_id') or episode.get('show_id')
        if not show_tmdb and wetrakr_show:
            show_tmdb = _show_tmdb(wetrakr_show, memo)
            if show_tmdb is False:
                return None
        season = episode.get('season_number', episode.get('season'))
        if season is None:
            season = item.get('season_number')
        number = episode.get('number', episode.get('episode'))
        if number is None:
            number = item.get('number')
        if not show_tmdb or season is None or number is None:
            continue
        try:
            pair = (int(season), int(number))
        except (TypeError, ValueError):
            continue
        key = str(int(show_tmdb))
        bucket = shows.setdefault(key, set())
        bucket.add(pair)
    rows = []
    for tmdb, pairs in shows.items():
        ordered = sorted(pairs)
        rows.append((tmdb, 0, ordered))
    return rows


_PRELOAD = {}


def syncMovies(user):
    try:
        if not getWeTrakrCredentialsInfo():
            return None
        rows = _PRELOAD['movies'] if 'movies' in _PRELOAD else _movie_indicators()
        if rows is None:
            return None
        return {'items': rows}
    except Exception:
        return None


def syncTVShows(user, _indicator_ver=None):
    try:
        if not getWeTrakrCredentialsInfo():
            return None
        rows = _PRELOAD['shows'] if 'shows' in _PRELOAD else _tv_indicators()
        if rows is None:
            return None
        return {'items': rows}
    except Exception:
        return None


def _unwrap(data):
    if isinstance(data, dict) and 'items' in data:
        return data.get('items') or []
    return data or []


def cachesyncMovies(timeout=0):
    return _unwrap(cache.get(syncMovies, timeout, _user()))


def cachesyncTVShows(timeout=0):
    return _unwrap(cache.get(syncTVShows, timeout, _user(), '1'))


def syncSeason(imdb, tmdb=None):
    try:
        rows = cachesyncTVShows(timeout=720) or []
        tmdb_s = str(tmdb or '0')
        watched = []
        for item in rows:
            try:
                if str(item[0]) == tmdb_s:
                    watched = item[2] or []
                    break
            except Exception:
                continue
        by_season = {}
        for pair in watched:
            try:
                season_n, episode_n = int(pair[0]), int(pair[1])
            except Exception:
                continue
            by_season.setdefault(season_n, set()).add(episode_n)
        fully = []
        for season_n, episodes in by_season.items():
            if not episodes or len(episodes) < 2:
                continue
            if min(episodes) == 1 and len(episodes) >= max(episodes):
                fully.append('%01d' % season_n)
        return fully
    except Exception:
        return []


def _activities():
    try:
        raw = control.setting('wetrakr.activities_json') or ''
        data = json.loads(raw) if raw else {}
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _store_activities(stamp):
    try:
        control.setSetting('wetrakr.activities_json', json.dumps(stamp or {}))
    except Exception:
        pass


def _activity_values(stamp, field):
    values = []
    if not isinstance(stamp, dict):
        return values
    for section in ('movies', 'shows', 'episodes'):
        block = stamp.get(section)
        if isinstance(block, dict):
            values.append(block.get(field))
    return values


def _activity_moved(previous, stamp, fields):
    if not isinstance(previous, dict) or not isinstance(stamp, dict):
        return True
    for field in fields:
        if _activity_values(previous, field) != _activity_values(stamp, field):
            return True
    return False


def _bust_sync_cache():
    try:
        cache.remove(syncMovies, _user())
    except Exception:
        pass
    try:
        cache.remove(syncTVShows, _user(), '1')
    except Exception:
        pass


def syncWeTrakrWatched(silent=True, force_update=False):
    if not getWeTrakrCredentialsInfo():
        return False
    if not _SYNC_LOCK.acquire(False if not force_update else True):
        return False
    try:
        stamp = _api('GET', '/sync/last_activities')
        previous = {} if force_update else _activities()
        fields = ('last_tracking_watched_at',)
        moved = force_update or not isinstance(stamp, dict) or _activity_moved(previous, stamp, fields)
        if not moved:
            return True
        movies = _movie_indicators()
        shows = _tv_indicators()
        if movies is None or shows is None:
            return False
        _PRELOAD['movies'] = movies
        _PRELOAD['shows'] = shows
        _bust_sync_cache()
        cachesyncMovies(timeout=0)
        cachesyncTVShows(timeout=0)
        _PRELOAD.pop('movies', None)
        _PRELOAD.pop('shows', None)
        if isinstance(stamp, dict):
            _store_activities(stamp)
        if not silent:
            control.infoDialog('WeTrakr Cache Refreshed.', sound=True)
        return True
    except Exception as e:
        _log('Watched sync failed: %s' % e)
        return False
    finally:
        _PRELOAD.pop('movies', None)
        _PRELOAD.pop('shows', None)
        try:
            _SYNC_LOCK.release()
        except Exception:
            pass


def refreshWeTrakrCache(silent=False):
    try:
        ok = syncWeTrakrWatched(silent=True, force_update=True)
        if not silent:
            control.infoDialog('WeTrakr Cache Refreshed.' if ok else 'WeTrakr Cache Refresh Failed.', sound=True)
    except Exception:
        if not silent:
            control.infoDialog('WeTrakr Cache Refresh Failed.', sound=True)
    try:
        control.refresh_list()
    except Exception:
        pass
