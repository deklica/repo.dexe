"""vidsrc.buzz / videm.buzz player: var Q -> play API -> /_stream HLS."""

import json
import re
from six.moves.urllib_parse import urlencode, urljoin, urlparse

from resources.lib.modules import client


HOSTS = ('vidsrc.buzz', 'videm.buzz', 'videm.xyz')


def _origin(url):
    parsed = urlparse(url)
    return '%s://%s' % (parsed.scheme, parsed.netloc) if parsed.scheme and parsed.netloc else ''


def _headers(referer):
    origin = _origin(referer) or 'https://vidsrc.buzz'
    return {
        'User-Agent': client.UserAgent,
        'Referer': referer if referer.endswith('/') or '?' in referer or '/embed' in referer else referer + '/',
        'Origin': origin,
        'Accept': 'application/json,text/html,*/*',
    }


def _config(html):
    match = re.search(r'\bvar\s+Q\s*=\s*', html or '')
    if not match:
        return None
    try:
        cfg = json.JSONDecoder().raw_decode(html[match.end():])[0]
    except Exception:
        return None
    return cfg if isinstance(cfg, dict) else None


def _play_api(page):
    host = (urlparse(page).hostname or '').lower()
    origin = _origin(page)
    if host == 'vidsrc.buzz':
        return origin + '/pl/api.php'
    return origin + '/api.php'


def resolve_page(html, page):
    """Return (stream urls, headers) from a buzz player document."""
    try:
        parsed = urlparse(page)
        host = (parsed.hostname or '').lower()
        if host not in HOSTS:
            return [], None
        cfg = _config(html)
        token = cfg.get('t') if isinstance(cfg, dict) else None
        ssr = cfg.get('ssr') if isinstance(cfg, dict) else None
        servers = ssr.get('servers') if isinstance(ssr, dict) else None
        if not isinstance(token, str) or not isinstance(servers, list):
            return [], None
        api = _play_api(page)
        headers = _headers(page)
        headers['Accept'] = 'application/json'
        urls = []
        for server in servers[:8]:
            if not isinstance(server, dict) or not isinstance(server.get('ref'), str):
                continue
            raw = client.request(api + '?' + urlencode({
                'a': 'play', 'ref': server['ref'], 't': token,
            }), headers=headers, timeout='12') or ''
            try:
                data = json.loads(raw)
            except Exception:
                continue
            if not isinstance(data, dict):
                continue
            media = urljoin(page, data.get('url') or '')
            target = urlparse(media)
            if (target.scheme != 'https' or (target.hostname or '').lower() != host
                    or target.path != '/_stream' or media in urls):
                continue
            urls.append(media)
            if len(urls) >= 4:
                break
        if not urls:
            return [], None
        play_headers = {
            'User-Agent': client.UserAgent,
            'Referer': page,
            'Origin': _origin(page),
        }
        return urls, play_headers
    except Exception:
        return [], None


def resolve_url(url, referer=None):
    """Fetch a buzz embed and resolve its /_stream playlists."""
    try:
        parsed = urlparse(url)
        if (parsed.scheme != 'https' or (parsed.hostname or '').lower() not in HOSTS):
            return [], None
        html = client.request(url, headers=_headers(referer or url), timeout='12') or ''
        return resolve_page(html, url)
    except Exception:
        return [], None
