"""2Embed movie/TV player: embed -> vidsrc.buzz / videm.buzz -> /_stream HLS."""

import re
from six.moves.urllib_parse import urljoin, urlparse

from resources.lib.modules import buzz_player
from resources.lib.modules import client

try:
    from html import unescape as html_unescape
except ImportError:
    from six.moves.html_parser import HTMLParser
    html_unescape = HTMLParser().unescape


BASE = 'https://www.2embed.cc'
REFERER = 'https://watch.cinewave.qzz.io/'
_TV_PATH = re.compile(r'^/embedtv/(\d+)&s=(\d+)&e=([1-9]\d*)$')
_MOVIE_PATH = re.compile(r'^/embed/(?:movie/)?(\d+)$')


def _page(url, referer):
    return client.request(url, headers={'User-Agent': client.UserAgent, 'Referer': referer}, timeout='12') or ''


def _frames(html):
    found = []
    for match in re.finditer(r'<iframe[^>]+>', html or '', re.I):
        tag = match.group(0)
        src = re.search(r'(?:data-src|src)=["\']([^"\']+)["\']', tag, re.I)
        if src:
            found.append(html_unescape(src.group(1)))
    return found


def normalize(url):
    if not url:
        return ''
    parsed = urlparse(url)
    host = (parsed.hostname or '').lower().replace('www.', '')
    if host not in ('2embed.cc', '2embed.skin', '2embed.me'):
        return url
    path = parsed.path.rstrip('/')
    query = parsed.query or ''
    if 'id=' in query:
        ident = re.search(r'(?:^|&)id=([^&]+)', query)
        if ident:
            value = ident.group(1)
            if value.startswith('tt') or '/tv' in path:
                return url
            return '%s://%s/embed/movie/%s' % (parsed.scheme or 'https', parsed.hostname, value)
    movie = _MOVIE_PATH.match(path)
    if movie:
        return '%s://%s/embed/movie/%s' % (parsed.scheme or 'https', parsed.hostname or 'www.2embed.cc', movie.group(1))
    return url


def embed_url(tmdb, media='movie', season=None, episode=None):
    ident = str(tmdb or '').strip()
    if not ident.isdigit() or ident == '0':
        return ''
    if media == 'tv':
        if not season or not episode:
            return ''
        return '%s/embedtv/%s&s=%s&e=%s' % (BASE, ident, season, episode)
    return BASE + '/embed/movie/' + ident


def _buzz_url(html, page):
    for raw in _frames(html):
        target = urljoin(page, html_unescape(raw))
        host = (urlparse(target).hostname or '').lower()
        if host in buzz_player.HOSTS:
            return target
    for raw in re.findall(r"""go\(\s*['"](https://(?:vidsrc|videm)\.buzz[^'"]+)['"]""", html or '', re.I):
        return html_unescape(raw)
    return ''


def _is_embed(url):
    parsed = urlparse(url)
    host = (parsed.hostname or '').lower()
    if not host.endswith('2embed.cc') and not host.endswith('2embed.skin'):
        return False
    path = parsed.path.rstrip('/')
    return bool(_MOVIE_PATH.match(path) or _TV_PATH.match(path))


def resolve_embed(url):
    """Return (stream urls, headers) for a 2embed.cc movie or TV embed."""
    try:
        parsed = urlparse(url or '')
        host = (parsed.hostname or '').lower()
        if host in buzz_player.HOSTS:
            return buzz_player.resolve_url(url)
        url = normalize(url)
        if not _is_embed(url):
            return [], None
        page = _page(url, REFERER)
        buzz = _buzz_url(page, url)
        if not buzz:
            return [], None
        return buzz_player.resolve_url(buzz, referer=url)
    except Exception:
        return [], None
