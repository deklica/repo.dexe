# version: 1.2.29 (doit correspond à addon.xml)
# -*- coding: utf-8 -*- 
'''
***********************************************************
*
* @file addon.py
* 
* Created on 2024-03-08.
*
* @license GNU General Public License, version 3 (GPL-3.0)
*
***********************************************************
'''

import re
import os
import sys
import json
import html
import gzip
import zlib
import base64
import hashlib
import hmac as _hmac
import socket
import struct
import random
import requests
import threading
import tempfile
import concurrent.futures
from http.server import HTTPServer, ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlencode, unquote, parse_qsl, quote_plus, urlparse, urljoin, urlsplit
from datetime import datetime, timezone, timedelta
import time
import calendar
import xbmc
import xbmcvfs
import xbmcgui
import xbmcplugin
import xbmcaddon

_KODI_TEMP = xbmcvfs.translatePath('special://temp/')
os.makedirs(_KODI_TEMP, exist_ok=True)

addon_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.dltv')

UA = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36'
FANART = addon.getAddonInfo('fanart')
ICON = addon.getAddonInfo('icon')

_seed_setting = addon.getSetting('seed_baseurl').strip()
SEED_BASEURL = _seed_setting if _seed_setting else ''

_CUSTOM_DNS = addon.getSetting('custom_dns').strip()
EXTRA_M3U8_URL = 'http://drewlive2423.duckdns.org:8081/DrewLive/MergedPlaylist.m3u8'


_s_chevy_proxy = addon.getSetting('chevy_proxy_url').strip()
CHEVY_PROXY = _s_chevy_proxy if _s_chevy_proxy else 'https://chevy.soyspace.cyou'
_s_chevy_lookup = addon.getSetting('chevy_lookup_url').strip()
CHEVY_LOOKUP = _s_chevy_lookup if _s_chevy_lookup else 'https://chevy.vovlacosa.sbs'
# Hardcoded fallbacks — never overwritten by Discovery (used when discovered servers are down)
_CHEVY_PROXY_BUILTIN = 'https://chevy.soyspace.cyou'
_CHEVY_LOOKUP_BUILTIN = 'https://chevy.vovlacosa.sbs'
_s_ksohls = addon.getSetting('ksohls_base_url').strip()
_KSOHLS_BASE = _s_ksohls if _s_ksohls else 'https://www.ksohls.ru'
PLAYER_REFERER = _KSOHLS_BASE + '/'
_KSOHLS_FALLBACK_BASES = ['https://www.ksohls.ru', 'https://enviromentalspace.cyou']

M3U8_PROXY_PORT = 19876
_actual_proxy_port = None  # resolved at runtime by _ensure_m3u8_proxy
try:
    _PROXY_ADDON_MTIME = str(int(os.path.getmtime(__file__)))
except Exception:
    _PROXY_ADDON_MTIME = '0'

IPTV_ORG_API = 'https://iptv-org.github.io/api/channels.json'
IPTV_ORG_INDEX_CACHE = os.path.join(_KODI_TEMP, 'dltv_iptv_org_idx2.json')
IPTV_ORG_TVG_CACHE = os.path.join(_KODI_TEMP, 'dltv_iptv_org_tvg.json')
IPTV_ORG_TTL = 7 * 24 * 3600  # refresh index every 7 days
_XMLTV_TTL = 4 * 3600      # re-download every 4 hours
_XMLTV_PROG_CACHE = os.path.join(_KODI_TEMP, 'dltv_xmltv_programs.json')
_XMLTV_PROG_TTL = 1800     # re-parse every 30 minutes
_XMLTV_SOURCES = {
    'epg_fr': ('French',      'https://epgshare01.online/epgshare01/epg_ripper_FR1.xml.gz', 'dltv_xmltv_FR.xml.gz'),
    'epg_uk': ('English',     'https://epgshare01.online/epgshare01/epg_ripper_UK1.xml.gz', 'dltv_xmltv_UK.xml.gz'),
    'epg_ar': ('Arabic',      'https://epgshare01.online/epgshare01/epg_ripper_AR1.xml.gz', 'dltv_xmltv_AR.xml.gz'),
    'epg_es': ('Spanish',     'https://epgshare01.online/epgshare01/epg_ripper_ES1.xml.gz', 'dltv_xmltv_ES.xml.gz'),
    'epg_it': ('Italian',     'https://epgshare01.online/epgshare01/epg_ripper_IT1.xml.gz', 'dltv_xmltv_IT.xml.gz'),
    'epg_de': ('German',      'https://epgshare01.online/epgshare01/epg_ripper_DE1.xml.gz', 'dltv_xmltv_DE.xml.gz'),
    'epg_pt': ('Portuguese',  'https://epgshare01.online/epgshare01/epg_ripper_PT1.xml.gz', 'dltv_xmltv_PT.xml.gz'),
    'epg_nl': ('Dutch',       'https://epgshare01.online/epgshare01/epg_ripper_NL1.xml.gz', 'dltv_xmltv_NL.xml.gz'),
    'epg_tr': ('Turkish',     'https://epgshare01.online/epgshare01/epg_ripper_TR1.xml.gz', 'dltv_xmltv_TR.xml.gz'),
    'epg_pl': ('Polish',      'https://epgshare01.online/epgshare01/epg_ripper_PL1.xml.gz', 'dltv_xmltv_PL.xml.gz'),
    'epg_ro': ('Romanian',    'https://epgshare01.online/epgshare01/epg_ripper_RO1.xml.gz', 'dltv_xmltv_RO.xml.gz'),
    'epg_ru': ('Russian',     'https://epgshare01.online/epgshare01/epg_ripper_RU1.xml.gz', 'dltv_xmltv_RU.xml.gz'),
}

_CDN_CACHE_FILE = os.path.join(_KODI_TEMP, 'dltv_cdn_map.json')
_DISCOVERY_CACHE_FILE = os.path.join(_KODI_TEMP, 'dltv_discovery.json')
_DISCOVERY_CACHE_TTL = 12 * 3600  # re-discover every 12h
_CDN_CACHE_TTL = 3600  # 1 hour
_CDN_STATUS_CACHE_FILE = os.path.join(_KODI_TEMP, 'dltv_cdn_status.json')
_CDN_STATUS_TTL = 300  # 5 minutes
_FAILED_CHANNELS_FILE = os.path.join(_KODI_TEMP, 'dltv_failed_channels.json')
_FAILED_CHANNEL_TTL = 600  # 10 minutes — channels with no valid content
# Upstreams (CHEVY, ksohls, stale CDN nodes) that stopped answering. Persisted
# because they stay dead across restarts: probing one costs 3-6s of timeout per
# attempt, and a channel falling through them pays that price on every play.
_UPSTREAM_DEAD_FILE = os.path.join(_KODI_TEMP, 'dltv_upstream_dead.json')
_UPSTREAM_DEAD_TTL = 21600  # 6 hours
# channel id -> wideiptv slug. dlive.sx is the only place that knows which slug
# belongs to which channel, and it throttles: five channel changes in a minute is
# enough to make it refuse every request, which kills every backend at once because
# they all resolve through it. The slug never changes, so one lookup covers a whole
# zapping session — the token is refreshed separately via wideiptv.top.
_WIDE_SLUG_FILE = os.path.join(_KODI_TEMP, 'dltv_wideiptv_slugs.json')
_WIDE_SLUG_TTL = 86400  # 24 hours
# Slugs the wideiptv CDN answers for with 404 "not found": the site lists them but the
# CDN holds no content. Measured 6 of 24 (RMCSPORT1/2FR, CANALPL*AF, CNPLSP3AF,
# beINMAX8FR) — an operator-side feed gap that clears when the channel goes live again,
# so the mark is short-lived and must not survive the day like a slug does.
_WIDE_SLUG_ABSENT_FILE = os.path.join(_KODI_TEMP, 'dltv_wideiptv_absent.json')
_WIDE_SLUG_ABSENT_TTL = 600  # 10 minutes
# CDN domains that serve image placeholders (not video) when a channel has no source stream.
# tempfileb.aiquickdraw.com and liftstory.com are intentionally NOT here — they serve real video.
# CHEVY stores real MPEG-TS segments on image CDNs (S3, R2, fooocus, visualgpt…) with fake .jpg/.png
# extensions — all confirmed as real video by AES decryption. URL-based detection is not reliable.
_PREMIUM_KEY_RX = re.compile(r'^premium(\d+)$')
_M3U8_ENDLIST = b'#EXTM3U\n#EXT-X-VERSION:3\n#EXT-X-TARGETDURATION:4\n#EXT-X-ENDLIST\n'
# L1: _MEDIA_SEQ_RX was a less-specific duplicate of _SEQ_RX (both matched the same tag).
# Removed _MEDIA_SEQ_RX; its single usage at _handle_m3u8 now uses _SEQ_RX instead.
_SEQ_RX = re.compile(r'#EXT-X-MEDIA-SEQUENCE:(\d+)')
_FAV_PROBE_TS_FILE = os.path.join(_KODI_TEMP, 'dltv_fav_probe_ts')
_PAGE_CACHE_FILE = os.path.join(_KODI_TEMP, 'dltv_page_cache.json')


def _aes128_cbc_decrypt(data, key, iv):
    """AES-128-CBC decrypt. Tries pycryptodome, cryptography, Windows CryptoAPI.
    CHEVY segments may not be padded to a 16-byte boundary — truncate to the
    largest multiple of 16 so block cipher backends don't reject the data."""
    rem = len(data) % 16
    if rem:
        data = data[:-rem]
    # Backend 1: pycryptodome
    try:
        from Crypto.Cipher import AES
        c = AES.new(key, AES.MODE_CBC, iv)
        dec = c.decrypt(data)
        log('[StreamProxy] AES: pycryptodome')
        pad = dec[-1] if dec else 0
        if 0 < pad <= 16 and dec[-pad:] == bytes([pad] * pad):
            return dec[:-pad]
        return dec
    except ImportError:
        pass
    except Exception as e:
        log(f'[StreamProxy] AES pycryptodome error: {e}')
    # Backend 2: cryptography package
    try:
        from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
        from cryptography.hazmat.backends import default_backend
        c = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
        d = c.decryptor()
        dec = d.update(data) + d.finalize()
        log('[StreamProxy] AES: cryptography')
        pad = dec[-1] if dec else 0
        if 0 < pad <= 16 and dec[-pad:] == bytes([pad] * pad):
            return dec[:-pad]
        return dec
    except ImportError:
        pass
    except Exception as e:
        log(f'[StreamProxy] AES cryptography error: {e}')
    # Backend 3: Windows CryptoAPI — explicit argtypes to avoid marshaling errors
    try:
        import ctypes
        _adv = ctypes.WinDLL('advapi32', use_last_error=True)
        _H = ctypes.c_size_t  # HCRYPTPROV / HCRYPTKEY = ULONG_PTR (pointer-sized)
        _adv.CryptAcquireContextW.restype = ctypes.c_int
        _adv.CryptAcquireContextW.argtypes = [
            ctypes.POINTER(_H), ctypes.c_wchar_p, ctypes.c_wchar_p,
            ctypes.c_uint, ctypes.c_uint]
        _adv.CryptImportKey.restype = ctypes.c_int
        _adv.CryptImportKey.argtypes = [
            _H, ctypes.c_char_p, ctypes.c_uint, _H, ctypes.c_uint, ctypes.POINTER(_H)]
        _adv.CryptSetKeyParam.restype = ctypes.c_int
        _adv.CryptSetKeyParam.argtypes = [_H, ctypes.c_uint, ctypes.c_char_p, ctypes.c_uint]
        _adv.CryptDecrypt.restype = ctypes.c_int
        _adv.CryptDecrypt.argtypes = [
            _H, _H, ctypes.c_int, ctypes.c_uint,
            ctypes.c_char_p, ctypes.POINTER(ctypes.c_uint)]
        _adv.CryptDestroyKey.restype = ctypes.c_int
        _adv.CryptDestroyKey.argtypes = [_H]
        _adv.CryptReleaseContext.restype = ctypes.c_int
        _adv.CryptReleaseContext.argtypes = [_H, ctypes.c_uint]
        _prov = _H(0)
        _key_h = _H(0)
        # PROV_RSA_AES=24, CRYPT_VERIFYCONTEXT=0xF0000000
        if not _adv.CryptAcquireContextW(ctypes.byref(_prov), None, None, 24, 0xF0000000):
            log(f'[StreamProxy] AES WinCryptoAPI AcquireCtx err={ctypes.get_last_error()}')
        else:
            # PLAINTEXTKEYBLOB: BLOBHEADER(8B) + DWORD cbKeySize(4B) + key(16B) = 28B
            # BLOBHEADER: bType=8, bVersion=2, reserved=0, aiKeyAlg=0x660E (CALG_AES_128)
            # 0x660E = ALG_CLASS_DATA_ENCRYPT|ALG_TYPE_BLOCK|ALG_SID_AES_128 (NOT 0x6610=AES-256)
            _blob = struct.pack('<BBHII', 8, 2, 0, 0x660E, 16) + bytes(key)
            if not _adv.CryptImportKey(_prov.value, _blob, len(_blob), 0, 0, ctypes.byref(_key_h)):
                log(f'[StreamProxy] AES WinCryptoAPI ImportKey err={ctypes.get_last_error()}')
                _adv.CryptReleaseContext(_prov.value, 0)
            else:
                _adv.CryptSetKeyParam(_key_h.value, 1, bytes(iv), 0)  # KP_IV=1
                _buf = ctypes.create_string_buffer(bytes(data), len(data))
                _buf_len = ctypes.c_uint(len(data))
                # fFinal=0: skip PKCS#7 validation (HLS segments may use non-standard padding)
                # strip padding manually, same as pycryptodome/cryptography backends
                if _adv.CryptDecrypt(_key_h.value, 0, 0, 0, _buf, ctypes.byref(_buf_len)):
                    dec = bytes(_buf.raw[:_buf_len.value])
                    _adv.CryptDestroyKey(_key_h.value)
                    _adv.CryptReleaseContext(_prov.value, 0)
                    pad = dec[-1] if dec else 0
                    if 0 < pad <= 16 and dec[-pad:] == bytes([pad] * pad):
                        result = dec[:-pad]
                    else:
                        result = dec
                    log('[StreamProxy] AES: WinCryptoAPI')
                    return result
                log(f'[StreamProxy] AES WinCryptoAPI CryptDecrypt err={ctypes.get_last_error()}')
                _adv.CryptDestroyKey(_key_h.value)
                _adv.CryptReleaseContext(_prov.value, 0)
    except Exception as e:
        log(f'[StreamProxy] AES WinCryptoAPI error: {e}')
    log('[StreamProxy] AES: no backend — streaming encrypted data (will not play)')
    return data


def _fetch_stream_key(key_id, channel_key, state, key_cache, force_refresh=False, key_ns=None):
    """Fetch AES-128 decryption key from CDN, caching result per session.

    force_refresh=True: bypass CHEVY's server-side cache (used on stale key retry).
    Adds Cache-Control: no-cache headers + ?_nc=<ts> URL cache-buster so CHEVY
    re-fetches from the upstream CDN key server instead of serving cached bytes.

    key_ns: namespace extracted from the key URI in the m3u8 (e.g. 'premium773').
    When provided, used directly instead of server_key from m3u8 URL path.
    CHEVY key URIs use channel_key as namespace, not server_key.

    Key server is derived from state['m3u8_url'] (same host as CHEVY proxy) so that
    when CHEVY_PROXY != CHEVY_LOOKUP (different server deployments), the correct
    server is always used — avoiding AES key mismatch.
    """
    if key_id in key_cache and not force_refresh:
        return key_cache[key_id]
    try:
        # Derive key host from m3u8 URL
        # m3u8 URL pattern: https://{host}/proxy/{server_key}/{channel_key}/mono.css
        # Key URL pattern:  https://{host}/key/{key_ns}/{key_id}
        # key_ns comes from the key URI in the m3u8 (most authoritative).
        # Fallback: server_key from m3u8 URL path.
        m3u8_url = state.get('m3u8_url', '')
        _key_host_m = re.match(r'(https?://[^/]+)', m3u8_url)
        key_host = _key_host_m.group(1) if _key_host_m else CHEVY_LOOKUP
        if key_ns:
            _srv_key = key_ns
        else:
            _srv_key_m = re.search(r'/proxy/([^/]+)/', m3u8_url)
            _srv_key = _srv_key_m.group(1) if _srv_key_m else channel_key
        url = f'{key_host}/key/{_srv_key}/{key_id}'
        ts = int(time.time())
        channel_salt = state.get('channel_salt') or ''
        fp = _compute_fingerprint()
        # Use viewembed page URL as Referer when available (CHEVY key endpoint checks it)
        _key_referer = state.get('player_referer') or m3u8_url or PLAYER_REFERER
        hdrs = {
            'User-Agent': _AUTH_UA,
            'Referer': _key_referer,
        }
        if channel_salt and channel_salt != 'noauth':
            nonce = _compute_pow_nonce(channel_key, channel_salt, key_id, ts)
            auth_sig = _compute_auth_sig(channel_key, channel_salt, key_id, ts, fp)
            hdrs['Authorization'] = f'Bearer {state["auth_token"]}'
            hdrs['X-Key-Timestamp'] = str(ts)
            hdrs['X-Key-Nonce'] = str(nonce)
            hdrs['X-Key-Path'] = auth_sig
            hdrs['X-Fingerprint'] = fp
        if force_refresh:
            # Bust CHEVY's URL-based cache and signal it to re-fetch from upstream
            url += f'?_nc={ts}'
            hdrs['Cache-Control'] = 'no-cache'
            hdrs['Pragma'] = 'no-cache'
        r = _get_session().get(url, headers=hdrs, timeout=3)
        key = r.content
        log(f'[StreamProxy] key {key_id}: {len(key)}B url={url} ref={_key_referer[:50]} force={force_refresh} hex={key.hex()}')
        key_cache[key_id] = key
        return key
    except Exception as e:
        log(f'[StreamProxy] key {key_id} fetch error: {e}')
        return None


def _is_placeholder(url):
    """Return True for CDN domains/paths confirmed to serve AI-generated placeholder images,
    never real HLS video. CHEVY uses these when a channel has no real stream.
    Other image-sounding CDNs (S3, R2, fooocus, visualgpt) are NOT listed: CHEVY stores
    real AES-encrypted TS on those (confirmed by decryption)."""
    _PH_DOMAINS = ('cdn.gptimage15.com', 'x-design-release.stariicloud.com')
    _PH_PATHS = ('/image-to-video/', '/ai_agent/')
    return any(d in url for d in _PH_DOMAINS) or any(p in url for p in _PH_PATHS)


def _apply_m3u8_filter(content):
    """Filter placeholder image segments from an M3U8 playlist.
    Returns (filtered_content, remaining_count, total_count) or (None, 0, total) if all filtered."""
    raw_lines = content.splitlines(keepends=True)
    filtered = []
    prev_removed = found_first = False
    removed_before_first = total = 0
    orig_seq_m = _SEQ_RX.search(content)
    orig_seq = int(orig_seq_m.group(1)) if orig_seq_m else 0
    for line in raw_lines:
        stripped = line.strip()
        if stripped and not stripped.startswith('#'):
            total += 1
            if _is_placeholder(stripped):
                if filtered and filtered[-1].strip().startswith('#EXTINF'):
                    filtered.pop()
                if not found_first:
                    removed_before_first += 1
                prev_removed = True
                continue
            else:
                if prev_removed and found_first:
                    filtered.append('#EXT-X-DISCONTINUITY\n')
                found_first = True
                prev_removed = False
        filtered.append(line)
    remaining = sum(1 for l in filtered if l.strip() and not l.strip().startswith('#'))
    if not remaining:
        return None, 0, total
    result = ''.join(filtered)
    if removed_before_first > 0 and orig_seq_m:
        result = result.replace(
            orig_seq_m.group(0),
            f'#EXT-X-MEDIA-SEQUENCE:{orig_seq + removed_before_first}',
            1
        )
    return result, remaining, total


_FAV_PROBE_COOLDOWN = 120  # seconds between background probes (persisted across processes)
_FAV_REFRESH_TS_FILE = os.path.join(_KODI_TEMP, 'dltv_fav_refresh_ts')
_FAV_REFRESH_DEBOUNCE = 10  # min seconds between Container.Refresh calls from mark_failed

# ISO 3166-1 alpha-2 country → ISO 639-3 primary language
COUNTRY_LANG = {
    'AE': 'ara', 'AF': 'pus', 'AL': 'sqi', 'AM': 'hye', 'AO': 'por',
    'AR': 'spa', 'AT': 'deu', 'AU': 'eng', 'AZ': 'aze', 'BA': 'bos',
    'BD': 'ben', 'BE': 'fra', 'BG': 'bul', 'BH': 'ara', 'BO': 'spa',
    'BR': 'por', 'CA': 'eng', 'CH': 'deu', 'CL': 'spa', 'CM': 'fra',
    'CN': 'zho', 'CO': 'spa', 'CR': 'spa', 'CU': 'spa', 'CY': 'ell',
    'CZ': 'ces', 'DE': 'deu', 'DK': 'dan', 'DO': 'spa', 'DZ': 'ara',
    'EC': 'spa', 'EE': 'est', 'EG': 'ara', 'ES': 'spa', 'FI': 'fin',
    'FR': 'fra', 'GB': 'eng', 'GE': 'kat', 'GH': 'eng', 'GR': 'ell',
    'GT': 'spa', 'HK': 'zho', 'HN': 'spa', 'HR': 'hrv', 'HU': 'hun',
    'ID': 'ind', 'IE': 'eng', 'IL': 'heb', 'IN': 'hin', 'IQ': 'ara',
    'IR': 'fas', 'IS': 'isl', 'IT': 'ita', 'JM': 'eng', 'JO': 'ara',
    'JP': 'jpn', 'KE': 'eng', 'KR': 'kor', 'KW': 'ara', 'KZ': 'kaz',
    'LB': 'ara', 'LT': 'lit', 'LU': 'fra', 'LV': 'lav', 'LY': 'ara',
    'MA': 'ara', 'MD': 'ron', 'ME': 'srp', 'MK': 'mkd', 'MN': 'mon',
    'MO': 'zho', 'MR': 'ara', 'MX': 'spa', 'MY': 'msa', 'MZ': 'por',
    'NG': 'eng', 'NI': 'spa', 'NL': 'nld', 'NO': 'nor', 'NP': 'nep',
    'NZ': 'eng', 'OM': 'ara', 'PA': 'spa', 'PE': 'spa', 'PH': 'fil',
    'PK': 'urd', 'PL': 'pol', 'PS': 'ara', 'PT': 'por', 'PY': 'spa',
    'QA': 'ara', 'RO': 'ron', 'RS': 'srp', 'RU': 'rus', 'SA': 'ara',
    'SD': 'ara', 'SE': 'swe', 'SG': 'eng', 'SI': 'slv', 'SK': 'slk',
    'SV': 'spa', 'SY': 'ara', 'TH': 'tha', 'TN': 'ara', 'TR': 'tur',
    'TT': 'eng', 'TW': 'zho', 'UA': 'ukr', 'US': 'eng', 'UY': 'spa',
    'UZ': 'uzb', 'VE': 'spa', 'VN': 'vie', 'YE': 'ara', 'ZA': 'eng',
}

LANG_NAMES = {
    'eng': 'English', 'fra': 'French', 'deu': 'German', 'spa': 'Spanish',
    'ita': 'Italian', 'por': 'Portuguese', 'ara': 'Arabic', 'nld': 'Dutch',
    'tur': 'Turkish', 'rus': 'Russian', 'pol': 'Polish', 'ron': 'Romanian',
    'swe': 'Swedish', 'nor': 'Norwegian', 'dan': 'Danish', 'fin': 'Finnish',
    'ces': 'Czech', 'hrv': 'Croatian', 'srp': 'Serbian', 'bul': 'Bulgarian',
    'hun': 'Hungarian', 'ell': 'Greek', 'heb': 'Hebrew', 'fas': 'Persian',
    'urd': 'Urdu', 'msa': 'Malay', 'hin': 'Hindi', 'ben': 'Bengali',
    'tam': 'Tamil', 'ind': 'Indonesian', 'zho': 'Chinese', 'tha': 'Thai',
    'vie': 'Vietnamese', 'jpn': 'Japanese', 'kor': 'Korean',
}

# EPlayer auth — UA/screen/tz/lang values used for fingerprint computation
_AUTH_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36'

_SEG_HEADERS = {
    'User-Agent': _AUTH_UA,
    'Accept': '*/*',
    'Accept-Language': 'en-US,en;q=0.9',
    'Accept-Encoding': 'gzip, deflate, br',
    'Origin': _KSOHLS_BASE,
    'Referer': PLAYER_REFERER,
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'cross-site',
}

# Thread-safe state store: channel_key → {auth_token, channel_salt, m3u8_url, fetched_at}
_proxy_lock = threading.Lock()
_channel_creds = {}
# Stall tracker: channel_key → {seq: last_seq, count: consecutive_same_seq}
_m3u8_stall = {}
_m3u8_timeouts = {}  # channel_key → consecutive timeout count
_last_sent_seq = {}  # channel_key → last seq number sent to player (for HLS polling throttle)
_sent_seg_urls = {}  # channel_key → set of CDN segment URLs already sent (dedup sliding window)
_last_media_seq_out = {}  # channel_key → last MEDIA-SEQUENCE sent to player (enforce monotonic)
_seg_url_to_channel = {}  # CDN segment URL → channel_key, for download-time dedup tracking
_stall_lock = threading.Lock()
_seg_semaphore = threading.Semaphore(2)  # max 2 concurrent segment downloads
_proxy_abort = threading.Event()  # set on Kodi shutdown to unblock sleeping handler threads
_probe_lock = threading.Lock()
_epg_bg_lock = threading.Lock()


def _do_cleanup_caches():
    """Perform one cache-cleanup pass (called at start and every 300s)."""
    now = time.time()
    # DNS cache: TTL 30 min
    with _dns_cache_lock:
        stale = [h for h, (_, ts) in list(_dns_cache.items()) if now - ts > 1800]
        for h in stale:
            del _dns_cache[h]
    # Channel creds: purge entries older than 10 min
    with _proxy_lock:
        stale = [k for k, v in list(_channel_creds.items()) if now - v.get('fetched_at', 0) > 600]
        for k in stale:
            del _channel_creds[k]
            _m3u8_stall.pop(k, None)
            _last_sent_seq.pop(k, None)
    # C1: cap _sent_seg_urls to last 200 entries per channel; evict _seg_url_to_channel
    # for channels no longer in _channel_creds
    with _stall_lock:
        with _proxy_lock:
            active_keys = set(_channel_creds.keys())
        for ch_key in list(_sent_seg_urls.keys()):
            urls = _sent_seg_urls[ch_key]
            if len(urls) > 200:
                # Keep only the last 200 — rebuild from a sorted slice is not possible
                # on a plain set, so replace with a new set of the last 200 items added.
                _sent_seg_urls[ch_key] = set(list(urls)[-200:])
        dead_urls = [u for u, ch in list(_seg_url_to_channel.items()) if ch not in active_keys]
        for u in dead_urls:
            del _seg_url_to_channel[u]


def _cleanup_caches():
    """Background thread: purge stale entries every 5 minutes. Exits on Kodi abort."""
    monitor = xbmc.Monitor()
    # L7: run cleanup once immediately before entering the wait loop
    _do_cleanup_caches()
    while not monitor.waitForAbort(300):
        _do_cleanup_caches()


def _dns_resolve(hostname, dns_server, port=53, timeout=2):
    """Resolve a hostname via UDP to a custom DNS server. Returns IP string or None."""
    try:
        txid = random.randint(1, 65535)
        # Header with RD flag, 1 question, 0 answers, 0 authority, 1 additional (EDNS0)
        header = struct.pack('>HHHHHH', txid, 0x0100, 1, 0, 0, 1)
        question = b''
        for label in hostname.split('.'):
            enc = label.encode('ascii')
            question += bytes([len(enc)]) + enc
        question += b'\x00' + struct.pack('>HH', 1, 1)  # Type A, Class IN
        # EDNS0 OPT record: allows up to 4096 byte UDP responses
        edns0 = b'\x00' + struct.pack('>HHIH', 41, 4096, 0, 0)
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
            sock.settimeout(timeout)
            sock.sendto(header + question + edns0, (dns_server, port))
            resp = sock.recv(4096)
        ancount = struct.unpack('>H', resp[6:8])[0]
        if ancount == 0:
            return None
        # Skip question section
        offset = 12
        while resp[offset] != 0:
            if resp[offset] & 0xC0 == 0xC0:
                offset += 2
                break
            offset += resp[offset] + 1
        else:
            offset += 1
        offset += 4  # QTYPE + QCLASS
        # Parse answer records
        for _ in range(ancount):
            if resp[offset] & 0xC0 == 0xC0:
                offset += 2
            else:
                while resp[offset] != 0:
                    offset += resp[offset] + 1
                offset += 1
            rtype, _rc, _ttl, rdlen = struct.unpack('>HHIH', resp[offset:offset + 10])
            offset += 10
            if rtype == 1 and rdlen == 4:
                return '.'.join(str(b) for b in resp[offset:offset + 4])
            offset += rdlen
        return None
    except Exception:
        return None


_dns_cache = {}  # host -> (ip, timestamp)
_dns_cache_lock = threading.Lock()
_active_dns = None  # set by _apply_custom_dns after reachability check
_DNS_FALLBACK = '8.8.8.8'
_original_getaddrinfo = socket.getaddrinfo

_upstream_dead = {}         # host -> (timestamp, last_error) — see _upstream_alive
_upstream_dead_lock = threading.Lock()

_server_key_cache = {}          # channel_id -> (server_key, timestamp)
_server_key_cache_lock = threading.Lock()
_SERVER_KEY_TTL = 600           # 10 min
_lovecdn_url_cache = {}         # stream_name -> (lovecdn_url, timestamp)
_lovecdn_url_cache_lock = threading.Lock()
_LOVECDN_URL_TTL = 480          # 8 min (token valid ~15 min)
_lovecdn_session = requests.Session()  # persistent session — keeps Cloudflare cookies
_lovecdn_seg_cache = {}         # seg_url -> bytes (pre-downloaded segments, last 6)
_lovecdn_seg_cache_lock = threading.Lock()
_ptv_seg_cache = {}             # premiumtv segment path -> unwrapped MPEG-TS
_ptv_seg_keys = []              # insertion order, bounded eviction
_ptv_seg_lock = threading.Lock()
# Unwrapping costs ~2 s per segment on an Android box, so a segment decoded twice
# is two seconds of latency added to the stream. ISA re-requests segments when it
# loses its buffer, and the proxy is asked again after a retry, so the repeat is
# common enough to be worth 3 slots of ~5 MB.
_PTV_SEG_CACHE_MAX = 3

_wide_seg_cache = {}            # seg_key -> bytes (wideiptv pre-downloaded segments)
_wide_seg_cache_lock = threading.Lock()
_wide_seg_queued = set()        # seg_key currently being prefetched
_wide_slug_cache = {}           # channel id -> {slug, url, token, ts}
_wide_slug_lock = threading.Lock()
_wide_slug_absent = {}          # slug -> timestamp, CDN has no content for it
_wide_dead_segs = {}            # seg_key -> expiry, for segments the CDN does not have
_wide_seg_keys = []             # insertion order, for bounded eviction
_WIDE_SEG_CACHE_MAX = 8         # ~5 MB each at 1080p — keep memory in check
_WIDE_PREFETCH_AHEAD = 6        # how many upcoming segments to chase per playlist
_WIDE_DEAD_TTL = 30             # forget an absent segment after 30s
_wide_prefetch_on = True


def _wide_seg_key(url):
    """Cache key for a wideiptv segment: path only, so a token refresh does not
    invalidate an already-buffered segment."""
    base = url.split('?', 1)[0]
    return base


def _wide_log_tail(url, width=40):
    """Last part of a wideiptv URL's *path* for logging.

    The token is long, random and differs per request, so slicing the raw URL
    shows a different tail every time and never says which segment it was."""
    path = urlsplit(url).path
    return path[-width:] or path


def _wide_is_playlist(url):
    """True for a manifest rather than a media segment.

    A master playlist lists its variant playlists as plain lines, so without this
    the prefetcher downloads each media playlist six times looking for MPEG-TS
    that will never be there."""
    return urlsplit(url).path.lower().endswith(('.m3u8', '.m3u', '.mpd'))


def _wide_cache_store(key, body):
    with _wide_seg_cache_lock:
        if key not in _wide_seg_cache:
            _wide_seg_keys.append(key)
        _wide_seg_cache[key] = body
        while len(_wide_seg_keys) > _WIDE_SEG_CACHE_MAX:
            _wide_seg_cache.pop(_wide_seg_keys.pop(0), None)


def _wide_prefetch_seg(seg_url, slug, attempts=6):
    """Background-download one wideiptv segment into memory.

    The wideiptv CDN drops roughly two connections in three, which is far too
    lossy for inputstream.adaptive to open a stream at all. Chasing segments ahead
    of playback turns that flakiness into a buffer-refill problem instead of a
    dropped-frame problem: as long as segments land faster than real time, ISA
    never sees a gap.

    A 404/403 is treated as terminal, not as flakiness. The log shows the playlist
    advertising segment paths the CDN does not have; retrying those only steals
    connections from the segments that could actually play, so they are marked
    dead for a short window and skipped."""
    key = _wide_seg_key(seg_url)
    if _wide_is_playlist(seg_url):
        # A variant playlist, not media. Fetching it would never yield MPEG-TS, so
        # it can only burn the six attempts below on every master playlist refresh.
        return
    with _wide_seg_cache_lock:
        if key in _wide_seg_cache or key in _wide_seg_queued:
            return
        if _wide_dead_segs.get(key, 0) > time.time():
            # The interesting case of the three: the CDN already told us this
            # segment does not exist, and we are proving we stop asking.
            log(f'[WidePrefetch] skip (marked absent) {_wide_log_tail(seg_url)}')
            return
        # Claim the slot atomically, then do every network call outside the lock.
        _wide_seg_queued.add(key)
    try:
        hdrs = {'User-Agent': UA, 'Referer': f'https://wideiptv.top/player/{slug}'}
        # Same fresh-token rebuild as the proxy path: the playlist's own token is
        # already stale by the time ISA asks for the segment.
        fetch_url = _wide_freshen_url(seg_url, slug)
        for i in range(attempts):
            try:
                r = requests.get(fetch_url, headers=hdrs, timeout=5)
                if r.status_code == 200 and r.content[:1] == b'\x47':
                    _wide_cache_store(key, r.content)
                    log(f'[WidePrefetch] cached {len(r.content)}B {_wide_log_tail(seg_url, 46)} '
                        f'(try {i + 1}/{attempts})')
                    return
                if r.status_code in (403, 404):
                    _wide_mark_dead(key)
                    log(f'[WidePrefetch] HTTP {r.status_code} — segment absent, '
                        f'not retrying {_wide_log_tail(seg_url)}')
                    return
                log(f'[WidePrefetch] HTTP {r.status_code} {len(r.content)}B '
                    f'{_wide_log_tail(seg_url)} (try {i + 1}/{attempts})')
            except Exception as e:
                log(f'[WidePrefetch] try {i + 1}/{attempts} {type(e).__name__}: '
                    f'{_wide_log_tail(seg_url)}')
            # Connection drops are the flakiness worth retrying, so pace the retries.
            time.sleep(0.3)
    finally:
        with _wide_seg_cache_lock:
            _wide_seg_queued.discard(key)


def _wide_mark_dead(key, ttl=_WIDE_DEAD_TTL):
    """Remember a segment the CDN does not have, so we stop asking for it."""
    with _wide_seg_cache_lock:
        _wide_dead_segs[key] = time.time() + ttl
        if len(_wide_dead_segs) > _WIDE_SEG_CACHE_MAX * 2:
            for k in [k for k, exp in _wide_dead_segs.items() if exp < time.time()]:
                _wide_dead_segs.pop(k, None)


def _wide_prefetch_ahead(seg_urls, slug):
    """Chase the segments that follow the ones ISA is about to ask for."""
    if not _wide_prefetch_on or not seg_urls:
        return
    for u in seg_urls[-_WIDE_PREFETCH_AHEAD:]:
        if not u.startswith('http'):
            continue
        t = threading.Thread(target=_wide_prefetch_seg, args=(u, slug), daemon=True)
        t.start()


_tls = threading.local()


def _get_session():
    """Return per-thread requests.Session (created on first use)."""
    if not hasattr(_tls, 'session') or getattr(_tls.session, 'verify', True) is not False:
        s = requests.Session()
        s.verify = False  # CHEVY proxy uses self-signed/mismatched SSL certs
        _tls.session = s
    return _tls.session


def _fix_lovecdn_pcr(data, seg_dur):
    """Fix corrupt PCR values in a lovecdn TS segment.
    Some lovecdn segments have random/garbage PCR on the video PID while PTS/DTS
    remain correct. Kodi's native VideoPlayer uses PCR as the presentation clock,
    causing severe stuttering when PCR jumps wildly within a segment.
    Fix: anchor to the first valid PCR and linearly interpolate all subsequent
    PCR packets across the segment duration. The first PCR in lovecdn segments is
    always correct (matches PTS), so this preserves the PCR/PTS relationship."""
    n_pkts = len(data) // 188
    if n_pkts < 2:
        return data

    # Find the first PCR packet and its value
    first_pcr = None
    first_pcr_idx = 0
    for i in range(n_pkts):
        off = i * 188
        if data[off] != 0x47:
            continue
        if not ((data[off + 3] >> 4) & 1):  # no adaptation field
            continue
        if data[off + 4] < 7:  # adaptation too short
            continue
        if not (data[off + 5] & 0x10):  # no PCR_flag
            continue
        b = data[off + 6:off + 12]
        pcr_base = (b[0] << 25) | (b[1] << 17) | (b[2] << 9) | (b[3] << 1) | (b[4] >> 7)
        pcr_ext = ((b[4] & 1) << 8) | b[5]
        first_pcr = pcr_base * 300 + pcr_ext
        first_pcr_idx = i
        break

    if first_pcr is None:
        return data  # no PCR in segment, nothing to fix

    # Linearly interpolate PCR from first_pcr to first_pcr + seg_dur * 27MHz
    total_27mhz = seg_dur * 27000000
    data = bytearray(data)
    for i in range(first_pcr_idx, n_pkts):
        off = i * 188
        if data[off] != 0x47:
            continue
        if not ((data[off + 3] >> 4) & 1):
            continue
        if data[off + 4] < 7:
            continue
        if not (data[off + 5] & 0x10):
            continue
        frac = (i - first_pcr_idx) / max(n_pkts - first_pcr_idx, 1)
        pcr = first_pcr + int(frac * total_27mhz)
        pcr_base = (pcr // 300) & 0x1FFFFFFFF  # 33-bit
        pcr_ext = int(pcr % 300)               # 9-bit
        data[off + 6] = (pcr_base >> 25) & 0xFF
        data[off + 7] = (pcr_base >> 17) & 0xFF
        data[off + 8] = (pcr_base >> 9) & 0xFF
        data[off + 9] = (pcr_base >> 1) & 0xFF
        data[off + 10] = ((pcr_base & 1) << 7) | 0x7E | ((pcr_ext >> 8) & 1)
        data[off + 11] = pcr_ext & 0xFF
    return bytes(data)


def _lovecdn_get_media_url(stream_name, force_refresh=False):
    """Fetch and return the current lovecdn media playlist content.
    Returns (media_url, lt_url, media_text, media_base) or None on failure.
    Caches the token URL for _LOVECDN_URL_TTL seconds (8 min)."""
    now = time.time()
    lovecdn_url = lt_url = None

    if not force_refresh:
        with _lovecdn_url_cache_lock:
            cached = _lovecdn_url_cache.get(stream_name)
            if cached and now - cached[1] < _LOVECDN_URL_TTL:
                lovecdn_url, lt_url = cached[0], cached[2]

    if not lovecdn_url:
        with _lovecdn_url_cache_lock:
            expired = _lovecdn_url_cache.get(stream_name)
        lt_url = (expired[2] if expired and len(expired) > 2 else None) \
                 or f'https://lovetier.bz/player/{stream_name}'
        try:
            r = _lovecdn_session.get(lt_url, headers={'User-Agent': UA}, timeout=8)
        except Exception as e:
            log(f'[LovecdnProxy] lovetier fetch error for {stream_name}: {e}')
            return None
        if r.status_code != 200:
            log(f'[LovecdnProxy] lovetier HTTP {r.status_code} for {stream_name}')
            return None
        m3 = re.search(r'streamUrl\s*:\s*"(https?:[^"]+)"', r.text)
        if not m3:
            log(f'[LovecdnProxy] no streamUrl for {stream_name}')
            return None
        lovecdn_url = m3.group(1).replace('\\/', '/')
        with _lovecdn_url_cache_lock:
            _lovecdn_url_cache[stream_name] = (lovecdn_url, now, lt_url)
        log(f'[LovecdnProxy] refreshed token for {stream_name}')

    try:
        r2 = _lovecdn_session.get(lovecdn_url, headers={'User-Agent': UA, 'Referer': lt_url}, timeout=8)
    except Exception as e:
        log(f'[LovecdnProxy] media fetch error for {stream_name}: {e}')
        return None
    if r2.status_code != 200:
        log(f'[LovecdnProxy] lovecdn HTTP {r2.status_code} for {stream_name}')
        with _lovecdn_url_cache_lock:
            _lovecdn_url_cache.pop(stream_name, None)
        return None

    master_base = lovecdn_url.split('?')[0].rsplit('/', 1)[0] + '/'
    media_text = r2.text
    media_base = master_base
    current_url = lovecdn_url
    # Follow master→variant chain
    while '#EXT-X-STREAM-INF' in media_text:
        next_url = None
        preferred_url = None
        for line in media_text.splitlines():
            stripped = line.strip()
            if stripped and not stripped.startswith('#'):
                candidate = stripped if stripped.startswith('http') else urljoin(media_base, stripped)
                if not next_url:
                    next_url = candidate
                if not preferred_url and 'a1' in candidate:
                    preferred_url = candidate
        next_url = preferred_url or next_url
        if not next_url or next_url == current_url:
            break
        try:
            rv = _lovecdn_session.get(next_url, headers={'User-Agent': UA, 'Referer': lt_url}, timeout=8)
        except Exception as e:
            log(f'[LovecdnProxy] variant fetch error: {e}')
            return None
        if rv.status_code != 200:
            log(f'[LovecdnProxy] variant HTTP {rv.status_code}')
            return None
        current_url = next_url
        media_text = rv.text
        media_base = current_url.split('?')[0].rsplit('/', 1)[0] + '/'
    # Cache the resolved media playlist URL
    with _lovecdn_url_cache_lock:
        cached_entry = _lovecdn_url_cache.get(stream_name)
        if cached_entry:
            _lovecdn_url_cache[stream_name] = (current_url, now, cached_entry[2])

    return current_url, lt_url, media_text, media_base


def _lovecdn_prefetch_seg(seg_url):
    """Pre-download a lovecdn segment into memory cache (called in background thread)."""
    with _lovecdn_seg_cache_lock:
        if seg_url in _lovecdn_seg_cache:
            return  # already cached
    try:
        r = _lovecdn_session.get(seg_url, headers={'User-Agent': UA}, timeout=(3, 10))
        if r.status_code == 200:
            with _lovecdn_seg_cache_lock:
                _lovecdn_seg_cache[seg_url] = r.content
                # Keep cache bounded: drop oldest entries beyond 6
                while len(_lovecdn_seg_cache) > 6:
                    _lovecdn_seg_cache.pop(next(iter(_lovecdn_seg_cache)))
            log(f'[LovecdnPrefetch] cached {len(r.content)}B {seg_url[-50:]}')
    except Exception as e:
        log(f'[LovecdnPrefetch] error: {e}')


def _patched_getaddrinfo(host, port, family=0, type=0, proto=0, flags=0):
    if not _active_dns or not host:
        return _original_getaddrinfo(host, port, family, type, proto, flags)
    # Only take over plain AF_INET lookups. Answering an explicit AF_INET6 request
    # with an AF_INET entry makes the caller build a socket the local stack may
    # not support, which surfaces as [Errno 92] Protocol not available.
    if family not in (0, socket.AF_INET):
        return _original_getaddrinfo(host, port, family, type, proto, flags)
    # Don't intercept IP literals or localhost
    try:
        socket.inet_aton(host)
        return _original_getaddrinfo(host, port, family, type, proto, flags)
    except OSError:
        pass
    if host == 'localhost' or host.endswith('.local'):
        return _original_getaddrinfo(host, port, family, type, proto, flags)
    with _dns_cache_lock:
        entry = _dns_cache.get(host)
    ip = None
    if entry:
        cached_ip, cached_ts = entry
        if time.time() - cached_ts < 1800:  # 30 min TTL
            ip = cached_ip
    if ip is None:
        ip = _dns_resolve(host, _active_dns)
        if ip:
            with _dns_cache_lock:
                _dns_cache[host] = (ip, time.time())
        else:
            # Active DNS failed — try the other server
            _fallback = _DNS_FALLBACK if _active_dns != _DNS_FALLBACK else _CUSTOM_DNS
            log(f'[CustomDNS] resolve failed via {_active_dns} for {host}, trying {_fallback}')
            ip = _dns_resolve(host, _fallback)
            if ip:
                with _dns_cache_lock:
                    _dns_cache[host] = (ip, time.time())
                log(f'[CustomDNS] {host} → {ip} (via {_fallback} fallback)')
            else:
                log(f'[CustomDNS] resolve failed for {host}, fallback to system DNS')
                return _original_getaddrinfo(host, port, family, type, proto, flags)
    socktypes = (type,) if type else (socket.SOCK_STREAM, socket.SOCK_DGRAM)
    return [(socket.AF_INET, st, proto, '', (ip, port or 0)) for st in socktypes]


def _apply_custom_dns():
    global _active_dns
    if not _CUSTOM_DNS:
        return
    # Quick reachability check: resolve a known hostname via the configured DNS server
    _test_ip = _dns_resolve('www.google.com', _CUSTOM_DNS, timeout=2)
    if _test_ip:
        _active_dns = _CUSTOM_DNS
        xbmc.log(f'[DLTV][CustomDNS] Active — using {_CUSTOM_DNS}', xbmc.LOGINFO)
    else:
        _active_dns = _DNS_FALLBACK
        xbmc.log(f'[DLTV][CustomDNS] {_CUSTOM_DNS} unreachable — using {_DNS_FALLBACK} as primary', xbmc.LOGWARNING)
    socket.getaddrinfo = _patched_getaddrinfo


_apply_custom_dns()
threading.Thread(target=_cleanup_caches, daemon=True).start()


def _compute_fingerprint():
    combined = _AUTH_UA + '1920x1080' + 'UTC' + 'en'
    return hashlib.sha256(combined.encode()).hexdigest()[:16]


def _compute_pow_nonce(channel_key, channel_salt, key_id, ts):
    hmac_base = _hmac.new(channel_salt.encode(), channel_key.encode(), hashlib.sha256).hexdigest()
    for nonce in range(100000):
        combined = hmac_base + channel_key + key_id + str(ts) + str(nonce)
        h = hashlib.md5(combined.encode()).hexdigest()
        if int(h[:4], 16) < 0x1000:
            return nonce
    return 99999


def _compute_auth_sig(channel_key, channel_salt, key_id, ts, fp):
    msg = f'{channel_key}|{key_id}|{ts}|{fp}'
    return _hmac.new(channel_salt.encode(), msg.encode(), hashlib.sha256).hexdigest()[:16]


def _xor_decode(arr, key):
    return ''.join(chr(b ^ key) for b in arr)


def _extract_credential(page, field):
    """Extract a credential value supporting plain string or XOR-encoded formats."""
    # Format 1: field: 'value'
    m = re.search(rf"{field}\s*:\s*'([^']+)'", page)
    if m:
        return m.group(1)
    # Format 2: field: _dec_XXXX(_init_YYYY, key)
    m = re.search(rf"{field}\s*:\s*_dec_\w+\((_init_\w+),\s*(\d+)\)", page)
    if m:
        init_name, key = m.group(1), int(m.group(2))
        arr_m = re.search(rf"{init_name}\s*=\s*\[([^\]]+)\]", page)
        if arr_m:
            arr = list(map(int, arr_m.group(1).split(',')))
            return _xor_decode(arr, key)
    return None


_CREDS_JS_SKIP_HOSTS = (
    'code.jquery.com', 'cdn.jsdelivr.net', 'cdnjs.cloudflare.com',
    'ajax.googleapis.com', 'www.google.com', 'www.googletagmanager.com',
    'static.cloudflareinsights.com',
)

def _extract_creds_with_js(page_text, page_url, base_url, sess):
    """Extract authToken+channelSalt from page HTML and any referenced external JS files.
    Skips known CDN libraries (jQuery, Clappr, HLS.js, reCAPTCHA…) — they never contain credentials."""
    at = _extract_credential(page_text, 'authToken')
    cs = _extract_credential(page_text, 'channelSalt')
    if at and cs:
        return at, cs
    # Credentials may be in an external JS file loaded by the page
    for sm in re.finditer(r'<script[^>]+src=["\']([^"\']+)["\']', page_text):
        src = sm.group(1)
        if src.startswith('//'):
            src = 'https:' + src
        elif src.startswith('/'):
            src = base_url.rstrip('/') + src
        elif not src.startswith('http'):
            continue
        if any(h in src for h in _CREDS_JS_SKIP_HOSTS):
            continue
        try:
            log(f'[EPlayerAuth] Fetching external JS: {src[:100]}')
            rjs = sess.get(src, headers={'User-Agent': _AUTH_UA, 'Referer': page_url}, timeout=4)
            log(f'[EPlayerAuth] JS content ({src[-40:]}): {rjs.text[:600]}')
            at = _extract_credential(rjs.text, 'authToken')
            cs = _extract_credential(rjs.text, 'channelSalt')
            if at and cs:
                log(f'[EPlayerAuth] Credentials found in external JS: {src[:80]}')
                return at, cs
        except Exception as e:
            log(f'[EPlayerAuth] External JS fetch error ({src[:60]}): {e}')
    return None, None


def _is_js_challenge(text):
    """Return True if response looks like a Cloudflare/bot JS challenge page."""
    t = text[:800]
    return ("window['" in t and 'document.location' in t) or 'challenge-form' in t


def _fetch_auth_credentials(channel_id, max_attempts=3):
    """Fetch fresh authToken and channelSalt from the ksohls.ru player page.
    Tries _KSOHLS_BASE first (with stream page referer); if it returns a JS challenge,
    falls back to _KSOHLS_FALLBACK_BASES."""
    # Use the stream page URL as referer — the auth server checks it.
    # Also visit it first: CF shares clearance state across zones on the same account,
    # so a prior visit to the configured base URL unblocks segments in the same session.
    stream_referer = abs_url(f'stream/stream-{channel_id}.php')
    try:
        _get_session().get(stream_referer, headers={'User-Agent': UA}, timeout=4)
    except Exception:
        pass
    bases = [_KSOHLS_BASE] + [b for b in _KSOHLS_FALLBACK_BASES if b != _KSOHLS_BASE]
    for base in bases:
        url = f'{base}/premiumtv/daddyhd.php?id={channel_id}'
        for attempt in range(max_attempts):
            try:
                r = _get_session().get(url, headers={
                    'User-Agent': UA,
                    'Referer': stream_referer,
                }, timeout=4)
                if r.status_code in (502, 503, 504):
                    log(f'[EPlayerAuth] Server error {r.status_code} on {base} (attempt {attempt+1}/{max_attempts})')
                    if attempt < max_attempts - 1:
                        time.sleep(1.5)
                    continue
                if _is_js_challenge(r.text):
                    log(f'[EPlayerAuth] JS challenge on {base}, trying next')
                    break  # skip remaining retries for this base
                auth_token, channel_salt = _extract_creds_with_js(r.text, url, base, _get_session())
                if auth_token and channel_salt:
                    return auth_token, channel_salt
                log(f'[EPlayerAuth] Credentials not found on {base} (attempt {attempt+1}/{max_attempts})')
            except Exception as e:
                log(f'[EPlayerAuth] fetch error (attempt {attempt+1}/{max_attempts}): {e}')
            if attempt < max_attempts - 1:
                time.sleep(1)
    return None, None


def _fetch_direct_m3u8_url(channel_id):
    """New backend format: the auth player page embeds the final signed m3u8 URL as a
    base64 literal (source:window.atob('...')). Returns (m3u8_url, player_referer) or
    (None, None). Tries daddy.php (current) and daddyhd.php (legacy) on each known base."""
    stream_referer = abs_url(f'stream/stream-{channel_id}.php')
    bases = [_KSOHLS_BASE] + [b for b in _KSOHLS_FALLBACK_BASES if b != _KSOHLS_BASE]
    seen = []
    for base in bases:
        if base in seen:
            continue
        seen.append(base)
        for path in ('/premiumtv/daddy.php', '/premiumtv/daddyhd.php'):
            try:
                r = _get_session().get(f'{base}{path}?id={channel_id}', headers={
                    'User-Agent': UA,
                    'Referer': stream_referer,
                }, timeout=4)
                if r.status_code != 200 or _is_js_challenge(r.text):
                    continue
                mb = re.search(r"atob\('([A-Za-z0-9+/=]+)'\)", r.text)
                if not mb:
                    continue
                u = base64.b64decode(mb.group(1)).decode('utf-8', 'ignore').strip()
                if u.startswith('http'):
                    log(f'[EPlayerAuth] direct m3u8 found on {base}{path} for id={channel_id}')
                    return u, base + '/'
            except Exception as e:
                log(f'[EPlayerAuth] direct fetch error on {base}{path}: {e}')
                continue
    return None, None


def _discover_server_urls():
    """Auto-discover CHEVY_PROXY, CHEVY_LOOKUP and _KSOHLS_BASE from the site's auth player page.
    Fetches stream/stream-1.php → finds premiumtv iframe → parses CHEVY URLs from its JS.
    Updates module-level globals and saves a cache file. Safe to call from a background thread."""
    global CHEVY_PROXY, CHEVY_LOOKUP, _KSOHLS_BASE, PLAYER_REFERER
    try:
        log('[Discovery] Starting server URL discovery...')
        watch_url = abs_url('watch.php?id=1')
        stream_url = abs_url('stream/stream-1.php')
        r = requests.get(stream_url, headers={'User-Agent': UA, 'Referer': watch_url}, timeout=8)
        if r.status_code != 200:
            log(f'[Discovery] stream page HTTP {r.status_code}')
            return

        # Find the auth player iframe (premiumtv URL)
        mp = re.search(r'<iframe[^>]+src="(https?://([^/"]+)/premiumtv/[^"]+)"', r.text)
        if not mp:
            log('[Discovery] no premiumtv iframe found')
            return
        player_url, ksohls_host = mp.group(1), mp.group(2)
        ksohls_base = f'https://{ksohls_host}'

        # Fetch the auth player page and scan for CHEVY URLs
        r2 = requests.get(player_url, headers={'User-Agent': UA, 'Referer': stream_url}, timeout=8)
        if r2.status_code != 200:
            log(f'[Discovery] auth player HTTP {r2.status_code}')
            return

        if _is_js_challenge(r2.text):
            log(f'[Discovery] auth player page behind JS challenge — skipping ksohls={ksohls_base}')
            return

        # Skip JS template literals like https://${M3U8_SERVER}/proxy/
        mp2 = re.search(r'(https?://(?!\$\{)[^\s"\'<>{}$]+)/proxy/', r2.text)
        chevy_proxy = mp2.group(1) if mp2 else None
        ml = re.search(r'(https?://(?!\$\{)[^\s"\'<>{}$]+)/server_lookup', r2.text)
        chevy_lookup = ml.group(1) if ml else None

        # If lookup not found as a literal, probe the proxy host's /health endpoint
        if chevy_proxy and not chevy_lookup:
            candidate = re.sub(r'^(https?://[^/]+).*', r'\1', chevy_proxy)
            try:
                rh = _get_session().get(f'{candidate}/health', headers={'User-Agent': UA}, timeout=4)
                if rh.status_code == 200:
                    chevy_lookup = candidate
                    log(f'[Discovery] lookup derived from proxy host: {chevy_lookup}')
            except Exception:
                pass

        # Fall back to current known lookup if still not resolved
        effective_lookup = chevy_lookup or CHEVY_LOOKUP

        log(f'[Discovery] ksohls={ksohls_base} proxy={chevy_proxy} lookup={effective_lookup}')

        _KSOHLS_BASE = ksohls_base
        PLAYER_REFERER = ksohls_base + '/'
        _SEG_HEADERS['Origin'] = ksohls_base
        _SEG_HEADERS['Referer'] = PLAYER_REFERER

        try:
            with open(_DISCOVERY_CACHE_FILE, 'w') as _f:
                json.dump({'ksohls': ksohls_base, 'proxy': chevy_proxy, 'lookup': effective_lookup}, _f)
        except Exception:
            pass

        if chevy_proxy:
            CHEVY_PROXY = chevy_proxy
            CHEVY_LOOKUP = effective_lookup
            addon.setSetting('chevy_proxy_url', chevy_proxy)
            addon.setSetting('chevy_lookup_url', effective_lookup)
            addon.setSetting('ksohls_base_url', ksohls_base)
            log(f'[Discovery] Updated: proxy={chevy_proxy} lookup={effective_lookup} ksohls={ksohls_base}')
        else:
            addon.setSetting('ksohls_base_url', ksohls_base)
            if effective_lookup:
                addon.setSetting('chevy_lookup_url', effective_lookup)
            log(f'[Discovery] Updated ksohls only (page has no literal proxy URL): ksohls={ksohls_base}')

    except Exception as e:
        log(f'[Discovery] error: {e}')


def _state_file(channel_key):
    return os.path.join(_KODI_TEMP, f'dltv_{channel_key}.json')


def _set_channel_state(channel_key, auth_token, channel_salt, m3u8_url, player_referer=None):
    state = {
        'auth_token': auth_token,
        'channel_salt': channel_salt,
        'm3u8_url': m3u8_url,
        'fetched_at': time.time(),
    }
    if player_referer:
        state['player_referer'] = player_referer
    with _proxy_lock:
        _channel_creds[channel_key] = state
    # Reset stall/timeout/throttle/dedup counters — fresh session, stale counts must not carry over
    with _stall_lock:
        _m3u8_stall.pop(channel_key, None)
        _m3u8_timeouts.pop(channel_key, None)
        _last_sent_seq.pop(channel_key, None)
        _sent_seg_urls.pop(channel_key, None)
        _last_media_seq_out.pop(channel_key, None)
    # Persist to temp file so other plugin processes can read the state
    try:
        with open(_state_file(channel_key), 'w') as f:
            json.dump(state, f)
    except Exception:
        pass


def _get_channel_state(channel_key):
    with _proxy_lock:
        state = _channel_creds.get(channel_key)
    # Always check if the file has been updated by another process
    try:
        path = _state_file(channel_key)
        if os.path.exists(path):
            file_mtime = os.path.getmtime(path)
            in_memory_time = state.get('fetched_at', 0) if state else 0
            if file_mtime > in_memory_time and (time.time() - file_mtime) < 300:
                with open(path) as f:
                    file_state = json.load(f)
                # New session from another process — reset dedup/stall so old
                # segment URLs don't cause immediate dedup skip.
                with _stall_lock:
                    _m3u8_stall.pop(channel_key, None)
                    _m3u8_timeouts.pop(channel_key, None)
                    _last_sent_seq.pop(channel_key, None)
                    _sent_seg_urls.pop(channel_key, None)
                    _last_media_seq_out.pop(channel_key, None)
                with _proxy_lock:
                    _channel_creds[channel_key] = file_state
                return dict(file_state)
    except Exception:
        pass
    if state:
        return dict(state)
    return {}


def _refresh_channel_creds(cid, max_attempts=3):
    """Fetch fresh auth credentials + CDN URL, update channel state.
    Returns updated state dict on success, or None on failure."""
    channel_key = f'premium{cid}'
    direct_url, pref = _fetch_direct_m3u8_url(cid)
    if direct_url:
        log(f'[EPlayerAuth] using new-format direct m3u8 for {channel_key}')
        _set_channel_state(channel_key, 'noauth', 'noauth', direct_url, player_referer=pref)
        # Réinitialiser les compteurs de stall/timeout qui causent les saccades
        with _stall_lock:
            _m3u8_stall.pop(channel_key, None)
            _m3u8_timeouts.pop(channel_key, None)
            _last_sent_seq.pop(channel_key, None)
            _sent_seg_urls.pop(channel_key, None)
            _last_media_seq_out.pop(channel_key, None)
        return _get_channel_state(channel_key)
    at, cs = _fetch_auth_credentials(cid, max_attempts=max_attempts)
    if not (at and cs):
        return None
    url = resolve_stream_url(cid)
    _set_channel_state(channel_key, at, cs, url)
    return _get_channel_state(channel_key)


_PTV_ENVELOPE_MAGIC = bytes([84, 73, 75, 84, 73, 75, 80, 88])  # b'TIKTIKPX'


def _png_rgb_pixels(data):
    """Decode a non-interlaced 8-bit PNG (colour type 2 or 6) into raw RGB bytes.

    Written to match pngRGB() in the premiumtv player page, including the five
    per-scanline filter types — the payload is hidden in the pixel data itself, so
    the filters have to be reversed exactly as the browser does."""
    if len(data) < 8 or data[:2] != b'\x89P':
        return None
    off = 8
    w = h = depth = ctype = interlace = 0
    idat = []
    while off + 8 <= len(data):
        length = struct.unpack('>I', data[off:off + 4])[0]
        if length > len(data) - off - 12:
            return None
        ctype_tag = data[off + 4:off + 8]
        payload = data[off + 8:off + 8 + length]
        if ctype_tag == b'IHDR':
            w, h = struct.unpack('>II', payload[:8])
            depth, ctype = payload[8], payload[9]
            interlace = payload[12] if len(payload) > 12 else 0
        elif ctype_tag == b'IDAT':
            idat.append(payload)
        elif ctype_tag == b'IEND':
            break
        off += 12 + length
    if not w or not h or depth != 8 or interlace or ctype not in (2, 6):
        return None
    try:
        raw = zlib.decompress(b''.join(idat))
    except zlib.error:
        return None
    bpp = 4 if ctype == 6 else 3
    stride = w * bpp
    if len(raw) < (stride + 1) * h:
        return None
    out = bytearray(w * h * 3)
    prev = bytearray(stride)
    pos = 0
    for row in range(h):
        ftype = raw[pos]
        pos += 1
        line = bytearray(raw[pos:pos + stride])
        pos += stride
        if ftype == 1:
            for i in range(bpp, stride):
                line[i] = (line[i] + line[i - bpp]) & 0xFF
        elif ftype == 2:
            for i in range(stride):
                line[i] = (line[i] + prev[i]) & 0xFF
        elif ftype == 3:
            for i in range(stride):
                left = line[i - bpp] if i >= bpp else 0
                line[i] = (line[i] + ((left + prev[i]) >> 1)) & 0xFF
        elif ftype == 4:
            for i in range(stride):
                a = line[i - bpp] if i >= bpp else 0
                b = prev[i]
                c = prev[i - bpp] if i >= bpp else 0
                dist = a + b - c
                da, db, dc = abs(dist - a), abs(dist - b), abs(dist - c)
                pred = a if (da <= db and da <= dc) else (b if db <= dc else c)
                line[i] = (line[i] + pred) & 0xFF
        if bpp == 3:
            out[row * w * 3:(row + 1) * w * 3] = line
        else:
            src = 0
            for x in range(w):
                out[(row * w + x) * 3:(row * w + x) * 3 + 3] = line[src:src + 3]
                src += 4
        prev = line
    return bytes(out)


def _unwrap_ptv_segment(body):
    """Recover the MPEG-TS that premiumtv wraps inside a PNG image.

    WHAT THIS IS
    The premiumtv player page ships a custom hls.js fragment loader
    (`LiveLoader`) whose only job is to unwrap each fragment before handing it to
    the player. The site serves the segments as PNG images so that ordinary HLS
    clients — Kodi, inputstream.adaptive, ffmpeg — cannot read them; a browser
    only plays because that loader unwraps them first.

    WHAT IT DOES HERE
    This reproduces the same unwrap so Kodi receives plain MPEG-TS. It is the
    reverse of a deliberate measure by the stream operator, not a fix for a bug:
    reading these segments required the format they were chosen to hide. It is
    documented here rather than left implicit so the trade-off stays visible to
    whoever maintains this.

    The envelope is not encrypted. Layout, per unwrapPixels() in the player:
      PNG pixels -> b'TIKTIKPX' (8 bytes) -> uint32 big-endian gzip length
      -> gzip stream -> MPEG-TS.
    Returns the TS bytes, or None when the body is not one of these envelopes.
    """
    if len(body) < 2 or body[:2] != b'\x89P':
        return None
    rgb = _png_rgb_pixels(body)
    if not rgb or len(rgb) < 12 or rgb[:8] != _PTV_ENVELOPE_MAGIC:
        return None
    length = struct.unpack('>I', rgb[8:12])[0]
    if length <= 0 or 12 + length > len(rgb):
        return None
    blob = rgb[12:12 + length]
    if len(blob) < 2 or blob[0] != 0x1f or blob[1] != 0x8b:
        return None
    try:
        ts = zlib.decompress(blob, 16 + zlib.MAX_WBITS)
    except zlib.error:
        return None
    if not ts or ts[0] != 0x47:
        return None
    return ts


def _ptv_cache_get(key):
    with _ptv_seg_lock:
        return _ptv_seg_cache.get(key)


def _ptv_cache_store(key, body):
    with _ptv_seg_lock:
        if key not in _ptv_seg_cache:
            _ptv_seg_cache[key] = body
            _ptv_seg_keys.append(key)
        while len(_ptv_seg_keys) > _PTV_SEG_CACHE_MAX:
            _ptv_seg_cache.pop(_ptv_seg_keys.pop(0), None)


def _proxy_headers(origin):
    """Build the Origin/Referer pair the premiumtv CDN expects.

    `origin` arrives as the page URL the addon was invoked from, query string
    included. Sending that whole string in Origin makes the header syntactically
    invalid and the CDN answers 403 to every manifest — measured on the live CDN:
    the same URL returns 200 with no Origin at all, and 200 with Origin set to
    the bare site root, but 403 with Origin set to the full page URL. Origin must
    be scheme + host only.
    """
    parsed = urlparse(origin)
    root = f'{parsed.scheme}://{parsed.netloc}' if parsed.scheme and parsed.netloc else origin
    referer = origin if '?' in origin else origin.rstrip('/') + '/'
    return {'User-Agent': UA, 'Origin': root, 'Referer': referer}



class _EPlayerProxyHandler(BaseHTTPRequestHandler):
    """Local HTTP proxy that:
    - GET /m3u8/<channel_key>  → fetches live m3u8, rewrites key URIs to /key/...
    - GET /key/<channel_key>/<key_id> → computes auth headers, fetches real AES key
    """

    def do_GET(self):
        if self.path == '/health':
            body = b'dltv-proxy'
            self.send_response(200)
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        if self.path == '/version':
            body = _PROXY_ADDON_MTIME.encode()
            self.send_response(200)
            self.send_header('Content-Type', 'text/plain')
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        m = re.match(r'^/m3u8/([^/?]+)', self.path)
        if m:
            self._handle_m3u8(m.group(1))
            return
        m = re.match(r'^/stream/([^/?]+)', self.path)
        if m:
            self._handle_stream(m.group(1))
            return
        # New 3-component format: /key/{channel_key}/{orig_srv}/{key_id}
        m = re.match(r'^/key/([^/]+)/([^/]+)/(\d+)$', self.path)
        if m:
            self._handle_key(m.group(1), m.group(3), orig_srv_key=m.group(2))
            return
        # Legacy 2-component format: /key/{channel_key}/{key_id}
        m = re.match(r'^/key/([^/]+)/(\d+)$', self.path)
        if m:
            self._handle_key(m.group(1), m.group(2))
            return
        m = re.match(r'^/seg/(.+)', self.path)
        if m:
            self._handle_segment(m.group(1))
            return
        m = re.match(r'^/raw/([^/]+)/(.+)', self.path)
        if m:
            self._handle_raw(m.group(1), m.group(2))
            return
        m = re.match(r'^/ptv/([^/]+)/(.+)', self.path)
        if m:
            self._handle_premiumtv(m.group(1), m.group(2))
            return
        m = re.match(r'^/wide/([^/]+)/(.+)', self.path)
        if m:
            self._handle_wide(m.group(1), m.group(2))
            return
        m = re.match(r'^/lovecdn/([^/?]+)', self.path)
        if m:
            self._handle_lovecdn(unquote(m.group(1)))
            return
        m = re.match(r'^/lovecdn-ts/([^/?]+)', self.path)
        if m:
            self._handle_lovecdn_ts(unquote(m.group(1)))
            return
        m = re.match(r'^/lovecdn-seg/(.+)', self.path)
        if m:
            self._handle_lovecdn_seg(unquote(m.group(1)))
            return
        self.send_response(404)
        self.end_headers()

    def _handle_m3u8(self, channel_key):
        state = _get_channel_state(channel_key)
        if not state or not state.get('m3u8_url'):
            # Proxy runs in old process — fetch credentials on demand
            m = _PREMIUM_KEY_RX.match(channel_key)
            if m:
                cid = m.group(1)
                log(f'[EPlayerProxy] No state for {channel_key}, fetching credentials for id={cid}')
                state = _refresh_channel_creds(cid)
                if not state:
                    # Auth unavailable (NFS channel or ksohls page has no creds) — noauth fallback
                    log(f'[EPlayerProxy] Auth failed for {channel_key}, using noauth fallback')
                    noauth_url = resolve_stream_url(cid)
                    _set_channel_state(channel_key, 'noauth', 'noauth', noauth_url)
                    state = _get_channel_state(channel_key)
        if not state or not state.get('m3u8_url'):
            self.send_response(503)
            self.end_headers()
            return
        try:
            m3u8_hdrs = {
                'User-Agent': _AUTH_UA,
                'Referer': PLAYER_REFERER,
                'Authorization': f'Bearer {state["auth_token"]}',
                'X-Channel-Key': channel_key,
                'X-User-Agent': _AUTH_UA,
                'Cache-Control': 'no-cache',
                'Pragma': 'no-cache',
            }
            _m3u8_url = state['m3u8_url']
            for _m3u8_attempt in range(3):
                try:
                    _tout = 5 if _m3u8_attempt > 0 else 3
                    r = _get_session().get(_m3u8_url, headers=m3u8_hdrs, timeout=_tout)
                    with _stall_lock:
                        _m3u8_timeouts.pop(channel_key, None)  # reset on success
                    break
                except requests.exceptions.Timeout:
                    if _m3u8_attempt == 0:
                        log(f'[EPlayerProxy] m3u8 timeout for {channel_key}, retrying')
                        time.sleep(1)
                    elif _m3u8_attempt == 1:
                        # Count consecutive timeouts; give up gracefully after 5
                        with _stall_lock:
                            _tc = _m3u8_timeouts.get(channel_key, 0) + 1
                            _m3u8_timeouts[channel_key] = _tc
                        log(f'[EPlayerProxy] m3u8 timeout #{_tc} for {channel_key}')
                        if _tc >= 5:
                            log(f'[EPlayerProxy] {channel_key}: CDN unresponsive ({_tc} timeouts) — ending stream')
                            _mark_channel_failed(channel_key)
                            with _stall_lock:
                                _m3u8_timeouts.pop(channel_key, None)
                            self.send_response(200)
                            self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
                            self.send_header('Content-Length', str(len(_M3U8_ENDLIST)))
                            self.end_headers()
                            self.wfile.write(_M3U8_ENDLIST)
                            return
                        raise
                    else:
                        raise
                except Exception as _e:
                    log(f'[EPlayerProxy] m3u8 conn error (attempt {_m3u8_attempt+1}): {_e}')
                    if _m3u8_attempt == 0:
                        time.sleep(0.1)
                    elif _m3u8_attempt == 1:
                        # Connection error — try substituting a builtin CHEVY host if discovered one is down
                        _cur_host = re.match(r'https?://[^/]+', _m3u8_url)
                        _builtin_host = re.match(r'https?://[^/]+', _CHEVY_PROXY_BUILTIN)
                        if _cur_host and _builtin_host and _cur_host.group() != _builtin_host.group():
                            _fallback_url = _m3u8_url.replace(_cur_host.group(), _builtin_host.group(), 1)
                            log(f'[EPlayerProxy] m3u8 fallback to builtin: {_fallback_url[:80]}')
                            _m3u8_url = _fallback_url
                            try:
                                os.remove(_DISCOVERY_CACHE_FILE)
                            except Exception:
                                pass
                        else:
                            raise
                    else:
                        raise

            # On 403/404, re-auth and retry once (403 = token expired or wrong CDN server key)
            if r.status_code in (403, 404):
                log(f'[EPlayerProxy] m3u8 {r.status_code} for {channel_key}, re-fetching credentials')
                m = _PREMIUM_KEY_RX.match(channel_key)
                if m:
                    cid = m.group(1)
                    state = _refresh_channel_creds(cid)
                    if not state:
                        # Auth unavailable (NFS channel) — retry without auth header
                        log(f'[EPlayerProxy] re-auth failed for {channel_key}, retrying noauth')
                        noauth_url = resolve_stream_url(cid)
                        _set_channel_state(channel_key, 'noauth', 'noauth', noauth_url)
                        state = _get_channel_state(channel_key)
                    if state:
                        new_hdrs = dict(m3u8_hdrs)
                        at = state.get('auth_token', '')
                        if at and at != 'noauth':
                            new_hdrs['Authorization'] = f'Bearer {at}'
                        else:
                            new_hdrs.pop('Authorization', None)
                        try:
                            r = _get_session().get(state['m3u8_url'], headers=new_hdrs, timeout=3)
                            log(f'[EPlayerProxy] m3u8 after re-auth: status={r.status_code}')
                        except Exception as _reauth_e:
                            log(f'[EPlayerProxy] m3u8 re-auth fetch failed: {_reauth_e}')
                            self.send_response(200)
                            self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
                            self.send_header('Content-Length', str(len(_M3U8_ENDLIST)))
                            self.end_headers()
                            self.wfile.write(_M3U8_ENDLIST)
                            return
                    if r.status_code != 200:
                        log(f'[EPlayerProxy] {channel_key}: CDN {r.status_code} after re-auth — ending stream')
                        _mark_channel_failed(channel_key)
                        self.send_response(200)
                        self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
                        self.send_header('Content-Length', str(len(_M3U8_ENDLIST)))
                        self.end_headers()
                        self.wfile.write(_M3U8_ENDLIST)
                        return

            # On 502/503, retry once after a short delay
            if r.status_code in (502, 503):
                log(f'[EPlayerProxy] m3u8 {r.status_code} for {channel_key}, retrying')
                time.sleep(1)
                r = _get_session().get(state['m3u8_url'], headers=m3u8_hdrs, timeout=3)

            content = r.text
            if r.status_code == 200:
                # Finite playlist = channel offline — end gracefully (not 503, avoids restart loop)
                if '#EXT-X-ENDLIST' in content:
                    log(f'[EPlayerProxy] {channel_key}: offline playlist (EXT-X-ENDLIST) — ending stream')
                    _mark_channel_failed(channel_key)
                    self.send_response(200)
                    self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
                    self.send_header('Content-Length', str(len(_M3U8_ENDLIST)))
                    self.end_headers()
                    self.wfile.write(_M3U8_ENDLIST)
                    return
                # Strip image placeholder segments served by known image CDNs.
                # NOTE: tempfileb.aiquickdraw.com is a real video CDN that obfuscates segments as .png — keep those.
                _content_filt, _remaining, _all_seg_count = _apply_m3u8_filter(content)
                if _remaining == 0:
                    _all_segs_raw = [l.strip() for l in content.splitlines()
                                     if l.strip() and not l.strip().startswith('#')]
                    log(f'[EPlayerProxy] {channel_key}: all {_all_seg_count} segments are images — samples: {_all_segs_raw[:2]}')
                    # Wait 3s for CDN to produce real segments (transient state), then re-fetch
                    _proxy_abort.wait(timeout=3)
                    if _proxy_abort.is_set():
                        return
                    _png_reauth_ok = False
                    try:
                        _refetch = _get_session().get(state['m3u8_url'], headers=m3u8_hdrs, timeout=5)
                        if _refetch.status_code == 200 and '#EXTM3U' in _refetch.text:
                            _rf_segs = [l.strip() for l in _refetch.text.splitlines()
                                        if l.strip() and not l.strip().startswith('#')]
                            if any(not _is_placeholder(s) for s in _rf_segs):
                                log(f'[EPlayerProxy] {channel_key}: CDN recovered after 3s wait — continuing')
                                content = _refetch.text
                                _png_reauth_ok = True
                    except Exception:
                        pass
                    # Try re-auth with a fresh CDN URL if 3s wait didn't help
                    _png_cid_m = _PREMIUM_KEY_RX.match(channel_key)
                    if not _png_reauth_ok and _png_cid_m:
                        _png_cid = _png_cid_m.group(1)
                        log(f'[EPlayerProxy] {channel_key}: re-authing to get fresh CDN')
                        state = _refresh_channel_creds(_png_cid, max_attempts=1)
                        if state:
                            m3u8_hdrs['Authorization'] = f'Bearer {state["auth_token"]}'
                            try:
                                _pr = _get_session().get(state['m3u8_url'], headers=m3u8_hdrs, timeout=5)
                                if _pr.status_code == 200 and '#EXTM3U' in _pr.text:
                                    _pr_segs = [l.strip() for l in _pr.text.splitlines()
                                                if l.strip() and not l.strip().startswith('#')]
                                    _pr_video = [s for s in _pr_segs if not _is_placeholder(s)]
                                    if _pr_video:
                                        log(f'[EPlayerProxy] {channel_key}: re-auth got real video segments — continuing')
                                        content = _pr.text
                                        _png_reauth_ok = True
                                    else:
                                        log(f'[EPlayerProxy] {channel_key}: re-auth still all images — channel offline')
                            except Exception as _pe:
                                log(f'[EPlayerProxy] {channel_key}: re-auth fetch failed: {_pe}')
                    if not _png_reauth_ok:
                        log(f'[EPlayerProxy] {channel_key}: no video segments after filtering — ending stream')
                        _mark_channel_failed(channel_key)
                        self.send_response(200)
                        self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
                        self.send_header('Content-Length', str(len(_M3U8_ENDLIST)))
                        self.end_headers()
                        self.wfile.write(_M3U8_ENDLIST)
                        return
                    # Re-apply filter on fresh content
                    _content_filt, _remaining, _all_seg_count = _apply_m3u8_filter(content)
                if _content_filt is not None and _remaining < _all_seg_count:
                    log(f'[EPlayerProxy] {channel_key}: filtered image segments, {_remaining} video segs remain')
                    content = _content_filt
            seq_m = _SEQ_RX.search(content)
            seq = seq_m.group(1) if seq_m else '?'
            log(f'[EPlayerProxy] m3u8 fetched seq={seq} status={r.status_code}')

            # Stall detection: sequence unchanged for 20+ seconds → re-auth
            # Time-based (not count-based) to be immune to parallel request bursts
            _STALL_TIMEOUT = 20  # seconds without sequence advance = stall
            if r.status_code == 200 and seq != '?':
                _now = time.time()
                with _stall_lock:
                    stall = _m3u8_stall.get(channel_key, {'seq': None, 'first_seen': _now})
                    if seq != stall['seq']:
                        stall = {'seq': seq, 'first_seen': _now}
                    _m3u8_stall[channel_key] = stall
                if _now - stall['first_seen'] >= _STALL_TIMEOUT:
                    same_retries = stall.get('same_url_retries', 0)
                    _stall_age = int(_now - stall['first_seen'])
                    log(f'[EPlayerProxy] stall detected (seq={seq} frozen {_stall_age}s), re-auth (same_url_retries={same_retries})')
                    cm = _PREMIUM_KEY_RX.match(channel_key)
                    if cm:
                        cid = cm.group(1)
                        at, cs = _fetch_auth_credentials(cid)
                        if at and cs:
                            old_url = (state or {}).get('m3u8_url', '')
                            new_url = resolve_stream_url(cid)
                            _set_channel_state(channel_key, at, cs, new_url)
                            if new_url != old_url:
                                # New CDN endpoint — reset stall tracker
                                with _stall_lock:
                                    _m3u8_stall[channel_key] = {'seq': None, 'first_seen': time.time(), 'same_url_retries': 0}
                                log(f'[EPlayerProxy] stall: new CDN URL obtained')
                            else:
                                # Same URL after re-auth — wait for CDN to produce new segments
                                same_retries += 1
                                if same_retries >= 3:
                                    # CDN genuinely frozen after 3 attempts — end stream
                                    log(f'[EPlayerProxy] stall: CDN frozen after {same_retries} retries — ending stream')
                                    with _stall_lock:
                                        _m3u8_stall.pop(channel_key, None)
                                    _mark_channel_failed(channel_key)
                                    self.send_response(200)
                                    self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
                                    self.send_header('Content-Length', str(len(_M3U8_ENDLIST)))
                                    self.end_headers()
                                    self.wfile.write(_M3U8_ENDLIST)
                                    return
                                # Not yet giving up — wait 6s then re-fetch CDN playlist
                                log(f'[EPlayerProxy] stall: same URL (retry {same_retries}/2), waiting 6s for CDN')
                                with _stall_lock:
                                    _m3u8_stall[channel_key] = {'seq': seq, 'first_seen': time.time(), 'same_url_retries': same_retries}
                                _proxy_abort.wait(timeout=6)
                                if _proxy_abort.is_set():
                                    return
                                try:
                                    _r2 = _get_session().get(state['m3u8_url'], headers=m3u8_hdrs, timeout=5)
                                    if _r2.status_code == 200:
                                        content = _r2.text
                                        log(f'[EPlayerProxy] stall: CDN re-fetched after wait')
                                except Exception:
                                    pass

            port = _actual_proxy_port or M3U8_PROXY_PORT

            def _rewrite_key(mo):
                uri = mo.group(1)
                # Capture original srv_key (the component before key_id) to preserve it
                # in the proxy path. Prevents mismatch when m3u8 URL srv_key ≠ key URI srv_key
                # (e.g. viewembed channels: m3u8 at /proxy/nfs/eurosport2fr/ but key at /key/eurosport2fr/).
                km = re.search(r'/key/([^/]+)/(\d+)', uri)
                if km:
                    orig_srv = km.group(1)
                    key_id = km.group(2)
                    return f'URI="http://127.0.0.1:{port}/key/{channel_key}/{orig_srv}/{key_id}"'
                return mo.group(0)

            content = re.sub(r'URI="([^"]+)"', _rewrite_key, content)

            # Rewrite segment URLs so Kodi fetches them via the proxy
            # (segments need Origin/Referer headers that Kodi doesn't send)
            # Also handle relative segment URLs using m3u8_url as base.
            # Two-pass safe dedup: remove CDN segments already sent (sliding window replay fix).
            # When no new segments (CDN hasn't advanced), serve an empty live playlist to avoid
            # a backward MEDIA-SEQUENCE jump that would confuse the player.
            _m3u8_base = state['m3u8_url'].split('?')[0].rsplit('/', 1)[0] + '/'
            # Pass 1: collect absolute CDN URLs and count new ones (not yet sent)
            _pl_lines = content.splitlines()
            _pl_segs = []
            for _line in _pl_lines:
                _s = _line.strip()
                if _s and not _s.startswith('#'):
                    _pl_segs.append(_s if _s.startswith('http') else urljoin(_m3u8_base, _s))

            # Pre-check: if ALL CDN segments are already downloaded, wait 2s and re-fetch CDN once.
            # This reduces latency between CDN advancing and player receiving new content,
            # preventing buffer starvation from thin dedup output.
            with _stall_lock:
                _pre_sent = _sent_seg_urls.get(channel_key, set())
                _all_pre_sent = bool(_pl_segs) and all(u in _pre_sent for u in _pl_segs)
            if _all_pre_sent:
                _proxy_abort.wait(timeout=2)
                if _proxy_abort.is_set():
                    return
                try:
                    _rp = _get_session().get(state['m3u8_url'], headers=m3u8_hdrs, timeout=3)
                    if _rp.status_code == 200:
                        _cp = _rp.text
                        _cfp, _, _ = _apply_m3u8_filter(_cp)
                        if _cfp is not None:
                            _cp = _cfp
                        content = _cp
                        _pl_lines = content.splitlines()
                        _pl_segs = [
                            _s if _s.startswith('http') else urljoin(_m3u8_base, _s)
                            for _l in _pl_lines for _s in [_l.strip()]
                            if _s and not _s.startswith('#')
                        ]
                except Exception:
                    pass

            with _stall_lock:
                _already_sent = _sent_seg_urls.get(channel_key, set())
                _new_count = sum(1 for u in _pl_segs if u not in _already_sent)
                _apply_dedup = _new_count >= 1
                _cdnseq_m = _SEQ_RX.search(content)
                _cdn_media_seq = int(_cdnseq_m.group(1)) if _cdnseq_m else 0
                if _apply_dedup:
                    # Pass 2: build deduplicated playlist.
                    # Segments are tracked at DOWNLOAD-TIME (in _handle_segment), not here.
                    # _already_sent = segments the player has ACTUALLY downloaded.
                    # Not-yet-downloaded segments from previous playlists appear as "new" here,
                    # giving the player a naturally thicker buffer without re-serving old content.
                    seg_lines = []
                    _dedup_removed_start = 0
                    _found_first_kept = False
                    _prev_removed = False
                    _seg_idx = 0
                    for _line in _pl_lines:
                        _s = _line.strip()
                        if _s and not _s.startswith('#'):
                            abs_seg = _pl_segs[_seg_idx]
                            _seg_idx += 1
                            if abs_seg in _already_sent:
                                # Already downloaded — remove from playlist
                                if seg_lines and seg_lines[-1].strip().startswith('#EXTINF'):
                                    seg_lines.pop()
                                if not _found_first_kept:
                                    _dedup_removed_start += 1
                                _prev_removed = True
                                log(f'[EPlayerProxy] dedup skip {channel_key} {abs_seg[-40:]}')
                            else:
                                # Not yet downloaded — keep in playlist
                                if _prev_removed and _found_first_kept:
                                    seg_lines.append('#EXT-X-DISCONTINUITY')
                                _found_first_kept = True
                                _prev_removed = False
                                # Map URL→channel so /seg/ handler can track download completion
                                _seg_url_to_channel[abs_seg] = channel_key
                                seg_lines.append(f'http://127.0.0.1:{port}/seg/{quote_plus(abs_seg)}')
                        else:
                            seg_lines.append(_line)
                    _adjusted_seq = _cdn_media_seq + _dedup_removed_start
                    # Enforce monotonically non-decreasing MEDIA-SEQUENCE
                    _prev_out_seq = _last_media_seq_out.get(channel_key, 0)
                    _final_media_seq = max(_adjusted_seq, _prev_out_seq)
                    _last_media_seq_out[channel_key] = _final_media_seq
                    content = '\n'.join(seg_lines)
                    content = _SEQ_RX.sub(f'#EXT-X-MEDIA-SEQUENCE:{_final_media_seq}', content)
                else:
                    # No new segments: all CDN segments already downloaded by the player.
                    # Serving them again would cause duplicate-segment freeze in ffmpegdirect.
                    # Instead, serve a valid empty live playlist — the player waits TARGET-DURATION
                    # and re-polls. Safe with download-time tracking (no parallel-thread race).
                    _tgt_m = re.search(r'#EXT-X-TARGETDURATION:(\d+)', content)
                    _tgt_dur = _tgt_m.group(1) if _tgt_m else '5'
                    _prev_out_seq = _last_media_seq_out.get(channel_key, _cdn_media_seq)
                    content = (
                        '#EXTM3U\n'
                        '#EXT-X-VERSION:3\n'
                        f'#EXT-X-TARGETDURATION:{_tgt_dur}\n'
                        f'#EXT-X-MEDIA-SEQUENCE:{_prev_out_seq}\n'
                    )
                    log(f'[EPlayerProxy] dedup: all segs sent for {channel_key}, empty live pl seq={_prev_out_seq}')

            # HLS polling throttle: if seq unchanged since last response, wait 2s
            # so Kodi doesn't hammer the CDN before it updates its playlist.
            with _stall_lock:
                _prev_seq = _last_sent_seq.get(channel_key)
                _last_sent_seq[channel_key] = seq
            if seq != '?' and seq == _prev_seq:
                _proxy_abort.wait(timeout=2)
                if _proxy_abort.is_set():
                    return

            body = content.encode('utf-8')
            self.send_response(200)
            self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        except Exception as e:
            log(f'[EPlayerProxy] m3u8 error for {channel_key}: {e}')
            self.send_response(502)
            self.end_headers()

    def _handle_stream(self, channel_key):
        """Serve HLS as a continuous MPEG-TS byte stream.
        Acts as an internal HLS client (URL-based segment tracking like hls.js):
        each unique CDN segment URL is downloaded and forwarded exactly once — no looping."""
        state = _get_channel_state(channel_key)
        if not state or not state.get('m3u8_url'):
            m = _PREMIUM_KEY_RX.match(channel_key)
            if m:
                cid = m.group(1)
                state = _refresh_channel_creds(cid)
        if not state or not state.get('m3u8_url'):
            self.send_response(503)
            self.end_headers()
            return

        log(f'[StreamProxy] {channel_key}: TS stream started')
        try:
            self.send_response(200)
            self.send_header('Content-Type', 'video/MP2T')
            self.end_headers()
        except Exception as e:
            log(f'[StreamProxy] {channel_key}: header error: {e}')
            return

        seen_seqs = set()   # dedup by sequence number — blocks URL-rotated same-content
        seen_urls = set()   # dedup by URL — blocks seq-renumbered same-content
        key_cache = {}
        _STALL_TIMEOUT = 12
        _stall_wait = _STALL_TIMEOUT   # reduced after URL switch to catch fast CDN propagation
        _segs_since_stall = 3          # tracks stability; <3 = keep reduced timeout
        _last_content_time = time.time()   # last time content was queued successfully
        _stall_retries = 0
        _stall_epoch_start = 0.0       # when current continuous stall epoch began (0 = not stalling)
        _aes_fail_streak = 0           # consecutive AES decrypt failures (key rotation detector)
        _STALL_EPOCH_MAX = 75.0        # give up after 75s of continuous stalling

        # Proactive background re-auth: starts at STALL_TIMEOUT/2 so credentials
        # are ready when the stall fires, avoiding a blocking 5-7s delay during playback.
        _reauth_event = threading.Event()
        _reauth_cache = [None]   # [(at, cs, new_url)] or [None]
        _reauth_started_at = [0.0]

        def _bg_reauth():
            cm = _PREMIUM_KEY_RX.match(channel_key)
            if not cm:
                _reauth_event.set()
                return
            try:
                cid = cm.group(1)
                at, cs = _fetch_auth_credentials(cid)
                if at and cs:
                    nu = resolve_stream_url(cid)
                    _reauth_cache[0] = (at, cs, nu)
            except Exception:
                pass
            _reauth_event.set()

        # Segment buffer: absorbs CDN delivery jitter (9-18s gaps between bursts)
        import queue as _q
        _seg_q = _q.Queue(maxsize=10)  # ~55s buffer at 5.5s/seg
        _client_gone = threading.Event()

        # Null TS packet (PID 0x1FFF): keeps Kodi's HTTP connection alive during CDN gaps
        _NULL_PKT = bytes([0x47, 0x1F, 0xFF, 0x10]) + bytes(184)

        # Pre-buffer: emit null packets until Kodi's buffer is deep enough.
        # Wait at least 6s (Kodi needs time to negotiate), and up to 12s if the
        # queue has fewer than 3 segments (so Kodi starts with ≥19s of buffer).
        _PRE_BUFFER_SECS = 6.0
        _PRE_BUFFER_MAX = 12.0
        _stream_start = time.time()

        def _sender():
            """Sender thread.
            Phase 1 — Pre-buffer: emit null packets until queue has ≥3 segments,
              giving the fetcher time to accumulate a head-start.
            Phase 2 — Throttled: send segments at 1× real-time pace. Between
              segments the sender waits seg_dur seconds (emitting null packets),
              which lets the fetcher run ahead and keep the queue filled.
              CDN gaps of up to queue_depth × seg_dur seconds are then covered
              by real segments from the queue rather than null-packet freezes.
            """
            _bps = 250000   # default ~2 Mbps; updated from real segments
            _BURST_INTERVAL = 0.02   # 50 Hz null burst rate

            # Phase 1: pre-buffer — null packets only, no real content.
            while (time.time() - _stream_start < _PRE_BUFFER_SECS
                   or (_seg_q.qsize() < 3 and time.time() - _stream_start < _PRE_BUFFER_MAX)):
                if _client_gone.is_set() or _proxy_abort.is_set():
                    return
                try:
                    self.wfile.write(_NULL_PKT)
                    self.wfile.flush()
                except (BrokenPipeError, OSError, ConnectionResetError):
                    log(f'[StreamProxy] {channel_key}: client disconnected (pre-buffer)')
                    _client_gone.set()
                    return
                time.sleep(0.04)

            # Phase 2: throttled send loop.
            # _pace_clock = real-time moment when next segment may be sent.
            _pace_clock = None
            while not _client_gone.is_set() and not _proxy_abort.is_set():

                # Pace wait: hold for seg_dur seconds between segments so the
                # fetcher can get ahead and fill the queue.
                # Send null packets during the wait to keep Kodi's connection alive.
                if _pace_clock is not None:
                    while not _client_gone.is_set() and not _proxy_abort.is_set():
                        remaining = _pace_clock - time.time()
                        if remaining <= 0:
                            break
                        time.sleep(min(remaining, _BURST_INTERVAL))
                        n = max(1, int(_bps * _BURST_INTERVAL / 188))
                        try:
                            self.wfile.write(_NULL_PKT * n)
                            self.wfile.flush()
                        except (BrokenPipeError, OSError, ConnectionResetError):
                            _client_gone.set()
                            break

                if _client_gone.is_set() or _proxy_abort.is_set():
                    break

                # Get next segment (may block further if CDN gap exceeds queue depth)
                try:
                    item = _seg_q.get(timeout=_BURST_INTERVAL)
                except _q.Empty:
                    n = max(1, int(_bps * _BURST_INTERVAL / 188))
                    try:
                        self.wfile.write(_NULL_PKT * n)
                        self.wfile.flush()
                    except (BrokenPipeError, OSError, ConnectionResetError):
                        _client_gone.set()
                    continue

                if item is None:
                    _seg_q.task_done()
                    break

                seg_body, seg_dur = item
                _bps = max(12500, len(seg_body) / max(seg_dur, 0.1))

                try:
                    self.wfile.write(seg_body)
                    self.wfile.flush()
                except (BrokenPipeError, OSError, ConnectionResetError):
                    log(f'[StreamProxy] {channel_key}: client disconnected')
                    _client_gone.set()
                    _seg_q.task_done()
                    return

                # Advance pace clock by seg_dur + 0.3s.
                # The 0.3s delta lets the fetcher run slightly ahead, building a
                # small queue buffer to absorb CDN delivery jitter.
                # Kept low (300ms) to avoid visible PCR drift in Kodi.
                # If we fell behind (CDN gap), reset to now (no catch-up rush).
                now = time.time()
                _pace_clock = max(now, _pace_clock or now) + seg_dur + 0.5

                _seg_q.task_done()

        _sender_t = threading.Thread(target=_sender, daemon=True)
        _sender_t.start()
        seg_proxy_url = addon.getSetting('seg_proxy').strip()
        seg_proxies = {'http': seg_proxy_url, 'https': seg_proxy_url} if seg_proxy_url else None
        seg_hdrs = dict(_SEG_HEADERS)
        _state_ref = None
        try:
            while not _proxy_abort.is_set() and not _client_gone.is_set():
                state = _get_channel_state(channel_key)
                if not state:
                    break

                # Direct-HLS channels carry their own referer in state (premiumtv host).
                if state.get('player_referer') and state.get('player_referer') != _state_ref:
                    _state_ref = state['player_referer']
                    seg_hdrs = dict(_SEG_HEADERS)
                    seg_hdrs['Referer'] = _state_ref + '/'
                    seg_hdrs['Origin'] = _state_ref

                m3u8_hdrs = {
                    'User-Agent': _AUTH_UA,
                    'Referer': state.get('player_referer') or PLAYER_REFERER,
                    'Authorization': f'Bearer {state["auth_token"]}',
                    'X-Channel-Key': channel_key,
                    'X-User-Agent': _AUTH_UA,
                    'Cache-Control': 'no-cache',
                    'Pragma': 'no-cache',
                }

                # Fetch CDN m3u8
                content = None
                try:
                    r = _get_session().get(state['m3u8_url'], headers=m3u8_hdrs, timeout=5)
                    if r.status_code == 200:
                        content = r.text
                    elif r.status_code in (403, 404):
                        log(f'[StreamProxy] m3u8 {r.status_code}, re-authing')
                        cm = _PREMIUM_KEY_RX.match(channel_key)
                        if cm:
                            _refresh_channel_creds(cm.group(1))
                        _proxy_abort.wait(timeout=1)
                        continue
                    elif r.status_code in (502, 503):
                        _proxy_abort.wait(timeout=2)
                        continue
                except Exception as e:
                    log(f'[StreamProxy] m3u8 fetch error: {e}')
                    if _stall_epoch_start == 0.0:
                        _stall_epoch_start = time.time()
                    elif time.time() - _stall_epoch_start >= _STALL_EPOCH_MAX:
                        log(f'[StreamProxy] {channel_key}: CDN unreachable >{int(_STALL_EPOCH_MAX)}s — ending stream')
                        _mark_channel_failed(channel_key)
                        break
                    _proxy_abort.wait(timeout=2)
                    continue

                if not content:
                    _proxy_abort.wait(timeout=2)
                    continue

                if '#EXT-X-ENDLIST' in content:
                    log(f'[StreamProxy] {channel_key}: EXT-X-ENDLIST — ending stream')
                    _mark_channel_failed(channel_key)
                    break

                # Filter placeholder image segments
                filtered, remaining, total = _apply_m3u8_filter(content)
                if remaining == 0:
                    log(f'[StreamProxy] {channel_key}: all {total} segs are placeholders, waiting')
                    _proxy_abort.wait(timeout=3)
                    _ph_now = time.time()
                    _ph_gap = _ph_now - _last_content_time
                    if _ph_gap >= _stall_wait and _PREMIUM_KEY_RX.match(channel_key):
                        if _stall_epoch_start == 0.0:
                            _stall_epoch_start = _ph_now
                        _ph_stall_total = _ph_now - _stall_epoch_start
                        log(f'[StreamProxy] {channel_key}: placeholder stall {int(_ph_gap)}s epoch={int(_ph_stall_total)}s')
                        if _ph_stall_total >= _STALL_EPOCH_MAX:
                            log(f'[StreamProxy] {channel_key}: placeholder frozen >{int(_STALL_EPOCH_MAX)}s — ending stream')
                            _mark_channel_failed(channel_key)
                            break
                        if _ph_now - _reauth_started_at[0] > _stall_wait:
                            _reauth_started_at[0] = _ph_now
                            _reauth_event.clear()
                            _reauth_cache[0] = None
                            threading.Thread(target=_bg_reauth, daemon=True).start()
                        _reauth_event.wait(timeout=8)
                        result = _reauth_cache[0]
                        _reauth_cache[0] = None
                        if result:
                            at, cs, new_url = result
                            _set_channel_state(channel_key, at, cs, new_url)
                            _last_content_time = time.time()
                    continue
                if filtered:
                    content = filtered

                tgt_m = re.search(r'#EXT-X-TARGETDURATION:(\d+)', content)
                tgt_dur = float(tgt_m.group(1)) if tgt_m else 6.0

                # Parse AES-128 key info
                current_key_id = None
                current_key_ns = None   # namespace from key URI (e.g. 'premium773', not server_key)
                current_iv = None
                seq_m = _SEQ_RX.search(content)
                base_seq = int(seq_m.group(1)) if seq_m else 0
                for _line in content.splitlines():
                    if _line.strip().startswith('#EXT-X-KEY:'):
                        _uri_m = re.search(r'URI="([^"]+)"', _line)
                        _iv_m = re.search(r'IV=0x([0-9a-fA-F]+)', _line)
                        if _uri_m:
                            _km = re.search(r'/key/([^/]+)/(\d+)', _uri_m.group(1))
                            if _km:
                                current_key_ns = _km.group(1)
                                current_key_id = _km.group(2)
                        if _iv_m:
                            current_iv = bytes.fromhex(_iv_m.group(1).zfill(32))
                        break

                # Parse segment URLs and per-segment EXTINF durations
                m3u8_base = state['m3u8_url'].split('?')[0].rsplit('/', 1)[0] + '/'
                segs = []
                seg_dur_map = {}
                _last_inf = tgt_dur
                for _sl in content.splitlines():
                    _sl = _sl.strip()
                    if _sl.startswith('#EXTINF:'):
                        try:
                            _last_inf = float(_sl[8:].split(',')[0])
                        except Exception:
                            _last_inf = tgt_dur
                    elif _sl and not _sl.startswith('#'):
                        _su = _sl if _sl.startswith('http') else urljoin(m3u8_base, _sl)
                        segs.append(_su)
                        seg_dur_map[_su] = _last_inf
                        _last_inf = tgt_dur

                # Stall detection: trigger only if no content queued for _STALL_TIMEOUT seconds.
                seq_str = str(base_seq)
                _now = time.time()
                _gap = _now - _last_content_time

                # Proactive re-auth: start as soon as CDN is 1.5× a segment overdue,
                # so credentials are ready when the stall fires (avoids blocking buffer drain).
                if (_gap >= max(_last_inf * 1.5, _stall_wait * 0.3)
                        and _PREMIUM_KEY_RX.match(channel_key)
                        and _now - _reauth_started_at[0] > _stall_wait):
                    _reauth_started_at[0] = _now
                    _reauth_event.clear()
                    _reauth_cache[0] = None
                    threading.Thread(target=_bg_reauth, daemon=True).start()

                if _gap >= _stall_wait:
                    # Track total continuous stall duration; give up after _STALL_EPOCH_MAX seconds.
                    if _stall_epoch_start == 0.0:
                        _stall_epoch_start = time.time()
                    _stall_total = time.time() - _stall_epoch_start
                    log(f'[StreamProxy] stall {int(_gap)}s seq={seq_str} retry={_stall_retries} epoch={int(_stall_total)}s')
                    if _stall_total >= _STALL_EPOCH_MAX:
                        log(f'[StreamProxy] {channel_key}: CDN frozen >{int(_STALL_EPOCH_MAX)}s — ending stream')
                        _mark_channel_failed(channel_key)
                        break
                    # Wait for background re-auth (should be nearly done after STALL_TIMEOUT/2 head-start)
                    _reauth_event.wait(timeout=8)
                    result = _reauth_cache[0]
                    _reauth_cache[0] = None
                    if result:
                        at, cs, new_url = result
                        old_url = state.get('m3u8_url', '')
                        _set_channel_state(channel_key, at, cs, new_url)
                        if new_url != old_url:
                            _last_content_time = time.time()
                            _stall_retries = 0
                            # CDN may take 5-15s to propagate the new URL.
                            # Reduce next stall threshold so we retry sooner instead of waiting full 12s.
                            _stall_wait = 7.0
                            _segs_since_stall = 0   # need 3 stable segs before restoring 12s timeout
                            _reauth_event.clear()
                            _reauth_cache[0] = None
                            _reauth_started_at[0] = time.time()
                            threading.Thread(target=_bg_reauth, daemon=True).start()
                            continue   # re-auth OK → fetch new m3u8 immediately
                        else:
                            _stall_retries += 1
                            _stall_wait = 7.0
                            _segs_since_stall = 0
                            _last_content_time = time.time()
                            # Don't block for a second reauth — CDN may already have
                            # the next seg ready. Start bg-reauth for next cycle and
                            # immediately re-poll the M3U8.
                            _reauth_event.clear()
                            _reauth_cache[0] = None
                            _reauth_started_at[0] = time.time()
                            threading.Thread(target=_bg_reauth, daemon=True).start()
                            continue
                    # No reauth result yet.
                    # For non-premium channels (e.g. viewembed CHEVY like eurosport2fr),
                    # there is no re-auth mechanism — reset the stall timer so the loop
                    # can process new CDN segments instead of being stuck in this handler.
                    # The stall epoch (_stall_epoch_start) is NOT reset here, so if the
                    # CDN truly stops delivering content, _stall_total eventually reaches
                    # _STALL_EPOCH_MAX and ends the stream.
                    if not _PREMIUM_KEY_RX.match(channel_key):
                        _last_content_time = time.time()
                    continue

                # Dual dedup: skip if seq seen (URL rotation) OR url seen (seq renumbering)
                new_segs = [(i, u) for i, u in enumerate(segs)
                            if (base_seq + i) not in seen_seqs and u not in seen_urls]
                if not new_segs:
                    _proxy_abort.wait(timeout=tgt_dur / 2)
                    continue

                _stall_retries = 0
                log(f'[StreamProxy] {channel_key}: seq={seq_str} {len(new_segs)} new seg(s)')

                # Download and stream each new segment
                for seg_idx, seg_url in new_segs:
                    if _proxy_abort.is_set():
                        return
                    seg_seq = base_seq + seg_idx

                    # IV: explicit or sequence-derived
                    iv = current_iv
                    if current_key_id and iv is None:
                        iv = seg_seq.to_bytes(16, 'big')

                    # Download with optional proxy fallback
                    # Only retry with proxy if one is configured; avoids double-wait on CDN timeout.
                    body = None
                    _max_seg_attempts = 2 if seg_proxies else 1
                    for attempt in range(_max_seg_attempts):
                        cur_proxies = seg_proxies if attempt == 1 else None
                        try:
                            sr = _get_session().get(seg_url, headers=seg_hdrs, timeout=(3, 5),
                                                   proxies=cur_proxies)
                            ct = sr.headers.get('Content-Type', '')
                            if sr.status_code == 200 and 'html' not in ct.lower():
                                body = sr.content
                                break
                            elif sr.status_code == 404:
                                seen_seqs.add(seg_seq)
                                seen_urls.add(seg_url)
                                log(f'[StreamProxy] seg 404 (expired): {seg_url[-50:]}')
                                break
                            elif sr.status_code == 429 and attempt == 0 and seg_proxies:
                                continue
                            else:
                                log(f'[StreamProxy] seg {sr.status_code}: {seg_url[-50:]}')
                                break
                        except Exception as e:
                            log(f'[StreamProxy] seg error: {e}')
                        if attempt == 0:
                            time.sleep(0.1)

                    if body is None:
                        continue

                    log(f'[StreamProxy] seg fetched len={len(body)} first8={body[:8].hex()} url={seg_url[-60:]}')

                    # Detect CHEVY plain-TS-with-header mode: segments are NOT AES encrypted,
                    # CHEVY prepends a variable-length header (fake PNG) before the actual TS data.
                    # Use 3 consecutive sync bytes; scan full body (PNG wrappers can exceed 1024B).
                    _chevy_offset = None
                    if body and body[0] != 0x47 and len(body) > 564:
                        for _off in range(len(body) - 564):
                            if (body[_off] == 0x47 and body[_off + 188] == 0x47
                                    and body[_off + 376] == 0x47):
                                _chevy_offset = _off
                                break
                    # Validate plain-TS result:
                    # 1. At least 300KB must remain after the offset.
                    # 2. First 2 TS packets must have no transport_error_indicator and no scrambling.
                    #    False positives in AES ciphertext almost always have error bits or scrambling
                    #    set in the random byte that lands at the TS flags position.
                    _MIN_PLAIN_TS = 300 * 1024
                    _plain_ts_valid = (
                        _chevy_offset is not None and _chevy_offset > 0
                        and len(body) - _chevy_offset >= _MIN_PLAIN_TS
                        # packet 1: no error (bit7 of byte 1), not scrambled (bits7-6 of byte 3)
                        and body[_chevy_offset + 1] & 0x80 == 0
                        and body[_chevy_offset + 3] & 0xC0 == 0
                        # packet 2: same checks
                        and body[_chevy_offset + 189] & 0x80 == 0
                        and body[_chevy_offset + 191] & 0xC0 == 0
                    )
                    if _plain_ts_valid:
                        log(f'[StreamProxy] CHEVY plain-TS header detected, skip {_chevy_offset}B')
                        body = body[_chevy_offset:]
                    elif current_key_id and iv:
                        # Fallback: try AES-128 decryption
                        key = _fetch_stream_key(current_key_id, channel_key, state, key_cache,
                                                key_ns=current_key_ns)
                        if key:
                            log(f'[StreamProxy] AES decrypt: len={len(body)} len%16={len(body)%16} iv={iv.hex()} key_ns={current_key_ns}')
                            _raw = body
                            body = _aes128_cbc_decrypt(body, key, iv)

                            def _find_ts_off(buf):
                                """Scan buf for 3 consecutive valid TS sync bytes.
                                Returns offset or None. Validates error/scrambling flags."""
                                if not buf or len(buf) <= 564:
                                    return None
                                for _o in range(len(buf) - 564):
                                    if (buf[_o] == 0x47
                                            and buf[_o + 188] == 0x47
                                            and buf[_o + 376] == 0x47
                                            and buf[_o + 1] & 0x80 == 0      # no transport error p1
                                            and buf[_o + 3] & 0xC0 == 0      # not scrambled p1
                                            and buf[_o + 189] & 0x80 == 0    # no transport error p2
                                            and buf[_o + 191] & 0xC0 == 0):  # not scrambled p2
                                        return _o
                                return None

                            # CHEVY format: [fake header N bytes] + [real TS].
                            # Try AES+header scan on first decrypt (cached key) BEFORE
                            # doing any stale-key re-fetch.  This avoids a wasteful
                            # extra HTTP request per segment and — critically — avoids
                            # getting a different random key from CHEVY when the
                            # reCAPTCHA whitelist has expired.
                            _dec_off = _find_ts_off(body) if body and body[0] != 0x47 else None
                            if _dec_off is not None and _dec_off > 0:
                                log(f'[StreamProxy] AES+header: strip {_dec_off}B after decrypt, seq={seg_seq}')
                                body = body[_dec_off:]
                            elif body and body[0] != 0x47:
                                # Scan also failed → key might be truly stale → re-fetch once
                                if current_key_id in key_cache:
                                    log(f'[StreamProxy] stale key {current_key_id}, re-fetching (cache-bust)')
                                    del key_cache[current_key_id]
                                    key2 = _fetch_stream_key(current_key_id, channel_key, state, key_cache,
                                                             force_refresh=True, key_ns=current_key_ns)
                                    if key2 and key2 != key:
                                        body = _aes128_cbc_decrypt(_raw, key2, iv)
                                        _dec_off2 = _find_ts_off(body) if body and body[0] != 0x47 else None
                                        if _dec_off2 is not None and _dec_off2 > 0:
                                            log(f'[StreamProxy] AES+header (retry): strip {_dec_off2}B, seq={seg_seq}')
                                            body = body[_dec_off2:]
                            if body and body[0] != 0x47:
                                seen_seqs.add(seg_seq)
                                seen_urls.add(seg_url)
                                _aes_fail_streak += 1
                                log(f'[StreamProxy] AES mismatch, drop seq={seg_seq} (streak={_aes_fail_streak}) first32={body[:32].hex()}')
                                if _aes_fail_streak >= 3:
                                    log(f'[StreamProxy] AES key rotated — forcing stall (streak={_aes_fail_streak})')
                                    _last_content_time = time.time() - _stall_wait
                                else:
                                    # Isolated bad segment — reset stall timer so segment
                                    # download/decrypt time doesn't accidentally trigger stall
                                    _last_content_time = time.time()
                                continue

                    seen_seqs.add(seg_seq)
                    seen_urls.add(seg_url)
                    seg_dur = seg_dur_map.get(seg_url, tgt_dur)

                    # Enqueue real segment with duration (sender uses dur for bitrate estimate)
                    while not _client_gone.is_set() and not _proxy_abort.is_set():
                        try:
                            _seg_q.put((body, seg_dur), timeout=0.5)
                            break
                        except _q.Full:
                            pass
                    if _client_gone.is_set():
                        return
                    # Log after put so q reflects actual queue depth (including this segment)
                    log(f'[StreamProxy] seg ok {len(body)}B dur={seg_dur:.1f}s first={body[:4].hex()} q={_seg_q.qsize()}')
                    # Reset stall timer only on successful delivery to queue
                    _last_content_time = time.time()
                    _stall_retries = 0
                    _stall_epoch_start = 0.0   # content flowing — reset stall epoch
                    _aes_fail_streak = 0
                    # Restore normal timeout only after 3 consecutive segs (CDN stable again)
                    if _stall_wait < _STALL_TIMEOUT:
                        _segs_since_stall += 1
                        if _segs_since_stall >= 3:
                            _stall_wait = _STALL_TIMEOUT

                # Brief pause before next CDN poll
                _proxy_abort.wait(timeout=0.5)
        finally:
            # H3: ensure sender always receives sentinel to unblock it on any exit path
            log(f'[StreamProxy] {channel_key}: stream ended')
            try:
                _seg_q.put(None, timeout=2)
            except Exception:
                pass
        _sender_t.join(timeout=10)

    def _handle_key(self, channel_key, key_id, orig_srv_key=None):
        state = _get_channel_state(channel_key)
        if not state or not state.get('m3u8_url'):
            # Proxy runs in old process — fetch credentials on demand
            m = _PREMIUM_KEY_RX.match(channel_key)
            if m:
                cid = m.group(1)
                state = _refresh_channel_creds(cid)
                if not state:
                    log(f'[EPlayerProxy] Auth failed for key {channel_key}, using noauth fallback')
                    noauth_url = resolve_stream_url(cid)
                    _set_channel_state(channel_key, 'noauth', 'noauth', noauth_url)
                    state = _get_channel_state(channel_key)
        if not state or not state.get('m3u8_url'):
            self.send_response(503)
            self.end_headers()
            return
        try:
            # Derive key host from m3u8 URL
            # m3u8 URL pattern: https://{host}/proxy/{server_key}/{channel_key}/mono.css
            # Key URL pattern:  https://{host}/key/{server_key}/{key_id}
            m3u8_url = state.get('m3u8_url', '')
            _key_host_m = re.match(r'(https?://[^/]+)', m3u8_url)
            key_host = _key_host_m.group(1) if _key_host_m else CHEVY_LOOKUP
            if orig_srv_key:
                # Use the srv_key from the original m3u8 key URI (most authoritative).
                # Avoids mismatch when m3u8 path srv_key ≠ key URI srv_key
                # (e.g. /proxy/nfs/eurosport2fr/ but key URI /key/eurosport2fr/{id}).
                _srv_key = orig_srv_key
            else:
                _srv_key_m = re.search(r'/proxy/([^/]+)/', m3u8_url)
                _srv_key = _srv_key_m.group(1) if _srv_key_m else channel_key
            key_url = f'{key_host}/key/{_srv_key}/{key_id}'
            channel_salt = state.get('channel_salt') or ''
            _key_referer = state.get('player_referer') or m3u8_url or PLAYER_REFERER
            hdrs = {'User-Agent': _AUTH_UA, 'Referer': _key_referer}
            if channel_salt and channel_salt != 'noauth':
                ts = int(time.time())
                fp = _compute_fingerprint()
                nonce = _compute_pow_nonce(channel_key, channel_salt, key_id, ts)
                auth_sig = _compute_auth_sig(channel_key, channel_salt, key_id, ts, fp)
                hdrs['Authorization'] = f'Bearer {state["auth_token"]}'
                hdrs['X-Key-Timestamp'] = str(ts)
                hdrs['X-Key-Nonce'] = str(nonce)
                hdrs['X-Key-Path'] = auth_sig
                hdrs['X-Fingerprint'] = fp
            r = _get_session().get(key_url, headers=hdrs, timeout=3)
            body = r.content
            log(f'[EPlayerProxy] key {key_id}: {len(body)}B status={r.status_code} host={key_host}')
            self.send_response(200)
            self.send_header('Content-Type', 'application/octet-stream')
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        except Exception as e:
            log(f'[EPlayerProxy] key error for {channel_key}/{key_id}: {e}')
            self.send_response(502)
            self.end_headers()

    def _handle_raw(self, encoded_origin, encoded_url):
        """Proxy a URL with a specific Origin/Referer.
        - m3u8/playlist: rewrites relative segment URLs to absolute and routes through /raw/
        - segments (.ts): buffered and forwarded (stream=False for retry on conn errors)
        """
        try:
            origin = unquote(encoded_origin)
            raw_url = unquote(encoded_url)

            # Guard: reject clearly relative URLs (Kodi resolved them incorrectly)
            if not raw_url.startswith('http'):
                log(f'[EPlayerProxy] raw: relative URL rejected: {raw_url}')
                self.send_response(400)
                self.end_headers()
                return

            hdrs = _proxy_headers(origin)
            referer = hdrs['Referer']

            # Fetch without streaming so we can inspect Content-Type / content prefix
            r = requests.get(raw_url, headers=hdrs, timeout=5)
            ct = r.headers.get('Content-Type', '')

            # Detect M3U8 by URL extension OR Content-Type OR content starting with #EXTM3U
            is_manifest = (
                '.m3u8' in raw_url.split('?')[0]
                or 'mpegurl' in ct.lower()
                or r.content[:7] == b'#EXTM3U'
            )

            if is_manifest:
                port = _actual_proxy_port or M3U8_PROXY_PORT
                base = r.url.split('?')[0].rsplit('/', 1)[0] + '/'  # use final URL after redirect
                enc_orig = quote_plus(origin)
                seg_lines = []
                for line in r.text.splitlines():
                    stripped = line.strip()
                    if stripped and not stripped.startswith('#'):
                        abs_seg = stripped if stripped.startswith('http') else urljoin(base, stripped)
                        seg_lines.append(f'http://127.0.0.1:{port}/raw/{enc_orig}/{quote_plus(abs_seg)}')
                    else:
                        seg_lines.append(line)
                body = '\n'.join(seg_lines).encode('utf-8')
                self.send_response(200)
                self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
                self.send_header('Content-Length', str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            else:
                # Segment — already buffered by stream=False above
                body = r.content
                ct_out = ct or 'video/mp2t'
                if body[:2] == b'\x89P':
                    # premiumtv ships its TS inside a PNG envelope; hand adaptive
                    # the real transport stream instead of the wrapper. Unwrapping
                    # is ~2 s of pure-Python pixel work, so a segment is decoded
                    # once and reused for every later request for the same path.
                    _ckey = raw_url.split('?', 1)[0]
                    ts = _ptv_cache_get(_ckey)
                    if ts is not None:
                        body = ts
                        ct_out = 'video/MP2T'
                    else:
                        _t0 = time.time()
                        ts = _unwrap_ptv_segment(body)
                        _ms = (time.time() - _t0) * 1000
                        if ts:
                            log(f'[PremiumTVProxy] unwrapped PNG envelope '
                                f'{len(body)}B -> MPEG-TS {len(ts)}B in {_ms:.0f} ms')
                            _ptv_cache_store(_ckey, ts)
                            body = ts
                            ct_out = 'video/MP2T'
                        else:
                            log(f'[PremiumTVProxy] PNG envelope not unwrapped '
                                f'({len(body)}B) after {_ms:.0f} ms')
                self.send_response(r.status_code)
                self.send_header('Content-Type', ct_out)
                self.send_header('Content-Length', str(len(body)))
                self.end_headers()
                self.wfile.write(body)
        except Exception as e:
            log(f'[EPlayerProxy] raw error: {e}')
            try:
                self.send_response(502)
                self.end_headers()
            except Exception:
                pass

    def _handle_premiumtv(self, encoded_origin, encoded_url):
        """Serve the premiumtv media playlist for inputstream.adaptive.
        Fetches the live playlist with the premiumtv Referer, filters out the
        trailing relative-path segment (which the CDN returns 403 for, and which
        adaptive retries 10x then aborts on), and rewrites the absolute R2
        segment URLs to route through /raw/ so the Referer is applied."""
        try:
            origin = unquote(encoded_origin)
            raw_url = unquote(encoded_url)

            if not raw_url.startswith('http'):
                log(f'[PremiumTVProxy] relative URL rejected: {raw_url}')
                self.send_response(400)
                self.end_headers()
                return

            hdrs = _proxy_headers(origin)
            referer = hdrs['Referer']

            r = requests.get(raw_url, headers=hdrs, timeout=8)
            if r.status_code != 200:
                log(f'[PremiumTVProxy] m3u8 HTTP {r.status_code}: {raw_url[:80]}')
                self.send_response(502)
                self.end_headers()
                return
            if r.content[:7] != b'#EXTM3U':
                # Not a manifest (segment or error body) — forward as-is
                body = r.content
                self.send_response(r.status_code)
                self.send_header('Content-Type', r.headers.get('Content-Type', 'video/mp2t'))
                self.send_header('Content-Length', str(len(body)))
                self.end_headers()
                self.wfile.write(body)
                return

            port = _actual_proxy_port or M3U8_PROXY_PORT
            base = r.url.split('?')[0].rsplit('/', 1)[0] + '/'  # use final URL after redirect
            enc_orig = quote_plus(origin)
            lines = []
            dropped = 0
            for line in r.text.splitlines():
                stripped = line.strip()
                if stripped and not stripped.startswith('#'):
                    # Keep only absolute http(s) segment URLs. Relative-path segments
                    # (e.g. 2026/08/19/...ts on the CDN host) 403 for everyone —
                    # filtering them lets adaptive start on a valid R2 segment.
                    if not stripped.startswith('http'):
                        dropped += 1
                        continue
                    lines.append(f'http://127.0.0.1:{port}/raw/{enc_orig}/{quote_plus(stripped)}')
                else:
                    lines.append(line)
            if dropped:
                log(f'[PremiumTVProxy] filtered {dropped} relative segment(s) from playlist')
            body = '\n'.join(lines).encode('utf-8')
            self.send_response(200)
            self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        except Exception as e:
            log(f'[PremiumTVProxy] error: {e}')
            try:
                self.send_response(502)
                self.end_headers()
            except Exception:
                pass

    def _handle_wide(self, encoded_slug, encoded_url):
        """Serve a wideiptv (Player 6) HLS playlist/segment for inputstream.adaptive.
        Fetches with a fresh token (auto-refreshed via the wideiptv API), rewrites
        manifest segment/variant URLs through /wide/ so the token is re-applied."""
        try:
            slug = unquote(encoded_slug)
            raw_url = unquote(encoded_url)
            if not raw_url.startswith('http'):
                log(f'[WideIptvProxy] relative URL rejected: {raw_url}')
                self.send_response(400)
                self.end_headers()
                return

            # Rebuild the URL with the fresh token (drop any stale one in the query)
            fetch_url = _wide_freshen_url(raw_url, slug)
            hdrs = {'User-Agent': UA, 'Referer': f'https://wideiptv.top/player/{slug}'}
            seg_key = _wide_seg_key(fetch_url)
            kind = 'manifest' if '.m3u8' in fetch_url else 'segment'
            # Log every ISA request. Without this, a log with no [WideIptvProxy]
            # line at all is ambiguous: it can mean ISA never asked, which is very
            # different from ISA asking and the upstream refusing.
            log(f'[WideIptvProxy] {kind} request slug={slug} key={seg_key[-24:]}')
            # Only verified MPEG-TS bodies ever enter the buffer, so a cache hit
            # unambiguously means ISA asked for a segment we already hold. Serve it
            # without touching the network: the prefetch exists precisely for the
            # moments when this particular connection is going to be dropped, so
            # looking here *after* fetching would defeat the whole buffer.
            with _wide_seg_cache_lock:
                _cached = _wide_seg_cache.get(seg_key)
            if _cached is not None:
                log(f'[WideIptvProxy] seg from buffer {len(_cached)}B {_wide_log_tail(fetch_url)}')
                self.send_response(200)
                self.send_header('Content-Type', 'video/MP2T')
                self.send_header('Content-Length', str(len(_cached)))
                self.end_headers()
                self.wfile.write(_cached)
                return
            r = None
            # The wideiptv CDN drops roughly two connections in three yet serves valid
            # HLS when it answers. Without retries each dropped poll costs a full
            # timeout and inputstream.adaptive aborts the stream ("error opening").
            # Per-attempt timeout is 5s (the CDN answers in well under a second when it
            # is up) so three attempts stay well inside adaptive's ~24s give-up window.
            for _attempt in range(3):
                try:
                    r = requests.get(fetch_url, headers=hdrs, timeout=5)
                    break
                except Exception as e:
                    log(f'[WideIptvProxy] attempt {_attempt + 1}/3 failed '
                        f'({type(e).__name__}): {fetch_url[:60]}')
                    if _attempt < 2:
                        time.sleep(0.5)
            if r is None:
                log('[WideIptvProxy] upstream unreachable after 3 attempts')
                self.send_response(502)
                self.end_headers()
                return
            if r.status_code != 200:
                log(f'[WideIptvProxy] HTTP {r.status_code}: {fetch_url[:80]}')
                self.send_response(502)
                self.end_headers()
                return
            if r.content[:7] != b'#EXTM3U':
                # Segment. The buffer was already consulted above; a miss here means
                # no prefetch thread has landed it yet, so fall back to what we got.
                body = r.content
                if not _is_media_segment(body):
                    # HTTP 200 but the payload is not media: a placeholder image or an
                    # error page from an expired token. Serving it as video makes
                    # inputstream.adaptive build a sample reader over garbage, which
                    # surfaces as "unhandled representation container type" plus
                    # "Codec id 27 require extradata" and an instant EOF. Refusing is
                    # what lets adaptive retry the segment instead of dying on it.
                    log(f'[WideIptvProxy] non-media segment {len(body)}B '
                        f'{body[:12]!r} {_wide_log_tail(fetch_url)}')
                    self.send_response(502)
                    self.end_headers()
                    return
                if body[:1] == b'\x47':
                    _wide_cache_store(seg_key, body)
                self.send_response(200)
                self.send_header('Content-Type', 'video/MP2T')
                self.send_header('Content-Length', str(len(body)))
                self.end_headers()
                self.wfile.write(body)
                return

            port = _actual_proxy_port or M3U8_PROXY_PORT
            base = r.url.split('?')[0].rsplit('/', 1)[0] + '/'
            enc_slug = quote_plus(slug)
            lines = []
            abs_segs = []
            for line in r.text.splitlines():
                stripped = line.strip()
                if stripped and not stripped.startswith('#'):
                    abs_seg = stripped if stripped.startswith('http') else urljoin(base, stripped)
                    abs_segs.append(abs_seg)
                    lines.append(f'http://127.0.0.1:{port}/wide/{enc_slug}/{quote_plus(abs_seg)}')
                else:
                    lines.append(line)
            _wide_prefetch_ahead(abs_segs, slug)
            body = '\n'.join(lines).encode('utf-8')
            self.send_response(200)
            self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        except Exception as e:
            log(f'[WideIptvProxy] error: {e}')
            try:
                self.send_response(502)
                self.end_headers()
            except Exception:
                pass

    def _handle_lovecdn(self, stream_name):
        """Proxy M3U8 for lovecdn streams with automatic token refresh.
        Segment URLs are rewritten to go through our local proxy (/lovecdn-seg/)
        which pre-fetches segments into memory — eliminates CDN latency and
        prevents HLS saccade at segment boundaries."""
        try:
            result = _lovecdn_get_media_url(stream_name)
            if not result:
                self.send_response(502)
                self.end_headers()
                return
            current_url, lt_url, media_text, media_base = result
            log(f'[LovecdnM3U8] {stream_name}: ' + ' | '.join(media_text.splitlines()[:20]))

            port = _actual_proxy_port or M3U8_PROXY_PORT
            lines = []
            for line in media_text.splitlines():
                stripped = line.strip()
                # Strip VOD/EVENT markers so libavformat treats stream as live (no loop)
                if stripped.startswith('#EXT-X-PLAYLIST-TYPE') or stripped == '#EXT-X-ENDLIST':
                    continue
                if stripped and not stripped.startswith('#'):
                    abs_seg = stripped if stripped.startswith('http') else urljoin(media_base, stripped)
                    # Route through local cache proxy
                    proxy_url = f'http://127.0.0.1:{port}/lovecdn-seg/{quote_plus(abs_seg)}'
                    lines.append(proxy_url)
                    # Pre-fetch in background so it's ready before Kodi asks for it
                    threading.Thread(
                        target=_lovecdn_prefetch_seg,
                        args=(abs_seg,),
                        daemon=True,
                    ).start()
                else:
                    lines.append(line)
            body = '\n'.join(lines).encode('utf-8')
            self.send_response(200)
            self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        except Exception as e:
            log(f'[LovecdnProxy] error for {stream_name}: {e}')
            try:
                self.send_response(502)
                self.end_headers()
            except Exception:
                pass

    def _handle_lovecdn_ts(self, stream_name):
        """Serve lovecdn stream as a continuous MPEG-TS byte stream (no HLS jitter).
        Acts as an internal HLS client: polls media playlist, downloads plain TS segments,
        and forwards them with null-packet pacing — same pattern as _handle_stream.

        Key design: HTTP response headers are NOT sent until 2 segments are buffered.
        This ensures ffmpegdirect/libavformat sees real H.264 SPS data immediately,
        avoiding DXVA2 initialization with incomplete stream info (which causes
        'status 2 with 255' errors when null packets are sent first)."""
        import queue as _q

        # Initial token fetch
        result = _lovecdn_get_media_url(stream_name, force_refresh=True)
        if not result:
            self.send_response(502)
            self.end_headers()
            return

        seen_urls = set()
        _seg_q = _q.Queue(maxsize=10)
        _client_gone = threading.Event()
        _NULL_PKT = bytes([0x47, 0x1F, 0xFF, 0x10]) + bytes(184)
        _PRE_BUFFER_MAX = 15.0
        _STALL_MAX = 30.0
        _last_content_time = [time.time()]

        def _download():
            """Download segments in background, filling _seg_q."""
            last_content = time.time()
            while not _proxy_abort.is_set() and not _client_gone.is_set():
                r = _lovecdn_get_media_url(stream_name)
                if not r:
                    _proxy_abort.wait(timeout=3)
                    r = _lovecdn_get_media_url(stream_name, force_refresh=True)
                    if not r:
                        log(f'[LovecdnTS] {stream_name}: token refresh failed, ending stream')
                        break

                _media_url, _lt_url, media_text, media_base = r
                tgt_m = re.search(r'#EXT-X-TARGETDURATION:(\d+)', media_text)
                tgt_dur = float(tgt_m.group(1)) if tgt_m else 6.0

                segs = []
                seg_dur_map = {}
                _last_inf = tgt_dur
                for _sl in media_text.splitlines():
                    _sl = _sl.strip()
                    if _sl.startswith('#EXTINF:'):
                        try:
                            _last_inf = float(_sl[8:].split(',')[0])
                        except Exception:
                            _last_inf = tgt_dur
                    elif _sl and not _sl.startswith('#'):
                        _su = _sl if _sl.startswith('http') else urljoin(media_base, _sl)
                        segs.append(_su)
                        seg_dur_map[_su] = _last_inf
                        _last_inf = tgt_dur

                new_segs = [u for u in segs if u not in seen_urls]
                if not new_segs:
                    if time.time() - last_content >= _STALL_MAX:
                        log(f'[LovecdnTS] {stream_name}: stall >{int(_STALL_MAX)}s — ending stream')
                        break
                    _proxy_abort.wait(timeout=tgt_dur / 2)
                    continue

                for seg_url in new_segs:
                    if _proxy_abort.is_set() or _client_gone.is_set():
                        break
                    try:
                        sr = _get_session().get(seg_url, headers={'User-Agent': UA}, timeout=(3, 8))
                        if sr.status_code == 200:
                            body = sr.content
                            seen_urls.add(seg_url)
                            seg_dur = seg_dur_map.get(seg_url, tgt_dur)
                            while not _client_gone.is_set() and not _proxy_abort.is_set():
                                try:
                                    _seg_q.put((body, seg_dur), timeout=0.5)
                                    break
                                except _q.Full:
                                    pass
                            last_content = time.time()
                            _last_content_time[0] = last_content
                            log(f'[LovecdnTS] seg {len(body)}B dur={seg_dur:.1f}s {seg_url[-50:]}')
                        elif sr.status_code == 403:
                            log(f'[LovecdnTS] seg 403 — clearing token cache for {stream_name}')
                            with _lovecdn_url_cache_lock:
                                _lovecdn_url_cache.pop(stream_name, None)
                        else:
                            log(f'[LovecdnTS] seg {sr.status_code}: {seg_url[-50:]}')
                    except Exception as e:
                        log(f'[LovecdnTS] seg error: {e}')
            _seg_q.put(None)

        _dl_t = threading.Thread(target=_download, daemon=True)
        _dl_t.start()

        # Wait for 2 segments before sending HTTP response.
        # No null packets sent — ffmpegdirect must see real H.264 SPS immediately
        # so DXVA2 (or its fallback) initializes with correct stream parameters.
        _wait_start = time.time()
        while _seg_q.qsize() < 2 and not _proxy_abort.is_set():
            if time.time() - _wait_start > _PRE_BUFFER_MAX:
                log(f'[LovecdnTS] {stream_name}: pre-buffer timeout')
                _client_gone.set()
                _dl_t.join(timeout=5)
                self.send_response(504)
                self.end_headers()
                return
            time.sleep(0.05)

        log(f'[LovecdnTS] {stream_name}: {_seg_q.qsize()} segs ready, starting stream')
        try:
            self.send_response(200)
            self.send_header('Content-Type', 'video/MP2T')
            self.end_headers()
        except Exception as e:
            log(f'[LovecdnTS] {stream_name}: header error: {e}')
            _client_gone.set()
            _dl_t.join(timeout=5)
            return

        def _sender():
            _bps = 250000
            _BURST_INTERVAL = 0.02
            _pace_clock = None
            while not _client_gone.is_set() and not _proxy_abort.is_set():
                if _pace_clock is not None:
                    while not _client_gone.is_set() and not _proxy_abort.is_set():
                        remaining = _pace_clock - time.time()
                        if remaining <= 0:
                            break
                        time.sleep(min(remaining, _BURST_INTERVAL))
                        n = max(1, int(_bps * _BURST_INTERVAL / 188))
                        try:
                            self.wfile.write(_NULL_PKT * n)
                            self.wfile.flush()
                        except (BrokenPipeError, OSError, ConnectionResetError):
                            _client_gone.set()
                            break
                if _client_gone.is_set() or _proxy_abort.is_set():
                    break
                try:
                    item = _seg_q.get(timeout=_BURST_INTERVAL)
                except _q.Empty:
                    n = max(1, int(_bps * _BURST_INTERVAL / 188))
                    try:
                        self.wfile.write(_NULL_PKT * n)
                        self.wfile.flush()
                    except (BrokenPipeError, OSError, ConnectionResetError):
                        _client_gone.set()
                    continue
                if item is None:
                    _seg_q.task_done()
                    break
                seg_body, seg_dur = item
                _bps = max(12500, len(seg_body) / max(seg_dur, 0.1))
                try:
                    self.wfile.write(seg_body)
                    self.wfile.flush()
                except (BrokenPipeError, OSError, ConnectionResetError):
                    log(f'[LovecdnTS] {stream_name}: client disconnected')
                    _client_gone.set()
                    _seg_q.task_done()
                    return
                now = time.time()
                _pace_clock = max(now, _pace_clock or now) + seg_dur
                _seg_q.task_done()

        _sender_t = threading.Thread(target=_sender, daemon=True)
        _sender_t.start()
        _sender_t.join()
        _client_gone.set()
        _dl_t.join(timeout=5)

    def _handle_lovecdn_seg(self, seg_url):
        """Fetch a lovecdn segment or sub-playlist with proper headers.
        Serves from pre-fetch memory cache when available (instant, no CDN latency).
        If the response is an M3U8, segment URLs are rewritten through this proxy
        (handles variant/master playlists that contain relative segment paths)."""
        try:
            # Serve from memory cache if segment was pre-fetched
            with _lovecdn_seg_cache_lock:
                cached_body = _lovecdn_seg_cache.get(seg_url)
            if cached_body is not None:
                self.send_response(200)
                self.send_header('Content-Type', 'video/MP2T')
                self.send_header('Content-Length', str(len(cached_body)))
                self.end_headers()
                self.wfile.write(cached_body)
                log(f'[LovecdnSeg] cache-hit {len(cached_body)}B {seg_url[-40:]}')
                return

            referer = 'https://lovetier.bz/'
            with _lovecdn_url_cache_lock:
                for sname, cached in list(_lovecdn_url_cache.items()):
                    if sname in seg_url and cached and len(cached) > 2 and cached[2]:
                        referer = cached[2]
                        break
            _p = urlparse(referer)
            origin = f'{_p.scheme}://{_p.netloc}'
            r = _lovecdn_session.get(seg_url, headers={
                'User-Agent': UA,
                'Referer': referer,
                'Origin': origin,
            }, timeout=10, stream=True)
            if r.status_code != 200:
                log(f'[LovecdnProxy] seg HTTP {r.status_code}: {seg_url[8:60]}')
                self.send_response(r.status_code)
                self.end_headers()
                return
            ct = r.headers.get('Content-Type', '')
            is_m3u8 = ('mpegurl' in ct or 'm3u8' in ct
                       or seg_url.split('?')[0].lower().endswith('.m3u8'))
            if is_m3u8:
                # Sub-playlist: buffer fully to detect HTML and rewrite segment URLs
                body_bytes = r.content
                body_text = body_bytes.decode('utf-8', errors='replace')
                if '<html' in body_text[:200].lower():
                    log(f'[LovecdnProxy] seg got HTML (Cloudflare?) for {seg_url[8:60]}')
                    with _lovecdn_url_cache_lock:
                        for sname in list(_lovecdn_url_cache.keys()):
                            if sname in seg_url:
                                _lovecdn_url_cache.pop(sname, None)
                                break
                    self.send_response(502)
                    self.end_headers()
                    return
                port = _actual_proxy_port or M3U8_PROXY_PORT
                base = seg_url.split('?')[0].rsplit('/', 1)[0] + '/'
                lines = []
                for line in body_text.splitlines():
                    stripped = line.strip()
                    if stripped and not stripped.startswith('#'):
                        abs_seg = stripped if stripped.startswith('http') else urljoin(base, stripped)
                        lines.append(f'http://127.0.0.1:{port}/lovecdn-seg/{quote_plus(abs_seg)}')
                    else:
                        lines.append(line)
                body = '\n'.join(lines).encode('utf-8')
                self.send_response(200)
                self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
                self.send_header('Content-Length', str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            else:
                # TS segment: stream to Kodi in chunks — avoids buffering 2.5MB before first byte
                cl = r.headers.get('Content-Length')
                self.send_response(200)
                self.send_header('Content-Type', ct or 'video/mp2t')
                if cl:
                    self.send_header('Content-Length', cl)
                self.end_headers()
                total = 0
                for chunk in r.iter_content(chunk_size=65536):
                    if chunk:
                        self.wfile.write(chunk)
                        total += len(chunk)
                log(f'[LovecdnProxy] seg ok {total}B {seg_url[8:60]}')
        except Exception as e:
            log(f'[LovecdnProxy] seg error: {e}')
            try:
                self.send_response(502)
                self.end_headers()
            except Exception:
                pass

    def _handle_segment(self, encoded_url):
        seg_url = unquote(encoded_url)
        log(f'[EPlayerProxy] seg req: {seg_url[8:80]}')
        seg_hdrs = dict(_SEG_HEADERS)
        body = None
        seg_proxy_url = addon.getSetting('seg_proxy').strip()
        proxies = {'http': seg_proxy_url, 'https': seg_proxy_url} if seg_proxy_url else None
        with _seg_semaphore:
            for attempt in range(2):
                current_proxies = proxies if attempt == 1 else None
                try:
                    r = _get_session().get(seg_url, headers=seg_hdrs, timeout=(3, 5),
                                          proxies=current_proxies)
                    ct = r.headers.get('Content-Type', '')
                    if r.status_code == 200 and 'html' not in ct.lower():
                        body = r.content
                        if current_proxies:
                            log(f'[EPlayerProxy] seg ok via proxy: {len(body)}B')
                        break
                    elif r.status_code == 429:
                        if attempt == 0 and proxies:
                            log(f'[EPlayerProxy] seg 429, retrying via proxy')
                            # continue to attempt 1 with proxy
                        else:
                            log(f'[EPlayerProxy] seg 429: CDN rate-limit')
                            break
                    else:
                        log(f'[EPlayerProxy] seg bad: status={r.status_code} ct={ct} size={len(r.content)}B')
                        break
                except requests.exceptions.Timeout:
                    log(f'[EPlayerProxy] seg timeout: {seg_url[:70]}')
                    break
                except Exception as e:
                    err_str = str(e)
                    if '407' in err_str or 'Proxy Authentication Required' in err_str:
                        log(f'[EPlayerProxy] seg proxy 407: incorrect proxy credentials — check the "Proxy segments" setting')
                        break
                    log(f'[EPlayerProxy] seg error (attempt {attempt + 1}): {e}')
                    if attempt == 0:
                        time.sleep(0.1)
        try:
            if body is not None:
                # Strip CHEVY PNG wrapper: plain TS wrapped in a fake PNG file.
                # PNG magic = \x89PNG; TS sync = 0x47. Use 3 consecutive sync bytes for reliable detection.
                # Scan only when body starts with PNG signature (avoids wasteful scan of AES data).
                _PNG_SIG = b'\x89PNG'
                if body and body[:4] == _PNG_SIG and len(body) > 564:
                    for _off in range(len(body) - 564):
                        if (body[_off] == 0x47 and body[_off + 188] == 0x47
                                and body[_off + 376] == 0x47):
                            log(f'[EPlayerProxy] seg stripped CHEVY header {_off}B, size {len(body)}→{len(body)-_off}B')
                            body = body[_off:]
                            break
                    else:
                        log(f'[EPlayerProxy] seg PNG wrapper but no TS sync found in {len(body)}B')
                log(f'[EPlayerProxy] seg ok: {len(body)}B first8={body[:8].hex()}')
                # Mark this segment as downloaded so the m3u8 dedup won't include it again
                _ch = _seg_url_to_channel.get(seg_url)
                if _ch:
                    with _stall_lock:
                        _sent_seg_urls.setdefault(_ch, set()).add(seg_url)
                self.send_response(200)
                self.send_header('Content-Type', 'video/mp2t')
                self.send_header('Content-Length', str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            else:
                log(f'[EPlayerProxy] seg fail 502: {seg_url[8:70]}')
                self.send_response(502)
                self.end_headers()
        except Exception:
            pass

    def do_HEAD(self):
        self.send_response(200)
        self.send_header('Content-Type', 'application/octet-stream')
        self.end_headers()

    def log_message(self, fmt, *args):
        pass


def _serve_until_abort(server):
    """Run the HTTP server until Kodi signals shutdown. Exits within ~0.5s of abort."""
    monitor = xbmc.Monitor()
    server.timeout = 0.5
    while not monitor.abortRequested():
        server.handle_request()
    _proxy_abort.set()  # unblock any handler threads sleeping in stall retry
    log('[EPlayerProxy] Kodi abort — proxy server stopped')
    server.server_close()


def _ensure_m3u8_proxy():
    global _actual_proxy_port
    if _actual_proxy_port is not None:
        return
    # H5: clear the abort event so handler threads started in this session are not
    # immediately unblocked by a stale set() from a previous proxy session.
    _proxy_abort.clear()
    for port in range(M3U8_PROXY_PORT, M3U8_PROXY_PORT + 20):
        try:
            server = ThreadingHTTPServer(('127.0.0.1', port), _EPlayerProxyHandler)
            server.daemon_threads = True  # request threads die with the process
            t = threading.Thread(target=_serve_until_abort, args=(server,), daemon=True)
            t.start()
            _actual_proxy_port = port
            log(f'[EPlayerProxy] Started on port {port} (mtime={_PROXY_ADDON_MTIME})')
            return
        except OSError as e:
            if e.errno in (98, 10048):
                # Port busy — check if it's our proxy with current code
                try:
                    rh = requests.get(f'http://127.0.0.1:{port}/health', timeout=1)
                    if rh.status_code == 200 and rh.text == 'dltv-proxy':
                        try:
                            rv = requests.get(f'http://127.0.0.1:{port}/version', timeout=1)
                            proxy_mtime = rv.text.strip() if rv.status_code == 200 else ''
                        except Exception:
                            proxy_mtime = ''
                        if proxy_mtime == _PROXY_ADDON_MTIME:
                            _actual_proxy_port = port
                            log(f'[EPlayerProxy] Already running on port {port} (up-to-date)')
                            return
                        else:
                            log(f'[EPlayerProxy] Port {port} has stale proxy (mtime {proxy_mtime} != {_PROXY_ADDON_MTIME}), trying next port')
                except Exception:
                    pass
                log(f'[EPlayerProxy] Port {port} busy (not ours), trying {port + 1}')
            else:
                log(f'[EPlayerProxy] Failed to start on port {port}: {e}')
                break
    _actual_proxy_port = None
    log(f'[EPlayerProxy] Could not bind any port — proxy unavailable')

EXTRA_CHANNELS_DATA = {}

_log_rotated = False  # M4: ensure log rotation happens at most once per session

def log(msg):
    global _log_rotated
    logpath = xbmcvfs.translatePath('special://logpath/')
    filename = 'dltv.log'
    log_file = os.path.join(logpath, filename)
    try:
        if isinstance(msg, str):
            _msg = f'\n    {msg}'
        else:
            _msg = f'\n    {repr(msg)}'
        if not os.path.exists(log_file):
            with open(log_file, 'w', encoding='utf-8'):
                pass
        # M4: rotate log if it exceeds 2 MB (keep last 500 lines), at most once per session
        if not _log_rotated:
            try:
                if os.path.getsize(log_file) > 2 * 1024 * 1024:
                    with open(log_file, 'r', encoding='utf-8', errors='replace') as _rf:
                        _lines = _rf.readlines()
                    with open(log_file, 'w', encoding='utf-8') as _wf:
                        _wf.writelines(_lines[-500:])
                    _log_rotated = True
            except Exception:
                pass
        with open(log_file, 'a', encoding='utf-8') as f:
            line = '[{} {}]: {}'.format(datetime.now().date(), str(datetime.now().time())[:8], _msg)
            f.write(line.rstrip('\r\n') + '\n')
    except Exception as e:
        try:
            xbmc.log(f'[ DLTV ] Logging Failure: {e}', 2)
        except:
            pass

# Stamp every session with the build that produced it. Logs get rotated and
# concatenated across versions, so without this a capture cannot be attributed.
log(f'[DLTV] v{addon.getAddonInfo("version")} loaded')

def should_cache_url(url: str) -> bool:
    """
    Determine if this URL is cacheable.
    Cache:
        - index.php pages (category, schedule, etc.)
        - 24-7-channels.php
    Do NOT cache:
        - watch.php (stream URLs)
    """
    if 'watch.php' in url:
        return False
    if 'index.php' in url or '24-7-channels.php' in url:
        return True
    return False


_CACHE_TTL_VALUES = [1800, 3600, 7200, 21600, 43200]  # 30min, 1h, 2h, 6h, 12h

def get_cache_expiry():
    try:
        return _CACHE_TTL_VALUES[int(addon.getSetting('cache_ttl'))]
    except Exception:
        return 7200  # default 2h

CACHE_EXPIRY = get_cache_expiry()

def _is_error_response(text, url=''):
    if not text:
        return True
    if '24-7-channels.php' in url and 'class="card"' not in text:
        return True
    return False

def _load_page_cache():
    try:
        with open(_PAGE_CACHE_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}

def _save_page_cache(cache):
    try:
        _dir = os.path.dirname(_PAGE_CACHE_FILE)
        fd, tmp_path = tempfile.mkstemp(dir=_dir)
        try:
            with os.fdopen(fd, 'w', encoding='utf-8') as f:
                json.dump(cache, f)
            os.replace(tmp_path, _PAGE_CACHE_FILE)
        except Exception:
            try:
                os.unlink(tmp_path)
            except Exception:
                pass
            raise
    except Exception as e:
        log(f"[fetch_via_proxy] Failed to save page cache: {e}")

_fetch_failed = {}             # url -> timestamp of the last failed fetch
_fetch_fail_lock = threading.Lock()
_FETCH_FAIL_TTL = 60          # seconds to stop retrying a URL that just failed


def fetch_via_proxy(url, headers=None, use_cache=True):
    headers = headers or {}
    should_cache = should_cache_url(url)

    if should_cache:
        cached = _load_page_cache()
        entry = cached.get(url)
        if isinstance(entry, dict) and 'data' in entry and 'timestamp' in entry:
            if time.time() - entry['timestamp'] < get_cache_expiry() and not _is_error_response(entry['data'], url):
                log(f"[fetch_via_proxy] Returning cached data for {url}")
                return entry['data']

    # Remember failures too. Without this, a portal that refuses connections makes
    # every directory rebuild retry each URL from scratch — 4 requests plus a
    # get_active_base probe each, ~8s per URL — and "Update schedule" clears the
    # cache and forces a rebuild, so the menu spins for minutes. Serving the last
    # good page (or nothing) for a minute is better than blocking the UI.
    _fail_ts = _fetch_failed.get(url)
    if _fail_ts and time.time() - _fail_ts < _FETCH_FAIL_TTL:
        _stale = ''
        if should_cache:
            _e = _load_page_cache().get(url)
            if isinstance(_e, dict):
                _stale = _e.get('data', '') or ''
        log(f"[fetch_via_proxy] {url[:60]} unreachable {int(time.time() - _fail_ts)}s ago, "
            f"{'serving stale cache' if _stale else 'skipping request'}")
        return _stale

    resp_text = ''
    for attempt in range(2):
        for verify_ssl in ([True, False] if attempt == 0 else [False]):
            if not verify_ssl:
                log(f'[fetch_via_proxy] SSL verify disabled for retry: {url[:60]}')
            try:
                resp_text = requests.get(url, headers=headers, timeout=8,
                                         verify=verify_ssl, allow_redirects=True).text
                if not _is_error_response(resp_text, url):
                    log(f"[fetch_via_proxy] ok attempt={attempt} verify={verify_ssl} for {url}")
                    break
                log(f"[fetch_via_proxy] bad response verify={verify_ssl}: {resp_text[:80]}")
            except Exception as e:
                log(f"[fetch_via_proxy] failed attempt={attempt} verify={verify_ssl} for {url}: {type(e).__name__}: {e}")
        if not _is_error_response(resp_text, url):
            break
        if attempt == 0:
            time.sleep(1)
    if _is_error_response(resp_text, url):
        with _fetch_fail_lock:
            _fetch_failed[url] = time.time()
        return ''

    with _fetch_fail_lock:
        _fetch_failed.pop(url, None)
    if should_cache:
        cached = _load_page_cache()
        cached[url] = {'timestamp': int(time.time()), 'data': resp_text}
        _save_page_cache(cached)

    return resp_text




def normalize_origin(url):
    if not url:
        return ''
    try:
        u = urlparse(url)
        return f'{u.scheme}://{u.netloc}/'
    except:
        return SEED_BASEURL

_active_base_cache = None
_active_base_failed_at = 0
_ACTIVE_BASE_FAIL_TTL = 30   # seconds before re-probing a portal that just refused


def get_active_base():
    global _active_base_cache, _active_base_failed_at
    if _active_base_cache:
        return _active_base_cache
    # A portal that just refused connections must not be re-probed on every single
    # call: a directory rebuild asks for the base once per URL, and each probe costs
    # a full timeout. Remember the failure briefly and reuse the fallback instead.
    if _active_base_failed_at and time.time() - _active_base_failed_at < _ACTIVE_BASE_FAIL_TTL:
        base = normalize_origin(SEED_BASEURL)
        if not base.endswith('/'):
            base += '/'
        _active_base_cache = base
        return base
    base = addon.getSetting('active_baseurl')
    if base:
        # Validate once per process — if unreachable, fall back to seed
        try:
            r = requests.get(base, headers={'User-Agent': UA}, timeout=5,
                             verify=False, allow_redirects=True)
            if r.status_code >= 400:
                raise Exception(f'HTTP {r.status_code}')
        except Exception as e:
            log(f'[get_active_base] {base} invalide ({e}), reset vers seed')
            base = ''
            _active_base_failed_at = time.time()
            addon.setSetting('active_baseurl', '')
    if not base:
        base = normalize_origin(SEED_BASEURL)
        addon.setSetting('active_baseurl', base)
    if not base.endswith('/'):
        base += '/'
    _active_base_cache = base
    return base

def abs_url(path: str) -> str:
    return urljoin(get_active_base(), path.lstrip('/'))

def get_local_time(utc_time_str):
    if not utc_time_str:
        return ''
    try:
        # Parse manually — datetime.strptime is None in some Kodi/Python envs (_strptime lazy import bug)
        h, m = map(int, utc_time_str.strip().split(':'))
        utc_now = time.gmtime()
        utc_ts = calendar.timegm((utc_now.tm_year, utc_now.tm_mon, utc_now.tm_mday, h, m, 0, 0, 0, 0))
        local = time.localtime(utc_ts)
        use_24h = addon.getSetting('time_format') == '1'
        if use_24h:
            return f'{local.tm_hour:02d}:{local.tm_min:02d}'
        else:
            period = 'AM' if local.tm_hour < 12 else 'PM'
            h12 = local.tm_hour % 12 or 12
            return f'{h12}:{local.tm_min:02d} {period}'
    except Exception as e:
        log(f"Failed to convert time: {e}")
        return utc_time_str or ''


def _build_current_events_map():
    """Return {channel_id: 'LocalTime  EventTitle'} for events currently airing (started < 4h ago)."""
    try:
        url = abs_url('index.php')
        html_text = fetch_via_proxy(url, headers={'User-Agent': UA, 'Referer': get_active_base()})
        if not html_text:
            return {}
        now_ts = time.time()
        utc_now = time.gmtime()
        today_midnight = calendar.timegm((utc_now.tm_year, utc_now.tm_mon, utc_now.tm_mday, 0, 0, 0, 0, 0, 0))
        ev_map = {}
        for time_str, event_title, channels_block in re.findall(
            r'<div\s+class="schedule__event">.*?'
            r'<div\s+class="schedule__eventHeader"[^>]*?>\s*'
            r'(?:<[^>]+>)*?'
            r'<span\s+class="schedule__time"[^>]*data-time="([^"]+)"[^>]*>.*?</span>\s*'
            r'<span\s+class="schedule__eventTitle">\s*([^<]+)\s*</span>.*?'
            r'</div>\s*'
            r'<div\s+class="schedule__channels">(.*?)</div>',
            html_text, re.IGNORECASE | re.DOTALL
        ):
            try:
                h, m = map(int, time_str.strip().split(':'))
            except Exception:
                continue
            # Check today and yesterday to handle midnight crossover
            is_current = False
            for midnight in (today_midnight, today_midnight - 86400):
                event_ts = midnight + h * 3600 + m * 60
                if event_ts <= now_ts < event_ts + 4 * 3600:
                    is_current = True
                    break
            if not is_current:
                continue
            local_time = get_local_time(time_str.strip())
            title = html.unescape(event_title.strip())
            display = f'{local_time}  {title}'
            for href, title_attr, link_text in re.findall(
                r'<a[^>]+href="([^"]+)"[^>]*title="([^"]*)"[^>]*>(.*?)</a>',
                channels_block, re.IGNORECASE | re.DOTALL
            ):
                try:
                    cid = dict(parse_qsl(urlparse(href).query)).get('id') or ''
                except Exception:
                    cid = ''
                if cid and cid not in ev_map:
                    ev_map[cid] = display
        return ev_map
    except Exception as e:
        log(f'[_build_current_events_map] error: {e}')
        return {}


def build_url(query):
    return addon_url + '?' + urlencode(query)

def addDir(title, dir_url, is_folder=True, logo=None, context_menu=None, plot=None):
    li = xbmcgui.ListItem(title)
    clean_title = re.sub(r'<[^>]+>', '', title)
    clean_plot = plot if plot else clean_title
    labels = {'title': clean_title, 'plot': clean_plot, 'mediatype': 'video'}
    if getKodiversion() < 20:
        li.setInfo("video", labels)
    else:
        infotag = li.getVideoInfoTag()
        infotag.setMediaType('video')
        infotag.setTitle(clean_title)
        infotag.setPlot(clean_plot)

    logo = logo or ICON
    li.setArt({'thumb': logo, 'poster': logo, 'banner': logo, 'icon': logo, 'fanart': FANART})
    li.setProperty("IsPlayable", 'false' if is_folder else 'true')
    if context_menu:
        li.addContextMenuItems(context_menu)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=dir_url, listitem=li, isFolder=is_folder)


def closeDir():
    xbmcplugin.endOfDirectory(addon_handle)

def getKodiversion():
    try:
        return int(xbmc.getInfoLabel("System.BuildVersion")[:2])
    except Exception:
        return 18

def Main_Menu():
    menu = [
        ['[B][COLOR gold]LIVE SPORTS SCHEDULE[/COLOR][/B]', 'sched', None],
        ['[B][COLOR gold]LIVE TV CHANNELS[/COLOR][/B]', 'live_tv', None],
        ['[B][COLOR gold]LIVE TV BY LANGUAGE[/COLOR][/B]', 'lang_menu', None],
        ['[B][COLOR gold]FAVORITE LIVE TV CHANNELS[/COLOR][/B]', 'favorites', None],
        ['[B][COLOR gold]EXTRA CHANNELS / VODS[/COLOR][/B]', 'extra_channels',
         'https://images-ext-1.discordapp.net/external/fUzDq2SD022-veHyDJTHKdYTBzD9371EnrUscXXrf0c/%3Fsize%3D4096/https/cdn.discordapp.com/icons/1373713080206495756/1fe97e658bc7fb0e8b9b6df62259c148.png?format=webp&quality=lossless'],
        ['[B][COLOR gold]SEARCH EVENTS SCHEDULE[/COLOR][/B]', 'search', None],
        ['[B][COLOR gold]SEARCH LIVE TV CHANNELS[/COLOR][/B]', 'search_channels', None],
        ['[B][COLOR gold]SEARCH CHANNEL BY NUMBER[/COLOR][/B]', 'search_by_number', None],
        ['[B][COLOR lime]EXPORT M3U / CONFIGURE PVR[/COLOR][/B]', 'export_m3u', None],
        ['[B][COLOR red]DIAGNOSTICS[/COLOR][/B]', 'diagnostics', None],
        ['[B][COLOR cyan]DLTV CHAT[/COLOR][/B]', 'chat', None],
    ]

    for title, mode_name, logo in menu:
        addDir(title, build_url({'mode': 'menu', 'serv_type': mode_name}), True, logo=logo)

    closeDir()


def run_diagnostics():
    def ok(text):
        return f'[COLOR lime][OK][/COLOR] {text}'
    def ko(text):
        return f'[COLOR red][KO][/COLOR] {text}'
    def info(text):
        return f'[COLOR cyan][INFO][/COLOR] {text}'

    version = addon.getAddonInfo('version')
    lines = [f'[B]DLTV — v{version} — Diagnostics[/B]', '']

    # 0. Configuration
    lines.append('[B]0. Configuration[/B]')
    lines.append(info(f'Base URL     : {get_active_base()}'))
    lines.append(info(f'CHEVY proxy  : {CHEVY_PROXY}'))
    lines.append(info(f'CHEVY lookup : {CHEVY_LOOKUP}'))
    dns = addon.getSetting('custom_dns').strip()
    lines.append(info(f'Custom DNS   : {dns or "(not set)"}'))
    seg_proxy = addon.getSetting('seg_proxy').strip()
    lines.append(info(f'Seg proxy    : {seg_proxy or "(not set)"}'))
    lines.append('')

    # 1. Channel list
    url = abs_url('24-7-channels.php')
    lines.append(f'[B]1. Channel list[/B]  ({url})')
    fetched = False
    for verify_ssl in [True, False]:
        try:
            r = requests.get(url, headers={'User-Agent': UA}, timeout=10,
                             verify=verify_ssl, allow_redirects=True)
            cards = len(re.findall(r'class="card"', r.text))
            if cards > 0:
                lines.append(ok(f'HTTP {r.status_code} — {cards} channels'))
                fetched = True
                break
            else:
                lines.append(ko(f'HTTP {r.status_code} — 0 channels (verify_ssl={verify_ssl})'))
        except Exception as e:
            lines.append(ko(f'verify_ssl={verify_ssl}: {type(e).__name__}: {str(e)[:80]}'))
    if not fetched:
        lines.append(ko('Failed to load channels'))
    lines.append('')

    # 2. CHEVY CDN — server lookup + m3u8 + AES key
    lines.append('[B]2. CHEVY CDN[/B]')
    # Use ch.116 (beIN SPORTS 1) as test channel — reliably on CHEVY
    _diag_cid = '116'
    _diag_key = f'premium{_diag_cid}'
    m3u8_content = ''
    try:
        _sl_r = requests.get(f'{CHEVY_LOOKUP}/server_lookup?channel_id={_diag_key}',
                             headers={'User-Agent': UA, 'Referer': PLAYER_REFERER}, timeout=6)
        _sk_d = _sl_r.json().get('server_key', '?') if _sl_r.status_code == 200 else '?'
        if _sk_d and _sk_d != 'nfs' and _sk_d != '?':
            lines.append(ok(f'server_lookup ch.{_diag_cid} → {_sk_d}'))
        elif _sk_d == 'nfs':
            lines.append(ko(f'server_lookup ch.{_diag_cid} → nfs (offline)'))
        else:
            lines.append(ko(f'server_lookup HTTP {_sl_r.status_code}'))
    except Exception as e:
        _sk_d = '?'
        lines.append(ko(f'server_lookup: {type(e).__name__}: {str(e)[:60]}'))

    # m3u8 fetch
    m3u8_url = resolve_stream_url(_diag_cid)
    try:
        _m3r = requests.get(m3u8_url, headers={'User-Agent': _AUTH_UA, 'Referer': PLAYER_REFERER},
                            timeout=8)
        m3u8_content = _m3r.text
        _segs_d = [l for l in m3u8_content.splitlines() if l and not l.startswith('#')]
        _ph_d, _real_d = 0, 0
        for _s in _segs_d:
            if _is_placeholder(_s):
                _ph_d += 1
            else:
                _real_d += 1
        if _m3r.status_code == 200 and _real_d > 0:
            lines.append(ok(f'm3u8 HTTP 200 — {_real_d} real segs ({_ph_d} filtered)'))
        elif _m3r.status_code == 200 and _ph_d > 0:
            lines.append(ko(f'm3u8 HTTP 200 — all {_ph_d} segs are placeholders'))
        else:
            lines.append(ko(f'm3u8 HTTP {_m3r.status_code} — {m3u8_content[:80]}'))
    except Exception as e:
        lines.append(ko(f'm3u8: {type(e).__name__}: {str(e)[:60]}'))

    # AES key fetch (no auth needed — CHEVY serves key directly)
    try:
        _km = re.search(r'/key/[^/]+/(\d+)', m3u8_content)
        if _km:
            _kid = _km.group(1)
            _kr = requests.get(f'{CHEVY_LOOKUP}/key/{_diag_key}/{_kid}',
                               headers={'User-Agent': _AUTH_UA, 'Referer': PLAYER_REFERER},
                               timeout=6)
            if _kr.status_code == 200 and len(_kr.content) == 16:
                lines.append(ok(f'AES key /key/{_diag_key}/{_kid} → 16B OK'))
            else:
                lines.append(ko(f'AES key HTTP {_kr.status_code} — {len(_kr.content)}B'))
        else:
            lines.append(info('AES key: no key URI in m3u8 (unencrypted or m3u8 failed)'))
    except Exception as e:
        lines.append(ko(f'AES key: {type(e).__name__}: {str(e)[:60]}'))
    lines.append('')

    # 3. Local proxy
    lines.append('[B]3. Local proxy[/B]')
    try:
        _ensure_m3u8_proxy()
        port = _actual_proxy_port or M3U8_PROXY_PORT
        rh = requests.get(f'http://127.0.0.1:{port}/health', timeout=2)
        if rh.status_code == 200 and rh.text == 'dltv-proxy':
            lines.append(ok(f'Proxy running — port {port}'))
            # Test m3u8 proxy path (noauth — works regardless of ksohls.ru)
            _set_channel_state(_diag_key, 'noauth', 'noauth', m3u8_url)
            rm = requests.get(f'http://127.0.0.1:{port}/m3u8/{_diag_key}', timeout=12)
            proxy_segs = [l for l in rm.text.splitlines() if l and not l.startswith('#')]
            if rm.status_code == 200 and proxy_segs:
                lines.append(ok(f'm3u8 proxy : HTTP 200 — {len(proxy_segs)} segments served'))
            else:
                lines.append(ko(f'm3u8 proxy : HTTP {rm.status_code} — {len(proxy_segs)} segments'))
        else:
            lines.append(ko(f'Proxy not responding (HTTP {rh.status_code})'))
    except Exception as e:
        lines.append(ko(f'Proxy: {type(e).__name__}: {str(e)[:80]}'))
    lines.append('')

    # 4. Stall state
    lines.append('[B]4. Stall state[/B]')
    stall_keys = list(_m3u8_stall.keys())
    with _proxy_lock:
        cred_keys = list(_channel_creds.keys())
    if stall_keys:
        for k in stall_keys:
            st = _m3u8_stall.get(k, {})
            _age = int(time.time() - st.get('first_seen', time.time()))
            lines.append(info(f'{k}: seq={st.get("seq")} frozen={_age}s retries={st.get("same_url_retries", 0)}'))
    else:
        lines.append(ok('No active stall'))
    lines.append(info(f'Cached channels: {", ".join(cred_keys) if cred_keys else "none"}'))
    lines.append('')

    # 5. CDN — CHEVY health
    lines.append('[B]5. CDN — CHEVY health[/B]')
    try:
        _rh = requests.get(f'{CHEVY_LOOKUP}/health',
                           headers={'User-Agent': UA, 'Referer': PLAYER_REFERER},
                           timeout=6)
        if _rh.status_code == 200:
            _hd = _rh.json()
            _wk = _hd.get('workers', {})
            _dm = _hd.get('daemon', {})
            _pool_ok = (_hd.get('status', '?') == 'ok') and not _wk.get('poolExhausted', False)
            _connected = _dm.get('connected', False)
            _using_fb = _dm.get('using_fallback', False)
            _bans = _hd.get('honeypot', {}).get('active_bans', 0)
            _sl = _hd.get('server_locator', {})
            _sess = _hd.get('sessions', {}).get('active', 0)
            _rl = _hd.get('rate_limits', {})
            _pool_str = 'OK' if _pool_ok else 'EXHAUSTED'
            _fb_str = ' [fallback]' if _using_fb else ''
            _daemon_str = 'connected' if _connected else 'DISCO'
            _health_line = f'Pool {_pool_str} — daemon {_daemon_str}{_fb_str} — sessions {_sess}'
            lines.append(ok(_health_line) if (_pool_ok and _connected) else ko(_health_line))
            _bans_str = f' | Bans: {_bans}' if _bans else ''
            _rl_str = f' | RL auth:{_rl.get("auth_tracked_ips",0)} ch:{_rl.get("channel_tracked_ips",0)}'
            lines.append(info(f'Locator: {_sl.get("cache_size",0)} entries — hit {_sl.get("hit_rate_percent","?")}%{_bans_str}{_rl_str}'))
        else:
            lines.append(ko(f'Health HTTP {_rh.status_code}'))
    except Exception as _e5:
        lines.append(ko(f'Health: {type(_e5).__name__}: {str(_e5)[:60]}'))

    # 5b. Per-CDN freshness
    lines.append('')
    _CDN_DEFAULTS = {'ddy6': '773', 'wind': '464', 'zeko': '116'}
    _cdn_probe = dict(_CDN_DEFAULTS)
    if os.path.exists(_CDN_CACHE_FILE):
        try:
            with open(_CDN_CACHE_FILE, 'r') as _cf:
                for _ck2, _sk2 in sorted(json.load(_cf).items()):
                    if _sk2 not in _cdn_probe and _sk2 != 'nfs':
                        _cdn_probe[_sk2] = _ck2.replace('premium', '')
        except Exception:
            pass

    _now_ts = time.time()
    _ph_hdr = {'User-Agent': UA, 'Referer': PLAYER_REFERER}
    for _sk3, _cid3 in sorted(_cdn_probe.items()):
        try:
            _mr = requests.get(f'{CHEVY_PROXY}/proxy/{_sk3}/premium{_cid3}/mono.css',
                               headers=_ph_hdr, timeout=6)
            if _mr.status_code != 200:
                lines.append(ko(f'  {_sk3:<8} HTTP {_mr.status_code}  DEAD'))
                continue
            _mb = _mr.text
            _seq3 = (re.search(r'#EXT-X-MEDIA-SEQUENCE:(\d+)', _mb) or
                     type('', (), {'group': lambda s, i: '?'})()).group(1)
            _nseg3 = len(re.findall(r'#EXTINF:', _mb))
            _tgt3 = int((re.search(r'#EXT-X-TARGETDURATION:(\d+)', _mb) or
                         type('', (), {'group': lambda s, i: '6'})()).group(1))
            _age_str3, _vivant = '?', False
            _dt3_m = re.search(r'#EXT-X-PROGRAM-DATE-TIME:(\S+)', _mb)
            if _dt3_m:
                try:
                    _dt3 = datetime.fromisoformat(_dt3_m.group(1).replace('Z', '+00:00'))
                    _age3 = int(_now_ts - _dt3.timestamp())
                    _lag3 = _age3 - _nseg3 * _tgt3
                    _age_str3 = f'{_age3 // 60}min' if _age3 >= 60 else f'{_age3}s'
                    _vivant = _lag3 < 60
                except Exception:
                    pass
            _lat3 = _drop3 = ''
            _rt3_m = re.search(r'uploader-runtime: ([^\n]+)', _mb)
            if _rt3_m:
                _lm3 = re.search(r'latency=(\d+)ms', _rt3_m.group(1))
                _dm3 = re.search(r'drop=([\d.]+%)', _rt3_m.group(1))
                if _lm3: _lat3 = f'lat={_lm3.group(1)}ms'
                if _dm3: _drop3 = f'drop={_dm3.group(1)}'
            _parts3 = [f'seq={_seq3}', f'{_nseg3} segs']
            if _lat3:   _parts3.append(_lat3)
            if _drop3:  _parts3.append(_drop3)
            _parts3.append(f'age={_age_str3}')
            _det3 = '  '.join(_parts3)
            lines.append(ok(f'  {_sk3:<8} {_det3}  LIVE') if _vivant else
                         ko(f'  {_sk3:<8} {_det3}  FROZEN'))
        except Exception as _ex3:
            lines.append(ko(f'  {_sk3:<8} ERROR: {str(_ex3)[:60]}'))

    # 5c. Local CDN cache summary
    lines.append('')
    if os.path.exists(_CDN_CACHE_FILE):
        try:
            _age_m2 = int((time.time() - os.path.getmtime(_CDN_CACHE_FILE)) / 60)
            with open(_CDN_CACHE_FILE, 'r') as _f2:
                _cdn2 = json.load(_f2)
            _sk_c2 = {}
            for _sv2 in _cdn2.values():
                _sk_c2[_sv2] = _sk_c2.get(_sv2, 0) + 1
            _sum2 = ', '.join(f'{k}:{v}' for k, v in sorted(_sk_c2.items(), key=lambda x: -x[1]))
            lines.append(info(f'Local cache: {len(_cdn2)} ch — age {_age_m2}min — {_sum2}'))
        except Exception:
            lines.append(info('Local CDN cache: corrupted'))
    else:
        lines.append(info('Local CDN cache: empty (auto-filled by ProbeBackground)'))

    msg = '\n'.join(lines)
    log(f'[Diagnostics]\n{msg}')
    xbmcgui.Dialog().textviewer(f'DLTV v{version} — Diagnostics', msg)

def getCategTrans():
    schedule_url = abs_url('index.php')
    try:
        html_text = fetch_via_proxy(schedule_url, headers={'User-Agent': UA, 'Referer': get_active_base()})
        m = re.search(r'<div[^>]+class="filters"[^>]*>(.*?)</div>', html_text, re.IGNORECASE | re.DOTALL)
        if not m:
            log("getCategTrans(): filters block not found")
            return []

        block = m.group(1)
        anchors = re.findall(r'<a[^>]+href="([^"]+)"[^>]*>(.*?)</a>', block, re.IGNORECASE | re.DOTALL)
        if not anchors:
            log("getCategTrans(): no <a> items in filters block")
            return []

        categs = []
        seen = set()
        for href, text_content in anchors:
            name = html.unescape(re.sub(r'\s+', ' ', text_content)).strip()
            if not name or name.lower() == 'all':
                continue
            if name in seen:
                continue
            seen.add(name)
            categs.append((name, '[]'))

        return categs
    except Exception as e:
        xbmcgui.Dialog().ok("Error", f"Error fetching category data: {e}")
        log(f'index parse fail: url={schedule_url} err={e}')
        return []

def Menu_Trans():
    categs = getCategTrans()
    if not categs:
        return
    addDir('[B][COLOR cyan]Update schedule[/COLOR][/B]', build_url({'mode': 'menu', 'serv_type': 'refresh_schedule'}))
    for categ_name, _ in categs:
        addDir(categ_name, build_url({'mode': 'showChannels', 'trType': categ_name}))
    closeDir()

def ShowChannels(categ, channels_list):
    for item in channels_list:
        title = item.get('title')
        addDir(title, build_url({'mode': 'trList', 'trType': categ, 'channels': json.dumps(item.get('channels'))}), True)
    closeDir()

def getTransData(categ):
    try:
        url = abs_url('index.php?cat=' + quote_plus(categ))
        html_text = fetch_via_proxy(url, headers={'User-Agent': UA, 'Referer': get_active_base()})
        cut = re.search(r'<h2\s+class="collapsible-header\b', html_text, re.IGNORECASE)
        if cut:
            html_text = html_text[:cut.start()]

        events = re.findall(
            r'<div\s+class="schedule__event">.*?'
            r'<div\s+class="schedule__eventHeader"[^>]*?>\s*'
            r'(?:<[^>]+>)*?'
            r'<span\s+class="schedule__time"[^>]*data-time="([^"]+)"[^>]*>.*?</span>\s*'
            r'<span\s+class="schedule__eventTitle">\s*([^<]+)\s*</span>.*?'
            r'</div>\s*'
            r'<div\s+class="schedule__channels">(.*?)</div>',
            html_text, re.IGNORECASE | re.DOTALL
        )

        trns = []
        for time_str, event_title, channels_block in events:
            event_time_local = get_local_time(time_str.strip())
            title = f'[COLOR gold]{event_time_local}[/COLOR] {html.unescape(event_title.strip())}'

            chans = []
            for href, title_attr, link_text in re.findall(
                r'<a[^>]+href="([^"]+)"[^>]*title="([^"]*)"[^>]*>(.*?)</a>',
                channels_block, re.IGNORECASE | re.DOTALL
            ):
                try:
                    u = urlparse(href)
                    qs = dict(parse_qsl(u.query))
                    cid = qs.get('id') or ''
                except Exception:
                    cid = ''
                name = html.unescape((title_attr or link_text).strip())
                if cid:
                    chans.append({'channel_name': name, 'channel_id': cid})

            if chans:
                trns.append({'title': title, 'channels': chans})

        return trns
    except Exception as e:
        log(f'getTransData error for categ={categ}: {e}')
        return []

def TransList(categ, channels):
    dead_cids = _get_dead_cids()
    fav_ids = {f['id'] for f in get_favorites()}
    for channel in channels:
        channel_title = html.unescape(channel.get('channel_name'))
        channel_id = str(channel.get('channel_id', '')).strip()
        if not channel_id:
            continue
        label = f'{_ch_label(channel_title, channel_id, dead_cids)} ({channel_id})'
        fav_label = '★ Remove from favorites' if channel_id in fav_ids else '☆ Add to favorites'
        ctx = [(fav_label, 'RunPlugin(%s)' % build_url({'mode': 'toggle_fav', 'cid': channel_id, 'name': channel_title}))]
        addDir(label, build_url({'mode': 'trLinks', 'trData': json.dumps({'channels': [{'channel_name': channel_title, 'channel_id': channel_id}]})}), False, context_menu=ctx)
    closeDir()

def getSource(trData):
    try:
        data = json.loads(unquote(trData))
        channels_data = data.get('channels')
        if channels_data and isinstance(channels_data, list):
            cid = str(channels_data[0].get('channel_id', '')).strip()
            if not cid:
                return
            if '%7C' in cid or '|' in cid:
                url_stream = abs_url('watchs2watch.php?id=' + cid)
            else:
                url_stream = abs_url('watch.php?id=' + cid)
            xbmcplugin.setContent(addon_handle, 'videos')
            PlayStream(url_stream)
    except Exception as e:
        log(f'getSource failed: {e}')

def get_favorites():
    try:
        return json.loads(addon.getSetting('favorites') or '[]')
    except Exception:
        return []

def save_favorites(favs):
    addon.setSetting('favorites', json.dumps(favs))

def toggle_favorite(cid, name):
    favs = get_favorites()
    ids = [f['id'] for f in favs]
    if cid in ids:
        favs = [f for f in favs if f['id'] != cid]
        save_favorites(favs)
        xbmcgui.Dialog().notification('DLTV', f'Removed from favorites: {name}', ICON, 2000)
    else:
        favs.append({'id': cid, 'name': name})
        save_favorites(favs)
        xbmcgui.Dialog().notification('DLTV', f'Added to favorites: {name}', ICON, 2000)
    xbmc.executebuiltin('Container.Refresh')


_KNOWN_CDNS = [
    ('Direct HLS (premiumtv, envelopes PNG deballées)', '__premiumtv__'),
    ('Direct HLS (wideiptv)',  '__wideiptv__'),
    ('Direct HLS (wideiptv)',  '__wideiptv__'),
    ('Auto — Player direct',  '__anyplayer__'),
    ('Auto — CHEVY (CDN)',    None),
]

# Order the cascade walks the backends when the preferred one cannot deliver video.
# premiumtv/wideiptv first: cheap (one page + one manifest probe each) and they give
# a clear reachable/placeholder verdict. __anyplayer__ scans six player pages, so it
# comes last-but-one. CHEVY (None) is the broadest but slowest fallback.
# Order and membership, from measurements over 26 channels:
#   wideiptv  — direct MPEG-TS, no portal request once the slug is cached, but the
#               CDN answered 404 for 6 of 24 slugs, so it cannot be the only option.
#   premiumtv — its segments are MPEG-TS wrapped inside a PNG envelope, which
#               /raw/ now unwraps (see _unwrap_ptv_segment). It covers channels the
#               wideiptv CDN has no content for, at the cost of a portal request.
#   the rest  — CHEVY, ksohls and StreamPage upstreams have been dead for weeks.
_PLAYBACK_CASCADE = ['__wideiptv__', '__premiumtv__', '__anyplayer__', '__streampage__', None]

# Playback always goes through the cascade, so asking the user to pick a backend on
# every click only changed the order of the attempts, never the outcome. The manual
# list is therefore only offered as a rescue once every backend has failed.
_AUTOPLAY_CDN = '__auto__'
_MANUAL_CDNS = [(lb, v) for lb, v in _KNOWN_CDNS if v is not None] + \
               [('Auto — CHEVY (CDN)', None)]

_CDN_LABELS = {v: lb for lb, v in _MANUAL_CDNS}
_CDN_LABELS['__streampage__'] = 'Auto — StreamPage (enviromentalspace)'

def list_favorites():
    favs = get_favorites()
    if not favs:
        xbmcgui.Dialog().notification('DLTV', 'No favorites. Long press a channel to add.', ICON, 3000)
        closeDir()
        return
    # Auto-probe on first open (cooldown of 120s prevents re-running on every open)
    _probe_favorites_background(favs)
    fav_ids = {f['id'] for f in favs}
    dead_cids = _get_dead_cids()
    # Load CDN map from cache to show CDN name on red channels
    _fav_cdn_map = {}
    try:
        if os.path.exists(_CDN_CACHE_FILE):
            with open(_CDN_CACHE_FILE, 'r') as _f:
                _fav_cdn_map = json.load(_f)
    except Exception:
        pass
    ev_map = _build_current_events_map()
    # EPG (epgshare01 XMLTV) has priority over the DLTV sports schedule
    xmltv_programs = _fetch_xmltv_background([(f['id'], f['name']) for f in favs])
    ev_map.update(xmltv_programs)
    addDir('[B][COLOR cyan]Check Channels[/COLOR][/B]', build_url({'mode': 'probe_favorites'}), False)
    addDir('[B][COLOR lime]+ Add channel by ID[/COLOR][/B]', build_url({'mode': 'add_by_id'}), False)
    for fav in sorted(favs, key=lambda x: x['name'].lower()):
        cid = fav['id']
        name = fav['name']
        cdn_name = _fav_cdn_map.get(cid) if cid in dead_cids else None
        ctx = [('Remove from favorites', 'RunPlugin(%s)' % build_url({'mode': 'toggle_fav', 'cid': cid, 'name': name}))]
        ev = ev_map.get(cid)
        label = f'{_ch_label(name, cid, dead_cids, cdn_name)} ({cid})'
        if ev:
            label += f'  [COLOR gold]{ev}[/COLOR]'
        addDir(label, build_url({'mode': 'play', 'url': abs_url('watch.php?id=' + cid)}), False, context_menu=ctx, plot=ev)
    closeDir()

def _normalize_ch_name(name):
    name = name.lower().strip()
    name = re.sub(r'[^\w\s]', ' ', name)
    name = re.sub(r'([a-z])(\d)', r'\1 \2', name)  # "sport360" → "sport 360"
    name = re.sub(r'\s+', ' ', name).strip()
    return name

# Pass 1 — language/country words (≥3 chars) present anywhere in the channel name
_NAME_TO_LANG = {
    # Language adjectives
    'arabic': 'ara', 'arab': 'ara',
    'english': 'eng', 'british': 'eng', 'scottish': 'eng', 'welsh': 'eng', 'irish': 'eng',
    'french': 'fra',
    'german': 'deu', 'deutsch': 'deu',
    'spanish': 'spa',
    'italian': 'ita',
    'portuguese': 'por',
    'turkish': 'tur',
    'russian': 'rus',
    'polish': 'pol',
    'romanian': 'ron',
    'dutch': 'nld',
    'greek': 'ell',
    'hebrew': 'heb',
    'persian': 'fas', 'farsi': 'fas',
    'hindi': 'hin', 'indian': 'hin',
    'urdu': 'urd',
    'swedish': 'swe',
    'norwegian': 'nor',
    'danish': 'dan',
    'finnish': 'fin',
    'czech': 'ces',
    'slovak': 'slk',
    'croatian': 'hrv',
    'serbian': 'srp',
    'bulgarian': 'bul',
    'hungarian': 'hun',
    'slovenian': 'slv',
    'albanian': 'sqi',
    'ukrainian': 'ukr',
    'malay': 'msa', 'malaysian': 'msa',
    'indonesian': 'ind',
    'chinese': 'zho',
    'japanese': 'jpn',
    'korean': 'kor',
    'thai': 'tha',
    'vietnamese': 'vie',
    'australian': 'eng', 'canadian': 'eng',
    'egyptian': 'ara', 'moroccan': 'ara', 'algerian': 'ara', 'tunisian': 'ara',
    'lebanese': 'ara', 'iraqi': 'ara', 'jordanian': 'ara', 'kuwaiti': 'ara',
    'bahraini': 'ara', 'omani': 'ara', 'qatari': 'ara', 'saudi': 'ara',
    'emirati': 'ara', 'syrian': 'ara', 'libyan': 'ara', 'yemeni': 'ara',
    # Noms de pays Europe
    'france': 'fra',
    'usa': 'eng', 'america': 'eng', 'american': 'eng',
    'germany': 'deu',
    'spain': 'spa', 'espana': 'spa',
    'italy': 'ita',
    'portugal': 'por',
    'netherlands': 'nld',
    'turkey': 'tur',
    'russia': 'rus',
    'poland': 'pol',
    'romania': 'ron',
    'greece': 'ell',
    'israel': 'heb',
    'iran': 'fas',
    'india': 'hin',
    'pakistan': 'urd',
    'malaysia': 'msa',
    'indonesia': 'ind',
    'china': 'zho',
    'japan': 'jpn',
    'korea': 'kor',
    'thailand': 'tha',
    'vietnam': 'vie',
    'brazil': 'por', 'brasil': 'por',
    'mexico': 'spa',
    'argentina': 'spa',
    'colombia': 'spa',
    'belgium': 'fra',
    'switzerland': 'deu',
    'austria': 'deu',
    'sweden': 'swe',
    'norway': 'nor',
    'denmark': 'dan',
    'finland': 'fin',
    # Noms de pays manquants (formes substantif)
    'bulgaria': 'bul',
    'serbia': 'srp',
    'croatia': 'hrv',
    'cyprus': 'ell',
    'ukraine': 'ukr',
    'slovenia': 'slv',
    'albania': 'sqi',
    'scotland': 'eng', 'ireland': 'eng', 'wales': 'eng',
    'australia': 'eng', 'canada': 'eng',
    # Pays arabes
    'qatar': 'ara',
    'egypt': 'ara',
    'morocco': 'ara',
    'algeria': 'ara',
    'tunisia': 'ara',
    'lebanon': 'ara',
    'iraq': 'ara',
    'jordan': 'ara',
    'kuwait': 'ara',
    'bahrain': 'ara',
    'oman': 'ara',
    'uae': 'ara',
    'syria': 'ara',
    'libya': 'ara',
    'sudan': 'ara',
    'yemen': 'ara',
    # French country names (Canal+/beIN channels)
    'afrique': 'fra',   # Canal+ Sport Afrique → français
}

# Pass 1 — 2-letter ISO codes, checked ONLY as the last word of the name
_CODE_TO_LANG = {
    'fr': 'fra', 'de': 'deu', 'es': 'spa', 'it': 'ita', 'pt': 'por',
    'nl': 'nld', 'tr': 'tur', 'ru': 'rus', 'pl': 'pol', 'ro': 'ron',
    'gr': 'ell', 'il': 'heb', 'ae': 'ara', 'sa': 'ara', 'ar': 'ara',
    'uk': 'eng', 'us': 'eng', 'gb': 'eng', 'au': 'eng', 'ca': 'eng',
    'be': 'fra', 'ch': 'deu', 'at': 'deu',
    'se': 'swe', 'no': 'nor', 'dk': 'dan', 'fi': 'fin',
    'hr': 'hrv', 'rs': 'srp', 'bg': 'bul', 'hu': 'hun',
    'sk': 'slk', 'cz': 'ces', 'si': 'slv', 'al': 'sqi',
    'ua': 'ukr', 'ie': 'eng', 'nz': 'eng', 'za': 'eng',
    'pk': 'urd', 'mx': 'spa', 'br': 'por',
    'my': 'msa', 'cn': 'zho', 'jp': 'jpn', 'kr': 'kor',
    'th': 'tha', 'vn': 'vie',
    'eg': 'ara', 'ma': 'ara', 'dz': 'ara', 'tn': 'ara',
    'lb': 'ara', 'qa': 'ara', 'iq': 'ara', 'jo': 'ara',
    'kw': 'ara', 'bh': 'ara', 'om': 'ara', 'sy': 'ara',
    'cy': 'ell',
}


def _lang_from_name(name):
    """Pass 1: detect language from explicit words in the channel name.
    - Last word: checked in _NAME_TO_LANG AND _CODE_TO_LANG.
    - Other words (right→left): _NAME_TO_LANG only (no 2-letter codes).
    Returns a language code or None."""
    words = re.findall(r'[a-z]+', name.lower())
    if not words:
        return None
    last = words[-1]
    if last in _NAME_TO_LANG:
        return _NAME_TO_LANG[last]
    if last in _CODE_TO_LANG:
        return _CODE_TO_LANG[last]
    for word in reversed(words[:-1]):
        if word in _NAME_TO_LANG:
            return _NAME_TO_LANG[word]
    return None

def _get_iptv_org_index():
    """Fetch/cache iptv-org channels.json, return normalized_name→lang_code index."""
    if os.path.exists(IPTV_ORG_INDEX_CACHE):
        if time.time() - os.path.getmtime(IPTV_ORG_INDEX_CACHE) < IPTV_ORG_TTL:
            try:
                with open(IPTV_ORG_INDEX_CACHE, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception:
                pass
    try:
        log('[iptv-org] Fetching channels database...')
        r = requests.get(IPTV_ORG_API, timeout=30)
        size_kb = len(r.content) // 1024
        log(f'[iptv-org] Downloaded {size_kb} KB (encoding: {r.headers.get("Content-Encoding", "none")})')
        index = {}
        tvg_index = {}  # normalized_name → tvg_id (e.g. "BBCOne.uk")
        for ch in r.json():
            tvg_id = ch.get('id', '')
            country = ch.get('country', '')
            lang = COUNTRY_LANG.get(country)
            candidates = [ch.get('name', '')] + ch.get('alt_names', [])
            for candidate in candidates:
                norm = _normalize_ch_name(candidate)
                if norm and tvg_id and norm not in tvg_index:
                    tvg_index[norm] = tvg_id
            if not lang:
                continue
            for candidate in candidates:
                norm = _normalize_ch_name(candidate)
                if norm and norm not in index:
                    index[norm] = lang
        with open(IPTV_ORG_INDEX_CACHE, 'w', encoding='utf-8') as f:
            json.dump(index, f)
        with open(IPTV_ORG_TVG_CACHE, 'w', encoding='utf-8') as f:
            json.dump(tvg_index, f)
        log(f'[iptv-org] Index built: {len(index)} entries, {len(tvg_index)} tvg IDs')
        return index
    except Exception as e:
        log(f'[iptv-org] Fetch error: {e}')
        return {}

def _lookup_lang(name, index):
    """Return the language code for a channel.
    Pass 1: detection from name words (explicit country/language).
    Pass 2: lookup in iptv-org index with progressive normalizations."""
    # Pass 1 — nom seul, sans index
    lang = _lang_from_name(name)
    if lang:
        return lang

    # Pass 2 — index iptv-org
    # Normalize the name, then progressively strip country/language suffixes
    # to improve match chances in the index.
    norm = _normalize_ch_name(name)

    # 2a. Exact match
    if norm in index:
        return index[norm]

    # 2b. Strip trailing number ("Sky Sports 1" → "Sky Sports")
    no_num = re.sub(r'\s+\d+$', '', norm).strip()
    if no_num != norm and no_num in index:
        return index[no_num]

    # 2c. Strip the last word if it is a country/language indicator,
    #     then search again (with and without trailing number)
    parts = norm.split()
    if len(parts) > 1:
        last_word = parts[-1]
        if last_word in _NAME_TO_LANG or last_word in _CODE_TO_LANG:
            stripped = ' '.join(parts[:-1]).strip()
            if stripped in index:
                return index[stripped]
            no_num2 = re.sub(r'\s+\d+$', '', stripped).strip()
            if no_num2 != stripped and no_num2 in index:
                return index[no_num2]

    return None


def _channel_name_to_tvg_id(name, tvg_index):
    """Map a DLTV channel name to an iptv-org tvg_id using progressive name stripping."""
    norm = _normalize_ch_name(name)
    if norm in tvg_index:
        return tvg_index[norm]
    # Remove trailing quality/number suffix: HD, SD, FHD, UHD, 4K, +1, digits
    stripped = re.sub(r'\s+(?:hd|sd|fhd|uhd|4k|\+\d+|\d+)$', '', norm).strip()
    if stripped != norm and stripped in tvg_index:
        return tvg_index[stripped]
    # Remove trailing number only
    no_num = re.sub(r'\s+\d+$', '', stripped or norm).strip()
    if no_num not in (norm, stripped) and no_num in tvg_index:
        return tvg_index[no_num]
    # Remove trailing country/lang word
    parts = (stripped or norm).split()
    if len(parts) > 1 and parts[-1] in _NAME_TO_LANG:
        base = ' '.join(parts[:-1]).strip()
        if base in tvg_index:
            return tvg_index[base]
        base_no_num = re.sub(r'\s+\d+$', '', base).strip()
        if base_no_num != base and base_no_num in tvg_index:
            return tvg_index[base_no_num]
    return None


def _fetch_xmltv_fr_epg(cid_name_pairs):
    """Return {cid: current_program_title} from epgshare01 XMLTV sources selected in settings.

    Downloads each enabled language gz once every 4h, merges XML, caches results 30min.
    cid_name_pairs: list of (dltv_channel_id, channel_name)
    """
    if not cid_name_pairs:
        return {}
    now_ts = time.time()

    # Load 30-min program cache
    prog_cache = {}
    try:
        if os.path.exists(_XMLTV_PROG_CACHE) and now_ts - os.path.getmtime(_XMLTV_PROG_CACHE) < _XMLTV_PROG_TTL:
            with open(_XMLTV_PROG_CACHE, 'r', encoding='utf-8') as f:
                prog_cache = json.load(f)
    except Exception:
        pass

    need_lookup = [p for p in cid_name_pairs if p[0] not in prog_cache]
    if not need_lookup:
        return {cid: prog_cache[cid] for cid, _ in cid_name_pairs if prog_cache.get(cid)}

    # Determine enabled sources from settings
    enabled = [sid for sid in _XMLTV_SOURCES if addon.getSetting(sid).lower() == 'true']
    log(f'[xmltv] enabled sources: {enabled}')
    if not enabled:
        enabled = ['epg_fr']  # fallback to French if nothing selected

    # Download/cache each enabled source and merge XML
    xml_parts = []
    for sid in enabled:
        label, url, cache_fname = _XMLTV_SOURCES[sid]
        cache_file = os.path.join(_KODI_TEMP, cache_fname)
        xml_gz = None
        if os.path.exists(cache_file) and now_ts - os.path.getmtime(cache_file) < _XMLTV_TTL:
            try:
                with open(cache_file, 'rb') as f:
                    xml_gz = f.read()
            except Exception:
                pass
        if xml_gz is None:
            try:
                log(f'[xmltv] Downloading {label} EPG...')
                resp = requests.get(url, timeout=30, headers={'User-Agent': UA})
                xml_gz = resp.content
                with open(cache_file, 'wb') as f:
                    f.write(xml_gz)
                log(f'[xmltv] {label}: {len(xml_gz)//1024}KB')
            except Exception as e:
                log(f'[xmltv] {label} download error: {e}')
                continue
        try:
            xml_parts.append(gzip.decompress(xml_gz).decode('utf-8', errors='replace'))
        except Exception as e:
            log(f'[xmltv] {label} decompress error: {e}')

    if not xml_parts:
        return {}

    xml_str = '\n'.join(xml_parts)

    # Collect channel IDs that actually have programme entries (some IDs are defined but empty)
    active_channels = set(re.findall(r'<programme channel="([^"]+)"', xml_str))

    # Build display_name → xmltv_id index, preferring IDs that have programme data
    xmltv_idx = {}
    for xmltv_id, display_name in re.findall(
        r'<channel id="([^"]+)"[^>]*>.*?<display-name[^>]*>([^<]+)</display-name>',
        xml_str, re.DOTALL
    ):
        norm = _normalize_ch_name(display_name)
        if not norm:
            continue
        if norm not in xmltv_idx:
            xmltv_idx[norm] = xmltv_id
        elif xmltv_id in active_channels and xmltv_idx[norm] not in active_channels:
            # Replace inactive ID with one that actually has programmes
            xmltv_idx[norm] = xmltv_id

    # Match each DLTV channel name to an XMLTV ID
    cid_to_xmltv = {}
    for cid, name in need_lookup:
        xmltv_id = _channel_name_to_tvg_id(name, xmltv_idx)
        if xmltv_id:
            cid_to_xmltv[cid] = xmltv_id
        else:
            prog_cache[cid] = ''  # no match, don't retry until cache expires

    if not cid_to_xmltv:
        try:
            with open(_XMLTV_PROG_CACHE, 'w', encoding='utf-8') as f:
                json.dump(prog_cache, f)
        except Exception:
            pass
        return {}

    # Parse timestamps helper (uses datetime/timezone/timedelta imported at module level)
    def _parse_xmltv_ts(s):
        s = s.strip()
        main = s[:14]
        tz = s[15:] if len(s) > 14 else '+0000'
        dt = datetime.strptime(main, '%Y%m%d%H%M%S')
        sign = 1 if tz[0] == '+' else -1
        h, m = int(tz[1:3]), int(tz[3:5])
        return (datetime(*dt.timetuple()[:6]) - timedelta(hours=h*sign, minutes=m*sign)).replace(tzinfo=timezone.utc).timestamp()

    # Scan programmes for matching XMLTV IDs
    target_xmltv = set(cid_to_xmltv.values())
    xmltv_to_program = {}
    for m in re.finditer(
        r'<programme channel="([^"]+)" start="([^"]+)" stop="([^"]+)"[^>]*>.*?<title[^>]*>([^<]+)</title>',
        xml_str, re.DOTALL
    ):
        xmltv_id, start_str, stop_str, title = m.groups()
        if xmltv_id not in target_xmltv or xmltv_id in xmltv_to_program:
            continue
        try:
            if _parse_xmltv_ts(start_str) <= now_ts <= _parse_xmltv_ts(stop_str):
                xmltv_to_program[xmltv_id] = html.unescape(title)
        except Exception:
            pass

    for cid, xmltv_id in cid_to_xmltv.items():
        prog_cache[cid] = xmltv_to_program.get(xmltv_id, '')

    try:
        with open(_XMLTV_PROG_CACHE, 'w', encoding='utf-8') as f:
            json.dump(prog_cache, f)
    except Exception:
        pass

    return {cid: prog_cache[cid] for cid, _ in cid_name_pairs if prog_cache.get(cid)}


def _fetch_xmltv_background(cid_name_pairs):
    """Return existing EPG cache without blocking; start a background refresh if stale."""
    cached = {}
    try:
        if os.path.exists(_XMLTV_PROG_CACHE):
            with open(_XMLTV_PROG_CACHE, 'r', encoding='utf-8') as f:
                prog_cache = json.load(f)
            cached = {cid: prog_cache[cid] for cid, _ in cid_name_pairs if prog_cache.get(cid)}
    except Exception:
        pass

    cache_fresh = (os.path.exists(_XMLTV_PROG_CACHE) and
                   time.time() - os.path.getmtime(_XMLTV_PROG_CACHE) < _XMLTV_PROG_TTL)
    if not cache_fresh:
        if _epg_bg_lock.acquire(blocking=False):
            def _run():
                try:
                    log('[EPGBackground] Starting XMLTV refresh...')
                    _fetch_xmltv_fr_epg(cid_name_pairs)
                    log('[EPGBackground] Done — refreshing container')
                    xbmc.executebuiltin('Container.Refresh')
                except Exception as e:
                    log(f'[EPGBackground] Error: {e}')
                finally:
                    _epg_bg_lock.release()
            threading.Thread(target=_run, daemon=True).start()

    return cached


def list_by_language():
    """Show language folders for all 24/7 channels."""
    xbmcgui.Dialog().notification('DLTV', 'Loading language index...', ICON, 2000)
    ch_list = channels()
    if not ch_list:
        closeDir()
        return
    index = _get_iptv_org_index()
    if not index:
        xbmcgui.Dialog().notification('DLTV', 'iptv-org index unavailable', ICON, 4000)
        closeDir()
        return
    lang_counts = {}
    unclassified = 0
    for href, name in ch_list:
        lang = _lookup_lang(name, index)
        if lang:
            lang_counts[lang] = lang_counts.get(lang, 0) + 1
        else:
            unclassified += 1
    for lang_code, count in sorted(lang_counts.items(), key=lambda x: -x[1]):
        lang_name = LANG_NAMES.get(lang_code, lang_code.upper())
        addDir(f'[B]{lang_name}[/B]  ({count})', build_url({'mode': 'lang_channels', 'lang': lang_code}), True)
    if unclassified:
        addDir(f'[Unclassified]  ({unclassified})', build_url({'mode': 'lang_channels', 'lang': '__none__'}), True)
    closeDir()

def list_lang_channels(lang_code):
    """Show channels matching a language code (or unclassified if lang_code='__none__')."""
    xbmcplugin.setContent(addon_handle, 'videos')
    ch_list = channels()
    index = _get_iptv_org_index()
    fav_ids = {f['id'] for f in get_favorites()}
    dead_cids = _get_dead_cids()
    for href, name in ch_list:
        cid_m = re.search(r'id=(\d+)', href)
        cid = cid_m.group(1) if cid_m else ''
        ch_lang = _lookup_lang(name, index) if index else None
        if lang_code == '__none__':
            if ch_lang is not None:
                continue
        else:
            if ch_lang != lang_code:
                continue
        fav_label = '★ Remove from favorites' if cid in fav_ids else '☆ Add to favorites'
        ctx = [(fav_label, 'RunPlugin(%s)' % build_url({'mode': 'toggle_fav', 'cid': cid, 'name': name}))] if cid else []
        label = f'{_ch_label(name, cid, dead_cids)} ({cid})' if cid else name
        addDir(label, build_url({'mode': 'play', 'url': abs_url(href)}), False, context_menu=ctx)
    closeDir()

def _get_cdn_dead_servers():
    """Return frozenset of server_keys currently KO. Cached 5 min to file."""
    try:
        if os.path.exists(_CDN_STATUS_CACHE_FILE) and \
                time.time() - os.path.getmtime(_CDN_STATUS_CACHE_FILE) < _CDN_STATUS_TTL:
            with open(_CDN_STATUS_CACHE_FILE, 'r') as f:
                return frozenset(json.load(f))
    except Exception:
        pass
    dead = set()
    try:
        resp = requests.get(f'{CHEVY_LOOKUP}/health',
                            headers={'User-Agent': UA, 'Referer': PLAYER_REFERER},
                            timeout=3)
        if resp.status_code == 200:
            hdata = resp.json()
            top_status = hdata.get('status', 'ok')
            workers = hdata.get('workers', {})
            daemon = hdata.get('daemon', {})
            pool_ex = workers.get('poolExhausted', False)
            # favorites workers can serve traffic even when pool is exhausted
            favorites_count = daemon.get('favorites_count', 0)
            connected = daemon.get('connected', True)
            # CDN is truly KO only if status is not ok, OR pool exhausted with no fallback at all
            globally_ko = (top_status != 'ok') or (pool_ex and favorites_count == 0 and not connected)
            if globally_ko:
                for sk in workers.get('servers', {}):
                    dead.add(sk)
    except Exception:
        pass
    try:
        with open(_CDN_STATUS_CACHE_FILE, 'w') as f:
            json.dump(list(dead), f)
    except Exception:
        pass
    return frozenset(dead)

def _refresh_favorites_debounced():
    """Trigger Container.Refresh at most once every _FAV_REFRESH_DEBOUNCE seconds."""
    try:
        try:
            with open(_FAV_REFRESH_TS_FILE) as _f:
                last_ts = float(_f.read().strip())
        except Exception:
            last_ts = 0
        now = time.time()
        if now - last_ts < _FAV_REFRESH_DEBOUNCE:
            return
        with open(_FAV_REFRESH_TS_FILE, 'w') as _f:
            _f.write(str(now))
        xbmc.executebuiltin('Container.Refresh')
        log('[FailedCache] Container.Refresh triggered (channel marked KO)')
    except Exception:
        pass


def _mark_channel_failed(channel_key):
    """Record a channel content failure (no valid video segments) for red-label coloring."""
    try:
        failed = {}
        if os.path.exists(_FAILED_CHANNELS_FILE):
            with open(_FAILED_CHANNELS_FILE, 'r') as f:
                failed = json.load(f)
        now = time.time()
        failed[channel_key] = now
        # Prune expired entries while we have the file open
        failed = {k: v for k, v in failed.items() if now - v < _FAILED_CHANNEL_TTL}
        _dir = os.path.dirname(_FAILED_CHANNELS_FILE)
        fd, tmp_path = tempfile.mkstemp(dir=_dir)
        try:
            with os.fdopen(fd, 'w') as f:
                json.dump(failed, f)
            os.replace(tmp_path, _FAILED_CHANNELS_FILE)
        except Exception:
            try:
                os.unlink(tmp_path)
            except Exception:
                pass
            raise
    except Exception:
        pass
    # Debounced Container.Refresh so favorites list updates when user returns to it
    _refresh_favorites_debounced()


def _clear_channel_failed(channel_key):
    """Remove a channel from the failed cache (probe confirmed it's working again)."""
    try:
        if not os.path.exists(_FAILED_CHANNELS_FILE):
            return False
        with open(_FAILED_CHANNELS_FILE, 'r') as f:
            failed = json.load(f)
        if channel_key in failed:
            del failed[channel_key]
            _dir = os.path.dirname(_FAILED_CHANNELS_FILE)
            fd, tmp_path = tempfile.mkstemp(dir=_dir)
            try:
                with os.fdopen(fd, 'w') as f:
                    json.dump(failed, f)
                os.replace(tmp_path, _FAILED_CHANNELS_FILE)
            except Exception:
                try:
                    os.unlink(tmp_path)
                except Exception:
                    pass
                raise
            return True
    except Exception:
        pass
    return False


def _probe_favorites_background(favs, force=False):
    """Probe each favorite channel's m3u8 in background; update failed cache and refresh list."""
    log(f'[ProbeBackground] Called with {len(favs)} favorites (force={force})')
    with _probe_lock:
        now = time.time()
        if not force:
            # Cooldown persisted in a file so it survives across Kodi plugin invocations
            try:
                with open(_FAV_PROBE_TS_FILE) as _f:
                    last_ts = float(_f.read().strip())
            except Exception:
                last_ts = 0
            elapsed = now - last_ts
            if elapsed < _FAV_PROBE_COOLDOWN:
                log(f'[ProbeBackground] Skipped — cooldown ({int(_FAV_PROBE_COOLDOWN - elapsed)}s remaining)')
                return
        # Mark probe as started immediately to avoid race between concurrent addon invocations
        try:
            with open(_FAV_PROBE_TS_FILE, 'w') as _f:
                _f.write(str(now))
        except Exception:
            pass

    log(f'[ProbeBackground] Launching background thread')

    def _run():
        try:
            log(f'[ProbeBackground] Thread started — probing {len(favs)} favorites')
            # Load CDN map for server keys (from cache — no blocking rebuild)
            cdn_map = {}
            try:
                if os.path.exists(_CDN_CACHE_FILE):
                    with open(_CDN_CACHE_FILE, 'r') as f:
                        cdn_map = json.load(f)
                log(f'[ProbeBackground] CDN cache loaded ({len(cdn_map)} entries)')
            except Exception as e:
                log(f'[ProbeBackground] CDN cache load failed: {e}')

            def probe_one(fav):
                cid = fav['id']
                channel_key = f'premium{cid}'
                sk = cdn_map.get(cid)
                if not sk or sk == 'unknown':
                    # Try live lookup — quick, already cached by chevy
                    try:
                        resp = _get_session().get(
                            f'{CHEVY_LOOKUP}/server_lookup?channel_id={channel_key}',
                            headers={'User-Agent': UA, 'Referer': PLAYER_REFERER},
                            timeout=3
                        )
                        sk = resp.json().get('server_key', 'unknown')
                    except Exception:
                        sk = 'unknown'
                if sk == 'unknown':
                    log(f'[ProbeBackground] {channel_key}: no server key — skipped')
                    return cid, sk, None  # skip — no server key
                url = f'{CHEVY_PROXY}/proxy/{sk}/{channel_key}/mono.css'
                ok = _probe_hls_url(url)
                log(f'[ProbeBackground] {channel_key} ({sk}): {"OK" if ok else "KO" if ok is False else "skip"}')
                return cid, sk, ok

            with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
                results = list(executor.map(probe_one, favs))

            # Persist discovered server keys back into the CDN cache
            try:
                updated_cdn = dict(cdn_map)
                for cid, sk, _ in results:
                    if sk and sk != 'unknown':
                        updated_cdn[cid] = sk
                if updated_cdn != cdn_map:
                    with open(_CDN_CACHE_FILE, 'w') as _wf:
                        json.dump(updated_cdn, _wf)
            except Exception as _ce:
                log(f'[ProbeBackground] CDN cache write failed: {_ce}')

            n_ok = sum(1 for _, _sk, ok in results if ok is True)
            n_ko = sum(1 for _, _sk, ok in results if ok is False)
            n_skip = sum(1 for _, _sk, ok in results if ok is None)
            changed = False
            for cid, _sk, ok in results:
                channel_key = f'premium{cid}'
                if ok is False:
                    _mark_channel_failed(channel_key)
                    changed = True
                    log(f'[ProbeBackground] {channel_key}: KO → marked red')
                elif ok is True:
                    if _clear_channel_failed(channel_key):
                        changed = True
                        log(f'[ProbeBackground] {channel_key}: OK → cleared red')

            if changed:
                xbmc.executebuiltin('Container.Refresh')
            log(f'[ProbeBackground] Done — {n_ok} OK / {n_ko} KO / {n_skip} skip — {"refreshed" if changed else "no change"}')
        except Exception as e:
            log(f'[ProbeBackground] Error: {e}')
            import traceback
            log(f'[ProbeBackground] Traceback: {traceback.format_exc()}')

    threading.Thread(target=_run, daemon=True).start()


def _get_dead_cids():
    """Return frozenset of channel IDs: CDN KO servers + recently failed content."""
    dead = set()
    # CDN server health
    dead_servers = _get_cdn_dead_servers()
    if dead_servers:
        try:
            if os.path.exists(_CDN_CACHE_FILE):
                with open(_CDN_CACHE_FILE, 'r') as f:
                    cdn_map = json.load(f)
                dead.update(cid for cid, sk in cdn_map.items() if sk in dead_servers)
        except Exception:
            pass
    # Proxy-level content failures (no valid video segments served)
    try:
        if os.path.exists(_FAILED_CHANNELS_FILE):
            with open(_FAILED_CHANNELS_FILE, 'r') as f:
                failed = json.load(f)
            now = time.time()
            for k, t in failed.items():
                if now - t < _FAILED_CHANNEL_TTL:
                    m = re.match(r'^premium(\d+)$', k)
                    if m:
                        dead.add(m.group(1))
    except Exception:
        pass
    return frozenset(dead)

def _ch_label(name, cid, dead_cids, cdn_name=None):
    """Wrap label in red if channel is KO. Optionally append CDN name."""
    if cid and cid in dead_cids:
        suffix = f' ({cdn_name})' if cdn_name else ''
        return f'[COLOR red]{name}{suffix}[/COLOR]'
    return name

def list_gen():
    chData = channels()
    if not chData:
        xbmcgui.Dialog().notification('DLTV', 'Failed to load channels. Check your connection.', ICON, 5000)
        log('[list_gen] channels() returned empty list')
    fav_ids = {f['id'] for f in get_favorites()}
    dead_cids = _get_dead_cids()
    ev_map = _build_current_events_map()
    for href, name in chData:
        cid_m = re.search(r'id=(\d+)', href)
        cid = cid_m.group(1) if cid_m else ''
        fav_label = '★ Remove from favorites' if cid in fav_ids else '☆ Add to favorites'
        ctx = [(fav_label, 'RunPlugin(%s)' % build_url({'mode': 'toggle_fav', 'cid': cid, 'name': name}))] if cid else []
        label = f'{_ch_label(name, cid, dead_cids)} ({cid})' if cid else name
        ev = ev_map.get(cid) if cid else None
        if ev:
            label += f'  [COLOR gold]{ev}[/COLOR]'
        addDir(label, build_url({'mode': 'play', 'url': abs_url(href)}), False, context_menu=ctx, plot=ev)
    closeDir()

_CARD_RX = re.compile(
    r'<a\s+class="card"[^>]*?href="(?P<href>[^"]+)"[^>]*?data-title="(?P<data_title>[^"]*)"[^>]*>'
    r'.*?<div\s+class="card__title">\s*(?P<title>.*?)\s*</div>'
    r'.*?ID:\s*(?P<id>\d+)\s*</div>'
    r'.*?</a>',
    re.IGNORECASE | re.DOTALL
)


def _lookup_channel_name(cid):
    """Return real channel name for given ID string, or None if not found."""
    url = abs_url('24-7-channels.php')
    try:
        resp = fetch_via_proxy(url, headers={'Referer': get_active_base(), 'User-Agent': UA})
    except Exception:
        return None
    for m in _CARD_RX.finditer(resp):
        if m.group('id') == cid:
            name = html.unescape(m.group('title').strip()) or html.unescape(m.group('data_title').strip())
            name = re.sub(r'^\s*\d+(?=[A-Za-z])', '', name).strip()
            return name or None
    return None


def channels():
    url = abs_url('24-7-channels.php')
    headers = {'Referer': get_active_base(), 'User-Agent': UA}

    try:
        resp = fetch_via_proxy(url, headers=headers)
    except Exception as e:
        log(f"[DLTV] channels(): request failed: {e}")
        return []

    card_rx = _CARD_RX

    items = []
    for m in card_rx.finditer(resp):
        href_rel = m.group('href').strip()
        title_dom = html.unescape(m.group('title').strip())
        title_attr = html.unescape(m.group('data_title').strip())
        name = title_dom or title_attr

        is_adult = (
            '18+' in name.upper() or
            'XXX' in name.upper() or
            name.strip().startswith('18+')
        )

        if is_adult:
            continue

        name = re.sub(r'^\s*\d+(?=[A-Za-z])', '', name).strip()
        items.append([href_rel, name])

    return items


def _channel_group(name):
    """Assign a group/category to a channel based on its name."""
    n = name.upper()
    if any(k in n for k in ['SPORT', 'ESPN', 'BEIN', 'DAZN', 'RACING', 'GOLF', 'BOXING',
                              'FIGHT', 'WWE', 'NBA ', 'NFL ', 'MLB ', 'NHL ', 'MOTOGP',
                              'EUROSPORT', 'SKY SPORTS', 'BT SPORT', 'PREMIER', 'CHAMPIONS',
                              'FORMULA', 'ARENA SPORT', 'MATCH TV', 'SETANTA', 'SPORTV']):
        return 'Sports'
    if any(k in n for k in ['NEWS', 'CNN', 'SKY NEWS', 'FOX NEWS', 'AL JAZEERA', 'ALJAZEERA',
                              'FRANCE 24', 'EURONEWS', 'BFMTV', 'BFM TV', 'LCI', 'CNBC',
                              'BLOOMBERG', 'TRT ', 'NHK', 'DW ']):
        return 'News'
    if any(k in n for k in [' UK', 'BBC ', 'ITV ', 'CHANNEL 4', 'CHANNEL 5', 'SKY ONE',
                              'SKY CINEMA', 'SKY ATLANTIC', 'SKY MAX', 'DAVE ', 'E4 ',
                              'MORE4', 'COMEDY CENTRAL UK']):
        return 'United Kingdom'
    if any(k in n for k in ['FRANCE', 'TF1', 'M6 ', 'ARTE', 'CANAL+', 'CNEWS', 'C NEWS',
                              'TMC ', 'TFX', 'W9 ', 'C8 ', 'CSTAR', 'GULLI', 'RMC ', 'NRJ ',
                              'BFM', 'RTL ']):
        return 'France'
    if any(k in n for k in [' US ', 'NBC ', 'CBS ', 'ABC ', 'AMC ', 'HBO ', 'SHOWTIME',
                              'STARZ', ' FX ', 'TBS ', 'BRAVO', 'HISTORY', 'DISCOVERY',
                              'NAT GEO', 'ANIMAL PLANET', 'LIFETIME', 'A&E ']):
        return 'USA'
    if any(k in n for k in ['ARABIC', 'ARAB', 'MBC ', 'OSN ', 'ROTANA', 'AL ARABIYA',
                              'AL MAYADEEN', 'BAHRAIN', 'KUWAIT', 'SAUDI', 'QATAR', ' UAE',
                              'KSA ', 'NILE ']):
        return 'Arabic'
    if any(k in n for k in ['INDIA', 'STAR PLUS', 'ZEE ', 'SONY LIV', 'COLORS', 'HIND']):
        return 'India'
    return 'International'


def generate_m3u():
    """Parse channel list and write M3U to special://userdata/dltv.m3u.
    Returns the file path on success, None on error."""
    url = abs_url('24-7-channels.php')
    try:
        resp = fetch_via_proxy(url, headers={'Referer': get_active_base(), 'User-Agent': UA})
    except Exception as e:
        log(f'[generate_m3u] fetch error: {e}')
        return None

    # Extended regex capturing logo in addition to existing fields
    card_rx = re.compile(
        r'<a\s+class="card"[^>]*?href="(?P<href>[^"]+)"[^>]*?data-title="(?P<data_title>[^"]*)"[^>]*>'
        r'(?:.*?<img[^>]+src="(?P<logo>[^"]*)"[^>]*>)?'
        r'.*?<div\s+class="card__title">\s*(?P<title>.*?)\s*</div>'
        r'.*?ID:\s*(?P<id>\d+)',
        re.IGNORECASE | re.DOTALL
    )

    lines = ['#EXTM3U']
    count = 0
    base = get_active_base().rstrip('/')

    for m in card_rx.finditer(resp):
        href_rel = m.group('href').strip()
        name_raw = html.unescape(m.group('title').strip()) or html.unescape(m.group('data_title').strip())
        logo = m.group('logo') or ''
        cid_m = re.search(r'id=(\d+)', href_rel)
        if not cid_m:
            continue
        cid = cid_m.group(1)
        # Skip adult
        nu = name_raw.upper()
        if '18+' in nu or 'XXX' in nu:
            continue
        name = re.sub(r'^\s*\d+(?=[A-Za-z])', '', name_raw).strip()
        group = _channel_group(name)
        play_url = ('plugin://plugin.video.dltv/?' +
                    urlencode({'mode': 'play', 'url': f'{base}/watch.php?id={cid}'}))
        lines.append(f'#EXTINF:-1 tvg-id="{cid}" tvg-name="{name}" tvg-logo="{logo}" group-title="{group}",{name}')
        lines.append(play_url)
        count += 1

    if count == 0:
        log('[generate_m3u] No channels found')
        return None

    out_path = xbmcvfs.translatePath('special://userdata/dltv.m3u')
    try:
        with open(out_path, 'w', encoding='utf-8') as f:
            f.write('\n'.join(lines) + '\n')
        log(f'[generate_m3u] Written {count} channels to {out_path}')
        return out_path
    except Exception as e:
        log(f'[generate_m3u] Write error: {e}')
        return None


def pvr_setup():
    """Generate M3U and guide user to configure PVR IPTV Simple Client."""
    xbmcgui.Dialog().notification('DLTV', 'Generating M3U file…', ICON, 2000)
    out_path = generate_m3u()
    if not out_path:
        xbmcgui.Dialog().ok('DLTV — Export M3U',
                             'Generation failed.\nCheck your connection.')
        return

    pvr_installed = False
    try:
        xbmcaddon.Addon('pvr.iptvsimple')
        pvr_installed = True
    except Exception:
        pass

    pvr_status = ('PVR IPTV Simple Client detected!' if pvr_installed
                  else 'PVR IPTV Simple Client not installed.\nInstall it from Extensions → Kodi Repository.')
    msg = (f'[B]{pvr_status}[/B]\n\n'
           f'M3U file generated:\n[I]{out_path}[/I]\n\n'
           f'Setup:\n'
           f'1. Settings → PVR IPTV Simple Client\n'
           f'2. M3U Play List URL → Local file\n'
           f'3. Path → {out_path}\n'
           f'4. OK → Kodi restarts PVR')
    if pvr_installed:
        if xbmcgui.Dialog().yesno('DLTV — Export M3U', msg,
                                   nolabel='Close', yeslabel='Open PVR settings'):
            xbmc.executebuiltin('Addon.OpenSettings(pvr.iptvsimple)')
    else:
        xbmcgui.Dialog().ok('DLTV — Export M3U', msg)


def _probe_hls_url(url):
    """Quick check: returns True if CDN responds with a live HLS playlist (any segments).
    Returns None (inconclusive) for auth errors (403/407) — CDN reachable but requires auth.
    Returns False for definitive failures (404, 5xx, HTML content, no segments)."""
    try:
        r = _get_session().get(url, headers={'User-Agent': UA, 'Referer': PLAYER_REFERER}, timeout=3)
        if r.status_code in (403, 407):
            return None  # CDN requires auth — inconclusive, don't mark as KO
        if r.status_code != 200:
            return False
        content = r.text
        if content[:5] in ('<!DOC', '<html', '<!doc'):
            return False
        # Finite playlist = channel offline
        if '#EXT-X-ENDLIST' in content:
            return False
        if '#EXTM3U' not in content:
            return len(content) > 0 and '<' not in content[:20]
        _segs = [l.strip() for l in content.splitlines()
                 if l.strip() and not l.strip().startswith('#')]
        return len(_segs) > 0  # CDN is reachable and serving a playlist
    except requests.Timeout:
        return None   # timeout = inconclusive, don't mark dead
    except requests.exceptions.ConnectionError:
        return None   # proxy unreachable — inconclusive, don't mark channel dead
    except Exception:
        return False



_AP_SKIP_HOSTS = ('sstatic', 'histats', 'adsco', 'fidget', 'chatango',
                  'facebook.com', 'google.com', 'ksohls.ru')
_AP_M3U8_RX = re.compile(r'''["'](https?://[^\s"'<>]+\.m3u8[^"']*)["']''')
_AP_IFRAME_RX = re.compile(r'''<iframe[^>]+src=["'](https?://[^"']{10,200})["']''')
_AP_STREAM_URL_RX = re.compile(r'''streamUrl\s*:\s*["'](https?:[^"']+)["']''')
_AP_PATHS = ('stream', 'cast', 'watch', 'plus', 'casting', 'player', 'embed')


def _decode_host(url):
    """Rewrite dlstreams.top -> dlstreams.st for DNS resolution reliability."""
    if 'dlstreams.top' in url:
        return url.replace('dlstreams.top', 'dlstreams.st')
    return url

def _try_player_page(channel_id, player_url, watch_url, sess):
    """Try to extract a stream URL from a single player page.
    Returns (url, origin) tuple on success, None otherwise.
    origin is the required HTTP Origin header value, or None if not needed."""
    try:
        r = sess.get(player_url, headers={'User-Agent': UA, 'Referer': watch_url}, timeout=8)
        if r.status_code != 200:
            log(f'[AnyPlayer] HTTP {r.status_code}: {player_url}')
            return None
        html = r.text
        # ── URL rewrite: dlstreams.top -> dlstreams.st (same IP, reliable DNS) ──────
        html = _decode_host(html)
        # ── CHEVY/auth-player guard: detect by content, not domain ──────────
        # Don't bail out — some pages embed CHEVY alongside another player.
        # The iframe scan below already skips /premiumtv/ iframes explicitly.
        if 'ksohls.ru' in html or '/premiumtv/daddyhd.php' in html:
            log(f'[AnyPlayer] CHEVY embed detected — scanning for alternative streams: {player_url}')

        # ── Provider: superdinamico.com → edg.ligapk.com (token-free) ───────
        ms = re.search(r'''<iframe[^>]+src=["'](https://[^"']+\.superdinamico\.com/embed\.php[^"']*)["']''', html)
        if ms:
            r2 = sess.get(ms.group(1), headers={'User-Agent': UA, 'Referer': player_url}, timeout=8)
            if r2.status_code == 200:
                ms2 = re.search(r'get_stream\.php\?id=([a-f0-9]{32})', r2.text)
                if ms2:
                    url = f'https://edg.ligapk.com/exemple.php?id={ms2.group(1)}'
                    log(f'[AnyPlayer] superdinamico/ligapk: {url}')
                    return (url, None)
            log(f'[AnyPlayer] superdinamico embed failed (HTTP {r2.status_code})')

        # ── Generic: direct .m3u8 URL in page source — probe each, skip broken ──
        for mm in _AP_M3U8_RX.finditer(html):
            candidate = mm.group(1)
            # skip blogspot/r-strm wrapper URLs (they serve HTML, not m3u8)
            if 'blogspot.com' in candidate or 'r-strm.' in candidate:
                continue
            try:
                rp = sess.get(candidate, headers={'User-Agent': UA}, timeout=4)
                if rp.status_code == 200 and '#EXTM3U' in rp.text[:200]:
                    log(f'[AnyPlayer] direct m3u8 OK: {candidate[:80]}')
                    return (candidate, None)
                log(f'[AnyPlayer] direct m3u8 skip ({rp.status_code}): {candidate[:60]}')
            except Exception:
                log(f'[AnyPlayer] direct m3u8 unreachable: {candidate[:60]}')

        # ── Generic: scan iframes for .m3u8 or streamUrl ────────────────────
        for iframe_url in _AP_IFRAME_RX.findall(html):
            if any(skip in iframe_url for skip in _AP_SKIP_HOSTS) or '/premiumtv/' in iframe_url:
                continue
            log(f'[AnyPlayer] scanning iframe: {iframe_url[:80]}')
            try:
                ri = sess.get(iframe_url, headers={'User-Agent': UA, 'Referer': player_url}, timeout=8)
                if ri.status_code != 200:
                    continue
                # ── ligue1live.xyz: wrapper page with nested iframe ──────────────
                if 'ligue1live.xyz' in iframe_url:
                    _ll_inner_m = re.search(r'<iframe\s[^>]*src=["\']([^"\']+)["\']', ri.text)
                    if _ll_inner_m:
                        _ll_inner_url = _ll_inner_m.group(1)
                        log(f'[AnyPlayer] ligue1live nested iframe: {_ll_inner_url[:80]}')
                        try:
                            _ll_r = sess.get(_ll_inner_url, headers={'User-Agent': UA, 'Referer': iframe_url}, timeout=8)
                            if _ll_r.status_code == 200:
                                for _ll_mi in _AP_M3U8_RX.finditer(_ll_r.text):
                                    _ll_cand = _ll_mi.group(1)
                                    try:
                                        _ll_rp = sess.get(_ll_cand, headers={'User-Agent': UA}, timeout=4)
                                        if _ll_rp.status_code == 200 and '#EXTM3U' in _ll_rp.text[:200]:
                                            log(f'[AnyPlayer] ligue1live m3u8 OK: {_ll_cand[:80]}')
                                            return (_ll_cand, None)
                                    except Exception:
                                        pass
                                _ll_su = _AP_STREAM_URL_RX.search(_ll_r.text)
                                if _ll_su:
                                    _ll_url = _ll_su.group(1).replace('\\/', '/')
                                    log(f'[AnyPlayer] ligue1live streamUrl: {_ll_url[:80]}')
                                    return (_ll_url, None)
                            else:
                                log(f'[AnyPlayer] ligue1live inner HTTP {_ll_r.status_code}')
                        except Exception as _ll_e:
                            log(f'[AnyPlayer] ligue1live inner error: {_ll_e}')
                for mi in _AP_M3U8_RX.finditer(ri.text):
                    candidate = mi.group(1)
                    if 'blogspot.com' in candidate or 'r-strm.' in candidate:
                        continue
                    try:
                        rp = sess.get(candidate, headers={'User-Agent': UA}, timeout=4)
                        if rp.status_code == 200 and '#EXTM3U' in rp.text[:200]:
                            # Probe first segment to verify segments are accessible
                            _seg_lines = [ln.strip() for ln in rp.text.splitlines()
                                          if ln.strip() and not ln.startswith('#')]
                            _seg_ok = True
                            if _seg_lines:
                                _su = _seg_lines[0]
                                if not _su.startswith('http'):
                                    _su = candidate.rsplit('/', 1)[0] + '/' + _su
                                try:
                                    _sr = sess.get(_su, headers={'User-Agent': UA,
                                                                  'Range': 'bytes=0-0'}, timeout=3)
                                    if _sr.status_code == 403:
                                        # Some CDNs reject Range requests — retry without Range
                                        try:
                                            _sr2 = sess.get(_su, headers={'User-Agent': UA}, timeout=3)
                                            if _sr2.status_code >= 400:
                                                log(f'[AnyPlayer] iframe m3u8 seg fail ({_sr2.status_code} norange): {candidate[:60]}')
                                                _seg_ok = False
                                        except Exception:
                                            pass  # network error — assume segment OK
                                    elif _sr.status_code >= 400:
                                        log(f'[AnyPlayer] iframe m3u8 seg fail ({_sr.status_code}): {candidate[:60]}')
                                        _seg_ok = False
                                except Exception:
                                    pass  # network error — assume segment OK
                            if not _seg_ok:
                                continue
                            log(f'[AnyPlayer] iframe m3u8 OK: {candidate[:80]}')
                            return (candidate, None)
                        log(f'[AnyPlayer] iframe m3u8 skip ({rp.status_code}): {candidate[:60]}')
                    except Exception:
                        log(f'[AnyPlayer] iframe m3u8 unreachable: {candidate[:60]}')
                mi2 = _AP_STREAM_URL_RX.search(ri.text)
                if mi2:
                    url = mi2.group(1).replace('\\/', '/')
                    log(f'[AnyPlayer] iframe streamUrl: {url[:80]}')
                    return (url, None)

                # ── lovecdn-style: ?stream= param + /player/ token (domain-agnostic) ──
                m_stream = re.search(r'[?&]stream=([\w-]+)', iframe_url)
                if m_stream:
                    stream_name = m_stream.group(1)
                    m_lt = re.search(
                        r'(https?://[^/"\'\s]+/player/' + re.escape(stream_name) + r')["\'\s\\]',
                        ri.text)
                    lt_url = m_lt.group(1) if m_lt else f'https://lovetier.bz/player/{stream_name}'
                    r_lt = sess.get(lt_url, headers={'User-Agent': UA, 'Referer': iframe_url}, timeout=8)
                    if r_lt.status_code == 200:
                        m_su = re.search(r'streamUrl\s*:\s*"([^"]+)"', r_lt.text)
                        if m_su:
                            su = m_su.group(1).replace('\\/', '/')
                            try:
                                rp = sess.get(su, headers={'User-Agent': UA, 'Referer': lt_url}, timeout=5)
                                if rp.status_code == 200 and '#EXTM3U' in rp.text[:200]:
                                    _ensure_m3u8_proxy()
                                    port = _actual_proxy_port or M3U8_PROXY_PORT
                                    # Prime the lovecdn cache with the exact (url, lt_url)
                                    # pair just verified here. Without it the /lovecdn-ts/
                                    # proxy re-resolves on its own and falls back to
                                    # lovetier.bz — whose DNS no longer exists — so the
                                    # backend was accepted here then answered 502 later.
                                    with _lovecdn_url_cache_lock:
                                        _lovecdn_url_cache[stream_name] = (su, time.time(), lt_url)
                                    log(f'[AnyPlayer] lovecdn-style: stream={stream_name} lt={lt_url[:60]}')
                                    return (f'http://127.0.0.1:{port}/lovecdn-ts/{quote_plus(stream_name)}', None)
                                log(f'[AnyPlayer] lovecdn streamUrl HTTP {rp.status_code} for {stream_name} — skip')
                            except Exception:
                                log(f'[AnyPlayer] lovecdn streamUrl unreachable for {stream_name} — skip')
                    else:
                        log(f'[AnyPlayer] lovecdn token HTTP {r_lt.status_code} for {stream_name}')

                # ── wiki.js player (fid + wiki.js src) — fully domain-agnostic ──
                mf = re.search(r'fid\s*=\s*"([^"]+)"', ri.text)
                mw = re.search(r'src=["\'](?:https?:)?//([^/"\']+)/wiki\.js["\']', ri.text)
                if mf and mw:
                    fid = mf.group(1)
                    wiki_host = mw.group(1)
                    st_url = f'https://{wiki_host}/wiki.php?player=desktop&live={fid}'
                    rst = sess.get(st_url, headers={'User-Agent': UA, 'Referer': iframe_url}, timeout=8)
                    if rst.status_code == 200:
                        mca = re.search(r'return\s*\(\[([^\]]+)\]\.join\(', rst.text)
                        if mca:
                            chars = re.findall(r'"(\\?.)"', mca.group(1))
                            url = ''.join(c.replace('\\/', '/') for c in chars)
                            if url.startswith('https://'):
                                log(f'[AnyPlayer] wiki.js fid={fid} host={wiki_host}: {url[:80]}')
                                return (url, f'https://{wiki_host}')

                # ── viewembed / CHEVY-template player (CHANNEL_KEY variable) ──
                m_ck2 = re.search(r"CHANNEL_KEY\s*=\s*['\"]([a-z0-9_-]+)['\"]", ri.text, re.IGNORECASE)
                if m_ck2:
                    vkey = m_ck2.group(1)
                    srv_list = []
                    m_sarr = re.search(r"M3U8_SERVER\b[^=\[]*=\s*\[([^\]]+)\]", ri.text)
                    if not m_sarr:
                        m_sarr = re.search(r"\bservers?\s*=\s*\[([^\]]+)\]", ri.text, re.IGNORECASE)
                    if m_sarr:
                        srv_list = [f'https://{s}' for s in re.findall(r"['\"]([a-z0-9._-]+\.[a-z]{2,})['\"]", m_sarr.group(1))]
                    for _ds in (CHEVY_PROXY, CHEVY_LOOKUP):
                        if _ds and _ds not in srv_list:
                            srv_list.append(_ds)
                    for srv in srv_list:
                        try:
                            sl_r = sess.get(f'{srv}/server_lookup?channel_id={vkey}',
                                            headers={'User-Agent': UA, 'Referer': iframe_url}, timeout=4)
                            if sl_r.status_code == 200:
                                _sk = sl_r.json().get('server_key', 'zeko')
                                cand = f'{srv}/proxy/{_sk}/{vkey}/mono.css'
                                rp = sess.get(cand, headers={'User-Agent': UA, 'Referer': iframe_url}, timeout=5)
                                if rp.status_code == 200 and '#EXTM3U' in rp.text[:200]:
                                    # Probe first segment: skip if it's a PNG placeholder (no TS data).
                                    # AES-encrypted segments appear as random bytes — body[:4] won't be \x89PNG.
                                    # Use _is_placeholder() on segment URLs first (catches cdn.gptimage15.com
                                    # even when segments are AES-encrypted), then fall back to byte probe.
                                    _ve_seg_ok = True
                                    _ve_segs = [l.strip() for l in rp.text.splitlines()
                                                if l.strip() and not l.strip().startswith('#')]
                                    if _ve_segs and all(_is_placeholder(s) for s in _ve_segs):
                                        log(f'[AnyPlayer] viewembed {vkey} all segs are placeholder CDN @ {srv[:40]} — skip')
                                        _ve_seg_ok = False
                                    elif _ve_segs:
                                        _ve_su = _ve_segs[0]
                                        if not _ve_su.startswith('http'):
                                            _ve_su = cand.rsplit('/', 1)[0] + '/' + _ve_su
                                        try:
                                            _ve_sr = sess.get(_ve_su, headers={'User-Agent': UA,
                                                                                'Range': 'bytes=0-2047'},
                                                              timeout=4)
                                            if _ve_sr.status_code in (200, 206):
                                                _ve_body = _ve_sr.content
                                                if _ve_body[:4] == b'\x89PNG':
                                                    # Check for TS sync within the fetched bytes
                                                    _ve_ts = any(
                                                        _ve_body[_o] == 0x47
                                                        and _o + 188 < len(_ve_body)
                                                        and _ve_body[_o + 188] == 0x47
                                                        for _o in range(len(_ve_body) - 188)
                                                    )
                                                    if not _ve_ts:
                                                        log(f'[AnyPlayer] viewembed {vkey} seg is PNG placeholder @ {srv[:40]} — skip')
                                                        _ve_seg_ok = False
                                        except Exception as _ve_e:
                                            log(f'[AnyPlayer] viewembed seg probe error: {_ve_e}')
                                    if _ve_seg_ok:
                                        # Cross-channel guard: viewembed key doesn't match this channel.
                                        # e.g. eurosport2fr served for premium773 gives wrong content.
                                        # Skip this iframe so AnyPlayer can try other paths (e.g. lovecdn).
                                        if vkey != f'premium{channel_id}':
                                            log(f'[AnyPlayer] viewembed cross-channel {vkey} ≠ premium{channel_id} — skip')
                                            break  # exit srv loop, continue iframe loop → returns None
                                        # Try to extract CHEVY auth credentials from the viewembed page.
                                        # viewembed.ru embeds the same channelSalt/authToken as ksohls.ru.
                                        _ve_at, _ve_cs = _extract_creds_with_js(ri.text, ri.url,
                                                                                  'https://viewembed.ru',
                                                                                  _get_session())
                                        if _ve_at and _ve_cs:
                                            log(f'[AnyPlayer] viewembed CHEVY creds extracted for {vkey}')
                                            _set_channel_state(vkey, _ve_at, _ve_cs, cand,
                                                               player_referer=ri.url)
                                        else:
                                            # 1. Try sibling from already-auth'd channel in this session
                                            _sib_at, _sib_cs = None, None
                                            with _proxy_lock:
                                                for _sc_state in _channel_creds.values():
                                                    _sc = _sc_state.get('channel_salt', '')
                                                    _sa = _sc_state.get('auth_token', '')
                                                    if _sc and _sc != 'noauth' and _sa and _sa != 'noauth':
                                                        _sib_cs = _sc
                                                        _sib_at = _sa
                                                        break
                                            # 2. If no sibling yet, proactively fetch creds from a known
                                            #    channel on the same CHEVY server (channel_salt is server-wide)
                                            if not _sib_at:
                                                for _probe_id in (495, 118, 121, 772):
                                                    try:
                                                        _sib_at, _sib_cs = _fetch_auth_credentials(_probe_id)
                                                        if _sib_at and _sib_cs:
                                                            log(f'[AnyPlayer] viewembed CHEVY probed sibling id={_probe_id} for {vkey}')
                                                            break
                                                    except Exception:
                                                        pass
                                            if _sib_at and _sib_cs:
                                                log(f'[AnyPlayer] viewembed CHEVY using sibling salt for {vkey}')
                                                _set_channel_state(vkey, _sib_at, _sib_cs, cand,
                                                                   player_referer=ri.url)
                                            else:
                                                # Open browser → reCAPTCHA whitelist → CHEVY serves stable keys
                                                import webbrowser as _wb
                                                log(f'[AnyPlayer] viewembed reCAPTCHA: opening browser {ri.url[:80]}')
                                                xbmcgui.Dialog().notification(
                                                    'DLTV', 'Auth navigateur (8s)...',
                                                    xbmcgui.NOTIFICATION_INFO, 8000)
                                                try:
                                                    _wb.open(ri.url)
                                                except Exception as _wb_e:
                                                    log(f'[AnyPlayer] browser open error: {_wb_e}')
                                                time.sleep(8)
                                                log(f'[AnyPlayer] viewembed CHEVY no auth for {vkey} — noauth+whitelist')
                                                _set_channel_state(vkey, 'noauth', 'noauth', cand,
                                                                   player_referer=ri.url)
                                        _ensure_m3u8_proxy()
                                        _ve_port = _actual_proxy_port or M3U8_PROXY_PORT
                                        log(f'[AnyPlayer] viewembed CHEVY key={vkey} server={srv[:40]}')
                                        return (f'http://127.0.0.1:{_ve_port}/m3u8/{vkey}', None)
                                log(f'[AnyPlayer] viewembed {vkey} m3u8 HTTP {rp.status_code} @ {srv[:40]}')
                            else:
                                log(f'[AnyPlayer] viewembed server_lookup HTTP {sl_r.status_code} @ {srv[:40]}')
                        except Exception as _e_ve:
                            log(f'[AnyPlayer] viewembed {srv[:40]} error: {_e_ve}')

            except Exception as e:
                log(f'[AnyPlayer] iframe error {iframe_url[:60]}: {e}')
                # lovecdn-style fallback: if iframe fetch failed but URL has ?stream=,
                # try lovetier.bz directly (lovecdn.ru may be down).
                m_stream_fb = re.search(r'[?&]stream=([\w-]+)', iframe_url)
                if m_stream_fb:
                    stream_name = m_stream_fb.group(1)
                    lt_url = f'https://lovetier.bz/player/{stream_name}'
                    try:
                        r_lt = sess.get(lt_url, headers={'User-Agent': UA, 'Referer': iframe_url}, timeout=8)
                        if r_lt.status_code == 200 and re.search(r'streamUrl\s*:\s*"https?:', r_lt.text):
                            _ensure_m3u8_proxy()
                            port = _actual_proxy_port or M3U8_PROXY_PORT
                            log(f'[AnyPlayer] lovecdn fallback (lovetier direct): stream={stream_name}')
                            return (f'http://127.0.0.1:{port}/lovecdn-ts/{quote_plus(stream_name)}', None)
                        log(f'[AnyPlayer] lovecdn fallback lovetier HTTP {r_lt.status_code} stream={stream_name}')
                    except Exception as e2:
                        log(f'[AnyPlayer] lovecdn fallback lovetier error stream={stream_name}: {e2}')

        return None

    except Exception as e:
        log(f'[AnyPlayer] error for {player_url}: {e}')
        return None


def get_any_player_stream(channel_id):
    """Try all player pages (stream, cast, watch, plus, casting, player, embed) in order.
    Applies auto-detection on each: superdinamico/ligapk, lovecdn-style (domain-agnostic),
    wiki.js, direct .m3u8, generic iframe scan. Skips pages using ksohls.ru (=CHEVY).
    Returns (url, origin) tuple on success, or None if all fail."""
    watch_url = abs_url(f'watch.php?id={channel_id}')
    sess = _get_session()
    for path in _AP_PATHS:
        player_url = abs_url(f'{path}/stream-{channel_id}.php')
        log(f'[AnyPlayer] Trying {path}/stream-{channel_id}.php')
        result = _try_player_page(channel_id, player_url, watch_url, sess)
        if result:
            return result
    log(f'[AnyPlayer] no stream found for id={channel_id}')
    return None


def get_stream_page_url(channel_id):
    """Fetch auth credentials via stream-{id}.php → enviromentalspace.cyou player.
    Returns (auth_token, channel_salt) or (None, None).
    The stream-{id}.php page now embeds an enviromentalspace.cyou player that has
    the same XOR-encoded authToken/channelSalt as ksohls.ru — usable with CHEVY proxy.
    """
    try:
        watch_url = abs_url(f'watch.php?id={channel_id}')
        stream_url_page = abs_url(f'stream/stream-{channel_id}.php')

        sess = _get_session()
        r = sess.get(stream_url_page, headers={
            'User-Agent': UA,
            'Referer': watch_url,
        }, timeout=12)
        if r.status_code != 200:
            log(f'[StreamPage] HTTP {r.status_code} for id={channel_id}')
            return None, None

        # Find any premiumtv player iframe (enviromentalspace.cyou or similar)
        mp = re.search(r'<iframe[^>]+src="(https?://[^"]+premiumtv[^"]+)"', r.text)
        if not mp:
            log(f'[StreamPage] no premiumtv iframe for id={channel_id}')
            return None, None
        player_url = mp.group(1)
        log(f'[StreamPage] player URL: {player_url[:80]}')

        r2 = sess.get(player_url, headers={
            'User-Agent': UA,
            'Referer': stream_url_page,
        }, timeout=8)
        player_base = re.sub(r'^(https?://[^/]+).*', r'\1', player_url)
        auth_token, channel_salt = _extract_creds_with_js(r2.text, player_url, player_base, sess)
        if auth_token and channel_salt:
            log(f'[StreamPage] Got credentials for channel {channel_id}')
            return auth_token, channel_salt
        log(f'[StreamPage] no credentials in player page for id={channel_id}')
        return None, None
    except Exception as e:
        log(f'[StreamPage] Error for channel {channel_id}: {e}')
        return None, None


def get_direct_hls_url(channel_id):
    """Fetch stream-{id}.php → premiumtv iframe → decode base64 HLS source URL.
    Some channels are served as a plain (unencrypted) HLS stream from the premiumtv
    player page (e.g. xameleon.phantemlis.top) instead of the CHEVY-encrypted CDN.
    Returns (hls_url, watch_url) or (None, None)."""
    try:
        watch_url = abs_url(f'watch.php?id={channel_id}')
        stream_page = abs_url(f'stream/stream-{channel_id}.php')
        sess = _get_session()
        r = sess.get(stream_page, headers={'User-Agent': UA, 'Referer': watch_url}, timeout=12)
        if r.status_code != 200:
            log(f'[DirectHls] stream page HTTP {r.status_code} for id={channel_id}')
            return None, None
        mp = re.search(r'<iframe[^>]+src="(https?://[^"]+premiumtv[^"]+)"', r.text)
        if not mp:
            log(f'[DirectHls] no premiumtv iframe for id={channel_id}')
            return None, None
        player_url = mp.group(1)
        referer_base = re.sub(r'^(https?://[^/]+).*', r'\1', player_url)
        r2 = sess.get(player_url, headers={'User-Agent': UA, 'Referer': stream_page}, timeout=8)
        if r2.status_code != 200:
            log(f'[DirectHls] player page HTTP {r2.status_code} for id={channel_id}')
            return None, None
        hls_url = ''
        m = re.search(r'atob\(\s*[\'"]([A-Za-z0-9+/=]+)[\'"]\s*\)', r2.text)
        if m:
            try:
                hls_url = base64.b64decode(m.group(1)).decode('utf-8')
            except Exception as e:
                log(f'[DirectHls] base64 decode error: {e}')
                hls_url = ''
        if not hls_url:
            # Current premiumtv pages dropped atob() and expose the CDN URL literally
            # as `const SRC = "..."`. Without this fallback the only live CDN
            # (edge.cowedd4855ws.sbs) is invisible and the addon bails out.
            for _pat in (r'const\s+SRC\s*=\s*[\'"](https?://[^\'"]+)[\'"]',
                         r'(?:file|src|source)\s*[:=]\s*[\'"](https?://[^\'"]+\.m3u8[^\'"]*)[\'"]',
                         r'(?:hls|player)\.(?:loadSource|src)\s*\(\s*[\'"](https?://[^\'"]+)[\'"]',
                         r'[\'"](https?://[^\'"\']*/premium\d+/index\.m3u8[^\'"\']*)[\'"]'):
                m2 = re.search(_pat, r2.text)
                if m2:
                    hls_url = html.unescape(m2.group(1)).strip()
                    log(f'[DirectHls] literal source on player page: {hls_url[:100]}')
                    break
        if not hls_url:
            log(f'[DirectHls] no source on player page for id={channel_id}')
            return None, None
        if not hls_url.startswith('http'):
            log(f'[DirectHls] source not http: {hls_url[:60]}')
            return None, None
        # If the decoded URL is a master playlist, follow the first variant so the
        # TS stream proxy receives a media playlist (its segment parser expects one).
        try:
            r3 = sess.get(hls_url, headers={'User-Agent': UA, 'Referer': watch_url + '/'}, timeout=8)
            if r3.status_code == 200 and '#EXT-X-STREAM-INF' in r3.text:
                for _sl in r3.text.splitlines():
                    _sl = _sl.strip()
                    if _sl and not _sl.startswith('#'):
                        hls_url = _sl if _sl.startswith('http') else urljoin(hls_url, _sl)
                        log(f'[DirectHls] resolved variant: {hls_url[:100]}')
                        break
        except Exception as e:
            log(f'[DirectHls] variant resolution skipped: {e}')
        log(f'[DirectHls] OK ({channel_id}): {hls_url[:100]}')
        return hls_url, watch_url
    except Exception as e:
        log(f'[DirectHls] error for id={channel_id}: {e}')
        return None, None


_wide_token_cache = {}
_wide_token_lock = threading.Lock()
_wide_token_inflight = {}      # slug -> Event, so one refresh serves all waiters
_wide_token_inflight_lock = threading.Lock()


def _wide_fresh_token(slug, fallback_token=''):
    """Return a valid wideiptv token for slug, refreshing via the API when stale."""
    with _wide_token_lock:
        cached = _wide_token_cache.get(slug)
        if cached and cached[1] > time.time() + 60:
            return cached[0]
        current = fallback_token or (cached[0] if cached else '')

    # One refresh per slug at a time. The segment prefetch spawns several threads
    # that all need the same token, and a stampede on refresh_token.php is a fast
    # way to get throttled by a site that already drops two connections in three.
    with _wide_token_inflight_lock:
        ev = _wide_token_inflight.get(slug)
        leader = ev is None
        if leader:
            ev = threading.Event()
            _wide_token_inflight[slug] = ev
    if not leader:
        ev.wait(timeout=12)
        with _wide_token_lock:
            cached = _wide_token_cache.get(slug)
        return cached[0] if cached else current
    try:
        resp = requests.post(
            'https://wideiptv.top/api/refresh_token.php',
            json={'channel': slug, 'current_token': current},
            headers={'User-Agent': UA, 'Referer': f'https://wideiptv.top/player/{slug}'},
            timeout=8,
        )
        data = resp.json()
        if data.get('success') and data.get('token'):
            with _wide_token_lock:
                _wide_token_cache[slug] = (data['token'], time.time() + int(data.get('expires_in', 300)))
            return data['token']
    except Exception as e:
        log(f'[WideIptv] token refresh error for {slug}: {e}')
    finally:
        with _wide_token_inflight_lock:
            _wide_token_inflight.pop(slug, None)
        ev.set()
    return current


def _wide_freshen_url(raw_url, slug):
    """Rebuild a wideiptv URL with a freshly refreshed token.

    Every fetch has to go through this: the token embedded in the upstream
    playlist goes stale within minutes, and the CDN answers a stale token with
    HTTP 200 plus an error page instead of a 403. A non-TS 200 body is the tell.
    """
    base_url = raw_url.split('?', 1)[0]
    qs = parse_qsl(raw_url.split('?', 1)[1], keep_blank_values=True) if '?' in raw_url else []
    qs = [(k, v) for k, v in qs if k != 'token']
    qs.append(('token', _wide_fresh_token(slug)))
    return base_url + '?' + urlencode(qs)


def _is_media_segment(body):
    """True when body looks like a real media segment rather than a placeholder.

    Deliberately permissive — MPEG-TS (possibly with leading junk, hence the
    offset scan) or fragmented MP4. A PNG or an HTML error page matches none of
    these, which is exactly what we need to catch.
    """
    if body[:1] == b'\x47':
        return True
    if body[4:8] in (b'ftyp', b'styp'):
        return True
    return _ts_payload_offset(body) >= 0


def _ts_payload_offset(body, window=20, min_ratio=0.8):
    """Return the byte offset where a real MPEG-TS stream starts inside body, else -1.

    Requires ~80% of 20 packets at 188-byte spacing to carry the 0x47 sync byte.
    A lax 3-consecutive-sync check false-positives on PNG payloads (~0.6% of
    offsets), which would make every placeholder image look like video."""
    n = len(body)
    max_off = min(n - 188 * window, 1024 * 1024)
    for off in range(max(0, max_off)):
        if body[off] != 0x47 or body[off + 188] != 0x47:
            continue
        hits = 0
        for k in range(window):
            if body[off + k * 188] == 0x47:
                hits += 1
        if hits >= window * min_ratio:
            return off
    return -1


def _placeholder_stream(manifest_url, referer=None, timeout=6):
    """True when a live manifest's segments are placeholder images instead of MPEG-TS
    (channel offline / CDN geo-gate). Only the first 64 KB of the first segment is
    fetched (the CDN honours Range), so this stays cheap. Without it Kodi just reports
    "Error creating demuxer" because ffmpeg is handed PNG bytes."""
    try:
        sess = _get_session()
        hdrs = {'User-Agent': UA}
        if referer:
            hdrs['Referer'] = referer
        m = sess.get(manifest_url, headers=hdrs, timeout=timeout)
        if m.status_code != 200 or not m.text.lstrip().startswith('#EXTM3U'):
            return False
        pl_url, pl_text = manifest_url, m.text
        if '#EXT-X-STREAM-INF' in m.text:
            # Master playlist: the non-comment line is a variant playlist, not a segment.
            # Probing it as a segment would always report "placeholder" on a perfectly
            # good stream, so descend to the variant first.
            variants = [l.strip() for l in m.text.splitlines()
                        if l.strip() and not l.strip().startswith('#')]
            if not variants:
                return False
            var_url = variants[0] if variants[0].startswith('http') else urljoin(manifest_url, variants[0])
            vm = sess.get(var_url, headers=hdrs, timeout=timeout)
            if vm.status_code != 200 or not vm.text.lstrip().startswith('#EXTM3U'):
                return False
            pl_url, pl_text = var_url, vm.text
            log(f'[Placeholder] master playlist -> variant {var_url[:90]}')
        segs = [l.strip() for l in pl_text.splitlines()
                if l.strip() and not l.strip().startswith('#')]
        if not segs:
            return False
        seg = segs[0] if segs[0].startswith('http') else urljoin(pl_url, segs[0])
        # The payload is never in the first 64 KB: these envelopes are a PNG, so the
        # TS only appears after the whole image has been decoded. Range-probing here
        # would classify every premiumtv channel as a placeholder.
        r = sess.get(seg, headers=hdrs, timeout=15)
        if r.status_code not in (200, 206):
            return False
        if _ts_payload_offset(r.content) >= 0:
            return False
        if _unwrap_ptv_segment(r.content):
            log('[Placeholder] first segment is a premiumtv PNG envelope with real TS '
                'inside — not a placeholder')
            return False
        log(f'[Placeholder] no MPEG-TS in first segment ({len(r.content)}B '
            f'magic={r.content[:4]!r}) — placeholder stream')
        return True
    except Exception as e:
        log(f'[Placeholder] check skipped: {type(e).__name__}: {str(e)[:60]}')
        return False


_UPSTREAM_DEAD_LOADED = False


def _upstream_dead_bootstrap():
    """Read the persisted caches once, on first use.

    Deferred behind a flag because this runs at import time, long before the helpers
    below exist."""
    global _UPSTREAM_DEAD_LOADED
    if _UPSTREAM_DEAD_LOADED:
        return
    _UPSTREAM_DEAD_LOADED = True
    _load_upstream_dead()
    _load_wide_slug_cache()
    _load_wide_absent()


def _load_upstream_dead():
    """Read the persisted dead-upstream list, dropping anything past its TTL."""
    try:
        with open(_UPSTREAM_DEAD_FILE, 'r', encoding='utf-8') as f:
            stored = json.load(f)
    except Exception:
        return
    now = time.time()
    fresh = {}
    for host, entry in (stored or {}).items():
        try:
            ts = float(entry['ts'])
        except Exception:
            continue
        if now - ts < _UPSTREAM_DEAD_TTL:
            fresh[host] = {'ts': ts, 'error': entry.get('error', '')}
    with _upstream_dead_lock:
        _upstream_dead.update(fresh)
    if fresh:
        log(f'[Upstream] loaded {len(fresh)} dead upstream(s) from cache: '
            f'{", ".join(sorted(fresh))}')


def _save_upstream_dead():
    """Persist dead upstreams so the next session skips them without probing."""
    with _upstream_dead_lock:
        snapshot = {h: {'ts': v[0], 'error': v[1]} for h, v in _upstream_dead.items()}
    try:
        _dir = os.path.dirname(_UPSTREAM_DEAD_FILE)
        fd, tmp_path = tempfile.mkstemp(dir=_dir)
        try:
            with os.fdopen(fd, 'w', encoding='utf-8') as f:
                json.dump(snapshot, f)
            os.replace(tmp_path, _UPSTREAM_DEAD_FILE)
        except Exception:
            try:
                os.unlink(tmp_path)
            except OSError:
                pass
    except Exception as e:
        log(f'[Upstream] dead-list save failed: {type(e).__name__}')


def _upstream_alive(url, referer=None, timeout=6):
    """Cheap liveness probe for non-HLS upstreams (CHEVY serves pseudo-playlists with a
    .css extension, so _cdn_reachable's #EXTM3U test cannot apply).

    Any HTTP answer counts as alive — including 4xx/5xx — because what matters here is
    only whether the host completes a TLS handshake and answers at all. Negative results
    are cached for 6 hours and written to disk: these hosts go down for days, and probing
    one on every channel turn costs 3-6s of timeout each time."""
    _upstream_dead_bootstrap()
    host = url.split('/')[2].lower() if '://' in url else url.lower()
    now = time.time()
    with _upstream_dead_lock:
        _ts = _upstream_dead.get(host)
    if _ts and now - _ts[0] < _UPSTREAM_DEAD_TTL:
        log(f'[Upstream] {host} known dead (cached), skipping')
        return False
    try:
        hdrs = {'User-Agent': UA}
        if referer:
            hdrs['Referer'] = referer
        _get_session().get(url, headers=hdrs, timeout=timeout)
    except Exception as e:
        # A refused or half-open connection ends up here as [Errno 92] Protocol not
        # available on some Android builds; the host is just as dead either way.
        log(f'[Upstream] {host} unreachable ({type(e).__name__})')
        with _upstream_dead_lock:
            _upstream_dead[host] = (now, str(e)[:60])
        _save_upstream_dead()
        return False
    with _upstream_dead_lock:
        _upstream_dead.pop(host, None)
    return True


def _cdn_reachable(url, referer=None, timeout=6, attempts=1):
    """Probe a CDN manifest: True only when it answers 200 with a real HLS playlist.

    Some CDN nodes (ds164.bluetier.top) drop roughly two connections in three yet serve
    perfectly good HLS when they answer, so connection-level failures are retried while
    an HTTP verdict (403/404/not-a-playlist) is returned immediately — retrying that
    would only waste the delay before falling through to the next backend."""
    hdrs = {'User-Agent': UA}
    if referer:
        hdrs['Referer'] = referer
    for i in range(max(1, attempts)):
        try:
            r = _get_session().get(url, headers=hdrs, timeout=timeout)
        except Exception as e:
            if i + 1 < attempts:
                log(f'[CDNProbe] {type(e).__name__} — retry {i + 2}/{attempts}: {url[:70]}')
                time.sleep(0.8)
                continue
            log(f'[CDNProbe] unreachable {type(e).__name__} after {attempts} try: {url[:70]}')
            return False
        if r.status_code != 200:
            log(f'[CDNProbe] HTTP {r.status_code}: {url[:90]}')
            return False
        if not r.text[:400].lstrip().startswith('#EXTM3U'):
            log(f'[CDNProbe] not a playlist (first bytes: {r.content[:16]!r}): {url[:90]}')
            return False
        return True
    return False


def _load_wide_slug_cache():
    """Read the persisted channel id -> wideiptv slug map, dropping stale entries."""
    try:
        with open(_WIDE_SLUG_FILE, 'r', encoding='utf-8') as f:
            stored = json.load(f)
    except Exception:
        return
    now = time.time()
    fresh = {}
    for cid, entry in (stored or {}).items():
        try:
            if now - float(entry['ts']) < _WIDE_SLUG_TTL and entry.get('slug'):
                fresh[str(cid)] = {'slug': entry['slug'], 'ts': float(entry['ts']),
                                   'url': entry.get('url', ''), 'token': entry.get('token', '')}
        except Exception:
            continue
    with _wide_slug_lock:
        _wide_slug_cache.update(fresh)
    if fresh:
        log(f'[WideIptv] slug cache: {len(fresh)} channel(s) known, no portal lookup needed')


def _save_wide_slug_cache():
    with _wide_slug_lock:
        snapshot = {k: {'slug': v['slug'], 'ts': v['ts'], 'url': v.get('url', ''),
                        'token': v.get('token', '')} for k, v in _wide_slug_cache.items()}
    try:
        _dir = os.path.dirname(_WIDE_SLUG_FILE)
        fd, tmp_path = tempfile.mkstemp(dir=_dir)
        try:
            with os.fdopen(fd, 'w', encoding='utf-8') as f:
                json.dump(snapshot, f)
            os.replace(tmp_path, _WIDE_SLUG_FILE)
        except Exception:
            try:
                os.unlink(tmp_path)
            except OSError:
                pass
    except Exception as e:
        log(f'[WideIptv] slug cache save failed: {type(e).__name__}')


def _wide_slug_cached(channel_id):
    """Return (slug, base_url, token) for a channel, or None when unknown/stale."""
    _upstream_dead_bootstrap()
    with _wide_slug_lock:
        entry = _wide_slug_cache.get(str(channel_id))
    if not entry or time.time() - entry['ts'] > _WIDE_SLUG_TTL:
        return None
    return entry['slug'], entry.get('url', ''), entry.get('token', '')


def _wide_slug_store(channel_id, slug, stream_url, token):
    with _wide_slug_lock:
        _wide_slug_cache[str(channel_id)] = {'slug': slug, 'ts': time.time(),
                                             'url': stream_url, 'token': token}
    _save_wide_slug_cache()


def _load_wide_absent():
    """Read slugs the CDN reported as absent, dropping marks past their TTL."""
    try:
        with open(_WIDE_SLUG_ABSENT_FILE, 'r', encoding='utf-8') as f:
            stored = json.load(f)
    except Exception:
        return
    now = time.time()
    fresh = {k: float(v) for k, v in (stored or {}).items() if _safe_float(v) and now - float(v) < _WIDE_SLUG_ABSENT_TTL}
    with _wide_slug_lock:
        _wide_slug_absent.update(fresh)


def _safe_float(v):
    try:
        float(v)
        return True
    except Exception:
        return False


def _save_wide_absent():
    with _wide_slug_lock:
        snapshot = dict(_wide_slug_absent)
    try:
        _dir = os.path.dirname(_WIDE_SLUG_ABSENT_FILE)
        fd, tmp_path = tempfile.mkstemp(dir=_dir)
        try:
            with os.fdopen(fd, 'w', encoding='utf-8') as f:
                json.dump(snapshot, f)
            os.replace(tmp_path, _WIDE_SLUG_ABSENT_FILE)
        except Exception:
            try:
                os.unlink(tmp_path)
            except OSError:
                pass
    except Exception:
        pass


def _wide_slug_mark_absent(slug):
    """Remember that the CDN holds no content for slug, but only briefly.

    This is not a dead host: the site still advertises the slug and the operator
    restores it when the channel goes live. Marking it for the full slug TTL would
    keep a channel dark for a day after a ten-minute gap.
    """
    with _wide_slug_lock:
        _wide_slug_absent[slug] = time.time()
        # Drop expired marks while we are here so the dict cannot grow unbounded.
        now = time.time()
        for k in [k for k, ts in list(_wide_slug_absent.items()) if now - ts > _WIDE_SLUG_ABSENT_TTL]:
            _wide_slug_absent.pop(k, None)
    _save_wide_absent()


def _wide_slug_is_absent(slug):
    with _wide_slug_lock:
        ts = _wide_slug_absent.get(slug)
    return bool(ts) and time.time() - ts < _WIDE_SLUG_ABSENT_TTL


def get_wideiptv_url(channel_id):
    """Player 6 (wideiptv.top) backend: walk stream-{id}.php → daddy.php?stream=SLUG →
    player page, extract the HLS streamUrl + channel slug + token.
    Returns (stream_url, slug, token) or None.

    A cached slug skips dlive.sx entirely: the token comes from wideiptv.top's own
    refresh API, so a cached channel needs no portal request at all.
    """
    try:
        cached = _wide_slug_cached(channel_id)
        if cached:
            slug, base_url, cached_token = cached
            if _wide_slug_is_absent(slug):
                log(f'[WideIptv] unavailable ({channel_id}): slug {slug} has no CDN content')
                return None
            fresh = _wide_fresh_token(slug, cached_token)
            # Rebuild with the fresh token; the stored URL's own token is long dead.
            rebuilt = _wide_freshen_url(base_url, slug) if base_url else ''
            log(f'[WideIptv] OK ({channel_id}): slug={slug} (cached, no portal request)')
            return rebuilt, slug, fresh

        watch_url = abs_url(f'watch.php?id={channel_id}')
        player_page = abs_url(f'player/stream-{channel_id}.php')
        sess = _get_session()
        r = sess.get(player_page, headers={'User-Agent': UA, 'Referer': watch_url}, timeout=12)
        if r.status_code != 200:
            log(f'[WideIptv] player page HTTP {r.status_code} for id={channel_id}')
            return None
        m = re.search(r'<iframe[^>]+src="(https?://[^"]*wideiptv[^"]*)"', r.text)
        if not m:
            log(f'[WideIptv] no wideiptv iframe for id={channel_id}')
            return None
        daddy_url = m.group(1)
        r2 = sess.get(daddy_url, headers={'User-Agent': UA, 'Referer': player_page}, timeout=8)
        if r2.status_code != 200:
            log(f'[WideIptv] daddy page HTTP {r2.status_code}')
            return None
        m2 = re.search(r'<iframe[^>]+src="(https?://[^"]*wideiptv[^"]*)"', r2.text)
        if not m2:
            log(f'[WideIptv] no player iframe on daddy page')
            return None
        player_url = m2.group(1)
        r3 = sess.get(player_url, headers={'User-Agent': UA, 'Referer': daddy_url}, timeout=8)
        if r3.status_code != 200:
            log(f'[WideIptv] player page HTTP {r3.status_code}')
            return None
        mc = re.search(r'streamUrl:\s*"([^"]+)"', r3.text)
        if not mc:
            log('[WideIptv] no streamUrl in player config')
            return None
        stream_url = mc.group(1).replace('\\/', '/')
        mt = re.search(r'currentToken:\s*"([^"]+)"', r3.text)
        token = mt.group(1) if mt else ''
        ms = re.search(r'channelSlug:\s*"([^"]+)"', r3.text)
        slug = ms.group(1) if ms else stream_url.rsplit('/', 2)[-2]
        log(f'[WideIptv] OK ({channel_id}): {stream_url[:90]} slug={slug}')
        _wide_slug_store(channel_id, slug, stream_url, token)
        # Prove the manifest exists before handing the URL over. A 404 here means the
        # site advertises the slug while the CDN holds no content for it, which is a
        # temporary operator gap rather than a bad token or a dead host.
        try:
            _mr = _get_session().get(stream_url, headers={'User-Agent': UA}, timeout=8)
            if _mr.status_code == 404:
                _wide_slug_mark_absent(slug)
                log(f'[WideIptv] slug {slug} has no CDN content (404) — marked for '
                    f'{_WIDE_SLUG_ABSENT_TTL // 60} min, skipping this channel')
                return None
        except Exception:
            pass  # reachability is not this check's job; the proxy retries anyway
        return stream_url, slug, token
    except Exception as e:
        log(f'[WideIptv] error for id={channel_id}: {e}')
        return None


def resolve_stream_url(channel_id, forced_key=None):
    channel_key = f'premium{channel_id}'
    if forced_key:
        log(f'[resolve_stream_url] Forced CDN for {channel_id}: {forced_key}')
        if forced_key == 'top1/cdn':
            return f'{CHEVY_PROXY}/proxy/top1/cdn/{channel_key}/mono.css'
        return f'{CHEVY_PROXY}/proxy/{forced_key}/{channel_key}/mono.css'
    # Session cache
    with _server_key_cache_lock:
        cached = _server_key_cache.get(channel_id)
        if cached and time.time() - cached[1] < _SERVER_KEY_TTL:
            server_key = cached[0]
            log(f'[resolve_stream_url] cache hit for {channel_id}: {server_key}')
            if server_key == 'top1/cdn':
                return f'{CHEVY_PROXY}/proxy/top1/cdn/{channel_key}/mono.css'
            return f'{CHEVY_PROXY}/proxy/{server_key}/{channel_key}/mono.css'
    server_key = 'zeko'
    _lookup_url = CHEVY_LOOKUP
    _proxy_url = CHEVY_PROXY
    for attempt in range(3):
        try:
            resp = _get_session().get(
                f'{_lookup_url}/server_lookup?channel_id={channel_key}',
                headers={'User-Agent': UA, 'Referer': PLAYER_REFERER},
                timeout=4
            )
            server_key = resp.json().get('server_key', 'zeko')
            with _server_key_cache_lock:
                _server_key_cache[channel_id] = (server_key, time.time())
            _proxy_url = CHEVY_PROXY if _lookup_url == CHEVY_LOOKUP else _CHEVY_PROXY_BUILTIN
            break
        except Exception as e:
            log(f'[resolve_stream_url] server_lookup failed (attempt {attempt+1}): {e}')
            if attempt == 0:
                time.sleep(0.3)
            elif attempt == 1 and _lookup_url != _CHEVY_LOOKUP_BUILTIN:
                # Discovered server is down — try builtin fallback and invalidate cache
                log(f'[resolve_stream_url] falling back to builtin CHEVY server')
                _lookup_url = _CHEVY_LOOKUP_BUILTIN
                _proxy_url = _CHEVY_PROXY_BUILTIN
                try:
                    os.remove(_DISCOVERY_CACHE_FILE)
                except Exception:
                    pass
    if server_key == 'top1/cdn':
        return f'{_proxy_url}/proxy/top1/cdn/{channel_key}/mono.css'
    return f'{_proxy_url}/proxy/{server_key}/{channel_key}/mono.css'

def _resolve_playback(channel_id, channel_key, forced_cdn):
    """Resolve one playback backend into a Kodi-ready stream URL.

    Returns (m3u8_url, is_hls_via_adaptive, use_player6, player_origin), or None when
    this backend cannot deliver video. Pure resolution: raises no Kodi dialog, so the
    caller can walk the whole backend list before reporting a failure to the user."""
    use_player6 = False
    auth_token, channel_salt = None, None
    player_origin = None
    m3u8_url = None
    _premiumtv_hls = False

    if forced_cdn == '__anyplayer__':
        _cross_channel_url = None
        ap_result = get_any_player_stream(channel_id)
        if ap_result:
            _ap_url_tmp, _ = ap_result
            # Cross-channel viewembed: EPlayerProxy URL for a different channel key
            # (e.g. eurosport2fr for premium773). The viewembed channel has auth state
            # (salt/nonce/sig) set up — route via /stream/ so the key is fetched with auth.
            # CHEVY returns a random dummy key without auth → decryption always fails.
            _ap_ck = _ap_url_tmp.rsplit('/m3u8/', 1)[-1] if '/m3u8/' in _ap_url_tmp else None
            if _ap_ck and '127.0.0.1' in _ap_url_tmp and _ap_ck != channel_key:
                log(f'[PlayStream] AnyPlayer cross-channel ({_ap_ck} ≠ {channel_key}) — routing /stream/ with viewembed auth')
                _ensure_m3u8_proxy()
                _cross_channel_url = f'http://127.0.0.1:{_actual_proxy_port or M3U8_PROXY_PORT}/stream/{_ap_ck}'
                ap_result = None
        if _cross_channel_url:
            m3u8_url = _cross_channel_url
            log(f'[PlayStream] Using cross-channel TS stream proxy: {m3u8_url}')
        elif ap_result:
            real_m3u8_url, player_origin = ap_result
            log(f'[PlayStream] AnyPlayer URL: {real_m3u8_url} (origin={player_origin})')
            use_player6 = True
        else:
            # AnyPlayer failed — try ksohls auth before noauth (noauth often returns placeholder images)
            log('[PlayStream] AnyPlayer failed — trying ksohls auth before noauth fallback')
            with concurrent.futures.ThreadPoolExecutor(max_workers=2) as _ex2:
                _f_url = _ex2.submit(resolve_stream_url, channel_id, None)
                _f_auth = _ex2.submit(_fetch_auth_credentials, channel_id)
                real_m3u8_url = _f_url.result()
                auth_token, channel_salt = _f_auth.result()
            if not auth_token:
                auth_token, channel_salt = get_stream_page_url(channel_id)
            if auth_token and channel_salt and auth_token != 'noauth':
                log(f'[PlayStream] AnyPlayer failed but ksohls auth OK — using CHEVY stream proxy')
                _set_channel_state(channel_key, auth_token, channel_salt, real_m3u8_url)
                _ensure_m3u8_proxy()
                m3u8_url = f'http://127.0.0.1:{_actual_proxy_port or M3U8_PROXY_PORT}/stream/{channel_key}'
                log(f'[PlayStream] Using TS stream proxy (auth): {m3u8_url}')
            else:
                log(f'[PlayStream] Auth also failed — falling back to CHEVY no-auth TS proxy')
                log(f'[PlayStream] Primary M3U8 URL (noauth fallback): {real_m3u8_url}')
                if not _upstream_alive(real_m3u8_url):
                    log('[PlayStream] backend failed: CHEVY no-auth upstream unreachable')
                    return None
                _set_channel_state(channel_key, 'noauth', 'noauth', real_m3u8_url)
                _ensure_m3u8_proxy()
                m3u8_url = f'http://127.0.0.1:{_actual_proxy_port or M3U8_PROXY_PORT}/stream/{channel_key}'
                log(f'[PlayStream] Using TS stream proxy (no-auth): {m3u8_url}')

    elif forced_cdn == '__streampage__':
        # StreamPage uses enviromentalspace.cyou auth + CHEVY CDN (TS proxy path)
        auth_token, channel_salt = get_stream_page_url(channel_id)
        if not auth_token:
            log('[PlayStream] backend failed: ' + f'StreamPage unavailable (ch.{channel_id})')
            return None
        real_m3u8_url = resolve_stream_url(channel_id)
        log(f'[PlayStream] StreamPage auth OK, CDN: {real_m3u8_url}')

    elif forced_cdn == '__premiumtv__':
        # Direct HLS from the premiumtv player page (plain unencrypted stream).
        # Serve the HLS playlist + segments through the /raw/ proxy so Kodi's
        # inputstream.adaptive fetches them with the required premiumtv Referer.
        direct_url, direct_ref = get_direct_hls_url(channel_id)
        if not direct_url:
            log('[PlayStream] backend failed: ' + f'Direct HLS unavailable (ch.{channel_id})')
            return None
        log(f'[PlayStream] Direct premiumtv HLS for {channel_key}: {direct_url}')
        if _placeholder_stream(direct_url, referer=direct_ref):
            log(f'[PlayStream] {channel_key}: CDN serves placeholder images — channel offline')
            log('[PlayStream] backend failed: ' + f'Channel offline (ch.{channel_id})')
            return None
        _set_channel_state(channel_key, 'direct', 'direct', direct_url, player_referer=direct_ref)
        _ensure_m3u8_proxy()
        _premiumtv_hls = True
        encoded_origin = quote_plus(direct_ref)
        encoded_url = quote_plus(direct_url)
        m3u8_url = f'http://127.0.0.1:{_actual_proxy_port or M3U8_PROXY_PORT}/ptv/{encoded_origin}/{encoded_url}'
        log(f'[PlayStream] Using premiumtv HLS via ptv proxy (inputstream.adaptive): {m3u8_url}')

    elif forced_cdn == '__wideiptv__':
        # Player 6 backend (wideiptv.top): clean H.264 HLS with SPS/PPS (unlike some
        # premiumtv streams which are HEVC without parameter sets and can't init Kodi's
        # decoder). Served through the /wide/ proxy so the token is refreshed on demand.
        w_result = get_wideiptv_url(channel_id)
        if not w_result:
            log('[PlayStream] backend failed: ' + f'Wideiptv unavailable (ch.{channel_id})')
            return None
        w_url, w_slug, w_token = w_result
        log(f'[PlayStream] Wideiptv for {channel_key}: {w_url[:100]} slug={w_slug}')
        # Validate/refresh the token immediately (uses the page token as the
        # refresh API's current_token) so the first adaptive fetch never
        # starts with a stale token.
        _wide_fresh_token(w_slug, w_token)
        _ensure_m3u8_proxy()
        # The wideiptv CDN nodes go down regularly (ds164.bluetier.top started
        # refusing TCP). Probe it first and fall back to the premiumtv direct HLS
        # instead of letting Kodi fail with a bare "Error creating demuxer".
        if not _cdn_reachable(w_url, referer=f'https://wideiptv.top/player/{w_slug}',
                                  timeout=5, attempts=4):
            log(f'[PlayStream] wideiptv CDN unreachable — falling back to premiumtv direct HLS')
            direct_url, direct_ref = get_direct_hls_url(channel_id)
            if not direct_url:
                log('[PlayStream] backend failed: ' + f'All CDNs unreachable (ch.{channel_key})')
                return None
            log(f'[PlayStream] Fallback premiumtv HLS for {channel_key}: {direct_url[:100]}')
            if _placeholder_stream(direct_url, referer=direct_ref):
                log(f'[PlayStream] {channel_key}: fallback CDN serves placeholder images — channel offline')
                log('[PlayStream] backend failed: ' + f'Channel offline (ch.{channel_id})')
                return None
            _set_channel_state(channel_key, 'direct', 'direct', direct_url, player_referer=direct_ref)
            encoded_origin = quote_plus(direct_ref)
            encoded_url = quote_plus(direct_url)
            m3u8_url = f'http://127.0.0.1:{_actual_proxy_port or M3U8_PROXY_PORT}/ptv/{encoded_origin}/{encoded_url}'
            log(f'[PlayStream] Using fallback premiumtv HLS via ptv proxy: {m3u8_url}')
            _premiumtv_hls = True
            # player_origin doubles as "which backend actually served this": the
            # cascade labels a success with the backend it was trying, so without
            # this a premiumtv fallback was logged as a wideiptv success.
            player_origin = 'premiumtv'
        else:
            encoded_slug = quote_plus(w_slug)
            encoded_url = quote_plus(w_url)
            m3u8_url = f'http://127.0.0.1:{_actual_proxy_port or M3U8_PROXY_PORT}/wide/{encoded_slug}/{encoded_url}'
            log(f'[PlayStream] Using wideiptv HLS via wide proxy (inputstream.adaptive): {m3u8_url}')
            _premiumtv_hls = True

    else:
        # CHEVY path — reuse cached credentials if fresh (< 5 min), otherwise
        # resolve CDN URL and fetch auth in parallel to minimise spinner time.
        cached = _get_channel_state(channel_key)
        auth_is_fresh = (cached and cached.get('auth_token')
                         and cached.get('auth_token') != 'noauth'
                         and (time.time() - cached.get('fetched_at', 0)) < 300)
        if auth_is_fresh:
            real_m3u8_url = resolve_stream_url(channel_id, forced_cdn)
            auth_token = cached['auth_token']
            channel_salt = cached['channel_salt']
            log(f'[PlayStream] Reusing cached credentials for {channel_key}')
        else:
            with concurrent.futures.ThreadPoolExecutor(max_workers=2) as _ex:
                _fut_resolve = _ex.submit(resolve_stream_url, channel_id, forced_cdn)
                _fut_auth = _ex.submit(_fetch_auth_credentials, channel_id)
                real_m3u8_url = _fut_resolve.result()
                auth_token, channel_salt = _fut_auth.result()
            if not auth_token:
                log('[PlayStream] ksohls.ru auth failed — trying StreamPage fallback')
                auth_token, channel_salt = get_stream_page_url(channel_id)
        log(f'[PlayStream] Primary M3U8 URL: {real_m3u8_url}')

    if m3u8_url:
        pass  # already set by __anyplayer__ noauth fallback
    elif use_player6:
        # If the detected player returned a required Origin, route through raw proxy.
        # Otherwise play the URL directly (e.g. lovecdn/ligapk don't need Origin).
        if player_origin:
            _ensure_m3u8_proxy()
            encoded_origin = quote_plus(player_origin)
            encoded_url = quote_plus(real_m3u8_url)
            m3u8_url = f'http://127.0.0.1:{_actual_proxy_port or M3U8_PROXY_PORT}/raw/{encoded_origin}/{encoded_url}'
            log(f'[PlayStream] Using raw proxy for Player6 (origin={player_origin})')
        else:
            m3u8_url = real_m3u8_url
            log(f'[PlayStream] Using Player 6 stream directly')
    else:
        if auth_token and channel_salt and auth_token != 'noauth':
            log(f'[PlayStream] Got auth credentials for {channel_key}')
            _set_channel_state(channel_key, auth_token, channel_salt, real_m3u8_url)
            _ensure_m3u8_proxy()
            m3u8_url = f'http://127.0.0.1:{_actual_proxy_port or M3U8_PROXY_PORT}/stream/{channel_key}'
            log(f'[PlayStream] Using TS stream proxy: {m3u8_url}')
        else:
            # Auth unavailable — try AnyPlayer first (handles channels like ch.121 where
            # CHEVY key endpoint returns a dummy key, making noauth m3u8 proxy unusable).
            log('[PlayStream] Auth unavailable — trying AnyPlayer fallback before noauth proxy')
            _cross_channel_url = None
            ap_result = get_any_player_stream(channel_id)
            if ap_result:
                _ap_url_tmp, _ = ap_result
                # Cross-channel viewembed: route via /stream/ for the viewembed channel
                # so key is fetched with auth (CHEVY returns random key without auth).
                _ap_ck = _ap_url_tmp.rsplit('/m3u8/', 1)[-1] if '/m3u8/' in _ap_url_tmp else None
                if _ap_ck and '127.0.0.1' in _ap_url_tmp and _ap_ck != channel_key:
                    log(f'[PlayStream] AnyPlayer cross-channel ({_ap_ck} ≠ {channel_key}) — routing /stream/ with viewembed auth')
                    _ensure_m3u8_proxy()
                    _cross_channel_url = f'http://127.0.0.1:{_actual_proxy_port or M3U8_PROXY_PORT}/stream/{_ap_ck}'
                    ap_result = None
            if _cross_channel_url:
                m3u8_url = _cross_channel_url
                log(f'[PlayStream] Using cross-channel TS stream proxy: {m3u8_url}')
            elif ap_result:
                real_m3u8_url, player_origin = ap_result
                log(f'[PlayStream] AnyPlayer fallback OK: {real_m3u8_url} (origin={player_origin})')
                if player_origin:
                    _ensure_m3u8_proxy()
                    encoded_origin = quote_plus(player_origin)
                    encoded_url = quote_plus(real_m3u8_url)
                    m3u8_url = f'http://127.0.0.1:{_actual_proxy_port or M3U8_PROXY_PORT}/raw/{encoded_origin}/{encoded_url}'
                    log(f'[PlayStream] Using raw proxy for AnyPlayer fallback (origin={player_origin})')
                else:
                    m3u8_url = real_m3u8_url
                    log(f'[PlayStream] Using AnyPlayer fallback stream directly')
                use_player6 = True
            else:
                log('[PlayStream] AnyPlayer fallback failed — using TS stream proxy (noauth)')
                if not _upstream_alive(real_m3u8_url):
                    log('[PlayStream] backend failed: CHEVY no-auth upstream unreachable')
                    return None
                _set_channel_state(channel_key, 'noauth', 'noauth', real_m3u8_url)
                _ensure_m3u8_proxy()
                m3u8_url = f'http://127.0.0.1:{_actual_proxy_port or M3U8_PROXY_PORT}/stream/{channel_key}'
                log(f'[PlayStream] Using TS stream proxy (no-auth): {m3u8_url}')
    return m3u8_url, _premiumtv_hls, use_player6, player_origin


def PlayStream(link):
    try:
        log(f'[PlayStream] Starting: {link}')

        parsed = urlparse(link)
        qs = dict(parse_qsl(parsed.query))
        channel_id = qs.get('id', '').split('|')[0].strip()

        if not channel_id:
            log('[PlayStream] No channel ID found')
            xbmcgui.Dialog().notification('DLTV', 'Channel not found (missing ID)', ICON, 4000)
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
            return

        log(f'[PlayStream] Channel ID: {channel_id}')
        channel_key = f'premium{channel_id}'

        use_player6 = False
        auth_token, channel_salt = None, None
        player_origin = None
        m3u8_url = None
        _premiumtv_hls = False

        # Backend cascade. The site rotates its players and CDN nodes constantly and
        # several backends are regularly down, geo-gated or serving placeholder images,
        # so walk all of them in order instead of asking the user to pick a dead one.
        # Order matters: wideiptv leads because it needs no portal request when its
        # slug is cached, and every other backend starts by asking the portal.
        if _wide_slug_cached(channel_id):
            log('[PlayStream] slug cached — wideiptv needs no portal request')
        for _cdn in _PLAYBACK_CASCADE:
            _label = _CDN_LABELS.get(_cdn, 'Auto — CHEVY (CDN)')
            log(f'[PlayStream] trying backend: {_label}')
            _res = _resolve_playback(channel_id, channel_key, _cdn)
            if _res:
                m3u8_url, _premiumtv_hls, use_player6, player_origin = _res
                # A backend may serve the stream through another one — wideiptv
                # falls back to premiumtv when its CDN is down. Report what
                # actually produced the URL, not what the cascade was attempting.
                _served = _label
                if player_origin == 'premiumtv':
                    _served = 'Direct HLS (premiumtv, fallback depuis wideiptv)'
                log(f'[PlayStream] backend OK: {_served}')
                break
        if not m3u8_url:
            log(f'[PlayStream] every backend failed for {channel_key} — offering manual list')
            # Rescue: only now ask which backend to force. The CDN nodes flap constantly,
            # so a backend that just failed often works on a second attempt; this also
            # covers codec cases the cascade ordering cannot know about (wideiptv's H.264
            # on a Kodi that refuses HEVC).
            _mi = xbmcgui.Dialog().select(f'Aucun backend ne marche — ch.{channel_id}\nForcer lequel?',
                                          [label for label, _ in _MANUAL_CDNS])
            if _mi >= 0:
                _, _forced = _MANUAL_CDNS[_mi]
                log(f'[PlayStream] forcing backend: {_CDN_LABELS.get(_forced, "CHEVY")}')
                _res = _resolve_playback(channel_id, channel_key, _forced)
                if _res:
                    m3u8_url, _premiumtv_hls, use_player6, player_origin = _res
        if not m3u8_url:
            xbmcgui.Dialog().notification('DLTV', f'No working stream (ch.{channel_id})', ICON, 4000)
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
            return

        _is_ts_proxy = not use_player6 and '127.0.0.1' in m3u8_url and '/stream/' in m3u8_url
        _is_m3u8_proxy = not use_player6 and f'/m3u8/{channel_key}' in m3u8_url
        liz = xbmcgui.ListItem(f'Channel {channel_id}', path=m3u8_url)
        liz.setContentLookup(False)
        if _premiumtv_hls:
            # HLS via inputstream.adaptive: Kodi re-polls the live playlist and
            # downloads segments through the /raw/ proxy (premiumtv Referer applied).
            liz.setMimeType('application/vnd.apple.mpegurl')
            liz.setProperty('inputstream', 'inputstream.adaptive')
            liz.setProperty('inputstream.adaptive.manifest_type', 'hls')
        elif _is_ts_proxy:
            # TS byte stream — use Kodi's native VideoPlayer (no inputstream needed)
            liz.setMimeType('video/MP2T')
        elif _is_m3u8_proxy:
            # HLS with AES-128: open_mode=ffmpeg so FFmpeg polls live playlist AND
            # handles AES-128-CBC decryption. open_mode=curl only fetches M3U8 once
            # (no live re-poll) which causes stream to stall after initial segments.
            liz.setMimeType('application/vnd.apple.mpegurl')
            liz.setProperty('inputstream', 'inputstream.ffmpegdirect')
            liz.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'true')
            liz.setProperty('inputstream.ffmpegdirect.open_mode', 'ffmpeg')
        elif '/lovecdn-ts/' in m3u8_url:
            # lovecdn via TS proxy: internal HLS client downloads segments and forwards
            # as a continuous MPEG-TS byte stream — no HLS re-polling, no loop risk.
            liz.setMimeType('video/MP2T')
        elif '/lovecdn/' in m3u8_url:
            # lovecdn HLS via ffmpegdirect (fallback, not currently used)
            liz.setMimeType('application/vnd.apple.mpegurl')
            liz.setProperty('inputstream', 'inputstream.ffmpegdirect')
            liz.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'true')
            liz.setProperty('inputstream.ffmpegdirect.open_mode', 'ffmpeg')
        elif use_player6 and '127.0.0.1' in m3u8_url and '/m3u8/' in m3u8_url:
            # EPlayerProxy URL returned from AnyPlayer (e.g. viewembed CHEVY) — ffmpegdirect via proxy
            liz.setMimeType('application/vnd.apple.mpegurl')
            liz.setProperty('inputstream', 'inputstream.ffmpegdirect')
            liz.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'true')
            liz.setProperty('inputstream.ffmpegdirect.open_mode', 'ffmpeg')
        else:
            liz.setMimeType('application/vnd.apple.mpegurl')
        liz.setProperty('IsPlayable', 'true')

        xbmcplugin.setResolvedUrl(addon_handle, True, liz)
        log(f'[PlayStream] Stream started ({"Player6" if use_player6 else "TS proxy" if _is_ts_proxy else "direct"})')

    except Exception as e:
        log(f'[PlayStream] Error: {e}')
        xbmcgui.Dialog().notification('DLTV', f'Error: {str(e)[:80]}', ICON, 6000)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())

def Search_Events():
    keyboard = xbmcgui.Dialog().input("Enter search term", type=xbmcgui.INPUT_ALPHANUM)
    if not keyboard or keyboard.strip() == '':
        closeDir()
        return
    term = keyboard.lower().strip()

    try:
        html_text = fetch_via_proxy(abs_url('index.php'), headers={'User-Agent': UA, 'Referer': get_active_base()})
        events = re.findall(
            r"<div\s+class=\"schedule__event\">.*?"
            r"<div\s+class=\"schedule__eventHeader\"[^>]*?>\s*"
            r"(?:<[^>]+>)*?"
            r"<span\s+class=\"schedule__time\"[^>]*data-time=\"([^\"]+)\"[^>]*>.*?</span>\s*"
            r"<span\s+class=\"schedule__eventTitle\">\s*([^<]+)\s*</span>.*?"
            r"</div>\s*"
            r"<div\s+class=\"schedule__channels\">(.*?)</div>",
            html_text, re.IGNORECASE | re.DOTALL
        )

        rows = {}
        seen = set()
        for time_str, raw_title, channels_block in events:
            title_clean = html.unescape(raw_title.strip())
            if term not in title_clean.lower():
                continue
            if title_clean in seen:
                continue
            seen.add(title_clean)
            event_time_local = get_local_time(time_str.strip())
            rows[title_clean] = channels_block

        for title, chblock in rows.items():
            links = []
            for href, title_attr, link_text in re.findall(
                r'<a[^>]+href="([^"]+)"[^>]*title="([^"]*)".*?>(.*?)</a>',
                chblock, re.IGNORECASE | re.DOTALL
            ):
                name = html.unescape(title_attr or link_text)
                links.append({'channel_name': name, 'channel_id': href})
            addDir(title, build_url({'mode': 'trLinks', 'trData': json.dumps({'channels': links})}), False)

    except Exception as e:
        log(f'Search_Events error: {e}')
    closeDir()

def Search_Channels():
    keyboard = xbmcgui.Dialog().input("Enter channel name", type=xbmcgui.INPUT_ALPHANUM)
    if not keyboard or keyboard.strip() == '':
        closeDir()
        return
    term = keyboard.lower().strip()
    chData = channels()
    fav_ids = {f['id'] for f in get_favorites()}
    dead_cids = _get_dead_cids()
    for href, title in chData:
        if term in title.lower():
            cid_m = re.search(r'id=(\d+)', href)
            cid = cid_m.group(1) if cid_m else ''
            fav_label = '★ Remove from favorites' if cid in fav_ids else '☆ Add to favorites'
            ctx = [(fav_label, 'RunPlugin(%s)' % build_url({'mode': 'toggle_fav', 'cid': cid, 'name': title}))] if cid else []
            label = f'{_ch_label(title, cid, dead_cids)} ({cid})' if cid else title
            addDir(label, build_url({'mode': 'play', 'url': abs_url(href)}), False, context_menu=ctx)
    closeDir()

def Search_Channel_By_Number():
    keyboard = xbmcgui.Dialog().input("Channel number", type=xbmcgui.INPUT_NUMERIC)
    if not keyboard or not keyboard.strip():
        xbmcplugin.endOfDirectory(addon_handle, False)
        return
    channel_id = keyboard.strip().lstrip('0') or '0'
    if not channel_id.isdigit():
        xbmcgui.Dialog().notification('DLTV', 'Invalid number', ICON, 3000)
        xbmcplugin.endOfDirectory(addon_handle, False)
        return

    # Look up channel name from the channel list
    ch_name = f'Channel {channel_id}'
    for href, name in channels():
        m = re.search(r'id=(\d+)', href)
        if m and m.group(1) == channel_id:
            ch_name = name
            break

    fav_ids = {f['id'] for f in get_favorites()}
    fav_label = '★ Remove from favorites' if channel_id in fav_ids else '☆ Add to favorites'
    ctx = [(fav_label, 'RunPlugin(%s)' % build_url({'mode': 'toggle_fav', 'cid': channel_id, 'name': ch_name}))]
    dead_cids = _get_dead_cids()
    label = f'{_ch_label(ch_name, channel_id, dead_cids)} ({channel_id})'
    addDir(label, build_url({'mode': 'play', 'url': abs_url(f'watch.php?id={channel_id}')}), False, context_menu=ctx)
    closeDir()


def load_extra_channels(force_reload=False):
    global EXTRA_CHANNELS_DATA
    _LOCAL_CACHE_EXPIRY = 24 * 60 * 60  # L5: renamed from CACHE_EXPIRY to avoid shadowing module-level name

    saved = addon.getSetting('extra_channels_cache')
    if saved and not force_reload:
        try:
            saved_data = json.loads(saved)
            if time.time() - saved_data.get('timestamp', 0) < _LOCAL_CACHE_EXPIRY:
                EXTRA_CHANNELS_DATA = saved_data.get('channels', {})
                if EXTRA_CHANNELS_DATA:
                    return EXTRA_CHANNELS_DATA
        except:
            pass

    try:
        resp = requests.get(EXTRA_M3U8_URL, headers={'User-Agent': UA}, timeout=10).text
    except Exception as e:
        log(f'[load_extra_channels] Network error: {e}')
        xbmcgui.Dialog().notification('DLTV', 'Extra channels unavailable', ICON, 3000)
        return {}

    categories = {}
    lines = resp.splitlines()

    for i, line in enumerate(lines):
        if not line.startswith('#EXTINF:'):
            continue

        title_match = re.search(r',(.+)$', line)
        cat_match = re.search(r'group-title="([^"]+)"', line)
        logo_match = re.search(r'tvg-logo="([^"]+)"', line)

        if not title_match:
            continue

        title = title_match.group(1).strip()
        category = cat_match.group(1).strip() if cat_match else 'Uncategorized'
        logo = logo_match.group(1) if logo_match else ICON

        is_adult = (
            '18+' in category.upper() or
            'XXX' in category.upper() or
            '18+' in title.upper() or
            'XXX' in title.upper()
        )

        if is_adult:
            continue

        stream_url = lines[i + 1].strip() if i + 1 < len(lines) else ''
        if not stream_url:
            continue

        categories.setdefault(category, []).append({
            'title': title,
            'url': stream_url,
            'logo': logo
        })

    EXTRA_CHANNELS_DATA = categories

    addon.setSetting(
        'extra_channels_cache',
        json.dumps({'timestamp': int(time.time()), 'channels': EXTRA_CHANNELS_DATA})
    )

    return EXTRA_CHANNELS_DATA

def ExtraChannels_Main():
    global EXTRA_CHANNELS_DATA
    if not EXTRA_CHANNELS_DATA:
        load_extra_channels() 
        if not EXTRA_CHANNELS_DATA:
            xbmcgui.Dialog().ok("Error", "Extra channels could not be loaded.")
            return

    addDir('[B][COLOR gold]Search Extra Channels / VODs[/COLOR][/B]',
           build_url({'mode': 'extra_search'}), True)

    for cat in sorted(EXTRA_CHANNELS_DATA.keys()):
        is_adult_cat = (
            '18+' in cat.upper() or
            'XXX' in cat.upper()
        )

        if is_adult_cat:
            continue
    
        addDir(cat, build_url({'mode': 'extra_list', 'category': cat}), True, logo="https://images-ext-1.discordapp.net/external/fUzDq2SD022-veHyDJTHKdYTBzD9371EnrUscXXrf0c/%3Fsize%3D4096/https/cdn.discordapp.com/icons/1373713080206495756/1fe97e658bc7fb0e8b9b6df62259c148.png?format=webp&quality=lossless")

    
    closeDir()



def ExtraChannels_Search():
    """
    Open a dialog to search for a channel or VOD in the extra list.
    """
    keyboard = xbmcgui.Dialog().input("Search Extra Channels / VODs", type=xbmcgui.INPUT_ALPHANUM)
    if not keyboard or keyboard.strip() == '':
        closeDir()
        return
    search_term = keyboard.strip()
    ExtraChannels_List(None, search_term) 


def ExtraChannels_List(category=None, search=None):
    """
    List ExtraChannels, optionally filtering by category or search term,
    enforcing adult access where needed.
    """
    global EXTRA_CHANNELS_DATA
    if not EXTRA_CHANNELS_DATA:
        load_extra_channels()  
        if not EXTRA_CHANNELS_DATA:
            xbmcgui.Dialog().ok("Error", "Extra channels could not be loaded.")
            return

    items_to_show = []

    for cat, streams in EXTRA_CHANNELS_DATA.items():
        if category and cat != category:
            continue

        is_adult_cat = (
            '18+' in cat.upper() or
            'XXX' in cat.upper()
        )
        if is_adult_cat:
            continue

        for item in streams:
            # L6: removed redundant inner `if category and cat != category` check (already filtered above)
            if search and search.lower() not in item['title'].lower():
                continue

            is_adult = (
                '18+' in item['title'].upper() or
                'XXX' in item['title'].upper()
            )
            if is_adult:
                continue

            items_to_show.append({
                'title': item['title'],
                'url': item['url'],
                'logo': item.get('logo', ICON)
            })

    for item in items_to_show:
        addDir(
            item['title'],
            build_url({'mode': 'extra_play', 'url': item['url'], 'logo': item.get('logo', ICON), 'name': item['title']}),
            False,
            logo=item.get('logo', ICON)
        )

    closeDir()


def ExtraChannels_Play(url, name='Extra Channel', logo=ICON):
    """
    Play a channel or VOD from ExtraChannels, enforcing adult access.
    """
    try:

        log(f'[ExtraChannels_Play] Original URL: {url}')

        if 'a1xmedia' in url.lower() or 'a1xs.vip' in url.lower():
            headers = {
                'User-Agent': UA,
                'Accept': '*/*',
                'Accept-Language': 'en-US,en;q=0.9',
                'Referer': 'https://a1xs.vip/'
            }
            try:
                response = requests.head(url, headers=headers, allow_redirects=True, timeout=10)
                url = response.url
                log(f'[ExtraChannels_Play] Resolved A1XMedia URL: {url}')
            except Exception as e:
                log(f'[ExtraChannels_Play] Failed to resolve A1XMedia URL, using original: {e}')

        elif 'daddylive' in url.lower() or 'dlhd' in url.lower():
            parsed_url = urlparse(url)
            qs_url = dict(parse_qsl(parsed_url.query))
            channel_id = qs_url.get('id', '').split('|')[0].strip()
            if not channel_id:
                m = re.search(r'(?:id=|premium)(\d+)', url)
                if m:
                    channel_id = m.group(1)
            if channel_id:
                PlayStream(abs_url('watch.php?id=' + channel_id))
                return
            log(f'[ExtraChannels_Play] Could not extract channel ID from: {url}')

        logo = logo or ICON
        liz = xbmcgui.ListItem(name, path=url)
        liz.setArt({'thumb': logo, 'icon': logo, 'fanart': FANART})
        if getKodiversion() < 20:
            liz.setInfo('video', {'title': name, 'plot': name})
        else:
            _infotag = liz.getVideoInfoTag()
            _infotag.setMediaType('video')
            _infotag.setTitle(name)
            _infotag.setPlot(name)

        if '.m3u8' in url.lower():
            liz.setProperty('inputstream', 'inputstream.adaptive')
            liz.setProperty('inputstream.adaptive.manifest_type', 'hls')
            liz.setMimeType('application/vnd.apple.mpegurl')
            log('[ExtraChannels_Play] HLS stream detected')
        elif url.lower().endswith('.mp4'):
            liz.setMimeType('video/mp4')
            log('[ExtraChannels_Play] MP4 stream detected')
        else:
            liz.setMimeType('video')
            log('[ExtraChannels_Play] Generic video stream')

        liz.setProperty('IsPlayable', 'true')
        xbmcplugin.setResolvedUrl(addon_handle, True, liz)
        log(f'[ExtraChannels_Play] Stream started for: {name}')

    except Exception as e:
        log(f'[ExtraChannels_Play] Error: {e}')
        import traceback
        log(f'Traceback: {traceback.format_exc()}')
        xbmcgui.Dialog().notification("DLTV", "Failed to play channel", ICON, 3000)


# ── Auto-discover server URLs: load cache if fresh, refresh in background if stale ──
def _proxy_host_reachable(url, timeout=1.5):
    """Quick TCP connectivity check — returns True if the proxy host accepts connections."""
    try:
        from urllib.parse import urlparse as _up
        import socket as _sock
        _p = _up(url)
        _port = _p.port or (443 if _p.scheme == 'https' else 80)
        _c = _sock.create_connection((_p.hostname, _port), timeout=timeout)
        _c.close()
        return True
    except Exception:
        return False

try:
    _disco_fresh = False
    if os.path.exists(_DISCOVERY_CACHE_FILE):
        if time.time() - os.path.getmtime(_DISCOVERY_CACHE_FILE) < _DISCOVERY_CACHE_TTL:
            with open(_DISCOVERY_CACHE_FILE) as _f:
                _d = json.load(_f)
            if _d.get('proxy') and _d.get('lookup') and _d.get('ksohls'):
                # Validate cached proxy is still reachable before committing to it
                if _proxy_host_reachable(_d['proxy']):
                    CHEVY_PROXY = _d['proxy']
                    CHEVY_LOOKUP = _d['lookup']
                    _KSOHLS_BASE = _d['ksohls']
                    PLAYER_REFERER = _KSOHLS_BASE + '/'
                    _SEG_HEADERS['Origin'] = _KSOHLS_BASE
                    _SEG_HEADERS['Referer'] = PLAYER_REFERER
                    addon.setSetting('chevy_proxy_url', CHEVY_PROXY)
                    addon.setSetting('chevy_lookup_url', CHEVY_LOOKUP)
                    addon.setSetting('ksohls_base_url', _KSOHLS_BASE)
                    _disco_fresh = True
                    log(f'[Discovery] Cache OK: ksohls={_KSOHLS_BASE} proxy={CHEVY_PROXY}')
                else:
                    log(f'[Discovery] Cached proxy unreachable ({_d["proxy"]}) — resetting to builtin servers')
                    try:
                        os.remove(_DISCOVERY_CACHE_FILE)
                    except Exception:
                        pass
                    # Reset globals and addon settings to builtin defaults
                    CHEVY_PROXY = _CHEVY_PROXY_BUILTIN
                    CHEVY_LOOKUP = _CHEVY_LOOKUP_BUILTIN
                    addon.setSetting('chevy_proxy_url', '')
                    addon.setSetting('chevy_lookup_url', '')
    if not _disco_fresh:
        threading.Thread(target=_discover_server_urls, daemon=True).start()
except Exception as _e:
    log(f'[Discovery] init error: {_e}')
    threading.Thread(target=_discover_server_urls, daemon=True).start()

if not params.get('mode'):
    Main_Menu()
else:
    mode = params.get('mode')

    if mode == 'menu':
        servType = params.get('serv_type')
        if servType == 'sched':
            Menu_Trans()
        elif servType == 'live_tv':
            list_gen()
        elif servType == 'lang_menu':
            list_by_language()
        elif servType == 'favorites':
            list_favorites()
        elif servType == 'extra_channels':
            ExtraChannels_Main()
        elif servType == 'search':
            Search_Events()
        elif servType == 'search_channels':
            Search_Channels()
        elif servType == 'search_by_number':
            Search_Channel_By_Number()
        elif servType == 'refresh_schedule':
            try:
                cache = _load_page_cache()
                removed = sum(1 for u in list(cache) if 'index.php' in u or '24-7' in u)
                for u in list(cache):
                    if 'index.php' in u or '24-7' in u:
                        del cache[u]
                _save_page_cache(cache)
                xbmcgui.Dialog().notification('DLTV', f'Schedule cache cleared ({removed} page(s))', ICON, 2500)
            except Exception as e:
                xbmcgui.Dialog().notification('DLTV', f'Error: {e}', ICON, 3000)
            xbmcplugin.endOfDirectory(addon_handle, False)
            xbmc.executebuiltin('Container.Refresh')
        elif servType == 'diagnostics':
            run_diagnostics()
            xbmcplugin.endOfDirectory(addon_handle, False)
        elif servType == 'export_m3u':
            pvr_setup()
            xbmcplugin.endOfDirectory(addon_handle, False)
        elif servType == 'chat':
            try:
                xbmc.executebuiltin('StartAndroidActivity("", "android.intent.action.VIEW", "", "https://daddylivehd.chatango.com/")')
            except Exception:
                xbmcgui.Dialog().ok('DaddyLive Chat', 'Open: https://daddylivehd.chatango.com/')
            xbmcplugin.endOfDirectory(addon_handle, False)

    elif mode == 'showChannels':
        transType = params.get('trType')
        channels_list = getTransData(transType)
        ShowChannels(transType, channels_list)

    elif mode == 'trList':
        transType = params.get('trType')
        channels_list = json.loads(params.get('channels'))
        TransList(transType, channels_list)

    elif mode == 'trLinks':
        trData = params.get('trData')
        getSource(trData)

    elif mode == 'play':
        link = params.get('url')
        PlayStream(link)

    elif mode == 'diagnostics':
        run_diagnostics()

    elif mode == 'add_by_id':
        cid = xbmcgui.Dialog().input('Channel ID to add', type=xbmcgui.INPUT_NUMERIC)
        if cid and cid.strip().isdigit():
            cid = cid.strip()
            favs = get_favorites()
            if any(f['id'] == cid for f in favs):
                xbmcgui.Dialog().notification('DLTV', f'Channel {cid} already in favorites', ICON, 2000)
            else:
                real_name = _lookup_channel_name(cid) or f'Channel {cid}'
                favs.append({'id': cid, 'name': real_name})
                save_favorites(favs)
                xbmcgui.Dialog().notification('DLTV', f'Added: {real_name}', ICON, 3000)
                xbmc.executebuiltin('Container.Refresh')
        xbmcplugin.endOfDirectory(addon_handle, False)

    elif mode == 'toggle_fav':
        toggle_favorite(params.get('cid', ''), params.get('name', ''))

    elif mode == 'probe_favorites':
        favs = get_favorites()
        if favs:
            xbmcgui.Dialog().notification('DLTV', f'Checking {len(favs)} channels…', ICON, 2000)
            _probe_favorites_background(favs, force=True)
        xbmcplugin.endOfDirectory(addon_handle, False)

    elif mode == 'lang_channels':
        list_lang_channels(params.get('lang', 'eng'))

    elif mode == 'extra_channels':
        ExtraChannels_Main()

    elif mode == 'extra_search':
        ExtraChannels_Search()

    elif mode == 'extra_list':  
        cat = params.get('category')
        search_term = params.get('search')
        ExtraChannels_List(cat, search_term)

    elif mode == 'extra_play':
        url = params.get('url')
        logo = params.get('logo', ICON)
        name = params.get('name', 'Extra Channel')
        ExtraChannels_Play(url, name=name, logo=logo)

