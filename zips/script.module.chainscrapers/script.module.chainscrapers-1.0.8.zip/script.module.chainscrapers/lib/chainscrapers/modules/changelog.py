# -*- coding: utf-8 -*-
"""
	Fenomscrapers Module
"""

from chainscrapers.modules.control import addonPath, addonVersion, joinPath
from chainscrapers.windows.textviewer import TextViewerXML


def get():
	chainscrapers_path = addonPath()
	chainscrapers_version = addonVersion()
	changelogfile = joinPath(chainscrapers_path, 'changelog.txt')
	r = open(changelogfile, 'r', encoding='utf-8', errors='ignore')
	text = r.read()
	r.close()
	heading = '[B]chainscrapers -  v%s - ChangeLog[/B]' % chainscrapers_version
	windows = TextViewerXML('textviewer.xml', chainscrapers_path, heading=heading, text=text)
	windows.run()
	del windows