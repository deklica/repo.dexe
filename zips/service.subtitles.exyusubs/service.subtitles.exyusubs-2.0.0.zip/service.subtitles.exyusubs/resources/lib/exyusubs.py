# -*- coding: utf-8 -*-
# ExyuSubs - pretraga, izbor i učitavanje ex-yu titlova sa OpenSubtitles
# (Stremio, REST, XML-RPC). Ulazna tačka je run(), poziva je main.py.
import sys
import os
import re
import io
import json
import time
import math
import codecs
import unicodedata
import struct
import base64
import gzip
import zipfile
import threading
import functools
import collections
import requests
import urllib.parse
from urllib.parse import unquote
import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs
import xbmcaddon


# ============================================================
#  ADDON INFO
# ============================================================

ADDON        = xbmcaddon.Addon()
ADDON_ID     = ADDON.getAddonInfo('id')
ADDON_NAME   = ADDON.getAddonInfo('name')
ADDON_VER    = ADDON.getAddonInfo('version')
PROFILE      = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))


# ============================================================
#  LANGUAGE CONFIGURATION
# ============================================================

# Kandidati za dekodiranje, poređani po verovatnoći za ex-yu titlove.
EXYU_ENCODINGS = [
    'cp1250',        # Windows centralna Evropa - najčešći za ex-yu latinicu
    'cp1251',        # Windows ćirilica - srpski/makedonski
    'iso-8859-2',    # Latin-2 - stariji ex-yu titlovi
    'cp1252',        # Windows zapadna Evropa - engleski
    'iso-8859-1',    # Latin-1 - engleski
    'iso-8859-5',    # ISO ćirilica
    'cp852',         # DOS centralna Evropa - vrlo stari titlovi
    'mac_latin2',    # Mac centralna Evropa
]

# Slova koja OČEKUJEMO u ex-yu latiničnom tekstu
EXYU_LATIN_CHARS = set('čćžšđČĆŽŠĐ')

# Ćirilica (srpska + makedonska) - legitimna ako je tekst pretežno ćiriličan
EXYU_CYRILLIC_CHARS = set(
    'абвгдђежзијклљмнњопрстћуфхцчџшАБВГДЂЕЖЗИЈКЛЉМНЊОПРСТЋУФХЦЧЏШ'
    'ѓѕќѐѝЃЅЌЀЍ'
)

# Znakovi koji su gotovo sigurno posledica pogrešnog dekodiranja
SUSPICIOUS_CHARS = set(
    'ÐðÞþÝýÿ¤¦©«¬®¯°±µ¶·¸¹º»¼½¾¿×÷'
    'àâãäåæçèêëìîïñòôõöøùûüÀÂÃÄÅÆÇÈÊËÌÎÏÑÒÔÕÖØÙÛÜ'
    'ЉЊЂЋЏљњ'
)

# Nelomljivi razmak posle [Local] i posle naziva titla, da Kodi ne prelomi red odmah iza oznake.
NBSP = '\u00a0'

# Najveća dužina naziva titla u logu
LOG_NAME_LEN = 90

# Podržani formati titlova. Ekstenzija se čuva, jer po njoj Kodi bira parser.
SUB_EXTENSIONS = ('.srt', '.sub', '.txt', '.ssa', '.ass', '.vtt', '.smi')

# Prepoznavanje SDH/CC titlova po nazivu fajla - dopuna nepouzdanom polju SubHearingImpaired.
SDH_PATTERN = re.compile(r'\b(sdh|cc|hearing.?impaired|closed.?caption)\b', re.IGNORECASE)

# lang_code služi i za Kodi oznaku jezika i za zastavicu
EXYU_LANGUAGES = [
    {'lang_code': 'sr', 'label': 'Serbian',     'stremio': ['srp', 'scc'], 'rest': ['scc']},
    {'lang_code': 'sr', 'label': 'Montenegrin', 'stremio': ['mne'],        'rest': ['mne']},
    {'lang_code': 'bs', 'label': 'Bosnian',     'stremio': ['bos'],        'rest': ['bos']},
    {'lang_code': 'hr', 'label': 'Croatian',    'stremio': ['hrv'],        'rest': ['hrv']},
    {'lang_code': 'sl', 'label': 'Slovenian',   'stremio': ['slv'],        'rest': ['slv']},
    {'lang_code': 'mk', 'label': 'Macedonian',  'stremio': ['mkd', 'mac'], 'rest': ['mac']},
]

# Engleski nije u glavnoj listi - koristi se samo kao rezervna pretraga (FALLBACK_TO_ENGLISH).
ENGLISH_LANGUAGE = {
    'lang_code': 'en', 'label': 'English', 'stremio': ['eng'], 'rest': ['eng']
}

# Jezici van interne liste (režim Kodi jezika) dobijaju oznake preko Kodijeve
# ISO 639-2/B konverzije. OpenSubtitles za neke jezike koristi drugu oznaku.
OS_LANG_OVERRIDES = {
    'greek': 'ell',
    'portuguese (brazil)': 'pob',
    'chinese (simple)': 'chi',
    'chinese (traditional)': 'zht',
}

# ISO 639-2/B -> 639-2/T, za jezike kod kojih se oznake razlikuju
ISO6392_B_TO_T = {
    'alb': 'sqi', 'arm': 'hye', 'baq': 'eus', 'bur': 'mya', 'chi': 'zho',
    'cze': 'ces', 'dut': 'nld', 'fre': 'fra', 'geo': 'kat', 'ger': 'deu',
    'gre': 'ell', 'ice': 'isl', 'mac': 'mkd', 'may': 'msa', 'per': 'fas',
    'rum': 'ron', 'slo': 'slk', 'tib': 'bod', 'wel': 'cym',
}


# ============================================================
#  API CONFIGURATION
# ============================================================

# TMDB - razrešavanje IMDB ID-a kada ga stavka nema
TMDB_API_KEY  = base64.b64decode("OGFkM2MyMWE5MmE2NGRhODMyYzU1OWQ1OGNjNjNhYjQ=").decode()
TMDB_BASE_URL = "https://api.themoviedb.org/3"

# Stremio OpenSubtitles v3 wrapper - primarni izvor titlova
STREMIO_BASE_URL = "https://opensubtitles-v3.strem.io/subtitles"

# Cinemeta - Stremio katalog metapodataka po IMDB ID-u: provera ID-a, razrešavanje po nazivu i mapiranje antologija.
CINEMETA_BASE_URL = "https://v3-cinemeta.strem.io"

# OpenSubtitles.org XML-RPC - rezervna pretraga i hash upit
OPENSUB_XMLRPC_URL = "https://api.opensubtitles.org/xml-rpc"
# User-agent za XML-RPC. Pravo na preuzimanje vezano je za sesiju, a
# sesija za registrovan user-agent; neregistrovan umesto titla dobija VIP poruku.
OPENSUB_UA_NAME    = "XBMC_Subtitles_Unofficial"
OPENSUB_USER_AGENT = f"{OPENSUB_UA_NAME}_v{ADDON_VER}"

# XML-RPC token se čuva u svojstvima Home prozora, zajedno sa vremenom
# prijave i user-agentom, da se LogIn ne ponavlja pri svakoj pretrazi.
OS_TOKEN_PROP     = 'exyusubs.os_token'
OS_TOKEN_TS_PROP  = 'exyusubs.os_token_ts'
OS_TOKEN_UA_PROP  = 'exyusubs.os_token_ua'
OS_TOKEN_MAX_AGE  = 13 * 60      # sekundi, ispod serverskih 15 min

# Najveći broj rezultata XML-RPC upita. Kada je dostignut, upit se ponavlja samo za jezike pretrage, bez engleskog.
OS_RESULT_CAP = 100

# OpenSubtitles.org REST - nazivi fajlova i metapodaci titlova. Server prima
# jedan jezik po upitu i vraća najviše REST_RESULT_CAP titlova, pa se šalje
# po jedan upit za svaki jezik koji Stremio vrati.
OPENSUB_REST_URL   = "https://rest.opensubtitles.org/search"
REST_RESULT_CAP    = 100

# Koliko dugo (s) važi sačuvan REST odgovor (u memoriji, ne na disku). Čuva
# ga i nit čiji je odgovor stigao posle prikaza liste, pa ponovno otvaranje
# dijaloga ne čeka server.
REST_CACHE_MAX_AGE = 3600


# ============================================================
#  HTTP HEADERS
# ============================================================

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36'
}


# ============================================================
#  BEHAVIOR OPTIONS
# ============================================================

# True = titl se konvertuje u UTF-8 pre snimanja (preporučeno)
CONVERT_TO_UTF8 = True

# Prevođenje ćiriličnog srpskog i bosanskog titla u latinicu, prema
# preferiranom jeziku pretrage ('original' i 'default' se prevode u konkretan
# jezik, kao u Kodiju). Makedonski ostaje ćiriličan. Radi uz CONVERT_TO_UTF8 = True.
#
# Preferirani jezik nije srpski ni makedonski (hrvatski, bosanski, slovenački, Kodi jezici):
# 'non_serbian' = prevodi se, i pri automatskom učitavanju i iz liste
# 'never'       = ne prevodi se
CYRILLIC_TO_LATIN = 'non_serbian'

# Preferirani srpski, Serbo-Croatian ili bez preferiranog jezika:
# 'auto'   = prevodi se samo pri automatskom učitavanju; iz liste ostaje
#            ćirilica (podrazumevano)
# 'always' = prevodi se i iz liste
# 'never'  = ne prevodi se
CYRILLIC_TO_LATIN_SERBIAN = 'auto'

# Najveći broj titlova u listi (0 ili None = bez ograničenja). Lista se seče
# po redosledu jezika; automatski izabran titl je prvi i ne odseca se.
MAX_RESULTS = 100

# Jezici pretrage - uvek ili interna lista ili Kodi jezici, nikad oba.
# Preferirani jezik važi samo ako je među jezicima pretrage.
# True  = interna lista (EXYU_LANGUAGES); preferirani engleski ne važi;
#         automatski izbor ostaje u jezičkoj grupi preferiranog (inače prvog) jezika
# False = jezici izabrani u Kodi podešavanjima za titlove, bilo koji; važi
#         i 'Forced only'. Kodi ih šalje bez prioriteta, pa automatski
#         izbor bira među svima: dokazana sinhronizacija (hash, grupa), pa
#         preferirani jezik.
#         Pravila pisma za ex-yu jezike važe samo za ex-yu titlove.
USE_INTERNAL_LANGUAGES = True

# True  = bez IMDB ID-a traži se po nazivu (OpenSubtitles query) - samo
#         kada ID nedostaje, nikad kao dopuna pretrage po ID-u
# False = bez IMDB ID-a pretraga se prekida
TITLE_SEARCH_FALLBACK = True

# True  = ako nijedan titl nije nađen za izabrane jezike, pokušava se
#         još jedna pretraga na engleskom (i kada su nađene samo ostale
#         ex-yu grupe, uz ENGLISH_WITH_OTHER_GROUPS)
# False = bez dodatne pretrage, lista ostaje prazna
FALLBACK_TO_ENGLISH = True

# Ex-yu jezičke grupe (srpsko-hrvatska, slovenačka, makedonska) uz internu
# listu i preferirani ex-yu jezik; bez preferiranog jezika i sa Kodi
# jezicima (jezike bira korisnik) ne važe.
# True  = traže se i prikazuju i titlovi ostalih grupa, ispod preferiranog jezika
# False = samo jezici grupe preferiranog jezika
SHOW_OTHER_LANG_GROUPS = True

# Uz SHOW_OTHER_LANG_GROUPS = True i englesku rezervu (FALLBACK_TO_ENGLISH,
# english=1), kada su nađeni samo titlovi ostalih ex-yu grupa:
# True  = dodaje se i engleska rezerva, ispod njih
# False = engleska rezerva se ne traži
ENGLISH_WITH_OTHER_GROUPS = True

# True  = određuje se da li je titl sinhronizovan sa videom koji se pušta;
#         'sync' ikona se pali za hash pogodak, istu release grupu i isto
#         web izdanje istog provajdera
# False = sync ikona se nikad ne pali
DETECT_SYNC = True

# ------------------------------------------------------------
#  AUTO-DOWNLOAD OPTIONS
# ------------------------------------------------------------
# 'kodi_if_default' = uključeno Kodi podešavanje "Auto-download first
#                     subtitle" i addon je podrazumevani servis za taj
#                     tip sadržaja (podrazumevano)
# 'kodi'            = samo Kodi podešavanje
# 'always'          = uvek
# 'never'           = nikad, lista uvek ostaje korisniku
AUTODOWNLOAD_MODE = 'kodi_if_default'

# Engleski titl iz rezerve (FALLBACK_TO_ENGLISH), kada addon radi sam:
# False = ostaje u listi, ne učitava se automatski
# True  = učitava se automatski kada je jedini nađen
# Ne važi za engleski među izabranim jezicima (običan jezik), ni za
# pozadinski poziv, gde se engleski iz rezerve učitava kada je jedini nađen.
AUTODOWNLOAD_ENGLISH = False

# Kada addon ne učita titl, Kodijev auto-download bi sam skinuo prvu
# stavku liste. True = Kodi podešavanje se privremeno gasi dok Kodi prima listu.
BLOCK_KODI_AUTO       = True
BLOCK_KODI_AUTO_DELAY = 2000   # ms

# Oznaka privremeno ugašenog podešavanja - ako proces bude prekinut,
# sledeće pokretanje addona ga vraća.
BLOCK_KODI_AUTO_PROP  = 'exyusubs.downloadfirst_off'

# True = titl skida i primenjuje addon, i kada video već ima titl traku
# (Kodijev auto-download tada ne radi). False = u plejeru addon ne učitava
# titl sam, to radi Kodijev auto-download.
AUTODOWNLOAD_FORCE = True

# Dijalozi koji se zatvaraju posle auto-učitavanja, po ID-u:
#   10153 = WINDOW_DIALOG_SUBTITLES (lista titlova)
#   10159 = WINDOW_DIALOG_SUBTITLE_OSD_SETTINGS (OSD izbor titla)
AUTO_CLOSE_WINDOWS = (10153, 10159)

# Najduže čekanje (ms) da plejer registruje primenjeni titl kao traku
AUTO_TRACK_WAIT = 1500
AUTO_TRACK_STEP = 100

# Oznaka obavljenog auto-učitavanja - jednom po reprodukciji. Čuva
# identitet reprodukcije, vreme i broj titl traka, po kojem se prepoznaje
# novo puštanje istog videa.
AUTO_DONE_PROP     = 'exyusubs.autodl_file'
AUTO_DONE_TS_PROP  = 'exyusubs.autodl_ts'
AUTO_DONE_CNT_PROP = 'exyusubs.autodl_tracks'

# Trajanje oznake auto-učitavanja - duže od filma, da auto ne pregazi
# ručno izabran titl.
AUTO_DONE_MAX_AGE = 12 * 3600

# ------------------------------------------------------------
#  BACKGROUND SEARCH API
#  Poziv iz drugog addona, bez dijaloga.
#
#    plugin://service.subtitles.exyusubs/?action=background
#        [&languages=Serbian,Croatian]   jezici pozivaoca (uz kodilangs=2)
#        [&preferredlanguage=Serbian]    preferirani jezik; ima prednost
#                                        nad Kodi podešavanjem
#        [&kodilangs=0|1|2]              0 = interna lista, 1 = Kodi jezici,
#                                        2 = parametar 'languages'
#        [&english=1|0]                  1 = engleska rezerva kada za
#                                        izabrane jezike nema ničega;
#                                        nađeni engleski titl se učitava
#                                        (ne i uz titlove ostalih ex-yu
#                                        grupa - ENGLISH_WITH_OTHER_GROUPS)
#
#  Parametri važe samo za taj poziv i imaju prednost nad
#  USE_INTERNAL_LANGUAGES i FALLBACK_TO_ENGLISH. Bez kodilangs važi
#  'languages' ako je dat, inače USE_INTERNAL_LANGUAGES. Liste nema, pa se
#  engleski titl iz rezerve učitava; bez rezerve pozivalac dobija 'none'.
#  Poziv je zahtev za automatsko učitavanje, pa se podešavanja dijaloga
#  ne proveravaju. Ako auto-učitavanje za isti video već radi, poziv čeka
#  njegov kraj.
#
#  Rezultat se upisuje u Home prozor (10000):
#    exyusubs.bg_file   = video na koji se status odnosi
#    exyusubs.bg_status = running | applied | english | list | none |
#                         skipped | disabled | error
#      applied  - titl učitan
#      english  - učitan engleski titl iz rezerve (za izabrane jezike
#                 nije nađen nijedan)
#      list     - titlova ima, ali nijedan nije za automatsko učitavanje
#      none     - ništa nije nađeno
#      skipped  - u plejeru je već aktivan titl
#      disabled - BACKGROUND_SEARCH = False
#      error    - plejer nije aktivan, greška ili neuspelo preuzimanje
# ------------------------------------------------------------
BACKGROUND_SEARCH = True

BG_STATUS_PROP = 'exyusubs.bg_status'
BG_FILE_PROP   = 'exyusubs.bg_file'
BG_TS_PROP     = 'exyusubs.bg_ts'
BG_KEY_PROP    = 'exyusubs.bg_key'     # interno: identitet reprodukcije

# Najduže trajanje statusa 'running' - stariji se smatra prekinutim
BG_RUNNING_MAX_AGE = 60

# Brava auto-učitavanja između dijaloga i pozadinske pretrage (odvojeni
# procesi). Dijalog bez brave prikazuje samo listu; pozadinska pretraga
# čeka bravu, pa ponovo proverava stanje. Brava starija od
# AUTO_LOCK_MAX_AGE smatra se napuštenom.
AUTO_LOCK_PROP    = 'exyusubs.auto_lock'
AUTO_LOCK_MAX_AGE = 60
AUTO_LOCK_SETTLE  = 100     # ms

# Ćirilica se u auto-izboru prihvata samo za jezike koji je koriste.
# Pismo se vidi tek iz preuzetog teksta, pa je broj pokušaja ograničen.
CYRILLIC_OK_LANGS  = ('sr', 'mk')
CYRILLIC_THRESHOLD = 0.5
AUTO_MAX_ATTEMPTS  = 3

# Najkraće vreme (s) za preuzimanje auto-izbora, i kada je rok pretrage
# skoro istekao
AUTO_MIN_DOWNLOAD_TIME = 5

# Jezičke grupe za auto-izbor - jezici iste grupe su međusobno
# zamenjivi. Lista prikazuje sve grupe, osim uz SHOW_OTHER_LANG_GROUPS = False.
LANG_GROUPS = {
    'sr': 'bhs',
    'hr': 'bhs',
    'bs': 'bhs',
    'mk': 'mk',
    'sl': 'sl',
}

# Sync nivoi, manji broj = pouzdaniji dokaz sinhronizacije. Sync ikonu
# dobijaju hash, grupa i provajder; nivo oznaka je procena i utiče samo na
# rangiranje. Preko preferiranog jezika (Kodi jezici) mogu samo hash i grupa.
SYNC_TIER_HASH     = 0  # OS MatchedBy='moviehash' - dokaz, ne procena
SYNC_TIER_GROUP    = 1  # ista release grupa, bez sukoba izvora i reza
SYNC_TIER_PROVIDER = 2  # web izdanje istog provajdera, iste oznake izdanja
SYNC_TIER_TAGS     = 3  # ista porodica izvora ili poklapanje kvaliteta
SYNC_TIER_NONE     = 4  # nema signala


def sync_icon(tier):
    """Vrednost 'sync' svojstva stavke: 'true' za hash, grupu i provajdera."""
    return 'true' if tier <= SYNC_TIER_PROVIDER else 'false'

# Neocenjen titl (ocena 0) boduje se kao srednja ocena
NEUTRAL_RATING = 3

# Veličina uzorka sa početka fajla za prepoznavanje pisma i kodne strane
SCRIPT_SAMPLE_CHARS   = 4000
ENCODING_SAMPLE_BYTES = 16384

# Bodovi kvaliteta - presuđuju tek unutar istog sync i jezičkog nivoa
SCORE_TRUSTED      = 3
SCORE_RANK_HIGH    = 2      # administrator, platinum, gold, vip
SCORE_RANK_TRUSTED = 1      # trusted member
SCORE_SDH_PENALTY  = -2
SCORE_AI_PENALTY   = -4

# Hash i naziv izdanja za HTTP stream: dva Range zahteva daju
# OpenSubtitles hash, a zaglavlje Content-Disposition originalni naziv
# fajla. Radi u pozadini, paralelno sa pretragom, jednom po reprodukciji.
STREAM_HASH_ENABLED = True

# True  = stream hash i kada se prikazuje samo lista (dijalog otvoren
#         ručno, ručna pretraga); lista ga čeka najviše TIMEOUT_HASH_LIST
# False = stream hash samo za automatski izbor (ako lista stiže presporo)
STREAM_HASH_LIST = True

# Manifest streamovi nemaju jedan fajl, pa ni hash
STREAM_MANIFEST_EXT = ('.m3u8', '.mpd', '.ism', '.isml')

# IPTV VOD (Xtream Codes) putanje - probe se preskače, jer dodatna
# konekcija ka panelu može da prekine reprodukciju.
STREAM_PROBE_SKIP = re.compile(r'/(?:movie|series)/[^/]+/[^/]+/\d+\.[a-z0-9]{2,5}$',
                               re.IGNORECASE)

# Koliko sati preuzet titl ostaje u special://temp/exyusubs/ za ponovno
# učitavanje. Starije fajlove briše addon.
STAGING_KEEP_HOURS = 24
STAGING_MAX_AGE    = STAGING_KEEP_HOURS * 3600

# Sheme putanja za koje se hash ne računa čitanjem fajla (sporo preko
# mreže). Za HTTP(S) hash računa stream probe, za ostale ostaje poređenje
# po nazivu izdanja.
NO_HASH_SCHEMES = (
    'plugin://', 'http://', 'https://', 'ftp://', 'ftps://',
    'rtmp://', 'rtmpe://', 'rtsp://', 'udp://', 'rtp://',
    'upnp://', 'pvr://', 'stack://', 'sftp://', 'dav://', 'davs://',
)

# Tagovi izvora ripa, grupisani u porodice. Porede se kao celi tokeni naziva.
SOURCE_FAMILIES = {
    'web':       ['webdl', 'webrip', 'web', 'amzn', 'nf', 'dsnp', 'hmax',
                  'atvp', 'itunes', 'pcok', 'stan', 'crav', 'hulu', 'ma',
                  'dcu', 'pmtp'],
    'disc':      ['bluray', 'blu', 'bdrip', 'brrip', 'bdmux', 'bdremux',
                  'uhdremux', 'remux', 'hddvd', 'dvdrip', 'dvd5', 'dvd9',
                  'dvdr', 'dvd'],
    'tv':        ['hdtv', 'pdtv', 'sdtv', 'dsr', 'dvbrip', 'dvbc', 'dvbs',
                  'ahdtv', 'uhdtv'],
    'cam':       ['telesync', 'hdts', 'ts', 'tsrip', 'cam', 'camrip', 'hdcam',
                  'hqcam', 'telecine', 'tc', 'hdtc', 'screener', 'dvdscr',
                  'bdscr', 'scr', 'workprint', 'r5', 'pdvd', 'vhsrip'],
}

# Provajderi web izvora - različiti provajderi često imaju različit tajming.
WEB_PROVIDERS = ('amzn', 'nf', 'dsnp', 'hmax', 'atvp', 'itunes', 'pcok',
                 'stan', 'crav', 'hulu', 'ma', 'dcu', 'pmtp')

# Tokeni reza izdanja - pored izvora jedini utiču na tajming; rezolucija, kodek i zvuk ne utiču.
RELEASE_TAGS = [
    'proper', 'repack', 'rerip', 'extended', 'unrated', 'uncut',
    'directors', 'theatrical', 'remastered', 'imax', 'hybrid',
]

# Oznake verzije filma (različito trajanje) - različita verzija isključuje poklapanje i kod iste release grupe
EDITION_TAGS = {'extended': 'extended', 'unrated': 'unrated', 'uncut': 'uncut',
                'directors': 'directors', 'director': 'directors', 'dc': 'directors',
                'theatrical': 'theatrical'}

# Oznake trackera i distributera koje se dopisuju iza naziva izdanja - nisu
# release grupe
TRACKER_TAGS = ('tgx', 'torrentgalaxy', 'ettv', 'eztv', 'eztvx', 'rartv',
                'publichd', 'ethd', '1337x', 'tjet', 'obfuscated')

# Oznake na kraju naziva titla koje nisu deo naziva izdanja: jezik, pismo, kodna strana, SDH
SUB_NAME_SUFFIXES = (
    'sdh', 'cc', 'hi', 'forced', 'eng', 'en', 'english',
    'ser', 'srp', 'scc', 'sr', 'srb', 'srpski', 'serbian',
    'hrv', 'hr', 'cro', 'hrvatski', 'croatian',
    'bos', 'bs', 'bosanski', 'bosnian', 'mne', 'cg', 'crnogorski',
    'slv', 'sl', 'slo', 'slovenski', 'slovenian',
    'mac', 'mk', 'mkd', 'makedonski', 'macedonian',
    'lat', 'latn', 'latin', 'latinica', 'cyr', 'cyrl', 'cir', 'cirilica',
    'ćirilica', 'cyrillic', 'utf8', 'utf-8', 'ansi', 'cp1250', 'cp1251',
    'win1250', 'win1251', 'yu', 'exyu', 'ex-yu', 'titl', 'titlovi', 'prevod',
)

# Kategorije kvaliteta - slab signal, jedan bod po kategoriji; odlučuje kada porodica izvora nije poznata (SYNC_TAG_THRESHOLD).
QUALITY_TAGS = {
    'res':   ('2160p', '1080p', '1080i', '720p', '576p', '480p', '4k', 'uhd'),
    'codec': ('x264', 'x265', 'h264', 'h265', 'hevc', 'avc', 'xvid', 'divx', 'av1'),
    'hdr':   ('10bit', 'hdr', 'hdr10', 'dv', 'dovi', 'sdr'),
}


def quality_matches(a_tok, b_tok):
    """Broj kategorija kvaliteta u kojima se oba naziva slažu bar u jednom tokenu."""
    return sum(1 for toks in QUALITY_TAGS.values()
               if any(t in a_tok and t in b_tok for t in toks))

# Nivo procene (SYNC_TIER_TAGS) bez prepoznate porodice izvora: najmanji broj kategorija kvaliteta u kojima se nazivi slažu
SYNC_TAG_THRESHOLD = 2


def release_words(text):
    """
    Tokeni naziva izdanja, redom; oznake kodeka i zvuka se spajaju u jedan
    token.
    """
    low = str(text or '').lower()
    low = re.sub(r'\bh\.26([45])\b', r'h26\1', low)              # h.264 -> h264
    low = re.sub(r'\b(ddp?|dd|aac|eac3|ac3|dts|truehd)?([2578])\.([01])\b',
                 r'\1\2\3', low)                                  # ddp5.1 -> ddp51, 7.1 -> 71
    low = re.sub(r'\bdts[\s._-]?hd[\s._-]?ma\b', 'dtshdma', low)   # MA ovde nije provajder
    low = low.replace('web-dl', 'webdl').replace('web-rip', 'webrip')
    low = low.replace('blu-ray', 'bluray').replace('hdr10+', 'hdr10')
    return [t for t in re.split(r'[^a-z0-9]+', low) if t]


@functools.lru_cache(maxsize=4096)
def release_tokens(text):
    """Skup tokena naziva izdanja (release_words)."""
    return frozenset(release_words(text))


# ============================================================
#  TIMEOUTS  (seconds)
# ============================================================

TIMEOUT_STREMIO   = 7
TIMEOUT_TMDB      = 5
TIMEOUT_CINEMETA  = 4
TIMEOUT_HASH      = 4      # po Range zahtevu ka streamu
TIMEOUT_HASH_LIST = 3      # hash upit (lokalni fajl i stream), kada se prikazuje samo lista
TIMEOUT_REST      = 5
TIMEOUT_XMLRPC    = 10
TIMEOUT_DOWNLOAD  = 15


# ============================================================
#  RETRY CONFIGURATION
# ============================================================

# Stremio ima XML-RPC kao rezervu: jedan ponovni pokušaj, samo posle greške
# servera (5xx)
RETRY_COUNT = 1      # broj ponovnih pokušaja za Stremio
RETRY_DELAY = 1.5    # sekundi između pokušaja

# REST daje samo nazive i oznake, pa je pauza pre ponovnog pokušaja kratka
REST_RETRY_COUNT = 1     # jedan ponovni pokušaj
REST_RETRY_DELAY = 1.0   # sekundi pre ponovnog pokušaja


# Dozvoljeno odstupanje godine pri razrešavanju naslova - izvori ponekad
# prijave godinu sezone umesto godine izdanja.
YEAR_TOLERANCE = 2


# ============================================================
#  SEARCH DEADLINE
# ============================================================

# Ukupan rok za pretragu, u sekundama (0 ili None = bez ograničenja).
# Kada istekne, preostali koraci se preskaču i prikazuje se ono što je nađeno.
SEARCH_DEADLINE = 30

# Trenutak isteka roka, postavlja se na početku pretrage
_deadline_at = None


def remaining_time(default_timeout):
    """
    Najduži timeout sledećeg mrežnog poziva: najviše default_timeout, a ne
    duže od preostalog roka. 0 znači da je rok istekao.
    """
    if not SEARCH_DEADLINE or _deadline_at is None:
        return default_timeout
    left = _deadline_at - time.time()
    if left <= 0:
        return 0
    return min(default_timeout, left)


# TMDB koji ne odgovara (timeout, greška veze) preskače se do kraja pretrage,
# da prepoznavanje naslova ne potroši rok; postavlja se na početku pretrage
_tmdb_down = False


def tmdb_unavailable():
    """Da li se TMDB upit preskače: rok je istekao ili TMDB ne odgovara."""
    return _tmdb_down or remaining_time(TIMEOUT_TMDB) <= 0


def tmdb_failed(e):
    """Timeout ili greška veze isključuju TMDB do kraja pretrage."""
    global _tmdb_down
    if (isinstance(e, (requests.exceptions.Timeout, requests.exceptions.ConnectionError))
            and not _tmdb_down):
        _tmdb_down = True
        log("TMDB: not responding, skipped for the rest of this search")


# ============================================================
#  LOGGING
# ============================================================

# True = pun ispis rada u Kodi log; False = tišina, upisuju se samo
# fatalne greške (log_fatal)
DEBUG = False

def log(msg, level=xbmc.LOGINFO):
    if DEBUG:
        xbmc.log(f"### [{ADDON_ID}] {msg}", level)

def log_error(msg):
    """Greška u radu koja ne prekida pretragu - dijagnostika, uz DEBUG."""
    if DEBUG:
        xbmc.log(f"### [{ADDON_ID}] ERROR: {msg}", xbmc.LOGERROR)

def log_fatal(msg):
    """Prekid rada ili trajna posledica po korisnika - upisuje se uvek."""
    xbmc.log(f"### [{ADDON_ID}] ERROR: {msg}", xbmc.LOGERROR)


# ============================================================
#  HELPER - MALFORMED RESPONSE GUARDS
#  Bezbedne vrednosti za JSON neočekivanog oblika
# ============================================================

def _dict(x):
    return x if isinstance(x, dict) else {}


def _dicts(x):
    return [i for i in x if isinstance(i, dict)] if isinstance(x, list) else []


def _int(x, default=0):
    try:
        return int(x)
    except (TypeError, ValueError):
        return default


# ============================================================
#  TITLE CLEANUP
# ============================================================

def parse_season_episode(text):
    """
    Sezona i epizoda iz teksta (S01E02, S01 E02, 1x02, Season 1 Episode 2).
    Vraća (sezona, epizoda, tekst pre oznake).
    """
    if not text:
        return None, None, ''

    q = str(text).strip()

    # (obrazac, izričita oznaka): sezona 0 (specijali) važi samo uz izričitu
    # oznaku (S00E05); oblik 1x02 traži naslov ispred, da naslov "4x4" ne
    # bude epizoda
    patterns = [
        (r'[Ss](\d{1,2})[\s._-]*[Ee](\d{1,3})', True),
        (r'(?<!\d)(\d{1,2})[xX](\d{1,3})(?!\d)', False),
        (r'season\s*(\d{1,2}).*?episode\s*(\d{1,3})', True),
    ]
    for pattern, explicit in patterns:
        m = re.search(pattern, q, flags=re.IGNORECASE)
        if m:
            try:
                season_num  = int(m.group(1))
                episode_num = int(m.group(2))
            except (TypeError, ValueError):
                continue
            prefix = q[:m.start()].strip(' .-_([')
            if not explicit and (season_num == 0 or not prefix):
                continue
            if season_num >= 0 and episode_num >= 0:
                return season_num, episode_num, prefix

    return None, None, q


def parse_se_from_filename(text):
    """
    Sezona i epizode iz naziva fajla titla, uključujući sezonu 0 i dvostruke
    epizode (S01E02-E03, S01E02E03, S01E02-03, 1x02-03).
    Vraća (sezona, prva epizoda, poslednja epizoda) ili (None, None, None).
    """
    if not text:
        return None, None, None

    q = str(text)
    patterns = [
        r'[Ss](\d{1,2})[\s._-]*[Ee](\d{1,3})(?:-?[Ee](\d{1,3})|-(\d{1,3})(?![a-z0-9]))?(?!\d)',
        r'(?<!\d)(\d{1,2})[xX](\d{1,3})(?:-(\d{1,3})(?![a-z0-9]))?(?!\d)',
        r'season[\s._-]*(\d{1,2}).*?episode[\s._-]*(\d{1,3})',
    ]
    for pattern in patterns:
        m = re.search(pattern, q, flags=re.IGNORECASE)
        if m:
            try:
                s, e = int(m.group(1)), int(m.group(2))
                last = next((int(g) for g in m.groups()[2:] if g), e)
                return s, e, max(e, last)
            except (TypeError, ValueError):
                continue
    return None, None, None


def xmlrpc_episode_matches(sub, season, episode):
    """
    Da li XML-RPC titl pripada traženoj epizodi. Presuđuju polja
    SeriesSeason i SeriesEpisode, a bez njih naziv fajla.
    """
    try:
        s = int(sub.get('SeriesSeason') or 0)
        e = int(sub.get('SeriesEpisode') or 0)
    except (TypeError, ValueError):
        s = e = 0
    if s > 0 and e > 0:
        try:
            if episode is None:
                return s == int(season)
            if s == int(season) and e == int(episode):
                return True
        except (TypeError, ValueError):
            return True
        # Polja nose prvu epizodu dvostruke; naziv fajla može navesti obe
        _, fe, fl = parse_se_from_filename(sub.get('SubFileName', ''))
        return fl is not None and fl != fe and episode_matches(
            sub.get('SubFileName', ''), season, episode)
    return episode_matches(sub.get('SubFileName', ''), season, episode)


def episode_matches(filename, season, episode):
    """False samo kada naziv titla nosi oznaku druge epizode."""
    s, e, last = parse_se_from_filename(filename)
    if s is None:
        return True

    try:
        # Bez epizode (cela sezona) dovoljno je poklapanje sezone
        if episode is None:
            return s == int(season)
        return s == int(season) and e <= int(episode) <= last
    except (TypeError, ValueError):
        return True


def imdb_from_text(text):
    """IMDB ID iz putanje ili URL-a stavke."""
    if not text:
        return None
    try:
        t = unquote(str(text))
    except Exception:
        t = str(text)

    m = re.search(r'(?:media_id|imdb|imdb_id|imdbnumber)=(tt\d{6,})', t, re.IGNORECASE)
    if not m:
        m = re.search(r'[/=&?](tt\d{6,})(?:[/&?]|$)', t)
    return m.group(1) if m else None


def title_matches_os(query, candidate, is_series=False):
    """
    Poređenje traženog naslova sa MovieName poljem OpenSubtitles odgovora.
    Kod epizoda se poredi naziv serije pod navodnicima. Za serije se
    prihvata i naziv jednak delu upita pre dvotačke (antologije).
    """
    if not query or not candidate:
        return False

    m = re.match(r'\s*"([^"]+)"', str(candidate))
    if m:
        candidate = m.group(1)

    if title_matches(query, candidate):
        return True

    if is_series and ':' in query:
        base = _title_words(query.split(':', 1)[0])
        return bool(base) and _title_words(candidate) == base
    return False


# Transliteracija srpske i makedonske ćirilice u latinicu bez dijakritika
_TITLE_TRANSLIT = str.maketrans({
    'а': 'a', 'б': 'b', 'в': 'v', 'г': 'g', 'д': 'd', 'ђ': 'dj', 'е': 'e',
    'ж': 'z', 'з': 'z', 'и': 'i', 'ј': 'j', 'к': 'k', 'л': 'l', 'љ': 'lj',
    'м': 'm', 'н': 'n', 'њ': 'nj', 'о': 'o', 'п': 'p', 'р': 'r', 'с': 's',
    'т': 't', 'ћ': 'c', 'у': 'u', 'ф': 'f', 'х': 'h', 'ц': 'c', 'ч': 'c',
    'џ': 'dz', 'ш': 's', 'ѕ': 'dz', 'đ': 'dj', 'ß': 'ss',
    'æ': 'ae', 'œ': 'oe', 'ø': 'o', 'ł': 'l', 'þ': 'th',
})


def _title_words(t):
    """
    Skup značajnih reči naslova, nezavisno od pisma, dijakritika i
    interpunkcije. Rimski brojevi se svode na cifre, a kratke pomoćne reči
    (članovi, predlozi, veznici) se izostavljaju.
    """
    t = re.sub("['\u2019\u02bb\u02bc]", '', str(t).lower())
    t = ''.join(ch for ch in unicodedata.normalize('NFKD', t)
                if not unicodedata.combining(ch))
    t = t.translate(_TITLE_TRANSLIT)
    # Slova svih pisama i cifre; ostalo razdvaja reči
    t = re.sub(r'[^\w ]+|_', ' ', t)
    stop_words = {'the', 'a', 'an', 'of', 'and', 'or', 'le', 'la', 'les',
                  'el', 'il', 'der', 'die', 'das', 'i', 'u', 'na', 'za'}
    # Oznake zemlje uz naslov serije ("The Office (US)")
    country = {'us', 'uk', 'usa', 'au', 'nz'}
    roman = {'ii': '2', 'iii': '3', 'iv': '4', 'v': '5', 'vi': '6',
             'vii': '7', 'viii': '8', 'ix': '9', 'x': '10'}
    out = set()
    for w in t.split():
        w = roman.get(w, w)
        # Jednocifreni brojevi se zadržavaju, da se nastavci razlikuju
        if w.isdigit() or (len(w) > 1 and w not in stop_words):
            out.add(w)
    # Naslov od samo kratkih ili pomoćnih reči ("家", "It") poredi se ceo
    if not out:
        out = set(t.split())
    # Oznake zemlje i formata (3D) se zanemaruju, osim kada su ceo naslov ("Us")
    return out - country - {'3d'} or out


def title_matches(query, candidate):
    """Da li se značajne reči dva naslova dovoljno poklapaju."""
    if not query or not candidate:
        return False

    q, c = _title_words(query), _title_words(candidate)
    if not q or not c:
        return False

    # Različiti brojevi u oba naslova znače različite nastavke ("Iron Man 2"
    # i "Iron Man 3"); broj samo na jednoj strani se ne računa ("Episode VII")
    qn, cn = {w for w in q if w.isdigit()}, {w for w in c if w.isdigit()}
    if qn and cn and qn != cn:
        return False

    # Kratki naslovi moraju da se poklope u potpunosti
    if min(len(q), len(c)) <= 2:
        return q == c

    # Kod dužih naslova dovoljna je većina reči kraćeg naslova (3 od 4)
    common = q & c
    return len(common) >= max(2, math.ceil(min(len(q), len(c)) * 0.7))


# Delovi naziva koji nisu naslov, za proveru Kodijevog reza: oznake izdanja
# i verzije (i Kodijeve, iz cleanstrings), godina, uglaste zagrade. Rez se
# prihvata samo kada je odsečeno sve takvo i bar jedna jaka oznaka - "The
# Proper Way" i "A German Life 1080p" zadržavaju reči naslova. Oznaku 3D
# poređenje naslova zanemaruje ("Piranha" = "Piranha 3D").
_RELEASE_STRONG = {
    'bluray', 'bdrip', 'brrip', 'dvdrip', 'dvdscr', 'hdtv', 'hdrip', 'webrip',
    'webdl', 'x264', 'x265', 'h264', 'h265', 'hevc', 'xvid', 'divx', '4k', 'uhd',
    'extended', 'unrated', 'remastered', '3d'}
_RELEASE_JUNK = _RELEASE_STRONG | {
    'ac3', 'dts', 'custom', 'dc', 'divx5', 'dsr', 'dsrip', 'dutch', 'dvd', 'dvd5',
    'dvd9', 'dvdscreener', 'screener', 'dvdivx', 'cam', 'fragment', 'fs',
    'hdtvrip', 'internal', 'limited', 'multisubs', 'ntsc', 'ogg', 'ogm', 'pal',
    'pdtv', 'proper', 'repack', 'rerip', 'retail', 'r3', 'r5', 'bd5', 'se', 'svcd',
    'swedish', 'german', 'ws', 'telesync', 'ts', 'telecine', 'tc', '3d', 'hrhd',
    'hrhdtv', 'hddvd', 'xvidvd', 'blu', 'ray', 'web', 'dl', 'rip', 'avc', 'hdr',
    'hdr10', 'dv', 'imax', 'aac', 'ddp', 'dd', 'eac3', 'truehd', 'atmos', 'flac',
    '10bit', '8bit', 'edition', 'cut', 'version', 'director', 'directors',
    'collector', 'collectors', 'special', 'ultimate', 'theatrical', 'final', 's',
    'multi', 'dual', 'nf', 'amzn', 'dsnp', 'hmax', 'atvp', 'hulu'}
_RELEASE_JUNK_RE = re.compile(
    r'\d{3,4}[pi]|cd\d|(?:dd|ddp|aac|ac3|eac3|dts)?\d\.\d|(?:dd|ddp|aac|ac3|eac3|dts)\d')


def _release_tail(text):
    """
    Da li je tekst samo "rep" izdanja (oznake, godina, uglaste i vitičaste
    zagrade, release grupa na kraju) sa bar jednom jakom oznakom, godinom
    ili zagradom - deo koji se sme odseći od naslova.
    """
    low = re.sub(r'h\.(26[45])', r'h\1', str(text).lower())
    low = low.replace('web-dl', 'webdl').replace('blu-ray', 'bluray')
    # Release grupa iza oznaka ("...[x264]-GRUPA") je deo repa
    low = re.sub(r'(?<=[\]\)a-z0-9])-[a-z0-9]{2,}\s*$', ' ', low)
    no_brackets = re.sub(r'\[[^\]]*\]|\{[^}]*\}', ' ', low)
    bracketed = no_brackets != low
    toks = re.findall(r'[a-z0-9]+(?:\.\d+)?', no_brackets)
    latest = int(time.strftime('%Y')) + 2
    strong = bracketed
    for t in toks:
        is_year = re.fullmatch(r'(?:19|20)\d{2}', t) is not None and int(t) <= latest
        if is_year or t in _RELEASE_STRONG or re.fullmatch(r'\d{3,4}[pi]', t):
            strong = True
        elif t not in _RELEASE_JUNK and not _RELEASE_JUNK_RE.fullmatch(t):
            return False
    return strong


def _strip_label_tags(title):
    """Naziv bez Kodi oznaka formatiranja ([COLOR], [B]...) i HTML tagova."""
    title = re.sub(r'\[COLOR[^\]]*\]|\[/COLOR\]', '', title, flags=re.IGNORECASE)
    title = re.sub(r'\[/?(B|I|LIGHT|UPPERCASE|LOWERCASE|CAPITALIZE)\]', '', title, flags=re.IGNORECASE)
    return re.sub(r'<[^>]+>', '', title)


def trailing_number(title):
    """Broj oblika godine na kraju naziva, bez zagrada ("Dune 2021"), ili None."""
    if not title or not isinstance(title, str):
        return None
    m = re.search(r'[\s._-]((?:19|20)\d{2})\s*$', _strip_label_tags(title))
    return int(m.group(1)) if m else None


def number_in_title(number, known_year=None, is_series=False):
    """
    Da li je broj sa kraja naziva deo naslova ("Wonder Woman 1984"), a ne
    godina: kada je dalje od dve godine u budućnosti, ili se ne slaže sa
    poznatom godinom - za film je izvan tolerancije, za seriju je više od
    YEAR_TOLERANCE godina posle godine epizode (serija počinje pre epizode). Bez poznate godine broj
    je godina.
    """
    if number > int(time.strftime('%Y')) + 2:
        return True
    try:
        known = int(known_year)
    except (TypeError, ValueError):
        return False
    if is_series:
        return number > known + YEAR_TOLERANCE
    return abs(number - known) > YEAR_TOLERANCE


def clean_title_for_search(title, known_year=None, is_series=False, keep_number=None):
    """
    Naziv za pretragu i godina iz njega. O broju sa kraja naziva bez
    zagrada odlučuje number_in_title; keep_number=True ga zadržava u
    naslovu, a False uzima kao godinu.
    """
    if not title or not isinstance(title, str):
        return "", None

    title = _strip_label_tags(title)

    number = trailing_number(title)
    if number is None:
        keep = False
    elif keep_number is None:
        keep = number_in_title(number, known_year, is_series)
    else:
        keep = bool(keep_number)

    year = None

    # Kodijev čistač radi sa nazivom fajla: uzima deo iza poslednje "/" i
    # seče na oznakama izdanja (3D, SE, CAM...). Naziv fajla ("Naslov.2019.
    # 1080p.WEB-DL") se čisti ceo; kod pravog naslova rez važi samo kada je
    # odsečen samo rep izdanja (_release_tail).
    filename_like = not re.search(r'\s', title) and bool(re.search(r'[._]', title))
    source = title
    if not filename_like:
        source = re.sub(r'[/\\]', ' ', title).strip()
        source = re.sub(r'\.(mkv|mp4|avi|m4v|mov|m2ts|webm|wmv|ts)$', '', source,
                        flags=re.IGNORECASE)
    try:
        clean, year_str = xbmc.getCleanMovieTitle(source)
        clean = (clean or '').strip()
        if year_str and year_str.isdigit() and 1900 <= int(year_str) <= 2100:
            year = int(year_str)
        rest = source[len(clean):] if clean and source.startswith(clean) else ''
        if filename_like:
            title = clean or title
        elif rest and _release_tail(rest):
            title = clean.rstrip(' ._-([')
        else:
            # Kodi je odsekao i reč iz naslova - seče se na prvoj jakoj
            # oznaci iza koje je samo rep izdanja, a godinu traže pravila ispod
            title, year = source, None
            for m in re.finditer(r'[A-Za-z0-9]+', source):
                tok = m.group().lower()
                if (m.start() and (tok in _RELEASE_STRONG or re.fullmatch(r'\d{3,4}[pi]', tok))
                        and source[:m.start()].strip(' ._-([')
                        and _release_tail(source[m.start():])):
                    title = source[:m.start()].rstrip(' ._-([')
                    break
    except Exception:
        title = title.strip()

    # Broj koji pripada naslovu Kodi bi uzeo kao godinu - vraća se u naslov
    if keep and year == number:
        title = f"{title} {number}"
        year = None

    # Oznaka epizode i sve iza nje; dozvoljen je razmak između sezone i
    # epizode. Oblik 1x02 bez naslova ispred ("4x4") je sam naslov.
    title = re.sub(r'\s*S\d{1,2}[\s._-]*E\d{1,3}.*', '', title, flags=re.IGNORECASE)
    cut = re.sub(r'\s*(?<!\d)\d{1,2}x\d{1,3}(?!\d).*', '', title, flags=re.IGNORECASE)
    if cut.strip(' .-_(['):
        title = cut
    title = re.sub(r'\s*Season\s*\d+.*', '', title, flags=re.IGNORECASE)
    title = re.sub(r'\s*Episode\s*\d+.*', '', title, flags=re.IGNORECASE)

    if not year:
        m = re.search(r'[\(\[]((?:19|20)\d{2})[\)\]]', title)
        if m:
            year = int(m.group(1))

    # Godina bez zagrada na kraju naziva, osim broja koji pripada naslovu
    if not year and not keep:
        m = re.search(r'[\s._-]((?:19|20)\d{2})\s*$', title)
        if m and not number_in_title(int(m.group(1))):
            year = int(m.group(1))
            title = title[:m.start()]

    # Godine u zagradama, uključujući odsečene zagrade
    title = re.sub(r'\s*[\(\[]\s*(?:19|20)\d{2}\s*[\)\]]?', '', title)
    title = re.sub(r'\s*[\(\[]\s*$', '', title)
    title = re.sub(r'[\._]', ' ', title)
    title = re.sub(r'\s+', ' ', title).strip()

    log(f"clean_title_for_search: '{title}' year={year}")
    return title, year


# ============================================================
#  TMDB - TV SHOW
# ============================================================

def _tmdb_search(path, clean_name, year=None, year_param=None):
    """
    Jedan TMDB upit; poznata godina se šalje kao parametar, da server suzi
    rezultate. Vraća listu rezultata.
    """
    params = {"api_key": TMDB_API_KEY, "query": clean_name}
    if year and year_param:
        params[year_param] = str(year)

    if tmdb_unavailable():
        log("TMDB: skipped (deadline or not responding)")
        return []
    try:
        r = _dict(requests.get(f"{TMDB_BASE_URL}/{path}", params=params,
                               timeout=remaining_time(TIMEOUT_TMDB)).json())
        return _dicts(r.get('results'))
    except Exception as e:
        tmdb_failed(e)
        log_error(f"_tmdb_search {path}: {e}")
        return []


def get_series_imdb_id(query, year=None, keep_number=None):
    try:
        clean_name, extracted_year = clean_title_for_search(
            query, year, is_series=True, keep_number=keep_number)

        if not clean_name:
            log_error("get_series_imdb_id: empty title after cleanup")
            return None

        # Godina u nazivu serije ("Doctor Who (2005)") je godina početka i
        # ima prednost nad godinom epizode
        search_year = extracted_year or year

        log(f"TMDB TV search: '{clean_name}'" + (f" year={search_year}" if search_year else ""))

        # Prvo sa godinom, a bez rezultata ponovo bez nje
        results = []
        with_year = False
        if search_year:
            results = _tmdb_search("search/tv", clean_name,
                                   search_year, "first_air_date_year")
            with_year = bool(results)
            if results:
                log(f"TMDB TV: {len(results)} results with year={search_year}")
            else:
                log(f"TMDB TV: no results with year={search_year}, retrying without")

        if not results:
            results = _tmdb_search("search/tv", clean_name)

        if not results:
            log(f"TMDB TV: no results for '{clean_name}'")
            return None

        # Zadržavaju se samo rezultati čiji se naslov poklapa sa traženim
        def matching(found):
            hits = [r for r in found if title_matches(clean_name, r.get('name', ''))]
            return hits or [r for r in found
                            if title_matches(clean_name, r.get('original_name', ''))]

        plausible = matching(results)
        # Rezultati sa godinom mogu biti samo drugi naslovi - ponovo bez nje
        if not plausible and with_year:
            log(f"TMDB TV: no title match with year={search_year}, retrying without")
            plausible = matching(_tmdb_search("search/tv", clean_name))
        if not plausible:
            # Bez poklapanja naslova rezultat se ne pogađa - sledi pretraga po nazivu
            log(f"TMDB TV: no title match for '{clean_name}', giving up")
            return None
        results = plausible

        best = results[0]

        # Godina iz naziva serije je godina početka: bira se serija sa
        # najbližom godinom premijere u toleranciji (ranija pri izjednačenju).
        # Inače se serija započeta posle godine epizode odbacuje, a od
        # ostalih se bira najkasnije započeta.
        if search_year and len(results) > 1:
            years = []
            for result in results:
                yr = (result.get('first_air_date', '') or '')[:4]
                if yr.isdigit():
                    years.append((int(yr), result))
            wanted = int(search_year)
            near = [(y, r) for y, r in years if abs(y - wanted) <= YEAR_TOLERANCE]
            started_before = [(y, r) for y, r in years if y <= wanted]
            if extracted_year and near:
                near.sort(key=lambda x: (abs(x[0] - wanted), x[0] > wanted))
                best = near[0][1]
                log(f"TMDB TV: title year picked '{best.get('name', '')}' "
                    f"(started {near[0][0]}, title year {search_year})")
            elif started_before:
                started_before.sort(key=lambda x: x[0], reverse=True)
                best = started_before[0][1]
                log(f"TMDB TV: year filter picked '{best.get('name', '')}' "
                    f"(started {started_before[0][0]}, episode year {search_year})")

        tmdb_id = best['id']
        log(f"TMDB TV: selected tmdb_id={tmdb_id} '{best.get('name', '')}'")

        if tmdb_unavailable():
            log("TMDB TV: external_ids skipped (deadline or not responding)")
            return None
        ext_r = requests.get(
            f"{TMDB_BASE_URL}/tv/{tmdb_id}/external_ids",
            params={"api_key": TMDB_API_KEY},
            timeout=remaining_time(TIMEOUT_TMDB)
        ).json()

        imdb = str(_dict(ext_r).get('imdb_id') or '')
        if not imdb.startswith('tt'):
            log(f"TMDB TV: no valid IMDB ID for tmdb_id={tmdb_id}")
            return None

        log(f"TMDB TV: resolved IMDB ID={imdb}")
        return imdb

    except Exception as e:
        tmdb_failed(e)
        log_error(f"get_series_imdb_id: {str(e)}")
        return None


# ============================================================
#  TMDB - MOVIE
# ============================================================

def get_movie_imdb_id(query, year=None, keep_number=None):
    try:
        clean_name, extracted_year = clean_title_for_search(
            query, year, keep_number=keep_number)

        if not clean_name:
            log_error("get_movie_imdb_id: empty title after cleanup")
            return None

        search_year = year or extracted_year

        log(f"TMDB Movie search: '{clean_name}'" + (f" year={search_year}" if search_year else ""))

        # Prvo sa godinom, a bez rezultata ponovo bez nje
        results = []
        with_year = False
        if search_year:
            results = _tmdb_search("search/movie", clean_name,
                                   search_year, "primary_release_year")
            with_year = bool(results)
            if results:
                log(f"TMDB Movie: {len(results)} results with year={search_year}")
            else:
                log(f"TMDB Movie: no results with year={search_year}, retrying without")

        if not results:
            results = _tmdb_search("search/movie", clean_name)

        if not results:
            log(f"TMDB Movie: no results for '{clean_name}'")
            return None

        # Zadržavaju se samo rezultati čiji se naslov poklapa sa traženim
        def matching(found):
            hits = [r for r in found if title_matches(clean_name, r.get('title', ''))]
            return hits or [r for r in found
                            if title_matches(clean_name, r.get('original_title', ''))]

        plausible = matching(results)
        # Rezultati sa godinom mogu biti samo drugi naslovi - ponovo bez nje
        if not plausible and with_year:
            log(f"TMDB Movie: no title match with year={search_year}, retrying without")
            plausible = matching(_tmdb_search("search/movie", clean_name))
        # Oznaka 3D iz naziva bira 3D film među istoimenim ("Piranha 3D")
        if len(plausible) > 1 and re.search(r'(?<![a-z0-9])3d(?![a-z0-9])', str(query).lower()):
            with_3d = [r for r in plausible
                       if re.search(r'(?<![a-z0-9])3d(?![a-z0-9])',
                                    str(r.get('title') or '').lower())]
            plausible = with_3d or plausible
        if not plausible:
            # Bez poklapanja naslova rezultat se ne pogađa - sledi pretraga po nazivu
            log(f"TMDB Movie: no title match for '{clean_name}', giving up")
            return None
        results = plausible

        # Odbacuju se kandidati izvan tolerancije godine
        if search_year:
            near = []
            for result in results:
                yr = (result.get('release_date', '') or '')[:4]
                if yr.isdigit() and abs(int(yr) - int(search_year)) <= YEAR_TOLERANCE:
                    near.append(result)
            if near:
                results = near
            else:
                log(f"TMDB Movie: no result within {YEAR_TOLERANCE}y of "
                    f"{search_year}, giving up")
                return None

        best = results[0]
        if search_year and len(results) > 1:
            for result in results:
                release_date = result.get('release_date', '')
                if release_date and str(search_year) in release_date:
                    best = result
                    log(f"TMDB Movie: year match on '{result.get('title', '')}' ({release_date})")
                    break

        tmdb_id = best['id']
        log(f"TMDB Movie: selected tmdb_id={tmdb_id} '{best.get('title', '')}'")

        if tmdb_unavailable():
            log("TMDB Movie: external_ids skipped (deadline or not responding)")
            return None
        ext_r = requests.get(
            f"{TMDB_BASE_URL}/movie/{tmdb_id}/external_ids",
            params={"api_key": TMDB_API_KEY},
            timeout=remaining_time(TIMEOUT_TMDB)
        ).json()

        imdb = str(_dict(ext_r).get('imdb_id') or '')
        if not imdb.startswith('tt'):
            log(f"TMDB Movie: no valid IMDB ID for tmdb_id={tmdb_id}")
            return None

        log(f"TMDB Movie: resolved IMDB ID={imdb}")
        return imdb

    except Exception as e:
        tmdb_failed(e)
        log_error(f"get_movie_imdb_id: {str(e)}")
        return None


# ============================================================
#  OS REST API - FILENAMES AND RATING
# ============================================================

STREMIO_DOWNLOAD_BASE = ("https://subs5.strem.io/en/download/"
                         "subencoding-stremio-utf8/src-api/file/")


def stremio_download_url(sub):
    """Stremio link za preuzimanje XML-RPC rezultata, po IDSubtitleFile."""
    fid = str(sub.get('IDSubtitleFile') or '').strip()
    if not fid.isdigit():
        return ''
    url = STREMIO_DOWNLOAD_BASE + fid
    enc = str(sub.get('SubEncoding') or '').strip().lower()
    if enc and enc not in ('utf-8', 'utf8'):
        url += f"?senc={urllib.parse.quote(enc)}"
    return url


def stremio_sub_info(sub):
    """
    Podaci o titlu iz Stremio odgovora, u obliku REST podataka - rezerva
    kada REST ne odgovori. Oznake kvaliteta postoje samo u REST-u.
    """
    name = str(sub.get('subtitleFileName') or '')
    if not name:
        return {}
    base, _ = os.path.splitext(name)
    fps = ''
    try:
        if sub.get('fpsMilli'):
            fps = f"{int(sub['fpsMilli']) / 1000:.3f}"
    except (TypeError, ValueError):
        fps = ''
    return {
        'filename':    base,
        'release':     str(sub.get('movieReleaseName') or ''),
        'fps':         fps,
        'hearing_imp': bool(SDH_PATTERN.search(name.lower())),
        'rating':      '0',
        'comment':     '',
    }


def lang_summary(codes):
    """Broj titlova po jeziku, za log."""
    counts = {}
    for c in codes:
        counts[c] = counts.get(c, 0) + 1
    return ', '.join(f"{k} {v}" for k, v in
                     sorted(counts.items(), key=lambda x: (-x[1], x[0]))) or '-'


# REST odgovori se čuvaju u memoriji (svojstvo Home prozora), ne na disku:
# {ključ: {'ts': vreme, 'data': {IDSubtitle: {...}}}}. Jedan unos je ceo
# odgovor jednog upita (naslov + epizoda + jezik, do 100 titlova), pa 20
# unosa pokriva nekoliko poslednjih naslova sa svim ex-yu jezicima.
REST_CACHE_PROP        = 'exyusubs.rest_cache'
REST_CACHE_MAX_ENTRIES = 20

# Upis je čitanje-izmena-upis; REST niti za više jezika pišu paralelno
_rest_lock = threading.Lock()


def _rest_cache_all():
    try:
        raw = xbmcgui.Window(10000).getProperty(REST_CACHE_PROP)
        data = json.loads(raw) if raw else {}
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _rest_cache_fresh(entry, now):
    try:
        return isinstance(entry, dict) and now - float(entry.get('ts', 0)) <= REST_CACHE_MAX_AGE
    except (TypeError, ValueError):
        return False


def _rest_cache_load(key):
    """Sačuvan REST odgovor mlađi od REST_CACHE_MAX_AGE, ili None."""
    entry = _rest_cache_all().get(key)
    if not _rest_cache_fresh(entry, time.time()) or not isinstance(entry.get('data'), dict):
        return None
    return {str(k): v for k, v in entry['data'].items() if isinstance(v, dict)} or None


def _rest_cache_save(key, mapping):
    """Čuva REST odgovor; zastareli unosi se brišu, a čuva se najviše
    REST_CACHE_MAX_ENTRIES najnovijih."""
    try:
        with _rest_lock:
            now = time.time()
            data = {k: v for k, v in _rest_cache_all().items() if _rest_cache_fresh(v, now)}
            data[key] = {'ts': now, 'data': mapping}
            if len(data) > REST_CACHE_MAX_ENTRIES:
                newest = sorted(data, key=lambda k: float(data[k].get('ts', 0)),
                                reverse=True)[:REST_CACHE_MAX_ENTRIES]
                data = {k: data[k] for k in newest}
            xbmcgui.Window(10000).setProperty(REST_CACHE_PROP, json.dumps(data))
    except Exception as e:
        log(f"REST API: cache save failed ({e})")


# Najveća dužina komentara uploadera koja se čuva uz titl (komentar navodi
# izdanja sa kojima je titl sinhronizovan; ostatak je slobodan tekst)
REST_COMMENT_MAX = 600


def get_detailed_subtitle_names(imdb_id, season=None, episode=None, rest_code=''):
    """
    Podaci o titlovima sa REST API-ja koje Stremio ne daje: naziv fajla,
    rejting, oznake, broj preuzimanja, izdanje, FPS i komentar uploadera.
    REST prima jedan jezik po upitu (rest_code); bez koda upit je za sve
    jezike. Vraća {IDSubtitle: {...}}; prazan dict kada REST ne odgovori.
    """
    mapping = {}
    if not imdb_id:
        return mapping

    codes = [rest_code] if re.fullmatch(r'[a-z]{3}', str(rest_code or '')) else []
    cache_key = f"{imdb_id}|{season}|{episode}|{','.join(codes)}"
    cached = _rest_cache_load(cache_key)
    if cached is not None:
        log(f"REST API: served from cache, {len(cached)} subtitles "
            f"({lang_summary(v.get('lang', '?') for v in cached.values())})")
        return cached

    try:
        numeric_id = imdb_id.replace('tt', '')

        # Parametri idu abecednim redom (episode, imdbid, season, sublanguageid); bez epizode pretražuje se cela sezona
        if season is not None and episode is not None:
            base_url = f"{OPENSUB_REST_URL}/episode-{episode}/imdbid-{numeric_id}/season-{season}"
        elif season is not None:
            base_url = f"{OPENSUB_REST_URL}/imdbid-{numeric_id}/season-{season}"
        else:
            base_url = f"{OPENSUB_REST_URL}/imdbid-{numeric_id}"
        rest_url = base_url + (f"/sublanguageid-{codes[0]}" if codes else '')

        if remaining_time(TIMEOUT_REST) <= 0:
            log("REST API: deadline reached, skipping")
            return mapping

        log(f"REST API request: {rest_url}")
        started = time.time()

        # Ponovni pokušaj samo za 5xx i timeout; 4xx se ne ponavlja
        response = None
        for attempt in range(1, REST_RETRY_COUNT + 2):
            try:
                response = requests.get(rest_url, headers=HEADERS,
                                        timeout=remaining_time(TIMEOUT_REST))
                if response.status_code < 500:
                    break
                log(f"REST API: HTTP {response.status_code}, retrying...")
            except requests.exceptions.Timeout:
                log(f"REST API: timeout on attempt {attempt}")
                response = None
            except Exception as e:
                log(f"REST API: error on attempt {attempt}: {e}")
                response = None
                break   # neočekivana greška - bez ponavljanja

            if attempt <= REST_RETRY_COUNT:
                if remaining_time(TIMEOUT_REST) <= REST_RETRY_DELAY:
                    log("REST API: deadline reached, no retry")
                    break
                time.sleep(REST_RETRY_DELAY)

        # Server koji odbije filter jezika (400) - upit bez njega, jezici se filtriraju lokalno
        if (response is not None and rest_url != base_url
                and response.status_code == 400 and remaining_time(TIMEOUT_REST) > 0):
            log(f"REST API: HTTP {response.status_code} with language filter, retrying without it")
            try:
                response = requests.get(base_url, headers=HEADERS,
                                        timeout=remaining_time(TIMEOUT_REST))
            except Exception as e:
                log(f"REST API: error without language filter: {e}")
                response = None

        if response is None:
            log(f"REST API: no response for imdbid={numeric_id} "
                f"after {time.time() - started:.1f} s")
            return mapping

        if not response.ok:
            log(f"REST API: HTTP {response.status_code} for imdbid={numeric_id}")
            return mapping

        data = response.json()
        if not isinstance(data, list):
            log("REST API: unexpected response format")
            return mapping
        data = _dicts(data)

        valid_langs = set(codes) if codes else None
        for item in data:
            lang = str(item.get('SubLanguageID') or '')
            if valid_langs is not None and lang not in valid_langs:
                continue
            sub_id    = str(item.get('IDSubtitle', ''))
            file_name = str(item.get('SubFileName') or '')
            if sub_id and file_name:
                try:
                    rating = str(int(math.floor(float(item.get('SubRating', '0') or '0') / 2 + 0.5)))
                except Exception:
                    rating = '0'
                # Naziv bez ekstenzije
                base_name, _ = os.path.splitext(file_name)
                # SDH se prepoznaje i po nazivu fajla, jer je SubHearingImpaired nepouzdan
                hi_flag = str(item.get('SubHearingImpaired', '0')) == '1'
                is_sdh  = hi_flag or bool(SDH_PATTERN.search(file_name.lower()))
                # Trusted oznaka se čuva odvojeno od ranga uploadera
                from_trusted = str(item.get('SubFromTrusted', '0')) == '1'
                user_rank    = str(item.get('UserRank', '') or '').strip()
                mapping[sub_id] = {
                    'lang':        lang,
                    'filename':    base_name,
                    'rating':      rating,
                    'ai':          str(item.get('SubAutoTranslation', '0')) == '1',
                    'forced':      str(item.get('SubForeignPartsOnly', '0')) == '1',
                    'featured':    str(item.get('SubFeatured', '0')) == '1',
                    'trusted':     from_trusted,
                    'user_rank':   user_rank,
                    'hearing_imp': is_sdh,
                    'downloads':   item.get('SubDownloadsCnt', '0'),
                    # Za sync detekciju
                    'release':     item.get('MovieReleaseName', '') or '',
                    'fps':         item.get('MovieFPS', '') or '',
                    # Komentar uploadera često navodi izdanja sa kojima je titl sinhronizovan
                    'comment':     str(item.get('SubAuthorComment') or '')[:REST_COMMENT_MAX],
                }

        log(f"REST API: mapped {len(mapping)} subtitles "
            f"({lang_summary(v['lang'] for v in mapping.values())}) "
            f"for imdbid={numeric_id} in {time.time() - started:.2f} s")
        if len(data) >= REST_RESULT_CAP:
            log(f"REST API: result limit reached ({len(data)}), "
                f"some subtitles may be missing")

        # Čuva se i odgovor koji stigne posle prikaza liste; prazan odgovor se ne čuva, jer REST može kasniti za Stremio-om
        if mapping:
            _rest_cache_save(cache_key, mapping)

    except Exception as e:
        log_error(f"get_detailed_subtitle_names: {str(e)}")

    return mapping


# ============================================================
#  IMDB ID RESOLUTION - TMDB, CINEMETA, ANTHOLOGIES
#  Izvori: TMDB broj, naslov (TMDB, pa Cinemeta) i proverena svojstva
#  Home prozora. Kada tip nije poznat, pretražuju se oba kataloga.
# ============================================================

def resolve_imdb_from_tmdb_id(tmdb_id, series_first=False, expected_title=None):
    """
    IMDB ID iz poznatog TMDB broja. Za poznatu seriju pita se samo /tv;
    kada tip nije poznat, proveravaju se oba kataloga. Uz expected_title
    naslov iz odgovora (ili neki od prevoda) mora da odgovara traženom.
    Vraća IMDB ID ili None.
    """
    if not tmdb_id or not str(tmdb_id).isdigit():
        return None

    paths = ['tv'] if series_first else ['movie', 'tv']

    for path in paths:
        if tmdb_unavailable():
            log("resolve_imdb_from_tmdb_id: skipped (deadline or TMDB not responding)")
            break
        try:
            # Jedan poziv daje naslov, prevode i external_ids
            r = _dict(requests.get(
                f"{TMDB_BASE_URL}/{path}/{tmdb_id}",
                params={"api_key": TMDB_API_KEY,
                        "append_to_response":
                            "external_ids,alternative_titles,translations"},
                timeout=remaining_time(TIMEOUT_TMDB)
            ).json())
        except Exception as e:
            tmdb_failed(e)
            log_error(f"resolve_imdb_from_tmdb_id {path}: {e}")
            continue

        names = [r.get('name'), r.get('original_name'),
                 r.get('title'), r.get('original_title')]
        # Nazivi na drugim jezicima, za lokalizovane naslove
        alt = _dict(r.get('alternative_titles'))
        for t in _dicts(alt.get('results')) + _dicts(alt.get('titles')):
            names.append(t.get('title'))
        for t in _dicts(_dict(r.get('translations')).get('translations')):
            data = _dict(t.get('data'))
            names.append(data.get('name') or data.get('title'))
        names = [str(n) for n in names if n]
        name = names[0] if names else ''
        imdb = _dict(r.get('external_ids')).get('imdb_id', '')

        if not imdb or not str(imdb).startswith('tt'):
            log(f"resolve_imdb_from_tmdb_id: {path}/{tmdb_id} has no IMDB ID")
            continue

        # Naslov iz odgovora mora da odgovara traženom
        if expected_title and not any(title_matches(expected_title, n) for n in names):
            log(f"resolve_imdb_from_tmdb_id: {path}/{tmdb_id} is '{name}', "
                f"not '{expected_title}' - rejected")
            continue

        log(f"resolve_imdb_from_tmdb_id: tmdb {path}/{tmdb_id} '{name}' -> {imdb}")
        return imdb

    log(f"resolve_imdb_from_tmdb_id: no IMDB ID for tmdb_id={tmdb_id}")
    return None


def _date10(value):
    """Datum u obliku YYYY-MM-DD, bez vremena."""
    return str(value or '')[:10]


def _same_day(a, b, tolerance=1):
    """
    Da li su dva datuma isti dan, uz toleranciju od jednog dana (lokalni datum emitovanja naspram UTC-a).
    """
    from datetime import date
    try:
        da = date.fromisoformat(_date10(a))
        db = date.fromisoformat(_date10(b))
    except (TypeError, ValueError):
        return False
    return abs((da - db).days) <= tolerance


def tmdb_tv_season_count(tmdb_id):
    """Broj regularnih sezona TMDB serije (bez specijala), ili None."""
    if tmdb_unavailable():
        return None
    try:
        r = _dict(requests.get(f"{TMDB_BASE_URL}/tv/{tmdb_id}",
                               params={"api_key": TMDB_API_KEY},
                               timeout=remaining_time(TIMEOUT_TMDB)).json())
        seasons = [x for x in _dicts(r.get('seasons'))
                   if _int(x.get('season_number')) > 0]
        count = len(seasons) if seasons else r.get('number_of_seasons')
        log(f"anthology: tv/{tmdb_id} has {count} season(s)")
        return int(count) if count else None
    except Exception as e:
        tmdb_failed(e)
        log(f"anthology: season count failed ({e})")
        return None


def map_anthology_season(title, tmdb_id, season, episode):
    """
    Matična IMDB serija za sezonu antologije koju TMDB vodi kao zaseban
    naslov (samo za naslove sa dvotačkom).

    Postupak:
      1. Sa TMDB-a se uzimaju datum emitovanja i naziv tražene epizode.
      2. Cinemeta se pretražuje po osnovnom nazivu (deo pre dvotačke).
      3. Kod kandidata se traži epizoda istog naziva, a zatim sezona sa
         istim datumom emitovanja; broj epizode tada ostaje isti.

    Vraća (imdb_id, sezona, epizoda) ili None.
    """
    if not title or ':' not in title or not tmdb_id or not season:
        return None

    base = title.split(':', 1)[0].strip()
    if len(base) < 2:
        return None

    ref_episode = episode if episode is not None else 1

    # 1. Datum i naziv tražene epizode sa TMDB-a
    if tmdb_unavailable():
        return None
    try:
        r = _dict(requests.get(
            f"{TMDB_BASE_URL}/tv/{tmdb_id}/season/{int(season)}",
            params={"api_key": TMDB_API_KEY},
            timeout=remaining_time(TIMEOUT_TMDB)
        ).json())
    except Exception as e:
        tmdb_failed(e)
        log_error(f"anthology: TMDB season fetch: {e}")
        return None

    ref = next((ep for ep in _dicts(r.get('episodes'))
                if ep.get('episode_number') == ref_episode), None)
    if not ref:
        log(f"anthology: TMDB has no S{season}E{ref_episode} for tv/{tmdb_id}")
        return None

    ref_date = _date10(ref.get('air_date'))
    ref_name = str(ref.get('name') or '').strip().lower()
    if not ref_date and not ref_name:
        return None

    log(f"anthology: '{title}' -> base '{base}', reference "
        f"S{season}E{ref_episode} '{ref_name}' aired {ref_date or '?'}")

    # 2. Kandidati za matičnu seriju
    if remaining_time(TIMEOUT_CINEMETA) <= 0:
        return None
    try:
        search_url = (f"{CINEMETA_BASE_URL}/catalog/series/top/"
                      f"search={urllib.parse.quote(base)}.json")
        metas = _dict(requests.get(search_url, headers=HEADERS,
                                   timeout=remaining_time(TIMEOUT_CINEMETA)).json())
        metas = _dicts(metas.get('metas'))
    except Exception as e:
        log_error(f"anthology: Cinemeta search: {e}")
        return None

    candidates = [m for m in metas if title_matches(base, str(m.get('name') or ''))][:3]
    if not candidates:
        log(f"anthology: no Cinemeta series named '{base}'")
        return None

    # 3. Epizoda po nazivu, a ako je nema, sezona po datumu
    for cand in candidates:
        imdb = cand.get('imdb_id') or cand.get('id') or ''
        if not str(imdb).startswith('tt'):
            continue
        if remaining_time(TIMEOUT_CINEMETA) <= 0:
            break
        try:
            meta = _dict(requests.get(f"{CINEMETA_BASE_URL}/meta/series/{imdb}.json",
                                      headers=HEADERS,
                                      timeout=remaining_time(TIMEOUT_CINEMETA)).json())
            videos = _dicts(_dict(meta.get('meta')).get('videos'))
        except Exception as e:
            log_error(f"anthology: Cinemeta meta {imdb}: {e}")
            continue

        # Specijali (sezona 0) se preskaču
        videos = [v for v in videos if _int(v.get('season')) > 0]

        named = [v for v in videos if ref_name and
                 str(v.get('name') or v.get('title') or '').strip().lower() == ref_name
                 and _int(v.get('episode')) > 0]
        # Isti naziv u više sezona ("Part 2") - presuđuje datum emitovanja,
        # a bez jednoznačnog pogotka sledi pravilo datuma
        if len(named) > 1 and ref_date:
            named = [v for v in named
                     if _same_day(v.get('released') or v.get('firstAired'), ref_date)]
        by_name = named[0] if len(named) == 1 else None
        if by_name:
            new_s, new_e = _int(by_name.get('season')), _int(by_name.get('episode'))
            log(f"anthology: matched by episode name -> {imdb} S{new_s}E{new_e}")
            return imdb, new_s, new_e

        if ref_date:
            dated = [v for v in videos
                     if _same_day(v.get('released') or v.get('firstAired'), ref_date)]
            seasons = {_int(v.get('season')) for v in dated} - {0}
            if len(seasons) == 1:
                new_s = seasons.pop()
                exists = any(_int(v.get('season')) == new_s and
                             _int(v.get('episode')) == ref_episode for v in videos)
                if exists:
                    log(f"anthology: matched by air date -> {imdb} S{new_s}E{ref_episode}")
                    return imdb, new_s, ref_episode

    log(f"anthology: no matching season found for '{title}'")
    return None


def _release_year(value):
    """Prva godina iz Cinemeta releaseInfo ("2019", "2019-", "2019-2022")."""
    m = re.match(r'\s*((?:19|20)\d{2})', str(value or ''))
    return int(m.group(1)) if m else None


def _year_fits(found_year, wanted_year, is_series):
    """
    Film: godina u toleranciji. Serija: počela najkasnije YEAR_TOLERANCE
    godina posle tražene. Nepoznata godina ne isključuje kandidata.
    """
    if not found_year or not wanted_year:
        return True
    if is_series:
        return found_year <= int(wanted_year) + YEAR_TOLERANCE
    return abs(found_year - int(wanted_year)) <= YEAR_TOLERANCE


def _cinemeta_get(path):
    """GET ka Cinemeti; svaki neuspeh vraća None."""
    if remaining_time(TIMEOUT_CINEMETA) <= 0:
        return None
    try:
        r = requests.get(f"{CINEMETA_BASE_URL}/{path}", headers=HEADERS,
                         timeout=remaining_time(TIMEOUT_CINEMETA))
        if not r.ok:
            return None
        return _dict(r.json())
    except Exception as e:
        log(f"cinemeta: {path.split('/')[0]} request failed ({e})")
        return None


def _episode_fits(videos, season, episode, wanted_year):
    """
    Da li serija ima traženu epizodu, emitovanu oko tražene godine.
    Godina epizode, a ne početna godina serije, razlikuje istoimene serije.
    """
    videos = _dicts(videos)
    in_season = [v for v in videos if _int(v.get('season')) == _int(season)]
    if not in_season:
        return False
    if episode is not None:
        in_season = [v for v in in_season if _int(v.get('episode')) == _int(episode)]
        if not in_season:
            return False
    if not wanted_year:
        return True
    years = [_release_year(v.get('released') or v.get('firstAired')) for v in in_season]
    years = [y for y in years if y]
    if not years:
        return True
    return any(abs(y - int(wanted_year)) <= YEAR_TOLERANCE for y in years)


def cinemeta_verify_imdb(imdb_id, title, year=None, is_series=False, season=None, episode=None):
    """
    Da li IMDB ID pripada traženom naslovu - za ID iz nepouzdanog izvora
    (svojstva Home prozora). Naslov se poredi strogo; kod serija sa poznatom
    sezonom proverava se i postojanje epizode i godina emitovanja.
    """
    if not imdb_id or not str(imdb_id).startswith('tt') or not title:
        return False

    types = ['series', 'movie'] if is_series else ['movie', 'series']
    for kind in types:
        data = _cinemeta_get(f"meta/{kind}/{imdb_id}.json")
        meta = _dict(_dict(data).get('meta'))
        name = str(meta.get('name') or '')
        if not name:
            continue
        found_year = _release_year(meta.get('releaseInfo') or meta.get('year'))

        ok = _title_words(title) == _title_words(name)
        reason = 'title'
        if ok and kind == 'series' and season is not None:
            ok = _episode_fits(meta.get('videos') or [], season, episode, year)
            reason = 'episode'
        elif ok:
            ok = _year_fits(found_year, year, kind == 'series')
            reason = 'year'

        log(f"cinemeta: verify {imdb_id} -> '{name}' ({found_year or '?'}) "
            f"{'accepted' if ok else 'rejected on ' + reason} for '{title}'")
        return ok

    log(f"cinemeta: {imdb_id} not found")
    return False


def title_readings(title, year=None, is_series=False):
    """
    Čitanja naziva za razrešavanje naslova, kao (keep_number, godina). Broj
    na kraju naziva može biti godina ili deo naslova: prvo se uzima izbor
    po number_in_title, pa drugo čitanje. Broj zadržan u naslovu ne važi i
    kao godina.
    """
    number = trailing_number(title)
    if number is None:
        return [(None, year)]
    keep = number_in_title(number, year, is_series)
    return [(k, None if k and str(year or '') == str(number) else year)
            for k in (keep, not keep)]


def resolve_imdb_via_cinemeta(title, year=None, series_first=False):
    """
    IMDB ID po naslovu preko Cinemete - rezerva kada TMDB ne uspe.
    Strogo poklapanje naslova i godina u toleranciji; od više pogodaka
    bira se najbliža godina, a bez godine se odustaje.
    """
    types = ['series', 'movie'] if series_first else ['movie', 'series']
    for kind in types:
        for keep_number, y in title_readings(title, year, kind == 'series'):
            clean_name, extracted_year = clean_title_for_search(
                title, y, is_series=kind == 'series', keep_number=keep_number)
            if not clean_name:
                return None
            # Kod serije godina u nazivu je godina početka (vidi
            # get_series_imdb_id)
            wanted_year = ((extracted_year or y) if kind == 'series'
                           else (y or extracted_year))

            data = _cinemeta_get(
                f"catalog/{kind}/top/search={urllib.parse.quote(clean_name)}.json")
            metas = _dicts(_dict(data).get('metas'))

            matches = []
            for m in metas:
                name = str(m.get('name') or '')
                imdb = str(m.get('imdb_id') or m.get('id') or '')
                if not str(imdb).startswith('tt') or _title_words(clean_name) != _title_words(name):
                    continue
                found_year = _release_year(m.get('releaseInfo') or m.get('year'))
                if not _year_fits(found_year, wanted_year, kind == 'series'):
                    continue
                matches.append((imdb, name, found_year))

            if not matches:
                continue

            if len(matches) > 1 and not wanted_year:
                log(f"cinemeta: {len(matches)} {kind} titles named '{clean_name}' "
                    f"and no year to tell them apart - giving up")
                return None

            # Sa godinom: najbliža godina pobeđuje
            if wanted_year:
                matches.sort(key=lambda x: abs((x[2] or 0) - int(wanted_year)))

            imdb, name, found_year = matches[0]
            log(f"cinemeta: resolved '{clean_name}' as {kind} '{name}' "
                f"({found_year or '?'}) -> {imdb}")
            return imdb

    log(f"cinemeta: no match for '{title}'")
    return None


def resolve_imdb_by_title(title, year=None, series_first=False):
    """IMDB ID po naslovu: prvo TMDB, a kada on ne uspe, Cinemeta."""
    imdb = resolve_imdb_via_tmdb(title, year, series_first=series_first)
    if imdb:
        return imdb
    log("TMDB could not resolve the title, trying Cinemeta")
    return resolve_imdb_via_cinemeta(title, year, series_first=series_first)


# Svojstva Home prozora koja mogu nositi IMDB ID - pre pretrage po naslovu, samo uz proveru preko Cinemete
WINDOW_IMDB_PROPS = ('imdb_id', 'IMDb', 'imdbnumber', 'script.trakt.imdb_id', 'show_imdb_id')


def imdb_from_window_props(title, year=None, is_series=False, season=None, episode=None):
    """
    IMDB ID iz globalnih svojstava Home prozora. Vrednost se prihvata tek
    kada naslov i godina odgovaraju trenutnoj pretrazi.
    """
    try:
        home = xbmcgui.Window(10000)
    except Exception:
        return None

    seen = set()
    for prop in WINDOW_IMDB_PROPS:
        try:
            val = str(home.getProperty(prop) or '').strip()
        except Exception:
            continue
        m = re.search(r'(tt\d{6,})', val)
        if not m or m.group(1) in seen:
            continue
        imdb = m.group(1)
        seen.add(imdb)
        log(f"Window(10000).{prop} = {imdb}, verifying")
        if cinemeta_verify_imdb(imdb, title, year, is_series, season, episode):
            return imdb
    return None


def resolve_imdb_via_tmdb(title, year=None, series_first=False):
    if not title:
        return None

    order = ([('tv', get_series_imdb_id), ('movie', get_movie_imdb_id)]
                if series_first else
                [('movie', get_movie_imdb_id), ('tv', get_series_imdb_id)])

    for kind, fn in order:
        if tmdb_unavailable():
            log("resolve_imdb_via_tmdb: skipped (deadline or TMDB not responding)")
            break
        for keep_number, y in title_readings(title, year, kind == 'tv'):
            if tmdb_unavailable():
                break
            imdb = fn(title, y, keep_number=keep_number)
            if imdb:
                log(f"resolve_imdb_via_tmdb: resolved as {kind} -> {imdb}")
                return imdb

    return None


# ============================================================
#  IMDB ID + METADATA DETECTION
#  Aktivan plejer koristi VideoPlayer.* oznake, a pretraga iz liste
#  (bez plejera) ListItem.* oznake.
# ============================================================

PROBE_LABELS = (
    'VideoPlayer.IMDBNumber', 'VideoPlayer.UniqueID(imdb)',
    'VideoPlayer.UniqueID(tmdb)', 'VideoPlayer.UniqueID(tvdb)',
    'VideoPlayer.TMDbId', 'VideoPlayer.TVShowTitle',
    'ListItem.IMDBNumber', 'ListItem.UniqueID(imdb)',
    'ListItem.UniqueID(tmdb)', 'ListItem.UniqueID(tvdb)',
    'ListItem.Property(imdb_id)', 'ListItem.Property(tmdb_id)',
    'ListItem.Property(unique_ids.imdb)', 'ListItem.Property(show_imdb_id)',
    'ListItem.Property(tvshow.imdb_id)',
)


def _probe_value(name, val):
    """
    Vrednost oznake, ili None kada je prazna, '0', 'None' ili jednaka imenu oznake.
    """
    v = str(val or '').strip()
    if not v or v.lower() in ('none', '0') or v == name:
        return None
    return v


def log_media_id_probe():
    """Ispisuje u log oznake koje mogu nositi identifikatore naslova."""
    for lbl in PROBE_LABELS:
        try:
            val = _probe_value(lbl, xbmc.getInfoLabel(lbl))
        except Exception:
            val = None
        if val:
            log(f"  probe {lbl} = {val!r}")



def _jsonrpc(method, params):
    """Jedan JSON-RPC poziv; vraća 'result' ili None."""
    try:
        req = {"jsonrpc": "2.0", "id": 1, "method": method, "params": params}
        resp = json.loads(xbmc.executeJSONRPC(json.dumps(req)))
        return resp.get('result')
    except Exception as e:
        log(f"jsonrpc {method}: {e}")
        return None


def library_episode_show(dbtype, dbid):
    """
    ID-evi serije za epizodu iz Kodi biblioteke: {'imdb', 'tmdb'}, vrednosti
    mogu biti None. Za sve što nije epizoda iz biblioteke vraća None.
    ID-evi same epizode se ne koriste, jer izvori titlova traže seriju.
    """
    try:
        if str(dbtype or '').lower() != 'episode':
            return None
        dbid = int(dbid or 0)
    except (TypeError, ValueError):
        return None
    if dbid <= 0:
        return None

    ids = {'imdb': None, 'tmdb': None}
    ep = _dict(_jsonrpc('VideoLibrary.GetEpisodeDetails',
                        {'episodeid': dbid, 'properties': ['tvshowid']}))
    try:
        tvshowid = int(_dict(ep.get('episodedetails')).get('tvshowid') or 0)
    except (TypeError, ValueError):
        tvshowid = 0
    if tvshowid <= 0:
        return ids

    show = _dict(_jsonrpc('VideoLibrary.GetTVShowDetails',
                          {'tvshowid': tvshowid,
                           'properties': ['uniqueid', 'imdbnumber']}))
    details = _dict(show.get('tvshowdetails'))
    uniq = _dict(details.get('uniqueid'))
    for val in (uniq.get('imdb'), details.get('imdbnumber')):
        val = str(val or '').strip()
        if val.startswith('tt'):
            ids['imdb'] = val
            break
    tmdb = str(uniq.get('tmdb') or '').strip()
    if tmdb.isdigit() and tmdb != '0':
        ids['tmdb'] = tmdb
    return ids


def se_label(season, episode):
    """Oznaka sezone i epizode za log: 'S4E2', 'S4' ili ''."""
    return ((f"S{season}" if season is not None else '')
            + (f"E{episode}" if episode is not None else ''))


def get_media_info():
    info = {
        'imdb_id': None,
        'tmdb_id': None,
        'title':   None,
        'season':  None,
        'episode': None,
        'year':    None,
    }

    # Tip sadržaja (movie/episode), kada ga stavka nosi
    media_type = ''

    junk_ids = {'', 'None', '0', 'VideoPlayer.IMDBNumber', 'VideoPlayer.TMDbId', 'VideoPlayer.TVShow.TMDbId', 'ListItem.IMDBNumber'}

    # Oznake koje nose TMDB broj
    tmdb_labels_playing = ('VideoPlayer.UniqueID(tmdb)',
                           'VideoPlayer.TMDbId',
                           'VideoPlayer.TVShow.TMDbId',
                           'ListItem.Property(tmdb_id)')
    tmdb_labels_list    = ('ListItem.UniqueID(tmdb)',
                           'ListItem.Property(tmdb_id)',
                           'ListItem.Property(tmdb)',
                           'ListItem.Property(themoviedb_id)')

    def read_tmdb_id(labels):
        for lbl in labels:
            try:
                val = str(xbmc.getInfoLabel(lbl) or '').strip()
            except Exception:
                continue
            if val and val.isdigit() and val != '0':
                log(f"TMDB ID from {lbl}: {val}")
                return val
        return None

    def is_valid_imdb(val):
        return val and str(val) not in junk_ids and str(val).startswith('tt')

    def clean_imdb(val, digits_ok=False):
        # IMDBNumber nosi podrazumevani ID stavke, koji može biti i TMDB ili
        # TVDB broj, pa se prihvata samo oblik tt. Goli broj se dopunjuje sa tt
        # samo iz oznaka koje su izričito IMDB.
        val = str(val).strip()
        if val in junk_ids:
            return None
        if val.startswith('tt'):
            return val
        if digits_ok and val.isdigit():
            return f"tt{val}"
        return None

    try:
        is_playing = xbmc.Player().isPlaying()
    except Exception:
        is_playing = False

    log(f"get_media_info: player active={is_playing}")

    if is_playing:
        # 1. VideoInfoTag - najpouzdaniji izvor dok se video pušta
        try:
            tag = xbmc.Player().getVideoInfoTag()
            imdb = tag.getUniqueID('imdb')
            if is_valid_imdb(imdb):
                info['imdb_id'] = imdb
                log(f"IMDB ID from VideoInfoTag: {imdb}")

            info['title'] = tag.getTVShowTitle() or tag.getTitle()
            media_type    = str(tag.getMediaType() or '').lower()
            # getSeason()/getEpisode() vraćaju -1 kada vrednosti nema
            s = tag.getSeason()
            e = tag.getEpisode()
            info['episode'] = e if isinstance(e, int) and e > 0 else None
            # Sezona 0 (specijali) važi samo za epizodu sa poznatim brojem
            # (tip epizoda, ili naslov serije kada tip nije naveden)
            special = (s == 0 and info['episode'] is not None and
                       (media_type == 'episode' or bool(tag.getTVShowTitle())))
            info['season']  = s if isinstance(s, int) and (s > 0 or special) else None
            y = tag.getYear()
            info['year']    = y if isinstance(y, int) and y > 0 else None
        except Exception as e:
            log_error(f"get_media_info VideoInfoTag: {str(e)}")

        # Epizoda iz Kodi biblioteke: koriste se ID-evi serije, a oznake
        # plejera (ID-evi epizode) se preskaču
        try:
            tag = xbmc.Player().getVideoInfoTag()
            lib_show = library_episode_show(tag.getMediaType(), tag.getDbId())
        except Exception:
            lib_show = None
        if lib_show is not None:
            log(f"library episode: TV show IDs {lib_show} "
                f"(episode ID {info['imdb_id'] or '-'} not used)")
            info['imdb_id'] = lib_show['imdb']
            info['tmdb_id'] = lib_show['tmdb']

        # 2. VideoPlayer.* oznake - rezerva za IMDB ID i naslov
        if not info['imdb_id'] and lib_show is None:
            imdb = clean_imdb(xbmc.getInfoLabel('VideoPlayer.IMDBNumber'))
            if is_valid_imdb(imdb):
                info['imdb_id'] = imdb
                log(f"IMDB ID from InfoLabel VideoPlayer.IMDBNumber: {imdb}")

        if not info['title']:
            info['title'] = (xbmc.getInfoLabel('VideoPlayer.TVShowTitle') or
                             xbmc.getInfoLabel('VideoPlayer.OriginalTitle') or
                             xbmc.getInfoLabel('VideoPlayer.Title'))

        if not info['episode']:
            e = xbmc.getInfoLabel('VideoPlayer.Episode')
            info['episode'] = int(e) if e and e.isdigit() else None

        if info['season'] is None:
            s = xbmc.getInfoLabel('VideoPlayer.Season')
            special = (s == '0' and info['episode'] is not None
                       and bool(xbmc.getInfoLabel('VideoPlayer.TVShowTitle')))
            info['season'] = int(s) if s and s.isdigit() and (s != '0' or special) else None

        if not info['year']:
            y = xbmc.getInfoLabel('VideoPlayer.Year')
            info['year'] = int(y) if y and y.isdigit() else None

        # 3. TMDB broj
        if not info['tmdb_id'] and lib_show is None:
            info['tmdb_id'] = read_tmdb_id(tmdb_labels_playing)

        # 4. IMDB ID iz putanje videa
        if not info['imdb_id'] and lib_show is None:
            try:
                found_id = imdb_from_text(xbmc.Player().getPlayingFile())
                if found_id:
                    info['imdb_id'] = found_id
                    log(f"IMDB ID from URL: {found_id}")
            except Exception as e:
                log_error(f"get_media_info URL parse: {str(e)}")

    else:
        # ----------------------------------------------------------
        # 1. ListItem.* oznake - pretraga iz liste, bez plejera.
        #    Prvo standardne Kodi oznake, zatim svojstva video addona.
        # ----------------------------------------------------------
        # Epizoda iz biblioteke - koriste se ID-evi serije
        lib_show = library_episode_show(xbmc.getInfoLabel('ListItem.DBTYPE'),
                                        xbmc.getInfoLabel('ListItem.DBID'))
        if lib_show is not None:
            log(f"library episode: TV show IDs {lib_show}")
            info['imdb_id'] = lib_show['imdb']
            info['tmdb_id'] = lib_show['tmdb']

        imdb_labels = (('ListItem.IMDBNumber', False),
                       ('ListItem.UniqueID(imdb)', True),
                       ('ListItem.Property(imdb_id)', True),
                       ('ListItem.Property(imdbnumber)', False))
        for lbl, digits_ok in (imdb_labels if lib_show is None else ()):
            imdb = clean_imdb(xbmc.getInfoLabel(lbl), digits_ok)
            if is_valid_imdb(imdb):
                info['imdb_id'] = imdb
                log(f"IMDB ID from {lbl}: {imdb}")
                break

        info['title'] = (xbmc.getInfoLabel('ListItem.TVShowTitle') or
                         xbmc.getInfoLabel('ListItem.OriginalTitle') or
                         xbmc.getInfoLabel('ListItem.Title'))

        if not info['tmdb_id'] and lib_show is None:
            info['tmdb_id'] = read_tmdb_id(tmdb_labels_list)

        # IMDB ID iz putanje stavke
        if not info['imdb_id'] and lib_show is None:
            for lbl in ('ListItem.FilenameAndPath', 'ListItem.FolderPath',
                        'ListItem.Path'):
                found_id = imdb_from_text(xbmc.getInfoLabel(lbl))
                if found_id:
                    info['imdb_id'] = found_id
                    log(f"IMDB ID from {lbl}: {found_id}")
                    break

        media_type = str(xbmc.getInfoLabel('ListItem.DBTYPE') or '').lower()

        # Kod stavke sezone ili serije ListItem.Episode je broj epizoda
        e = xbmc.getInfoLabel('ListItem.Episode')
        info['episode'] = (int(e) if e and e.isdigit()
                           and media_type not in ('season', 'tvshow') else None)

        # Sezona 0 (specijali) važi samo za epizodu sa poznatim brojem
        s = xbmc.getInfoLabel('ListItem.Season')
        special = (s == '0' and info['episode'] is not None
                   and (media_type == 'episode'
                        or bool(xbmc.getInfoLabel('ListItem.TVShowTitle'))))
        info['season'] = int(s) if s and s.isdigit() and (s != '0' or special) else None

        y = xbmc.getInfoLabel('ListItem.Year')
        info['year'] = int(y) if y and y.isdigit() else None

    # Naslov bez oznaka formatiranja ([COLOR], [B]...)
    if info['title']:
        info['title'] = _strip_label_tags(info['title']).strip() or None

    # Sezona i epizoda iz naslova, kada ih oznake nisu dale (epizoda 0 je
    # validna); naslov filma se ne tumači kao oznaka epizode
    if (not (info['season'] is not None and info['episode'] is not None)
            and info['title'] and media_type != 'movie'):
        season_num, episode_num, _ = parse_season_episode(info['title'])
        if season_num is not None:
            info['season'] = season_num
            if episode_num is not None:
                info['episode'] = episode_num
            log(f"get_media_info: parsed S{season_num}"
                f"{'E' + str(episode_num) if episode_num is not None else ''} from title")

    # ----------------------------------------------------------
    # Godina iz naslova, kada je oznake nisu dale
    # ----------------------------------------------------------
    if not info['year'] and info['title']:
        _, year_found = clean_title_for_search(info['title'])
        if year_found:
            info['year'] = year_found
            log(f"get_media_info: parsed year {year_found} from title")

    # Bez IMDB ID-a naslov se razrešava preko TMDB-a; poznat TMDB broj ima
    # prednost nad pretragom po nazivu
    imdb_from_label = bool(info['imdb_id'])

    if not info['imdb_id'] and info['tmdb_id']:
        # TMDB broj serije iz Kodi biblioteke je pouzdan - naslov se ne proverava
        from_library = lib_show is not None
        info['imdb_id'] = resolve_imdb_from_tmdb_id(
            info['tmdb_id'], series_first=info['season'] is not None or from_library,
            expected_title=None if from_library else info['title'])
        if info['imdb_id']:
            log(f"IMDB ID from TMDB id {info['tmdb_id']}: {info['imdb_id']}")

    # Antologija: sezona koju TMDB vodi kao zasebnu seriju mapira se na
    # matičnu IMDB seriju, uz novu numeraciju. Bez poznate sezone mapira se
    # samo serija sa jednom sezonom (sezona 1).
    anthology_season = info['season']
    if (not info['imdb_id'] and info['tmdb_id'] and info['season'] is None
            and ':' in (info['title'] or '')
            and tmdb_tv_season_count(info['tmdb_id']) == 1):
        anthology_season = 1
        log("anthology: whole-series search on a single-season show, using S1")

    if not info['imdb_id'] and info['tmdb_id'] and anthology_season:
        mapped = map_anthology_season(info['title'], info['tmdb_id'],
                                      anthology_season, info['episode'])
        if mapped:
            imdb, new_season, new_episode = mapped
            src = se_label(info['season'], info['episode']) or 'whole series'
            dst = se_label(new_season, new_episode if info['episode'] is not None else None)
            log(f"anthology: {src} -> {imdb} {dst}")
            info['imdb_id'] = imdb
            info['season']  = new_season
            if info['episode'] is not None:
                info['episode'] = new_episode

    # Svojstva Home prozora, uz proveru preko Cinemete; zatim pretraga po naslovu
    if not info['imdb_id'] and info['title']:
        info['imdb_id'] = imdb_from_window_props(
            info['title'], info['year'], is_series=info['season'] is not None,
            season=info['season'], episode=info['episode'])
        if info['imdb_id']:
            log(f"IMDB ID from Window(10000), verified: {info['imdb_id']}")

    if not info['imdb_id'] and info['title']:
        log("No IMDB ID found, resolving by title...")
        # Poznata sezona znači seriju, i bez epizode (pretraga cele sezone)
        is_series = info['season'] is not None
        info['imdb_id'] = resolve_imdb_by_title(
            info['title'], info['year'], series_first=is_series)

        if info['imdb_id']:
            log(f"IMDB ID from title lookup: {info['imdb_id']}")

    if not info['imdb_id']:
        log("get_media_info: no IMDB ID found, title search follows")

    # Kada ID nije pročitan iz oznake, oznake identifikatora se ispisuju u log
    if not imdb_from_label:
        log_media_id_probe()

    log(f"get_media_info result: {info}")
    return info


# ============================================================
#  HELPER - OPENSUBTITLES VIDEO HASH
# ============================================================

OS_HASH_CHUNK = 65536          # 64 KB
OS_HASH_MIN_SIZE = 131072      # OS zahteva fajl veći od 128 KB

def _os_hash_from_chunks(size, head, tail):
    """OS hash: veličina + zbir 64-bitnih reči prvih i poslednjih 64 KB."""
    hash_val = size & 0xFFFFFFFFFFFFFFFF
    for buf in (head, tail):
        usable = len(buf) - (len(buf) % 8)
        hash_val = (hash_val + sum(struct.unpack('<%dQ' % (usable // 8), bytes(buf[:usable])))) & 0xFFFFFFFFFFFFFFFF
    return f"{hash_val:016x}"


def parse_kodi_url(url):
    """
    Kodi putanja streama nosi HTTP zaglavlja iza '|':
      https://host/file|User-Agent=...&Referer=...
    Vraća (čist URL, dict zaglavlja).
    """
    raw = str(url or '')
    if '|' not in raw:
        return raw, {}
    clean, tail = raw.split('|', 1)
    headers = {}
    for k, v in urllib.parse.parse_qsl(tail, keep_blank_values=True):
        if k:
            headers[k] = v
    return clean, headers


def _content_disposition_filename(value):
    """Naziv fajla iz Content-Disposition zaglavlja, RFC 5987 ili obični."""
    if not value:
        return ''
    m = re.search(r"filename\*=(?:UTF-8|utf-8)?''([^;]+)", value)
    if m:
        return urllib.parse.unquote(m.group(1).strip().strip('"'))
    m = re.search(r'filename\s*=\s*"([^"]+)"', value)
    if not m:
        m = re.search(r'filename\s*=\s*([^;]+)', value)
    return m.group(1).strip() if m else ''


def compute_stream_hash(url):
    """
    OS hash i naziv fajla za HTTP stream, preko dva Range zahteva.
    Vraća {'hash', 'size', 'filename'}, prazan dict za konačan odgovor bez
    podataka (manifest, IPTV VOD, server bez Range podrške), ili None kod
    privremenog neuspeha.
    """
    clean, headers = parse_kodi_url(url)
    low = clean.lower().split('?', 1)[0]
    if not low.startswith(('http://', 'https://')):
        return None
    if low.endswith(STREAM_MANIFEST_EXT):
        log("stream hash: manifest stream, skipping")
        return {}
    if STREAM_PROBE_SKIP.search(low):
        log("stream hash: IPTV VOD source, skipping")
        return {}

    req_headers = dict(headers)
    req_headers.setdefault('User-Agent', HEADERS['User-Agent'])

    def ranged(start, end):
        h = dict(req_headers)
        h['Range'] = f"bytes={start}-{end}"
        r = requests.get(clean, headers=h, stream=True, timeout=TIMEOUT_HASH)
        try:
            if r.status_code != 206:
                log(f"stream hash: server answered {r.status_code} to Range, skipping")
                return None, r.headers, r.status_code
            body = r.raw.read(OS_HASH_CHUNK)
            return body, r.headers, r.status_code
        finally:
            r.close()

    try:
        head, h1, status = ranged(0, OS_HASH_CHUNK - 1)
        if head is None:
            # Odgovori 200 (Range zanemaren) i 416 su konačni; ostali se
            # ponavljaju pri sledećoj pretrazi
            return {} if status in (200, 416) else None

        m = re.search(r'/(\d+)\s*$', h1.get('Content-Range', ''))
        size = int(m.group(1)) if m else 0
        filename = _content_disposition_filename(h1.get('Content-Disposition', ''))
        if filename:
            log(f"stream hash: filename from Content-Disposition -> {filename}")

        if size < OS_HASH_MIN_SIZE:
            log(f"stream hash: size unknown or too small ({size})")
            return {'hash': None, 'size': size or None, 'filename': filename}

        tail, _, _ = ranged(size - OS_HASH_CHUNK, size - 1)
        if tail is None or len(head) < OS_HASH_CHUNK or len(tail) < OS_HASH_CHUNK:
            log("stream hash: incomplete chunks, hash skipped")
            return {'hash': None, 'size': size, 'filename': filename}

        hash_hex = _os_hash_from_chunks(size, head, tail)
        log(f"stream hash: hash={hash_hex} size={size}")
        return {'hash': hash_hex, 'size': size, 'filename': filename}

    except Exception as e:
        log(f"stream hash: failed ({e})")
        return None


# Pomoćne niti pokrenute u ovom procesu. Pre izlaska se čeka njihov kraj
# (najviše THREAD_EXIT_WAIT), da završni red loga bude poslednji.
_threads = []

# Najduže ukupno čekanje (s) na niti pri izlasku - lista je tada već
# predata Kodiju. Pokriva REST upit sa ponovnim pokušajem (5 + 1 + 5 s);
# nit koja radi duže (hash upit sporog servera) završava sama, jer Kodi
# čeka niti skripte pre gašenja interpretera.
THREAD_EXIT_WAIT = 12


def start_thread(target):
    t = threading.Thread(target=target)
    t.daemon = True
    t.start()
    _threads.append(t)
    return t


def join_threads():
    deadline = time.time() + THREAD_EXIT_WAIT
    for t in _threads:
        left = deadline - time.time()
        if left <= 0:
            break
        t.join(left)
    alive = sum(1 for t in _threads if t.is_alive())
    if alive:
        log(f"exit: {alive} helper thread(s) still running")


def start_stream_probe(url, probe, lang_codes, current_file, search_key):
    """
    Stream probe i hash upit u pozadinskoj niti. probe je rezultat iz keša
    reprodukcije (tada ostaje samo hash upit) ili None. Nit sama čuva
    rezultate u kešu reprodukcije, pa kasni rezultat koristi sledeće
    otvaranje. Vraća (nit, držač): držač['result'] je probe, a
    držač['matched'] hash pogoci.
    """
    holder = {}

    def _run():
        result = probe
        if result is None:
            try:
                result = compute_stream_hash(url)
            except Exception as e:
                log(f"stream hash: thread error ({e})")
                result = None
            # Privremeni neuspeh (None) se ne kešira kao rezultat, beleži se
            # samo njegovo vreme; kasni rezultat se ne upisuje kada se u
            # međuvremenu pušta drugi video
            if result is not None and playback_unchanged(search_key):
                playback_cache_save(current_file, search_key, probe=result)
            elif result is None and playback_unchanged(search_key):
                playback_cache_save(current_file, search_key, probe_fail_ts=time.time())
        holder['result'] = result
        if result and result.get('hash') and result.get('size'):
            matched = xmlrpc_hash_lookup(result['hash'], result['size'], lang_codes)
            holder['matched'] = matched
            if matched is not None and playback_unchanged(search_key):
                save_hash_matches(current_file, matched, lang_codes, search_key)

    return start_thread(_run), holder


def compute_os_hash(file_path):
    if not file_path or not isinstance(file_path, str):
        return None, None

    low = file_path.lower()
    if low.startswith(NO_HASH_SCHEMES):
        scheme = low.split('://', 1)[0] + '://'
        log(f"compute_os_hash: stream source ({scheme}), hash left to the stream probe")
        return None, None

    f = None
    try:
        f = xbmcvfs.File(file_path)
        size = f.size()

        if not size or size < OS_HASH_MIN_SIZE:
            log(f"compute_os_hash: file too small or size unknown ({size})")
            return None, None

        f.seek(0, 0)
        head = f.readBytes(OS_HASH_CHUNK)
        f.seek(size - OS_HASH_CHUNK, 0)
        tail = f.readBytes(OS_HASH_CHUNK)
        hash_hex = _os_hash_from_chunks(size, head, tail)
        log(f"compute_os_hash: hash={hash_hex} size={size}")
        return hash_hex, size

    except Exception as e:
        log(f"compute_os_hash: failed ({e})")
        return None, None
    finally:
        if f is not None:
            try:
                f.close()
            except Exception:
                pass


# ============================================================
#  HELPER - SYNC HEURISTIC BY RELEASE NAME
#  Poređenje release grupe i tagova izdanja, kada nema hash potvrde
# ============================================================

@functools.lru_cache(maxsize=4096)
def extract_release_groups(text):
    """
    Skup svih release grupa u tekstu. Tekst (MovieReleaseName, naziv fajla,
    komentar uploadera) može navoditi više izdanja.
    """
    if not text:
        return set()

    groups = set()

    # Tekst može biti spisak izdanja, red po red
    for line in re.split(r'[\r\n,;]+', str(text)):
        line = line.strip()
        if len(line) < 6:
            continue

        # Uklanjanje ekstenzija
        base = re.sub(r'\.(srt|sub|ssa|ass|txt|vtt|mkv|mp4|avi|mov|m2ts)$', '',
                      line, flags=re.IGNORECASE)

        # Uklanjanje oznaka jezika, pisma i kodne strane, broja kopije i
        # oznake trackera iza grupe ("-GRUPA[TGx]")
        for _ in range(8):
            new = _SUB_SUFFIX_RE.sub('', base)
            if new != base:
                new = new.rstrip(' ._-')
            m = _TRAILING_TAGS_RE.search(new)
            if m and not _tag_like_group(m.group(1).lower()):
                new = new[:m.start(2)]
            # Oznaka trackera iza grupe ("-GRUPA-Obfuscated", "-GRUPA-EZTVx.to")
            m = re.search(r'-([A-Za-z0-9]{3,}(?:\.[A-Za-z]{2,3})?)\s*$', new)
            if m and _tracker_tag(m.group(1).lower()):
                new = new[:m.start()]
            if new == base:
                break
            base = new

        # Grupa u uglastim zagradama, bilo gde u redu; zagrada može nositi
        # više grupa razdvojenih sa " - " (ili ".-." kada su razmaci već
        # tačke), "/", "|", ",", a razmak u nazivu grupe važi kao tačka
        # ("[Neka Grupa]" = "[Neka.Grupa]")
        for m in re.finditer(r'\[([^\]]{3,})\]', base):
            for part in re.split(r'\s*[/|,+]\s*|[\s.]+-[\s.]+', m.group(1)):
                part = re.sub(r'\s+', '.', part.strip()).strip('.').lower()
                if len(part) >= 3 and re.fullmatch(r'[a-z0-9.]+', part):
                    groups.add(part)

        # Grupa iza crtice na kraju reda; sa domenom samo YTS ("-YTS.MX")
        m = re.search(r'-([A-Za-z0-9]{3,})(\.[A-Za-z]{2,3})?\s*$', base)
        if m:
            g = (m.group(1) + (m.group(2) or '')).lower()
            if not m.group(2) or _norm_group(g) == 'yts':
                groups.add(g)

    # Uklanjaju se oznake izdanja i trackera koje nisu nazivi grupa
    return frozenset(_norm_group(g) for g in groups
                     if not _tag_like_group(g) and not _tracker_tag(g))


_SOURCE_TAG_SET  = {t for tags in SOURCE_FAMILIES.values() for t in tags}
_QUALITY_TAG_SET = {t for toks in QUALITY_TAGS.values() for t in toks}
_OTHER_TAG_SET   = {'rip', 'ray', 'dl', 'eng', 'english', 'sub', 'subs',
                    'hardsub', 'multi', 'dual', 'dubbed', 'internal',
                    'limited', 'complete', 'atmos', 'hd', 'sd'}
_AUDIO_TAG_RE    = re.compile(r'(?:dd|ddp|dd\+|aac|ac3|eac3|dts|truehd|flac|opus|mp3)[\d.]*')
_SUFFIX_SET      = set(SUB_NAME_SUFFIXES)
_SUFFIX_ALT      = '|'.join(re.escape(s) for s in
                            sorted(SUB_NAME_SUFFIXES, key=len, reverse=True))
_SUB_SUFFIX_RE   = re.compile(
    r'(?:[\[(](?:' + _SUFFIX_ALT + r')[\])]'            # [srp], (lat)
    r'|(?<=[\s._-])(?:' + _SUFFIX_ALT + r')'           # .sr, -lat, _utf8
    r'|\(\d{1,2}\))\s*$',                                # (1)
    re.IGNORECASE)
_TRAILING_TAGS_RE = re.compile(r'-([A-Za-z0-9]{2,})((?:\s*\[[^\]]*\])+)\s*$')


def _tag_like_group(g):
    """Da li izvučena 'grupa' zapravo liči na oznaku izdanja."""
    if not re.search(r'[a-z]', g):                  # 5.1, 2019
        return True
    if g in _SOURCE_TAG_SET or g in _QUALITY_TAG_SET or g in _OTHER_TAG_SET:
        return True
    if g in RELEASE_TAGS or g in _SUFFIX_SET:
        return True
    if re.fullmatch(r'\d{3,4}[pi]', g):             # 1080p, 1080i
        return True
    if re.fullmatch(r's\d{1,2}e\d{1,3}(e\d{1,3})?|\d{1,2}x\d{2,3}', g):
        return True                                 # S01E02, 1x02
    return bool(_AUDIO_TAG_RE.fullmatch(g))


def _tracker_tag(g):
    """Oznaka trackera (TGx, ettv, eztv.re...) umesto release grupe."""
    return g in TRACKER_TAGS or g.split('.')[0] in TRACKER_TAGS


def _norm_group(g):
    """Isti enkoder pod različitim oznakama (YTS.MX, YTS.AM, YIFY)."""
    return 'yts' if g == 'yify' or g == 'yts' or g.startswith('yts.') else g


# Granica između naslova i oznaka izdanja: godina, oznaka epizode ili
# sezone. Oznake izvora i provajdera traže se tek iza nje.
RELEASE_PART_START = re.compile(
    r'(?<![a-z0-9])(?:(?:19|20)\d{2}|s\d{1,2}[\s._-]*e\d{1,3}|\d{1,2}x\d{2,3}|s\d{1,2})'
    r'(?![a-z0-9])')


def release_part(text):
    """
    Deo naziva iza naslova, malim slovima; bez godine i oznake epizode
    ceo naziv.
    """
    low = str(text or '').lower()
    m = RELEASE_PART_START.search(low)
    return low[m.end():] if m else low


# Oznake izvora koje mogu biti i reč naslova epizode ("Cam", "Web", "Ma",
# "Stan"): računaju se samo kada naziv nosi i oznaku kvaliteta ili
# nedvosmislenu oznaku izvora, a "stan" i "ma" samo neposredno ispred web
# oznake (explicit_web_provider).
_WEAK_SOURCE_TAGS = {'web', 'blu', 'dvd', 'ts', 'tc', 'cam', 'scr', 'r5',
                     'dsr', 'dvbc', 'dvbs'} | set(WEB_PROVIDERS)
_AMBIGUOUS_TAGS   = {'stan', 'ma'}


@functools.lru_cache(maxsize=4096)
def detect_source_family(text):
    """
    Porodica izvora ('web', 'disc', 'tv', 'cam') ili ''. Odlučuje poslednji
    prepoznat token iza naslova, jer oznaka izvora stoji iza naslova epizode,
    a ispred kodeka i grupe.
    """
    if not text:
        return ''
    words = release_words(release_part(text))
    strong = any(t in _SOURCE_TAG_SET and t not in _WEAK_SOURCE_TAGS for t in words)
    release_like = strong or any(t in _QUALITY_TAG_SET for t in words)
    family = ''
    for tok in words:
        if tok in _AMBIGUOUS_TAGS or (tok in _WEAK_SOURCE_TAGS and not release_like):
            continue
        for fam, tags in SOURCE_FAMILIES.items():
            if tok in tags:
                family = fam
    return family


# Provajder naveden neposredno ispred web oznake ("AMZN.WEB-DL", "NF.WEBRip");
# reč iz naslova epizode ("Stan", "Ma") se ne računa
_PROVIDER_WEB_RE = re.compile(
    r'(?<![a-z0-9])(' + '|'.join(WEB_PROVIDERS) + r')[\s._-]+web(?:[\s._-]?(?:dl|rip))?(?![a-z0-9])')


def explicit_web_provider(text):
    """Provajder naveden neposredno ispred web oznake, iza naslova, ili ''."""
    m = _PROVIDER_WEB_RE.search(release_part(text))
    return m.group(1) if m else ''


def detect_web_provider(text):
    """
    Provajder web izdanja: naveden ispred web oznake, inače poslednji token
    provajdera iza naslova, ili ''.
    """
    prov = explicit_web_provider(text)
    if prov:
        return prov
    for tok in release_words(release_part(text)):
        if tok in WEB_PROVIDERS and tok not in _AMBIGUOUS_TAGS:
            prov = tok
    return prov


def get_video_name_for_match():
    """
    Naziv videa za poređenje sa nazivom izdanja - prvi kandidat koji liči
    na naziv izdanja (putanja, oznaka stavke, InfoLabels).
    """
    def usable(name):
        if not name:
            return ''
        # Kodi putanja nosi HTTP zaglavlja iza '|'
        base = os.path.basename(str(name).split('|')[0].split('?')[0]).strip()
        # Naziv izdanja ima razdvajače i razumnu dužinu
        if len(base) < 10 or not re.search(r'[._\- ]', base):
            return ''
        # Hash i UUID nizovi se odbacuju
        stripped = re.sub(r'[^A-Za-z0-9]', '', base)
        if len(stripped) >= 16 and not re.search(r'(19|20)\d{2}', base):
            low = base.lower()
            has_tag = any(t in low for t in ('1080', '2160', '720', 'web', 'blu', 'hdtv', 'x264', 'x265'))
            if not has_tag:
                return ''
        return base

    candidates = []

    # 1. Stvarna putanja fajla
    try:
        candidates.append(unquote(xbmc.Player().getPlayingFile()))
    except Exception:
        pass

    # 2. Oznaka stavke - video addoni tu često upisuju puni naziv izdanja
    try:
        item = xbmc.Player().getPlayingItem()
        candidates.append(item.getLabel())
        candidates.append(item.getLabel2())
        for prop in ('release_title', 'releaseTitle', 'release', 'source_name', 'filename', 'name'):
            try:
                candidates.append(item.getProperty(prop))
            except Exception:
                pass
    except Exception:
        pass

    # 3. InfoLabels sa originalnim nazivom
    for lbl in ('Player.Filename',
                'ListItem.FilenameAndPath',
                'ListItem.Filename',
                'ListItem.Label',
                'Player.Title',
                'VideoPlayer.Title'):
        try:
            candidates.append(xbmc.getInfoLabel(lbl))
        except Exception:
            pass

    # Prednost ima naziv sa oznakama izdanja ili grupom; sam naslov (oznaka
    # stavke) je poslednja mogućnost
    names = []
    for c in candidates:
        got = usable(c)
        if got and got not in names:
            names.append(got)
    for got in names:
        if _release_facts(got)['rel'] or extract_release_groups(got):
            log(f"sync: video name for matching -> {got}")
            return got
    if names:
        log(f"sync: video name for matching (no release tags) -> {names[0]}")
        return names[0]

    log("sync: no usable video name found, release matching disabled")
    return ''


def fps_conflict(sub_fps, video_fps):
    """
    Da li su FPS titla i videa poznati i različiti. Celobrojni umnožak
    (Kodi na startu reprodukcije zna da prijavi dupli FPS) nije sukob,
    jer trajanje ostaje isto.
    """
    try:
        if not sub_fps or not video_fps:
            return False
        sf, vf = float(sub_fps), float(video_fps)
        if sf <= 0 or vf <= 0:
            return False
        ratio = max(sf, vf) / min(sf, vf)
        return abs(ratio - round(ratio)) > 0.005
    except (TypeError, ValueError):
        return False


def source_conflict(texts, video_name):
    """
    Da li nazivi izdanja titla navode samo izvor različit od izvora videa
    (npr. CAM za Blu-ray) - znak da titl verovatno nije sinhronizovan.
    """
    if not video_name:
        return False
    vid = os.path.basename(str(video_name)).lower().replace('_', '.').replace(' ', '.')
    vid_src = detect_source_family(vid)
    if not vid_src:
        return False
    # Samo nazivi izdanja (sa godinom ili oznakom epizode), naziv po naziv;
    # slobodan tekst komentara se ne računa
    texts = [t for t in (texts or []) if t and str(t).strip()]
    segs = [seg for t in split_release_list(texts) for seg in _release_segments(t)
            if RELEASE_PART_START.search(seg.lower())]
    families = {detect_source_family(seg) for seg in segs} - {''}
    return bool(families) and vid_src not in families


def split_release_list(texts):
    """
    Razbija tekstove na pojedinačne nazive izdanja (red po red ili zarez).
    Zarez deli samo nazive sa tačkama bez razmaka, da naslov sa zarezom
    ostane ceo.
    """
    out = []
    for text in texts:
        for line in re.split(r'[\r\n;]+', str(text)):
            line = line.strip()
            if not line:
                continue
            parts = [p.strip() for p in line.split(',')]
            if len(parts) > 1 and all(p and '.' in p and ' ' not in p for p in parts):
                out.extend(parts)
            else:
                out.append(line)
    return out


_MEDIA_EXT = {'mkv', 'mp4', 'avi', 'm4v', 'mov', 'srt'}


@functools.lru_cache(maxsize=4096)
def _release_facts(text):
    """Izvor, web provajder i verzija filma iz naziva izdanja."""
    toks = release_tokens(text)
    part = release_tokens(release_part(text))
    src  = detect_source_family(text)
    return {
        'src':  src,
        'prov': detect_web_provider(text),
        'ed':   {EDITION_TAGS[t] for t in part if t in EDITION_TAGS},
        # Naziv nosi oznake izdanja (nije samo naslov ili komentar)
        'rel':  bool(src) or quality_matches(toks, toks) >= 1,
    }


def _release_conflict(a, b):
    """Da li se dva naziva izdanja razlikuju po izvoru, provajderu ili verziji."""
    if a['src'] and b['src'] and a['src'] != b['src']:
        return True
    if not (a['rel'] and b['rel']):
        return False
    if a['prov'] and b['prov'] and a['prov'] != b['prov']:
        return True
    return a['ed'] != b['ed']


# Završne reči naziva videa koje nisu release grupe
_NON_GROUP_WORDS = {'audio', 'cut', 'edition', 'version', 'subbed', 'sample',
                    'ita', 'ger', 'deu', 'fre', 'fra', 'spa', 'esp', 'rus',
                    'pol', 'hun', 'cze', 'tur', 'por', 'nld', 'swe', 'nor',
                    'dan', 'fin', 'jpn', 'kor', 'chi'}


# Domeni iza oznake trackera ("EZTVx.to", "eztv.re")
_TRACKER_DOMAINS = {'to', 're', 'mx', 'am', 'com', 'org', 'net', 'io', 'se', 'cc', 'li',
                    'ws', 'de', 'nl', 'ru', 'me', 'uk', 'pw', 'ch'}


def _last_group_token(name):
    """
    Poslednji token naziva videa ako liči na release grupu ("x264 GRUPA",
    "AAC5.1.YIFY"), inače ''. Oznake jezika i trackera na kraju se preskaču.
    """
    base = re.sub(r'\.(mkv|mp4|avi|m4v|mov|m2ts|webm)$', '', str(name or ''),
                  flags=re.IGNORECASE)
    toks = release_words(base)
    # Oznake jezika i trackera (i domen trackera, "EZTVx.to") i broj kopije
    # ("(1)") na kraju se preskaču
    while toks and (toks[-1] in _SUFFIX_SET or _tracker_tag(toks[-1])
                    or (toks[-1].isdigit() and len(toks[-1]) <= 2)
                    or (len(toks) >= 2 and _tracker_tag(toks[-2])
                        and (toks[-1] in _TRACKER_DOMAINS
                             or (len(toks[-1]) == 2 and toks[-1].isalpha())))):
        toks.pop()
    if not toks:
        return ''
    # YTS sa domenom ("YTS.MX")
    if len(toks) >= 2 and _norm_group(f"{toks[-2]}.{toks[-1]}") == 'yts':
        return 'yts'
    last = toks[-1]
    if (len(last) >= 3 and not _tag_like_group(last)
            and last not in _NON_GROUP_WORDS and last not in EDITION_TAGS):
        return _norm_group(last)
    return ''


def _ends_with_group(name):
    """Da li se naziv videa završava tokenom koji liči na release grupu."""
    return bool(_last_group_token(name))


# Razdvajanje teksta sa više naziva izdanja (komentar uploadera): novi
# red, zarez, tačka-zarez, " / ", " | ", " & ", " + ", ili razmak ispred
# naziva koji počinje novo izdanje (".2023", ".S01", ".S01E02")
_SEGMENT_SPLIT_RE = re.compile(
    r'[\r\n,;]+|\s+[/|&+]\s+'
    r'|\s+(?=\S*\.(?:(?:19|20)\d{2}|[sS]\d{1,2}(?:[eE]\d{1,3})?)(?![a-zA-Z0-9]))')


@functools.lru_cache(maxsize=4096)
def _release_segments(text):
    """
    Pojedinačni nazivi izdanja iz teksta. Naziv sa tačkama unutar rečenice
    ("Sync za Naziv.2023.1080p.WEB-GRUPA i ...") izdvaja se i zasebno, bez
    interpunkcije oko njega.
    """
    out = []
    for p in _SEGMENT_SPLIT_RE.split(str(text)):
        p = (p or '').strip().rstrip('.,;:!?')
        if not p:
            continue
        out.append(p)
        if re.search(r'\s', p):
            for tok in p.split():
                tok = tok.strip('.,;:!?()"\'')
                if tok != p and '.' in tok and RELEASE_PART_START.search(tok.lower()):
                    out.append(tok)
    return tuple(out)


# Poslednja oznaka izdanja u nazivu videa (rezolucija, izvor, kodek, zvuk,
# HDR) - iza nje su release grupa i eventualne dodatne oznake
_LAST_RELEASE_TAG_RE = re.compile(
    r'(?<![a-z0-9])(?:\d{3,4}[pi]|x26[45]|h\.?26[45]|hevc|avc|xvid|divx|web-?dl|webrip|'
    r'bluray|bdrip|brrip|hdtv|hdrip|dvdrip|remux|(?:dd|ddp|aac|ac3|eac3)\d?(?:\.\d)?|'
    r'dts(?:-hd)?|truehd|atmos|hdr10\+?|hdr|dv|10bit)(?![a-z0-9])')


def _tail_groups(vid):
    """
    Release grupe iza poslednje oznake izdanja u nazivu videa, i kada iza
    grupe stoji još jedna oznaka ("...H265-Ben.The.Men-DUAL.FAMG").
    """
    base = re.sub(r'\.(mkv|mp4|avi|m4v|mov|m2ts|webm)$', '', vid)
    last = None
    for last in _LAST_RELEASE_TAG_RE.finditer(base):
        pass
    if last is None:
        return frozenset()
    groups = set()
    for seg in base[last.end():].split('-')[1:]:
        seg = seg.strip('._ ')
        if (len(seg) >= 3 and re.fullmatch(r'[a-z0-9]+(?:\.[a-z0-9]+)*', seg)
                and re.search(r'[a-z]', seg)
                and not _tag_like_group(seg) and not _tracker_tag(seg)):
            groups.add(_norm_group(seg))
    return frozenset(groups)


@functools.lru_cache(maxsize=8)
def _video_facts(vid):
    """
    Podaci o nazivu videa koji ne zavise od titla, izračunati jednom po
    nazivu (poziva se za svaki titl u listi).
    """
    facts    = _release_facts(vid)
    tok      = release_tokens(vid) - _MEDIA_EXT
    rest     = release_part(vid)
    return (facts,
            extract_release_groups(vid) | _tail_groups(vid),
            _last_group_token(vid),
            tok,
            set(t for t in RELEASE_TAGS if t in tok),
            explicit_web_provider(vid),
            set(t for t in RELEASE_TAGS if t in release_tokens(rest)),
            bool(facts['rel'] and len(tok) >= 4 and _ends_with_group(vid)))


def is_release_match(candidates, video_name, sub_fps=None, video_fps=None):
    """
    candidates - tekstovi sa nazivima izdanja: MovieReleaseName, naziv
    fajla titla, komentar uploadera.

    Vraća sync nivo:
      SYNC_TIER_GROUP    (1) - ista release grupa, bez sukoba izvora,
                               provajdera i verzije filma
      SYNC_TIER_PROVIDER (2) - web izdanje istog provajdera (naveden ispred
                               web oznake), sa istim oznakama izdanja
      SYNC_TIER_TAGS     (3) - ista porodica izvora bez sukoba provajdera,
                               ili slaganje kvaliteta preko praga (procena)
      SYNC_TIER_NONE     (4) - nema poklapanja
    Poredi se sa konstantama, ne kao bool.
    """
    if isinstance(candidates, str):
        candidates = [candidates]
    elif not isinstance(candidates, (list, tuple, set)):
        return SYNC_TIER_NONE
    candidates = split_release_list(c for c in candidates if c and str(c).strip())

    if not candidates or not video_name:
        return SYNC_TIER_NONE

    vid = os.path.basename(str(video_name)).lower()
    vid = vid.replace('_', '.').replace(' ', '.')

    # Video naziv mora imati bar nešto upotrebljivo
    if len(vid) < 8:
        return SYNC_TIER_NONE

    (vid_facts, vid_groups, vid_last, vid_tok, vid_cut, vid_ep,
     vid_part_cut, word_rule) = _video_facts(vid)

    def group_in_video(g):
        # Izvučena grupa videa, poslednji token naziva ("x264 GRUPA.mkv") ili
        # grupa na početku naziva fajla ("grupa-naslov.2023.mkv"). Poslednji
        # token važi samo uz oznake izdanja, da reč iz naslova epizode
        # ("S01E02 - Elite.mkv") ne bude grupa.
        return len(g) >= 3 and (g in vid_groups
                                or (g == vid_last and vid_facts['rel'])
                                or vid.startswith(g + '-'))

    # 1. Ista release grupa znači isti izvor i tajming, pa ima prednost i
    #    nad FPS proverom - osim kada se nazivi razlikuju po izvoru,
    #    provajderu ili verziji filma (grupa izdaje i WEB i Blu-ray). Tekst
    #    sa više izdanja proverava se naziv po naziv.
    for cand in candidates:
        for seg in _release_segments(cand):
            if (any(group_in_video(g) for g in extract_release_groups(seg))
                    and not _release_conflict(_release_facts(seg), vid_facts)):
                return SYNC_TIER_GROUP

    # Bez poklapanja grupe FPS neslaganje presuđuje protiv
    if fps_conflict(sub_fps, video_fps):
        return SYNC_TIER_NONE

    # Izvor ripa - različite porodice gotovo nikad nemaju isti tajming;
    # unutar web porodice presuđuje provajder
    vid_src  = vid_facts['src']
    vid_prov = vid_facts['prov']

    # Isti naziv izdanja od reči do reči kada grupa nije izdvojena - samo
    # kada naziv videa nosi oznake izdanja i završava se grupom; tekst sa
    # više izdanja proverava se naziv po naziv
    if word_rule:
        for cand in candidates:
            for seg in _release_segments(cand):
                if ((release_tokens(seg) - {'srt', 'sub', 'txt'}) >= vid_tok
                        and not _release_conflict(_release_facts(seg), vid_facts)):
                    return SYNC_TIER_GROUP

    # 2. Isti web provajder: različite grupe skidaju isti fajl sa servisa.
    #    Oba naziva navode istog provajdera neposredno ispred web oznake
    #    ("AMZN.WEB-DL", "NF.WEBRip") i imaju iste oznake izdanja (PROPER,
    #    REPACK, EXTENDED...). Proveravaju se samo nazivi izdanja (sa godinom
    #    ili oznakom epizode), naziv po naziv.
    if vid_ep:
        for cand in candidates:
            for seg in _release_segments(cand):
                if not RELEASE_PART_START.search(seg.lower()):
                    continue
                seg_cut = set(t for t in RELEASE_TAGS
                              if t in release_tokens(release_part(seg)))
                if (explicit_web_provider(seg) == vid_ep
                        and seg_cut == vid_part_cut
                        and not _release_conflict(_release_facts(seg), vid_facts)):
                    return SYNC_TIER_PROVIDER

    # 3. Ista porodica izvora ili slaganje kvaliteta - procena, naziv po naziv
    for cand in candidates:
        for seg in _release_segments(cand):
            sub_src = detect_source_family(seg)
            if vid_src and sub_src and vid_src != sub_src:
                continue
            sub_tok = release_tokens(seg)
            # Različit rez izdanja znači različit tajming
            if set(t for t in RELEASE_TAGS if t in sub_tok) != vid_cut:
                continue

            same_source = bool(vid_src and sub_src and vid_src == sub_src)
            quality = quality_matches(sub_tok, vid_tok)

            if same_source:
                # Ista porodica izvora znači verovatno isti tajming, osim kod
                # različitih web provajdera
                sub_prov = detect_web_provider(seg)
                if vid_prov and sub_prov and vid_prov != sub_prov:
                    continue
                return SYNC_TIER_TAGS
            elif quality >= SYNC_TAG_THRESHOLD:
                return SYNC_TIER_TAGS

    return SYNC_TIER_NONE


# ============================================================
#  HELPER - ACTIVE LANGUAGE LIST
#  Jezici za pretragu:
#  USE_INTERNAL_LANGUAGES = True  -> cela EXYU_LANGUAGES lista
#  USE_INTERNAL_LANGUAGES = False -> jezici iz Kodi podešavanja (parametar
#    'languages', engleski nazivi, redosledom Kodi liste, bez prioriteta);
#    pravila za ex-yu jezike važe samo za njih
#  Bez upotrebljivog Kodi jezika koristi se interna lista.
# ============================================================

def language_entry(name):
    """
    Unos jezika van interne liste, iz engleskog naziva kako ga daje Kodi.
    Vraća None kada Kodi jezik ne prepoznaje.
    """
    label = str(name or '').strip()
    if not label:
        return None
    try:
        code_b  = str(xbmc.convertLanguage(label, xbmc.ISO_639_2) or '').lower()
        code_1  = str(xbmc.convertLanguage(label, xbmc.ISO_639_1) or '').lower()
    except Exception:
        return None
    os_id = OS_LANG_OVERRIDES.get(label.lower(), code_b)
    if len(os_id) != 3:
        return None
    codes = [os_id]
    for c in (code_b, ISO6392_B_TO_T.get(code_b, '')):
        if c and c not in codes:
            codes.append(c)
    return {'lang_code': code_1 or os_id, 'label': label,
            'stremio': codes, 'rest': [os_id]}


def find_language(name):
    """Unos jezika za naziv: interna lista, engleski ili Kodi konverzija."""
    low = str(name or '').strip().lower()
    for entry in EXYU_LANGUAGES + [ENGLISH_LANGUAGE]:
        if entry['label'].lower() == low:
            return entry
    return language_entry(name)


SERBO_CROATIAN = ('serbo-croatian', 'serbocroatian')


def effective_preferred(preferred, active, kodi_mode):
    """
    Preferirani jezik koji pretraga poštuje.

    Jezik važi samo ako je među jezicima pretrage (interna lista ili Kodi
    jezici, nikad oba); sa internom listom engleski ne važi, jer je
    rezerva. 'forced_only' važi samo sa Kodi jezicima. 'original' i
    'default' se prevode kao u Kodiju (jezik audio trake, jezik
    interfejsa); 'none' znači redosled liste.

    Vraća (naziv jezika ili '', forced_only).
    """
    val = str(preferred or '').strip()
    low = val.lower()
    if low == 'forced_only':
        if not kodi_mode:
            log("search: preferred 'forced_only' ignored with the internal language list")
        return '', kodi_mode
    if low in ('original', 'default'):
        val = kodi_preferred_language(low)
        low = val.lower()
    if low in ('', 'none', 'unknown'):
        return '', False
    labels = {e['label'].lower() for e in active
              if kodi_mode or e.get('lang_code') != 'en'}
    if low in labels or (low in SERBO_CROATIAN
                         and labels & {'serbian', 'montenegrin', 'bosnian', 'croatian'}):
        return val, False
    log(f"search: preferred '{val}' is not among the search languages, ignored")
    return '', False


def select_languages(kodi_languages='', use_internal=None):
    """
    Jezici pretrage i da li važi režim Kodi jezika. Vraća (lista, kodi_mode);
    kodi_mode je False i kada nijedan Kodi jezik nije upotrebljiv.
    """
    # use_internal=None: važi USE_INTERNAL_LANGUAGES; pozadinski poziv ga može zameniti
    if use_internal is None:
        use_internal = USE_INTERNAL_LANGUAGES
    if use_internal or not kodi_languages:
        return list(EXYU_LANGUAGES), False

    names = [n.strip() for n in kodi_languages.split(',') if n.strip()]

    # Zbirni naziv "Serbo-Croatian" pokriva srpski, hrvatski, bosanski i crnogorski
    serbo_croatian = {'serbian', 'croatian', 'bosnian', 'montenegrin'}

    # Redosled iz Kodi podešavanja; ex-yu jezici zadržavaju svoje oznake i
    # pravila, a "Serbo-Croatian" se na svom mestu širi u svoje jezike
    active = []
    for name in names:
        if name.lower() in SERBO_CROATIAN:
            entries = [e for e in EXYU_LANGUAGES
                       if e['label'].lower() in serbo_croatian]
        else:
            entry = find_language(name)
            if entry is None:
                log(f"languages: unknown language '{name}', skipped")
            entries = [entry] if entry is not None else []
        for entry in entries:
            if entry not in active:
                active.append(entry)

    if not active:
        log("languages: no usable Kodi language, using internal list")
        return list(EXYU_LANGUAGES), False
    log(f"languages: using Kodi selection -> "
        f"{', '.join(e['label'] for e in active)}")
    return active, True


def order_by_preferred(active, preferred):
    """
    Preferirani jezik ide na vrh liste - redosled određuje raspored liste i
    prioritet interne liste. Jezik koji nije među jezicima pretrage se ne
    dodaje.
    """
    pref = (preferred or '').strip().lower()
    if not pref or pref in ('none', 'original', 'default', 'forced_only'):
        return active

    # Zbirni naziv podiže srpski, crnogorski, bosanski i hrvatski
    if pref in SERBO_CROATIAN:
        order = ['serbian', 'montenegrin', 'bosnian', 'croatian']
        matched = [e for lbl in order for e in active if e['label'].lower() == lbl]
    else:
        matched = [e for e in active if e['label'].lower() == pref]

    if not matched:
        log(f"languages: preferred '{preferred}' not in active list")
        return active
    log(f"languages: preferred '{preferred}' moved to top")
    return matched + [e for e in active if e not in matched]


# ============================================================
#  HELPER - DECODED TEXT SCORING
#  Ocena ispravnosti dekodiranog teksta za jednobajtne kodne strane.
#  Veći rezultat = verovatnije ispravan enkoding.
# ============================================================

def utf16_encoding(raw):
    """
    Kodek za UTF-16 ili UTF-32 sadržaj, inače None. Odlučuje BOM, a bez
    njega (samo UTF-16) raspored nula bajtova, kojih tekst u UTF-8 ili
    jednobajtnoj kodnoj strani nema.
    """
    if raw.startswith((codecs.BOM_UTF32_LE, codecs.BOM_UTF32_BE)):
        return 'utf-32'
    if raw.startswith((codecs.BOM_UTF16_LE, codecs.BOM_UTF16_BE)):
        return 'utf-16'
    head = raw[:1024]
    half = len(head) // 2
    if half < 4:
        return None
    even = head[0::2].count(0)
    odd = head[1::2].count(0)
    if odd >= half * 0.3 and even <= half * 0.05:
        return 'utf-16-le'
    if even >= half * 0.3 and odd <= half * 0.05:
        return 'utf-16-be'
    return None


def _dialogue_text(text):
    """
    Tekst replika za ocenu enkodinga: kod ASS/SSA samo tekst Dialogue
    redova, bez oznaka formatiranja ({\\...}, <i>...). Zaglavlja i oznake su
    ASCII u svakom enkodingu i ne govore ništa o pismu.
    """
    if 'Dialogue:' in text:
        lines = [l.split(',', 9)[9] for l in text.splitlines()
                 if l.startswith('Dialogue:') and l.count(',') >= 9]
        if lines:
            text = '\n'.join(lines)
    return re.sub(r'\{[^}]*\}|<[^>]*>', '', text)


def score_decoded_text(text):
    if not text or not isinstance(text, str):
        return -9999

    text     = _dialogue_text(text)
    score    = 0
    cyr_cnt  = 0
    lat_cnt  = 0
    ascii_cnt = 0

    for ch, n in collections.Counter(text).items():
        if ch in EXYU_LATIN_CHARS:
            score += 10 * n             # čćžšđ - jak pozitivan signal
            lat_cnt += n
        elif ch in SUSPICIOUS_CHARS:
            score -= 8 * n              # tipična posledica pogrešnog dekodiranja
        elif ch in EXYU_CYRILLIC_CHARS:
            cyr_cnt += n                # ocenjuje se kasnije, po koherentnosti
        elif ch.isascii():
            if ch.isalnum() or ch.isspace() or ch in '.,!?:;-\'"()[]<>/':
                score += n              # normalan tekst titla
                if ch.isalpha():
                    ascii_cnt += n
            elif ord(ch) < 32 and ch not in '\r\n\t':
                score -= 20 * n         # kontrolni znak - skoro sigurno greška
        elif ord(ch) > 0x2000 and ch not in '…—–‘’“”':
            score -= 5 * n              # egzotični unicode van očekivanog opsega

    # Ćirilica je ispravna samo kada je tekst pretežno ćiriličan; mešanje
    # pisama znači pogrešan enkoding.
    total_letters = cyr_cnt + lat_cnt + ascii_cnt
    if total_letters > 0:
        if cyr_cnt / total_letters > 0.5:
            score += cyr_cnt * 8        # koherentan ćirilični titl
        elif cyr_cnt > 0:
            score -= cyr_cnt * 6        # latinica pogrešno pročitana kao ćirilica

    return score


# ============================================================
#  HELPER - DISPLAY TAGS
#  Obojene oznake [AI] [Forced] [Featured] [Trusted/Rank] i broj preuzimanja.
#  AI/Forced plavo, Featured/Trusted/Rank zeleno, preuzimanja žuto.
# ============================================================

def build_tags(ai=False, forced=False, featured=False, trusted=False,
                user_rank='', downloads=None):
    tags = []
    if ai:       tags.append('[COLOR dodgerblue][AI][/COLOR]')
    if forced:   tags.append('[COLOR dodgerblue][Forced][/COLOR]')
    if featured: tags.append('[COLOR limegreen][Featured][/COLOR]')

    if trusted:
        tags.append('[COLOR limegreen][Trusted][/COLOR]')
    elif user_rank:
        rank_label = str(user_rank).strip().title()
        tags.append(f'[COLOR limegreen][{rank_label}][/COLOR]')

    result = ' '.join(tags)

    try:
        dl = int(downloads or 0)
    except (TypeError, ValueError):
        dl = 0
    if dl > 0:
        dl_str = f'[COLOR gold]{dl}x[/COLOR]'
        result = f'{result} {dl_str}' if result else dl_str

    return result


# ============================================================
#  HELPER - SCRIPT RATIO
#  Udeo ćirilice među slovima preuzetog teksta
# ============================================================

# Srpska ćirilica u latinicu; Љ, Њ, Џ zavise od susednih slova
_SR_CYR_TO_LAT = str.maketrans({
    'а': 'a', 'б': 'b', 'в': 'v', 'г': 'g', 'д': 'd', 'ђ': 'đ', 'е': 'e',
    'ж': 'ž', 'з': 'z', 'и': 'i', 'ј': 'j', 'к': 'k', 'л': 'l', 'љ': 'lj',
    'м': 'm', 'н': 'n', 'њ': 'nj', 'о': 'o', 'п': 'p', 'р': 'r', 'с': 's',
    'т': 't', 'ћ': 'ć', 'у': 'u', 'ф': 'f', 'х': 'h', 'ц': 'c', 'ч': 'č',
    'џ': 'dž', 'ш': 'š',
    'А': 'A', 'Б': 'B', 'В': 'V', 'Г': 'G', 'Д': 'D', 'Ђ': 'Đ', 'Е': 'E',
    'Ж': 'Ž', 'З': 'Z', 'И': 'I', 'Ј': 'J', 'К': 'K', 'Л': 'L', 'М': 'M',
    'Н': 'N', 'О': 'O', 'П': 'P', 'Р': 'R', 'С': 'S', 'Т': 'T', 'Ћ': 'Ć',
    'У': 'U', 'Ф': 'F', 'Х': 'H', 'Ц': 'C', 'Ч': 'Č', 'Ш': 'Š',
})
_SR_CYR_DIGRAPHS = {'Љ': ('Lj', 'LJ'), 'Њ': ('Nj', 'NJ'), 'Џ': ('Dž', 'DŽ')}
_SR_CYR_DIGRAPH_RE = re.compile('[ЉЊЏ]')


def cyrillic_to_latin(text):
    """
    Srpska ćirilica u latinicu. Љ, Њ i Џ u reči pisanoj velikim slovima
    postaju LJ, NJ i DŽ, inače Lj, Nj i Dž.
    """
    if not text:
        return text
    def _digraph(m, text=text):
        i = m.start()
        nxt = text[i + 1:i + 2]
        prv = text[i - 1] if i > 0 else ''
        caps = nxt.isupper() or (not nxt.isalpha() and prv.isupper())
        return _SR_CYR_DIGRAPHS[m.group()][1 if caps else 0]
    return _SR_CYR_DIGRAPH_RE.sub(_digraph, text).translate(_SR_CYR_TO_LAT)


def latin_conversion(preferred, auto=False):
    """
    Da li se ćirilični srpski i bosanski titlovi prevode u latinicu za
    preferirani jezik (engleski naziv, kako ga šalje Kodi): iz liste, ili
    pri automatskom učitavanju (auto=True). Srpski, Serbo-Croatian i bez
    preferiranog jezika idu po CYRILLIC_TO_LATIN_SERBIAN, ostali po
    CYRILLIC_TO_LATIN; makedonski se ne prevodi.
    """
    pref = str(preferred or '').strip().lower()
    if pref in ('original', 'default', 'forced_only', 'macedonian'):
        return False
    if pref in ('', 'none', 'serbian') or pref in SERBO_CROATIAN:
        mode = str(CYRILLIC_TO_LATIN_SERBIAN or 'never').strip().lower()
        return mode == 'always' or (mode == 'auto' and auto)
    return str(CYRILLIC_TO_LATIN or 'never').strip().lower() != 'never'


def cyrillic_ratio(text, sample=SCRIPT_SAMPLE_CHARS):
    """Udeo ćirilice među slovima, izračunat nad uzorkom teksta."""
    if not text:
        return 0.0
    if sample and len(text) > sample:
        text = text[:sample]
    cyr = 0
    lat = 0
    for ch in text:
        if ch in EXYU_CYRILLIC_CHARS:
            cyr += 1
        elif ch in EXYU_LATIN_CHARS or (ch.isascii() and ch.isalpha()):
            lat += 1
    total = cyr + lat
    if total < 50:          # premalo teksta za zaključak
        return 0.0
    return cyr / float(total)


# ============================================================
#  HELPER - KODI SETTINGS VIA JSON-RPC
#  Čitanje i upis Kodi podešavanja.
# ============================================================

def get_kodi_setting(setting_id):
    try:
        req = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "Settings.GetSettingValue",
            "params": {"setting": setting_id},
        }
        resp = json.loads(xbmc.executeJSONRPC(json.dumps(req)))
        if 'error' in resp:
            log_error(f"get_kodi_setting({setting_id}): {resp['error']}")
            return None
        return resp.get('result', {}).get('value')
    except Exception as e:
        log_error(f"get_kodi_setting({setting_id}): {e}")
        return None


def set_kodi_setting(setting_id, value):
    try:
        req = {"jsonrpc": "2.0", "id": 1, "method": "Settings.SetSettingValue",
               "params": {"setting": setting_id, "value": value}}
        resp = json.loads(xbmc.executeJSONRPC(json.dumps(req)))
        return 'error' not in resp
    except Exception as e:
        log_error(f"set_kodi_setting({setting_id}): {e}")
        return False


def _set_home_prop(name, value):
    try:
        xbmcgui.Window(10000).setProperty(name, value or '')
    except Exception:
        pass


def downloadfirst_on():
    """
    Kodi podešavanje "Auto-download first subtitle" kako ga je korisnik
    postavio - i dok ga addon drži privremeno ugašenim. None kada se ne
    može pročitati.
    """
    value = get_kodi_setting('subtitles.downloadfirst')
    if value is False:
        try:
            ts = xbmcgui.Window(10000).getProperty(BLOCK_KODI_AUTO_PROP)
            if ts and time.time() - float(ts) < BLOCK_KODI_AUTO_DELAY / 1000.0 + 10:
                return True
        except Exception:
            pass
    return value


def _block_mark():
    try:
        return xbmcgui.Window(10000).getProperty(BLOCK_KODI_AUTO_PROP)
    except Exception:
        return ''


def _clear_block_mark(mark):
    """Briše oznaku blokade samo ako je i dalje naša."""
    if _block_mark() == mark:
        _set_home_prop(BLOCK_KODI_AUTO_PROP, '')


def restore_downloadfirst_after_block(mark):
    """
    Vraća subtitles.downloadfirst posle pauze. Ako je drugi proces addona
    u međuvremenu upisao svoju oznaku, vraćanje prepušta njemu; ako je
    oznaku upisao tokom samog vraćanja, podešavanje se ponovo gasi.
    """
    current = _block_mark()
    if current not in (mark, ''):
        log("search: another search took over the Kodi auto-download block")
        return
    if not set_kodi_setting('subtitles.downloadfirst', True):
        log_fatal("search: could not restore subtitles.downloadfirst - "
                  "re-enable it in Kodi settings")
        return
    current = _block_mark()
    if current not in (mark, ''):
        set_kodi_setting('subtitles.downloadfirst', False)
        log("search: another search took over the Kodi auto-download block")
        return
    _clear_block_mark(mark)
    log("search: subtitles.downloadfirst restored")


def restore_stale_downloadfirst():
    """
    Vraća subtitles.downloadfirst koje je prekinuto pokretanje ostavilo
    ugašenim. Sveža oznaka pripada pretrazi u toku i ne dira se.
    """
    try:
        ts = xbmcgui.Window(10000).getProperty(BLOCK_KODI_AUTO_PROP)
        if not ts or time.time() - float(ts) < BLOCK_KODI_AUTO_DELAY / 1000.0 + 10:
            return
    except Exception:
        return
    if set_kodi_setting('subtitles.downloadfirst', True):
        log("search: subtitles.downloadfirst restored after interrupted run")
    _set_home_prop(BLOCK_KODI_AUTO_PROP, '')


# ============================================================
#  PLAYBACK CACHE
#  Podaci koji zavise samo od videa (metapodaci, hash i naziv izdanja
#  streama, hash pogoci, auto-učitan titl) čuvaju se u Home prozoru i
#  važe dok traje ista reprodukcija (playback_key). Neuspelo
#  razrešavanje metapodataka važi kraće.
# ============================================================

PB_CACHE_PROP       = 'exyusubs.pbcache'
PB_CACHE_MAX_AGE    = 12 * 3600
PB_INFO_NEG_MAX_AGE = 10 * 60


def playback_key(current_file):
    """
    Identitet reprodukcije: putanja videa uz naslov, sezonu i epizodu iz
    plejera, jer isti URL (lokalni proxy) može puštati različite videe.
    """
    if not current_file:
        return ''
    parts = [current_file]
    for lbl in ('VideoPlayer.TVShowTitle', 'VideoPlayer.Title',
                'VideoPlayer.Season', 'VideoPlayer.Episode'):
        try:
            parts.append(xbmc.getInfoLabel(lbl) or '')
        except Exception:
            parts.append('')
    return '|'.join(parts)


def same_playback_key(a, b):
    """
    Da li dva identiteta reprodukcije označavaju isti video. Putanja mora
    da bude ista; oznake plejera se porede samo kada su obe popunjene.
    """
    if not a or not b or not isinstance(a, str) or not isinstance(b, str):
        return False
    pa, pb = a.rsplit('|', 4), b.rsplit('|', 4)
    if len(pa) != 5 or len(pb) != 5 or pa[0] != pb[0]:
        return a == b
    return all(x == y or not x or not y for x, y in zip(pa[1:], pb[1:]))


def playback_unchanged(expected_key):
    """Da li se i dalje pušta video sa identitetom expected_key."""
    try:
        now = playback_key(xbmc.Player().getPlayingFile())
    except Exception:
        return False
    return same_playback_key(now, expected_key)


def playback_cache_load(current_file, key=''):
    key = key or playback_key(current_file)
    if not key:
        return {}
    try:
        raw = xbmcgui.Window(10000).getProperty(PB_CACHE_PROP)
        data = json.loads(raw) if raw else {}
        if (data.get('file') == key
                and time.time() - float(data.get('ts', 0)) < PB_CACHE_MAX_AGE):
            return data
    except Exception:
        pass
    return {}


def playback_info_valid(pb_cache):
    """
    Da li keširani metapodaci važe: sa IMDB ID-om cele reprodukcije, bez
    njega PB_INFO_NEG_MAX_AGE.
    """
    info = pb_cache.get('info')
    if not isinstance(info, dict) or 'title' not in info:
        return False
    if info.get('imdb_id'):
        return True
    try:
        return time.time() - float(pb_cache.get('info_ts', 0)) < PB_INFO_NEG_MAX_AGE
    except (TypeError, ValueError):
        return False


# Upis keša reprodukcije je čitanje-izmena-upis; hash nit piše paralelno
_pb_lock = threading.Lock()


def playback_cache_save(current_file, key='', **fields):
    """
    Upisuje polja u keš reprodukcije. key je identitet reprodukcije za koju
    su podaci dobijeni (sa početka pretrage); bez njega se uzima tekući.
    """
    key = key or playback_key(current_file)
    if not key:
        return
    try:
        with _pb_lock:
            data = playback_cache_load(current_file, key)
            data.update(fields)
            data['file'] = key
            data['ts']   = time.time()
            xbmcgui.Window(10000).setProperty(PB_CACHE_PROP, json.dumps(data))
    except Exception as e:
        log(f"playback cache: save failed ({e})")


def playing_is_tv():
    """
    Da li Kodi pušteni video tretira kao TV sadržaj - isključivo po tipu
    sadržaja (tvshow/episode), kao GUIDialogSubtitles pri izboru servisa.
    """
    try:
        media_type = xbmc.Player().getVideoInfoTag().getMediaType()
    except Exception:
        media_type = ''
    return str(media_type or '').lower() in ('episode', 'tvshow')


def autodownload_enabled():
    """Da li se titl učitava automatski, prema AUTODOWNLOAD_MODE."""
    mode = (AUTODOWNLOAD_MODE or 'kodi_if_default').strip().lower()

    if mode == 'always':
        log("autodownload: mode=always")
        return True
    if mode == 'never':
        log("autodownload: mode=never")
        return False

    value = downloadfirst_on()
    if mode == 'kodi':
        log(f"autodownload: mode=kodi, subtitles.downloadfirst={value}")
        return bool(value)

    # kodi_if_default
    if not value:
        log(f"autodownload: mode=kodi_if_default, subtitles.downloadfirst={value}")
        return False

    setting_id = 'subtitles.tv' if playing_is_tv() else 'subtitles.movie'
    default_service = get_kodi_setting(setting_id)
    if default_service is None:
        # Podešavanje se ne može pročitati - auto se ne pokreće
        log(f"autodownload: cannot read {setting_id}, treating as disabled")
        return False

    is_default = str(default_service) == ADDON_ID
    log(f"autodownload: mode=kodi_if_default, {setting_id}='{default_service}' "
        f"-> {'this addon is default' if is_default else 'not default, list only'}")
    return is_default


def auto_already_done(current_file):
    """
    Da li je auto-učitavanje već obavljeno za reprodukciju u toku:
      - isti identitet reprodukcije (playback_key)
      - oznaka nije starija od AUTO_DONE_MAX_AGE
      - plejer ima bar onoliko titl traka koliko u trenutku primene
    Poslednji uslov razlikuje ponovno puštanje istog videa.
    """
    key = playback_key(current_file)
    if not key:
        return False
    try:
        home = xbmcgui.Window(10000)
        if home.getProperty(AUTO_DONE_PROP) != key:
            return False

        ts = home.getProperty(AUTO_DONE_TS_PROP)
        if not ts or (time.time() - float(ts)) > AUTO_DONE_MAX_AGE:
            log("autodownload: previous mark expired")
            return False

        current = subtitle_track_count()
        if current == 0:
            log("autodownload: no subtitle track left, treating as new playback")
            return False

        # Oznaka bez broja traka tretira se kao jedna traka
        try:
            marked = int(home.getProperty(AUTO_DONE_CNT_PROP) or 1)
        except (TypeError, ValueError):
            marked = 1

        if current > 0 and marked > 0 and current < marked:
            log(f"autodownload: subtitle tracks {current} < {marked} at apply time, "
                f"treating as new playback")
            return False

        return True
    except Exception:
        return False


def mark_auto_done(current_file, track_count=0, key=''):
    try:
        home = xbmcgui.Window(10000)
        home.setProperty(AUTO_DONE_PROP, key or playback_key(current_file))
        home.setProperty(AUTO_DONE_TS_PROP, str(time.time()))
        home.setProperty(AUTO_DONE_CNT_PROP, str(max(0, int(track_count or 0))))
    except Exception:
        pass


def ensure_subtitles_visible():
    """
    Pali prikaz titlova i proverava rezultat, uz jedan ponovni pokušaj.
    Dodata titl traka ne uključuje sama prikaz titlova.
    """
    for attempt in range(2):
        try:
            xbmc.Player().showSubtitles(True)
        except Exception as e:
            log(f"autodownload: showSubtitles failed ({e})")
            return False

        try:
            if xbmc.getCondVisibility('VideoPlayer.SubtitlesEnabled'):
                return True
        except Exception:
            # Uslov se ne može očitati - komanda se smatra izvršenom
            return True

        if attempt == 0:
            xbmc.sleep(AUTO_TRACK_STEP)

    log("autodownload: subtitles still reported as disabled")
    return False


def select_last_subtitle_track():
    """Bira poslednju titl traku (tek dodati spoljni titl) ako nije izabrana."""
    try:
        count = subtitle_track_count()
        if count <= 0:
            return
        players = _jsonrpc('Player.GetActivePlayers', {}) or []
        pid = next((p.get('playerid') for p in players
                    if isinstance(p, dict) and p.get('type') == 'video'), None)
        if pid is None:
            return
        props = _dict(_jsonrpc('Player.GetProperties',
                               {'playerid': pid, 'properties': ['currentsubtitle']}))
        current = _dict(props.get('currentsubtitle')).get('index')
        if current == count - 1:
            return
        _jsonrpc('Player.SetSubtitle', {'playerid': pid, 'subtitle': count - 1,
                                        'enable': True})
        log(f"download: subtitle track {count - 1} selected (was {current})")
    except Exception as e:
        log(f"download: track selection skipped ({e})")


def bg_set_status(status, current_file='', key=None, only_if_owner=False):
    """
    Status pozadinske pretrage za pozivaoca. Upisuje se pre putanje, da
    pozivalac nikad ne vidi novu putanju uz stari status. Sa
    only_if_owner=True status se ne upisuje ako je u međuvremenu krenula
    pretraga za drugu reprodukciju (key).
    """
    if key is None:
        key = playback_key(current_file)
    try:
        home = xbmcgui.Window(10000)
        if only_if_owner:
            owner = home.getProperty(BG_KEY_PROP)
            if owner and owner != key:
                log(f"background: newer search owns the status, '{status}' not written")
                return
        home.setProperty(BG_TS_PROP, str(time.time()))
        home.setProperty(BG_STATUS_PROP, status)
        home.setProperty(BG_KEY_PROP, key)
        home.setProperty(BG_FILE_PROP, current_file or '')
        log(f"background: status={status}")
    except Exception as e:
        log_error(f"background: cannot set status: {e}")


def bg_running(current_file):
    """
    Da li pozadinska pretraga za ovu reprodukciju upravo radi (poredi se
    identitet reprodukcije, ne sama putanja).
    """
    if not current_file:
        return False
    try:
        home = xbmcgui.Window(10000)
        if home.getProperty(BG_STATUS_PROP) != 'running':
            return False
        if not same_playback_key(home.getProperty(BG_KEY_PROP),
                                 playback_key(current_file)):
            return False
        ts = home.getProperty(BG_TS_PROP)
        return bool(ts) and (time.time() - float(ts)) <= BG_RUNNING_MAX_AGE
    except Exception:
        return False


_lock_token = ''


def _auto_lock_read():
    try:
        raw = xbmcgui.Window(10000).getProperty(AUTO_LOCK_PROP)
        data = json.loads(raw) if raw else {}
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def auto_lock_acquire(current_file, wait=0):
    """
    Uzima bravu auto-učitavanja za ovu reprodukciju. Sa wait > 0 čeka
    najviše toliko sekundi da je drugi proces oslobodi. Vraća True kada je
    brava uzeta.
    """
    global _lock_token
    key = playback_key(current_file)
    if not key:
        return False
    token = os.urandom(8).hex()
    end = time.time() + wait
    monitor = xbmc.Monitor()
    while True:
        cur = _auto_lock_read()
        try:
            stale = time.time() - float(cur.get('ts', 0)) > AUTO_LOCK_MAX_AGE
        except (TypeError, ValueError):
            stale = True
        if not cur or stale or not same_playback_key(cur.get('key', ''), key):
            _set_home_prop(AUTO_LOCK_PROP, json.dumps(
                {'token': token, 'key': key, 'ts': time.time()}))
            # Dva procesa mogu istovremeno da zateknu slobodnu bravu - posle
            # kratke pauze važi poslednji upis
            xbmc.sleep(AUTO_LOCK_SETTLE)
            if _auto_lock_read().get('token') == token:
                _lock_token = token
                return True
        if time.time() >= end or monitor.abortRequested():
            return False
        monitor.waitForAbort(0.25)


def auto_lock_release():
    """Oslobađa bravu ako je naša; bezbedno i kada nije uzeta."""
    global _lock_token
    if _lock_token and _auto_lock_read().get('token') == _lock_token:
        _set_home_prop(AUTO_LOCK_PROP, '')
    _lock_token = ''


# Kodovi jezika (ISO 639-1/2, iz audio traka i jezika interfejsa) u
# engleske nazive koje addon koristi; ostale jezike prevodi Kodi
LANG_CODE_NAMES = {
    'sr': 'Serbian', 'srp': 'Serbian', 'scc': 'Serbian',
    'cnr': 'Montenegrin', 'mne': 'Montenegrin',
    'hr': 'Croatian', 'hrv': 'Croatian', 'scr': 'Croatian',
    'bs': 'Bosnian', 'bos': 'Bosnian',
    'sl': 'Slovenian', 'slv': 'Slovenian',
    'mk': 'Macedonian', 'mkd': 'Macedonian', 'mac': 'Macedonian',
    'en': 'English', 'eng': 'English',
}


def kodi_preferred_language(pref):
    """
    Preferirani jezik u obliku u kom ga Kodi šalje iz dijaloga: 'original'
    postaje jezik tekuće audio trake, a 'default' jezik Kodi interfejsa.
    Nepoznat jezik daje prazan string.
    """
    val = str(pref or '').strip()
    low = val.lower()
    code = ''
    if low == 'original':
        players = _jsonrpc('Player.GetActivePlayers', {}) or []
        pid = next((p.get('playerid') for p in players
                    if isinstance(p, dict) and p.get('type') == 'video'), None)
        if pid is not None:
            props = _dict(_jsonrpc('Player.GetProperties',
                                   {'playerid': pid, 'properties': ['currentaudiostream']}))
            code = str(_dict(props.get('currentaudiostream')).get('language') or '')
    elif low == 'default':
        gui = str(get_kodi_setting('locale.language') or '')   # resource.language.sr_rs
        code = gui.rsplit('.', 1)[-1].split('_', 1)[0].split('@', 1)[0]
    else:
        return val
    code = code.strip().lower()
    name = LANG_CODE_NAMES.get(code, '')
    if not name and code:
        try:
            name = str(xbmc.convertLanguage(code, xbmc.ENGLISH_NAME) or '')
        except Exception:
            name = ''
    log(f"search: preferred language '{val}' -> '{name or '(unknown)'}'")
    return name


def kodi_subtitle_languages():
    """
    Jezici titlova i preferirani jezik iz Kodi podešavanja, u obliku u kom
    ih Kodi šalje kroz dijalog (engleski nazivi).
    """
    langs = get_kodi_setting('subtitles.languages')
    if isinstance(langs, (list, tuple)):
        langs = ','.join(str(l) for l in langs if l)
    pref = kodi_preferred_language(get_kodi_setting('locale.subtitlelanguage'))
    return str(langs or ''), str(pref or '')


def player_is_playing():
    """Da li se video pušta."""
    try:
        return bool(xbmc.Player().isPlaying())
    except Exception:
        return False


def active_subtitle_info():
    """
    Titl uključen u plejeru: dict (language, name, index), ili None. Forced
    traka se ne računa; stanje koje se ne može očitati daje None.
    """
    try:
        req = {"jsonrpc": "2.0", "id": 1, "method": "Player.GetActivePlayers"}
        resp = json.loads(xbmc.executeJSONRPC(json.dumps(req)))
        player_id = next((p.get('playerid') for p in (resp.get('result') or [])
                          if p.get('type') == 'video'), None)
        if player_id is None:
            return None

        req = {"jsonrpc": "2.0", "id": 2, "method": "Player.GetProperties",
               "params": {"playerid": player_id,
                          "properties": ["subtitleenabled", "currentsubtitle"]}}
        resp = json.loads(xbmc.executeJSONRPC(json.dumps(req)))
        if 'error' in resp:
            log_error(f"active_subtitle_info: {resp['error']}")
            return None
        result = resp.get('result') or {}
        if not result.get('subtitleenabled'):
            return None

        cur = result.get('currentsubtitle') or {}
        # Prazan objekat: titl je uključen, ali traka ne postoji
        if not cur or not (cur.get('language') or cur.get('name')
                           or 'index' in cur):
            return None
        if cur.get('isforced'):
            log(f"autodownload: active subtitle is forced "
                f"({cur.get('language') or cur.get('name') or '?'}), ignored")
            return None
        return {'language': cur.get('language') or '',
                'name': cur.get('name') or '',
                'index': cur.get('index')}
    except Exception as e:
        log_error(f"active_subtitle_info: {e}")
        return None


def subtitle_track_count():
    """
    Broj titl traka u plejeru (isti izvor kao Kodijev GetSubtitleCount),
    ili -1 kada se ne može očitati.
    """
    try:
        return len(xbmc.Player().getAvailableSubtitleStreams() or [])
    except Exception:
        return -1


def wait_for_subtitle_track(before=0, timeout=AUTO_TRACK_WAIT, step=AUTO_TRACK_STEP,
                            tag='autodownload'):
    """
    Čeka da broj titl traka preraste 'before' (broj pre setSubtitles).
    Vraća True kada je traka registrovana, False posle isteka vremena.
    """
    before = max(0, int(before or 0))
    waited = 0
    while waited < timeout:
        count = subtitle_track_count()
        if count > before:
            log(f"{tag}: subtitle track registered after {waited} ms")
            return True
        if count < 0:
            # Broj se ne može očitati - bez daljeg čekanja
            xbmc.sleep(step)
            return False
        xbmc.sleep(step)
        waited += step

    if tag == 'download':
        # Isti titl izabran ponovo: Kodi prepisuje svoju kopiju i zadržava
        # postojeću traku
        log("download: no new track, Kodi reused its existing copy")
    else:
        log("autodownload: subtitle track not registered in time, "
            "Kodi may still run its own auto-download")
    return False


# Polja hash pogotka koja se čuvaju u kešu reprodukcije - dovoljna za stavku liste
HASH_SUB_FIELDS = (
    'IDSubtitle', 'IDSubtitleFile', 'SubLanguageID', 'SubFileName',
    'SubDownloadLink', 'ZipDownloadLink', 'SubEncoding', 'MovieReleaseName',
    'MovieFPS', 'SubRating', 'SubHearingImpaired', 'SubFromTrusted', 'UserRank',
    'SubAutoTranslation', 'SubForeignPartsOnly', 'SubFeatured',
    'SubDownloadsCnt', 'SubAuthorComment', 'SubBad', 'MatchedBy',
)


def hash_sub_record(sub):
    """Hash pogodak sveden na polja iz HASH_SUB_FIELDS, kao stringove."""
    rec = {k: str(sub.get(k) if sub.get(k) is not None else '') for k in HASH_SUB_FIELDS}
    rec['SubAuthorComment'] = rec['SubAuthorComment'][:300]
    rec['MatchedBy'] = 'moviehash'
    return rec


def xmlrpc_hash_lookup(video_hash, video_size, lang_codes):
    """
    Titlovi koje OpenSubtitles vezuje za ovaj video fajl (MatchedBy=
    'moviehash'): {IDSubtitle: zapis}, ili None kada upit nije uspeo (prazan
    rezultat je odgovor i kešira se).
    """
    if not video_hash or not video_size or remaining_time(TIMEOUT_XMLRPC) <= 0:
        return None

    matched = {}
    try:
        server, token = xmlrpc_connect(TIMEOUT_XMLRPC)
        if not token:
            log_error("hash lookup: XML-RPC login failed")
            return None
        params = {'sublanguageid': ','.join(lang_codes),
                  'moviehash': video_hash, 'moviebytesize': str(video_size)}
        data, token = xmlrpc_search(server, token, params)
        if data is None:
            return None
        for sub in data:
            if sub.get('MatchedBy') == 'moviehash' and sub.get('IDSubtitle'):
                matched[str(sub.get('IDSubtitle'))] = hash_sub_record(sub)
        log(f"hash lookup: {len(matched)} subtitle(s) matched by moviehash")
    except Exception as e:
        log_error(f"hash lookup: {e}")
        return None
    return matched


def refresh_sync_from_probe(candidates, probe, video_fps, matched=None):
    """
    Osvežava sync nivo kandidata podacima iz stream probe - naziv izdanja
    iz zaglavlja servera i hash pogoci (matched) - pre rangiranja i upisa
    liste. Vraća hash pogotke ili None.
    """
    if not probe:
        return None

    video_name = probe.get('filename') or ''
    if video_name and candidates:
        upgraded = 0
        probe_src = detect_source_family(
            os.path.basename(video_name).lower().replace('_', '.').replace(' ', '.'))
        for c in candidates:
            if c.get('sync_tier', SYNC_TIER_NONE) <= SYNC_TIER_GROUP:
                continue
            tier = is_release_match(c.get('match_texts') or [], video_name,
                                    c.get('sub_fps'), video_fps)
            if tier < c.get('sync_tier', SYNC_TIER_NONE):
                c['sync_tier'] = tier
                c['sync_flag'] = sync_icon(tier)
                upgraded += 1
            # Naziv fajla sa streama ima prednost i za proveru izvora, kada navodi izvor
            if probe_src:
                c['src_conflict'] = (c['sync_tier'] > SYNC_TIER_GROUP and
                                     source_conflict(c.get('match_texts') or [], video_name))
        log(f"sync: release name from stream -> {upgraded} candidate(s) upgraded")

    if matched is not None and probe.get('hash') and candidates:
        apply_hash_matches(candidates, matched)
    return matched


def cached_hash_matches(pb_cache, lang_codes):
    """
    Hash pogoci iz keša reprodukcije: {IDSubtitle: zapis}, a zapis je None
    kada je sačuvan samo ID. None kada upita još nije bilo ili je rađen za
    uži skup jezika od lang_codes.
    """
    ids = pb_cache.get('hash_matched')
    if not isinstance(ids, list):
        return None
    queried = pb_cache.get('hash_langs')
    if not isinstance(queried, list) or set(lang_codes) - set(queried):
        return None
    matched = {str(i): None for i in ids}
    for rec in pb_cache.get('hash_subs') or []:
        if isinstance(rec, dict) and rec.get('IDSubtitle'):
            matched[str(rec['IDSubtitle'])] = rec
    return matched


def save_hash_matches(current_file, matched, lang_codes, key=''):
    """Čuva hash pogotke u kešu reprodukcije (ID-evi, zapisi i jezici upita)."""
    matched = matched or {}
    playback_cache_save(current_file, key, hash_matched=sorted(matched),
                        hash_subs=[r for r in matched.values() if r],
                        hash_langs=sorted(lang_codes))


def add_hash_candidates(candidates, matched, active_langs, scope_codes, video_fps=None):
    """
    Dodaje u listu hash pogotke kojih nema među rezultatima pretrage
    (Stremio ne vraća sve titlove). Samo jezici iz scope_codes i titlovi
    koji nisu označeni kao loši. Vraća broj dodatih.
    """
    if not matched:
        return 0
    listed = {c.get('sub_id') for c in candidates}
    added = 0

    # Mesto u listi: engleska rezerva (engleski van izabranih jezika) je
    # iza svih izabranih jezika
    en_selected = any(l['lang_code'] == 'en' for l in active_langs)

    def rank(c):
        if c.get('lang_code') == 'en' and not en_selected:
            return len(active_langs)
        return c.get('lang_index', 99)

    for sub_id, rec in matched.items():
        if not rec or sub_id in listed:
            continue
        lang = rec.get('SubLanguageID', '')
        if lang not in scope_codes or str(rec.get('SubBad') or '0') != '0':
            continue
        idx = next((i for i, l in enumerate(active_langs) if lang in l['rest']), None)
        if idx is not None:
            entry = active_langs[idx]
        elif lang in ENGLISH_LANGUAGE['rest']:
            entry, idx = ENGLISH_LANGUAGE, 0     # engleska rezerva
        else:
            continue
        try:
            cand = xmlrpc_candidate(rec, entry, idx, '', video_fps)
        except Exception as e:
            log_error(f"hash lookup: candidate skipped: {e}")
            continue
        if not cand.get('url'):
            continue
        # Na početak bloka svog jezika, da lista ostane grupisana po jeziku
        pos = next((i for i, c in enumerate(candidates) if c.get('label') == entry['label']),
                   next((i for i, c in enumerate(candidates)
                         if rank(c) > rank(cand)), len(candidates)))
        candidates.insert(pos, cand)
        listed.add(sub_id)
        added += 1
    if added:
        log(f"sync: moviehash -> {added} matched subtitle(s) added to the list")
    return added


def apply_hash_matches(candidates, matched):
    """Kandidati koje OpenSubtitles vezuje za ovaj fajl dobijaju nivo hash."""
    if not matched:
        return
    hits = 0
    for c in candidates:
        if c.get('sub_id') in matched:
            c['sync_tier'] = SYNC_TIER_HASH
            c['sync_flag'] = sync_icon(SYNC_TIER_HASH)
            hits += 1
    log(f"sync: moviehash -> {hits} candidate(s) in list confirmed"
        + (f", {len(matched) - hits} matched but not listed" if len(matched) > hits else ""))


def emit_candidates(handle, candidates, front=None):
    """
    Upisuje stavke u dijalog, po jeziku, redosledom kojim su sakupljene.
    Kandidat 'front' (primenjen ili izabran titl) ide na prvo mesto.
    """
    if front is not None:
        ordered = [front] + [c for c in candidates if c is not front]
    else:
        ordered = list(candidates)

    # Ograničenje broja stavki seče listu po redosledu sakupljanja;
    # izabrani titl je prvi i ne može biti odsečen
    if MAX_RESULTS and len(ordered) > MAX_RESULTS:
        log(f"search: limiting displayed results {len(ordered)} -> {MAX_RESULTS}")
        ordered = ordered[:MAX_RESULTS]

    # ListItem se pravi samo za stavke unutar ograničenja.
    # Titlovi već preuzeti na disk prepoznaju se po imenu fajla.
    local_keys = cached_subtitle_keys()
    local_count = 0

    for c in ordered:
        path = c.get('path')
        if not path:
            continue
        label2 = c.get('label2', '')
        # Titl na disku u bilo kojoj varijanti (original ili latinična kopija)
        key = _safe_key(c.get('cache_key'))
        if key and key in local_keys:
            label2 = f"{LOCAL_TAG}{NBSP}{label2}"
            local_count += 1
        item = xbmcgui.ListItem(label=c.get('label', ''),
                                label2=label2)
        item.setArt({'icon': c.get('rating_art', '0'),
                     'thumb': c.get('lang_code', '')})
        item.setProperty('sync',         c.get('sync_flag', 'false'))
        item.setProperty('hearing_imp',  c.get('hi_flag', 'false'))
        item.setProperty('LanguageName', c.get('label', ''))
        xbmcplugin.addDirectoryItem(
            handle=handle, url=path,
            listitem=item, isFolder=False
        )

    if local_count:
        log(f"search: {local_count} subtitle(s) already on disk")
    log(f"search: displayed {len(ordered)} subtitles to user"
        + (f" (auto pick first: {(front.get('filename') or '')[:LOG_NAME_LEN]})"
           if front is not None else ""))


def close_subtitle_dialogs():
    """Zatvara dijalog pretrage titlova i OSD izbor titla iznad njega."""
    for win_id in AUTO_CLOSE_WINDOWS:
        try:
            if xbmc.getCondVisibility(f'Window.IsActive({win_id})'):
                xbmc.executebuiltin(f'Dialog.Close({win_id},true)')
                log(f"autodownload: closed dialog {win_id}")
        except Exception as e:
            log(f"autodownload: could not close dialog {win_id} ({e})")


# ============================================================
#  AUTO SUBTITLE SELECTION
#  Filtriranje i rangiranje važe samo za automatski izbor; lista u
#  dijalogu je potpuna.
#
#  Interna lista - samo jezička grupa preferiranog (inače prvog) jezika:
#    (lang_block, sync_tier, mismatch, lang_tier, cyrillic_hint, -quality)
#  Vodeći jezik i njegova ex-yu grupa su prvi blok; u bloku sinhronizacija
#  ima prednost nad jezikom. mismatch (drugi FPS ili drugi izvor, npr. CAM
#  za Blu-ray) je mek signal u okviru istog sync nivoa, a zatim odlučuju
#  jezik, pismo (latinica pre ćirilice) i kvalitet.
#
#  Kodi jezici - svi izabrani jezici, bez filtera grupa:
#    (strong_sync, mismatch, pref_block, sync_tier, pref_exact,
#     cyrillic_hint, -quality, lang_index)
#  Dokazana sinhronizacija (hash, grupa) ima prednost nad preferiranim
#  jezikom; isti provajder i procena (nivo oznaka) važe tek unutar
#  preferiranog jezika i njegove ex-yu grupe. Kodi jezici nemaju redosled, pa ga nema ni
#  rangiranje - lang_index samo razrešava potpuno izjednačene.
# ============================================================

def _rank_bonus(user_rank):
    rank = (user_rank or '').strip().lower()
    if not rank:
        return 0
    if any(k in rank for k in ('administrator', 'platinum', 'gold', 'vip')):
        return SCORE_RANK_HIGH
    if 'trusted' in rank:
        return SCORE_RANK_TRUSTED
    return 0


def quality_score(c):
    score = 0.0

    if c.get('trusted') or c.get('featured'):
        score += SCORE_TRUSTED

    score += _rank_bonus(c.get('user_rank'))

    try:
        rating = float(c.get('rating') or 0)
    except (TypeError, ValueError):
        rating = 0.0
    score += rating if rating > 0 else NEUTRAL_RATING

    # Broj preuzimanja ulazi logaritamski, da ne nadjača ostale kriterijume
    try:
        dl = int(c.get('downloads') or 0)
    except (TypeError, ValueError):
        dl = 0
    if dl > 0:
        score += math.log10(dl + 1)

    if c.get('hearing_imp'):
        score += SCORE_SDH_PENALTY
    if c.get('ai'):
        score += SCORE_AI_PENALTY

    return score


CYRILLIC_ENCODINGS = ('cp1251', 'windows-1251', 'koi8-r', 'koi8r',
                      'iso-8859-5', 'iso8859-5', 'maccyrillic')
CYRILLIC_NAME_MARKERS = ('cyr', 'cir', 'ćir', 'cirilica', 'ćirilica')


def cyrillic_hint(c):
    """
    1 kada metapodaci (deklarisani enkoding ili oznaka u nazivu) ukazuju
    na ćirilicu, inače 0. Važi samo za ex-yu titlove; titl koji se
    prevodi u latinicu dobija 0.
    """
    if c.get('to_latin') or c.get('lang_code') not in LANG_GROUPS:
        return 0
    enc = str(c.get('encoding') or '').lower().replace('_', '-')
    if enc in CYRILLIC_ENCODINGS:
        return 1
    # Tokeni zadržavaju slova sa dijakriticima
    toks = set(re.split(r'[^a-z0-9ćčđšž]+', str(c.get('filename') or '').lower()))
    return 1 if any(m in toks for m in CYRILLIC_NAME_MARKERS) else 0


def pick_auto_candidates(candidates, target_lang, active_langs, forced_only=False,
                         kodi_mode=False):
    """
    Kandidati podobni za automatski izbor, od najboljeg. Prazna lista
    znači da se izbor prepušta korisniku. Sa forced_only=True (Kodi
    'Forced only') biraju se samo forced titlovi. kodi_mode=True: jezici iz
    Kodi podešavanja, bez filtera ex-yu grupa.
    """
    if not candidates:
        return []

    target_group = LANG_GROUPS.get(target_lang or '')
    if not target_group and not kodi_mode:
        # Bez ex-yu preferiranog jezika grupu određuje prvi ex-yu jezik aktivne liste
        for entry in active_langs:
            target_group = LANG_GROUPS.get(entry.get('lang_code', ''))
            if target_group:
                break

    kept = []
    for c in candidates:
        name = (c.get('filename') or '')[:LOG_NAME_LEN]

        if not c.get('url'):
            continue

        # Forced titl prevodi samo strane dijaloge - za auto se uzima samo
        # kada je izričito preferiran, i tada jedino on
        if bool(c.get('forced')) != forced_only:
            log(f"auto: skip {'forced' if c.get('forced') else 'non-forced'} -> {name}")
            continue

        # Ex-yu jezičke grupe se ne mešaju (interna lista); engleski i
        # nepoznati jezici prolaze. Sa Kodi jezicima bira se među svim
        # izabranim jezicima.
        c_group = LANG_GROUPS.get(c.get('lang_code', ''))
        if not kodi_mode and target_group and c_group and c_group != target_group:
            log(f"auto: skip language group {c_group} -> {name}")
            continue

        kept.append(c)

    if not kept:
        log("auto: no candidate passed the filters")
        return []

    # AI prevod se odbacuje samo kada postoji ljudski prevod
    human = [c for c in kept if not c.get('ai')]
    if human and len(human) != len(kept):
        log(f"auto: dropping {len(kept) - len(human)} AI translations")
        kept = human

    # Interna lista: vodeći jezik (preferirani, inače prvi na listi) i
    # njegova ex-yu grupa čine prvi blok, u kome se srodni jezici takmiče po
    # sinhronizaciji; ostali jezici slede po redosledu liste
    lead = target_lang or (active_langs[0].get('lang_code', '') if active_langs else '')
    lead_group = LANG_GROUPS.get(lead)

    def lang_block(c):
        lang_code = c.get('lang_code', '')
        if lang_code == lead or (lead_group and LANG_GROUPS.get(lang_code) == lead_group):
            return 0
        return 1 + next((i for i, e in enumerate(active_langs)
                         if e.get('lang_code') == lang_code), len(active_langs))

    def mismatch(c, sync_tier):
        # Mek signal, jer se FPS videa menja tokom reprodukcije, izvor je
        # procena po nazivu, a FPS titla upisuje uploader. Hash pogodak i
        # ista grupa poništavaju oba.
        if sync_tier <= SYNC_TIER_GROUP:
            return 0
        return 1 if (c.get('fps_conflict') or c.get('src_conflict')) else 0

    def sort_key(c):
        lang_code = c.get('lang_code', '')
        if target_lang and lang_code == target_lang:
            lang_tier = 0
        else:
            lang_tier = 1 + int(c.get('lang_index', 9))
        sync_tier = int(c.get('sync_tier', SYNC_TIER_NONE))
        return (lang_block(c),
                sync_tier,
                mismatch(c, sync_tier),
                lang_tier,
                cyrillic_hint(c),
                -quality_score(c))

    # Kodi jezici: dokazana sinhronizacija, pa preferirani jezik
    def kodi_key(c):
        lang_code = c.get('lang_code', '')
        sync_tier = int(c.get('sync_tier', SYNC_TIER_NONE))
        # Preko preferiranog jezika mogu samo hash i grupa
        strong    = sync_tier if sync_tier <= SYNC_TIER_GROUP else SYNC_TIER_GROUP + 1
        # Preferirani jezik i njegova ex-yu grupa; bez preferiranog svi jezici su ravnopravni
        in_pref   = (not target_lang or lang_code == target_lang
                     or (target_group and LANG_GROUPS.get(lang_code) == target_group))
        return (strong,
                mismatch(c, sync_tier),
                0 if in_pref else 1,
                sync_tier,
                0 if (not target_lang or lang_code == target_lang) else 1,
                cyrillic_hint(c),
                -quality_score(c),
                int(c.get('lang_index', 9)))

    kept.sort(key=kodi_key if kodi_mode else sort_key)

    for c in kept[:3]:
        log(f"auto: candidate sync={c.get('sync_tier')} fps_ok={not c.get('fps_conflict')} "
            f"fps={c.get('sub_fps') or '?'} src_ok={not c.get('src_conflict')} "
            f"lang={c.get('lang_code')} cyr_hint={cyrillic_hint(c)} "
            f"score={quality_score(c):.2f} -> {(c.get('filename') or '')[:LOG_NAME_LEN]}")

    return kept


# ============================================================
#  XML-RPC - TOKEN AND CLIENT
# ============================================================

def get_cached_os_token():
    """Važeći token, ili prazan string."""
    try:
        home  = xbmcgui.Window(10000)
        token = home.getProperty(OS_TOKEN_PROP)
        ts    = home.getProperty(OS_TOKEN_TS_PROP)
        # Token dobijen sa drugim user-agentom nema isto pravo preuzimanja -
        # prijava se ponavlja
        if home.getProperty(OS_TOKEN_UA_PROP) != OPENSUB_USER_AGENT:
            return ''
        if token and ts and (time.time() - float(ts)) < OS_TOKEN_MAX_AGE:
            return token
    except Exception:
        pass
    return ''


def store_os_token(token):
    try:
        home = xbmcgui.Window(10000)
        home.setProperty(OS_TOKEN_PROP, token or '')
        home.setProperty(OS_TOKEN_TS_PROP, str(time.time()) if token else '')
        home.setProperty(OS_TOKEN_UA_PROP, OPENSUB_USER_AGENT if token else '')
    except Exception:
        pass


def clear_os_token():
    store_os_token('')


def _xmlrpc_login(server):
    """Anonimna prijava sa registrovanim user-agentom. Vraća token ili ''."""
    login = server.LogIn('', '', 'en', OPENSUB_USER_AGENT)
    token = (login.get('token') if isinstance(login, dict) else '') or ''
    token = token if isinstance(token, str) else ''
    if token:
        store_os_token(token)
    return token


def xmlrpc_connect(timeout):
    """
    XML-RPC klijent i token; prijava se radi samo kada keširanog tokena
    nema ili je istekao. Vraća (server, token), token je '' kada prijava
    ne uspe.

    Timeout važi za svaki poziv posebno (prijava, upit, ponovljeni upit), u
    okviru preostalog roka pretrage, bez globalnog socket timeout-a. Provera
    sertifikata je isključena, jer Python na delu Kodi platformi ne vidi
    sistemske CA sertifikate.
    """
    import xmlrpc.client
    import ssl

    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    ctx.check_hostname = False
    ctx.verify_mode    = ssl.CERT_NONE

    class _Transport(xmlrpc.client.SafeTransport):
        def make_connection(self, host):
            conn = super().make_connection(host)
            conn.timeout = max(0.5, remaining_time(timeout))
            return conn

        def request(self, host, handler, request_body, verbose=False):
            # Konekcija se ponovo koristi - timeout se osvežava pre svakog poziva
            conn = self._connection[1] if self._connection else None
            if conn is not None:
                conn.timeout = max(0.5, remaining_time(timeout))
                if getattr(conn, 'sock', None) is not None:
                    conn.sock.settimeout(conn.timeout)
            return super().request(host, handler, request_body, verbose)

    server = xmlrpc.client.ServerProxy(OPENSUB_XMLRPC_URL,
                                       transport=_Transport(context=ctx))

    token = get_cached_os_token()
    if token:
        log("XML-RPC: using cached token")
    else:
        token = _xmlrpc_login(server)
    return server, token


def xmlrpc_search(server, token, params):
    """
    Jedan SearchSubtitles poziv, sa jednim (dict) ili više (list)
    kriterijuma. Odbijen token se obnavlja i upit ponavlja jednom.
    Vraća (rezultati, token); rezultati su None kada upit nije uspeo, a
    token je '' kada prijava ne uspe.
    """
    def status_ok(r):
        return isinstance(r, dict) and str(r.get('status', '')).startswith('200')

    params = params if isinstance(params, list) else [params]
    res = server.SearchSubtitles(token, params)
    if not status_ok(res):
        status = res.get('status', '') if isinstance(res, dict) else ''
        log(f"XML-RPC: status '{status}', re-login")
        clear_os_token()
        if remaining_time(1) <= 0:
            log("XML-RPC: deadline reached, no re-login")
            return None, token
        token = _xmlrpc_login(server)
        if not token:
            return None, ''
        res = server.SearchSubtitles(token, params)
        if not status_ok(res):
            log("XML-RPC: search failed after re-login")
            return None, token
    # 'data' je False kada nema rezultata
    data = res.get('data', [])
    return ([x for x in data if isinstance(x, dict)] if isinstance(data, list) else []), token


def merge_xmlrpc_results(subs):
    """Uklanja duplikate iz XML-RPC odgovora; redosled prvog pojavljivanja se čuva."""
    by_key, order = {}, []
    for x in subs or []:
        if not isinstance(x, dict):
            continue
        key = str(x.get('IDSubtitleFile') or x.get('IDSubtitle') or id(x))
        if key not in by_key:
            by_key[key] = x
            order.append(key)
    return [by_key[k] for k in order]


# ============================================================
#  SINGLE SEARCH PASS FOR A GIVEN LANGUAGE LIST
#  Stremio (primarni) + XML-RPC (fallback). Vraća broj dodatih
#  titlova; 0 pokreće engleski fallback u search().
# ============================================================

def xmlrpc_candidate(sub, entry, lang_index, video_path='', video_fps=None):
    """
    Kandidat iz XML-RPC stavke (i hash pogotka), u obliku koji koriste lista
    i automatski izbor. entry je unos jezika, lang_index mesto jezika u
    listi.
    """
    lang        = sub.get('SubLanguageID', '')
    sub_url     = sub.get('SubDownloadLink', '')
    raw_name    = str(sub.get('SubFileName') or f"subtitle_{lang}.srt")
    # Flagovi stižu kao string ili int, pa se porede kroz str().
    # SDH se proverava i po nazivu fajla.
    hi_flag     = str(sub.get('SubHearingImpaired', '0')) == '1'
    is_sdh      = hi_flag or bool(SDH_PATTERN.search(raw_name.lower()))
    hearing_imp = 'true' if is_sdh else 'false'
    try:
        rating = str(int(math.floor(float(sub.get('SubRating', '0') or '0') / 2 + 0.5)))
    except Exception:
        rating = '0'
    if not sub_url:
        sub_url = sub.get('ZipDownloadLink', '')
    # Rezervni link preko Stremio-a (isti IDSubtitleFile), za slučaj VIP poruke
    alt_url = stremio_download_url(sub)

    # Naziv bez ekstenzije
    filename, _ = os.path.splitext(raw_name)

    # Trusted oznaka ima prednost nad rangom uploadera
    from_trusted = str(sub.get('SubFromTrusted', '0')) == '1'
    user_rank    = str(sub.get('UserRank', '') or '').strip()
    tags = build_tags(
        ai        = str(sub.get('SubAutoTranslation', '0')) == '1',
        forced    = str(sub.get('SubForeignPartsOnly', '0')) == '1',
        featured  = str(sub.get('SubFeatured', '0')) == '1',
        trusted   = from_trusted,
        user_rank = user_rank,
        downloads = sub.get('SubDownloadsCnt', '0'),
    )
    label2 = f"{filename}{NBSP} {tags}" if tags else filename

    # moviehash pogodak je dokaz sinhronizacije; bez njega se porede nazivi izdanja
    sync_tier = SYNC_TIER_NONE
    if DETECT_SYNC:
        if sub.get('MatchedBy') == 'moviehash':
            sync_tier = SYNC_TIER_HASH
        elif video_path:
            sync_tier = is_release_match(
                [sub.get('MovieReleaseName', ''),
                 raw_name,
                 sub.get('SubAuthorComment', '')],
                video_path,
                sub.get('MovieFPS'), video_fps)
    sync_flag = sync_icon(sync_tier)

    params_dl = {
        'action':   'download',
        'url':      sub_url,
        'alt_url':  alt_url,
        'filename': filename,
        'encoding': sub.get('SubEncoding', ''),
        'lang_code': entry['lang_code'],
        'source':   'xmlrpc',
        'cache_key': f"os{sub.get('IDSubtitle')}" if sub.get('IDSubtitle') else '',
    }
    path = f"{sys.argv[0]}?{urllib.parse.urlencode(params_dl)}"

    return {
        'sub_id':       str(sub.get('IDSubtitle', '')),
        'match_texts':  [sub.get('MovieReleaseName', ''), raw_name,
                         sub.get('SubAuthorComment', '')],
        'sub_fps':      sub.get('MovieFPS'),
        'label':        entry['label'],
        'label2':       label2,
        'rating_art':   rating,
        'sync_flag':    sync_flag,
        'hi_flag':      hearing_imp,
        'path':         path,
        'url':          sub_url,
        'alt_url':      alt_url,
        'cache_key':    f"os{sub.get('IDSubtitle')}" if sub.get('IDSubtitle') else '',
        'filename':     filename,
        'encoding':     sub.get('SubEncoding', ''),
        'lang_code':    entry['lang_code'],
        'lang_index':   lang_index,
        'sync_tier':    sync_tier,
        'fps_conflict': fps_conflict(sub.get('MovieFPS'), video_fps),
        'src_conflict': sync_tier > SYNC_TIER_GROUP and source_conflict(
            [sub.get('MovieReleaseName', ''), raw_name, sub.get('SubAuthorComment', '')],
            video_path),
        'forced':       str(sub.get('SubForeignPartsOnly', '0')) == '1',
        'ai':           str(sub.get('SubAutoTranslation', '0')) == '1',
        'featured':     str(sub.get('SubFeatured', '0')) == '1',
        'trusted':      from_trusted,
        'user_rank':    user_rank,
        'hearing_imp':  is_sdh,
        'rating':       rating,
        'downloads':    sub.get('SubDownloadsCnt', '0'),
    }


def start_rest_thread(cache, imdb_id, season, episode, code):
    """
    REST upit za jedan jezik u pozadinskoj niti, jednom po naslovu, epizodi
    i jeziku u kešu pretrage. Vraća (nit, držač); rezultat je u držač['data'].
    """
    thread_key = f"rest:{imdb_id}:{season}:{episode}:{code}:thread"
    if thread_key in cache:
        return cache[thread_key]
    holder = {}

    def _fetch_rest():
        try:
            holder['data'] = get_detailed_subtitle_names(
                imdb_id, season=season, episode=episode, rest_code=code)
        except Exception as e:
            log_error(f"search: REST thread error: {e}")
            holder['data'] = {}

    cache[thread_key] = (start_thread(_fetch_rest), holder)
    return cache[thread_key]


def rest_details(cache, imdb_id, season, episode, codes):
    """
    REST podaci za jezike codes - paralelni upiti, po jedan za jezik. Čeka
    se najviše TIMEOUT_REST; odgovor koji stigne kasnije čuva se za sledeće
    otvaranje. Vraća spojen {IDSubtitle: {...}}.
    """
    started = [start_rest_thread(cache, imdb_id, season, episode, c) for c in codes]
    end = time.time() + max(0.1, remaining_time(TIMEOUT_REST))
    merged = {}
    for thread, holder in started:
        thread.join(max(0.0, end - time.time()))
        merged.update(holder.get('data') or {})
    return merged


# Oznake u kešu pretrage: Stremio nije odgovorio (po URL-u) i bar jedan
# izvor je odgovorio (prazan rezultat tada znači da titlova nema)
STREMIO_FAILED_KEY = 'stremio_failed:'
ANSWERED_KEY       = 'answered'


def _run_search(imdb_id, season, episode, is_series, active_langs,
                video_path='', video_fps=None, cache=None, title_query='',
                auto_candidates=None, english_query=False, pref_group=None):
    displayed = 0
    # Kandidati nose podatke za rangiranje i polja prikaza; stavke se upisuju
    # u dijalog tek kada je redosled poznat.
    if auto_candidates is None:
        auto_candidates = []
    # Keš deljen između prolaza (ex-yu i engleski) - odgovori ne zavise od
    # jezika, koji se filtrira lokalno
    if cache is None:
        cache = {}

    # Filteri i mape iz prosleđene liste jezika
    stremio_codes = [c for l in active_langs for c in l['stremio']]
    stremio_map   = {c: l for l in active_langs for c in l['stremio']}
    rest_codes    = [c for l in active_langs for c in l['rest']]

    # Stremio radi samo po IMDB ID-u i konkretnoj epizodi; pretraga po
    # naslovu i pretraga cele sezone idu na XML-RPC
    stremio_url = None
    if not imdb_id:
        log(f"search: no IMDB ID, title search for '{title_query}'")
    elif is_series and episode is None:
        log(f"search: season-only search (S{season}), Stremio skipped")
    else:
        if is_series:
            query_id = f"{imdb_id}:{season}:{episode}"
        else:
            query_id = imdb_id
        stremio_url = f"{STREMIO_BASE_URL}/{'series' if is_series else 'movie'}/{query_id}.json"
        log(f"search: Stremio URL: {stremio_url}")

    # ----------------------------------------------------------
    # Stremio - primarni izvor, sa RETRY_COUNT ponovnih pokušaja
    # ----------------------------------------------------------
    stremio_ok = False
    subtitles  = None

    if not stremio_url:
        pass                      # nema IMDB ID-a ili epizode - pretraga ide na XML-RPC
    elif stremio_url in cache:
        subtitles = cache[stremio_url]
        log(f"search: Stremio response served from cache ({len(subtitles)} items)")
    elif cache.get(STREMIO_FAILED_KEY + stremio_url):
        log("search: Stremio failed earlier in this search, skipping")
    else:
        response = None
        for attempt in range(1, RETRY_COUNT + 2):  # prvi pokušaj + RETRY_COUNT ponovnih
            if remaining_time(TIMEOUT_STREMIO) <= 0:
                log("search: deadline reached, stopping Stremio attempts")
                break
            try:
                log("search: Stremio request" if attempt == 1 else
                    f"search: Stremio retry {attempt - 1} after server error")
                response = requests.get(stremio_url, headers=HEADERS, timeout=remaining_time(TIMEOUT_STREMIO))
                log(f"search: Stremio HTTP {response.status_code}")

                # Ponovni pokušaj samo za grešku servera (5xx); posle timeouta
                # sledi XML-RPC
                if response.status_code < 500:
                    break

                # 5xx - pauza pre sledećeg pokušaja, ne duže od roka
                log(f"search: Stremio server error {response.status_code}, retrying...")
                if attempt <= RETRY_COUNT:
                    time.sleep(min(RETRY_DELAY, remaining_time(RETRY_DELAY)))

            except requests.exceptions.Timeout:
                log(f"search: Stremio timeout on attempt {attempt}, switching to fallback")
                break

            except Exception as e:
                log_error(f"search: Stremio error on attempt {attempt}: {e}")
                break  # neočekivana greška - bez ponavljanja

        if response is not None and response.ok:
            try:
                data = response.json()
                subtitles = data.get('subtitles') if isinstance(data, dict) else None
                subtitles = [x for x in subtitles if isinstance(x, dict)] \
                    if isinstance(subtitles, list) else []
                cache[stremio_url] = subtitles
                cache[ANSWERED_KEY] = True
            except Exception as e:
                log_error(f"search: Stremio JSON parse error: {e}")
        # Neuspeh se pamti do kraja pretrage - engleski prolaz ga ne ponavlja
        if stremio_url not in cache:
            cache[STREMIO_FAILED_KEY + stremio_url] = True

    if subtitles is not None:
        try:
            filtered = [s for s in subtitles if s.get('lang') in stremio_codes]
            log(f"search: Stremio total={len(subtitles)}, search languages={len(filtered)} "
                f"({lang_summary(stremio_map[x.get('lang')]['rest'][0] for x in filtered)})")

            if not filtered:
                log("search: Stremio returned no exyu subtitles, switching to XML-RPC fallback")
                # Engleska rezerva je verovatna - njen REST upit kreće odmah,
                # paralelno sa XML-RPC-om
                eng = ENGLISH_LANGUAGE
                if english_query and any(x.get('lang') in eng['stremio'] for x in subtitles):
                    start_rest_thread(cache, imdb_id, season, episode, eng['rest'][0])

            if filtered:
                # Nazivi fajlova i oznake iz REST-a - po jedan upit za svaki
                # jezik koji Stremio vraća (REST ne prima više jezika), paralelno
                present = list(dict.fromkeys(stremio_map[x.get('lang')]['rest'][0]
                                             for x in filtered))
                # Samo ostale ex-yu grupe: engleska rezerva je verovatna
                # (ENGLISH_WITH_OTHER_GROUPS), pa njen REST upit kreće odmah
                eng = ENGLISH_LANGUAGE
                if (english_query and pref_group and SHOW_OTHER_LANG_GROUPS
                        and ENGLISH_WITH_OTHER_GROUPS
                        and all(LANG_GROUPS.get(stremio_map[x.get('lang')]['lang_code'])
                                not in (None, pref_group) for x in filtered)
                        and any(x.get('lang') in eng['stremio'] for x in subtitles)):
                    start_rest_thread(cache, imdb_id, season, episode, eng['rest'][0])
                detailed_names = rest_details(cache, imdb_id, season, episode, present)
                if not detailed_names:
                    log("search: REST returned nothing, using names from Stremio")
                if detailed_names:
                    hits = sum(1 for x in filtered if str(x.get('id') or '') in detailed_names)
                    log(f"search: REST details for {hits} of {len(filtered)} subtitles")

                # Sortiranje po prioritetu jezika iz aktivne liste
                def lang_priority(sub):
                    lang  = sub.get('lang', '')
                    entry = stremio_map.get(lang)
                    if not entry:
                        return 99
                    return next((i for i, l in enumerate(active_langs)
                                 if l['lang_code'] == entry['lang_code']
                                 and l['label'] == entry['label']), 99)

                # Odbacuju se titlovi za druge epizode, po oznaci u nazivu fajla
                if is_series:
                    pre = len(filtered)
                    filtered = [
                        sub for sub in filtered
                        if episode_matches(
                            (detailed_names.get(str(sub.get('id') or ''))
                             or stremio_sub_info(sub)).get('filename', ''),
                            season, episode)
                    ]
                    if len(filtered) != pre:
                        log(f"search: episode filter {pre} -> {len(filtered)} "
                            f"(wanted S{season}E{episode})")

                # Stremio je uspešan samo ako posle filtera epizode nešto
                # ostane; inače sledi XML-RPC
                stremio_ok = bool(filtered)
                if not filtered:
                    log("search: Stremio subtitles are all for other episodes, "
                        "switching to XML-RPC fallback")

                filtered.sort(key=lang_priority)

                added_before = len(auto_candidates)
                for sub in filtered:
                    try:
                        lang        = sub.get('lang', '')
                        sub_id      = str(sub.get('id') or '')
                        sub_url     = sub.get('url', '')
                        entry       = stremio_map.get(lang, active_langs[0])
                        # Bez REST podataka naziv, izdanje i FPS se uzimaju iz
                        # Stremio odgovora
                        sub_info    = detailed_names.get(sub_id) or stremio_sub_info(sub)
                        filename    = sub_info.get('filename', f"OpenSubtitles_{sub_id}")
                        rating      = sub_info.get('rating', '0')
                        hearing_imp = 'true' if sub_info.get('hearing_imp', False) else 'false'
                        tags        = build_tags(
                            ai        = sub_info.get('ai',        False),
                            forced    = sub_info.get('forced',    False),
                            featured  = sub_info.get('featured',  False),
                            trusted   = sub_info.get('trusted',   False),
                            user_rank = sub_info.get('user_rank', ''),
                            downloads = sub_info.get('downloads', '0'),
                        )
                        label2 = f"{filename}{NBSP} {tags}" if tags else filename

                        # Sinhronizacija se procenjuje poređenjem naziva
                        # izdanja iz svih dostupnih polja
                        sync_tier = SYNC_TIER_NONE
                        if DETECT_SYNC and video_path:
                            sync_tier = is_release_match(
                                [sub_info.get('release', ''),
                                 filename,
                                 sub_info.get('comment', '')],
                                video_path,
                                sub_info.get('fps'), video_fps)
                        sync_flag = sync_icon(sync_tier)

                        params_dl = {
                            'action':    'download',
                            'url':       sub_url,
                            'filename':  filename,
                            'encoding':  sub.get('SubEncoding', ''),
                            'lang_code': entry['lang_code'],
                            'source':    'stremio',
                            'cache_key': f"os{sub_id}" if sub_id else '',
                        }
                        path = f"{sys.argv[0]}?{urllib.parse.urlencode(params_dl)}"

                        auto_candidates.append({
                            # Polja prikaza; ListItem se pravi u
                            # emit_candidates
                            'sub_id':       sub_id,
                            'match_texts':  [sub_info.get('release', ''), filename,
                                             sub_info.get('comment', '')],
                            'sub_fps':      sub_info.get('fps'),
                            'label':        entry['label'],
                            'label2':       label2,
                            'rating_art':   rating,
                            'sync_flag':    sync_flag,
                            'hi_flag':      hearing_imp,
                            'path':         path,
                            'url':          sub_url,
                            'cache_key':    f"os{sub_id}" if sub_id else '',
                            'filename':     filename,
                            'encoding':     sub.get('SubEncoding', ''),
                            'lang_code':    entry['lang_code'],
                            'lang_index':   lang_priority(sub),
                            'sync_tier':    sync_tier,
                            'fps_conflict': fps_conflict(sub_info.get('fps'), video_fps),
                            'src_conflict': sync_tier > SYNC_TIER_GROUP and source_conflict(
                                [sub_info.get('release', ''), filename,
                                 sub_info.get('comment', '')], video_path),
                            'forced':       sub_info.get('forced',   False),
                            'ai':           sub_info.get('ai',       False),
                            'featured':     sub_info.get('featured', False),
                            'trusted':      sub_info.get('trusted',  False),
                            'user_rank':    sub_info.get('user_rank', ''),
                            'hearing_imp':  sub_info.get('hearing_imp', False),
                            'rating':       rating,
                            'downloads':    sub_info.get('downloads', '0'),
                        })
                    except Exception as e:
                        # Neispravna stavka odgovora se preskače
                        log_error(f"search: Stremio item skipped: {e}")

                added = len(auto_candidates) - added_before
                log(f"search: Stremio collected {added} subtitles")
                displayed += added
                # Nijedna stavka nije upotrebljiva - sledi XML-RPC
                if not added:
                    stremio_ok = False
        except Exception as e:
            log_error(f"search: Stremio processing error: {e}")

    # XML-RPC rezerva, kada Stremio nije dao upotrebljiv rezultat za jezike pretrage. Ključ keša ne sadrži jezik.
    xmlrpc_key = f"xmlrpc:{imdb_id or title_query}:{season}:{episode}"
    subs = None

    if not stremio_ok and subs is None and cache.get('xmlrpc_failed:' + xmlrpc_key):
        log("search: XML-RPC failed earlier in this search, skipping")
        subs = []
    if not stremio_ok and xmlrpc_key in cache:
        subs = cache[xmlrpc_key]
        log(f"search: XML-RPC response served from cache ({len(subs)} items)")

    if not stremio_ok and subs is None and remaining_time(TIMEOUT_XMLRPC) <= 0:
        log("search: deadline reached, skipping XML-RPC fallback")
    elif not stremio_ok and subs is None:
        log("search: initiating XML-RPC fallback")
        try:
            server, token = xmlrpc_connect(TIMEOUT_XMLRPC)
            if not token:
                log_error("search: XML-RPC login failed, no token")
            else:
                # Jedan poziv za sve jezike, uključujući engleski kada engleski
                # prolaz može da usledi
                query_codes = list(rest_codes)
                if english_query:
                    for code in ENGLISH_LANGUAGE['rest']:
                        if code not in query_codes:
                            query_codes.append(code)

                xmlrpc_params = {'sublanguageid': ','.join(query_codes)}

                # IMDB ID, a bez njega pretraga po nazivu
                if imdb_id:
                    xmlrpc_params['imdbid'] = imdb_id.replace('tt', '')
                else:
                    xmlrpc_params['query'] = title_query

                if is_series:
                    xmlrpc_params['season'] = str(season)
                    # Bez epizode OS vraća titlove za celu sezonu
                    if episode is not None:
                        xmlrpc_params['episode'] = str(episode)

                # Upit je bez hash-a; hash pogoci se traže zasebnim upitom (nit)
                log(f"search: XML-RPC params: {xmlrpc_params}")

                subs, token = xmlrpc_search(server, token,
                                            dict(xmlrpc_params, sublanguageid=','.join(query_codes)))
                if subs is None:
                    log_error("search: XML-RPC search failed")
                else:
                    cache[ANSWERED_KEY] = True
                    subs = merge_xmlrpc_results(subs)
                    log(f"search: XML-RPC found {len(subs)} subtitles")

                    # Odgovor odsečen na granici broja rezultata: upit se
                    # ponavlja samo za jezike pretrage, a engleski rezultati
                    # prvog odgovora se zadržavaju
                    eng_added = len(query_codes) > len(rest_codes)
                    if (eng_added and token and len(subs) >= OS_RESULT_CAP
                            and remaining_time(TIMEOUT_XMLRPC) > 0):
                        log(f"search: XML-RPC hit result cap ({OS_RESULT_CAP}), "
                            f"re-querying without English")
                        exyu_subs, token = xmlrpc_search(
                            server, token, dict(xmlrpc_params, sublanguageid=','.join(rest_codes)))
                        if exyu_subs is None:
                            # Ponovljeni upit nije uspeo - važi prvi odgovor
                            log("search: XML-RPC ex-yu re-query failed, keeping first answer")
                        else:
                            eng_subs = [x for x in subs
                                        if x.get('SubLanguageID') not in rest_codes]
                            merged = merge_xmlrpc_results(exyu_subs + eng_subs)
                            log(f"search: XML-RPC merged {len(exyu_subs)} ex-yu + "
                                f"{len(eng_subs)} eng -> {len(merged)}")
                            subs = merged

                    cache[xmlrpc_key] = subs

        except Exception as e:
            log_error(f"search: XML-RPC fallback error: {e}")
        # Neuspeh se pamti do kraja pretrage kada je upit uključio i engleski
        if xmlrpc_key not in cache and english_query:
            cache['xmlrpc_failed:' + xmlrpc_key] = True

    # Obrada XML-RPC rezultata radi i za rezultate iz keša (engleski prolaz)
    if not stremio_ok and subs:
        def xmlrpc_priority(sub):
            lang = sub.get('SubLanguageID', '')
            return rest_codes.index(lang) if lang in rest_codes else 99

        subs_filtered = [s for s in subs
                         if s.get('SubLanguageID') in rest_codes
                         and str(s.get('SubBad', '0')) == '0']  # bez titlova označenih kao loši

        # Pretraga po nazivu: MovieName mora da odgovara traženom naslovu
        if not imdb_id and title_query:
            pre = len(subs_filtered)
            subs_filtered = [
                x for x in subs_filtered
                if title_matches_os(title_query, str(x.get('MovieName') or ''), is_series)
            ]
            if len(subs_filtered) != pre:
                log(f"search: title filter {pre} -> {len(subs_filtered)} "
                    f"(wanted '{title_query}')")

        # Odbacuju se titlovi za druge epizode (SeriesSeason/SeriesEpisode, a
        # bez njih naziv fajla)
        if is_series:
            pre = len(subs_filtered)
            subs_filtered = [
                x for x in subs_filtered
                if xmlrpc_episode_matches(x, season, episode)
            ]
            if len(subs_filtered) != pre:
                log(f"search: episode filter {pre} -> {len(subs_filtered)} "
                    f"(wanted S{season}E{episode})")

        subs_filtered.sort(key=xmlrpc_priority)
        log(f"search: XML-RPC total={len(subs)}, search languages={len(subs_filtered)} "
            f"({lang_summary(x.get('SubLanguageID', '?') for x in subs_filtered)})")

        added_before = len(auto_candidates)
        for sub in subs_filtered:
            try:
                # Unos iz aktivne liste jezika
                lang  = sub.get('SubLanguageID', '')
                entry = next((l for l in active_langs if lang in l['rest']),
                             active_langs[0])
                auto_candidates.append(xmlrpc_candidate(
                    sub, entry, xmlrpc_priority(sub), video_path, video_fps))
            except Exception as e:
                # Neispravna stavka odgovora se preskače
                log_error(f"search: XML-RPC item skipped: {e}")

        added = len(auto_candidates) - added_before
        log(f"search: XML-RPC collected {added} subtitles")
        displayed += added

    return displayed


# ============================================================
#  AUTO SUBTITLE LOADING
#  Preuzimanje i primena najbolje rangiranog kandidata; dijalog se
#  zatvara, osim kod pozadinske pretrage.
# ============================================================

def resolve_target_language(preferred_language):
    """
    Preferirani jezik kao lang_code, iz engleskog naziva jezika. Posebne
    vrednosti ('none', 'original', 'default', 'forced_only') i nepoznat
    jezik daju prazan string.
    """
    pref = (preferred_language or '').strip().lower()
    if not pref or pref in ('none', 'original', 'default', 'forced_only'):
        return ''
    if pref in SERBO_CROATIAN:
        return 'sr'
    entry = find_language(preferred_language)
    return entry['lang_code'] if entry else ''


def auto_apply(ordered, target_lang, close_dialogs=True, expected_key=''):
    """
    Preuzima najbolje rangiranog kandidata iz 'ordered' i primenjuje ga na
    plejer. close_dialogs=False kod pozadinske pretrage. Titl se ne
    primenjuje ako se u međuvremenu pušta drugi video (expected_key).

    Vraća primenjenog kandidata, ili None kada ništa nije primenjeno.
    """
    if not ordered:
        return None

    # Bez puštenog videa ostaje samo lista
    if not player_is_playing():
        log("autodownload: player not active, leaving the list to the user")
        return None

    try:
        current_file = xbmc.Player().getPlayingFile()
    except Exception:
        current_file = ''

    if not current_file:
        log("autodownload: no playing file, skipping")
        return None

    def same_playback():
        if not expected_key:
            return True
        try:
            now = playback_key(xbmc.Player().getPlayingFile())
        except Exception:
            now = ''
        if not same_playback_key(now, expected_key):
            log("autodownload: another video is playing now, subtitle not applied")
            return False
        return True

    if not same_playback():
        return None

    # Jednom po reprodukciji; pri sledećem otvaranju dijaloga bira korisnik
    if auto_already_done(current_file):
        log("autodownload: already done for this file, leaving list to user")
        return None

    # Pismo se vidi tek iz preuzetog teksta, posle prevođenja u latinicu
    # (to_latin), i proverava se samo za ex-yu titlove. Za preferirani
    # hr/bs/sl ćirilica iz iste jezičke grupe se preskače dok ima drugih
    # kandidata; u ostalim slučajevima samo kada je sledeći kandidat ex-yu
    # titl bez oznake ćirilice, istog sync nivoa. Za srpski, makedonski i
    # bez preferiranog jezika pismo ne menja izbor.
    reject_cyrillic = target_lang in LANG_GROUPS and target_lang not in CYRILLIC_OK_LANGS
    prefer_latin    = bool(target_lang) and target_lang not in CYRILLIC_OK_LANGS

    def apply(cand, result):
        name = (cand.get('filename') or '')[:LOG_NAME_LEN]
        # Video se mogao promeniti tokom preuzimanja
        if not same_playback():
            return None
        # Titl uključen tokom pretrage i preuzimanja se ne menja
        active = active_subtitle_info()
        if active is not None:
            log(f"autodownload: subtitle enabled meanwhile "
                f"([{active['language'] or '?'}] {active['name'][:40]}), not replaced")
            return None
        tracks_before = subtitle_track_count()
        try:
            xbmc.Player().setSubtitles(result['path'])
        except Exception as e:
            log_error(f"autodownload: setSubtitles failed: {e}")
            return None

        log(f"=== AUTO SUBTITLE APPLIED | [{cand.get('lang_code')}] {name} ===")

        # Čeka se da plejer registruje traku - do tada bi Kodi sam skinuo prvu
        # stavku liste
        wait_for_subtitle_track(tracks_before)

        # Prikaz titlova se uključuje izričito
        ensure_subtitles_visible()

        # Oznaka čuva broj traka sa primenjenim titlom, po kojem se prepoznaje
        # novo puštanje istog videa; neprijavljena traka se računa kao dodata
        tracks = subtitle_track_count()
        if tracks_before >= 0 and tracks >= 0:
            tracks = max(tracks, tracks_before + 1)
        mark_auto_done(current_file, tracks, expected_key)
        playback_cache_save(current_file, expected_key, applied_key=cand.get('cache_key', ''))

        # Zatvara se lista i OSD izbor titla iznad nje
        if close_dialogs:
            close_subtitle_dialogs()
        return cand

    # Preskočen ćirilični titl ostaje rezerva ako nijedan sledeći ne uspe
    fallback = None

    attempts = ordered[:AUTO_MAX_ATTEMPTS]
    dead_hosts = set()
    for idx, cand in enumerate(attempts):
        host = urllib.parse.urlsplit(cand.get('url') or '').netloc
        # Server koji nije odgovorio se preskače, osim za titl koji je na disku
        if (host in dead_hosts
                and _file_key(cand.get('cache_key', '')) not in cached_subtitle_keys()):
            log(f"autodownload: {host} timed out, skipping candidate {idx + 1}")
            continue
        name = (cand.get('filename') or '')[:LOG_NAME_LEN]

        # Rok pretrage važi i za preuzimanje: sledeći pokušaj kreće samo pre
        # isteka roka, a svako preuzimanje dobija bar AUTO_MIN_DOWNLOAD_TIME
        if idx > 0 and remaining_time(1) <= 0:
            log("autodownload: deadline reached, no further attempts")
            break
        dl_timeout = max(AUTO_MIN_DOWNLOAD_TIME, remaining_time(TIMEOUT_DOWNLOAD))

        log(f"autodownload: attempt {idx + 1} -> [{cand.get('lang_code')}] {name}")

        result = fetch_and_save(cand['url'], cand.get('encoding', ''),
                                cand.get('lang_code', ''), cand.get('cache_key', ''),
                                cand.get('alt_url', ''), timeout=dl_timeout,
                                to_latin=cand.get('to_latin', False))
        if result and result.get('blocked'):
            log("autodownload: downloads blocked (VIP placeholder), not trying other candidates")
            break
        if result and result.get('timeout'):
            # Server koji nije odgovorio (i kod rezervnog linka)
            dead_hosts.add(result.get('host') or host)
            continue
        if not result:
            log("autodownload: download failed, trying next candidate")
            continue

        # Pravila pisma važe samo za ex-yu titlove
        is_cyr   = (result['cyr_ratio'] > CYRILLIC_THRESHOLD
                    and cand.get('lang_code') in LANG_GROUPS)
        has_next = idx + 1 < len(attempts)
        if is_cyr and has_next:
            nxt = attempts[idx + 1]
            skip = False
            if (reject_cyrillic and LANG_GROUPS.get(cand.get('lang_code'))
                    == LANG_GROUPS.get(target_lang)):
                log(f"autodownload: cyrillic script ({result['cyr_ratio']:.2f}) "
                    f"unsuitable for '{target_lang}', trying next candidate")
                skip = True
            elif (prefer_latin and nxt.get('lang_code') in LANG_GROUPS
                    and not cyrillic_hint(nxt)
                    and nxt.get('sync_tier') == cand.get('sync_tier')):
                log(f"autodownload: cyrillic script ({result['cyr_ratio']:.2f}), "
                    f"latin candidate with same sync level available - trying it")
                skip = True
            if skip:
                if fallback is None:
                    fallback = (cand, result)
                continue

        # I ovaj kandidat je ćiriličan - primenjuje se bolje rangiran
        # preskočeni titl
        if is_cyr and fallback is not None:
            log("autodownload: cyrillic again, applying the best-ranked skipped candidate")
            return apply(*fallback)

        return apply(cand, result)

    if fallback is not None:
        log("autodownload: no other candidate applied, using skipped cyrillic one")
        return apply(*fallback)

    log("autodownload: no candidate could be applied")
    return None


# ============================================================
#  HELPER - METADATA FROM MANUAL QUERY
#  Metapodaci iz teksta ručne pretrage (action=manualsearch), u istom
#  obliku kao get_media_info()
# ============================================================

def get_media_info_manual(search_string):
    info = {'imdb_id': None, 'title': None,
            'season': None, 'episode': None, 'year': None}

    query = str(search_string).strip() if search_string else ''
    if not query:
        log_error("get_media_info_manual: empty search string")
        return info

    log(f"get_media_info_manual: query='{query}'")

    # Isti parser kao u get_media_info
    season_num, episode_num, rest = parse_season_episode(query)
    if season_num is not None and episode_num is not None:
        info['season']  = season_num
        info['episode'] = episode_num
        query = rest or query
        log(f"get_media_info_manual: parsed S{season_num}E{episode_num}, "
            f"title query='{query}'")

    # Unet IMDB ID se koristi direktno
    m_imdb = re.search(r'(tt\d{6,})', query, flags=re.IGNORECASE)
    if m_imdb:
        info['imdb_id'] = m_imdb.group(1).lower()
        info['title']   = query
        log(f"get_media_info_manual: IMDB ID typed directly: {info['imdb_id']}")
        return info

    clean_name, year = clean_title_for_search(query)
    info['title'] = clean_name or query
    info['year']  = year

    # Razrešava se uneti naziv, da broj sa kraja može biti i deo naslova
    is_series = info['season'] is not None
    info['imdb_id'] = resolve_imdb_by_title(
        query, info['year'], series_first=is_series)

    if not info['imdb_id']:
        log(f"get_media_info_manual: could not resolve '{info['title']}', title search follows")

    log(f"get_media_info_manual result: {info}")
    return info


# ============================================================
#  BACKGROUND SEARCH
#  Poziv iz drugog addona, bez dijaloga. Parametri i statusi su
#  opisani uz BACKGROUND_SEARCH.
# ============================================================

def url_bool(params, key):
    """1/0 (true/false, yes/no) iz URL-a; None kada parametra nema."""
    val = str(params.get(key, '')).strip().lower()
    if val in ('1', 'true', 'yes', 'on'):
        return True
    if val in ('0', 'false', 'no', 'off'):
        return False
    return None


def background_search(params):
    """
    Pretraga bez dijaloga, na zahtev drugog addona. Rezultat se vraća kroz
    status u Home prozoru (BG_STATUS_PROP).
    """
    params = dict(params or {})

    current_file = ''
    try:
        if player_is_playing():
            current_file = xbmc.Player().getPlayingFile()
    except Exception:
        current_file = ''

    # Identitet reprodukcije za koju ovaj poziv radi
    bg_key = playback_key(current_file)

    if not BACKGROUND_SEARCH:
        log("background: disabled (BACKGROUND_SEARCH = False)")
        bg_set_status('disabled', current_file, bg_key)
        return

    if not current_file:
        log("background: player not active")
        bg_set_status('error', current_file, bg_key)
        return

    # Poziv za isti video dok prvi još radi - status upisuje prvi
    if bg_running(current_file):
        log("background: already running for this file, ignoring call")
        return

    bg_set_status('running', current_file, bg_key)
    status = 'error'
    try:
        # Auto-učitavanje za isti video je u toku - čeka se njegov kraj, pa se
        # stanje proverava ponovo
        if not auto_lock_acquire(current_file, wait=AUTO_LOCK_MAX_AGE + 5):
            log("background: auto lock not acquired")
            return
        # Status 'running' dobija novo vreme posle čekanja
        bg_set_status('running', current_file, bg_key, only_if_owner=True)
        status = _background_run(params, current_file)
    except Exception as e:
        log_error(f"background: {e}")
        status = 'error'
    finally:
        auto_lock_release()
        # Isti URL, a drugi video: status stare pretrage se ne upisuje, jer bi
        # se pripisao novom videu
        try:
            now_file = xbmc.Player().getPlayingFile() if player_is_playing() else ''
        except Exception:
            now_file = ''
        if (now_file and now_file == current_file
                and not same_playback_key(playback_key(now_file), bg_key)):
            log(f"background: another video is playing on the same URL, '{status}' not written")
        else:
            bg_set_status(status, current_file, bg_key, only_if_owner=True)


def _background_run(params, current_file):
    """Pozadinska pretraga pod bravom. Vraća status za pozivaoca."""
    # Titl addona je već učitan u ovoj reprodukciji
    if auto_already_done(current_file):
        log("background: subtitle already applied for this playback")
        was_english = playback_cache_load(current_file).get('applied_english')
        return 'english' if was_english else 'applied'

    # U plejeru je već aktivan titl
    active_sub = active_subtitle_info()
    if active_sub is not None:
        log(f"background: subtitle already active "
            f"([{active_sub['language'] or '?'}] {active_sub['name'][:40]})")
        return 'skipped'

    # Izvor jezika bira kodilangs (0 = interna lista, 1 = Kodi jezici,
    # 2 = parametar 'languages'); bez njega važi 'languages' ako je dat,
    # inače USE_INTERNAL_LANGUAGES. Parametri važe samo za ovaj poziv.
    kodilangs = {'0': 0, '1': 1, '2': 2}.get(str(params.get('kodilangs', '')).strip())
    english   = url_bool(params, 'english')
    kodi_langs, kodi_pref = kodi_subtitle_languages()

    explicit_langs = bool(params.get('languages', '').strip())
    if kodilangs is None:
        kodilangs = 2 if explicit_langs else (0 if USE_INTERNAL_LANGUAGES else 1)
    if kodilangs == 2 and not explicit_langs:
        log("background: kodilangs=2 without 'languages', using internal list")
        kodilangs = 0
    if kodilangs == 1:
        params['languages'] = kodi_langs
    use_internal = (kodilangs == 0)
    lang_src = {0: 'internal list', 1: 'Kodi settings', 2: 'from caller'}[kodilangs]

    # Preferirani jezik iz parametra ima prednost nad Kodi podešavanjem
    if not params.get('preferredlanguage'):
        params['preferredlanguage'] = kodi_pref

    # english=1|0 pali ili gasi englesku rezervu za ovaj poziv; nađeni
    # engleski titl se učitava kada je jedini nađen, jer liste nema
    allow_english = FALLBACK_TO_ENGLISH if english is None else english

    log(f"background: languages={'internal list' if use_internal else repr(params.get('languages', ''))} "
        f"({lang_src}), preferred='{params.get('preferredlanguage', '')}', "
        f"english_fallback={allow_english}")

    return search(params, background=True, use_internal=use_internal,
                  allow_english=allow_english) or 'error'


# ============================================================
#  SEARCH - MAIN FLOW
#  Metapodaci, pretraga za izabrane jezike i engleska rezerva
# ============================================================

def search(params=None, background=False, use_internal=None,
           allow_english=False):
    """
    Pretraga za Kodi dijalog, ili pozadinska pretraga (background=True),
    koja ne koristi xbmcplugin i vraća status.
    """
    global _deadline_at, _tmdb_down

    if background:
        handle = -1
    else:
        try:
            handle = int(sys.argv[1])
        except Exception as e:
            log_error(f"search: invalid handle: {e}")
            return

    params = params or {}

    # Rok za celu pretragu
    _deadline_at = (time.time() + SEARCH_DEADLINE) if SEARCH_DEADLINE else None
    _tmdb_down   = False
    if SEARCH_DEADLINE:
        log(f"search: deadline {SEARCH_DEADLINE}s")

    # ----------------------------------------------------------
    # Aktivna lista jezika i preferirani jezik koji se poštuje
    # (effective_preferred); njega dalje koriste redosled, automatski
    # izbor i prevođenje ćirilice
    # ----------------------------------------------------------
    active_langs, kodi_mode = select_languages(params.get('languages', ''),
                                               use_internal)
    preferred, forced_only = effective_preferred(params.get('preferredlanguage', ''),
                                                 active_langs, kodi_mode)
    params['preferredlanguage'] = preferred
    active_langs = order_by_preferred(active_langs, preferred)

    # Grupa preferiranog ex-yu jezika, samo uz internu listu; bez
    # SHOW_OTHER_LANG_GROUPS ostale ex-yu grupe se ne traže
    pref_group = None if kodi_mode else LANG_GROUPS.get(resolve_target_language(preferred))
    if pref_group and not SHOW_OTHER_LANG_GROUPS:
        other = [e['label'] for e in active_langs
                 if LANG_GROUPS.get(e['lang_code']) not in (None, pref_group)]
        if other:
            log(f"languages: other language groups left out: {', '.join(other)}")
            active_langs = [e for e in active_langs
                            if LANG_GROUPS.get(e['lang_code']) in (None, pref_group)]

    # ----------------------------------------------------------
    # Metapodaci: iz ručnog upita, keša reprodukcije ili Kodija
    # ----------------------------------------------------------
    manual_query = params.get('searchstring', '').strip()
    current_file = ''
    try:
        if player_is_playing():
            current_file = xbmc.Player().getPlayingFile()
    except Exception:
        current_file = ''
    # Identitet reprodukcije za koju se pretraga radi
    search_key = playback_key(current_file)
    pb_cache = playback_cache_load(current_file)

    info_failed = False
    if params.get('action') == 'manualsearch' and manual_query:
        info = get_media_info_manual(manual_query)
    elif playback_info_valid(pb_cache):
        info = pb_cache['info']
        log(f"get_media_info: served from playback cache: {info}")
    else:
        try:
            info = get_media_info()
        except Exception as e:
            # Greška pri razrešavanju ne prekida pretragu i ne kešira se
            log_error(f"get_media_info failed: {e}")
            info = None
        if info is None:
            info_failed = True
            info = {'imdb_id': None, 'tmdb_id': None, 'title': None,
                    'season': None, 'episode': None, 'year': None}
        elif current_file and (info.get('imdb_id') or remaining_time(1) > 0):
            # Neuspeh se kešira kraće, i samo kada razrešavanje nije prekinuto rokom
            playback_cache_save(current_file, search_key, info=info, info_ts=time.time())

    imdb_id   = info.get('imdb_id')
    season    = info.get('season')
    episode   = info.get('episode')
    title     = info.get('title')
    is_series = season is not None

    # Naziv za pretragu po nazivu - samo kada IMDB ID nije pronađen
    title_query = ''
    if TITLE_SEARCH_FALLBACK and title and not imdb_id:
        title_query, _ = clean_title_for_search(title, info.get('year'),
                                                is_series=is_series)

    if not imdb_id:
        if not title_query:
            log_error("search: no IMDB ID and no usable title, aborting")
            if background:
                # 'error' ako razrešavanje nije uspelo, inače 'none'
                return 'error' if info_failed else 'none'
            xbmcplugin.endOfDirectory(handle)
            return
        log(f"search: no IMDB ID, falling back to title search '{title_query}'")

    log(f"search: imdb={imdb_id} | title={title} | S={season} | E={episode}")

    # Kontekst za detekciju sinhronizacije: hash, naziv izdanja i FPS videa
    video_path = ''
    video_hash = None
    video_size = None
    video_fps  = None
    raw_path   = ''

    if DETECT_SYNC:
        try:
            if xbmc.Player().isPlaying():
                raw_path   = xbmc.Player().getPlayingFile()
                fps_label  = xbmc.getInfoLabel('Player.Process(videofps)')
                video_fps  = fps_label if fps_label else None
                # Hash se računa nad stvarnom putanjom (osim za streamove)
                video_hash, video_size = compute_os_hash(raw_path)
                # Najbolji dostupan naziv izdanja videa
                video_path = get_video_name_for_match()
        except Exception as e:
            log(f"search: sync context unavailable ({e})")

    # Automatski izbor se odlučuje jednom - od njega zavisi i čekanje na
    # stream probe
    is_manual = params.get('action') == 'manualsearch'
    if background:
        # Pozadinski poziv je zahtev za auto-učitavanje; aktivan titl je već
        # proveren u _background_run
        auto_on = player_is_playing()
    else:
        auto_on = (not is_manual and AUTODOWNLOAD_FORCE and player_is_playing()
                   and autodownload_enabled())

    # Auto-učitavanje obavljeno u ovoj reprodukciji ili aktivan titl u
    # plejeru isključuju auto-učitavanje - lista se tada ne čeka kao za
    # automatski izbor
    if auto_on and not background:
        if auto_already_done(current_file):
            log("autodownload: already done for this playback, list only")
            auto_on = False
        else:
            active_sub = active_subtitle_info()
            if active_sub is not None:
                log(f"autodownload: subtitle already active "
                    f"([{active_sub['language'] or '?'}] {active_sub['name'][:40]}), list only")
                auto_on = False

    # Dok drugi proces radi auto-učitavanje za isti video, prikazuje se samo lista
    if auto_on and not background and not auto_lock_acquire(current_file):
        log("autodownload: auto in progress in another process, list only")
        auto_on = False

    # Jezici hash upita - jezici pretrage i engleski, jedan upit za oba prolaza
    hash_codes = [c for l in active_langs for c in l['rest']]
    for code in ENGLISH_LANGUAGE['rest']:
        if code not in hash_codes:
            hash_codes.append(code)

    # Stream: probe (hash i naziv fajla) i hash upit rade u pozadini,
    # paralelno sa pretragom, jednom po reprodukciji. Bez automatskog izbora
    # samo uz STREAM_HASH_LIST.
    stream_thread, stream_holder = None, {}
    cached_probe = pb_cache.get('probe')
    if cached_probe is not None and not isinstance(cached_probe, dict):
        cached_probe = None
    stream_matches = cached_hash_matches(pb_cache, hash_codes) if cached_probe else None
    if (STREAM_HASH_ENABLED and DETECT_SYNC and not video_hash
            and (auto_on or STREAM_HASH_LIST)
            and raw_path.lower().startswith(('http://', 'https://'))):
        if cached_probe is not None:
            log("stream hash: served from playback cache")
        # Hash upit se ponavlja samo kada ranije nije uspeo; probe koji je
        # nedavno pao ne ponavlja se dok se prikazuje samo lista
        try:
            probe_failed_recently = (time.time() - float(pb_cache.get('probe_fail_ts') or 0)
                                     < PB_INFO_NEG_MAX_AGE)
        except (TypeError, ValueError):
            probe_failed_recently = False
        if cached_probe is None and probe_failed_recently and not auto_on:
            log("stream hash: probe failed recently, list shown without it")
        elif cached_probe is None or (cached_probe.get('hash') and stream_matches is None):
            stream_thread, stream_holder = start_stream_probe(
                raw_path, cached_probe, hash_codes, current_file, search_key)

    # Lokalni fajl: hash pogoci se traže zasebnim upitom, paralelno sa
    # pretragom, jednom po reprodukciji - za automatski izbor i za sync
    # ikone liste. Nit sama čuva rezultat, i kada ga lista ne sačeka.
    hash_thread, hash_holder = None, {}
    if (DETECT_SYNC and video_hash and video_size
            and cached_hash_matches(pb_cache, hash_codes) is None):
        def _hash_lookup():
            result = xmlrpc_hash_lookup(video_hash, video_size, hash_codes)
            hash_holder['result'] = result
            # Neuspeh (None) se ne kešira; kasni rezultat se ne upisuje
            # kada se u međuvremenu pušta drugi video
            if result is not None and playback_unchanged(search_key):
                save_hash_matches(current_file, result, hash_codes, search_key)
        hash_thread = start_thread(_hash_lookup)

    # Keš deljen između ex-yu i engleskog prolaza
    net_cache = {}

    # Kandidati iz svih prolaza rangiraju se zajedno
    auto_candidates = []

    # Engleska rezerva (FALLBACK_TO_ENGLISH); pozadinski poziv je pali ili
    # gasi parametrom english=1|0
    english_pass = allow_english if background else FALLBACK_TO_ENGLISH

    found = _run_search(imdb_id, season, episode, is_series, active_langs,
                        video_path, video_fps, net_cache, title_query,
                        auto_candidates, english_query=english_pass,
                        pref_group=pref_group)
    english_fallback = False
    english_tried    = False

    # Samo titlovi ostalih ex-yu grupa, bez grupe preferiranog jezika, za
    # rezervu se računaju kao prazan rezultat (ENGLISH_WITH_OTHER_GROUPS)
    other_groups_only = bool(
        found and pref_group and SHOW_OTHER_LANG_GROUPS and ENGLISH_WITH_OTHER_GROUPS
        and all(LANG_GROUPS.get(c.get('lang_code')) not in (None, pref_group)
                for c in auto_candidates))

    # Engleska rezerva, kada ništa nije nađeno: po IMDB ID-u, a po nazivu
    # samo kada ID-a nema; odgovori se uzimaju iz keša pretrage. Engleski
    # titlovi idu iza već nađenih.
    if (found == 0 or other_groups_only) and english_pass:
        # Engleski među jezicima pretrage je već pretražen
        has_english = any(l['lang_code'] == 'en' for l in active_langs)
        if has_english:
            log("search: English was already searched - skipping fallback")
        elif remaining_time(1) <= 0:
            log("search: deadline reached, skipping English fallback")
        else:
            log("search: only other language groups found, adding English"
                if found else "search: no results for selected languages, retrying in English")
            english_tried = True

            eng_found = 0
            if imdb_id:
                eng_found = _run_search(imdb_id, season, episode, is_series,
                                        [ENGLISH_LANGUAGE], video_path, video_fps,
                                        net_cache, title_query, auto_candidates,
                                        english_query=True)
            elif title_query and TITLE_SEARCH_FALLBACK:
                eng_found = _run_search(None, season, episode, is_series,
                                        [ENGLISH_LANGUAGE], video_path, video_fps,
                                        net_cache, title_query, auto_candidates,
                                        english_query=True)

            english_fallback = eng_found > 0
            found += eng_found
            log(f"search: English fallback returned {eng_found} subtitles")

    # Rangiranje za automatski izbor (samo uz auto_on) prethodi upisu liste
    auto_first = None
    auto_order = []
    # Engleski izabran među jezicima pretrage je običan jezik; iz rezerve se
    # u dijalogu učitava samo uz AUTODOWNLOAD_ENGLISH, a u pozadini kada je
    # jedini nađen, jer liste nema
    english_ok = (background or AUTODOWNLOAD_ENGLISH
                  or any(l['lang_code'] == 'en' for l in active_langs))

    # Pretraga bez plejera služi samo proveri dostupnosti titlova
    if found and not is_manual and not player_is_playing():
        log("search: player not active, autodownload skipped")

    # Rezultat stream probe i hash upita primenjuje se pre rangiranja. Za
    # automatski izbor nit se čeka najviše TIMEOUT_HASH + TIMEOUT_XMLRPC, za
    # samu listu TIMEOUT_HASH_LIST, u okviru roka; kasni rezultat nit sama
    # čuva za sledeće otvaranje.
    probe = cached_probe
    if stream_thread is not None:
        wait = (TIMEOUT_HASH + TIMEOUT_XMLRPC) if auto_on else TIMEOUT_HASH_LIST
        stream_thread.join(max(0.1, remaining_time(wait)))
        if 'result' in stream_holder:
            probe = stream_holder['result'] or {}
        stream_matches = stream_holder.get('matched')
        if stream_thread.is_alive():
            log(f"stream hash: {'hash lookup' if 'result' in stream_holder else 'probe'} "
                f"still running, proceeding without it")
    elif probe and stream_matches is not None:
        log(f"hash lookup: {len(stream_matches)} match(es) served from playback cache")
    hash_found = None
    if probe:
        hash_found = refresh_sync_from_probe(auto_candidates, probe, video_fps, stream_matches)

    # Hash pogoci lokalnog fajla - iz pozadinske niti ili keša reprodukcije.
    # Za automatski izbor nit se čeka najviše TIMEOUT_XMLRPC, za samu listu
    # TIMEOUT_HASH_LIST, u okviru roka.
    if video_hash and video_size:
        matched = cached_hash_matches(pb_cache, hash_codes)
        if matched is None and hash_thread is not None:
            wait = TIMEOUT_XMLRPC if auto_on else TIMEOUT_HASH_LIST
            hash_thread.join(max(0.1, remaining_time(wait)))
            if hash_thread.is_alive():
                log("hash lookup: still running, proceeding without it")
            else:
                matched = hash_holder.get('result')
        if matched:
            if auto_candidates:
                apply_hash_matches(auto_candidates, matched)
            hash_found = matched

    # Hash pogoci kojih nema u rezultatima pretrage dodaju se u listu - i
    # kada pretraga nije našla ništa; za izabrane jezike, a za engleski samo
    # kada je pokrenuta engleska rezerva
    if hash_found:
        scope_codes = [c for l in active_langs for c in l['rest']]
        if english_tried:
            scope_codes += [c for c in ENGLISH_LANGUAGE['rest'] if c not in scope_codes]
        found += add_hash_candidates(auto_candidates, hash_found, active_langs,
                                     scope_codes, video_fps)
        if english_tried and any(c.get('lang_code') == 'en' for c in auto_candidates):
            english_fallback = True

    # Ćirilični titlovi koji se prevode u latinicu - pri automatskom izboru
    # ('to_latin') i, po podešavanju, iz liste ('&latin=1'). Ćirilicu od
    # ostalih jezika imaju srpski i bosanski; makedonski se ne prevodi.
    list_latin = latin_conversion(preferred)
    auto_latin = latin_conversion(preferred, auto=True)
    if list_latin or auto_latin:
        marked = 0
        for c in auto_candidates:
            if c.get('lang_code') in ('sr', 'bs'):
                c['to_latin'] = True
                if list_latin:
                    c['path'] = c.get('path', '') + '&latin=1'
                marked += 1
        log(f"search: cyrillic to latin enabled for {marked} candidate(s) "
            f"({'list and auto' if list_latin else 'auto only'})")

    if found and auto_on:
        try:
            target_lang = resolve_target_language(params.get('preferredlanguage', ''))
            log(f"autodownload: {len(auto_candidates)} candidates, "
                f"preferred='{params.get('preferredlanguage', '')}' "
                f"-> target_lang='{target_lang or '(none)'}', video_fps={video_fps}")
            auto_order = pick_auto_candidates(auto_candidates, target_lang,
                                              active_langs, forced_only, kodi_mode)
            # Engleska rezerva se sama ne učitava (vidi english_ok), niti
            # kada postoji titl na izabranom jeziku (hash pogodak ili
            # ostale ex-yu grupe)
            exyu_found = english_fallback and any(c.get('lang_code') != 'en'
                                                  for c in auto_candidates)
            if auto_order and (not english_ok or exyu_found):
                exyu_only = [c for c in auto_order if c.get('lang_code') != 'en']
                if not exyu_only:
                    log("autodownload: English fallback not loaded automatically, "
                        "leaving the list to the user")
                auto_order = exyu_only
            if auto_order:
                auto_first = auto_order[0]
            else:
                log("autodownload: nothing suitable, leaving the list to the user")
        except Exception as e:
            log_error(f"autodownload: ranking failed: {e}")
            auto_order, auto_first = [], None

    # Pozadinski režim: bez liste, samo primena i status
    if background:
        if not found:
            # Bez odgovora ijednog izvora rezultat nije poznat
            status = 'none' if net_cache.get(ANSWERED_KEY) else 'error'
        elif not auto_on:
            status = 'error'        # plejer zaustavljen tokom pretrage
        elif not auto_order:
            status = 'list'
        else:
            try:
                applied_ok = auto_apply(auto_order, resolve_target_language(
                    params.get('preferredlanguage', '')), close_dialogs=False,
                    expected_key=search_key)
            except Exception as e:
                log_error(f"autodownload: {e}")
                applied_ok = False
            if not applied_ok:
                # Titl uključen u međuvremenu nije greška
                status = 'skipped' if active_subtitle_info() is not None else 'error'
            elif english_fallback and applied_ok.get('lang_code') == 'en':
                status = 'english'      # učitan engleski iz rezerve
            else:
                status = 'applied'
            if applied_ok:
                playback_cache_save(current_file, search_key,
                                    applied_english=(status == 'english'))
        return status

    # Da li je auto-učitavanje tek na redu - utvrđuje se pre primene, koja
    # ga označava kao obavljeno
    auto_will_apply = bool(auto_order) and not auto_already_done(current_file)

    # Primena prethodi endOfDirectory, da traka postoji pre Kodijeve provere
    applied = None
    if auto_order:
        try:
            applied = auto_apply(auto_order, resolve_target_language(
                params.get('preferredlanguage', '')), expected_key=search_key)
        except Exception as e:
            log_error(f"autodownload: {e}")
        if applied:
            playback_cache_save(current_file, search_key, applied_english=bool(
                english_fallback and applied.get('lang_code') == 'en'))
    auto_lock_release()

    # Na vrhu liste je titl učitan u ovoj reprodukciji: upravo primenjen,
    # ili, pri ponovnom otvaranju, ranije auto-učitan. Titlovi već
    # preuzeti na disk nose oznaku [Local].
    front = applied
    if front is None:
        front = auto_first
        applied_key = _safe_key(pb_cache.get('applied_key'))
        if applied_key and not auto_will_apply:
            previous = next((c for c in auto_candidates
                             if _safe_key(c.get('cache_key')) == applied_key), None)
            if previous is not None:
                front = previous
                log(f"search: auto-loaded subtitle on top -> "
                    f"{(previous.get('filename') or '')[:LOG_NAME_LEN]}")

    # Lista se upisuje kada je redosled poznat
    emit_candidates(handle, auto_candidates, front)

    # Titl nije učitan, a Kodi bi sam skinuo prvu stavku - podešavanje se
    # gasi dok Kodi prima listu i vraća posle BLOCK_KODI_AUTO_DELAY. Bez
    # AUTODOWNLOAD_FORCE blokada važi samo van plejera. Ako je podešavanje
    # ugasio drugi proces addona, vraćanje preuzima ovaj.
    block_mark = ''
    if (BLOCK_KODI_AUTO and found and not applied
            and (AUTODOWNLOAD_FORCE or not player_is_playing())
            and subtitle_track_count() <= 0
            and downloadfirst_on() is True):
        block_mark = f"{time.time():.6f}"
        _set_home_prop(BLOCK_KODI_AUTO_PROP, block_mark)
        if set_kodi_setting('subtitles.downloadfirst', False):
            log("search: subtitle not loaded, Kodi auto-download suppressed - list stays with the user")
        else:
            _clear_block_mark(block_mark)
            block_mark = ''

    xbmcplugin.endOfDirectory(handle)

    if block_mark:
        xbmc.sleep(BLOCK_KODI_AUTO_DELAY)
        restore_downloadfirst_after_block(block_mark)


# ============================================================
#  SUBTITLE DOWNLOAD + UTF-8 CONVERSION
# ============================================================

def _safe_key(key):
    return re.sub(r'[^A-Za-z0-9]', '', str(key or ''))[:40]


def _file_key(cache_key):
    """
    Ključ za ime titla na disku, u obliku os<ID>; bez ID-a prazan
    string.
    """
    key = _safe_key(cache_key)
    return key if re.fullmatch(r'os[A-Za-z0-9]+', key) else ''


# Ljubičasta - razlikuje se od boja ostalih oznaka
LOCAL_TAG = '[COLOR FFDA70D6][Local][/COLOR]'

# Preuzeti titlovi su u sopstvenom podfolderu i ime im ne sadrži reč
# "subtitle", jer Kodi fajlove sa tom reči iz special://temp/ briše na
# početku svake reprodukcije.
STAGING_DIR = 'special://temp/exyusubs/'


def staging_dir():
    path = xbmcvfs.translatePath(STAGING_DIR)
    try:
        os.makedirs(path, exist_ok=True)
    except Exception as e:
        log(f"download: cannot create {path} ({e})")
    return path


def cached_subtitle_keys():
    """Skup ID-eva titlova koji su na disku i mlađi od STAGING_MAX_AGE."""
    keys = set()
    try:
        temp_dir = staging_dir()
        now = time.time()
        for f in os.listdir(temp_dir):
            # Skriveni original (ORIG_SUFFIX) je takođe na disku
            name = f[:-len(ORIG_SUFFIX)] if f.endswith(ORIG_SUFFIX) else f
            if not name.lower().endswith(SUB_EXTENSIONS):
                continue
            parts = name.split('.')
            if len(parts) < 2:
                continue
            try:
                if now - os.path.getmtime(os.path.join(temp_dir, f)) > STAGING_MAX_AGE:
                    continue
            except Exception:
                continue
            keys.add(parts[0])
    except Exception as e:
        log(f"search: local subtitle scan skipped ({e})")
    return keys


def cached_subtitle(temp_dir, cache_key, lang_code, latin=False):
    """
    Već preuzet isti titl, ako je na disku i mlađi od STAGING_MAX_AGE;
    latin=True traži latiničnu kopiju (os<ID>.lat.<jezik>.<ext>).
    Vraća isti dict kao fetch_and_save, ili None.
    """
    key = _file_key(cache_key)
    if not key:
        return None
    base   = key + '.lat' if latin else key
    prefix = f"{base}.{lang_code}." if lang_code else f"{base}."
    try:
        for f in os.listdir(temp_dir):
            if not (f.startswith(prefix) and f.lower().endswith(SUB_EXTENSIONS)):
                continue
            if not latin and f.startswith(f"{key}.lat."):
                continue
            fp = os.path.join(temp_dir, f)
            if time.time() - os.path.getmtime(fp) > STAGING_MAX_AGE:
                continue
            with io.open(fp, encoding='utf-8', errors='replace') as fh:
                text = fh.read(SCRIPT_SAMPLE_CHARS * 2)
            if not text.strip():
                continue
            if latin:
                # Skriveni original traje koliko i latinična kopija, a
                # primenjeni fajl ostaje najnoviji
                orig = f"{key}.{lang_code}." if lang_code else f"{key}."
                for o in os.listdir(temp_dir):
                    if o.startswith(orig) and o.endswith(ORIG_SUFFIX):
                        os.utime(os.path.join(temp_dir, o), None)
            os.utime(fp, None)      # produžava rok dok se titl koristi
            log(f"download: served from disk cache -> {f}")
            return {'path': fp, 'filename': f,
                    'ext': os.path.splitext(f)[1].lower(),
                    'cyr_ratio': cyrillic_ratio(text)}
    except Exception as e:
        log(f"download: disk cache lookup failed ({e})")
    return None


# Ćirilični original uz latiničnu kopiju čuva se sa ovim nastavkom, da ga
# drugi addoni i servisi ne vide kao titl i ne učitaju preko primenjenog
ORIG_SUFFIX = '.orig'


def vfs_move(src, dst):
    """
    Premešta fajl kroz Kodijev VFS (kopija + brisanje). Preimenovanje mimo
    VFS-a Kodi ne vidi u kešu listinga, pa novi fajl ne bi mogao da otvori.
    """
    if not xbmcvfs.copy(src, dst):
        return False
    xbmcvfs.delete(src)
    return True


def restore_original(temp_dir, key, lang_code):
    """
    Skriveni original (os<ID>.<jezik>.<ext>.orig) vraća pod ime titla, za
    izbor iz liste. Vraća True kada je original vraćen.
    """
    if not key:
        return False
    prefix = f"{key}.{lang_code}." if lang_code else f"{key}."
    try:
        for f in os.listdir(temp_dir):
            if f.startswith(prefix) and f.endswith(ORIG_SUFFIX):
                # Istekao original se ne koristi - sledi novo preuzimanje
                if time.time() - os.path.getmtime(os.path.join(temp_dir, f)) > STAGING_MAX_AGE:
                    continue
                name = f[:-len(ORIG_SUFFIX)]
                if not vfs_move(os.path.join(temp_dir, f), os.path.join(temp_dir, name)):
                    log(f"download: original not restored ({f})")
                    return False
                log(f"download: original restored -> {name}")
                return True
    except Exception as e:
        log(f"download: original not restored ({e})")
    return False


def has_latin_copy(temp_dir, key):
    """Da li za ključ postoji latinična kopija (os<ID>.lat.*)."""
    try:
        return any(f.startswith(f"{key}.lat.") for f in os.listdir(temp_dir))
    except Exception:
        return False


def hide_original(temp_dir, key, lang_code):
    """Original uz latiničnu kopiju dobija ORIG_SUFFIX (vidi restore_original)."""
    if not key:
        return
    prefix = f"{key}.{lang_code}." if lang_code else f"{key}."
    try:
        for f in os.listdir(temp_dir):
            if (f.startswith(prefix) and f.lower().endswith(SUB_EXTENSIONS)
                    and not f.startswith(f"{key}.lat.")):
                if vfs_move(os.path.join(temp_dir, f), os.path.join(temp_dir, f + ORIG_SUFFIX)):
                    log(f"download: original hidden -> {f}{ORIG_SUFFIX}")
    except Exception as e:
        log(f"download: original not hidden ({e})")


def latin_copy(cached, temp_dir, key, lang_code):
    """
    Latinična kopija titla koji je već na disku, bez novog preuzimanja;
    original se skriva (ORIG_SUFFIX) pre upisa kopije, da primenjeni fajl
    bude najnoviji. Titl bez ćirilice se vraća nepromenjen. Vraća isti
    dict kao fetch_and_save, ili None kada ne uspe.
    """
    try:
        with io.open(cached['path'], encoding='utf-8', errors='replace', newline='') as fh:
            original = fh.read()
        text = cyrillic_to_latin(original)
        if text == original:
            return cached
        hide_original(temp_dir, key, lang_code)
        ext  = cached['ext']
        name = f"{key}.lat.{lang_code}{ext}" if lang_code else f"{key}.lat{ext}"
        path = os.path.join(temp_dir, name)
        with io.open(path, 'w', encoding='utf-8', newline='') as fh:
            fh.write(text)
        log(f"download: latin copy of cached subtitle -> {name}")
        return {'path': path, 'filename': name, 'ext': ext,
                'cyr_ratio': cyrillic_ratio(text)}
    except Exception as e:
        log(f"download: latin copy failed ({e})")
        return None


def undo_double_utf8(text):
    """
    UTF-8 tekst koji je usput jednom pročitan kao cp1252/cp1250 i ponovo
    kodiran ('Å¡' umesto 'š'). Vraća ispravljen tekst, ili None kada
    obrazac nije prepoznat ili se tekst ne može vratiti.
    """
    # Vodeći bajtovi UTF-8 sekvenci pročitani kao cp1252 (Ã Ä Å Ð Ñ) ili
    # cp1250 (Ä Ĺ Đ Ń)
    if sum(text.count(m) for m in ('Ã', 'Ä', 'Å', 'Ð', 'Ñ', 'Ĺ', 'Đ', 'Ń')) < 3:
        return None
    for enc in ('cp1252', 'cp1250'):
        try:
            try:
                raw = text.encode(enc)
            except UnicodeEncodeError:
                # Nedefinisana mesta kodne strane (0x81, 0x8D...) su prošla
                # kao sirovi bajtovi
                raw = bytearray()
                for ch in text:
                    try:
                        raw += ch.encode(enc)
                    except UnicodeEncodeError:
                        if ord(ch) > 0xFF:
                            raise
                        raw.append(ord(ch))
            return bytes(raw).decode('utf-8')
        except (UnicodeEncodeError, UnicodeDecodeError):
            continue
    return None


def fetch_and_save(url, encoding='', lang_code='', cache_key='', alt_url='',
                   timeout=None, to_latin=False):
    """
    Preuzima titl, raspakuje arhivu, prepoznaje format i enkoding i snima
    ga u special://temp/exyusubs/ kao os<IDSubtitle>.<jezik>.<ext>.
    Isti titl ima isto ime, pa se ponovo koristi sa diska; ime se
    razlikuje od Kodijevog TempSubtitle.<jezik>.<ext>.

    Sa to_latin=True ćirilica se prevodi u latinicu; preveden titl se čuva
    pod zasebnim imenom (os<IDSubtitle>.lat.<jezik>.<ext>), a original kao
    os<IDSubtitle>.<jezik>.<ext>.orig, koji se ponovo koristi bez preuzimanja.

    Vraća dict {'path', 'filename', 'ext', 'cyr_ratio'}, {'blocked': True}
    kod VIP poruke, {'timeout': True, 'host'} kada server nije odgovorio,
    ili None.
    """
    if not url:
        log_error("download: no URL provided")
        return None

    temp_dir = staging_dir()

    plain_key = _file_key(cache_key)
    use_latin = bool(plain_key and to_latin and CONVERT_TO_UTF8)

    cached = cached_subtitle(temp_dir, plain_key, lang_code, latin=True) if use_latin else None
    if cached:
        hide_original(temp_dir, plain_key, lang_code)
    else:
        cached = cached_subtitle(temp_dir, plain_key, lang_code)
        # Skriveni original se vraća bez novog preuzimanja
        if not cached and restore_original(temp_dir, plain_key, lang_code):
            cached = cached_subtitle(temp_dir, plain_key, lang_code)
        # Ćirilični titl sa diska se prevodi bez novog preuzimanja
        if cached and use_latin:
            cached = latin_copy(cached, temp_dir, plain_key, lang_code)
    if cached:
        return cached

    try:

        # Brisanje titlova starijih od STAGING_MAX_AGE; ponovna upotreba
        # titla osvežava njegovo vreme. Greška ne prekida preuzimanje.
        try:
            now = time.time()
            for f in os.listdir(temp_dir):
                fp = os.path.join(temp_dir, f)
                if not os.path.isfile(fp):
                    continue
                try:
                    if now - os.path.getmtime(fp) > STAGING_MAX_AGE:
                        os.remove(fp)
                except Exception:
                    pass
        except Exception as e:
            log(f"download: temp cleanup skipped ({e})")

        log(f"download: url={url} encoding={encoding or 'unknown'} lang={lang_code}")

        res = requests.get(url, headers=HEADERS, timeout=timeout or TIMEOUT_DOWNLOAD)
        res.raise_for_status()
        raw = res.content
        log(f"download: received {len(raw)} bytes")

        # Format titla se utvrđuje iz arhive ili sadržaja, jer Kodi bira parser po ekstenziji
        sub_ext = '.srt'

        # ----------------------------------------------------------
        # ZIP / GZIP - prepoznavanje po magic bajtovima i raspakivanje
        # ----------------------------------------------------------
        if raw[:2] == b'PK':
            log("download: detected ZIP archive, extracting subtitle")
            try:
                with zipfile.ZipFile(io.BytesIO(raw)) as zf:
                    # Prvi titl u arhivi; .txt poslednji, jer arhiva uz
                    # titl može nositi i tekstualni opis
                    sub_names = sorted((n for n in zf.namelist()
                                        if n.lower().endswith(SUB_EXTENSIONS)),
                                       key=lambda n: n.lower().endswith('.txt'))
                    if sub_names:
                        chosen = sub_names[0]
                        raw = zf.read(chosen)
                        # Format iz arhive
                        _, zip_ext = os.path.splitext(chosen)
                        if zip_ext:
                            sub_ext = zip_ext.lower()
                        log(f"download: extracted '{chosen}' from ZIP")
                    else:
                        log_error("download: ZIP contains no subtitle files")
                        return None
            except zipfile.BadZipFile as e:
                log_error(f"download: invalid ZIP archive: {e}")
                return None

        elif raw[:2] == b'\x1f\x8b':
            log("download: detected GZIP archive, extracting subtitle")
            try:
                raw = gzip.decompress(raw)
                log(f"download: GZIP decompressed ({len(raw)} bytes)")
            except Exception as e:
                log_error(f"download: GZIP decompression failed: {e}")
                return None

        # VIP poruka umesto titla: pokušava se rezervni link, a zatim se
        # preuzimanje proglašava blokiranim
        if len(raw) < 2048 and (b'osdb.link/vip' in raw or b'VIP member' in raw):
            if alt_url:
                log("download: VIP placeholder received, retrying via Stremio")
                return fetch_and_save(alt_url, encoding, lang_code, cache_key,
                                      timeout=timeout, to_latin=to_latin)
            log_error("download: OpenSubtitles returned VIP placeholder instead of subtitle")
            return {'blocked': True}

        # UTF-16 se odmah prevodi u UTF-8, pre provere formata
        enc16 = utf16_encoding(raw)
        if enc16:
            log(f"download: {enc16} content detected, converting to UTF-8")
            raw = raw.decode(enc16, errors='replace').encode('utf-8')
            encoding = 'utf-8'

        # Prazan odgovor ili HTML stranica (greška servera) nisu titl
        body = raw.lstrip(codecs.BOM_UTF8).strip()
        head = body[:512].lower()
        is_html = (head.startswith((b'<!doctype html', b'<html', b'<head'))
                   or (head.startswith(b'<?xml') and b'<html' in head))
        if not body or is_html:
            what = 'HTML page received instead of subtitle' if body else 'empty subtitle received'
            if alt_url:
                log(f"download: {what}, retrying via Stremio")
                return fetch_and_save(alt_url, encoding, lang_code, cache_key,
                                      timeout=timeout, to_latin=to_latin)
            log_error(f"download: {what}")
            return None

        # Format po sadržaju početka fajla - pouzdaniji od ekstenzije
        head = raw[:512].lstrip(codecs.BOM_UTF8).lstrip()
        if head[:12].lower() == b'[script info':
            if sub_ext not in ('.ass', '.ssa'):
                log(f"download: content is ASS/SSA, overriding '{sub_ext}'")
            sub_ext = '.ass'
        elif head[:6].lower() == b'webvtt':
            log("download: content is WebVTT")
            sub_ext = '.vtt'

        # ----------------------------------------------------------
        # Konverzija u UTF-8: BOM -> strogi UTF-8 -> UTF-8 uz pojedinačne
        # neispravne bajtove -> deklarisani ili cp1252 (jezici van ex-yu
        # grupe) -> bodovanje jednobajtnih kodnih strana, uz mali bonus
        # deklarisanom enkodingu.
        # ----------------------------------------------------------
        def decode_content(raw, encoding):
            declared = encoding.strip().lower().replace('_', '-') if encoding else ''
            # Normalizacija naziva enkodinga
            if declared in ('utf8', 'utf-8-bom', 'utf8bom'):
                declared = 'utf-8'

            # 1. BOM
            if raw.startswith(codecs.BOM_UTF8):
                log("download: UTF-8 BOM detected")
                return raw.decode('utf-8-sig')

            # 2. Strogi UTF-8
            try:
                text_utf8 = raw.decode('utf-8')
                # Višebajtne sekvence - UTF-8
                if any(ord(c) > 127 for c in text_utf8):
                    log("download: detected UTF-8 (multi-byte sequences)")
                    return text_utf8
                # Čist ASCII
                log("download: detected plain ASCII")
                return text_utf8
            except UnicodeDecodeError:
                pass

            # 3. UTF-8 sa pokojim neispravnim bajtom (red nalepljen iz druge
            #    kodne strane): ispravnih višebajtnih znakova mora biti bar
            #    20 puta više od neispravnih bajtova
            replaced = raw.decode('utf-8', errors='replace')
            bad  = replaced.count('\ufffd')
            good = len(replaced) - len(replaced.encode('ascii', 'ignore')) - bad
            if good >= 20 and good >= 20 * bad:
                log(f"download: detected UTF-8 with {bad} invalid byte(s) replaced")
                return replaced

            # 4. Jezik van ex-yu grupe (Kodi jezici, engleski): ex-yu bodovanje
            #    ne važi - deklarisani enkoding, inače cp1252 (zapadna Evropa)
            if lang_code not in LANG_GROUPS:
                for enc in ([declared] if declared else []) + ['cp1252']:
                    try:
                        text = raw.decode(enc)
                    except (UnicodeDecodeError, LookupError):
                        continue
                    log(f"download: non ex-yu language, using encoding '{enc}'")
                    return text

            # 5. Bodovanje jednobajtnih kodnih strana (ex-yu jezici)
            candidates = list(EXYU_ENCODINGS)
            if declared and declared not in candidates:
                candidates.insert(0, declared)

            # Boduje se uzorak sa početka fajla (kod ASS/SSA od replika);
            # ceo fajl se dekodira pobedničkim enkodingom
            events = raw.lower().find(b'[events]')
            start  = events if events >= 0 else 0
            sample = raw[start:start + ENCODING_SAMPLE_BYTES]

            best_enc, best_score = None, None
            for enc in candidates:
                try:
                    decoded = sample.decode(enc)
                except (UnicodeDecodeError, LookupError):
                    continue
                sc = score_decoded_text(decoded)
                # Mali bonus deklarisanom enkodingu, presuđuje pri bliskim ocenama
                if enc == declared:
                    sc += 5
                log(f"download: encoding candidate '{enc}' score={sc}")
                if best_score is None or sc > best_score:
                    best_enc, best_score = enc, sc

            best_text = None
            if best_enc is not None:
                try:
                    best_text = raw.decode(best_enc)
                except (UnicodeDecodeError, LookupError):
                    # Neispravni bajtovi van uzorka se zamenjuju
                    log(f"download: '{best_enc}' failed on full file, using replace")
                    best_text = raw.decode(best_enc, errors='replace')

            if best_text is not None:
                if declared and best_enc != declared:
                    log(f"download: declared '{declared}' overridden by '{best_enc}' (score={best_score})")
                else:
                    log(f"download: using encoding '{best_enc}' (score={best_score})")
                return best_text

            log_error("download: all encodings failed, using utf-8 with replace")
            return raw.decode('utf-8', errors='replace')

        # CONVERT_TO_UTF8 = False - fajl se snima bez konverzije
        cyr = 0.0
        key = plain_key
        original_bytes = None
        if CONVERT_TO_UTF8:
            text = decode_content(raw, encoding)
            fixed = undo_double_utf8(text)
            if fixed is not None:
                log("download: double-encoded UTF-8 repaired")
                text = fixed
            if to_latin:
                latin = cyrillic_to_latin(text)
                if latin != text:
                    log("download: cyrillic converted to latin")
                    # Original ostaje na disku (skriven) za izbor iz liste;
                    # bez ID-a titla nema ni zasebnog imena
                    if plain_key:
                        original_bytes = text.encode('utf-8')
                        key = plain_key + '.lat'
                    text = latin
            out_bytes = text.encode('utf-8')
            cyr       = cyrillic_ratio(text)
        else:
            log("download: UTF-8 conversion disabled, saving raw content")
            out_bytes = raw

        # Ime po ID-u titla: os<IDSubtitle>.<jezik>.<ext>, za preveden titl
        # os<IDSubtitle>.lat.<jezik>.<ext>; bez ID-a vremenska oznaka.
        if key:
            filename_with_lang = (f"{key}.{lang_code}{sub_ext}"
                                  if lang_code else f"{key}{sub_ext}")
            temp_path = os.path.join(temp_dir, filename_with_lang)
        else:
            stamp = int(time.time() * 1000) % 10_000_000
            while True:
                filename_with_lang = (f"t{stamp}.{lang_code}{sub_ext}"
                                      if lang_code else f"t{stamp}{sub_ext}")
                temp_path = os.path.join(temp_dir, filename_with_lang)
                if not os.path.exists(temp_path):
                    break
                stamp += 1

        # Original se upisuje pre latinične kopije, da primenjeni fajl bude
        # najnoviji na disku, i skriven (ORIG_SUFFIX)
        if original_bytes is not None:
            orig_name = (f"{plain_key}.{lang_code}{sub_ext}{ORIG_SUFFIX}"
                         if lang_code else f"{plain_key}{sub_ext}{ORIG_SUFFIX}")
            try:
                f = xbmcvfs.File(os.path.join(temp_dir, orig_name), 'wb')
                f.write(bytearray(original_bytes))
                f.close()
                log(f"download: original kept as {orig_name}")
            except Exception as e:
                log(f"download: original not kept ({e})")

        f = None
        try:
            f = xbmcvfs.File(temp_path, 'wb')
            f.write(bytearray(out_bytes))
        except Exception as e:
            log_error(f"download: failed to write temp file: {e}")
            return None
        finally:
            # Fajl se zatvara i kada upis ne uspe
            if f is not None:
                try:
                    f.close()
                except Exception:
                    pass

        log(f"download: saved to {temp_path} ({len(out_bytes)} bytes)")

        return {
            'path':      temp_path,
            'filename':  filename_with_lang,
            'ext':       sub_ext,
            'cyr_ratio': cyr,
        }

    except requests.exceptions.Timeout:
        log_error("download: request timed out")
        return {'timeout': True, 'host': urllib.parse.urlsplit(url).netloc}
    except requests.exceptions.HTTPError as e:
        log_error(f"download: HTTP error: {e}")
    except Exception as e:
        log_error(f"download: {str(e)}")

    return None


# ============================================================
#  DOWNLOAD ACTION
#  Ručni izbor iz liste: addon predaje Kodiju gotov UTF-8 fajl, a
#  smeštaj i ime određuje Kodi.
# ============================================================

def download(params):
    """Preuzima izabrani titl i predaje ga Kodiju. Vraća ime fajla ili ''."""
    try:
        handle = int(sys.argv[1])
    except Exception as e:
        log_error(f"download: invalid handle: {e}")
        return ''

    result = fetch_and_save(params.get('url'),
                            params.get('encoding', ''),
                            params.get('lang_code', ''),
                            params.get('cache_key', ''),
                            params.get('alt_url', ''),
                            to_latin=params.get('latin') == '1')

    name = ''
    tracks_before = subtitle_track_count() if player_is_playing() else -1
    if result and result.get('path'):
        name = result['filename']
        list_item = xbmcgui.ListItem(label=name)
        xbmcplugin.addDirectoryItem(
            handle=handle, url=result['path'],
            listitem=list_item, isFolder=False
        )

    xbmcplugin.endOfDirectory(handle)

    # Kodi dodaje traku tek posle endOfDirectory; uz ugrađene titl trake zna
    # da je ne izabere ili ne uključi prikaz, pa se to proverava ovde. Isti
    # titl izabran ponovo zamenjuje postojeću traku, pa broj traka ne raste.
    key = _file_key(params.get('cache_key', ''))
    rehide = bool(name and key and has_latin_copy(staging_dir(), key))
    if name and tracks_before >= 0:
        if wait_for_subtitle_track(tracks_before, tag='download'):
            select_last_subtitle_track()
            ensure_subtitles_visible()
    elif rehide:
        xbmc.sleep(AUTO_TRACK_WAIT)

    # Kodi do sada ima svoju kopiju fajla, pa se original uz latiničnu kopiju
    # ponovo skriva od drugih addona - bez obzira na ishod čekanja
    if rehide:
        hide_original(staging_dir(), key, params.get('lang_code', ''))
    return name


# ============================================================
#  ENTRY POINT
# ============================================================

def run():
    """
    Ulazna tačka addona - poziva je main.py. Završni red (=== ... DONE ===)
    ispisuje se posle svih pomoćnih niti, kao poslednji red pokretanja.
    """
    done = 'SEARCH DONE'
    try:
        param_string = sys.argv[2][1:] if len(sys.argv) > 2 else ""
        params = dict(urllib.parse.parse_qsl(param_string))
        action = params.get('action')
        done = {'download': 'DOWNLOAD DONE',
                'background': 'BACKGROUND SEARCH DONE',
                'manualsearch': 'MANUAL SEARCH DONE'}.get(action, 'SEARCH DONE')

        # Vraćanje podešavanja koje je prekinuto pokretanje ostavilo ugašenim
        restore_stale_downloadfirst()

        if action == 'download':
            log(f"=== DOWNLOAD START | lang={params.get('lang_code','?')} source={params.get('source','?')} ===")
            done += f" | {download(params) or 'no subtitle'}"
        elif action == 'background':
            log("=== BACKGROUND SEARCH START ===")
            background_search(params)
        elif action == 'manualsearch':
            log(f"=== MANUAL SEARCH START | query='{params.get('searchstring','')}' ===")
            search(params)
        else:
            log("=== SEARCH START ===")
            search(params)

    except Exception as e:
        import traceback
        log_fatal(f"FATAL: {str(e)}\n{traceback.format_exc()}")
        # Pozadinski poziv nema dijalog
        if 'action=background' not in (sys.argv[2] if len(sys.argv) > 2 else ''):
            try:
                handle = int(sys.argv[1])
                xbmcplugin.endOfDirectory(handle)
            except Exception:
                pass
    finally:
        auto_lock_release()
        # Lista je predata Kodiju - čeka se kraj pomoćnih niti
        join_threads()
        log(f"=== {done} ===")
