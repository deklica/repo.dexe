# -*- coding: utf-8 -*-
import os
import sys

import xbmcaddon
import xbmcvfs

_LIB = os.path.join(xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('path')),
                    'resources', 'lib')
if _LIB not in sys.path:
    sys.path.insert(0, _LIB)

import exyusubs  # noqa: E402

exyusubs.run()
