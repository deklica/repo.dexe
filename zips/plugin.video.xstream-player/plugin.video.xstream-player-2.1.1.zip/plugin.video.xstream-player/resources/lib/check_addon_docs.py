﻿# -*- coding: utf-8 -*-
import re

with open('addon.py', 'r', encoding='utf-8') as f:
    lines = f.readlines()

print("=== addon.py (functions missing docstrings) ===")
count = 0
for i, line in enumerate(lines):
    if re.match(r'^def\s+\w+\(', line):
        j = i + 1
        while j < len(lines) and lines[j].strip() == '':
            j += 1
        if j < len(lines):
            next_line = lines[j].strip()
            if not (next_line.startswith('\"\"\"') or next_line.startswith("\"\"\"")):
                count += 1
                print(f"  Line {i+1}: {line.strip()}")
print(f"Total missing: {count}")
