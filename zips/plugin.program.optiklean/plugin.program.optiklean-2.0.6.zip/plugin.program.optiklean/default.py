import sys
import sqlite3
import os
import errno
import fnmatch
import re
import json
import time
from datetime import datetime
from resources.lib import backup_restore

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

try:
    addon_handle = int(sys.argv[1])
except IndexError:
    addon_handle = -1
    
base_url = sys.argv[0]

addon = xbmcaddon.Addon()
# Path to addon_data for storing logs
addon_data_folder = xbmcvfs.translatePath(f"special://profile/addon_data/{addon.getAddonInfo('id')}/")

# Ensure addon_data directory exists
if not xbmcvfs.exists(addon_data_folder):
    xbmcvfs.mkdirs(addon_data_folder)

addon_path = xbmcvfs.translatePath(addon.getAddonInfo("path"))
media_path = f"{addon_path}/resources/media/"
fanart_path = f"{media_path}fanart.jpg"
logo_path = f"{media_path}logo.png"

def ensure_path_format(path):
    """
    Ensures consistent path formatting across different platforms,
    especially for Android where path handling can be tricky.
    """
    # Remove any trailing slashes
    path = path.rstrip('/')
    # Ensure we have exactly one trailing slash
    return path + '/'


# Definisce i percorsi per i file di log
log_files = {
    "clear_kodi_temp_folder": os.path.join(addon_data_folder, "clear_kodi_temp_folder.log"),
    "clear_cache_files_from_addon_data": os.path.join(addon_data_folder, "clear_cache_files_from_addon_data.log"),
    "clear_temp_folders_from_addon_data": os.path.join(addon_data_folder, "clear_temp_folders_from_addon_data.log"),
    "clear_temp_folder_from_addons": os.path.join(addon_data_folder, "clear_temp_folder_from_addons.log"), 
    "clear_unused_thumbnails": os.path.join(addon_data_folder, "clear_unused_thumbnails.log"),
    "clear_older_thumbnails": os.path.join(addon_data_folder, "clear_older_thumbnails.log"),
    "clear_addon_leftovers": os.path.join(addon_data_folder, "clear_addon_leftovers.log"),
    "clear_kodi_packages": os.path.join(addon_data_folder, "clear_kodi_packages.log"),
    "optimize_databases": os.path.join(addon_data_folder, "optimize_databases.log")
}


def get_file_size(file_path):
    """Returns file size in bytes or 0 if file doesn't exist"""
    try:
        if xbmcvfs.exists(file_path):
            file = xbmcvfs.File(file_path)
            size = file.size()
            file.close()
            return size
            
        # Fallback to os.path if xbmcvfs fails
        if os.path.exists(file_path):
            return os.path.getsize(file_path)

    except Exception as e:
        xbmc.log(f"OptiKlean DEBUG: Error getting size for {file_path}: {str(e)}", xbmc.LOGERROR)
    return 0


def get_folder_size(folder_path):
    """Calcola la dimensione totale di una cartella in bytes (cross-platform)"""
    total_size = 0
    
    # Prima prova con xbmcvfs (funziona su tutti i sistemi)
    try:
        dirs, files = xbmcvfs.listdir(folder_path)
        for file in files:
            file_path = xbmcvfs.makeLegalFilename(os.path.join(folder_path, file))
            file_size = get_file_size(file_path)
            total_size += file_size
        
        for dir_name in dirs:
            dir_path = xbmcvfs.makeLegalFilename(os.path.join(folder_path, dir_name))
            total_size += get_folder_size(dir_path)
            
    except Exception as e:
        xbmc.log(f"OptiKlean DEBUG: Error calculating folder size with xbmcvfs: {str(e)}", xbmc.LOGERROR)
        # Fallback a os.walk se xbmcvfs fallisce
        try:
            for root, dirs, files in os.walk(folder_path):
                for f in files:
                    fp = os.path.join(root, f)
                    total_size += os.path.getsize(fp)
        except Exception as e:
            xbmc.log(f"OptiKlean DEBUG: Error calculating folder size with os.walk: {str(e)}", xbmc.LOGERROR)
    
    return total_size


def format_size(bytes):
    """Formatta i bytes in una stringa leggibile (KB, MB, GB)"""
    if bytes >= 1024 * 1024 * 1024:
        return f"{bytes / (1024 * 1024 * 1024):.2f} GB"
    elif bytes >= 1024 * 1024:
        return f"{bytes / (1024 * 1024):.2f} MB"
    elif bytes >= 1024:
        return f"{bytes / 1024:.2f} KB"
    else:
        return f"{bytes} B"


def update_automatic_settings_log():
    """Genera/Aggiorna il log delle impostazioni automatiche con stato e prossima esecuzione"""

    log_path = os.path.join(addon_data_folder, "automatic_cleaning_settings.log")
    cleaning_types = [
        "clear_cache_and_temp",
        "clear_unused_thumbnails",
        "clear_addon_leftovers",
        "clear_kodi_packages",
        "optimize_databases"
    ]

    # Ottieni il formato data/ora dalle impostazioni regionali di Kodi
    date_format = xbmc.getRegion('dateshort')
    time_format = xbmc.getRegion('time').replace('%H', 'HH').replace('%I', 'hh').replace('%M', 'mm')

    # Mappa per convertire i pattern regionali in formato Python
    format_map = {
        'DD': '%d', 'MM': '%m', 'YYYY': '%Y',
        'hh': '%I', 'mm': '%M', 'ss': '%S', 'HH': '%H',
        'AP': '%p' if '%p' in xbmc.getRegion('time') else ''
    }

    # Converti i formati regionali in formato Python
    py_date_format = date_format
    py_time_format = time_format
    for k, v in format_map.items():
        py_date_format = py_date_format.replace(k, v)
        py_time_format = py_time_format.replace(k, v)

    full_format = f"{py_date_format} {py_time_format}"

    log_content = addon.getLocalizedString(31166) + "\n\n"

    for cleaning in cleaning_types:
        enabled = addon.getSettingBool(f"{cleaning}_enable")
        interval_days = addon.getSettingInt(f"{cleaning}_interval")

        if not enabled:
            log_content += f"Automatic {cleaning.replace('_', ' ')} -> disabled\n"
            continue

        # Leggi il file JSON dell'ultima esecuzione
        last_run_file = os.path.join(addon_data_folder, f"last_{cleaning}.json")
        next_run_info = ""

        if xbmcvfs.exists(last_run_file):
            try:
                with open(last_run_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    last_run_timestamp = data.get('timestamp', 0)
                    last_run_human = data.get('human_readable', '')

                    if last_run_timestamp > 0:
                        last_run_local = datetime.fromtimestamp(last_run_timestamp).strftime(full_format)
                        next_run = datetime.fromtimestamp(last_run_timestamp + (interval_days * 86400))
                        next_run_local = next_run.strftime(full_format)
                        day_label = "day" if interval_days == 1 else "days"
                        next_run_info = (
                            f" (set on {last_run_local})\n"
                            f"next run time: {next_run_local} (every {interval_days} {day_label})"
                        )
                    elif last_run_human:
                        next_run_info = f" (set on {last_run_human})\nnext run time: unknown"
            except Exception as e:
                xbmc.log(f"OptiKlean: Error reading {last_run_file}: {str(e)}", xbmc.LOGERROR)
                next_run_info = "\n(last run time unknown)"
        else:
            next_run_info = "\n(first run pending)"

        log_content += f"Automatic {cleaning.replace('_', ' ')} -> enabled{next_run_info}\n\n"

    # Scrivi il file di log usando xbmcvfs
    try:
        file = xbmcvfs.File(log_path, 'w')
        file.write(log_content)
        file.close()
        xbmc.log("OptiKlean: Updated automatic settings log", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"OptiKlean: Error writing automatic settings log: {str(e)}", xbmc.LOGERROR)


def update_last_run(cleaning_type):
    """
    Aggiorna il file JSON con i valori correnti per una determinata opzione attiva.
    """
    try:
        last_run_file = os.path.join(addon_data_folder, f"last_{cleaning_type}.json")
        data = {
            "enabled": addon.getSettingBool(f"{cleaning_type}_enable"),
            "interval": addon.getSettingInt(f"{cleaning_type}_interval"),
            "timestamp": int(time.time()),
            "human_readable": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        with open(last_run_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2)
        xbmc.log(f"OptiKlean: Updated last run info for {cleaning_type}", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"OptiKlean: Failed to update last run for {cleaning_type}: {str(e)}", xbmc.LOGERROR)


def monitor_settings_changes():
    """Monitora le modifiche alle impostazioni e aggiorna il log quando cambiano"""
    try:
        settings_to_monitor = [
            ("clear_cache_and_temp", "enable", "interval"),
            ("clear_unused_thumbnails", "enable", "interval"),
            ("clear_addon_leftovers", "enable", "interval"),
            ("clear_kodi_packages", "enable", "interval"),
            ("optimize_databases", "enable", "interval")
        ]

        settings_changed = False

        for prefix, enable_suffix, interval_suffix in settings_to_monitor:
            current_enable = addon.getSettingBool(f"{prefix}_{enable_suffix}")
            current_interval = addon.getSettingInt(f"{prefix}_{interval_suffix}")

            last_run_file = os.path.join(addon_data_folder, f"last_{prefix}.json")

            if xbmcvfs.exists(last_run_file):
                with open(last_run_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    last_enable = data.get("enabled", False)
                    last_interval = data.get("interval", 7)
            else:
                last_enable = not current_enable
                last_interval = current_interval + 1

            if (current_enable != last_enable) or (current_interval != last_interval):
                settings_changed = True
                if current_enable:
                    update_last_run(prefix)
                else:
                    if xbmcvfs.exists(last_run_file):
                        xbmcvfs.delete(last_run_file)
                        xbmc.log(f"OptiKlean: Eliminato file {last_run_file} perché disabilitato", xbmc.LOGINFO)

        if settings_changed:
            update_automatic_settings_log()
            xbmc.log("OptiKlean: Log impostazioni aggiornato!", xbmc.LOGINFO)

    except Exception as e:
        xbmc.log(f"OptiKlean: Errore nel monitoraggio: {str(e)}", xbmc.LOGERROR)
        

def get_autostart_delay():
    """Returns the autostart delay in seconds from settings"""
    delay_minutes = addon.getSettingInt("autostart_delay")
    return delay_minutes * 60  # Convert to seconds


# Funzione per mostrare il menu principale
def show_menu():
    
    # Set fanart per tutto il menu (sfondo dietro le voci)
    xbmcplugin.setPluginFanart(addon_handle, fanart_path)

    # Mappa azioni -> icone
    icons = {
        "clear_cache_and_temp": f"{media_path}cache.png",
        "clear_unused_thumbnails": f"{media_path}thumbnails.png",
        "clear_addon_leftovers": f"{media_path}leftovers.png",
        "clear_kodi_packages": f"{media_path}packages.png",
        "optimize_databases": f"{media_path}databases.png",
        "all_in_one_panel": f"{media_path}AIO.png",
        "backup_and_restore": f"{media_path}backup_restore.png",
        "view_logs": f"{media_path}logs.png",
        "show_support": f"{media_path}help.png",
        "open_addon_settings": f"{media_path}settings.png"
    }

    menu_items = [
        (addon.getLocalizedString(31043), "clear_cache_and_temp"),
        (addon.getLocalizedString(31044), "clear_unused_thumbnails"),
        (addon.getLocalizedString(31045), "clear_addon_leftovers"),
        (addon.getLocalizedString(31046), "clear_kodi_packages"),
        (addon.getLocalizedString(31047), "optimize_databases"),
        (addon.getLocalizedString(31048), "all_in_one_panel"),
        (addon.getLocalizedString(31049), "backup_and_restore"),
        (addon.getLocalizedString(31050), "view_logs"),
        (addon.getLocalizedString(31051), "show_support"),
        (addon.getLocalizedString(31052), "open_addon_settings")
    ]

    for label, action in menu_items:
        li = xbmcgui.ListItem(label)
        li.setArt({
            "icon": icons.get(action, ""),
            "thumb": icons.get(action, ""),
            "poster": logo_path,
            "fanart": fanart_path
        })
        li.setProperty("fanart_image", fanart_path)

        xbmcplugin.addDirectoryItem(
            handle=addon_handle,
            url=f"{base_url}?action={action}",
            listitem=li,
            isFolder=False
        )

    xbmcplugin.endOfDirectory(addon_handle)

    # Aggiorna il log sia all'apertura che dopo modifiche
    try:
        monitor_settings_changes()  # Prima verifica le modifiche
    except Exception as e:
        xbmc.log(f"OptiKlean: Error updating logs: {str(e)}", xbmc.LOGERROR)


# Funzione helper per scrivere il log
def write_log(log_key, content, append=False):
    """
    Writes content to the specified log file with automatic timestamp footer.
    If append is True, the content will be appended to the file instead of overwriting it.
    """
    def get_localized_datetime():
        """Get current datetime formatted according to Kodi's regional settings"""
        # Get Kodi's time format (12h vs 24h)
        time_format = xbmc.getRegion('time').replace('%H', 'HH').replace('%I', 'hh').replace('%M', 'mm')
        
        # Get date format based on region
        date_format = xbmc.getRegion('dateshort')
        
        # Convert to Python datetime format
        format_map = {
            'DD': '%d', 'MM': '%m', 'YYYY': '%Y',
            'hh': '%I', 'mm': '%M', 'ss': '%S', 'HH': '%H',
            'AP': '%p' if '%p' in xbmc.getRegion('time') else ''
        }
        
        for k, v in format_map.items():
            date_format = date_format.replace(k, v)
            time_format = time_format.replace(k, v)
        
        full_format = f"{date_format} {time_format}"
        return time.strftime(full_format)
    
    log_path = log_files.get(log_key)
    mode = "a" if append else "w"
    
    try:
        with open(log_path, mode, encoding="utf-8") as f:
            f.write(content)
            if not content.endswith('\n'):
                f.write('\n')
            # Fix: content is a string, not a dictionary
            f.write(f"\nDate and time: {get_localized_datetime()}\n")
    except Exception as e:
        xbmc.log(f"Error writing log file {log_path}: {e}", xbmc.LOGERROR)


# Costanti per lo stato di eliminazione file
DELETE_SUCCESS = "success"
DELETE_LOCKED = "locked"
DELETE_ERROR = "error"


# Funzione helper migliorata per eliminare file con rilevamento file lock
def delete_file(file_path, retry_count=2, retry_delay=0.5, progress_dialog=None):
    """
    Delete a file with lock detection and retry logic.
    Returns:
        tuple: (status, error_message)
        status can be: "success", "locked", or "error"
    """
    xbmc.log(f"OptiKlean DEBUG: Attempting to delete file: {file_path}", xbmc.LOGINFO)
    
    if not xbmcvfs.exists(file_path):
        xbmc.log(f"OptiKlean DEBUG: File doesn't exist: {file_path}", xbmc.LOGINFO)
        return DELETE_SUCCESS, ""
    
    # Aggiorna la dialog di progresso se fornita
    if progress_dialog:
        filename = file_path.split('/')[-1] if file_path else ""
        # Fix: use getPercentage() instead of getPercent()
        try:
            percent = progress_dialog.getPercentage()
        except AttributeError:
            # Fallback for older Kodi versions
            percent = 0
        progress_dialog.update(percent, f"Processing: {filename}")
    
    # Rest of the function remains unchanged
    for attempt in range(retry_count + 1):
        try:
            xbmc.log(f"OptiKlean DEBUG: Delete attempt {attempt+1}/{retry_count+1} for {file_path}", xbmc.LOGINFO)
            if xbmcvfs.delete(file_path):
                xbmc.log(f"OptiKlean DEBUG: Successfully deleted file: {file_path}", xbmc.LOGINFO)
                return DELETE_SUCCESS, ""
            else:
                xbmc.log(f"OptiKlean DEBUG: xbmcvfs.delete returned False for {file_path}", xbmc.LOGINFO)
                return DELETE_ERROR, "Failed to delete (unknown error)"
        except OSError as e:
            # Controlla i codici di errore comuni per file bloccati
            if e.errno in (errno.EACCES, errno.EPERM, errno.EBUSY, errno.EAGAIN):
                xbmc.log(f"OptiKlean DEBUG: File locked (attempt {attempt+1}): {file_path} - {e}", xbmc.LOGINFO)
                if attempt < retry_count:
                    time.sleep(retry_delay)
                    continue
                return DELETE_LOCKED, f"File locked: {e}"
            else:
                xbmc.log(f"OptiKlean DEBUG: OS error deleting file: {file_path} - {e}", xbmc.LOGINFO)
                return DELETE_ERROR, f"Error: {e}"
        except Exception as e:
            xbmc.log(f"OptiKlean DEBUG: Unexpected error deleting file: {file_path} - {e}", xbmc.LOGINFO)
            return DELETE_ERROR, f"Unexpected error: {e}"
    
    xbmc.log(f"OptiKlean DEBUG: File appears to be locked after all retry attempts: {file_path}", xbmc.LOGINFO)
    return DELETE_LOCKED, "File appears to be locked by another process"


# Funzione per verificare se è sicuro eliminare un file
def is_safe_to_delete(file_path, temp_path=None, addon_id=None, critical_cache_addons=None):
    """
    Check if a file can be safely deleted
    :param file_path: Full path to the file
    :param temp_path: Path to temp folder (optional)
    :param addon_id: Addon ID (optional)
    :param critical_cache_addons: List of protected addons (optional)
    :return: True if safe to delete, False if protected
    """
    # Files always protected in temp folder
    temp_protected_files = [
        'kodi.log',
        'kodi.old.log',
        'commoncache.db',
        'commoncache.socket'
    ]
    
    # Check if in temp folder
    is_temp_file = temp_path and temp_path in file_path
    
    # 1. Protect specific files in temp folder
    if is_temp_file:
        filename = file_path.split('/')[-1]
        if filename in temp_protected_files:
            return False
        # Skip all other checks for temp folder
        return True
    
    # 2. Protect critical addon caches (only outside temp folder)
    if (
        critical_cache_addons
        and addon_id
        and addon_id in critical_cache_addons
        and (
            "cache" in file_path.lower()
            or "temp" in file_path.lower()
        )
    ):

        return False
    
    # 3. Protect specific extensions (only outside temp folder)
    protected_extensions = ['.db', '.xml', '.json', '.ini', '.cfg']
    if any(file_path.lower().endswith(ext) for ext in protected_extensions):
        return False
        
    return True


# Funzione per verificare se una cartella deve essere esclusa dalla pulizia
def is_excluded_folder(folder_path, temp_path=None):
    """Verifica se una cartella deve essere esclusa dalla pulizia"""
    # Lista di cartelle da escludere - inizialmente vuota
    excluded_folders = []
    
    # Estrai il nome della cartella dal percorso
    folder_name = folder_path.rstrip('/').split('/')[-1]
    
    # Controllo se è una cartella esclusa
    if folder_name in excluded_folders:
        return True
    
    return False


# Funzione per verificare se il percorso è una cache critica da preservare
def is_critical_cache(addon_id, folder_path, critical_cache_addons):
    """Verifica se il percorso è una cache critica da preservare"""
    if addon_id in critical_cache_addons:
        # Per inputstreamhelper, potremmo voler preservare cartelle specifiche
        if addon_id == "script.module.inputstreamhelper":
            # Ad esempio, preservare il contenuto delle sottocartelle "storage" o "download"
            if "storage" in folder_path or "download" in folder_path:
                return True
        # Per default, preserviamo tutte le cache degli addon critici
        return True
    return False


# Funzione per eliminare ricorsivamente file e cartelle in modo sicuro
def delete_directory_recursive(directory_path, progress_dialog=None, parent_results=None):
    """
    Elimina ricorsivamente una cartella e tutti i suoi contenuti.
    - Restituisce True se la cartella è stata eliminata o non esisteva
    - Restituisce False se c'è stato un problema nell'eliminazione
    """

    # Ensure consistent path format
    directory_path = ensure_path_format(directory_path)
    xbmc.log(f"OptiKlean DEBUG: Entering delete_directory_recursive for {directory_path}", xbmc.LOGINFO)   
 
    # Se la cartella non esiste, consideriamo che l'operazione sia riuscita
    if not xbmcvfs.exists(directory_path):
        xbmc.log(f"OptiKlean DEBUG: Directory doesn't exist: {directory_path}", xbmc.LOGINFO)
        return True

    # Inizializza i risultati se non sono stati forniti dal chiamante
    if parent_results is None:
        parent_results = {
            "deleted": [],
            "locked": [],
            "errors": [],
            "protected": []
        }
    
    try:
        # Ottiene liste di file e cartelle
        xbmc.log(f"OptiKlean DEBUG: Attempting to list contents of {directory_path}", xbmc.LOGINFO)
        dirs, files = xbmcvfs.listdir(directory_path)
        xbmc.log(f"OptiKlean DEBUG: Files found in {directory_path}: {files}", xbmc.LOGINFO)
        xbmc.log(f"OptiKlean DEBUG: Subdirectories found in {directory_path}: {dirs}", xbmc.LOGINFO)
        
        # Prima elimina tutti i file
        for file in files:
            file_path = xbmcvfs.makeLegalFilename(ensure_path_format(directory_path) + file)
            xbmc.log(f"OptiKlean DEBUG: Attempting to delete file: {file_path}", xbmc.LOGINFO)
            
            # Aggiorna progresso se fornito
            if progress_dialog:
                # Fix: use getPercentage() with fallback
                try:
                    percent = progress_dialog.getPercentage()
                except AttributeError:
                    percent = 0
                progress_dialog.update(percent, f"Deleting file: {file}")
            
            # Elimina il file
            status, error = delete_file(file_path, progress_dialog=progress_dialog)
            if status == DELETE_SUCCESS:
                parent_results["deleted"].append(file_path)
                xbmc.log(f"OptiKlean DEBUG: Successfully deleted file: {file_path}", xbmc.LOGINFO)
            elif status == DELETE_LOCKED:
                parent_results["locked"].append(f"{file_path} (locked)")
                xbmc.log(f"OptiKlean DEBUG: File is locked: {file_path}", xbmc.LOGINFO)
                return False  # Non possiamo eliminare la cartella se un file è bloccato
            else:
                parent_results["errors"].append(f"{file_path} ({error})")
                xbmc.log(f"OptiKlean DEBUG: Error deleting file: {file_path} - {error}", xbmc.LOGINFO)
                return False  # Non possiamo eliminare la cartella se c'è un errore
        
        # Poi elimina ricorsivamente tutte le sottocartelle
        for folder in dirs:
            folder_path = xbmcvfs.makeLegalFilename(ensure_path_format(directory_path) + folder)
            xbmc.log(f"OptiKlean DEBUG: Processing subfolder: {folder_path}", xbmc.LOGINFO)
            
            # Aggiorna progresso se fornito
            if progress_dialog:
                # Fix: use getPercentage() with fallback
                try:
                    percent = progress_dialog.getPercentage()
                except AttributeError:
                    percent = 0
                progress_dialog.update(percent, f"Processing folder: {folder}")
            
            # Chiamata ricorsiva per eliminare la sottocartella
            subfolder_result = delete_directory_recursive(folder_path, progress_dialog, parent_results)
            xbmc.log(f"OptiKlean DEBUG: Subfolder processing result: {subfolder_result} for {folder_path}", xbmc.LOGINFO)
            if not subfolder_result:
                xbmc.log(f"OptiKlean DEBUG: Failed to process subfolder: {folder_path}", xbmc.LOGINFO)
                return False  # Non possiamo eliminare la cartella principale se una sottocartella non può essere eliminata
        
        # Infine, elimina la cartella stessa
        xbmc.log(f"OptiKlean DEBUG: Attempting to remove directory: {directory_path}", xbmc.LOGINFO)
        if xbmcvfs.rmdir(directory_path):
            parent_results["deleted"].append(f"Deleted folder: {directory_path}")
            xbmc.log(f"OptiKlean DEBUG: Successfully removed directory: {directory_path}", xbmc.LOGINFO)
            return True
        else:
            parent_results["errors"].append(f"Failed to delete folder: {directory_path}")
            xbmc.log(f"OptiKlean DEBUG: Failed to remove directory: {directory_path}", xbmc.LOGINFO)
            return False
    
    except Exception as e:
        xbmc.log(f"OptiKlean DEBUG: Exception in delete_directory_recursive: {str(e)}", xbmc.LOGERROR)
        parent_results["errors"].append(f"Error processing folder {directory_path}: {str(e)}")
        return False


# Funzione per eliminare file e cartelle in modo sicuro con report dei risultati
def delete_files_in_folder(
    folder, 
    progress_dialog=None, 
    safe_check=True,
    addon_id=None, 
    temp_path=None, 
    critical_cache_addons=None,
):
    """
    Elimina file e cartelle in modo sicuro con report dei risultati
    """
    # Ensure consistent path format
    folder = ensure_path_format(folder)
    xbmc.log(f"OptiKlean DEBUG: Starting delete_files_in_folder for {folder}", xbmc.LOGINFO)
    
    results = {
        "deleted": [],
        "locked": [],
        "errors": [],
        "protected": []
    }

    if not xbmcvfs.exists(folder):
        xbmc.log(f"OptiKlean DEBUG: Folder does not exist: {folder}", xbmc.LOGINFO)
        results["errors"].append(f"Folder does not exist: {folder}")
        return results

    try:
        # Ottiene liste separate di cartelle e file
        xbmc.log(f"OptiKlean DEBUG: Attempting to list contents of {folder}", xbmc.LOGINFO)
        dirs, files = xbmcvfs.listdir(folder)
        xbmc.log(f"OptiKlean DEBUG: Directories found in {folder}: {dirs}", xbmc.LOGINFO)
        xbmc.log(f"OptiKlean DEBUG: Files found in {folder}: {files}", xbmc.LOGINFO)
        total_items = len(dirs) + len(files)
        
        # Processa prima i file
        for index, item in enumerate(files):
            if progress_dialog and progress_dialog.iscanceled():
                xbmc.log("OptiKlean DEBUG: Operation canceled by user", xbmc.LOGINFO)
                break

            item_path = xbmcvfs.makeLegalFilename(ensure_path_format(folder) + item)
            xbmc.log(f"OptiKlean DEBUG: Processing file: {item_path}", xbmc.LOGINFO)
            
            # Aggiorna progresso
            if progress_dialog:
                percent = int((index / total_items) * 100) if total_items > 0 else 0
                progress_dialog.update(percent, f"Processing file: {item}")

            if safe_check and not is_safe_to_delete(item_path, temp_path):
                xbmc.log(f"OptiKlean DEBUG: File protected (not safe to delete): {item_path}", xbmc.LOGINFO)
                results["protected"].append(item_path)
                continue

            success, error = delete_file(item_path)
            if success == DELETE_SUCCESS:
                xbmc.log(f"OptiKlean DEBUG: Successfully deleted file: {item_path}", xbmc.LOGINFO)
                results["deleted"].append(item_path)
            elif success == DELETE_LOCKED:
                xbmc.log(f"OptiKlean DEBUG: File is locked: {item_path}", xbmc.LOGINFO)
                results["locked"].append(f"{item_path} (locked)")
            else:
                xbmc.log(f"OptiKlean DEBUG: Error deleting file: {item_path} - {error}", xbmc.LOGINFO)
                results["errors"].append(f"{item_path} ({error})")

        # Poi processa le cartelle
        for index, item in enumerate(dirs, start=len(files)):
            if progress_dialog and progress_dialog.iscanceled():
                xbmc.log("OptiKlean DEBUG: Operation canceled by user", xbmc.LOGINFO)
                break

            item_path = xbmcvfs.makeLegalFilename(ensure_path_format(folder) + item)
            xbmc.log(f"OptiKlean DEBUG: Processing folder: {item_path}", xbmc.LOGINFO)
            
            # Aggiorna progresso
            if progress_dialog:
                percent = int((index / total_items) * 100) if total_items > 0 else 0
                progress_dialog.update(percent, f"Processing folder: {item}")
            
            # Controlla se è una cartella esclusa
            if is_excluded_folder(item_path, temp_path):
                xbmc.log(f"OptiKlean DEBUG: Folder excluded from processing: {item_path}", xbmc.LOGINFO)
                results["protected"].append(f"Excluded folder (protected): {item_path}")
                continue
            
            # Controllo se è una cache critica prima di procedere
            if critical_cache_addons and addon_id and is_critical_cache(addon_id, item_path, critical_cache_addons):
                xbmc.log(f"OptiKlean DEBUG: Folder is a critical cache (protected): {item_path}", xbmc.LOGINFO)
                results["protected"].append(f"Protected cache (critical addon): {item_path}")
                continue

            xbmc.log(f"OptiKlean DEBUG: About to process directory recursively: {item_path}", xbmc.LOGINFO)

            # Elimina ricorsivamente la cartella
            folder_deleted = delete_directory_recursive(item_path, progress_dialog, results)
            xbmc.log(f"OptiKlean DEBUG: Result of recursive deletion: {folder_deleted} for {item_path}", xbmc.LOGINFO)

    except Exception as e:
        xbmc.log(f"OptiKlean DEBUG: Exception in delete_files_in_folder: {str(e)}", xbmc.LOGERROR)
        results["errors"].append(f"Error listing {folder}: {str(e)}")

    xbmc.log(f"OptiKlean DEBUG: Completed delete_files_in_folder for {folder}. Results: deleted={len(results['deleted'])}, locked={len(results['locked'])}, errors={len(results['errors'])}, protected={len(results['protected'])}", xbmc.LOGINFO)
    return results


def map_directory_structure(folder_path):
    """
    Recursively maps the directory structure using xbmcvfs.listdir() with try/except
    Returns a dictionary representing the folder structure or None if path is invalid
    """
    folder_path = ensure_path_format(folder_path)
    structure = {
        'path': folder_path,
        'files': [],
        'subfolders': [],
        'accessible': False
    }
    
    try:
        dirs, files = xbmcvfs.listdir(folder_path)
        structure['accessible'] = True
        structure['files'] = files
        
        xbmc.log(f"OptiKlean DEBUG: Mapped {folder_path} - files: {files}", xbmc.LOGINFO)
        
        for dir_name in dirs:
            # Fix: properly join paths without duplicate base paths
            subfolder_path = ensure_path_format(os.path.join(folder_path, dir_name))
            xbmc.log(f"OptiKlean DEBUG: Processing subfolder: {subfolder_path}", xbmc.LOGINFO)
            subfolder_structure = map_directory_structure(subfolder_path)
            if subfolder_structure:
                structure['subfolders'].append(subfolder_structure)
                xbmc.log(f"OptiKlean DEBUG: Added subfolder {subfolder_path} with {len(subfolder_structure['files'])} files and {len(subfolder_structure['subfolders'])} subfolders", xbmc.LOGINFO)
                
    except Exception as e:
        xbmc.log(f"OptiKlean DEBUG: Error mapping directory {folder_path}: {str(e)}", xbmc.LOGERROR)
        structure['accessible'] = False
        
    return structure if structure['accessible'] else None


def clear_kodi_temp_folder(temp_path, progress_dialog=None, critical_cache_addons=None, safe_check=True):
    """
    Clears the Kodi temp folder while preserving log files and critical caches
    Returns dictionary with results (deleted, locked, errors, protected)
    """
    results = {
        "deleted": [],
        "locked": [],
        "errors": [],
        "protected": [],
        "total_size": 0
    }

    # Folders that are created by Kodi itself everytime so don't need to be deleted
    protected_folders = ["temp", "archive_cache"]  # These are in special://temp/
    
    temp_path = ensure_path_format(temp_path)
    xbmc.log(f"OptiKlean DEBUG: Starting clear_kodi_temp_folder for {temp_path} with safe_check={safe_check}", xbmc.LOGINFO)
    
    try:
        # First map the entire directory structure
        progress_dialog and progress_dialog.update(0, "Mapping temp folder structure...")
        folder_structure = map_directory_structure(temp_path)
        
        if not folder_structure:
            results["errors"].append(f"Could not access temp folder: {temp_path}")
            xbmc.log("OptiKlean DEBUG: Could not map temp folder structure", xbmc.LOGERROR)
            return results
        
        xbmc.log(f"OptiKlean DEBUG: Completed mapping temp folder structure. Root files: {len(folder_structure['files'])}, Subfolders: {len(folder_structure['subfolders'])}", xbmc.LOGINFO)
        
        # Process all files in the root first - ALWAYS protect log files regardless of safe_check
        for file_name in folder_structure['files']:
            if progress_dialog and progress_dialog.iscanceled():
                break
                
            file_path = os.path.join(temp_path, file_name)
            xbmc.log(f"OptiKlean DEBUG: Processing root file: {file_path}", xbmc.LOGINFO)
            
            # First check if this is a protected file (like kodi.log)
            if not is_safe_to_delete(file_path, temp_path):
                xbmc.log(f"OptiKlean DEBUG: Protected file skipped: {file_path}", xbmc.LOGINFO)
                results["protected"].append(file_path)
                continue
            
            # Get file size BEFORE deletion
            file_size = get_file_size(file_path) or 0
                
            status, error = delete_file(file_path, progress_dialog=progress_dialog)
            if status == DELETE_SUCCESS:
                results["deleted"].append((file_path, file_size))  # Store as tuple with size
                results["total_size"] += file_size
                xbmc.log(f"OptiKlean DEBUG: Successfully deleted file: {file_path} (size: {file_size} bytes)", xbmc.LOGINFO)
            elif status == DELETE_LOCKED:
                results["locked"].append(file_path)
            else:
                results["errors"].append(f"{file_path} ({error})")
    
        # Then process all subfolders recursively
        def process_folder(folder, parent_results):
            full_path = folder['path']
            xbmc.log(f"OptiKlean DEBUG: Processing folder: {full_path}", xbmc.LOGINFO)
            
            # Skip excluded folders
            if is_excluded_folder(full_path, temp_path):
                xbmc.log(f"OptiKlean DEBUG: Excluded folder skipped: {full_path}", xbmc.LOGINFO)
                parent_results["protected"].append(f"Excluded folder: {full_path}")
                return True
                
            # Get folder name and relative path
            folder_name = full_path.rstrip('/').split('/')[-1]
                  
            if (folder_name in protected_folders):
                xbmc.log(f"OptiKlean DEBUG: Protected folder in temp - processing contents only: {full_path}", xbmc.LOGINFO)
                
                # Process files in this folder
                for file_name in folder['files']:
                    if progress_dialog and progress_dialog.iscanceled():
                        return False
                        
                    file_path = os.path.join(full_path, file_name)
                    xbmc.log(f"OptiKlean DEBUG: Processing file: {file_path}", xbmc.LOGINFO)
                    
                    if safe_check and not is_safe_to_delete(file_path, temp_path):
                        xbmc.log(f"OptiKlean DEBUG: Protected file skipped: {file_path}", xbmc.LOGINFO)
                        parent_results["protected"].append(file_path)
                        continue
                    
                    # Get file size BEFORE deletion
                    file_size = get_file_size(file_path) or 0
                        
                    status, error = delete_file(file_path, progress_dialog=progress_dialog)
                    if status == DELETE_SUCCESS:
                        parent_results["deleted"].append((file_path, file_size))  # Store as tuple
                        parent_results["total_size"] += file_size
                        xbmc.log(f"OptiKlean DEBUG: Successfully deleted file: {file_path} (size: {file_size} bytes)", xbmc.LOGINFO)
                    elif status == DELETE_LOCKED:
                        parent_results["locked"].append(file_path)
                    else:
                        parent_results["errors"].append(f"{file_path} ({error})")
                
                # Process all subfolders recursively
                for subfolder in folder['subfolders']:
                    process_folder(subfolder, parent_results)
                
                return True            

            # Process files in this folder (for non-protected folders)
            for file_name in folder['files']:
                if progress_dialog and progress_dialog.iscanceled():
                    return False
                    
                file_path = os.path.join(full_path, file_name)
                xbmc.log(f"OptiKlean DEBUG: Processing file: {file_path}", xbmc.LOGINFO)
                
                # Only check protected files if safe_check is True (for non-root files)
                if safe_check and not is_safe_to_delete(file_path, temp_path):
                    xbmc.log(f"OptiKlean DEBUG: Protected file skipped: {file_path}", xbmc.LOGINFO)
                    parent_results["protected"].append(file_path)
                    continue

                # Get file size BEFORE deletion
                file_size = get_file_size(file_path) or 0
                
                status, error = delete_file(file_path, progress_dialog=progress_dialog)

                if status == DELETE_SUCCESS:
                    parent_results["deleted"].append((file_path, file_size))  # Store as tuple
                    parent_results["total_size"] += file_size
                    xbmc.log(f"OptiKlean DEBUG: Successfully deleted file: {file_path} (size: {file_size} bytes)", xbmc.LOGINFO)
                elif status == DELETE_LOCKED:
                    parent_results["locked"].append(file_path)
                else:
                    parent_results["errors"].append(f"{file_path} ({error})")
            
            # Process all subfolders recursively
            for subfolder in folder['subfolders']:
                process_folder(subfolder, parent_results)
                
            # Try to delete the folder itself if empty
            try:
                dirs, files = xbmcvfs.listdir(full_path)
                if not dirs and not files:
                    if xbmcvfs.rmdir(full_path):
                        parent_results["deleted"].append((f"Deleted folder: {full_path}", 0))  # Store as tuple with size 0
                        xbmc.log(f"OptiKlean DEBUG: Successfully deleted folder: {full_path}", xbmc.LOGINFO)
                    else:
                        parent_results["errors"].append(f"Failed to delete folder: {full_path}")
                        xbmc.log(f"OptiKlean DEBUG: Failed to delete folder: {full_path} (may not be empty)", xbmc.LOGINFO)
                else:
                    remaining = len(dirs) + len(files)
                    parent_results["errors"].append(f"Folder not empty: {full_path} ({remaining} items remaining)")
                    xbmc.log(f"OptiKlean DEBUG: Folder not empty, contains {remaining} items: {full_path}", xbmc.LOGINFO)
            except Exception as e:
                parent_results["errors"].append(f"Error deleting folder {full_path}: {str(e)}")
                xbmc.log(f"OptiKlean DEBUG: Exception deleting folder {full_path}: {str(e)}", xbmc.LOGERROR)
                
            return True
        
        # Process all top-level folders (this will recursively process their contents)
        for folder in folder_structure['subfolders']:
            if progress_dialog and progress_dialog.iscanceled():
                break
            process_folder(folder, results)
        
    except Exception as e:
        results["errors"].append(f"General error in clear_kodi_temp_folder: {str(e)}")
        xbmc.log(f"OptiKlean DEBUG: General error in clear_kodi_temp_folder: {str(e)}", xbmc.LOGERROR)
    
    xbmc.log(f"OptiKlean DEBUG: Completed clear_kodi_temp_folder. Results: deleted={len(results['deleted'])}, locked={len(results['locked'])}, errors={len(results['errors'])}, protected={len(results['protected'])}", xbmc.LOGINFO)
    return results


def clear_cache_and_temp(auto_mode=False):

    # Inizializza il totale cumulativo
    total_freed_all_options = 0

    # Opzioni:
    # 0: Clear Kodi temp folder (preserving log files)
    # 1: Clear cache files from addon data
    # 2: Clear temp folders from addon data
    # 3: Clear temp folder from addons
    choices = [
        addon.getLocalizedString(31070),
        addon.getLocalizedString(31071),
        addon.getLocalizedString(31072),
        addon.getLocalizedString(31073)
    ]
    
    temp_path = ensure_path_format(xbmcvfs.translatePath("special://temp/"))
    addon_data_path = ensure_path_format(xbmcvfs.translatePath("special://profile/addon_data/"))

    if not auto_mode:
        selected = xbmcgui.Dialog().multiselect(addon.getLocalizedString(31053), choices)  # "Select cache/temp to clear"
        if selected is None:
            return
    else:
        # Modalità automatica: applica il ritardo se impostato prima di iniziare
        delay_seconds = get_autostart_delay()
        if delay_seconds > 0:
            xbmc.log(f"OptiKlean: Automatic cleaning delayed by {delay_seconds} seconds", xbmc.LOGINFO)
            time.sleep(delay_seconds)
        
        selected = [0, 1, 2, 3]
  
    # Lista di addon con cache essenziali da non cancellare
    critical_cache_addons = [
        "script.module.inputstreamhelper",
        "inputstream.adaptive",
        "inputstream.rtmp",
        "script.module.resolveurl",
        "plugin.video.youtube",
        'plugin.video.netflix',
        'plugin.video.amazon',
        'plugin.video.disneyplus',
        'script.common.plugin.cache',
        'pvr.iptvsimple'
    ]
    
    progress = xbmcgui.DialogProgress()
    progress.create("OptiKlean", addon.getLocalizedString(31055))  # "Preparing to clear cache..."
    
    try:
        # Opzione 0: Clear Kodi temp folder (preserving logs)
        if selected and 0 in selected:
            start_time = time.perf_counter()
            progress.update(0, addon.getLocalizedString(31082))  # "Clearing Kodi temp folder (preserving log files)..."
            
            # Log che stiamo iniziando l'operazione
            xbmc.log("OptiKlean: Starting to clear Kodi temp folder", xbmc.LOGINFO)
            xbmc.log(f"OptiKlean: Using temp path: {temp_path}", xbmc.LOGINFO)
            
            # Use safe_check=False to delete all files except protected ones
            results = clear_kodi_temp_folder(temp_path, progress, 
                                          critical_cache_addons=critical_cache_addons,
                                          safe_check=True)
                                          
            total_freed_all_options += results.get("total_size", 0)
            
            # Verifica effettiva prima di segnare come completato
            if results and (results.get("deleted") or results.get("total_size", 0) > 0):
                xbmc.log(f"OptiKlean: Temp folder cleanup successful, deleted {len(results.get('deleted', []))} items", xbmc.LOGINFO)
            else:
                xbmc.log("OptiKlean: Temp folder cleanup didn't delete any files", xbmc.LOGINFO)

            log_content = addon.getLocalizedString(31093) + "\n\n"  # "Kodi temp folder cleaning results:"
            
            if results["deleted"]:
                # Separate files and folders, calculate precise total
                deleted_files = []
                deleted_folders = []
                total_bytes = 0
                
                for item in results["deleted"]:
                    if isinstance(item, tuple):
                        file_path, file_size = item
                        if "Deleted folder:" in file_path:  # It's a folder entry
                            _, full_path = file_path.split(":", 1)
                            folder_name = os.path.basename(full_path.strip().rstrip("/"))
                            deleted_folders.append(folder_name)
                        elif file_size > 0:  # It's a file with size
                            deleted_files.append((os.path.basename(file_path), file_size))
                            total_bytes += file_size
                
                # Precise size conversion (bytes → MB)
                total_mb = total_bytes / (1024 * 1024)
                
                # Build log output
                if deleted_files:
                    log_content += addon.getLocalizedString(31098).format(count=len(deleted_files), size=total_mb) + "\n"  # "Files deleted: {count} ({size:.3f} MB freed)"
                    for filename, size in deleted_files:
                        if size >= 1048576:  # ≥1MB
                            log_content += f"  - {filename} ({size/1048576:.3f} MB)\n"
                        elif size >= 1024:  # ≥1KB
                            log_content += f"  - {filename} ({size/1024:.3f} KB)\n"
                        else:
                            log_content += f"  - {filename} ({size} B)\n"
                
                if deleted_folders:
                    log_content += "\n" + addon.getLocalizedString(31099).format(count=len(deleted_folders)) + "\n"  # "Folders deleted: {count}"
                    for folder in deleted_folders:
                        log_content += f"  - {folder}\n"
                
                log_content += "\n"
            
            if results["locked"]:
                log_content += addon.getLocalizedString(31100) + "\n"  # "Files in use (locked):"
                log_content += "  " + "\n  ".join([os.path.basename(f) for f in results["locked"]]) + "\n\n"
            
            if results["errors"]:
                log_content += addon.getLocalizedString(31101) + "\n"  # "Errors:"
                log_content += "  " + "\n  ".join(results["errors"]) + "\n\n"
            
            if results["protected"]:
                log_content += addon.getLocalizedString(31102) + "\n"  # "Protected items (not deleted):"
                protected_items = [os.path.basename(f) for f in results["protected"][:20]]
                log_content += "  " + "\n  ".join(protected_items)
                if len(results["protected"]) > 20:
                    log_content += "\n  " + addon.getLocalizedString(31103).format(count=len(results["protected"]) - 20)  # "... and {count} more items"
                log_content += "\n\n"

            # Log completion
            xbmc.log(f"OptiKlean: Completed clearing Kodi temp folder. Deleted: {len(results['deleted'])}, Protected: {len(results['protected'])}, Errors: {len(results['errors'])}", xbmc.LOGINFO)
            execution_time = round(time.perf_counter() - start_time, 2)
            log_content += addon.getLocalizedString(31104).format(time=execution_time) + "\n"  # "Running time: {time}s"
            write_log("clear_kodi_temp_folder", log_content.rstrip() + "\n")

        # Opzione 1: Clear cache files from addon data
        if selected and 1 in selected and not progress.iscanceled():
            start_time = time.perf_counter()
            progress.update(0, addon.getLocalizedString(31077))  # "Scanning addon data..."
            
            log_content = addon.getLocalizedString(31094) + "\n\n"  # "Addon cache folders cleaning results:"
            xbmc.log("OptiKlean: Starting addon cache cleaning", xbmc.LOGINFO)
            total_size_freed = 0
            option1_size_freed = 0

            if not xbmcvfs.exists(addon_data_path):
                error_msg = f"Addon data path does not exist: {addon_data_path}"
                xbmc.log(f"OptiKlean: {error_msg}", xbmc.LOGERROR)
                log_content += error_msg + "\n"
            else:
                try:
                    addon_folders, _ = xbmcvfs.listdir(addon_data_path)
                    xbmc.log(f"OptiKlean: Found {len(addon_folders)} addon folders", xbmc.LOGINFO)
                    
                    if not addon_folders:
                        log_content += addon.getLocalizedString(31106) + "\n"
                    else:
                        total_addons = len(addon_folders)
                        has_skips = False

                        for index, addon_id in enumerate(addon_folders):
                            if progress.iscanceled():
                                break
                            
                            progress.update((index * 100) // total_addons, addon.getLocalizedString(31090).format(addon_id=addon_id))  # "Checking {addon_id}..."
                            
                            # Skip critical addons
                            if addon_id in critical_cache_addons:
                                if not has_skips:
                                    log_content += "\n"
                                    has_skips = True
                                log_content += addon.getLocalizedString(31107).format(addon_id=addon_id) + "\n"
                                continue
                            
                            cache_path = xbmcvfs.makeLegalFilename(f"{addon_data_path}/{addon_id}/cache/")
                            
                            if xbmcvfs.exists(cache_path):
                                try:
                                    _, files = xbmcvfs.listdir(cache_path)
                                    addon_deleted = []
                                    addon_size_freed = 0
                                    addon_errors = []
                                    addon_protected = []

                                    for file_name in files:
                                        if progress.iscanceled():
                                            break
                                            
                                        file_path = xbmcvfs.makeLegalFilename(f"{cache_path}/{file_name}")
                                        
                                        # Get file size before deletion
                                        file_size = get_file_size(file_path) or 0
                                        
                                        xbmc.log(f"OptiKlean DEBUG: File {file_path} size: {file_size} bytes", xbmc.LOGDEBUG)
                                        
                                        if is_safe_to_delete(file_path, addon_id=addon_id, 
                                                          critical_cache_addons=critical_cache_addons):
                                            status, error = delete_file(file_path)
                                            
                                            if status == DELETE_SUCCESS:
                                                addon_deleted.append((file_name, file_size))
                                                addon_size_freed += file_size
                                                total_size_freed += file_size
                                                option1_size_freed += file_size
                                                
                                                xbmc.log(f"OptiKlean DEBUG: Successfully deleted {file_path}, added {file_size} bytes to total", xbmc.LOGDEBUG)
                                            elif status == DELETE_LOCKED:
                                                addon_errors.append(f"Locked: {file_name}")
                                            else:
                                                addon_errors.append(f"Error: {file_name} ({error})")
                                        else:
                                            addon_protected.append(file_name)
                                    
                                    # Add results to log
                                    if addon_deleted or addon_errors or addon_protected:
                                        log_content += f"{addon_id} (cache):\n"
                                        
                                        if addon_deleted:
                                            size_kb = addon_size_freed / 1024
                                            log_content += addon.getLocalizedString(31108).format(count=len(addon_deleted), size=size_kb) + "\n"
                                            for file_name, file_size in addon_deleted:
                                                size_str = f"{file_size/1024:.2f}KB" if file_size >= 1024 else f"{file_size}B"
                                                log_content += f"    - {file_name} ({size_str})\n"
                                        
                                        if addon_protected:
                                            log_content += addon.getLocalizedString(31109).format(count=len(addon_protected)) + "\n"
                                            for file_name in addon_protected:
                                                log_content += f"    - {file_name}\n"
                                        
                                        if addon_errors:
                                            log_content += addon.getLocalizedString(31110).format(count=len(addon_errors)) + "\n"
                                            for error in addon_errors:
                                                log_content += f"    - {error}\n"
                                        
                                        log_content += "\n"
                                
                                except Exception as e:
                                    log_content += f"{addon_id} ERROR: {str(e)}\n"
                    
                except Exception as e:
                    log_content += f"Error listing addon_data: {str(e)}\n"

            xbmc.log(f"OptiKlean DEBUG: Total size freed in option 1: {total_size_freed} bytes ({total_size_freed/1024/1024:.2f} MB)", xbmc.LOGINFO)

            # Add total at the end (after all addon entries)
            if total_size_freed > 0:
                total_mb = total_size_freed / (1024 * 1024)
                log_content += addon.getLocalizedString(31111).format(size=total_mb) + "\n\n"

                total_freed_all_options += option1_size_freed

            execution_time = round(time.perf_counter() - start_time, 2)
            log_content += addon.getLocalizedString(31104).format(time=execution_time) + "\n"
            write_log("clear_cache_files_from_addon_data", log_content.rstrip() + "\n")
            
        # Opzione 2: Clear temp folders from addon data
        if selected and 2 in selected and not progress.iscanceled():
            start_time = time.perf_counter()
            progress.update(0, addon.getLocalizedString(31078))  # "Preparing to clear addon data temp folders..."
            total_size_freed = 0
            option2_size_freed = 0
            
            log_content = addon.getLocalizedString(31095) + "\n\n"  # "Addon temp folders cleaning results:"
            xbmc.log("OptiKlean: Starting addon temp folders cleaning", xbmc.LOGINFO)
            xbmc.log(f"OptiKlean: Using addon_data path: {addon_data_path}", xbmc.LOGINFO)
            
            if not xbmcvfs.exists(addon_data_path):
                error_msg = f"Addon data path does not exist: {addon_data_path}"
                xbmc.log(f"OptiKlean: {error_msg}", xbmc.LOGERROR)
                log_content += error_msg + "\n"
            else:
                try:
                    addon_folders, _ = xbmcvfs.listdir(addon_data_path)
                    xbmc.log(f"OptiKlean: Found {len(addon_folders)} addon folders", xbmc.LOGINFO)
                    
                    if not addon_folders:
                        log_content += addon.getLocalizedString(31106) + "\n"
                        xbmc.log("OptiKlean: No addon folders found", xbmc.LOGINFO)
                    else:
                        total_addons = len(addon_folders)
                        has_skips = False
                        last_was_skip = False
                        total_size_freed = 0
                        
                        for index, addon_id in enumerate(addon_folders):
                            if progress.iscanceled():
                                break
                            
                            progress.update((index * 100) // total_addons, addon.getLocalizedString(31090).format(addon_id=addon_id))
                            xbmc.log(f"OptiKlean: Processing addon {addon_id}", xbmc.LOGINFO)
                            
                            if addon_id in critical_cache_addons:
                                skip_msg = addon.getLocalizedString(31107).format(addon_id=addon_id)
                                if not has_skips:
                                    log_content = log_content.rstrip() + "\n\n"
                                    has_skips = True
                                log_content += skip_msg + "\n"
                                last_was_skip = True
                                xbmc.log(f"OptiKlean: {skip_msg}", xbmc.LOGINFO)
                                continue
                            
                            last_was_skip = False
                            
                            for temp_folder in ['temp', 'tmp']:
                                temp_path = xbmcvfs.makeLegalFilename(f"{addon_data_path}/{addon_id}/{temp_folder}/")
                                xbmc.log(f"OptiKlean: Checking for {temp_folder} at {temp_path}", xbmc.LOGINFO)
                                
                                if xbmcvfs.exists(temp_path):
                                    try:
                                        _, files = xbmcvfs.listdir(temp_path)
                                        xbmc.log(f"OptiKlean: Found {len(files)} files in {temp_folder}", xbmc.LOGINFO)
                                        
                                        deleted = []
                                        protected = []
                                        errors = []
                                        addon_size_freed = 0
                                        
                                        for file_name in files:
                                            if progress.iscanceled():
                                                break
                                                
                                            file_path = xbmcvfs.makeLegalFilename(f"{temp_path}/{file_name}")
                                            xbmc.log(f"OptiKlean: Processing file {file_path}", xbmc.LOGINFO)
                                            
                                            file_size = get_file_size(file_path) or 0
                                            
                                            if is_safe_to_delete(file_path, addon_id=addon_id, 
                                                              critical_cache_addons=critical_cache_addons):
                                                status, error = delete_file(file_path)
                                                if status == DELETE_SUCCESS:
                                                    if xbmcvfs.exists(file_path):
                                                        error_msg = f"File still exists after deletion: {file_path}"
                                                        xbmc.log(f"OptiKlean: {error_msg}", xbmc.LOGWARNING)
                                                        errors.append(f"Verify failed: {file_name}")
                                                    else:
                                                        xbmc.log(f"OptiKlean: Successfully deleted {file_path} ({file_size} bytes)", xbmc.LOGINFO)
                                                        deleted.append((file_name, file_size))
                                                        addon_size_freed += file_size
                                                        total_size_freed += file_size
                                                        option2_size_freed += file_size
                                                elif status == DELETE_LOCKED:
                                                    error_msg = f"Failed to delete {file_path} (locked)"
                                                    xbmc.log(f"OptiKlean: {error_msg}", xbmc.LOGWARNING)
                                                    errors.append(f"Locked: {file_name}")
                                                else:
                                                    error_msg = f"Failed to delete {file_path} ({error})"
                                                    xbmc.log(f"OptiKlean: {error_msg}", xbmc.LOGERROR)
                                                    errors.append(f"Error: {file_name} ({error})")
                                            else:
                                                xbmc.log(f"OptiKlean: Protected file {file_path}", xbmc.LOGINFO)
                                                protected.append(file_name)
                                        
                                        if has_skips and not last_was_skip and (deleted or protected or errors):
                                            log_content += "\n"
                                        
                                        if deleted or protected or errors:
                                            log_content += f"{addon_id} ({temp_folder}):\n"
                                            
                                            if deleted:
                                                size_kb = addon_size_freed / 1024
                                                log_content += addon.getLocalizedString(31108).format(count=len(deleted), size=size_kb) + "\n"
                                                for file_name, file_size in deleted:
                                                    size_str = f"{file_size/1024:.2f}KB" if file_size >= 1024 else f"{file_size}B"
                                                    log_content += f"    - {file_name} ({size_str})\n"
                                            
                                            if protected:
                                                log_content += addon.getLocalizedString(31109).format(count=len(protected)) + "\n"
                                                for file_name in protected:
                                                    log_content += f"    - {file_name}\n"
                                            
                                            if errors:
                                                log_content += addon.getLocalizedString(31110).format(count=len(errors)) + "\n"
                                                for error in errors:
                                                    log_content += f"    - {error}\n"
                                            
                                            log_content += "\n"
                                    
                                    except Exception as e:
                                        error_msg = f"Error processing {addon_id} {temp_folder}: {str(e)}"
                                        log_content += f"{addon_id} {temp_folder} ERROR: {error_msg}\n"
                                        xbmc.log(f"OptiKlean: {error_msg}", xbmc.LOGERROR)
                                else:
                                    xbmc.log(f"OptiKlean: No {temp_folder} folder found for {addon_id}", xbmc.LOGINFO)
                    
                    # Move total space freed to the end of the log
                    if total_size_freed > 0:
                        size_mb = total_size_freed / (1024 * 1024)
                        log_content += f"Total space freed: {size_mb:.2f} MB\n\n"
                        
                        total_freed_all_options += option2_size_freed

                except Exception as e:
                    error_msg = f"Error listing addon_data folder: {str(e)}"
                    log_content += error_msg + "\n"
                    xbmc.log(f"OptiKlean: {error_msg}", xbmc.LOGERROR)

            execution_time = round(time.perf_counter() - start_time, 2)
            log_content += addon.getLocalizedString(31104).format(time=execution_time) + "\n"
            write_log("clear_temp_folders_from_addon_data", log_content.rstrip() + "\n")

        # Opzione 3: Clear temp folder from addons
        if selected and 3 in selected and not progress.iscanceled():
            start_time = time.perf_counter()
            progress.update(0, addon.getLocalizedString(31079))  # "Preparing to clear addons temp folder..."
            option3_size_freed = 0
            
            log_content = addon.getLocalizedString(31096) + "\n\n"  # "Addons temp folder cleaning results:"
            xbmc.log("OptiKlean DEBUG: Starting clear addons temp folder", xbmc.LOGINFO)
            
            addons_temp_path = ensure_path_format(xbmcvfs.translatePath("special://home/addons/temp/"))
            xbmc.log(f"OptiKlean DEBUG: Using addons temp path: {addons_temp_path}", xbmc.LOGINFO)
            
            if not xbmcvfs.exists(addons_temp_path):
                error_msg = f"Addons temp folder does not exist: {addons_temp_path}"
                xbmc.log(f"OptiKlean DEBUG: {error_msg}", xbmc.LOGERROR)
                log_content += error_msg + "\n"
            else:
                # First map the directory structure
                progress.update(10, addon.getLocalizedString(31084))
                folder_structure = map_directory_structure(addons_temp_path)
                
                if not folder_structure:
                    error_msg = f"Could not access addons temp folder: {addons_temp_path}"
                    xbmc.log(f"OptiKlean DEBUG: {error_msg}", xbmc.LOGERROR)
                    log_content += error_msg + "\n"
                else:
                    xbmc.log(f"OptiKlean DEBUG: Found {len(folder_structure['files'])} files and {len(folder_structure['subfolders'])} subfolders in addons temp", xbmc.LOGINFO)
                    
                    results = {
                        "deleted": [],
                        "locked": [],
                        "errors": [],
                        "protected": [],
                        "total_size": 0
                    }
                    
                    def process_folder(folder, parent_results):
                        nonlocal option3_size_freed
                        full_path = folder['path']
                        xbmc.log(f"OptiKlean DEBUG: Processing folder: {full_path}", xbmc.LOGINFO)
                        
                        # Process files in this folder
                        for file_name in folder['files']:
                            if progress.iscanceled():
                                return False
                                
                            file_path = os.path.join(full_path, file_name)
                            xbmc.log(f"OptiKlean DEBUG: Processing file: {file_path}", xbmc.LOGINFO)
                            
                            if not is_safe_to_delete(file_path, addons_temp_path):
                                xbmc.log(f"OptiKlean DEBUG: Protected file skipped: {file_path}", xbmc.LOGINFO)
                                parent_results["protected"].append(file_path)
                                continue
                            
                            file_size = get_file_size(file_path) or 0
                            status, error = delete_file(file_path, progress_dialog=progress)

                            if status == DELETE_SUCCESS:
                                parent_results["deleted"].append((file_path, file_size))
                                parent_results["total_size"] += file_size
                                option3_size_freed += file_size
                                xbmc.log(f"OptiKlean DEBUG: Successfully deleted file: {file_path} (size: {file_size} bytes)", xbmc.LOGINFO)
                            elif status == DELETE_LOCKED:
                                parent_results["locked"].append(file_path)
                                xbmc.log(f"OptiKlean DEBUG: File is locked: {file_path}", xbmc.LOGINFO)
                            else:
                                parent_results["errors"].append(f"{file_path} ({error})")
                                xbmc.log(f"OptiKlean DEBUG: Error deleting file: {file_path} - {error}", xbmc.LOGERROR)
                        
                        # Process all subfolders recursively
                        for subfolder in folder['subfolders']:
                            process_folder(subfolder, parent_results)
                        
                        return True
                    
                    # Process all top-level folders
                    for folder in folder_structure['subfolders']:
                        if progress.iscanceled():
                            break
                        process_folder(folder, results)
                    
                    # Process files in root folder
                    for file_name in folder_structure['files']:
                        if progress.iscanceled():
                            break
                            
                        file_path = os.path.join(addons_temp_path, file_name)
                        xbmc.log(f"OptiKlean DEBUG: Processing root file: {file_path}", xbmc.LOGINFO)
                        
                        if not is_safe_to_delete(file_path, addons_temp_path):
                            xbmc.log(f"OptiKlean DEBUG: Protected file skipped: {file_path}", xbmc.LOGINFO)
                            results["protected"].append(file_path)
                            continue

                        # Get size BEFORE deletion
                        file_size = get_file_size(file_path) or 0
                        status, error = delete_file(file_path, progress_dialog=progress)
                            
                        if status == DELETE_SUCCESS:
                            results["deleted"].append((file_path, file_size))  # Store as tuple with size
                            results["total_size"] += file_size
                            option3_size_freed += file_size
                            xbmc.log(f"OptiKlean DEBUG: Successfully deleted file: {file_path} (size: {file_size} bytes)", xbmc.LOGINFO)
                        elif status == DELETE_LOCKED:
                            results["locked"].append(file_path)
                            xbmc.log(f"OptiKlean DEBUG: File is locked: {file_path}", xbmc.LOGINFO)
                        else:
                            results["errors"].append(f"{file_path} ({error})")
                            xbmc.log(f"OptiKlean DEBUG: Error deleting file: {file_path} - {error}", xbmc.LOGERROR)
                    
                    # Generate log content
                    if results["deleted"]:
                        size_mb = results["total_size"] / (1024 * 1024)
                        total_freed_all_options += option3_size_freed
                        log_content += addon.getLocalizedString(31175).format(count=len(results['deleted']), size=size_mb) + "\n"
                        for item in results["deleted"]:
                            if isinstance(item, tuple):
                                file_path, file_size = item
                                filename = os.path.basename(file_path)
                                size_str = f"{file_size/1024:.2f}KB" if file_size >= 1024 else f"{file_size}B"
                                log_content += f"- {filename} ({size_str})\n"
                            else:
                                # Handle folder deletion messages
                                if "Deleted folder:" in item:
                                    folder_name = item.split(":")[1].strip().split('/')[-1]
                                    log_content += f"- [Folder] {folder_name}\n"
                                else:
                                    log_content += f"- {item}\n"
                        log_content += "\n"

                    if results["locked"]:
                        log_content += addon.getLocalizedString(31176).format(count=len(results['locked'])) + "\n"
                        for item in results["locked"]:
                            log_content += f"- {os.path.basename(item)}\n"
                        log_content += "\n"

                    if results["errors"]:
                        log_content += f"Errors ({len(results['errors'])}):\n"
                        for error in results["errors"]:
                            # Try to extract filename from error messages
                            if "Error in" in error:
                                path_part = error.split(':')[0].strip()
                                filename = os.path.basename(path_part)
                                log_content += f"- {filename}: {error.split(':', 1)[1].strip()}\n"
                            else:
                                log_content += f"- {error}\n"
                        log_content += "\n"

                    if results["protected"]:
                        log_content += addon.getLocalizedString(31102) + "\n"
                        for item in results["protected"]:
                            log_content += f"- {os.path.basename(item)}\n"
                        log_content += "\n"
                    
                    xbmc.log(f"OptiKlean DEBUG: Addons temp cleanup completed. Deleted: {len(results['deleted'])}, Locked: {len(results['locked'])}, Errors: {len(results['errors'])}, Protected: {len(results['protected'])}", xbmc.LOGINFO)
                        
            execution_time = round(time.perf_counter() - start_time, 2)
            log_content += "\n" + addon.getLocalizedString(31104).format(time=execution_time) + "\n"
            write_log("clear_temp_folder_from_addons", log_content.rstrip() + "\n")
            
        # Show notification if any option was selected and completed
        if selected:
            total_mb = total_freed_all_options / (1024 * 1024)
            notification_msg = addon.getLocalizedString(31056).format(total_mb=total_mb)  # "Clear cache and temp completed! ({total_mb:.2f} MB freed)"
            xbmcgui.Dialog().notification("OptiKlean", notification_msg, logo_path, 3000)

            # Aggiorna i log delle impostazioni automatiche solo se:
            # 1. Non è in modalità automatica
            # 2. Almeno una pulizia è stata completata con successo
            # 3. La pulizia automatica è abilitata nelle impostazioni
            if not auto_mode and addon.getSettingBool("clear_cache_and_temp_enable"):
                try:
                    update_last_run("clear_cache_and_temp")
                    update_automatic_settings_log()
                    xbmc.log("OptiKlean: Updated automatic cleaning logs after manual execution", xbmc.LOGINFO)
                except Exception as e:
                    xbmc.log(f"OptiKlean: Error updating automatic logs: {str(e)}", xbmc.LOGERROR)
        
    except Exception as e:
        error_msg = f"Unexpected error during cleanup: {str(e)}"
        xbmc.log(error_msg, xbmc.LOGERROR)
        xbmcgui.Dialog().notification("OptiKlean", addon.getLocalizedString(31057), xbmcgui.NOTIFICATION_ERROR, 5000)  # "Error during cleanup, see log"
                
    finally:
        progress.close()


# Funzione per trovare il database delle texture
def find_texture_database(db_path):
    """
    Trova il database delle texture più recente in modo dinamico, compatibile con tutte le versioni di Kodi.
    """
    xbmc.log(f"OptiKlean DEBUG: Entering find_texture_database with path: {db_path}", xbmc.LOGINFO)
    
    # Ensure proper path format (no double slashes)
    db_path = db_path.replace('//', '/')
    
    if not xbmcvfs.exists(db_path):
        xbmc.log(f"OptiKlean DEBUG: Database path does not exist: {db_path}", xbmc.LOGINFO)
        return None

    # Pattern per identificare i database delle texture
    texture_pattern = "Textures*.db"
    xbmc.log(f"OptiKlean DEBUG: Looking for files matching pattern: {texture_pattern}", xbmc.LOGINFO)

    # Cerca tutti i file nella directory database
    _, files = xbmcvfs.listdir(db_path)
    xbmc.log(f"OptiKlean DEBUG: All files in database directory: {files}", xbmc.LOGINFO)
    
    matching_files = [f for f in files if fnmatch.fnmatch(f, texture_pattern)]
    xbmc.log(f"OptiKlean DEBUG: Matching texture database files: {matching_files}", xbmc.LOGINFO)

    if not matching_files:
        xbmc.log("OptiKlean DEBUG: No texture database files found", xbmc.LOGINFO)
        return None  # Nessun database texture trovato

    # Converti i nomi dei file in numeri e ordina per versione (Textures13.db, Textures14.db, ...)
    def extract_version(filename):
        match = re.search(r"Textures(\d+)\.db", filename)
        version = int(match.group(1)) if match else 0
        xbmc.log(f"OptiKlean DEBUG: Extracted version {version} from file {filename}", xbmc.LOGINFO)
        return version

    matching_files.sort(key=extract_version, reverse=True)
    xbmc.log(f"OptiKlean DEBUG: Sorted texture database files: {matching_files}", xbmc.LOGINFO)

    # Restituisce il database più recente - Fix path to avoid double slashes
    latest_db = matching_files[0]
    full_path = xbmcvfs.translatePath(f"{db_path}{latest_db}")
    full_path = full_path.replace('//', '/')  # Ensure no double slashes
    xbmc.log(f"OptiKlean DEBUG: Selected latest texture database: {full_path}", xbmc.LOGINFO)
    return full_path


# Funzione per cancellare le thumbnails non più utilizzate
def clear_unused_thumbnails(auto_mode=False):
    xbmc.log("OptiKlean DEBUG: Starting clear_unused_thumbnails", xbmc.LOGINFO)
    start_time = time.perf_counter()
    
    # Se non è in modalità automatica, mostra la finestra di selezione
    if not auto_mode:
        choices = [
            addon.getLocalizedString(31074),  # "Clear unused thumbnails"
            addon.getLocalizedString(31075)   # "Clear thumbnails older than 30 days"
        ]
        
        selected = xbmcgui.Dialog().multiselect(addon.getLocalizedString(31054), choices)  # "Select thumbnail cleaning options"
        if selected is None or len(selected) == 0:
            return
    else:
        # Modalità automatica: applica il ritardo se impostato prima di iniziare
        delay_seconds = get_autostart_delay()
        if delay_seconds > 0:
            xbmc.log(f"OptiKlean: Automatic thumbnails cleaning delayed by {delay_seconds} seconds", xbmc.LOGINFO)
            time.sleep(delay_seconds)
        
        # In modalità automatica, esegui entrambe le pulizie per una manutenzione completa
        selected = [0, 1]  # unused + older than 30 days
    
    progress = xbmcgui.DialogProgress()
    progress.create("OptiKlean", addon.getLocalizedString(31076))  # "Preparing thumbnails cleanup..."
    
    # Inizializza variabili comuni
    db_path = ensure_path_format(xbmcvfs.translatePath("special://database/"))
    standard_thumb_path = ensure_path_format(xbmcvfs.translatePath("special://userdata/Thumbnails/"))
    alt_thumb_path = ensure_path_format(xbmcvfs.translatePath("special://thumbnails/"))

    skin_base = ensure_path_format(xbmcvfs.translatePath("special://skin/"))
    skin_subfolders = ["thumbnails/", "media/Thumbnails/", "extras/Thumbnails/"]
    skin_thumb_paths = [ensure_path_format(os.path.join(skin_base, sub)) for sub in skin_subfolders]

    thumb_paths = [p for p in [standard_thumb_path, alt_thumb_path] if xbmcvfs.exists(p)] + [
        p for p in skin_thumb_paths if xbmcvfs.exists(p)
    ]

    for p in thumb_paths:
        xbmc.log(f"OptiKlean DEBUG: Thumbnail path added: {p}", xbmc.LOGINFO)

    if not thumb_paths:
        xbmc.log("OptiKlean DEBUG: No valid thumbnail paths found", xbmc.LOGERROR)
        progress.close()
        
        error_msg = addon.getLocalizedString(31058) + "\n"  # "Thumbnails folder not found."
        if 0 in selected:  # Clear unused thumbnails
            execution_time = round(time.perf_counter() - start_time, 2)
            error_msg += f"\n{addon.getLocalizedString(31104).format(time=execution_time)}\n"  # "Running time: {time}s"
            write_log("clear_unused_thumbnails", error_msg)
        
        if 1 in selected:  # Clear older thumbnails
            execution_time = round(time.perf_counter() - start_time, 2)
            error_msg += f"\n{addon.getLocalizedString(31104).format(time=execution_time)}\n"  # "Running time: {time}s"
            write_log("clear_older_thumbnails", error_msg)
        
        xbmcgui.Dialog().notification("OptiKlean", addon.getLocalizedString(31058), xbmcgui.NOTIFICATION_ERROR, 3000)  # "Thumbnails folder not found."
        return

    def clear_older_thumbnails_internal(thumb_paths, progress_dialog, start_progress, end_progress, days_threshold=30):
        """
        Elimina le thumbnails più vecchie di X giorni usando la tabella sizes del database delle texture
        e rimuove anche le righe corrispondenti dal database
        """
        # Calcola il timestamp di soglia (X giorni fa)
        threshold_timestamp = int(time.time()) - (days_threshold * 86400)
        # Converti in formato datetime per il confronto SQL
        threshold_datetime = datetime.fromtimestamp(threshold_timestamp).strftime("%Y-%m-%d %H:%M:%S")
        
        texture_db = find_texture_database(db_path)
        if not texture_db:
            xbmc.log("OptiKlean DEBUG: Texture database not found for older thumbnails cleanup", xbmc.LOGERROR)
            return [], [], [], 0, 0, 0
        
        deleted = []
        locked = []
        errors = []
        total_size_freed = 0
        deleted_db_sizes = 0
        deleted_db_texture = 0
        
        try:
            # Connetti al database delle texture
            conn = sqlite3.connect(texture_db)
            cursor = conn.cursor()
            
            # Verifica la struttura del database
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
            tables = [row[0] for row in cursor.fetchall()]
            
            xbmc.log(f"OptiKlean DEBUG: Available tables in texture database: {tables}", xbmc.LOGINFO)
            
            if 'sizes' not in tables or 'texture' not in tables:
                xbmc.log("OptiKlean DEBUG: Required tables (sizes, texture) not found in database", xbmc.LOGERROR)
                conn.close()
                return [], [], [], 0, 0, 0
            
            # Verifica le colonne delle tabelle
            cursor.execute("PRAGMA table_info(sizes)")
            sizes_columns = [col[1] for col in cursor.fetchall()]
            cursor.execute("PRAGMA table_info(texture)")
            texture_columns = [col[1] for col in cursor.fetchall()]
            
            xbmc.log(f"OptiKlean DEBUG: Sizes table columns: {sizes_columns}", xbmc.LOGINFO)
            xbmc.log(f"OptiKlean DEBUG: Texture table columns: {texture_columns}", xbmc.LOGINFO)
            
            # Verifica che le colonne necessarie esistano
            required_sizes_cols = ['idtexture', 'lastusetime']
            required_texture_cols = ['id', 'cachedurl']
            
            if not all(col in sizes_columns for col in required_sizes_cols):
                xbmc.log(f"OptiKlean DEBUG: Missing required columns in sizes table. Required: {required_sizes_cols}, Found: {sizes_columns}", xbmc.LOGERROR)
                conn.close()
                return [], [], [], 0, 0, 0
                
            if not all(col in texture_columns for col in required_texture_cols):
                xbmc.log(f"OptiKlean DEBUG: Missing required columns in texture table. Required: {required_texture_cols}, Found: {texture_columns}", xbmc.LOGERROR)
                conn.close()
                return [], [], [], 0, 0, 0
            
            # Query per trovare le thumbnails più vecchie di X giorni
            # Facciamo un JOIN tra sizes e texture per ottenere direttamente cachedurl
            query = """
                SELECT t.id, t.cachedurl, s.lastusetime
                FROM sizes s
                INNER JOIN texture t ON s.idtexture = t.id
                WHERE s.lastusetime < ?
            """
            
            xbmc.log(f"OptiKlean DEBUG: Executing query with threshold: {threshold_datetime}", xbmc.LOGINFO)
            cursor.execute(query, (threshold_datetime,))
            old_thumbnails = cursor.fetchall()
            
            xbmc.log(f"OptiKlean DEBUG: Found {len(old_thumbnails)} thumbnails older than {days_threshold} days", xbmc.LOGINFO)
            
            if len(old_thumbnails) == 0:
                xbmc.log("OptiKlean DEBUG: No old thumbnails found", xbmc.LOGINFO)
                conn.close()
                return [], [], [], 0, 0, 0
            
            # Processa ogni thumbnail trovata
            for index, (texture_id, cachedurl, lastusetime) in enumerate(old_thumbnails):
                if progress_dialog and progress_dialog.iscanceled():
                    xbmc.log("OptiKlean DEBUG: User canceled old thumbnails cleanup", xbmc.LOGINFO)
                    break
                    
                # Calcola progresso nell'intervallo assegnato
                progress_range = end_progress - start_progress
                percent = start_progress + int((index / len(old_thumbnails)) * progress_range) if len(old_thumbnails) > 0 else end_progress
                
                if progress_dialog:
                    progress_dialog.update(percent, f"Processing old thumbnail {index+1}/{len(old_thumbnails)}")
                
                # Calcola l'età in giorni per il log
                try:
                    last_use_dt = datetime.strptime(lastusetime, "%Y-%m-%d %H:%M:%S")
                    days_old = (datetime.now() - last_use_dt).days
                except Exception as e:
                    xbmc.log(f"OptiKlean DEBUG: Error parsing lastusetime '{lastusetime}': {str(e)}", xbmc.LOGWARNING)
                    days_old = -1
                
                xbmc.log(f"OptiKlean DEBUG: Processing thumbnail ID {texture_id}, cachedurl: {cachedurl}, last used: {lastusetime} ({days_old} days ago)", xbmc.LOGINFO)
                
                # Cerca il file thumbnail nei percorsi possibili
                thumbnail_found = False
                file_deleted = False
                file_size = 0
                
                for base_path in thumb_paths:
                    # Costruisci il percorso completo: base_path + cachedurl
                    # cachedurl è già nel formato "4/4bfd5855.jpg"
                    thumb_file_path = xbmcvfs.makeLegalFilename(f"{base_path}{cachedurl}")
                    
                    if xbmcvfs.exists(thumb_file_path):
                        thumbnail_found = True
                        xbmc.log(f"OptiKlean DEBUG: Found thumbnail file: {thumb_file_path}", xbmc.LOGINFO)
                        
                        # Ottieni dimensione prima della cancellazione
                        file_size = get_file_size(thumb_file_path) or 0
                        
                        # Elimina il file
                        status, error = delete_file(thumb_file_path)
                        
                        if status == DELETE_SUCCESS:
                            deleted.append((thumb_file_path, file_size))
                            total_size_freed += file_size
                            file_deleted = True
                            xbmc.log(f"OptiKlean DEBUG: Deleted old thumbnail: {cachedurl} ({days_old} days old, size: {file_size} bytes)", xbmc.LOGINFO)
                        elif status == DELETE_LOCKED:
                            locked.append(thumb_file_path)
                            xbmc.log(f"OptiKlean DEBUG: Locked old thumbnail: {cachedurl}", xbmc.LOGINFO)
                        else:
                            errors.append(f"{thumb_file_path} ({error})")
                            xbmc.log(f"OptiKlean DEBUG: Error deleting old thumbnail: {cachedurl} - {error}", xbmc.LOGERROR)
                        break
                
                # Elimina le righe dal database indipendentemente dal fatto che il file fisico sia stato trovato/eliminato
                # Questo perché il file potrebbe essere già stato eliminato manualmente ma le righe nel database rimangono
                try:
                    # Elimina dalla tabella sizes
                    cursor.execute("DELETE FROM sizes WHERE idtexture=?", (texture_id,))
                    deleted_sizes_rows = cursor.rowcount
                    deleted_db_sizes += deleted_sizes_rows
                    
                    # Elimina dalla tabella texture
                    cursor.execute("DELETE FROM texture WHERE id=?", (texture_id,))
                    deleted_texture_rows = cursor.rowcount
                    deleted_db_texture += deleted_texture_rows
                    
                    xbmc.log(f"OptiKlean DEBUG: Deleted database entries for texture ID {texture_id}: {deleted_sizes_rows} from sizes, {deleted_texture_rows} from texture", xbmc.LOGINFO)
                    
                except sqlite3.Error as db_error:
                    error_msg = f"Database deletion error for texture ID {texture_id}: {str(db_error)}"
                    errors.append(error_msg)
                    xbmc.log(f"OptiKlean DEBUG: {error_msg}", xbmc.LOGERROR)
                
                if not thumbnail_found:
                    xbmc.log(f"OptiKlean DEBUG: Thumbnail file not found on disk: {cachedurl} (database entry will still be removed)", xbmc.LOGDEBUG)
            
            # Commit delle modifiche al database e ottimizzazione
            try:
                conn.commit()
                xbmc.log("OptiKlean DEBUG: Database changes committed", xbmc.LOGINFO)
                
                # Ottimizza il database per ridurre le dimensioni fisiche
                if progress_dialog:
                    progress_dialog.update(end_progress - 5, "Optimizing database...")
                
                cursor.execute("VACUUM")
                xbmc.log("OptiKlean DEBUG: Database vacuumed successfully", xbmc.LOGINFO)
                
            except sqlite3.Error as db_error:
                error_msg = f"Database commit/vacuum error: {str(db_error)}"
                errors.append(error_msg)
                xbmc.log(f"OptiKlean DEBUG: {error_msg}", xbmc.LOGERROR)
            
            conn.close()
            
            xbmc.log(f"OptiKlean DEBUG: Old thumbnails cleanup completed. Files deleted: {len(deleted)}, Locked: {len(locked)}, Errors: {len(errors)}, Size freed: {total_size_freed} bytes, DB entries removed: {deleted_db_sizes} from sizes, {deleted_db_texture} from texture", xbmc.LOGINFO)
            
            return deleted, locked, errors, total_size_freed, deleted_db_sizes, deleted_db_texture
            
        except sqlite3.Error as e:
            if 'conn' in locals():
                conn.close()
            xbmc.log(f"OptiKlean DEBUG: Database error in clear_older_thumbnails_internal: {str(e)}", xbmc.LOGERROR)
            return [], [], [], 0, 0, 0
        except Exception as e:
            if 'conn' in locals():
                conn.close()
            xbmc.log(f"OptiKlean DEBUG: Error in clear_older_thumbnails_internal: {str(e)}", xbmc.LOGERROR)
            return [], [], [], 0, 0, 0

    try:
        # Esegui Clear unused thumbnails se selezionato
        if 0 in selected:
            xbmc.log("OptiKlean DEBUG: Executing unused thumbnails cleanup", xbmc.LOGINFO)
            
            log_content_unused = "Unused thumbnails cleaning results:\n\n"
            
            texture_db = find_texture_database(db_path)
            xbmc.log(f"OptiKlean DEBUG: Texture database path: {texture_db}", xbmc.LOGINFO)

            if not texture_db:
                xbmc.log("OptiKlean DEBUG: Texture database not found.", xbmc.LOGERROR)
                progress.update(100, addon.getLocalizedString(31203))  # "Texture database not found."
                log_content_unused += "Texture database not found.\n"
                execution_time = round(time.perf_counter() - start_time, 2)
                log_content_unused += f"\nRunning time: {execution_time}s\n"
                write_log("clear_unused_thumbnails", log_content_unused)
                if not auto_mode:
                    xbmcgui.Dialog().notification("OptiKlean", addon.getLocalizedString(31156), xbmcgui.NOTIFICATION_ERROR, 3000)
                if len(selected) == 1:  # Se è l'unica opzione selezionata, esci
                    return
            else:
                progress.update(10, addon.getLocalizedString(31157))
                conn = sqlite3.connect(texture_db)
                cursor = conn.cursor()
                cursor.execute("SELECT cachedurl FROM texture")
                rows = cursor.fetchall()
                conn.close()

                valid_thumbs = set()
                missing_thumbs = 0

                for row in rows:
                    full_path = row[0]
                    found = False
                    for base_path in thumb_paths:
                        thumb_path_item = xbmcvfs.makeLegalFilename(f"{base_path}{full_path}")
                        if xbmcvfs.exists(thumb_path_item):
                            valid_thumbs.add(thumb_path_item)
                            found = True
                            break
                    if not found:
                        missing_thumbs += 1
                        xbmc.log(f"OptiKlean DEBUG: Missing thumbnail: {full_path}", xbmc.LOGDEBUG)

                progress.update(20, addon.getLocalizedString(31204))  # "Counting thumbnails..."

                def count_files(path):
                    total = 0
                    try:
                        dirs, files = xbmcvfs.listdir(path)
                        total += len(files)
                        for d in dirs:
                            sub_path = xbmcvfs.makeLegalFilename(f"{path}/{d}")
                            total += count_files(sub_path)
                    except Exception as e:
                        xbmc.log(f"OptiKlean DEBUG: Error counting files in {path}: {str(e)}", xbmc.LOGERROR)
                    return total

                total_files = sum(count_files(p) for p in thumb_paths)

                # Determina l'intervallo di progresso per questa operazione
                start_prog = 30
                end_prog = 65 if 1 in selected else 100
                
                progress.update(start_prog, addon.getLocalizedString(31205))  # "Deleting unused thumbnails..."
                deleted, locked, errors, processed_files, total_size_freed = [], [], [], 0, 0

                def recursive_thumbnail_cleanup(thumb_path, valid_thumbs, progress_dialog, total_files, processed_files, start_progress, end_progress):
                    xbmc.log(f"OptiKlean DEBUG: Entering recursive_thumbnail_cleanup for path: {thumb_path}", xbmc.LOGINFO)
                    deleted = []
                    locked = []
                    errors = []
                    size_freed = 0
                    
                    try:
                        dirs, files = xbmcvfs.listdir(thumb_path)
                        
                        for file in files:
                            if progress_dialog and progress_dialog.iscanceled():
                                return deleted, locked, errors, processed_files, size_freed

                            file_path = xbmcvfs.makeLegalFilename(f"{thumb_path}/{file}")
                            processed_files += 1
                            
                            # Calcola il progresso nell'intervallo assegnato
                            progress_range = end_progress - start_progress
                            percent = start_progress + int((processed_files / total_files) * progress_range) if total_files > 0 else end_progress
                            progress_dialog.update(percent, f"Checking: {file[:20]}...")
                            
                            if file_path not in valid_thumbs:
                                # Get file size BEFORE deletion
                                file_size = get_file_size(file_path) or 0
                                status, error = delete_file(file_path)
                                if status == DELETE_SUCCESS:
                                    deleted.append((file_path, file_size))
                                    size_freed += file_size
                                    xbmc.log(f"OptiKlean DEBUG: Deleted {file_path} (size: {file_size} bytes)", xbmc.LOGINFO)
                                elif status == DELETE_LOCKED:
                                    locked.append(file_path)
                                    xbmc.log(f"OptiKlean DEBUG: File locked: {file_path}", xbmc.LOGINFO)
                                else:
                                    errors.append(f"{file_path} ({error})")
                                    xbmc.log(f"OptiKlean DEBUG: Error deleting {file_path}: {error}", xbmc.LOGERROR)

                        for dir_name in dirs:
                            sub_path = xbmcvfs.makeLegalFilename(f"{thumb_path}/{dir_name}")
                            sub_deleted, sub_locked, sub_errors, processed_files, sub_size = recursive_thumbnail_cleanup(
                                sub_path, valid_thumbs, progress_dialog, total_files, processed_files, start_progress, end_progress
                            )
                            deleted.extend(sub_deleted)
                            locked.extend(sub_locked)
                            errors.extend(sub_errors)
                            size_freed += sub_size

                    except Exception as e:
                        xbmc.log(f"OptiKlean DEBUG: Exception in recursive_thumbnail_cleanup: {str(e)}", xbmc.LOGERROR)
                        errors.append(f"Error in {thumb_path}: {str(e)}")

                    return deleted, locked, errors, processed_files, size_freed

                current_index = 0
                for path in thumb_paths:
                    del_, lock_, err_, proc_, size_ = recursive_thumbnail_cleanup(
                        path, valid_thumbs, progress, total_files, current_index, start_prog, end_prog
                    )
                    deleted.extend(del_)
                    locked.extend(lock_)
                    errors.extend(err_)
                    processed_files += proc_
                    total_size_freed += size_
                    current_index = processed_files

                # Calculate total size freed in MB
                total_mb = total_size_freed / (1024 * 1024)
                
                log_content_unused += f"Deleted: {len(deleted)} ({total_mb:.2f} MB freed)\n"
                log_content_unused += f"Locked: {len(locked)}\n"
                log_content_unused += f"Errors: {len(errors)}\n\n"
                xbmc.log(f"Valid thumbs in DB: {len(valid_thumbs)}", level=xbmc.LOGINFO)
                xbmc.log(f"Missing thumbs: {missing_thumbs}", level=xbmc.LOGINFO)

                if deleted:
                    log_content_unused += addon.getLocalizedString(31158) + "\n"
                    for file_path, file_size in deleted:
                        filename = os.path.basename(file_path)
                        if file_size >= 1024 * 1024:
                            size_str = f"{file_size/(1024*1024):.2f}MB"
                        elif file_size >= 1024:
                            size_str = f"{file_size/1024:.2f}KB"
                        else:
                            size_str = f"{file_size}B"
                        log_content_unused += f"    - {filename} ({size_str})\n"
                    log_content_unused += "\n"

                if locked:
                    log_content_unused += addon.getLocalizedString(31159) + "\n"
                    for file_path in locked:
                        log_content_unused += f"    - {os.path.basename(file_path)}\n"
                    log_content_unused += "\n"

                if errors:
                    log_content_unused += addon.getLocalizedString(31101) + "\n"
                    for error in errors:
                        if "Error in" in error:
                            parts = error.split(':')
                            if len(parts) > 1:
                                path_part = parts[0].strip()
                                filename = os.path.basename(path_part)
                                log_content_unused += f"    - {filename}: {':'.join(parts[1:]).strip()}\n"
                            else:
                                log_content_unused += f"    - {error}\n"
                        else:
                            log_content_unused += f"    - {error}\n"
                    log_content_unused += "\n"

                xbmc.log(f"OptiKlean DEBUG: Unused thumbnail cleanup completed. Freed {total_mb:.2f} MB", xbmc.LOGINFO)

            execution_time_unused = round(time.perf_counter() - start_time, 2)
            log_content_unused += "\n" + addon.getLocalizedString(31104).format(time=execution_time_unused) + "\n"
            write_log("clear_unused_thumbnails", log_content_unused)

        # Esegui Clear thumbnails older than 30 days se selezionato
        if 1 in selected:
            xbmc.log("OptiKlean DEBUG: Executing older thumbnails cleanup", xbmc.LOGINFO)
            
            log_content_older = addon.getLocalizedString(31160) + "\n\n"
            
            # Determina l'intervallo di progresso per questa operazione
            start_prog = 70 if 0 in selected else 30
            end_prog = 100
            
            progress.update(start_prog, addon.getLocalizedString(31206))  # "Deleting thumbnails older than 30 days..."
            
            deleted_older, locked_older, errors_older, total_size_freed_older, deleted_db_sizes, deleted_db_texture = clear_older_thumbnails_internal(
                thumb_paths, progress, start_prog, end_prog, 30
            )
            
            # Calculate total size freed in MB
            total_mb_older = total_size_freed_older / (1024 * 1024)
            
            log_content_older += addon.getLocalizedString(31161) + "\n"
            log_content_older += addon.getLocalizedString(31162).format(count=len(deleted_older), size=total_mb_older) + "\n"
            log_content_older += addon.getLocalizedString(31163).format(sizes=deleted_db_sizes, texture=deleted_db_texture) + "\n"
            log_content_older += f"Locked: {len(locked_older)}\n"
            log_content_older += f"Errors: {len(errors_older)}\n\n"

            if deleted_older:
                log_content_older += addon.getLocalizedString(31164) + "\n"
                for file_path, file_size in deleted_older:
                    filename = os.path.basename(file_path)
                    if file_size >= 1024 * 1024:
                        size_str = f"{file_size/(1024*1024):.2f}MB"
                    elif file_size >= 1024:
                        size_str = f"{file_size/1024:.2f}KB"
                    else:
                        size_str = f"{file_size}B"
                    log_content_older += f"    - {filename} ({size_str})\n"
                log_content_older += "\n"

            if locked_older:
                log_content_older += addon.getLocalizedString(31159) + "\n"
                for file_path in locked_older:
                    log_content_older += f"    - {os.path.basename(file_path)}\n"
                log_content_older += "\n"

            if errors_older:
                log_content_older += addon.getLocalizedString(31101) + "\n"
                for error in errors_older:
                    if "Error in" in error:
                        parts = error.split(':')
                        if len(parts) > 1:
                            path_part = parts[0].strip()
                            filename = os.path.basename(path_part)
                            log_content_older += f"    - {filename}: {':'.join(parts[1:]).strip()}\n"
                        else:
                            log_content_older += f"    - {error}\n"
                    else:
                        log_content_older += f"    - {error}\n"
                log_content_older += "\n"

            xbmc.log(f"OptiKlean DEBUG: Older thumbnail cleanup completed. Freed {total_mb_older:.2f} MB", xbmc.LOGINFO)
            
            execution_time_older = round(time.perf_counter() - start_time, 2)
            log_content_older += "\n" + addon.getLocalizedString(31104).format(time=execution_time_older) + "\n"
            write_log("clear_older_thumbnails", log_content_older)

        progress.update(100, addon.getLocalizedString(31207))  # "Finishing..."
        
        # Aggiorna i log delle impostazioni automatiche solo se:
        # 1. Non è in modalità automatica
        # 2. La pulizia automatica è abilitata nelle impostazioni
        # 3. È stata eseguita la pulizia delle thumbnails non utilizzate (opzione 0)
        if not auto_mode and 0 in selected and addon.getSettingBool("clear_unused_thumbnails_enable"):
            try:
                update_last_run("clear_unused_thumbnails")
                update_automatic_settings_log()
                xbmc.log("OptiKlean: Updated automatic cleaning logs after manual execution", xbmc.LOGINFO)
            except Exception as e:
                xbmc.log(f"OptiKlean: Error updating automatic logs: {str(e)}", xbmc.LOGERROR)

    except Exception as e:
        xbmc.log(f"OptiKlean DEBUG: Critical error in clear_unused_thumbnails: {str(e)}", xbmc.LOGERROR)
        error_content = f"Critical error: {str(e)}"
        if 0 in selected:
            write_log("clear_unused_thumbnails", error_content)
        if 1 in selected:
            write_log("clear_older_thumbnails", error_content)

    finally:
        progress.close()
        
        # Crea messaggi di notifica basati su cosa è stato eseguito
        if 0 in selected and 1 in selected:
            # Entrambe le operazioni
            total_deleted = len(deleted) + len(deleted_older) if 'deleted' in locals() and 'deleted_older' in locals() else 0
            total_mb_combined = (total_size_freed + total_size_freed_older) / (1024 * 1024) if 'total_size_freed' in locals() and 'total_size_freed_older' in locals() else 0
            notification_msg = addon.getLocalizedString(31177).format(total_deleted=total_deleted, total_mb_combined=total_mb_combined)
        elif 0 in selected:
            # Solo thumbnails non utilizzate
            if 'deleted' in locals() and 'total_mb' in locals():
                notification_msg = addon.getLocalizedString(31178).format(len_deleted=len(deleted), total_mb=total_mb)
            else:
                notification_msg = addon.getLocalizedString(31179)
        elif 1 in selected:
            # Solo thumbnails vecchie
            if 'deleted_older' in locals() and 'total_mb_older' in locals():
                notification_msg = addon.getLocalizedString(31180).format(len_deleted_older=len(deleted_older), total_mb_older=total_mb_older)
            else:
                notification_msg = addon.getLocalizedString(31181)
        else:
            notification_msg = addon.getLocalizedString(31182)
        
        xbmc.log("OptiKlean DEBUG: Finished clear_unused_thumbnails function", xbmc.LOGINFO)
        xbmcgui.Dialog().notification("OptiKlean", notification_msg, logo_path, 5000)


def delete_folder(folder_path, progress_dialog=None):
    """
    Delete a folder and all its contents using hybrid xbmcvfs + os approach.
    Returns tuple: (status, locked_files, error_message)
    status can be: DELETE_SUCCESS, DELETE_LOCKED, or DELETE_ERROR
    """
    # Normalize path for all platforms
    folder_path = os.path.normpath(folder_path)
    if not folder_path.endswith(os.sep):
        folder_path += os.sep
    
    xbmc.log(f"OptiKlean DEBUG: Attempting to delete folder: {folder_path}", xbmc.LOGINFO)
    
    # Hybrid existence check
    def path_exists(path):
        # First try xbmcvfs
        if xbmcvfs.exists(path):
            return True
        # Fallback to os.path
        return os.path.exists(path)
    
    if not path_exists(folder_path):
        xbmc.log(f"OptiKlean DEBUG: Folder does not exist: {folder_path}", xbmc.LOGINFO)
        return DELETE_SUCCESS, [], "Folder does not exist"

    locked_files = []
    
    try:
        # Get list of contents using best available method
        def list_contents(path):
            try:
                # First try xbmcvfs
                dirs, files = xbmcvfs.listdir(path)
                return dirs, files
            except Exception as e:
                xbmc.log(f"OptiKlean DEBUG: xbmcvfs.listdir failed: {str(e)}", xbmc.LOGERROR)
                # Fallback to os.listdir
                try:
                    all_items = os.listdir(path)
                    dirs = [d for d in all_items if os.path.isdir(os.path.join(path, d))]
                    files = [f for f in all_items if not os.path.isdir(os.path.join(path, f))]
                    return dirs, files
                except Exception as e:
                    xbmc.log(f"OptiKlean DEBUG: Error listing contents: {str(e)}", xbmc.LOGERROR)
                    raise

        # Delete files first
        dirs, files = list_contents(folder_path)
        xbmc.log(f"OptiKlean DEBUG: Found {len(files)} files and {len(dirs)} subdirectories", xbmc.LOGINFO)
        
        for file in files:
            if progress_dialog and progress_dialog.iscanceled():
                return DELETE_ERROR, [], "Operation cancelled by user"
                
            file_path = os.path.join(folder_path, file)
            if progress_dialog:
                try:
                    percent = progress_dialog.getPercentage()
                    progress_dialog.update(percent, f"Deleting file: {file}")
                except AttributeError:
                    pass
            
            # Hybrid delete approach
            status = DELETE_ERROR
            error_msg = ""
            
            # First try xbmcvfs
            try:
                if xbmcvfs.delete(file_path):
                    status = DELETE_SUCCESS
                else:
                    # Fallback to os.remove
                    try:
                        os.remove(file_path)
                        status = DELETE_SUCCESS
                    except Exception as e:
                        error_msg = str(e)
                        if getattr(e, 'errno', None) in (errno.EACCES, errno.EPERM, errno.EBUSY):
                            status = DELETE_LOCKED
            except Exception as e:
                error_msg = str(e)
                if getattr(e, 'errno', None) in (errno.EACCES, errno.EPERM, errno.EBUSY):
                    status = DELETE_LOCKED
            
            if status == DELETE_LOCKED:
                locked_files.append(file_path)
                xbmc.log(f"OptiKlean DEBUG: File is locked: {file_path}", xbmc.LOGINFO)
            elif status == DELETE_ERROR:
                xbmc.log(f"OptiKlean DEBUG: Error deleting file: {file_path} - {error_msg}", xbmc.LOGERROR)
        
        # Then delete subdirectories recursively
        for folder in dirs:
            if progress_dialog and progress_dialog.iscanceled():
                return DELETE_ERROR, [], "Operation cancelled by user"
                
            subfolder_path = os.path.join(folder_path, folder)
            if progress_dialog:
                try:
                    percent = progress_dialog.getPercentage()
                    progress_dialog.update(percent, f"Processing subfolder: {folder}")
                except AttributeError:
                    pass
            
            sub_status, sub_locked, sub_error = delete_folder(subfolder_path, progress_dialog)
            if sub_status == DELETE_LOCKED:
                locked_files.extend(sub_locked)
            elif sub_status == DELETE_ERROR:
                xbmc.log(f"OptiKlean DEBUG: Error deleting subfolder: {subfolder_path} - {sub_error}", xbmc.LOGERROR)
        
        # Finally delete the folder itself
        if locked_files:
            return DELETE_LOCKED, locked_files, "Folder contains locked files"
            
        # Hybrid folder deletion
        deleted = False
        try:
            # First try xbmcvfs
            if xbmcvfs.rmdir(folder_path):
                deleted = True
            else:
                # Fallback to os.rmdir
                try:
                    os.rmdir(folder_path)
                    deleted = True
                except OSError as e:
                    if e.errno == errno.ENOTEMPTY:
                        # Folder not empty - try to list contents to verify
                        try:
                            remaining_dirs, remaining_files = list_contents(folder_path)
                            xbmc.log(f"OptiKlean DEBUG: Folder not empty, contains {len(remaining_files)} files and {len(remaining_dirs)} subfolders", xbmc.LOGINFO)
                        except Exception:
                            pass
                    error_msg = str(e)
        except Exception as e:
            error_msg = str(e)
        
        if deleted:
            xbmc.log(f"OptiKlean DEBUG: Successfully deleted folder: {folder_path}", xbmc.LOGINFO)
            return DELETE_SUCCESS, [], ""
        else:
            xbmc.log(f"OptiKlean DEBUG: Failed to delete folder: {folder_path} - {error_msg}", xbmc.LOGERROR)
            return DELETE_ERROR, [], error_msg
    
    except Exception as e:
        xbmc.log(f"OptiKlean DEBUG: Exception in delete_folder: {str(e)}", xbmc.LOGERROR)
        return DELETE_ERROR, [], str(e)


# Funzione per pulire i residui degli addon (addon disabilitati e residui di addon disinstallati)
def clear_addon_leftovers(auto_mode=False):
    start_time = time.perf_counter()
    progress = xbmcgui.DialogProgress()
    progress.create("OptiKlean", addon.getLocalizedString(31197))  # "Reading addon information..."
    log_content = addon.getLocalizedString(31165) + "\n\n"
    xbmc.log("OptiKlean DEBUG: Starting clear_addon_leftovers", xbmc.LOGINFO)

    # Get enabled addons
    progress.update(20, addon.getLocalizedString(31208))  # "Reading enabled addons list..."
    enabled_addons = []
    try:
        json_response = xbmc.executeJSONRPC('{"jsonrpc":"2.0", "method":"Addons.GetAddons", "params":{"enabled":true}, "id":1}')
        response = json.loads(json_response)
        if 'result' in response and 'addons' in response['result']:
            enabled_addons = [addon['addonid'] for addon in response['result']['addons']]
            xbmc.log(f"OptiKlean DEBUG: Found {len(enabled_addons)} enabled addons", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"OptiKlean DEBUG: Error getting enabled addons: {str(e)}", xbmc.LOGERROR)

    # Get disabled addons
    progress.update(30, addon.getLocalizedString(31209))  # "Reading disabled addons list..."
    disabled_addons = []
    try:
        json_response = xbmc.executeJSONRPC('{"jsonrpc":"2.0", "method":"Addons.GetAddons", "params":{"enabled":false}, "id":1}')
        response = json.loads(json_response)
        if 'result' in response and 'addons' in response['result']:
            disabled_addons = [addon['addonid'] for addon in response['result']['addons']]
            xbmc.log(f"OptiKlean DEBUG: Found {len(disabled_addons)} disabled addons", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"OptiKlean DEBUG: Error getting disabled addons: {str(e)}", xbmc.LOGERROR)

    all_installed_addons = set(enabled_addons + disabled_addons)
    disabled_addons_set = set(disabled_addons)
    xbmc.log(f"OptiKlean DEBUG: Total installed addons: {len(all_installed_addons)}", xbmc.LOGINFO)

    # Check addons folder
    addon_dir = xbmcvfs.translatePath("special://home/addons/")
    progress.update(40, addon.getLocalizedString(31210))  # "Finding addon folders..."
    existing_addon_folders = set(xbmcvfs.listdir(addon_dir)[0]) if xbmcvfs.exists(addon_dir) else set()
    xbmc.log(f"OptiKlean DEBUG: Found {len(existing_addon_folders)} addon folders on disk", xbmc.LOGINFO)

    # Check addon_data folder
    addon_data_dir = xbmcvfs.translatePath("special://home/userdata/addon_data/")
    progress.update(50, addon.getLocalizedString(31211))  # "Checking addon data folders..."
    existing_addon_data_folders = set(xbmcvfs.listdir(addon_data_dir)[0]) if xbmcvfs.exists(addon_data_dir) else set()
    xbmc.log(f"OptiKlean DEBUG: Found {len(existing_addon_data_folders)} addon_data folders on disk", xbmc.LOGINFO)

    # Identify leftovers
    orphaned_folders = [folder for folder in existing_addon_folders if folder not in all_installed_addons]
    disabled_folders = [folder for folder in existing_addon_folders if folder in disabled_addons_set]
    orphaned_addon_data = [folder for folder in existing_addon_data_folders if folder not in all_installed_addons]
    disabled_addon_data = [folder for folder in existing_addon_data_folders if folder in disabled_addons_set]
    xbmc.log(f"OptiKlean DEBUG: Found {len(orphaned_folders)} orphaned folders, {len(disabled_folders)} disabled folders, {len(orphaned_addon_data)} orphaned addon_data, {len(disabled_addon_data)} disabled addon_data", xbmc.LOGINFO)

    # Create selection list
    display_list = []
    folder_map = {}
    xbmc.log("OptiKlean DEBUG: Building selection list", xbmc.LOGINFO)

    # Disabled addon folders (in addons)
    for folder in disabled_folders:
        if folder != "packages":  # Skip packages folder
            display_name = f"{addon.getLocalizedString(31226)} {folder} (addons)"
            display_list.append(display_name)
            folder_map[display_name] = xbmcvfs.translatePath(os.path.normpath(os.path.join(addon_dir, folder)))
            xbmc.log(f"OptiKlean DEBUG: Added disabled addon folder: {folder}", xbmc.LOGINFO)

    # Disabled addon_data folders
    for folder in disabled_addon_data:
        if folder != "packages":  # Skip packages folder
            display_name = f"{addon.getLocalizedString(31226)} {folder} (addon_data)"
            display_list.append(display_name)
            folder_map[display_name] = xbmcvfs.translatePath(os.path.normpath(os.path.join(addon_data_dir, folder)))
            xbmc.log(f"OptiKlean DEBUG: Added disabled addon_data folder: {folder}", xbmc.LOGINFO)

    # Orphaned addon folders
    for folder in orphaned_folders:
        if folder != "packages" and folder != "temp":  # Skip packages and temp folders
            display_name = f"{addon.getLocalizedString(31227)} {folder} (addons)"
            display_list.append(display_name)
            folder_map[display_name] = xbmcvfs.translatePath(os.path.normpath(os.path.join(addon_dir, folder)))
            xbmc.log(f"OptiKlean DEBUG: Added orphaned addon folder: {folder}", xbmc.LOGINFO)

    # Orphaned addon_data folders
    for folder in orphaned_addon_data:
        if folder != "packages":  # Skip packages folder
            display_name = f"{addon.getLocalizedString(31227)} {folder} (addon_data)"
            display_list.append(display_name)
            folder_map[display_name] = xbmcvfs.translatePath(os.path.normpath(os.path.join(addon_data_dir, folder)))
            xbmc.log(f"OptiKlean DEBUG: Added orphaned addon_data folder: {folder}", xbmc.LOGINFO)

    progress.close()

    if not display_list:
        xbmc.log("OptiKlean DEBUG: No leftover or disabled addons found", xbmc.LOGINFO)
        progress.close()
        log_content += addon.getLocalizedString(31112) + "\n"
        write_log("clear_addon_leftovers", log_content)
        
        # Aggiorna i log delle impostazioni automatiche anche se non ci sono addon da eliminare
        xbmc.log(f"OptiKlean DEBUG: auto_mode={auto_mode}, clear_addon_leftovers_enable={addon.getSettingBool('clear_addon_leftovers_enable')}", xbmc.LOGINFO)
        if not auto_mode and addon.getSettingBool("clear_addon_leftovers_enable"):
            try:
                update_last_run("clear_addon_leftovers")
                update_automatic_settings_log()
                xbmc.log("OptiKlean: Updated automatic cleaning logs after manual execution", xbmc.LOGINFO)
            except Exception as e:
                xbmc.log(f"OptiKlean: Error updating automatic logs: {str(e)}", xbmc.LOGERROR)

        # Mostra la finestra di dialogo solo se non è in modalità automatica
        if not auto_mode:
            xbmcgui.Dialog().ok("OptiKlean", addon.getLocalizedString(31061))
        return

    # User selection
    message = addon.getLocalizedString(31062)
    if not auto_mode:
        selected = xbmcgui.Dialog().multiselect(message, display_list)
        xbmc.log(f"OptiKlean DEBUG: User selected {len(selected) if selected else 0} items", xbmc.LOGINFO)

        if not selected:
            xbmc.log("OptiKlean DEBUG: No items selected for deletion", xbmc.LOGINFO)
            write_log("clear_addon_leftovers", log_content)
            return

        selected_display_names = [display_list[i] for i in selected]
    else:
        # Modalità automatica: applica il ritardo se impostato prima di iniziare
        delay_seconds = get_autostart_delay()
        if delay_seconds > 0:
            xbmc.log(f"OptiKlean: Automatic addon leftovers cleaning delayed by {delay_seconds} seconds", xbmc.LOGINFO)
            time.sleep(delay_seconds)
        
        selected_display_names = display_list

    # Deletion process
    progress = xbmcgui.DialogProgress()
    progress.create("OptiKlean", addon.getLocalizedString(31198))  # "Removing selected addons..."
    total_selected = len(selected_display_names)
    deleted_folders = []
    locked_folders = []
    locked_files = []
    error_folders = []
    total_size_freed = 0  # Track total size of deleted files

    for index, display_name in enumerate(selected_display_names):
        if progress.iscanceled():
            xbmc.log("OptiKlean DEBUG: Operation canceled by user", xbmc.LOGINFO)
            break

        folder_path = folder_map[display_name]
        xbmc.log(f"OptiKlean DEBUG: Processing folder {folder_path} ({index+1}/{total_selected})", xbmc.LOGINFO)
        percent = int((index / total_selected) * 100) if total_selected > 0 else 0
        progress.update(percent, addon.getLocalizedString(31212).format(index=index+1, total=total_selected, path=folder_path))

        # Get folder size before deletion
        folder_size = get_folder_size(folder_path)
        xbmc.log(f"OptiKlean DEBUG: Folder size before deletion: {folder_size} bytes", xbmc.LOGINFO)
        
        status, locked_file_list, error_msg = delete_folder(folder_path, progress_dialog=progress)
        if status == DELETE_SUCCESS:
            xbmc.log(f"OptiKlean DEBUG: Successfully deleted folder {folder_path}", xbmc.LOGINFO)
            deleted_folders.append((folder_path, folder_size))
            total_size_freed += folder_size
        elif status == DELETE_LOCKED:
            xbmc.log(f"OptiKlean DEBUG: Folder locked {folder_path}", xbmc.LOGINFO)
            locked_folders.append(folder_path)
            locked_files.extend(locked_file_list)
        else:
            xbmc.log(f"OptiKlean DEBUG: Error deleting folder {folder_path}: {error_msg}", xbmc.LOGERROR)
            error_folders.append(f"{folder_path} ({error_msg})")

    progress.close()

    # Calculate total MB freed
    total_size_freed = sum(size for _, size in deleted_folders)  # Calculate from deleted_folders
    total_mb = total_size_freed / (1024 * 1024) if total_size_freed > 0 else 0  # Initialize here

    # Final log
    xbmc.log(f"OptiKlean DEBUG: Deletion complete. Deleted: {len(deleted_folders)}, Freed: {total_mb:.2f} MB", xbmc.LOGINFO)
    
    # Organize deleted folders by type using existing variables
    deleted_addons = [(f.replace(addon_dir, ""), s) for f, s in deleted_folders if addon_dir in f]
    deleted_addon_data = [(f.replace(addon_data_dir, ""), s) for f, s in deleted_folders if addon_data_dir in f]
    
    if deleted_folders:
        log_content += addon.getLocalizedString(31113) + "\n"
        if deleted_addons:
            log_content += addon.getLocalizedString(31114) + "\n"
            for folder, size in deleted_addons:
                size_mb = size / (1024 * 1024)
                log_content += f"    - {folder} ({size_mb:.2f} MB)\n"
        if deleted_addon_data:
            log_content += addon.getLocalizedString(31115) + "\n"
            for folder, size in deleted_addon_data:
                size_mb = size / (1024 * 1024)
                log_content += f"    - {folder} ({size_mb:.2f} MB)\n"
        log_content += f"\n  Total space freed: {total_mb:.2f} MB\n\n"
    
    if locked_folders:
        cleaned_locked = [f.replace(addon_dir, "").replace(addon_data_dir, "") for f in locked_folders]
        log_content += addon.getLocalizedString(31116) + "\n  " + "\n  ".join(cleaned_locked) + "\n\n"
        if locked_files:
            cleaned_locked_files = [os.path.basename(f) for f in locked_files]
            log_content += addon.getLocalizedString(31117) + "\n  " + "\n  ".join(cleaned_locked_files) + "\n\n"
    if error_folders:
        cleaned_errors = []
        for error in error_folders:
            path, msg = error.split(" (", 1)
            cleaned_path = path.replace(addon_dir, "").replace(addon_data_dir, "")
            cleaned_errors.append(f"{cleaned_path} ({msg}")
        log_content += addon.getLocalizedString(31219) + "\n  " + "\n  ".join(cleaned_errors) + "\n\n"

    execution_time = round(time.perf_counter() - start_time, 2)
    log_content += addon.getLocalizedString(31104).format(time=execution_time) + "\n"
    
    write_log("clear_addon_leftovers", log_content)
    xbmcgui.Dialog().notification(
        "OptiKlean",
        addon.getLocalizedString(31064).format(count=len(deleted_folders), total_mb=total_mb),
        logo_path,
        3000
    )

    # Aggiorna i log delle impostazioni automatiche solo se:
    # 1. Non è in modalità automatica
    # 2. La pulizia automatica è abilitata nelle impostazioni
    xbmc.log(f"OptiKlean DEBUG: auto_mode={auto_mode}, clear_addon_leftovers_enable={addon.getSettingBool('clear_addon_leftovers_enable')}", xbmc.LOGINFO)
    if not auto_mode and addon.getSettingBool("clear_addon_leftovers_enable"):
        try:
            update_last_run("clear_addon_leftovers")
            update_automatic_settings_log()
            xbmc.log("OptiKlean: Updated automatic cleaning logs after manual execution", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"OptiKlean: Error updating automatic logs: {str(e)}", xbmc.LOGERROR)

# Funzione per pulire i pacchetti (packages)
def clear_kodi_packages(auto_mode=False):
    # Se è in modalità automatica, applica il ritardo se impostato prima di iniziare
    if auto_mode:
        delay_seconds = get_autostart_delay()
        if delay_seconds > 0:
            xbmc.log(f"OptiKlean: Automatic packages cleaning delayed by {delay_seconds} seconds", xbmc.LOGINFO)
            time.sleep(delay_seconds)
    
    start_time = time.perf_counter()
    progress = xbmcgui.DialogProgress()
    progress.create("OptiKlean", addon.getLocalizedString(31199))  # "Preparing to clear packages..."
    
    packages_path = xbmcvfs.translatePath("special://home/addons/packages")
    xbmc.log(f"OptiKlean DEBUG: Using packages path: {packages_path}", xbmc.LOGINFO)
    log_content = addon.getLocalizedString(31097) + "\n\n"  # "Kodi packages cleaning results:"
    
    # Track results
    deleted_items = []
    locked_items = []
    error_items = []
    total_size_freed = 0  # Track total size of deleted packages
    
    xbmc.log(f"OptiKlean DEBUG: Starting package cleanup at path: {packages_path}", xbmc.LOGINFO)
    
    def path_exists(path):
        path = xbmcvfs.translatePath(os.path.normpath(path))
        if xbmcvfs.exists(path):
            xbmc.log(f"OptiKlean DEBUG: Path exists (xbmcvfs): {path}", xbmc.LOGINFO)
            return True
        if os.path.exists(path):
            xbmc.log(f"OptiKlean DEBUG: Path exists (os.path): {path}", xbmc.LOGINFO)
            return True
        xbmc.log(f"OptiKlean DEBUG: Path does not exist: {path}", xbmc.LOGINFO)
        return False
    
    if not path_exists(packages_path):
        error_msg = f"Packages folder does not exist: {packages_path}"
        xbmc.log(f"OptiKlean DEBUG: {error_msg}", xbmc.LOGERROR)
        log_content += error_msg + "\n"
        progress.close()
        write_log("clear_kodi_packages", log_content)
        xbmcgui.Dialog().notification("OptiKlean", addon.getLocalizedString(31059), xbmcgui.NOTIFICATION_ERROR, 3000)  # "Packages folder not found"
        return
    
    # Hybrid file listing with robust path handling
    def list_package_files(path):
        norm_path = xbmcvfs.translatePath(os.path.normpath(path))
        try:
            xbmc.log(f"OptiKlean DEBUG: Attempting xbmcvfs.listdir for: {norm_path}", xbmc.LOGINFO)
            dirs, files = xbmcvfs.listdir(norm_path)
            zip_files = [f for f in files if f.lower().endswith('.zip')]
            xbmc.log(f"OptiKlean DEBUG: Found {len(zip_files)} zip files via xbmcvfs", xbmc.LOGINFO)
            return zip_files
        except Exception as e:
            xbmc.log(f"OptiKlean DEBUG: xbmcvfs.listdir failed, falling back to os.listdir: {str(e)}", xbmc.LOGWARNING)
            try:
                zip_files = [f for f in os.listdir(norm_path) if f.lower().endswith('.zip') and os.path.isfile(
                    xbmcvfs.translatePath(os.path.normpath(os.path.join(norm_path, f))))]
                xbmc.log(f"OptiKlean DEBUG: Found {len(zip_files)} zip files via os.listdir", xbmc.LOGINFO)
                return zip_files
            except Exception as e:
                xbmc.log(f"OptiKlean DEBUG: Failed to list directory contents: {str(e)}", xbmc.LOGERROR)
                return []
    
    package_files = list_package_files(packages_path)
    total_files = len(package_files)
    
    xbmc.log(f"OptiKlean DEBUG: Found {total_files} package files to process", xbmc.LOGINFO)
    
    if total_files == 0:
        progress.close()
        log_content += addon.getLocalizedString(31118) + "\n"  # "No package files found to delete."
        write_log("clear_kodi_packages", log_content)
        xbmcgui.Dialog().notification("OptiKlean", addon.getLocalizedString(31060), logo_path, 3000)  # "No packages found"
        # Aggiorna i log delle impostazioni automatiche anche se non ci sono pacchetti
        xbmc.log(f"OptiKlean DEBUG: auto_mode={auto_mode}, clear_kodi_packages_enable={addon.getSettingBool('clear_kodi_packages_enable')}", xbmc.LOGINFO)
        if not auto_mode and addon.getSettingBool("clear_kodi_packages_enable"):
            try:
                update_last_run("clear_kodi_packages")
                update_automatic_settings_log()
                xbmc.log("OptiKlean: Updated automatic cleaning logs after manual execution", xbmc.LOGINFO)
            except Exception as e:
                xbmc.log(f"OptiKlean: Error updating automatic logs: {str(e)}", xbmc.LOGERROR)
        return
    
    def delete_package_file(file_path):
        norm_path = xbmcvfs.translatePath(os.path.normpath(file_path))
        xbmc.log(f"OptiKlean DEBUG: Attempting to delete: {norm_path}", xbmc.LOGINFO)

        # Get file size before deletion (spostato all'inizio)
        try:
            file_size = get_file_size(norm_path)
        except Exception:
            file_size = 0  # Default se non riesci a ottenere la dimensione

        # First try xbmcvfs
        try:
            if xbmcvfs.delete(norm_path):
                xbmc.log(f"OptiKlean DEBUG: Successfully deleted via xbmcvfs: {norm_path}", xbmc.LOGINFO)
                return DELETE_SUCCESS, file_size  # Restituisci la dimensione invece di ""
            xbmc.log(f"OptiKlean DEBUG: xbmcvfs.delete returned False for: {norm_path}", xbmc.LOGWARNING)
        except Exception as e:
            xbmc.log(f"OptiKlean DEBUG: xbmcvfs.delete exception: {str(e)}", xbmc.LOGWARNING)
        
        # Fallback to os.remove with verification
        try:
            if os.path.exists(norm_path):
                os.remove(norm_path)
                if not os.path.exists(norm_path):
                    xbmc.log(f"OptiKlean DEBUG: Successfully deleted via os.remove: {norm_path}", xbmc.LOGINFO)
                    return DELETE_SUCCESS, file_size
                xbmc.log(f"OptiKlean DEBUG: File still exists after os.remove: {norm_path}", xbmc.LOGERROR)
                return DELETE_ERROR, "File removal failed"
            xbmc.log(f"OptiKlean DEBUG: File disappeared before os.remove: {norm_path}", xbmc.LOGINFO)
            return DELETE_SUCCESS, 0
        except OSError as e:
            if e.errno in (errno.EACCES, errno.EPERM, errno.EBUSY):
                xbmc.log(f"OptiKlean DEBUG: File locked: {norm_path}", xbmc.LOGINFO)
                return DELETE_LOCKED, str(e)
            xbmc.log(f"OptiKlean DEBUG: OS error deleting file: {norm_path} - {str(e)}", xbmc.LOGERROR)
            return DELETE_ERROR, str(e)
        except Exception as e:
            xbmc.log(f"OptiKlean DEBUG: Unexpected error deleting file: {norm_path} - {str(e)}", xbmc.LOGERROR)
            return DELETE_ERROR, str(e)
    
    for index, package_file in enumerate(package_files):
        if progress.iscanceled():
            xbmc.log("OptiKlean DEBUG: Operation canceled by user", xbmc.LOGINFO)
            log_content += "\n" + addon.getLocalizedString(31119) + "\n"
            break
            
        percent = int((index / total_files) * 100) if total_files > 0 else 0
        file_path = xbmcvfs.translatePath(os.path.normpath(os.path.join(packages_path, package_file)))
        progress.update(percent, addon.getLocalizedString(31091).format(index=index+1, total=total_files, package_file=package_file))  # "Deleting package ({index}/{total}): {package_file}"
        
        xbmc.log(f"OptiKlean DEBUG: Processing package file {index+1}/{total_files}: {file_path}", xbmc.LOGINFO)
        
        status, result = delete_package_file(file_path)
        if status == DELETE_SUCCESS:
            if isinstance(result, int):  # If we got a file size
                deleted_items.append((file_path, result))
                total_size_freed += result
            else:
                deleted_items.append((file_path, 0))  # Default to 0 if size unknown
        elif status == DELETE_LOCKED:
            locked_items.append(f"{file_path} ({result})")
        else:
            error_items.append(f"{file_path} ({result})")
    
    progress.close()
    
    # Format results
    if deleted_items:
        total_mb = total_size_freed / (1024 * 1024)
        log_content += addon.getLocalizedString(31120).format(count=len(deleted_items), size=total_mb) + "\n"
        for file_path, size in deleted_items:
            filename = os.path.basename(file_path)  # Extract just the filename
            size_kb = size / 1024
            size_mb = size / (1024 * 1024)
            # Show size in appropriate unit (KB or MB)
            if size_mb >= 1:
                log_content += f"  - {filename} ({size_mb:.2f} MB)\n"
            else:
                log_content += f"  - {filename} ({size_kb:.2f} KB)\n"
        log_content += "\n"
    
    if locked_items:
        log_content += addon.getLocalizedString(31121) + "\n"
        for item in locked_items:
            path, reason = item.split(" (", 1) if " (" in item else (item, "")
            filename = os.path.basename(path)
            log_content += f"  - {filename} ({reason}\n"
        log_content += "\n"
    
    if error_items:
        log_content += addon.getLocalizedString(31122) + "\n"
        for item in error_items:
            path, reason = item.split(" (", 1) if " (" in item else (item, "")
            filename = os.path.basename(path)
            log_content += f"  - {filename} ({reason}\n"
        log_content += "\n"

    execution_time = round(time.perf_counter() - start_time, 2)
    log_content += "\n" + addon.getLocalizedString(31104).format(time=execution_time) + "\n"
    write_log("clear_kodi_packages", log_content)
    
    # Show summary notification
    if deleted_items:
        total_mb = total_size_freed / (1024 * 1024)
        summary = addon.getLocalizedString(31153).format(count=len(deleted_items), size=total_mb)
    else:
        summary = addon.getLocalizedString(31154)
    if locked_items:
        summary += f" ({len(locked_items)} locked)"
    xbmcgui.Dialog().notification("OptiKlean", summary, logo_path, 3000)
    xbmc.log(f"OptiKlean DEBUG: Package cleanup completed. {summary}", xbmc.LOGINFO)

    # Aggiorna i log delle impostazioni automatiche solo se:
    # 1. Non è in modalità automatica
    # 2. La pulizia automatica è abilitata nelle impostazioni
    xbmc.log(f"OptiKlean DEBUG: auto_mode={auto_mode}, clear_kodi_packages_enable={addon.getSettingBool('clear_kodi_packages_enable')}", xbmc.LOGINFO)
    if not auto_mode and addon.getSettingBool("clear_kodi_packages_enable"):
        try:
            update_last_run("clear_kodi_packages")
            update_automatic_settings_log()
            xbmc.log("OptiKlean: Updated automatic cleaning logs after manual execution", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"OptiKlean: Error updating automatic logs: {str(e)}", xbmc.LOGERROR)

# Funzione per ottimizzare i database di Kodi e degli addons
def optimize_databases(auto_mode=False):
    # Se è in modalità automatica, applica il ritardo se impostato prima di iniziare
    if auto_mode:
        delay_seconds = get_autostart_delay()
        if delay_seconds > 0:
            xbmc.log(f"OptiKlean: Automatic database optimization delayed by {delay_seconds} seconds", xbmc.LOGINFO)
            time.sleep(delay_seconds)
    
    if not auto_mode:
        warning_message = addon.getLocalizedString(30400)
        
        user_choice = xbmcgui.Dialog().yesno(
            addon.getLocalizedString(30300),
            warning_message
        )
        
        if not user_choice:
            xbmc.log("OptiKlean: User cancelled database optimization", xbmc.LOGINFO)
            return

    start_time = time.perf_counter()
    # Percorsi base
    std_db_path = xbmcvfs.translatePath("special://database/")
    backup_path_setting = addon.getSetting("backup_path")
    # Se backup_path configurato → {backup_path}/db_backups/
    # Se vuoto → {addon_profile}/db_backups/
    if backup_path_setting and backup_path_setting.strip():
        backup_path = os.path.join(backup_path_setting, 'db_backups')
    else:
        backup_path = os.path.join(xbmcvfs.translatePath(addon.getAddonInfo('profile')), 'db_backups')
    xbmc.log(f"OptiKlean DEBUG: Using backup path: {backup_path}", xbmc.LOGINFO)
    addon_data_path = xbmcvfs.translatePath("special://userdata/addon_data/").rstrip('/') + '/'

    # Inizializza log (senza debug)
    log_content = addon.getLocalizedString(31167) + "\n\n"
    
    # Risultati
    optimized_dbs = []
    locked_dbs = []
    error_dbs = []
    backup_dbs = []
    backup_failed = []
    integrity_checks = []
    backup_cleanup = []
    backup_cleanup_failed = []
    corrupted_databases = []  # Nuova lista per database corrotti

    # Progress dialog
    progress = xbmcgui.DialogProgress()
    progress.create("OptiKlean", addon.getLocalizedString(31200))  # "Preparing database optimization..."
    
    # Create backup directory if it doesn't exist
    try:
        if not os.path.exists(backup_path):
            os.makedirs(backup_path)
            xbmc.log(f"OptiKlean DEBUG: Created backup directory: {backup_path}", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"OptiKlean DEBUG: Error creating backup directory: {str(e)}", xbmc.LOGERROR)
        return
    
    def check_directory_exists(dir_path):
        if xbmcvfs.exists(dir_path):
            return True
        test_file = xbmcvfs.makeLegalFilename(dir_path + "/.temp_test")
        try:
            f = xbmcvfs.File(test_file, 'w')
            f.write("test")
            f.close()
            xbmcvfs.delete(test_file)
            return True
        except Exception:
            try:
                xbmcvfs.delete(test_file)
            except Exception:
                pass
            return False

    def verify_database_integrity(db_path):
        """
        Verifica l'integrità del database usando PRAGMA integrity_check
        Returns: (is_valid, error_message)
        """
        try:
            xbmc.log(f"OptiKlean DEBUG: Checking integrity of {db_path}", xbmc.LOGINFO)
            conn = sqlite3.connect(db_path, timeout=5)
            cursor = conn.cursor()
            
            # PRAGMA integrity_check restituisce "ok" se tutto è a posto
            cursor.execute("PRAGMA integrity_check;")
            result = cursor.fetchone()
            conn.close()
            
            if result and result[0].lower() == 'ok':
                xbmc.log(f"OptiKlean DEBUG: Database integrity OK: {db_path}", xbmc.LOGINFO)
                return True, "OK"
            else:
                error_msg = result[0] if result else "Unknown integrity error"
                xbmc.log(f"OptiKlean DEBUG: Database integrity FAILED: {db_path} - {error_msg}", xbmc.LOGERROR)
                return False, error_msg
                
        except sqlite3.DatabaseError as e:
            xbmc.log(f"OptiKlean DEBUG: Database error during integrity check: {db_path} - {str(e)}", xbmc.LOGERROR)
            return False, f"Database error: {str(e)}"
        except Exception as e:
            xbmc.log(f"OptiKlean DEBUG: Exception during integrity check: {db_path} - {str(e)}", xbmc.LOGERROR)
            return False, f"Exception: {str(e)}"

    def restore_database_backup(backup_file_path, original_db_path, db_identifier):
        """
        Ripristina un database dal backup
        Returns: (success, error_message)
        """
        try:
            if not xbmcvfs.exists(backup_file_path):
                return False, "Backup file not found"
            
            # Prima elimina il database corrotto
            if xbmcvfs.exists(original_db_path):
                if not xbmcvfs.delete(original_db_path):
                    return False, "Failed to delete corrupted database"
            
            # Poi copia il backup al posto originale
            if xbmcvfs.copy(backup_file_path, original_db_path):
                xbmc.log(f"OptiKlean DEBUG: Successfully restored backup for: {db_identifier}", xbmc.LOGINFO)
                return True, ""
            else:
                return False, "Failed to copy backup file"
                
        except Exception as e:
            xbmc.log(f"OptiKlean DEBUG: Exception restoring backup: {db_identifier} - {str(e)}", xbmc.LOGERROR)
            return False, str(e)

    def cleanup_backup_file(backup_file_path, db_identifier):
        """
        Rimuove il file di backup se non più necessario
        Returns: (success, error_message)
        """
        try:
            if xbmcvfs.exists(backup_file_path):
                if xbmcvfs.delete(backup_file_path):
                    xbmc.log(f"OptiKlean DEBUG: Successfully removed backup: {backup_file_path}", xbmc.LOGINFO)
                    return True, ""
                else:
                    xbmc.log(f"OptiKlean DEBUG: Failed to remove backup: {backup_file_path}", xbmc.LOGERROR)
                    return False, "Delete operation failed"
            else:
                xbmc.log(f"OptiKlean DEBUG: Backup file not found: {backup_file_path}", xbmc.LOGINFO)
                return True, "File not found"
        except Exception as e:
            xbmc.log(f"OptiKlean DEBUG: Exception removing backup: {backup_file_path} - {str(e)}", xbmc.LOGERROR)
            return False, str(e)
    
    def process_databases(directory, source_type="standard"):
        db_files = []
        try:
            _, files = xbmcvfs.listdir(directory)
            for file in files:
                if file.lower().endswith((".db", ".sqlite")):
                    db_files.append((directory, file, source_type))
        except Exception:
            pass
        return db_files
    
    # Raccolta database
    all_db_files = []
    all_db_files.extend(process_databases(std_db_path, "standard"))
    
    if check_directory_exists(addon_data_path):
        addon_dirs, _ = xbmcvfs.listdir(addon_data_path)
        for addon_dir in addon_dirs:
            addon_path = xbmcvfs.makeLegalFilename(addon_data_path + addon_dir)
            if check_directory_exists(addon_path):
                all_db_files.extend(process_databases(addon_path, f"addon:{addon_dir}"))
                try:
                    subdirs, _ = xbmcvfs.listdir(addon_path)
                    for subdir in subdirs:
                        subdir_path = xbmcvfs.makeLegalFilename(addon_path + '/' + subdir)
                        if check_directory_exists(subdir_path):
                            all_db_files.extend(process_databases(subdir_path, f"addon:{addon_dir}:{subdir}"))
                except Exception:
                    pass
    
    # Prima fase: Backup e Ottimizzazione
    total_files = len(all_db_files)
    if total_files == 0:
        progress.close()
        log_content += addon.getLocalizedString(31123) + "\n"
        write_log("optimize_databases", log_content)
        xbmcgui.Dialog().notification("OptiKlean", addon.getLocalizedString(31063), logo_path, 3000)
        return

    # Teniamo traccia dei database elaborati per la verifica successiva
    processed_databases = []
    
    for index, (dir_path, file, source_type) in enumerate(all_db_files):
        if progress.iscanceled():
            log_content += "\n" + addon.getLocalizedString(31119) + "\n"
            break
            
        percent = int((index / total_files) * 50)  # Prima metà del progresso
        progress.update(percent, addon.getLocalizedString(31086).format(filename=file))

        db_file_path = xbmcvfs.makeLegalFilename(dir_path + '/' + file)
        backup_type_path = xbmcvfs.makeLegalFilename(backup_path + '/' + source_type.replace(":", "_"))
        
        if not xbmcvfs.exists(backup_type_path):
            xbmcvfs.mkdirs(backup_type_path)
        
        backup_file_path = xbmcvfs.makeLegalFilename(backup_type_path + '/' + file + ".bak")
        
        # Backup
        backup_success = False
        try:
            if xbmcvfs.copy(db_file_path, backup_file_path):
                backup_dbs.append(f"{source_type}:{file}")
                backup_success = True
            else:
                backup_failed.append(f"{source_type}:{file}")
        except Exception:
            backup_failed.append(f"{source_type}:{file}")
        
        # Ottimizzazione solo se il backup è riuscito
        optimization_success = False
        optimization_error = None
        if backup_success:
            try:
                conn = sqlite3.connect(db_file_path, timeout=1)
                conn.execute("PRAGMA quick_check;")
                conn.execute("VACUUM;")
                conn.close()
                optimized_dbs.append(f"{source_type}:{file}")
                optimization_success = True
            except sqlite3.OperationalError as e:
                if "locked" in str(e).lower():
                    locked_dbs.append(f"{source_type}:{file}")
                    optimization_error = "locked"
                else:
                    error_dbs.append(f"{source_type}:{file}")
                    optimization_error = str(e)
            except Exception as e:
                error_dbs.append(f"{source_type}:{file}")
                optimization_error = str(e)
        
        # Aggiungi alla lista per verifica successiva se:
        # 1. Il backup è riuscito (necessario per ripristino)
        # 2. E se l'ottimizzazione è riuscita O se è fallita per corruzione (non per lock)
        if backup_success and (optimization_success or (optimization_error and optimization_error != "locked")):
            processed_databases.append({
                'db_path': db_file_path,
                'backup_path': backup_file_path,
                'identifier': f"{source_type}:{file}",
                'optimization_success': optimization_success,
                'optimization_error': optimization_error
            })

    # Seconda fase: Verifica integrità e gestione backup
    if processed_databases and not progress.iscanceled():
        progress.update(50, addon.getLocalizedString(31213))  # "Verifying database integrity..."
        xbmc.log("OptiKlean DEBUG: Starting integrity verification phase", xbmc.LOGINFO)
        
        for index, db_info in enumerate(processed_databases):
            if progress.iscanceled():
                break
                
            percent = 50 + int((index / len(processed_databases)) * 50)  # Seconda metà del progresso
            progress.update(percent, addon.getLocalizedString(31214).format(db_name=os.path.basename(db_info['db_path'])))
            
            # Se l'ottimizzazione è fallita, considera il database come corrotto senza verificare
            if not db_info['optimization_success']:
                integrity_checks.append(f"✗ {db_info['identifier']} - Optimization failed: {db_info['optimization_error']}")
                corrupted_databases.append(db_info)
                xbmc.log(f"OptiKlean DEBUG: Database failed optimization: {db_info['identifier']} - {db_info['optimization_error']}", xbmc.LOGWARNING)
                continue
            
            # Verifica integrità solo per database ottimizzati con successo
            is_valid, error_msg = verify_database_integrity(db_info['db_path'])
            
            if is_valid:
                integrity_checks.append(f"✓ {db_info['identifier']}")
                
                # Se l'integrità è OK, rimuovi il backup
                cleanup_success, cleanup_error = cleanup_backup_file(
                    db_info['backup_path'], 
                    db_info['identifier']
                )
                
                if cleanup_success:
                    backup_cleanup.append(db_info['identifier'])
                else:
                    backup_cleanup_failed.append(f"{db_info['identifier']} ({cleanup_error})")
            else:
                integrity_checks.append(f"✗ {db_info['identifier']} - {error_msg}")
                # Mantieni il backup se l'integrità non è OK e aggiungi ai corrotti
                corrupted_databases.append(db_info)
                xbmc.log(f"OptiKlean DEBUG: Database corrupted after optimization: {db_info['identifier']}", xbmc.LOGWARNING)
    
    progress.close()
    
    # Gestione database corrotti - Dialog di ripristino
    if corrupted_databases and not auto_mode:
        xbmc.log(f"OptiKlean DEBUG: Found {len(corrupted_databases)} corrupted databases", xbmc.LOGWARNING)
        
        # Crea il messaggio per la dialog
        corrupted_list = [db['identifier'] for db in corrupted_databases]
        dialog_message = (
            addon.getLocalizedString(31065).format(count=len(corrupted_databases)) + "\n\n"
            + "\n".join([f"• {db_id}" for db_id in corrupted_list])
            + "\n\n" + addon.getLocalizedString(31066) + "\n"
            + addon.getLocalizedString(31067)
        )
        
        # Mostra dialog di conferma
        restore_choice = xbmcgui.Dialog().yesno(
            addon.getLocalizedString(31068), 
            dialog_message
        )
        
        if restore_choice:
            # L'utente ha scelto di ripristinare i backup
            xbmc.log("OptiKlean DEBUG: User chose to restore corrupted database backups", xbmc.LOGINFO)
            
            progress = xbmcgui.DialogProgress()
            progress.create("OptiKlean", addon.getLocalizedString(31085))
            
            restored_databases = []
            restore_errors = []
            
            for index, db_info in enumerate(corrupted_databases):
                if progress.iscanceled():
                    break
                
                percent = int((index / len(corrupted_databases)) * 100)
                progress.update(percent, addon.getLocalizedString(31092).format(db_name=os.path.basename(db_info['db_path'])))
                
                restore_success, restore_error = restore_database_backup(
                    db_info['backup_path'],
                    db_info['db_path'],
                    db_info['identifier']
                )
                
                if restore_success:
                    restored_databases.append(db_info['identifier'])
                    
                    # Dopo il ripristino riuscito, elimina il backup
                    cleanup_success, cleanup_error = cleanup_backup_file(
                        db_info['backup_path'],
                        db_info['identifier']
                    )
                    
                    if cleanup_success:
                        backup_cleanup.append(db_info['identifier'])
                    else:
                        backup_cleanup_failed.append(f"{db_info['identifier']} ({cleanup_error})")
                else:
                    restore_errors.append(f"{db_info['identifier']} ({restore_error})")
            
            progress.close()
            
            # Aggiorna le liste per il log
            if restored_databases:
                log_content += "\n" + addon.getLocalizedString(31124) + "\n"
                log_content += addon.getLocalizedString(31125).format(count=len(restored_databases)) + "\n"
                log_content += "\n".join(f"• {db}" for db in restored_databases) + "\n\n"
                
                # Rimuovi i database ripristinati dalla lista dei corrotti per il log finale
                corrupted_databases = [db for db in corrupted_databases if db['identifier'] not in restored_databases]
            
            if restore_errors:
                log_content += addon.getLocalizedString(31126) + "\n"
                log_content += "\n".join(f"• {error}" for error in restore_errors) + "\n\n"
            
            # Mostra notifica di ripristino
            if restored_databases:
                notification_msg = addon.getLocalizedString(31069).format(count=len(restored_databases))
                if restore_errors:
                    notification_msg += f" ({len(restore_errors)} errors)"
                xbmcgui.Dialog().notification("OptiKlean", notification_msg, logo_path, 5000)
        else:
            # L'utente ha scelto di non ripristinare
            xbmc.log("OptiKlean DEBUG: User chose not to restore corrupted database backups", xbmc.LOGINFO)
            log_content += "\n" + addon.getLocalizedString(31127) + "\n"
            log_content += addon.getLocalizedString(31128) + "\n\n"
    
    elif corrupted_databases and auto_mode:
        # In modalità automatica, ripristina automaticamente i database corrotti
        xbmc.log(f"OptiKlean DEBUG: Found {len(corrupted_databases)} corrupted databases in auto mode - restoring automatically", xbmc.LOGWARNING)
        
        restored_databases = []
        restore_errors = []
        
        for db_info in corrupted_databases:
            restore_success, restore_error = restore_database_backup(
                db_info['backup_path'],
                db_info['db_path'],
                db_info['identifier']
            )
            
            if restore_success:
                restored_databases.append(db_info['identifier'])
                
                # Dopo il ripristino riuscito, elimina il backup
                cleanup_success, cleanup_error = cleanup_backup_file(
                    db_info['backup_path'],
                    db_info['identifier']
                )
                
                if cleanup_success:
                    backup_cleanup.append(db_info['identifier'])
                else:
                    backup_cleanup_failed.append(f"{db_info['identifier']} ({cleanup_error})")
            else:
                restore_errors.append(f"{db_info['identifier']} ({restore_error})")
        
        # Log dei risultati del ripristino automatico
        if restored_databases:
            log_content += "\n" + addon.getLocalizedString(31129) + "\n"
            log_content += addon.getLocalizedString(31130).format(count=len(restored_databases)) + "\n"
            log_content += "\n".join(f"• {db}" for db in restored_databases) + "\n\n"
            
            xbmc.log(f"OptiKlean: Auto-restored {len(restored_databases)} corrupted databases", xbmc.LOGINFO)
            
            # Rimuovi i database ripristinati dalla lista dei corrotti per il log finale
            corrupted_databases = [db for db in corrupted_databases if db['identifier'] not in restored_databases]
        
        if restore_errors:
            log_content += addon.getLocalizedString(31131) + "\n"
            log_content += "\n".join(f"• {error}" for error in restore_errors) + "\n\n"
            
            xbmc.log(f"OptiKlean: Failed to auto-restore {len(restore_errors)} databases", xbmc.LOGERROR)
        
        # Se ci sono ancora database corrotti che non sono stati ripristinati
        if corrupted_databases:
            log_content += addon.getLocalizedString(31132) + "\n"
            log_content += addon.getLocalizedString(31133) + "\n"
            log_content += "\n".join(f"• {db['identifier']}" for db in corrupted_databases) + "\n"
            log_content += addon.getLocalizedString(31134) + "\n\n"
    
    # Costruzione log dettagliato
    log_content += addon.getLocalizedString(31135).format(total=total_files) + "\n\n"
    
    if backup_dbs:
        log_content += addon.getLocalizedString(31136) + "\n" + "\n".join(f"• {db}" for db in backup_dbs) + "\n\n"
    
    if optimized_dbs:
        log_content += addon.getLocalizedString(31137) + "\n" + "\n".join(f"• {db}" for db in optimized_dbs) + "\n\n"
    
    if integrity_checks:
        log_content += addon.getLocalizedString(31138) + "\n" + "\n".join(f"• {check}" for check in integrity_checks) + "\n\n"
    
    if backup_cleanup:
        log_content += addon.getLocalizedString(31139) + "\n" + "\n".join(f"• {db}" for db in backup_cleanup) + "\n\n"
    
    if locked_dbs:
        log_content += addon.getLocalizedString(31140) + "\n" + "\n".join(f"• {db}" for db in locked_dbs) + "\n\n"
    
    if backup_failed:
        log_content += addon.getLocalizedString(31141) + "\n" + "\n".join(f"• {db}" for db in backup_failed) + "\n\n"
    
    if error_dbs:
        log_content += addon.getLocalizedString(31142) + "\n" + "\n".join(f"• {db}" for db in error_dbs) + "\n\n"
    
    if backup_cleanup_failed:
        log_content += addon.getLocalizedString(31143) + "\n" + "\n".join(f"• {db}" for db in backup_cleanup_failed) + "\n\n"

    # Se ci sono ancora database corrotti (non ripristinati), includili nel log
    if corrupted_databases:
        log_content += addon.getLocalizedString(31144) + "\n"
        log_content += "\n".join(f"• {db['identifier']}" for db in corrupted_databases) + "\n\n"

    # Statistiche finali
    total_optimized = len(optimized_dbs)
    total_cleaned_backups = len(backup_cleanup)
    total_retained_backups = len(backup_dbs) - total_cleaned_backups
    total_corrupted = len(corrupted_databases)
    
    log_content += addon.getLocalizedString(31145) + "\n"
    log_content += addon.getLocalizedString(31146).format(count=total_optimized) + "\n"
    log_content += addon.getLocalizedString(31147).format(count=total_cleaned_backups) + "\n"
    log_content += addon.getLocalizedString(31148).format(count=total_retained_backups) + "\n"
    if total_corrupted > 0:
        log_content += addon.getLocalizedString(31149).format(count=total_corrupted) + "\n"

    execution_time = round(time.perf_counter() - start_time, 2)
    log_content += "\n" + addon.getLocalizedString(31104).format(time=execution_time) + "\n"    
    write_log("optimize_databases", log_content)
    
    # Notifica finale più informativa
    if total_optimized > 0:
        if total_cleaned_backups > 0:
            notification_msg = addon.getLocalizedString(31150).format(count=total_optimized)
            if total_corrupted > 0:
                if auto_mode and 'restored_databases' in locals():
                    notification_msg += addon.getLocalizedString(31151).format(count=len(restored_databases))
                else:
                    notification_msg += f", {total_corrupted} corrupted"
            else:
                notification_msg += addon.getLocalizedString(31152).format(count=total_cleaned_backups)
        else:
            notification_msg = addon.getLocalizedString(31150).format(count=total_optimized) + f", {total_retained_backups} backups retained"
            if total_corrupted > 0:
                if auto_mode and 'restored_databases' in locals():
                    notification_msg += addon.getLocalizedString(31151).format(count=len(restored_databases))
                else:
                    notification_msg += f", {total_corrupted} corrupted"
    else:
        notification_msg = addon.getLocalizedString(31080)
    
    xbmcgui.Dialog().notification("OptiKlean", notification_msg, logo_path, 5000)

    # Aggiorna i log delle impostazioni automatiche solo se:
    # 1. Non è in modalità automatica
    # 2. La pulizia automatica è abilitata nelle impostazioni
    if not auto_mode and addon.getSettingBool("optimize_databases_enable"):
        try:
            update_last_run("optimize_databases")
            update_automatic_settings_log()
            xbmc.log("OptiKlean: Updated automatic cleaning logs after manual execution", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"OptiKlean: Error updating automatic logs: {str(e)}", xbmc.LOGERROR)


def show_backup_dialog():
    choice = xbmcgui.Dialog().select(addon.getLocalizedString(31183), [
        addon.getLocalizedString(31184),  # "Full backup"
        addon.getLocalizedString(31185),  # "Backup only addons"
        addon.getLocalizedString(31186),  # "Backup only addon data"
        addon.getLocalizedString(31187),  # "Backup addons + data"
        addon.getLocalizedString(31188),  # "Backup skins"
        addon.getLocalizedString(31189),  # "Backup Kodi databases"
        addon.getLocalizedString(31190),  # "Backup sources"
        addon.getLocalizedString(31191),  # "Backup GUI settings"
        addon.getLocalizedString(31192),  # "Backup profiles"
        addon.getLocalizedString(31193),  # "Backup advanced settings"
        addon.getLocalizedString(31194),  # "Backup keymaps"
        addon.getLocalizedString(31195),  # "Backup playlists"
        addon.getLocalizedString(31228),  # "Backup network passwords" 
        addon.getLocalizedString(31229)   # "Restore from backup"
    ])
    
    if choice == -1:
        return

    actions = [
        "full", "addons", "addon_data", "both", "skins", "databases",
        "sources", "gui_settings", "profiles", "advanced_settings", 
        "keymaps", "playlists", "passwords", "restore" 
    ]

    mode = actions[choice]
    if mode == "restore":
        backup_restore.perform_restore()
    else:
        backup_restore.perform_backup(mode)


def show_support():
    """Mostra la finestra di dialogo personalizzata per il supporto"""
    telegram_url = "https://t.me/ItalianSpaghettiGeeks"
    
    # Crea una classe per la finestra di dialogo
    class SupportDialog(xbmcgui.WindowXMLDialog):
        def __init__(self, *args, **kwargs):
            self.telegram_url = kwargs.get('telegram_url')
            super(SupportDialog, self).__init__(*args, **kwargs)
        
        def onInit(self):
            try:
                # Imposta solo i testi (l'immagine QR è già definita in XML)
                label_control = self.getControl(9002)
                if label_control:
                    label_control.setLabel(addon.getLocalizedString(30807))  # "Telegram group:"
                
                url_control = self.getControl(9003)
                if url_control:
                    url_control.setLabel(self.telegram_url)
                    
            except Exception as e:
                xbmc.log(f"OptiKlean: Error initializing support dialog - {str(e)}", xbmc.LOGERROR)
        
        def onClick(self, controlId):
            try:
                if controlId == 9000:  # Pulsante Chiudi
                    self.close()
                elif controlId == 9003:  # Pulsante URL Telegram
                    self.open_telegram_url()
            except Exception as e:
                xbmc.log(f"OptiKlean: Error in support dialog click handler - {str(e)}", xbmc.LOGERROR)
        
        def open_telegram_url(self):
            """Apre l'URL di Telegram usando il browser o l'app nativa"""
            try:
                # Su Android, prova prima l'intent Telegram
                if xbmc.getCondVisibility("System.Platform.Android"):
                    xbmc.log("OptiKlean: Attempting to open Telegram via Android intent", xbmc.LOGINFO)
                    try:
                        xbmc.executebuiltin('StartAndroidActivity("org.telegram.messenger","android.intent.action.VIEW",,"tg://resolve?domain=ItalianSpaghettiGeeks")')
                        xbmc.log("OptiKlean: Successfully opened Telegram app", xbmc.LOGINFO)
                        return
                    except Exception as e:
                        xbmc.log(f"OptiKlean: Failed to open Telegram app: {str(e)}", xbmc.LOGWARNING)
                
                # Fallback: apri nel browser web
                browser_url = self.telegram_url
                xbmc.log(f"OptiKlean: Opening Telegram URL in browser: {browser_url}", xbmc.LOGINFO)
                
                # Prova diversi metodi per aprire l'URL
                if xbmc.getCondVisibility("System.Platform.Windows"):
                    # Windows: usa RunPlugin per aprire l'URL
                    xbmc.executebuiltin(f'System.Exec("cmd /c start {browser_url}")')
                elif xbmc.getCondVisibility("System.Platform.Linux"):
                    # Linux: usa xdg-open
                    xbmc.executebuiltin(f'System.Exec("xdg-open {browser_url}")')
                elif xbmc.getCondVisibility("System.Platform.OSX"):
                    # macOS: usa open
                    xbmc.executebuiltin(f'System.Exec("open {browser_url}")')
                elif xbmc.getCondVisibility("System.Platform.IOS"):
                    # iOS: limitazioni di sicurezza - mostra dialog con URL
                    xbmcgui.Dialog().ok(
                        heading=addon.getLocalizedString(30307),  # "Support"
                        message=f"{addon.getLocalizedString(30402)}\n\n{browser_url}"  # "Visit support group:" + URL
                    )
                    return
                elif xbmc.getCondVisibility("System.Platform.Android"):
                    # Android: usa intent browser come fallback
                    xbmc.executebuiltin(f'StartAndroidActivity("","android.intent.action.VIEW","","{browser_url}")')
                else:
                    # Fallback generico: mostra una notifica con l'URL
                    xbmcgui.Dialog().ok(
                        heading=addon.getLocalizedString(30307),  # "Support"
                        message=f"{addon.getLocalizedString(30402)}\n\n{browser_url}"  # "Visit support group:" + URL
                    )
                    return
                
            except Exception as e:
                xbmc.log(f"OptiKlean: Error opening Telegram URL: {str(e)}", xbmc.LOGERROR)
                # Fallback finale: mostra dialog con URL
                xbmcgui.Dialog().ok(
                    heading=addon.getLocalizedString(31218),  # "Error"
                    message=f"{addon.getLocalizedString(30402)}\n\n{self.telegram_url}"  # "Visit support group:" + URL
                )
    
    try:
        # Mostra la finestra di dialogo
        dialog = SupportDialog(
            'SupportDialog.xml',
            xbmcaddon.Addon().getAddonInfo('path'),
            'default',
            '1080i',
            telegram_url=telegram_url
        )
        dialog.doModal()
        del dialog
    except Exception as e:
        xbmc.log(f"OptiKlean: Error showing support dialog - {str(e)}", xbmc.LOGERROR)
        # Fallback alla dialog standard
        xbmcgui.Dialog().ok(
            heading=addon.getLocalizedString(30307),  # "Support"
            message=f"{addon.getLocalizedString(30402)}\n\n{telegram_url}"  # "Visit support group:" + URL
        )


# Funzione per visualizzare i log
def view_logs():
    log_reports = [
        (addon.getLocalizedString(30600), "clear_kodi_temp_folder.log"),
        (addon.getLocalizedString(30601), "clear_cache_files_from_addon_data.log"),
        (addon.getLocalizedString(30602), "clear_temp_folders_from_addon_data.log"),
        (addon.getLocalizedString(30603), "clear_temp_folder_from_addons.log"),
        (addon.getLocalizedString(30604), "clear_unused_thumbnails.log"),
        (addon.getLocalizedString(30605), "clear_older_thumbnails.log"),
        (addon.getLocalizedString(30606), "clear_addon_leftovers.log"),
        (addon.getLocalizedString(30607), "clear_kodi_packages.log"),
        (addon.getLocalizedString(30608), "optimize_databases.log"),
        (addon.getLocalizedString(30609), "automatic_cleaning_settings.log"),

        # Backup logs
        (addon.getLocalizedString(30626), "backup_full.log"),
        (addon.getLocalizedString(30610), "backup_addons.log"),
        (addon.getLocalizedString(30611), "backup_addon_data.log"),
        (addon.getLocalizedString(30612), "backup_addons_and_data.log"),
        (addon.getLocalizedString(30613), "backup_skins.log"),
        (addon.getLocalizedString(30614), "backup_databases.log"),
        (addon.getLocalizedString(30615), "backup_sources.log"),
        (addon.getLocalizedString(30616), "backup_GUI_settings.log"),
        (addon.getLocalizedString(30617), "backup_profiles.log"),
        (addon.getLocalizedString(30618), "backup_advanced_settings.log"),
        (addon.getLocalizedString(30619), "backup_keymaps.log"),
        (addon.getLocalizedString(30620), "backup_playlists.log"),

        # Restore log
        (addon.getLocalizedString(30621), "restore_backup.log")
    ]

    # Create a list of user-friendly names
    display_names = [name for name, _ in log_reports]
    selected = xbmcgui.Dialog().select(addon.getLocalizedString(31196), display_names)  # "Select log to view"

    if selected != -1:
        _, filename = log_reports[selected]
        log_file = os.path.join(addon_data_folder, filename)

        try:
            if os.path.exists(log_file):
                with open(log_file, "r", encoding="utf-8") as f:
                    content = f.read()
                if not content.strip():
                    content = addon.getLocalizedString(31220)  # "Empty content"
            else:
                content = addon.getLocalizedString(31221)  # "Log file not found."
        except Exception as e:
            content = addon.getLocalizedString(31222).format(error=str(e))  # "Error reading log file: {error}"

        xbmcgui.Dialog().textviewer(addon.getLocalizedString(31223).format(log_name=display_names[selected]), content)  # "Log: {log_name}"


def run_automatic_maintenance():
    """Esegue la manutenzione automatica quando chiamato da autoexec.py"""
    xbmc.log("OptiKlean: Avvio manutenzione automatica", xbmc.LOGINFO)
    
    actions_executed = []
    addon = xbmcaddon.Addon()
    
    # Ensure data folder exists
    if not xbmcvfs.exists(addon_data_folder):
        xbmcvfs.mkdirs(addon_data_folder)
        xbmc.log("OptiKlean: Created addon data folder", xbmc.LOGINFO)
    
    def should_run_cleaning(cleaning_type):
        """Determina se una determinata pulizia deve essere eseguita in base allo switch e all'intervallo"""
        try:
            # Verifica se è abilitata nelle impostazioni
            if not addon.getSettingBool(f"{cleaning_type}_enable"):
                xbmc.log(f"OptiKlean: {cleaning_type} non eseguita perché disabilitata", xbmc.LOGDEBUG)
                return False

            interval = addon.getSettingInt(f"{cleaning_type}_interval")
            last_run_file = os.path.join(addon_data_folder, f"last_{cleaning_type}.json")

            if not xbmcvfs.exists(last_run_file):
                return True  # prima esecuzione

            with open(last_run_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
                last_run = data.get("timestamp", 0)

            if last_run == 0:
                return True

            next_run = last_run + (interval * 86400)
            now = int(time.time())
            return now >= next_run

        except Exception as e:
            xbmc.log(f"OptiKlean: Errore in should_run_cleaning: {str(e)}", xbmc.LOGERROR)
            return False


    def run_cleaning(cleaning_name, function, success_message):
        """Esegue una pulizia se è attiva e dovrebbe essere eseguita"""
        try:
            enabled = addon.getSettingBool(f"{cleaning_name}_enable")
            if not enabled:
                xbmc.log(f"OptiKlean: {cleaning_name} è disabilitato, salto pulizia", xbmc.LOGINFO)
                return False

            if should_run_cleaning(cleaning_name):
                xbmc.log(f"OptiKlean: Starting {cleaning_name} cleaning", xbmc.LOGINFO)

                if 'auto_mode' in function.__code__.co_varnames:
                    function(auto_mode=True)
                else:
                    function()

                update_last_run(cleaning_name)
                actions_executed.append(success_message)

                xbmc.log(f"OptiKlean: Completed {cleaning_name} cleaning", xbmc.LOGINFO)
                return True
            else:
                xbmc.log(f"OptiKlean: {cleaning_name} non necessario al momento", xbmc.LOGINFO)
                return False

        except Exception as e:
            xbmc.log(f"OptiKlean: Error during {cleaning_name}: {str(e)}", xbmc.LOGERROR)
            return False
    
    # Execute cleanings
    run_cleaning("clear_cache_and_temp", clear_cache_and_temp, "Cache/temp")
    run_cleaning("clear_unused_thumbnails", clear_unused_thumbnails, "Thumbnails")
    run_cleaning("clear_addon_leftovers", clear_addon_leftovers, "Addon leftovers")
    run_cleaning("clear_kodi_packages", clear_kodi_packages, "Packages")
    run_cleaning("optimize_databases", optimize_databases, "Databases")

    # Show notification if any action was executed
    if actions_executed:
        msg = "Auto-clean: " + ", ".join(actions_executed)
        xbmc.executebuiltin(f'Notification(OptiKlean, {msg}, 4000)')
        xbmc.log(f"OptiKlean: Completed cleanings - {msg}", xbmc.LOGINFO)
        
        # Aggiorna il log delle impostazioni dopo le pulizie
        try:
            update_automatic_settings_log()
        except Exception as e:
            xbmc.log(f"OptiKlean: Error updating settings log: {str(e)}", xbmc.LOGERROR)
    else:
        xbmc.log("OptiKlean: No cleanings required at this time", xbmc.LOGINFO)


class BaseWindow(xbmcgui.WindowXML):
    """Classe base comune per le finestre dell'addon con funzioni condivise"""
    
    def __init__(self, xmlFilename, scriptPath, defaultSkin='default', defaultRes='1080i'):
        super().__init__(xmlFilename, scriptPath, defaultSkin, defaultRes)
    
    def onAction(self, action):
        """Gestisce le azioni comuni (come ESC, Back, etc.)"""
        if action.getId() in (9, 10, 92, 216, 247, 257, 275, 61467, 61448):
            self.close()


class DetailsWindow(BaseWindow):
    """Classe per gestire la finestra dei dettagli delle cartelle"""
    
    def __init__(self, xmlFilename, scriptPath, defaultSkin='default', defaultRes='1080i'):
        super().__init__(xmlFilename, scriptPath, defaultSkin, defaultRes)
        self.folder_path = ""
        self.exclude_folders = []
        self.total_size = 0
        self.folder_sizes = []
    
    def set_folder_path(self, folder_path, exclude_folders=None):
        """Imposta il percorso della cartella da analizzare e le cartelle da escludere"""
        if folder_path:
            self.folder_path = folder_path
        self.exclude_folders = exclude_folders or []
    
    def calculate_folder_sizes(self):
        """Calcola le dimensioni di tutte le cartelle/file nella directory specificata"""
        self.folder_sizes = []
        self.total_size = 0
        
        try:
            if xbmcvfs.exists(self.folder_path):
                dirs, files = xbmcvfs.listdir(self.folder_path)
                
                # Analizza prima le cartelle
                for dir_name in dirs:
                    if dir_name not in self.exclude_folders:  # Escludi cartelle specificate
                        dir_path = xbmcvfs.makeLegalFilename(os.path.join(self.folder_path, dir_name))
                        size = get_folder_size(dir_path)
                        if size > 0:  # Mostra solo cartelle con contenuto
                            self.folder_sizes.append((dir_name, size))
                            self.total_size += size
                
                # Se non ci sono cartelle significative, analizza i file individuali
                # (utile per la cartella packages che contiene principalmente file .zip)
                if len(self.folder_sizes) == 0:
                    for file_name in files:
                        if file_name not in self.exclude_folders:  # Escludi file specificati
                            file_path = xbmcvfs.makeLegalFilename(os.path.join(self.folder_path, file_name))
                            try:
                                size = get_file_size(file_path)
                                if size > 0:  # Mostra solo file con contenuto
                                    self.folder_sizes.append((file_name, size))
                                    self.total_size += size
                            except Exception as e:
                                xbmc.log(f"OptiKlean DEBUG: Error getting file size for {file_path}: {str(e)}", xbmc.LOGERROR)
                
                # Ordina per dimensione (decrescente)
                self.folder_sizes.sort(key=lambda x: x[1], reverse=True)
        except Exception as e:
            xbmc.log(f"OptiKlean DEBUG: Error calculating folder sizes: {str(e)}", xbmc.LOGERROR)
    
    def onInit(self):
        """Inizializzazione della finestra"""
        try:
            xbmc.log("OptiKlean: DetailsWindow onInit called", xbmc.LOGINFO)
            # IMPOSTA IL TITOLO DELLA FINESTRA (tradotto)
            self.getControl(1).setLabel(addon.getLocalizedString(30306))  # "Folder Space Analysis"
            
            # IMPOSTA LE INTESTAZIONI DELLE COLONNE (tradotte)
            self.getControl(10).setLabel(addon.getLocalizedString(30802))  # "Percentage"
            self.getControl(11).setLabel(addon.getLocalizedString(30803))  # "Size"
            self.getControl(12).setLabel(addon.getLocalizedString(30804))  # "Folder"
            
            # Carica i dati delle cartelle
            if not self.folder_path:
                xbmc.log("OptiKlean: No folder path set for DetailsWindow", xbmc.LOGWARNING)
                self.getControl(1).setLabel(addon.getLocalizedString(31169))  # "Unable to load folder details"
                return
                
            # Calculate folder sizes
            self.calculate_folder_sizes()
            
            if not self.folder_sizes:
                xbmc.log("OptiKlean: No folder data to display", xbmc.LOGWARNING)
                self.getControl(1).setLabel(addon.getLocalizedString(31169))  # "Unable to load folder details"
                return
            
            # Popola la lista con i dati degli addon
            try:
                list_control = self.getControl(5000)
                list_control.reset()  # Pulisce la lista
                
                for folder_name, size in self.folder_sizes:
                    if self.total_size > 0:
                        percentage = (size / self.total_size) * 100
                    else:
                        percentage = 0
                    
                    # Crea un ListItem per ogni cartella
                    list_item = xbmcgui.ListItem(folder_name)
                    
                    # Mostra percentuali con un decimale per maggiore precisione
                    if percentage >= 0.1:
                        list_item.setProperty("percentage", f"{percentage:.1f}%")
                    elif percentage >= 0.01:
                        list_item.setProperty("percentage", f"{percentage:.2f}%")
                    else:
                        list_item.setProperty("percentage", "<0.01%")
                    list_item.setProperty("size", format_size(size))
                    
                    # Aggiungi l'item alla lista
                    list_control.addItem(list_item)
                
                xbmc.log(f"OptiKlean: DetailsWindow displayed {len(self.folder_sizes)} folders", xbmc.LOGINFO)
                
            except RuntimeError as e:
                xbmc.log(f"OptiKlean DEBUG: Error setting up list control: {str(e)}", xbmc.LOGERROR)
            
        except Exception as e:
            xbmc.log(f"OptiKlean ERROR: Error in DetailsWindow onInit: {str(e)}", xbmc.LOGERROR)
            # Fallback: mostra una finestra di dialogo con le informazioni
            try:
                self.calculate_folder_sizes()
                
                # Costruisci il messaggio formattato come tabella
                message = "Folder Space Analysis\n\n"
                message += f"Total directory size: {format_size(self.total_size)}\n\n"
                message += "Percentage | Size      | Folder\n"
                message += "-" * 50 + "\n"
                
                for folder_name, size in self.folder_sizes[:10]:  # Mostra solo i primi 10
                    if self.total_size > 0:
                        percentage = (size / self.total_size) * 100
                    else:
                        percentage = 0
                    
                    # Formato percentuale migliorato
                    if percentage >= 0.1:
                        perc_str = f"{percentage:7.1f}%"
                    elif percentage >= 0.01:
                        perc_str = f"{percentage:7.2f}%"
                    else:
                        perc_str = "  <0.01%"
                    
                    message += f"{perc_str}   {format_size(size):>8s}   {folder_name}\n"
                
                if len(self.folder_sizes) > 10:
                    message += f"\n... and {len(self.folder_sizes) - 10} more folders"
                
                xbmcgui.Dialog().textviewer(addon.getLocalizedString(31224), message)  # "Folder Details"
                self.close()
            except Exception as fallback_error:
                xbmc.log(f"OptiKlean ERROR: Fallback error: {str(fallback_error)}", xbmc.LOGERROR)
                xbmcgui.Dialog().ok(addon.getLocalizedString(31168), addon.getLocalizedString(31169))
                self.close()
    
    def onClick(self, controlId):
        """Gestisce i click sui controlli"""
        if controlId == 9000:  # Close button (X)
            self.close()


class AllInOnePanelWindow(BaseWindow):
    """Classe per gestire la finestra All in One Panel"""
    
    def __init__(self, xmlFilename, scriptPath, defaultSkin='default', defaultRes='1080i'):
        super().__init__(xmlFilename, scriptPath, defaultSkin, defaultRes)
        xbmc.log("OptiKlean: AllInOnePanelWindow initialized", xbmc.LOGINFO)
        
        # Inizializza i percorsi
        self.db_path = xbmcvfs.translatePath("special://database/")
        self.thumbnails_path = xbmcvfs.translatePath("special://profile/thumbnails/")
        self.addon_dir = xbmcvfs.translatePath("special://home/addons/")
        self.addon_data_dir = xbmcvfs.translatePath("special://profile/addon_data/")
        self.packages_path = xbmcvfs.translatePath("special://home/addons/packages/")
        self.temp_path = xbmcvfs.translatePath("special://home/addons/temp/")
        self.temp_folder = xbmcvfs.translatePath("special://temp/")
    
    def calculate_unused_thumbnails_size(self):
        """Calcola la dimensione delle thumbnails inutilizzate analizzando il database delle texture"""
        total_size = 0
        
        # Usa la funzione esistente find_texture_database con il path già definito
        texture_db = find_texture_database(self.db_path)
        
        if not texture_db:
            xbmc.log("OptiKlean: Texture database not found for size calculation", xbmc.LOGWARNING)
            return 0
        
        try:
            import sqlite3
            conn = sqlite3.connect(texture_db)
            cursor = conn.cursor()
            
            # Query per ottenere tutte le thumbnail dal database
            cursor.execute("SELECT cachedurl FROM texture")
            db_thumbs = set(row[0] for row in cursor.fetchall())
            conn.close()
            
            # Percorsi delle thumbnails
            thumb_paths = [self.thumbnails_path]
            if xbmcvfs.exists(xbmcvfs.translatePath("special://thumbnails/")):
                thumb_paths.append(xbmcvfs.translatePath("special://thumbnails/"))
            
            # Controlla ogni thumbnail sul disco
            for thumb_base in thumb_paths:
                if not xbmcvfs.exists(thumb_base):
                    continue
                    
                # Naviga ricorsivamente tutte le sottocartelle
                for root, dirs, files in os.walk(thumb_base):
                    for file in files:
                        full_path = os.path.join(root, file)
                        # Calcola il percorso relativo per confronto con DB
                        rel_path = os.path.relpath(full_path, thumb_base).replace('\\', '/')
                        
                        # Se non è nel database, conta come inutilizzata
                        if rel_path not in db_thumbs:
                            try:
                                total_size += os.path.getsize(full_path)
                            except (OSError, IOError) as e:
                                # File potrebbe essere stato eliminato o non accessibile
                                xbmc.log(f"OptiKlean DEBUG: Could not get size for {full_path}: {str(e)}", xbmc.LOGDEBUG)
                            except Exception as e:
                                xbmc.log(f"OptiKlean DEBUG: Unexpected error getting size for {full_path}: {str(e)}", xbmc.LOGWARNING)
            
        except Exception as e:
            xbmc.log(f"OptiKlean: Error calculating unused thumbnails size: {str(e)}", xbmc.LOGERROR)
        
        return total_size
    
    def calculate_addon_leftovers_size(self):
        """Calcola lo spazio occupato da addons disabilitati e residui"""
        total_size = 0
        
        try:
            # Get enabled and disabled addons
            enabled_addons = []
            disabled_addons = []
            
            try:
                json_response = xbmc.executeJSONRPC('{"jsonrpc":"2.0", "method":"Addons.GetAddons", "params":{"enabled":true}, "id":1}')
                response = json.loads(json_response)
                if 'result' in response and 'addons' in response['result']:
                    enabled_addons = [addon['addonid'] for addon in response['result']['addons']]
            except (json.JSONDecodeError, KeyError, TypeError) as e:
                xbmc.log(f"OptiKlean DEBUG: Error getting enabled addons: {str(e)}", xbmc.LOGWARNING)
            except Exception as e:
                xbmc.log(f"OptiKlean DEBUG: Unexpected error getting enabled addons: {str(e)}", xbmc.LOGERROR)
            
            try:
                json_response = xbmc.executeJSONRPC('{"jsonrpc":"2.0", "method":"Addons.GetAddons", "params":{"enabled":false}, "id":1}')
                response = json.loads(json_response)
                if 'result' in response and 'addons' in response['result']:
                    disabled_addons = [addon['addonid'] for addon in response['result']['addons']]
            except (json.JSONDecodeError, KeyError, TypeError) as e:
                xbmc.log(f"OptiKlean DEBUG: Error getting disabled addons: {str(e)}", xbmc.LOGWARNING)
            except Exception as e:
                xbmc.log(f"OptiKlean DEBUG: Unexpected error getting disabled addons: {str(e)}", xbmc.LOGERROR)
            
            all_installed = set(enabled_addons + disabled_addons)
            
            # Check addon folders for orphaned/disabled
            if os.path.exists(self.addon_dir):
                for folder in os.listdir(self.addon_dir):
                    if folder in ('packages', 'temp'):
                        continue
                    folder_path = os.path.join(self.addon_dir, folder)
                    if os.path.isdir(folder_path):
                        # Count if disabled or orphaned
                        if folder not in all_installed or folder in disabled_addons:
                            total_size += get_folder_size(folder_path)
            
            # Check addon_data folders
            if os.path.exists(self.addon_data_dir):
                for folder in os.listdir(self.addon_data_dir):
                    if folder in ('packages',):
                        continue
                    folder_path = os.path.join(self.addon_data_dir, folder)
                    if os.path.isdir(folder_path):
                        if folder not in all_installed or folder in disabled_addons:
                            total_size += get_folder_size(folder_path)

        except Exception as e:
            xbmc.log(f"OptiKlean: Error calculating addon leftovers size: {str(e)}", xbmc.LOGERROR)
        
        return total_size
    
    def calculate_sizes(self):
        """Calcola le dimensioni di tutti i componenti pulibili"""
        sizes = {
            'addons': 0,
            'addon_data': 0,
            'packages': 0,
            'thumbnails': 0,
            'total': 0,
            'cache_temp': 0,
            'unused_thumbs': 0,
            'addon_leftovers': 0,
            'kodi_packages': 0,
            'total_recoverable': 0
        }
        
        try:
            # Calculate actual folder sizes
            if os.path.exists(self.addon_dir):
                sizes['addons'] = get_folder_size(self.addon_dir)
            
            if os.path.exists(self.addon_data_dir):
                sizes['addon_data'] = get_folder_size(self.addon_data_dir)
            
            if os.path.exists(self.packages_path):
                sizes['packages'] = get_folder_size(self.packages_path)
            
            if os.path.exists(self.thumbnails_path):
                sizes['thumbnails'] = get_folder_size(self.thumbnails_path)
            
            # Calculate total used
            sizes['total'] = sizes['addons'] + sizes['addon_data'] + sizes['packages'] + sizes['thumbnails']
            
            # Calculate recoverable space (estimates for cleanup tasks)
            # Cache/temp from addon_data
            addon_data_cache_temp = 0
            if os.path.exists(self.addon_data_dir):
                for addon_folder in os.listdir(self.addon_data_dir):
                    addon_path = os.path.join(self.addon_data_dir, addon_folder)
                    if os.path.isdir(addon_path):
                        # Check for cache folders
                        cache_path = os.path.join(addon_path, 'cache')
                        if os.path.exists(cache_path):
                            addon_data_cache_temp += get_folder_size(cache_path)
                        # Check for temp folders
                        temp_path = os.path.join(addon_path, 'temp')
                        if os.path.exists(temp_path):
                            addon_data_cache_temp += get_folder_size(temp_path)
            
            # Temp folder
            temp_folder_size = 0
            if os.path.exists(self.temp_folder):
                temp_folder_size = get_folder_size(self.temp_folder)
            
            sizes['cache_temp'] = addon_data_cache_temp + temp_folder_size
            
            # Unused thumbnails
            sizes['unused_thumbs'] = self.calculate_unused_thumbnails_size()
            
            # Addon leftovers
            sizes['addon_leftovers'] = self.calculate_addon_leftovers_size()
            
            # Packages (all of them are potentially removable)
            sizes['kodi_packages'] = sizes['packages']
            
            # Total recoverable
            sizes['total_recoverable'] = (sizes['cache_temp'] + sizes['unused_thumbs'] + 
                                         sizes['addon_leftovers'] + sizes['kodi_packages'])

        except Exception as e:
            xbmc.log(f"OptiKlean: Error in calculate_sizes: {str(e)}", xbmc.LOGERROR)
        
        return sizes

    def refresh_data(self):
        """Ricalcola e aggiorna tutti i valori nella UI"""
        try:
            progress = xbmcgui.DialogProgress()
            progress.create("OptiKlean", addon.getLocalizedString(31202))  # "Refreshing data..."
            
            progress.update(10, addon.getLocalizedString(31215))  # "Preparing to recalculate sizes..."
            
            progress.update(50, addon.getLocalizedString(31216))  # "Calculating updated sizes..."
            sizes = self.calculate_sizes()
            
            # Update UI labels with new values
            try:
                # Addons size
                self.getControl(8002).setLabel(format_size(sizes['addons']))
                # Addon data size
                self.getControl(8004).setLabel(format_size(sizes['addon_data']))
                # Packages size
                self.getControl(8006).setLabel(format_size(sizes['packages']))
                # Thumbnails size
                self.getControl(8008).setLabel(format_size(sizes['thumbnails']))
                # Total used
                self.getControl(8010).setLabel(format_size(sizes['total']))
                
                # Recoverable sizes
                self.getControl(8012).setLabel(format_size(sizes['cache_temp']))
                self.getControl(8014).setLabel(format_size(sizes['unused_thumbs']))
                self.getControl(8016).setLabel(format_size(sizes['addon_leftovers']))
                self.getControl(8018).setLabel(format_size(sizes['kodi_packages']))
                self.getControl(8020).setLabel(format_size(sizes['total_recoverable']))
            except Exception as e:
                xbmc.log(f"OptiKlean: Error updating UI controls: {str(e)}", xbmc.LOGERROR)
            
            progress.update(100, addon.getLocalizedString(31217))  # "Data refresh completed!"
            time.sleep(1)
            progress.close()
            
        except Exception as e:
            xbmc.log(f"OptiKlean: Error in refresh_data: {str(e)}", xbmc.LOGERROR)
            if 'progress' in locals():
                progress.close()

    def show_addons_details(self):
        """Mostra la finestra dei dettagli degli addons"""
        try:
            details_window = DetailsWindow(
                'DetailsWindow.xml',
                addon.getAddonInfo('path'),
                'default',
                '1080i'
            )
            details_window.set_folder_path(self.addon_dir, exclude_folders=['packages', 'temp'])
            details_window.doModal()
            del details_window
            
        except Exception as e:
            xbmc.log(f"OptiKlean: Error showing addons details: {str(e)}", xbmc.LOGERROR)
            xbmcgui.Dialog().notification(
                addon.getLocalizedString(31218),  # "Error"
                addon.getLocalizedString(31169),  # "Unable to load folder details"
                xbmcgui.NOTIFICATION_ERROR,
                3000
            )

    def show_addon_data_details(self):
        """Mostra la finestra dei dettagli dell'addon data"""
        try:
            details_window = DetailsWindow(
                'DetailsWindow.xml',
                addon.getAddonInfo('path'),
                'default',
                '1080i'
            )
            details_window.set_folder_path(self.addon_data_dir, exclude_folders=['packages'])
            details_window.doModal()
            del details_window
            
        except Exception as e:
            xbmc.log(f"OptiKlean: Error showing addon data details: {str(e)}", xbmc.LOGERROR)
            xbmcgui.Dialog().notification(
                addon.getLocalizedString(31218),  # "Error"
                addon.getLocalizedString(31169),  # "Unable to load folder details"
                xbmcgui.NOTIFICATION_ERROR,
                3000
            )

    def show_packages_details(self):
        """Mostra la finestra dei dettagli dei packages"""
        try:
            details_window = DetailsWindow(
                'DetailsWindow.xml',
                addon.getAddonInfo('path'),
                'default',
                '1080i'
            )
            details_window.set_folder_path(self.packages_path)
            details_window.doModal()
            del details_window
            
        except Exception as e:
            xbmc.log(f"OptiKlean: Error showing packages details: {str(e)}", xbmc.LOGERROR)
            xbmcgui.Dialog().notification(
                addon.getLocalizedString(31218),  # "Error"
                addon.getLocalizedString(31169),  # "Unable to load folder details"
                xbmcgui.NOTIFICATION_ERROR,
                3000
            )

    def onInit(self):
        """Inizializzazione della finestra"""
        try:
            # IMPOSTA I TITOLI DELLE SEZIONI
            self.getControl(1).setLabel(addon.getLocalizedString(30800))  # "Actual used space:"
            self.getControl(2).setLabel(addon.getLocalizedString(30809))  # "Estimated space savings..."
            
            # IMPOSTA LE LABEL FISSE DELLA SEZIONE 1 (Spazio utilizzato)
            self.getControl(10).setLabel(addon.getLocalizedString(30813))  # "Addons:"
            self.getControl(11).setLabel(addon.getLocalizedString(30801))  # "Addons data:"
            self.getControl(12).setLabel(addon.getLocalizedString(30805))  # "Kodi packages:"
            self.getControl(13).setLabel(addon.getLocalizedString(30806))  # "Thumbnails:"
            self.getControl(14).setLabel(addon.getLocalizedString(30808))  # "Total used:"
            
            # IMPOSTA LE LABEL FISSE DELLA SEZIONE 2 (Risparmio stimato)
            self.getControl(21).setLabel(addon.getLocalizedString(30100))  # "Clear cache and temp"
            self.getControl(22).setLabel(addon.getLocalizedString(30101))  # "Clear unused/older thumbnails"
            self.getControl(23).setLabel(addon.getLocalizedString(30102))  # "Clear addons leftovers"
            self.getControl(24).setLabel(addon.getLocalizedString(30103))  # "Clear packages"
            self.getControl(25).setLabel(addon.getLocalizedString(30810))  # "Total recoverable:"
            
            # IMPOSTA LE LABEL INIZIALI DEI VALORI DINAMICI SU "Loading..."
            loading_text = addon.getLocalizedString(31225)  # "Loading..."
            
            # Sezione 1 - Valori dinamici
            self.getControl(110).setLabel(loading_text)
            self.getControl(111).setLabel(loading_text)
            self.getControl(112).setLabel(loading_text)
            self.getControl(113).setLabel(loading_text)
            self.getControl(114).setLabel(loading_text)
            
            # Sezione 2 - Valori dinamici
            self.getControl(121).setLabel(loading_text)
            self.getControl(122).setLabel(loading_text)
            self.getControl(123).setLabel(loading_text)
            self.getControl(124).setLabel(loading_text)
            self.getControl(125).setLabel(loading_text)
            
            # IMPOSTA LE LABEL DEI PULSANTI
            self.getControl(201).setLabel(addon.getLocalizedString(30811))  # "Clean all!"
            self.getControl(202).setLabel(addon.getLocalizedString(30812))  # "Restart Kodi"
            
            # ORA CALCOLA E AGGIORNA I VALORI DINAMICI
            sizes = self.calculate_sizes()
            
            # Aggiorna i valori calcolati
            # Sezione 1 - Spazio utilizzato
            self.getControl(110).setLabel(format_size(sizes['addons']))
            self.getControl(111).setLabel(format_size(sizes['addon_data']))
            self.getControl(112).setLabel(format_size(sizes['packages']))
            self.getControl(113).setLabel(format_size(sizes['thumbnails']))
            self.getControl(114).setLabel(format_size(sizes['total']))
            
            # Sezione 2 - Risparmio stimato
            self.getControl(121).setLabel(format_size(sizes['cache_temp']))
            self.getControl(122).setLabel(format_size(sizes['unused_thumbs']))
            self.getControl(123).setLabel(format_size(sizes['addon_leftovers']))
            self.getControl(124).setLabel(format_size(sizes['kodi_packages']))
            self.getControl(125).setLabel(format_size(sizes['total_recoverable']))            
        except Exception as e:
            xbmc.log(f"OptiKlean: Error in AllInOnePanelWindow.onInit: {str(e)}", xbmc.LOGERROR)
    
    def onClick(self, controlId):
        """Gestisce i click sui controlli"""
        try:
            if controlId == 9000:  # Close button
                self.close()
            
            elif controlId == 101:  # Details Addons button (icona lente)
                self.show_addons_details()
            elif controlId == 102:  # Details Addon Data button (icona lente)
                self.show_addon_data_details()
            elif controlId == 103:  # Details Packages button (icona lente)
                self.show_packages_details()
            
            # mantieni anche i vecchi id se usati altrove
            elif controlId == 8001:  # Addons details button
                self.show_addons_details()
            elif controlId == 8003:  # Addon data details button
                self.show_addon_data_details()
            elif controlId == 8005:  # Packages details button
                self.show_packages_details()
            
            elif controlId == 201:  # Clean all button
                if xbmcgui.Dialog().yesno(
                    addon.getLocalizedString(31172),  # "Confirmation"
                    addon.getLocalizedString(31201)   # "Running full cleanup..."
                ):
                    # Run all cleanup tasks
                    progress = xbmcgui.DialogProgress()
                    progress.create("OptiKlean", addon.getLocalizedString(31201))
                    
                    try:
                        # Execute cleanup functions
                        clear_cache_and_temp(auto_mode=True)
                        if progress.iscanceled():
                            return
                        
                        clear_unused_thumbnails(auto_mode=True)
                        if progress.iscanceled():
                            return
                        
                        clear_addon_leftovers(auto_mode=True)
                        if progress.iscanceled():
                            return
                        
                        clear_kodi_packages(auto_mode=True)
                        if progress.iscanceled():
                            return
                        
                        # Refresh data
                        self.refresh_data()
                        
                    except Exception as e:
                        xbmc.log(f"OptiKlean: Error during full cleanup: {str(e)}", xbmc.LOGERROR)
                        xbmcgui.Dialog().notification(
                            "OptiKlean",
                            addon.getLocalizedString(31174),  # "Cleanup failed (see log)"
                            xbmcgui.NOTIFICATION_ERROR,
                            5000
                        )
                    finally:
                        if 'progress' in locals():
                            progress.close()
                            
            elif controlId == 8021:  # Refresh button
                self.refresh_data()
            elif controlId == 202:  # Restart Kodi button
                if xbmcgui.Dialog().yesno(
                    addon.getLocalizedString(31172),  # "Confirmation"
                    addon.getLocalizedString(31173)   # "Would you like to restart Kodi now?"
                ):
                    xbmc.executebuiltin('RestartApp')
                    
        except Exception as e:
            xbmc.log(f"OptiKlean: Error in AllInOnePanelWindow.onClick: {str(e)}", xbmc.LOGERROR)

def show_all_in_one_panel():
    """Apre la finestra personalizzata All in One Panel"""
    try:
        # Usa il percorso dell'addon correttamente
        addon_path = addon.getAddonInfo('path')
        xml_file = "AllInOnePanel.xml"
        
        # Verifica che il file XML esista
        xml_full_path = os.path.join(addon_path, "resources", "skins", "default", "1080i", xml_file)
        if not xbmcvfs.exists(xml_full_path):
            xbmc.log(f"OptiKlean ERROR: File XML non trovato: {xml_full_path}", xbmc.LOGERROR)
            xbmcgui.Dialog().notification("OptiKlean", addon.getLocalizedString(31170), xbmcgui.NOTIFICATION_ERROR, 5000)
            return
        
        xbmc.log(f"OptiKlean: Aprendo finestra XML da: {xml_full_path}", xbmc.LOGINFO)
        
        # Crea e mostra la finestra personalizzata usando la classe
        window = AllInOnePanelWindow(xml_file, addon_path, "default", "1080i")
        window.doModal()
        del window
        
    except Exception as e:
        xbmc.log(f"OptiKlean ERROR: Errore nell'apertura della finestra All in One Panel: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification(addon.getLocalizedString(31218), addon.getLocalizedString(31171).format(error=str(e)), xbmcgui.NOTIFICATION_ERROR, 5000)


def open_addon_settings():
    # Apre le impostazioni dell'addon
    addon.openSettings()


# Gestione dei parametri per eseguire l'azione selezionata
if __name__ == '__main__':
    # Controlla per il parametro "autorun" da service.py (fallback)
    if len(sys.argv) > 1 and sys.argv[1] == 'autorun':
        xbmc.log("OptiKlean: Rilevato parametro autorun", xbmc.LOGINFO)
        run_automatic_maintenance()
    else:
        # Elaborazione normale dei parametri del menu
        params = {}
        if len(sys.argv) > 2 and sys.argv[2].startswith('?'):
            params = dict(pair.split('=') for pair in sys.argv[2][1:].split('&') if '=' in pair)
        action = params.get("action")
        
        if action == "clear_cache_and_temp":
            clear_cache_and_temp()
        elif action == "clear_unused_thumbnails":
            clear_unused_thumbnails()
        elif action == "clear_addon_leftovers":
            clear_addon_leftovers()
        elif action == "clear_kodi_packages":
            clear_kodi_packages()
        elif action == "optimize_databases":
            optimize_databases()
        elif action == "all_in_one_panel":
            show_all_in_one_panel()
        elif action == "backup_and_restore":
            show_backup_dialog()
        elif action == "view_logs":
            view_logs()
        elif action == "show_support":
            show_support()
        elif action == "open_addon_settings":
            open_addon_settings()
        else:
            show_menu()
