import os
import zipfile
import shutil
import json
import time
from datetime import datetime
import ctypes

import xbmcvfs
import xbmcgui
import xbmc
import xbmcaddon


addon = xbmcaddon.Addon()
addon_id = addon.getAddonInfo('id')

addon_path = xbmcvfs.translatePath(addon.getAddonInfo("path"))
media_path = f"{addon_path}/resources/media/"
logo_path = f"{media_path}logo.png"

def is_network_path(path):
    """Check if path is a network/remote path"""
    return any(path.lower().startswith(proto) for proto in ['smb://', 'nfs://', 'ftp://', 'sftp://', 'http://', 'https://'])

def safe_path_join(*paths):
    """Cross-platform path joining using xbmcvfs methods"""
    if not paths:
        return ""
    
    result = str(paths[0])
    for path in paths[1:]:
        if result.endswith('/') or result.endswith('\\'):
            result = result.rstrip('/\\')
        if str(path).startswith('/') or str(path).startswith('\\'):
            path = str(path).lstrip('/\\')
        result = result + '/' + str(path)
    
    return result

def safe_file_size(path):
    """Get file size using xbmcvfs for network compatibility"""
    try:
        if xbmcvfs.exists(path):
            with xbmcvfs.File(path, 'r') as f:
                return f.size()
        return 0
    except Exception as e:
        xbmc.log(f"OptiKlean: Error getting file size {path}: {e}", xbmc.LOGWARNING)
        return 0

def safe_copy_file(source, dest):
    """Copy file using xbmcvfs for network compatibility with detailed error logging"""
    try:
        # Log the operation for debugging
        xbmc.log(f"OptiKlean: Attempting to copy from {source} to {dest}", xbmc.LOGDEBUG)
        
        # Verifica che il file sorgente esista
        source_exists = False
        if source.startswith('/') or (len(source) > 1 and source[1] == ':'):
            # Percorso assoluto locale - usa os.path.exists
            source_exists = os.path.exists(source)
        else:
            # Percorso xbmcvfs - usa xbmcvfs.exists
            source_exists = xbmcvfs.exists(source)
        
        if not source_exists:
            xbmc.log(f"OptiKlean: Source file does not exist: {source}", xbmc.LOGWARNING)
            return False
        
        # Ensure destination directory exists
        dest_dir = '/'.join(dest.split('/')[:-1])
        if dest_dir and not xbmcvfs.exists(dest_dir):
            if not xbmcvfs.mkdirs(dest_dir):
                xbmc.log(f"OptiKlean: Failed to create destination directory: {dest_dir}", xbmc.LOGWARNING)
                return False
        
        # Attempt the copy operation
        copy_result = xbmcvfs.copy(source, dest)
        if copy_result:
            # Verifica che la copia sia andata a buon fine controllando se il file di destinazione esiste
            if xbmcvfs.exists(dest):
                xbmc.log(f"OptiKlean: Successfully copied {source} to {dest}", xbmc.LOGDEBUG)
                return True
            else:
                xbmc.log(f"OptiKlean: Copy reported success but destination file not found: {dest}", xbmc.LOGWARNING)
                return False
        else:
            xbmc.log(f"OptiKlean: xbmcvfs.copy returned False for {source} to {dest}", xbmc.LOGWARNING)
            return False
            
    except Exception as e:
        xbmc.log(f"OptiKlean: Exception copying file {source} to {dest}: {e}", xbmc.LOGWARNING)
        return False

def is_valid_optiklean_backup(zip_path):
    try:
        # Handle both local and network paths
        if is_network_path(zip_path):
            # For network paths, copy to temp location first
            temp_dir = xbmcvfs.translatePath("special://temp/")
            temp_file = safe_path_join(temp_dir, "temp_backup_check.zip")
            if xbmcvfs.copy(zip_path, temp_file):
                try:
                    with zipfile.ZipFile(xbmcvfs.translatePath(temp_file), 'r') as zipf:
                        result = '.optiklean_backup' in zipf.namelist()
                    xbmcvfs.delete(temp_file)
                    return result
                except (zipfile.BadZipFile, zipfile.LargeZipFile, OSError, IOError) as e:
                    xbmc.log(f"OptiKlean: Error reading temp backup file: {e}", xbmc.LOGWARNING)
                    xbmcvfs.delete(temp_file)
                    return False
            return False
        else:
            # Local path - use standard method
            with zipfile.ZipFile(xbmcvfs.translatePath(zip_path), 'r') as zipf:
                return '.optiklean_backup' in zipf.namelist()
    except (zipfile.BadZipFile, zipfile.LargeZipFile, OSError, IOError, Exception) as e:
        xbmc.log(f"OptiKlean: Error validating backup file {zip_path}: {e}", xbmc.LOGWARNING)
        return False

def write_log_local(log_key, content, append=False):
    """Write content to log file with timestamp and rotation for restore logs"""
    def get_localized_datetime():
        """Get current datetime formatted according to Kodi's regional settings"""
        try:
            # Get Kodi's time format (12h vs 24h)
            time_format = xbmc.getRegion('time').replace('%H', 'HH').replace('%I', 'hh').replace('%M', 'mm')
            
            # Get date format based on region
            date_format = xbmc.getRegion('dateshort')
            
            # Convert to Python datetime format
            format_map = {
                'DD': '%d', 'MM': '%m', 'YYYY': '%Y',
                'hh': '%I', 'mm': '%M', 'ss': '%S', 'HH': '%H',
                'AP': '%p' if '%p' in xbmc.getRegion('time') else ''
            }
            
            for k, v in format_map.items():
                date_format = date_format.replace(k, v)
                time_format = time_format.replace(k, v)
            
            full_format = f"{date_format} {time_format}"
            return time.strftime(full_format)
        except Exception as e:
            # Fallback to safe ISO format if regional formatting fails
            xbmc.log(f"OptiKlean: Error with localized datetime, using fallback: {e}", xbmc.LOGWARNING)
            return datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    def rotate_restore_log(log_path, new_content):
        """Mantiene solo le ultime 8 operazioni di restore"""
        entries = []
        
        # Leggi le entry esistenti se il file esiste
        if xbmcvfs.exists(log_path):
            try:
                with xbmcvfs.File(log_path, 'r') as f:
                    current_content = f.read()
                
                # Dividi il contenuto in base a "Date and time:" che marca la fine di ogni entry
                parts = current_content.split('\nDate and time:')
                
                # Ricostruisci le entry complete (tranne la prima che non ha il prefisso)
                for i, part in enumerate(parts):
                    if i == 0 and part.strip():
                        # Prima parte senza prefisso "Date and time:"
                        entries.append(part.strip())
                    elif part.strip():
                        # Parti successive, aggiungi il prefisso
                        entries.append(f"Date and time:{part.strip()}")
                        
            except Exception as e:
                xbmc.log(f"OptiKlean: Error reading existing log: {str(e)}", xbmc.LOGWARNING)
        
        # Aggiungi la nuova entry
        new_entry = new_content.strip()
        if not new_entry.endswith('\n'):
            new_entry += '\n'
        new_entry += f"\nDate and time: {get_localized_datetime()}\n"
        
        entries.append(new_entry)
        
        # Mantieni solo le ultime 8 entry
        if len(entries) > 8:
            entries = entries[-8:]
        
        # Scrivi il contenuto rotato
        try:
            with xbmcvfs.File(log_path, 'w') as f:
                for i, entry in enumerate(entries):
                    if i > 0:
                        f.write('\n' + '='*50 + '\n\n')
                    f.write(entry)
            xbmc.log(f"OptiKlean: Log rotated, kept {len(entries)} entries", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"OptiKlean: Error writing rotated log: {str(e)}", xbmc.LOGERROR)

    log_files = get_log_files()
    log_path = log_files.get(log_key)
    if not log_path:
        xbmc.log(f"OptiKlean: Log key '{log_key}' not found", xbmc.LOGERROR)
        return
    
    # Assicurati che la directory esista
    log_dir = '/'.join(log_path.split('/')[:-1])
    if log_dir and not xbmcvfs.exists(log_dir):
        try:
            xbmcvfs.mkdirs(log_dir)
            xbmc.log(f"OptiKlean: Created log directory {log_dir}", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"OptiKlean: Failed to create log directory {log_dir}: {str(e)}", xbmc.LOGERROR)
            return
    
    # Gestione speciale per il log di restore con rotazione
    if log_key == "restore_backup":
        rotate_restore_log(log_path, content)
        return
    
    # Gestione normale per altri log
    try:
        if append and xbmcvfs.exists(log_path):
            with xbmcvfs.File(log_path, 'r') as f:
                existing_content = f.read()
        else:
            existing_content = ""
        
        new_content = existing_content + content
        if not new_content.endswith('\n'):
            new_content += '\n'
        new_content += f"\nDate and time: {get_localized_datetime()}\n"
        
        with xbmcvfs.File(log_path, 'w') as f:
            f.write(new_content)
        xbmc.log(f"OptiKlean: Log written to {log_path}", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"OptiKlean: Error writing log file {log_path}: {e}", xbmc.LOGERROR)

def get_log_files():
    """Get log file paths"""
    addon_data_folder = xbmcvfs.translatePath(f"special://profile/addon_data/{addon_id}/")

    if not xbmcvfs.exists(addon_data_folder):
        xbmcvfs.mkdirs(addon_data_folder)

    return {
        "backup_addons": safe_path_join(addon_data_folder, "backup_addons.log"),
        "backup_addon_data": safe_path_join(addon_data_folder, "backup_addon_data.log"),
        "backup_addons_and_data": safe_path_join(addon_data_folder, "backup_addons_and_data.log"),
        "backup_databases": safe_path_join(addon_data_folder, "backup_databases.log"),
        "backup_sources": safe_path_join(addon_data_folder, "backup_sources.log"),
        "backup_gui_settings": safe_path_join(addon_data_folder, "backup_gui_settings.log"),
        "backup_profiles": safe_path_join(addon_data_folder, "backup_profiles.log"),
        "backup_advanced_settings": safe_path_join(addon_data_folder, "backup_advanced_settings.log"),
        "backup_skins": safe_path_join(addon_data_folder, "backup_skins.log"),
        "backup_keymaps": safe_path_join(addon_data_folder, "backup_keymaps.log"),
        "backup_playlists": safe_path_join(addon_data_folder, "backup_playlists.log"),
        "restore_backup": safe_path_join(addon_data_folder, "restore_backup.log")
    }

def get_size_mb(path):
    """Get directory size in MB using direct filesystem access for local Kodi paths"""
    try:
        # Convert Kodi special paths to local filesystem paths
        local_path = xbmcvfs.translatePath(path) if path.startswith("special://") else path
        
        if not os.path.exists(local_path):
            return 0.0
            
        if os.path.isfile(local_path):
            # Single file - get size directly
            return round(os.path.getsize(local_path) / (1024 * 1024), 2)
        elif os.path.isdir(local_path):
            # Directory - use os.walk for accurate recursive size
            total_size = 0
            for root, dirs, files in os.walk(local_path):
                for file in files:
                    try:
                        file_path = os.path.join(root, file)
                        total_size += os.path.getsize(file_path)
                    except (OSError, IOError):
                        continue
            return round(total_size / (1024 * 1024), 2)
        
        return 0.0
        
    except Exception as e:
        xbmc.log(f"OptiKlean: Error calculating size for {path}: {e}", xbmc.LOGWARNING)
        return 0.0

def get_free_space_mb(path):
    """Get available free space in MB (returns None for network paths)"""
    try:
        # Check if it's a network path
        if is_network_path(path):
            xbmc.log(f"OptiKlean: Cannot determine free space for network path: {path}", xbmc.LOGINFO)
            return None
        
        # Convert to local path
        local_path = xbmcvfs.translatePath(path)
        
        # Use platform-specific methods for better accuracy
        if xbmc.getCondVisibility("System.Platform.Windows"):
            # Windows method using ctypes - more reliable
            free_bytes = ctypes.c_ulonglong(0)
            ret = ctypes.windll.kernel32.GetDiskFreeSpaceExW(
                ctypes.c_wchar_p(local_path),
                None,
                None,
                ctypes.byref(free_bytes)
            )
            if ret == 0:
                raise ctypes.WinError()
            return round(free_bytes.value / (1024 * 1024), 2)
        else:
            # Unix/Linux method using os.statvfs
            stat = os.statvfs(local_path)
            free_bytes = stat.f_bavail * stat.f_frsize
            return round(free_bytes / (1024 * 1024), 2)
            
    except Exception as e:
        xbmc.log(f"OptiKlean: Failed to get free space for {path}: {e}", xbmc.LOGWARNING)
        return None

def calculate_backup_size_estimate(backup_items):
    total_bytes = 0
    
    # Compression ratios by file type
    COMPRESSION_RATIOS = {
        'text': 0.2,      # XML, JSON, etc.
        'binary': 0.65,   # Databases, binaries
        'image': 0.9,     # JPG/PNG (already compressed)
        'media': 0.95,    # Videos/music
        'other': 0.7      # Default
    }

    def get_file_type(filepath):
        ext = os.path.splitext(filepath)[1].lower()
        if ext in ('.xml', '.json', '.txt', '.log', '.ini', '.py'):
            return 'text'
        elif ext in ('.db', '.sqlite', '.dat', '.bin'):
            return 'binary'
        elif ext in ('.jpg', '.jpeg', '.png', '.gif', '.webp'):
            return 'image'
        elif ext in ('.mp3', '.mp4', '.mkv', '.avi'):
            return 'media'
        return 'other'

    for source_path, _ in backup_items:
        if not os.path.exists(source_path):
            continue
            
        if os.path.isfile(source_path):
            # Single file
            file_type = get_file_type(source_path)
            file_size = os.path.getsize(source_path)
            total_bytes += file_size * COMPRESSION_RATIOS[file_type]
            
        else:
            # Directory - recursive scan
            for root, dirs, files in os.walk(source_path):
                for file in files:
                    file_path = os.path.join(root, file)
                    try:
                        file_type = get_file_type(file_path)
                        file_size = os.path.getsize(file_path)
                        total_bytes += file_size * COMPRESSION_RATIOS[file_type]
                    except OSError:
                        continue
    
    # Add 10% buffer and convert to MB
    estimated_mb = (total_bytes * 1.1) / (1024 * 1024)
    return round(estimated_mb, 2)

def get_size_kb(path):
    """Get directory size in KB using direct filesystem access for local Kodi paths"""
    try:
        # Convert Kodi special paths to local filesystem paths
        local_path = xbmcvfs.translatePath(path) if path.startswith("special://") else path
        
        if not os.path.exists(local_path):
            return 0.0
            
        if os.path.isfile(local_path):
            # Single file - get size directly
            return round(os.path.getsize(local_path) / 1024, 2)
        elif os.path.isdir(local_path):
            # Directory - use os.walk for accurate recursive size
            total_size = 0
            for root, dirs, files in os.walk(local_path):
                for file in files:
                    try:
                        file_path = os.path.join(root, file)
                        total_size += os.path.getsize(file_path)
                    except (OSError, IOError):
                        continue
            return round(total_size / 1024, 2)
        
        return 0.0
        
    except Exception as e:
        xbmc.log(f"OptiKlean: Error calculating size for {path}: {e}", xbmc.LOGWARNING)
        return 0.0

def select_addons_for_backup(backup_mode="both"):
    """Select addons for backup based on specified type"""
    addons_path = xbmcvfs.translatePath("special://home/addons/")
    addon_data_path = xbmcvfs.translatePath("special://profile/addon_data/")

    excluded_prefixes = (
        "xbmc.", "script.module.", "script.common.", "inputstream.", "metadata.",
        "resource.language.", "service.xbmc.versioncheck", "service.subtitles.", "repository."
    )
    excluded_exact = ("script.image.resource.select",)

    addon_list = []
    display_list = []

    try:
        # First handle regular addons that exist in addons_path
        for folder in sorted(os.listdir(addons_path)):
            if folder.lower() in ("temp", "packages"):
                continue
            if folder in excluded_exact or any(folder.startswith(p) for p in excluded_prefixes):
                continue
            
            addon_dir = safe_path_join(addons_path, folder)
            data_dir = safe_path_join(addon_data_path, folder)
            
            has_addon = os.path.isdir(addon_dir)
            has_data = os.path.isdir(data_dir)
            
            if backup_mode == "addons" and not has_addon:
                continue
            elif backup_mode == "addon_data" and not has_data:
                continue
            elif backup_mode == "both" and not (has_addon or has_data):
                continue
                
            addon_size_kb = get_size_kb(addon_dir) if has_addon else 0.0
            data_size_kb = get_size_kb(data_dir) if has_data else None
            
            # Format size display - use KB if < 1000KB, otherwise MB
            def format_size(kb):
                if kb < 1000:
                    return f"{kb:.2f} KB"
                else:
                    return f"{kb/1024:.2f} MB"
            
            if backup_mode == "addons":
                label = f"{folder} ({format_size(addon_size_kb)})"
            elif backup_mode == "addon_data":
                if data_size_kb is not None:
                    label = f"{folder} ({format_size(data_size_kb)} data)"
                else:
                    label = f"{folder} (no data)"
            else:
                label = f"{folder} ({format_size(addon_size_kb)} addon"
                label += f", {format_size(data_size_kb)} data" if data_size_kb is not None else ", no data)"
            
            display_list.append(label)
            addon_list.append(folder)

        # Special case: Also include data folders that don't have corresponding addons in home/addons/
        if backup_mode in ("addon_data", "both"):
            for data_folder in sorted(os.listdir(addon_data_path)):
                if data_folder in addon_list:  # Already processed
                    continue
                if data_folder in excluded_exact or any(data_folder.startswith(p) for p in excluded_prefixes):
                    continue
                
                data_dir = safe_path_join(addon_data_path, data_folder)
                if os.path.isdir(data_dir):
                    data_size_kb = get_size_kb(data_dir)
                    label = f"{data_folder} ({format_size(data_size_kb)} data)" if data_size_kb is not None else f"{data_folder} (no data)"
                    display_list.append(label)
                    addon_list.append(data_folder)
            
    except Exception as e:
        xbmc.log(f"OptiKlean: Error listing addons: {e}", xbmc.LOGERROR)
        return None  # Return None to distinguish from empty selection

    # Show selection dialog
    selected_indices = xbmcgui.Dialog().multiselect("Select addons to back up", display_list)
    
    # Handle dialog return values properly
    if selected_indices is None:  # User pressed Cancel
        xbmc.log("OptiKlean: User cancelled addon selection", xbmc.LOGINFO)
        return None
    elif not selected_indices:  # User pressed OK with no selection
        xbmc.log("OptiKlean: User selected 0 addons", xbmc.LOGINFO)
        return []
    
    # Return the selected addon IDs
    selected_addons = []
    for index in selected_indices:
        if 0 <= index < len(addon_list):  # Safety check
            selected_addons.append(addon_list[index])
    
    xbmc.log(f"OptiKlean: User selected {len(selected_addons)} addons: {selected_addons}", xbmc.LOGINFO)
    return selected_addons

def create_temp_backup(backup_items, progress_callback=None):
    """Create temporary backup ZIP file locally"""
    temp_dir = xbmcvfs.translatePath("special://temp/optiklean/")
    if not xbmcvfs.exists(temp_dir):
        xbmcvfs.mkdirs(temp_dir)
    
    # 🎯 AGGIUNTO: Controlla spazio disponibile per il backup temporaneo
    estimated_size_mb = calculate_backup_size_estimate(backup_items)
    temp_free_space = get_free_space_mb(temp_dir)
    
    if temp_free_space is not None and estimated_size_mb * 1.5 > temp_free_space:
        # Margine di sicurezza 50% per il file temporaneo non compresso
        xbmc.log(f"OptiKlean: Insufficient temp space. Need ~{estimated_size_mb * 1.5:.1f}MB, available: {temp_free_space:.1f}MB", xbmc.LOGWARNING)
        
        # Mostra dialog di errore informativo
        xbmcgui.Dialog().ok(
            "Insufficient Space",
            f"Not enough space in temporary directory for backup creation.[CR]"
            f"Required: ~{estimated_size_mb * 1.5:.1f} MB[CR]"
            f"Available: {temp_free_space:.1f} MB[CR][CR]"
            f"Please free up space or choose a smaller backup."
        )
        return None
    
    temp_zip = safe_path_join(temp_dir, f"backup_temp_{int(time.time())}.zip")
    temp_zip_local = xbmcvfs.translatePath(temp_zip)
    
    try:
        with zipfile.ZipFile(temp_zip_local, 'w', zipfile.ZIP_DEFLATED) as backup_zip:
            total_items = len(backup_items)
            for i, (source_path, archive_path) in enumerate(backup_items):
                if progress_callback and progress_callback():  # Check for cancellation
                    return None
                
                if progress_callback:
                    progress_callback(int((i / total_items) * 100), f"Backing up: {source_path.split('/')[-1]}")
                
                # 🎯 AGGIUNTO: Controlla spazio durante la creazione
                if i % 10 == 0:  # Controlla ogni 10 file per performance
                    try:
                        temp_free_now = get_free_space_mb(temp_dir)
                        if temp_free_now is not None and temp_free_now < 100:  # Meno di 100MB liberi
                            xbmc.log(f"OptiKlean: Low temp space during backup: {temp_free_now:.1f}MB", xbmc.LOGWARNING)
                            
                            # Opzionale: interrompi il backup se lo spazio è troppo poco
                            if temp_free_now < 50:  # Meno di 50MB - situazione critica
                                xbmc.log(f"OptiKlean: Critical temp space shortage: {temp_free_now:.1f}MB", xbmc.LOGERROR)
                                raise Exception(f"Insufficient temporary space: {temp_free_now:.1f}MB remaining")
                    except Exception:
                        # Non interrompere il backup per errori di controllo spazio (eccetto spazio critico)
                        # Se l'eccezione contiene il messaggio di spazio critico, deve essere rilanciata
                        # ma per semplicità, ignoriamo tutti gli errori del controllo spazio
                        pass
                
                add_to_zip_recursive(backup_zip, source_path, archive_path)
        
            backup_zip.writestr('.optiklean_backup', 'OptiKlean backup file')
        
        return temp_zip
    except Exception as e:
        xbmc.log(f"OptiKlean: Error creating temp backup: {e}", xbmc.LOGERROR)
        # Clean up on error
        if xbmcvfs.exists(temp_zip):
            xbmcvfs.delete(temp_zip)
        return None

def add_to_zip_recursive(zip_file, source_path, archive_path):
    try:
        # Convert Kodi special paths to local filesystem paths
        local_path = xbmcvfs.translatePath(source_path) if source_path.startswith("special://") else source_path
        
        if not os.path.exists(local_path):
            xbmc.log(f"OptiKlean: Source not found: {local_path}", xbmc.LOGERROR)
            return False

        if os.path.isfile(local_path):
            # Single file - add directly
            zip_file.write(local_path, archive_path)
            return True
        else:
            # Directory - recursive add
            for root, dirs, files in os.walk(local_path):
                for file in files:
                    file_path = os.path.join(root, file)
                    rel_path = os.path.relpath(file_path, local_path)
                    zip_path = os.path.join(archive_path, rel_path).replace('\\', '/')
                    
                    try:
                        zip_file.write(file_path, zip_path)
                    except Exception as e:
                        xbmc.log(f"OptiKlean: Failed to add {file_path}: {str(e)}", xbmc.LOGWARNING)
            return True

    except Exception as e:
        xbmc.log(f"OptiKlean: ZIP creation error: {str(e)}", xbmc.LOGERROR)
        return False

def perform_backup(mode):
    addon_data_path = xbmcvfs.translatePath("special://profile/addon_data/plugin.program.optiklean/")
    prompt_status_path = safe_path_join(addon_data_path, "backup_path_prompt_status.json")

    # Define maps at the start for use in both notification and log
    log_key_map = {
        "addons": "backup_addons",
        "addon_data": "backup_addon_data", 
        "both": "backup_addons_and_data",
        "skins": "backup_skins",
        "databases": "backup_databases",
        "sources": "backup_sources",
        "gui_settings": "backup_gui_settings",
        "profiles": "backup_profiles",
        "advanced_settings": "backup_advanced_settings",
        "keymaps": "backup_keymaps",
        "playlists": "backup_playlists"
    }
    
    type_label_map = {
        "addons": "Addons only",
        "addon_data": "Addon data only",
        "both": "Addons + data",
        "skins": "Skins",
        "databases": "Kodi databases",
        "sources": "Sources (sources.xml)",
        "gui_settings": "GUI settings (guisettings.xml)",
        "profiles": "Profiles (profiles.xml)",
        "advanced_settings": "Advanced settings (advancedsettings.xml)",
        "keymaps": "Keymaps",
        "playlists": "Playlists"
    }

    # Initialize variables for log
    zip_name = "—"
    dest_zip = "—"  
    size_mb = 0
    result = "Error"
    backed_up_items = []

    backup_dest = addon.getSetting("backup_path")
    if not backup_dest.strip():
        # Check if we should ask for path or use default
        if xbmcvfs.exists(prompt_status_path):
            try:
                with xbmcvfs.File(prompt_status_path, 'r') as f:
                    data = json.loads(f.read())
                    if data.get("use_default", False):
                        backup_dest = xbmcvfs.translatePath("special://home/")
                    else:
                        backup_dest = xbmcgui.Dialog().browse(0, "Select backup destination", "files")
                        if not backup_dest:
                            xbmcgui.Dialog().notification("OptiKlean", "Backup cancelled", xbmcgui.NOTIFICATION_WARNING, 3000)
                            return
            except (IOError, OSError, json.JSONDecodeError, KeyError, Exception) as e:
                xbmc.log(f"OptiKlean: Error reading backup path prompt status: {e}", xbmc.LOGWARNING)
                backup_dest = xbmcvfs.translatePath("special://home/")
        else:
            # First time - ask user
            choice = xbmcgui.Dialog().yesno(
                "Backup Destination",
                "No backup path set. Would you like to:[CR]• YES: Choose a custom folder[CR]• NO: Use Kodi home folder as default"
            )
            
            if choice:  # User chose YES - custom folder
                backup_dest = xbmcgui.Dialog().browse(0, "Select backup destination", "files")
                if not backup_dest:
                    xbmcgui.Dialog().notification("OptiKlean", "Backup cancelled", xbmcgui.NOTIFICATION_WARNING, 3000)
                    return
                # Save the custom path
                addon.setSetting("backup_path", backup_dest)
            else:  # User chose NO - use default
                backup_dest = xbmcvfs.translatePath("special://home/")
                # Save preference to not ask again
                try:
                    with xbmcvfs.File(prompt_status_path, 'w') as f:
                        f.write(json.dumps({"use_default": True}))
                except (IOError, OSError, json.JSONDecodeError, Exception) as e:
                    xbmc.log(f"OptiKlean: Error writing backup path prompt status: {e}", xbmc.LOGWARNING)

    # Set variables during the process
    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M")
    zip_name = f"kodi_backup_{mode}_{timestamp}.zip"
    dest_zip = safe_path_join(backup_dest, zip_name)

    addons_path = xbmcvfs.translatePath("special://home/addons/")
    db_path = xbmcvfs.translatePath("special://profile/Database/")
    userdata_path = xbmcvfs.translatePath("special://profile/")

    backup_items = []
    result = "Success"

    try:
        if mode in ["addons", "addon_data", "both"]:
            selected_addons = select_addons_for_backup(mode)
            
            if selected_addons is None:  # User cancelled
                return
            if not selected_addons:  # Empty selection
                xbmcgui.Dialog().notification("OptiKlean", "No addons selected", xbmcgui.NOTIFICATION_WARNING, 3000)
                return
            
            # Get Kodi paths (use xbmcvfs for consistency)
            addons_path = xbmcvfs.translatePath("special://home/addons/")
            addon_data_root = xbmcvfs.translatePath("special://profile/addon_data/")
            
            xbmc.log(f"OptiKlean: Addons path: {addons_path}", xbmc.LOGDEBUG)
            xbmc.log(f"OptiKlean: Addon data path: {addon_data_root}", xbmc.LOGDEBUG)
            
            for addon_id in selected_addons:
                # Handle addon code backup
                if mode in ["addons", "both"]:
                    # Use the same reliable method as select_addons_for_backup()
                    addon_path = xbmcvfs.translatePath(f"special://home/addons/{addon_id}")
                    xbmc.log(f"OptiKlean: DEBUG - Checking addon path: '{addon_path}'", xbmc.LOGDEBUG)
                    
                    # Use os.path.isdir() like in select_addons_for_backup() for consistency
                    if os.path.isdir(addon_path):
                        # Use forward slashes for archive path (ZIP standard)
                        archive_path = f"addons/{addon_id}"
                        backup_items.append((addon_path, archive_path))
                        backed_up_items.append(f"Addon: {addon_id}")
                        xbmc.log(f"OptiKlean: Found addon: {addon_id}", xbmc.LOGINFO)
                    else:
                        xbmc.log(f"OptiKlean: Addon not found: {addon_path}", xbmc.LOGWARNING)
                
                # Handle addon data backup
                if mode in ["addon_data", "both"]:
                    # Use the same reliable method as select_addons_for_backup()
                    data_path = xbmcvfs.translatePath(f"special://profile/addon_data/{addon_id}")
                    xbmc.log(f"OptiKlean: DEBUG - Checking data path: '{data_path}'", xbmc.LOGDEBUG)
                    
                    # Use os.path.isdir() like in select_addons_for_backup() for consistency
                    if os.path.isdir(data_path):
                        archive_path = f"addon_data/{addon_id}"
                        backup_items.append((data_path, archive_path))
                        backed_up_items.append(f"Data: {addon_id}")
                        xbmc.log(f"OptiKlean: Found addon data: {addon_id}", xbmc.LOGINFO)
                    else:
                        xbmc.log(f"OptiKlean: Addon data not found: {data_path}", xbmc.LOGDEBUG)
            
            # Debug output
            xbmc.log(f"OptiKlean: Final backup items count: {len(backup_items)}", xbmc.LOGINFO)
            for item in backup_items:
                xbmc.log(f"OptiKlean: Backup item: {item[0]} -> {item[1]}", xbmc.LOGDEBUG)

        elif mode == "databases":
            if xbmcvfs.exists(db_path):
                try:
                    dirs, files = xbmcvfs.listdir(db_path)
                    for db_file in files:
                        if db_file.endswith('.db'):
                            backup_items.append((safe_path_join(db_path, db_file), f"Database/{db_file}"))
                            backed_up_items.append(f"Database: {db_file}")
                except Exception as e:
                    xbmc.log(f"OptiKlean: Error listing databases: {e}", xbmc.LOGWARNING)

        elif mode == "sources":
            sources_file = safe_path_join(userdata_path, "sources.xml")
            if xbmcvfs.exists(sources_file):
                backup_items.append((sources_file, "sources.xml"))

        elif mode == "gui_settings":
            gui_settings_file = safe_path_join(userdata_path, "guisettings.xml")
            if xbmcvfs.exists(gui_settings_file):
                backup_items.append((gui_settings_file, "guisettings.xml"))

        elif mode == "profiles":
            profiles_file = safe_path_join(userdata_path, "profiles.xml")
            if xbmcvfs.exists(profiles_file):
                backup_items.append((profiles_file, "profiles.xml"))

        elif mode == "advanced_settings":
            advanced_settings_file = safe_path_join(userdata_path, "advancedsettings.xml")
            if xbmcvfs.exists(advanced_settings_file):
                backup_items.append((advanced_settings_file, "advancedsettings.xml"))
            else:
                xbmcgui.Dialog().notification("OptiKlean", "No advancedsettings.xml found", logo_path, 3000)
                result = "No advancedsettings.xml found"
                return

        elif mode == "keymaps":
            keymaps_folder = xbmcvfs.translatePath("special://userdata/keymaps/")
            if xbmcvfs.exists(keymaps_folder):
                try:
                    dirs, files = xbmcvfs.listdir(keymaps_folder)
                    keymap_count = 0
                    
                    for file in files:
                        if file.endswith('.xml'):
                            keymap_count += 1
                            backed_up_items.append(f"Keymap: {file}")
                    
                    # Check subfolders
                    for dir_name in dirs:
                        subdir_path = safe_path_join(keymaps_folder, dir_name)
                        if xbmcvfs.exists(subdir_path):
                            try:
                                _, subfiles = xbmcvfs.listdir(subdir_path)
                                for subfile in subfiles:
                                    if subfile.endswith('.xml'):
                                        keymap_count += 1
                                        backed_up_items.append(f"Keymap: {dir_name}/{subfile}")
                            except Exception:
                                pass
                    
                    if keymap_count == 0:
                        xbmcgui.Dialog().notification("OptiKlean", "No custom keymaps found", logo_path, 3000)
                        result = "No custom keymaps found"
                        return
                    
                    backup_items.append((keymaps_folder, "keymaps"))
                except Exception:
                    xbmcgui.Dialog().notification("OptiKlean", "Unable to read keymaps folder", xbmcgui.NOTIFICATION_ERROR, 3000)
                    result = "Unable to read keymaps folder"
                    return
            else:
                xbmcgui.Dialog().notification("OptiKlean", "No custom keymaps found", logo_path, 3000)
                result = "No custom keymaps found"
                return

        elif mode == "skins":
            # Automatically collect all skin items
            backup_items, backed_up_items = collect_skin_items_for_backup()
            if not backup_items:
                xbmcgui.Dialog().notification("OptiKlean", "No skin items found", xbmcgui.NOTIFICATION_WARNING, 3000)
                result = "No skin items found to backup"
                return

        elif mode == "playlists":
            playlists_folder = xbmcvfs.translatePath("special://userdata/playlists/")
            if xbmcvfs.exists(playlists_folder):
                try:
                    dirs, files = xbmcvfs.listdir(playlists_folder)
                    playlist_count = len([f for f in files if f.endswith(('.m3u', '.pls', '.xsp'))])
                    
                    if playlist_count == 0:
                        xbmcgui.Dialog().notification("OptiKlean", "No custom playlists found", logo_path, 3000)
                        result = "No custom playlists found"
                        return
                    
                    backup_items.append((playlists_folder, "playlists"))
                    backed_up_items.append(f"Playlists ({playlist_count} files)")
                except Exception:
                    xbmcgui.Dialog().notification("OptiKlean", "Unable to read playlists folder", xbmcgui.NOTIFICATION_ERROR, 3000)
                    result = "Unable to read playlists folder"
                    return
            else:
                xbmcgui.Dialog().notification("OptiKlean", "No playlists folder found", logo_path, 3000)
                result = "No playlists folder found"
                return

        # Modified empty backup items check with more detailed logging
        if not backup_items:
            xbmc.log("OptiKlean: No valid items found to backup. Possible causes:", xbmc.LOGWARNING)
            xbmc.log(f"- Mode: {mode}", xbmc.LOGWARNING)
            if mode in ["addons", "addon_data", "both"]:
                xbmc.log(f"- Selected addons: {selected_addons if 'selected_addons' in locals() else 'N/A'}", xbmc.LOGWARNING)
                xbmc.log(f"- Addons path exists: {xbmcvfs.exists(addons_path)}", xbmc.LOGWARNING)
                xbmc.log(f"- Addon data path exists: {xbmcvfs.exists(xbmcvfs.translatePath('special://profile/addon_data/'))}", xbmc.LOGWARNING)
            
            xbmcgui.Dialog().notification(
                "OptiKlean", 
                "No valid items to backup", 
                xbmcgui.NOTIFICATION_WARNING, 
                4000
            )
            result = "No valid items found"
            return

        # Calculate estimated backup size
        estimated_size_mb = calculate_backup_size_estimate(backup_items)
        
        # Get available free space
        free_space = get_free_space_mb(backup_dest)
        
        if free_space is None:
            free_space_text = "Unknown"
            confirmation_message = (
                f"Backup type: {type_label_map.get(mode, mode.replace('_', ' ').title())}[CR]"
                f"Estimated size (compressed): ~{estimated_size_mb} MB[CR]"
                f"Free space available: {free_space_text}[CR][CR]"
                f"Unable to determine available space on the device.[CR]"
                f"Proceed with the backup anyway?"
            )
        else:
            if free_space >= 1024:
                free_space_text = f"{free_space / 1024:.1f} GB"
            else:
                free_space_text = f"{free_space:.1f} MB"
                
            # Check if there's enough space (with 20% safety margin)
            space_warning = ""
            if estimated_size_mb * 1.2 > free_space:
                space_warning = "[CR][COLOR red]Warning: Low disk space![/COLOR]"
                
            confirmation_message = (
                f"Backup type: {type_label_map.get(mode, mode.replace('_', ' ').title())}[CR]"
                f"Estimated size (compressed): ~{estimated_size_mb} MB[CR]"
                f"Free space available: {free_space_text}{space_warning}[CR][CR]"
                f"Do you want to proceed with the backup?"
            )
        
        # User confirmation
        if not xbmcgui.Dialog().yesno("Confirm Backup", confirmation_message):
            result = "Cancelled by user"
            return

        # Create backup
        progress = xbmcgui.DialogProgress()
        progress.create("OptiKlean", "Creating backup...")
        
        # Progress callback
        def progress_callback(percent=None, message=None):
            if progress.iscanceled():
                return True
            if percent is not None:
                progress.update(percent, message or "Creating backup...")
            return False
        
        # Create temporary backup locally
        temp_zip = create_temp_backup(backup_items, progress_callback)
        
        if temp_zip is None:
            result = "Cancelled by user" if progress.iscanceled() else "Error creating backup"
            progress.close()
            return

        # Get size from the temp zip immediately after creation
        try:
            temp_local_path = xbmcvfs.translatePath(temp_zip)
            size_bytes = os.path.getsize(temp_local_path)
            size_mb = max(0.01, round(size_bytes / (1024 * 1024), 2))  # Ensure min 0.01MB display
        except Exception as e:
            xbmc.log(f"OptiKlean: Could not get backup size: {str(e)}", xbmc.LOGWARNING)
            size_mb = 0.00

        progress.update(90, "Copying backup to destination...")
        transfer_success = False

        try:
            if is_network_path(dest_zip):
                # NETWORK TRANSFER (SMB/NFS)
                if safe_copy_file(temp_zip, dest_zip):
                    xbmc.log(f"OptiKlean: Backup copied to {dest_zip}", xbmc.LOGINFO)
                    transfer_success = True
                else:
                    raise Exception("Network copy failed")
            else:
                # LOCAL TRANSFER - try shutil first
                dest_local = xbmcvfs.translatePath(dest_zip)
                try:
                    shutil.move(temp_local_path, dest_local)
                    xbmc.log(f"OptiKlean: Backup moved to {dest_local}", xbmc.LOGINFO)
                    transfer_success = True
                except (shutil.Error, OSError) as e:
                    # Fallback to xbmcvfs if shutil fails
                    xbmc.log(f"OptiKlean: shutil.move failed, trying xbmcvfs: {str(e)}", xbmc.LOGWARNING)
                    if xbmcvfs.copy(temp_zip, dest_zip):
                        transfer_success = True
                    else:
                        raise Exception("Both shutil and xbmcvfs failed")

        except Exception as e:
            result = f"Transfer failed: {str(e)}"
            xbmc.log(f"OptiKlean: Backup transfer error: {str(e)}", xbmc.LOGERROR)
        finally:
            # Always cleanup temp file (except when using shutil.move which already moved it)
            try:
                if os.path.exists(temp_local_path):
                    # Only delete if file still exists (shutil.move removes it automatically)
                    if transfer_success and not is_network_path(dest_zip):
                        # For local transfers with shutil.move, file was already moved, no cleanup needed
                        xbmc.log("OptiKlean: Temp file moved successfully by shutil.move", xbmc.LOGDEBUG)
                    else:
                        # For network transfers or failed transfers, delete the temp file
                        os.remove(temp_local_path)
                        xbmc.log(f"OptiKlean: Temp backup file cleaned up: {temp_local_path}", xbmc.LOGDEBUG)
            except Exception as e:
                xbmc.log(f"OptiKlean: Temp cleanup failed: {str(e)}", xbmc.LOGWARNING)
            progress.close()

        if not transfer_success:
            return
        
        # Show notification with accurate size
        item_count = len(backup_items)
        item_text = "item" if item_count == 1 else "items"
        notification_type = type_label_map.get(mode, mode.replace('_', ' ').title())
        xbmcgui.Dialog().notification(
            "OptiKlean", 
            f"{notification_type}: {item_count} {item_text} ({size_mb} MB)", 
            logo_path, 
            5000
        )

    except Exception as e:
        result = f"Error: {str(e)}"
        xbmc.log(f"OptiKlean: Backup error: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("OptiKlean", f"Backup failed: {str(e)}", xbmcgui.NOTIFICATION_ERROR, 5000)
        
    finally:
        log_content = (
            f"Timestamp        : {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
            f"Backup type      : {type_label_map.get(mode, 'Unknown')}\n"
            f"Filename         : {zip_name}\n"
            f"Destination path : {dest_zip}\n"
            f"Size             : {size_mb} MB\n"
            f"Result           : {result}\n"
        )

        # Add backup contents summary for relevant types
        if mode in ["addons", "addon_data", "both", "databases", "skins", "keymaps"] and backed_up_items:
            log_content += "\nBackup contents:\n"
            for item in backed_up_items:
                log_content += f"• {item}\n"
        
        # Use valid log key as fallback
        log_key = log_key_map.get(mode, "backup_advanced_settings")
        write_log_local(log_key, log_content, append=False)

def perform_restore():
    addon_data_path = xbmcvfs.translatePath("special://profile/addon_data/plugin.program.optiklean/")
    
    # Inizializza le variabili per il log - Aggiungi inizializzazioni sicure
    backup_file = "—"
    restore_type = "Unknown"
    size_mb = 0
    result = "Error"
    items_restored = 0
    failed_files = []
    cleanup_temp_backup = False  # Inizializza sempre per evitare UnboundLocalError
    temp_backup_file = None  # Inizializza anche questa per sicurezza
    backup_file_original = "—"  # Mantieni il percorso originale per il log
    restarting_kodi = False  # Flag per evitare operazioni durante il riavvio
    backup_file_deleted = False  # Flag per tracciare se il file di backup è stato cancellato
    
    try:
        # Seleziona il file di backup
        backup_file = xbmcgui.Dialog().browse(1, "Select backup file to restore", "files", ".zip")
        if not backup_file:
            result = "Cancelled by user"
            xbmcgui.Dialog().notification("OptiKlean", "Restore cancelled", xbmcgui.NOTIFICATION_WARNING, 3000)
            return
        
        # Salva il percorso originale per il log prima di qualsiasi modifica
        backup_file_original = backup_file
        
        # Usa xbmcvfs per verificare l'esistenza del file (compatibile con percorsi di rete)
        if not xbmcvfs.exists(backup_file):
            result = "Backup file not found"
            xbmcgui.Dialog().notification("OptiKlean", "Backup file not found", xbmcgui.NOTIFICATION_ERROR, 3000)
            return
        
        if not is_valid_optiklean_backup(backup_file):
            result = "Invalid OptiKlean backup file"
            xbmcgui.Dialog().ok(
                "Invalid backup file",
                "The selected ZIP file is not a valid OptiKlean backup. Please select a backup created with the OptiKlean addon."
            )
            return

        # Calcola la dimensione del file di backup usando xbmcvfs
        size_mb = round(safe_file_size(backup_file) / (1024 * 1024), 2)
        
        # Per percorsi di rete, copia il backup localmente prima dell'estrazione
        temp_backup_file = backup_file
        
        if is_network_path(backup_file):
            temp_dir = xbmcvfs.translatePath("special://temp/optiklean/")
            if not xbmcvfs.exists(temp_dir):
                xbmcvfs.mkdirs(temp_dir)
            
            temp_backup_file = safe_path_join(temp_dir, f"temp_restore_backup_{int(time.time())}.zip")
            xbmc.log(f"OptiKlean: Copying network backup to local temp: {backup_file} -> {temp_backup_file}", xbmc.LOGINFO)
            
            if not xbmcvfs.copy(backup_file, temp_backup_file):
                result = "Error copying backup file from network location"
                xbmcgui.Dialog().notification("OptiKlean", "Failed to copy backup file", xbmcgui.NOTIFICATION_ERROR, 3000)
                return
            cleanup_temp_backup = True
        
        # Analizza il contenuto del backup per determinare il tipo
        temp_extract_path = safe_path_join(addon_data_path, "temp_restore")
        if not xbmcvfs.exists(temp_extract_path):
            xbmcvfs.mkdirs(temp_extract_path)
        
        with zipfile.ZipFile(xbmcvfs.translatePath(temp_backup_file), 'r') as backup_zip:
            file_list = backup_zip.namelist()
            
            # Determina il tipo di backup in base ai contenuti
            has_addons = any(f.startswith('addons/') for f in file_list)
            has_addon_data = any(f.startswith('addon_data/') for f in file_list)
            has_databases = any(f.startswith('Database/') for f in file_list)
            has_sources = 'sources.xml' in file_list
            has_gui_settings = 'guisettings.xml' in file_list
            has_profiles = 'profiles.xml' in file_list
            has_advanced_settings = 'advancedsettings.xml' in file_list
            has_keymaps = any(f.startswith('keymaps/') for f in file_list)
            
            # Verifica se è un backup di skin
            has_skin_addons = any(f.startswith('addons/skin.') for f in file_list)
            has_skin_helpers = any(f.startswith('addons/script.skin') for f in file_list)
            has_skin_backgrounds = any(f.startswith('addons/resource.images.skinbackgrounds.') for f in file_list)
            has_skin_resources = any(f.startswith('addons/resource.images.studios.') or 
                                   f.startswith('addons/resource.images.moviegenreicons.') or
                                   f.startswith('addons/resource.images.weathericons.') or
                                   f.startswith('addons/resource.images.recordlabels.') or
                                   f.startswith('addons/resource.images.musicgenreicons.') or
                                   f.startswith('addons/resource.images.countryflags.') or
                                   f.startswith('addons/resource.images.languageflags.') or
                                   f.startswith('addons/resource.images.moviecountryicons.') or
                                   f.startswith('addons/resource.images.tvshowgenreicons.') or
                                   f.startswith('addons/resource.images.studiopacks.') or
                                   f.startswith('addons/resource.images.skinicons.') or
                                   f.startswith('addons/resource.images.skinfanart.') or
                                   f.startswith('addons/resource.images.skinlogos.') or
                                   f.startswith('addons/resource.images.skinposters.') or
                                   f.startswith('addons/resource.images.skinwidgets.') or
                                   f.startswith('addons/resource.uisounds.') or
                                   f.startswith('addons/resource.font.') for f in file_list)
            has_advanced_skin_scripts = any(f.startswith('addons/script.skinhelper.') or
                                          f.startswith('addons/script.colorbox.') or
                                          f.startswith('addons/script.embuary.') or
                                          f.startswith('addons/script.arctic.') or
                                          f.startswith('addons/script.aura.') or
                                          f.startswith('addons/script.titan.') or
                                          f.startswith('addons/script.confluence.') or
                                          f.startswith('addons/script.estuary.') or
                                          f.startswith('addons/script.nexus.') or
                                          f.startswith('addons/script.amber.') for f in file_list)
            # Considera anche backup con solo guisettings.xml + skin addon come backup skin
            has_skin_settings_combo = ('guisettings.xml' in file_list and 
                                     (has_skin_addons or has_skin_helpers or has_skin_resources or has_advanced_skin_scripts))
            is_skin_backup = has_skin_addons or has_skin_helpers or has_skin_backgrounds or has_skin_resources or has_advanced_skin_scripts or has_skin_settings_combo
            
            if is_skin_backup:
                restore_type = "Skins"
            elif has_addons and has_addon_data:
                restore_type = "Addons + data"
            elif has_addons:
                restore_type = "Addons only"
            elif has_addon_data:
                restore_type = "Addon data only"
            elif has_databases:
                restore_type = "Kodi databases"
            elif has_sources:
                restore_type = "Sources (sources.xml)"
            elif has_gui_settings:
                restore_type = "GUI settings (guisettings.xml)"
            elif has_profiles:
                restore_type = "Profiles (profiles.xml)"
            elif has_advanced_settings:
                restore_type = "Advanced settings (advancedsettings.xml)"
            elif has_keymaps:
                restore_type = "Keymaps"
            
            # Determina il percorso di destinazione per il calcolo dello spazio libero
            destination_path = xbmcvfs.translatePath("special://home/")
            
            # Ottieni lo spazio libero disponibile
            free_space = get_free_space_mb(destination_path)
            
            if free_space is None:
                free_space_text = "Unknown"
                confirmation_message = (
                    f"Restore type: {restore_type}[CR]"
                    f"Size: {size_mb} MB[CR]"
                    f"Available free space: {free_space_text}[CR][CR]"
                    f"Unable to determine free space on this device.[CR]"
                    f"Do you want to proceed with the restore anyway?[CR][CR]"
                    f"This will overwrite existing files."
                )
            else:
                if free_space >= 1024:
                    free_space_text = f"{free_space / 1024:.1f} GB"
                else:
                    free_space_text = f"{free_space:.1f} MB"
                    
                confirmation_message = (
                    f"Restore type: {restore_type}[CR]"
                    f"Size: {size_mb} MB[CR]"
                    f"Available free space: {free_space_text}[CR][CR]"
                    f"This will overwrite existing files. Continue?"
                )
            
            # Conferma utente
            if not xbmcgui.Dialog().yesno("Confirm Restore", confirmation_message):
                result = "Cancelled by user"
                return
            
            # Avvia il processo di ripristino
            progress = xbmcgui.DialogProgress()
            progress.create("OptiKlean", "Restoring backup...")
            
            total_files = len(file_list)
            restored_count = 0
            
            # Invece di fermarsi al primo errore, raccogli tutti gli errori
            failed_files = []
            
            for i, file_path in enumerate(file_list):
                if progress.iscanceled():
                    result = "Cancelled by user"
                    break
                
                if file_path == '.optiklean_backup':
                    continue  # Salta il file marcatore
                    
                # Invece di solo il nome file, mostra anche progresso numerico
                progress.update(int((i / total_files) * 100), 
                    f"Restoring {i+1}/{total_files}: {file_path.split('/')[-1]}")
                
                try:
                    # Determina il percorso di destinazione in base al tipo di backup
                    dest_path = None
                    
                    if file_path.startswith('addons/'):
                        # Backup addons: ripristina in special://home/addons/
                        relative_path = file_path[7:]  # Rimuove 'addons/'
                        dest_path = safe_path_join(xbmcvfs.translatePath("special://home/addons/"), relative_path)
                        
                    elif file_path.startswith('addon_data/'):
                        # Backup addon_data: ripristina in special://profile/addon_data/
                        relative_path = file_path[11:]  # Rimuove 'addon_data/'
                        dest_path = safe_path_join(xbmcvfs.translatePath("special://profile/addon_data/"), relative_path)
                        
                    elif file_path.startswith('Database/'):
                        # Backup databases: ripristina in special://profile/Database/
                        relative_path = file_path[9:]  # Rimuove 'Database/'
                        dest_path = safe_path_join(xbmcvfs.translatePath("special://profile/Database/"), relative_path)
                        
                    elif file_path.startswith('keymaps/'):
                        # Backup keymaps: ripristina in special://userdata/keymaps/
                        relative_path = file_path[8:]  # Rimuove 'keymaps/'
                        dest_path = safe_path_join(xbmcvfs.translatePath("special://userdata/keymaps/"), relative_path)
                        
                    elif file_path in ['sources.xml', 'guisettings.xml', 'profiles.xml', 'advancedsettings.xml']:
                        # File di configurazione: ripristina in special://profile/
                        dest_path = safe_path_join(xbmcvfs.translatePath("special://profile/"), file_path)
                        
                    else:
                        xbmc.log(f"OptiKlean: Skipping unknown file: {file_path}", xbmc.LOGWARNING)
                        continue  # Salta file non riconosciuti
                    
                    if dest_path is None:
                        continue
                    
                    # Crea le directory se necessarie usando metodo robusto
                    dest_dir = '/'.join(dest_path.split('/')[:-1])
                    if dest_dir and not xbmcvfs.exists(dest_dir):
                        xbmcvfs.mkdirs(dest_dir)
                    
                    # Estrai il file in una directory temporanea locale
                    temp_extract_local = xbmcvfs.translatePath(temp_extract_path)
                    try:
                        backup_zip.extract(file_path, temp_extract_local)
                        
                        # Costruisci il percorso del file temporaneo estratto
                        temp_file_local = os.path.join(temp_extract_local, file_path)
                        
                        # Verifica che il file sia stato estratto correttamente usando percorso locale
                        if os.path.exists(temp_file_local):
                            # Converti il percorso locale in formato xbmcvfs per la copia
                            temp_file_xbmc = temp_file_local.replace("\\", "/")
                            if not temp_file_xbmc.startswith("special://"):
                                # Se è un percorso assoluto locale, mantienilo così
                                pass
                            
                            # Usa safe_copy_file con percorsi corretti
                            if safe_copy_file(temp_file_xbmc, dest_path):
                                restored_count += 1
                                xbmc.log(f"OptiKlean: Restored {file_path} to {dest_path}", xbmc.LOGINFO)
                            else:
                                failed_files.append((file_path, "Failed to copy to destination"))
                                xbmc.log(f"OptiKlean: Failed to copy {temp_file_xbmc} to {dest_path}", xbmc.LOGWARNING)
                        else:
                            failed_files.append((file_path, "File not found after extraction"))
                            xbmc.log(f"OptiKlean: File not found after extraction: {temp_file_local}", xbmc.LOGWARNING)
                            
                    except Exception as extract_error:
                        failed_files.append((file_path, f"Extraction failed: {str(extract_error)}"))
                        xbmc.log(f"OptiKlean: Failed to extract {file_path}: {str(extract_error)}", xbmc.LOGWARNING)
                        
                except Exception as e:
                    failed_files.append((file_path, str(e)))
                    xbmc.log(f"OptiKlean: Error restoring file {file_path}: {str(e)}", xbmc.LOGWARNING)
                    continue  # Continua con i file successivi
            
            progress.close()
            items_restored = restored_count
            
            if result != "Cancelled by user":
                result = "Success"

                if failed_files:
                    # Aggiorna il risultato per indicare errori parziali
                    result = f"Partial success: {items_restored} restored, {len(failed_files)} failed"
                    
                    notification_msg = f"Restore completed: {items_restored} items ({len(failed_files)} errors) ({size_mb} MB)"
                    xbmcgui.Dialog().notification("OptiKlean", notification_msg, logo_path, 5000)
                else:
                    # Notifica di successo completo
                    notification_msg = f"Restore completed: {items_restored} items ({size_mb} MB)"
                    xbmcgui.Dialog().notification("OptiKlean", notification_msg, logo_path, 5000)

                backup_filename = backup_file_original.split('/')[-1] if backup_file_original != "—" else "—"
                safe_backup_display_name = str(backup_filename).replace('\x00', '').strip()[:255]

                # Chiedi se cancellare il file di backup dopo il ripristino (per tutti i tipi di file)
                if items_restored > 0 and xbmcgui.Dialog().yesno(
                    "Delete Backup File?",
                    f"The backup has been successfully restored.[CR]Would you like to delete the backup file?[CR][CR]{safe_backup_display_name}"
                ):
                    try:
                        # Salva il nome del file prima di cancellarlo per il log
                        backup_filename = backup_file_original.split('/')[-1]
                        
                        # Debug logging per la cancellazione
                        xbmc.log(f"OptiKlean: DEBUG - Attempting to delete backup file: {backup_file_original}", xbmc.LOGDEBUG)
                        xbmc.log(f"OptiKlean: DEBUG - File exists before deletion: {xbmcvfs.exists(backup_file_original)}", xbmc.LOGDEBUG)
                        
                        if xbmcvfs.delete(backup_file_original):
                            xbmc.log("OptiKlean: DEBUG - xbmcvfs.delete returned True", xbmc.LOGDEBUG)
                        else:
                            xbmc.log("OptiKlean: DEBUG - xbmcvfs.delete returned False", xbmc.LOGDEBUG)
                        
                        # Verifica che il file sia stato effettivamente cancellato
                        if not xbmcvfs.exists(backup_file_original):
                            xbmc.log("OptiKlean: DEBUG - File successfully deleted (no longer exists)", xbmc.LOGDEBUG)
                            backup_file_deleted = True  # Imposta il flag per indicare che il file è stato cancellato
                        else:
                            xbmc.log("OptiKlean: DEBUG - WARNING - File still exists after deletion attempt", xbmc.LOGWARNING)
                        
                        # NON modificare backup_file_original - mantieni il percorso per il log
                        
                        xbmcgui.Dialog().notification(
                            "OptiKlean", 
                            f"Backup file {safe_backup_display_name} deleted successfully", 
                            logo_path, 
                            4000
                        )
                        xbmc.log(f"OptiKlean: Backup file deleted: {safe_backup_display_name}", xbmc.LOGINFO)
                    except Exception as e:
                        xbmc.log(f"OptiKlean: DEBUG - Exception during file deletion: {str(e)}", xbmc.LOGDEBUG)
                        
                        # Aggiorna il risultato per includere l'errore di cancellazione
                        if result == "Success":
                            result = f"Success (backup file deletion failed: {str(e)})"
                        elif result.startswith("Partial success"):
                            result += f" (backup file deletion failed: {str(e)})"
                        
                        xbmcgui.Dialog().notification(
                            "OptiKlean", 
                            f"Failed to delete backup file: {str(e)}", 
                            xbmcgui.NOTIFICATION_ERROR, 
                            4000
                        )
                        xbmc.log(f"OptiKlean: Error deleting backup file {safe_backup_display_name}: {str(e)}", xbmc.LOGERROR)

                # Chiedi se riavviare Kodi dopo aver gestito la cancellazione del backup
                if items_restored > 0:
                    # Use pre-sanitized filename from before deletion dialog (critical fix)
                    restart_msg = "Some changes may require a Kodi restart to take effect.[CR]Would you like to restart Kodi now?"
                    
                    if xbmcgui.Dialog().yesno("Restart Kodi?", restart_msg):
                        try:
                            # Definisci e sanifica le variabili necessarie per il log prima del riavvio
                            if 'safe_backup_display_name' not in locals():
                                backup_display_name = backup_file_original.split('/')[-1] if backup_file_original != "—" else "—"
                                safe_backup_display_name = str(backup_display_name).replace('\x00', '').strip()[:255]
                            
                            # Sanifica il percorso originale per il log
                            safe_backup_original = str(backup_file_original).replace('\x00', '').strip()[:500] if backup_file_original else "—"
                            safe_restore_type = str(restore_type).replace('\x00', '').strip()[:100]
                            safe_result = str(result).replace('\x00', '').strip()[:200]
                            
                            log_content = (
                                f"Restore type     : {safe_restore_type}\n"
                                f"Backup file      : {safe_backup_display_name}\n"
                                f"Source path      : {safe_backup_original}\n"
                                f"Size             : {size_mb} MB\n"
                                f"Items restored   : {items_restored}\n"
                                f"Result           : {safe_result}\n"
                            )
                            
                            if failed_files:
                                log_content += f"\nErrors encountered ({len(failed_files)} files):\n"
                                for file_path, error in failed_files:
                                    safe_file_path = str(file_path).replace('\x00', '').strip()[:200]
                                    safe_error = str(error).replace('\x00', '').strip()[:300]
                                    log_content += f"• {safe_file_path}: {safe_error}\n"
                            
                            write_log_local("restore_backup", log_content)
                            xbmc.log("OptiKlean: Log written before Kodi restart", xbmc.LOGINFO)
                            
                        except Exception as e:
                            xbmc.log(f"OptiKlean: Error writing log before restart: {str(e)}", xbmc.LOGWARNING)
                            try:
                                fallback_content = f"Restore completed before restart\nTimestamp: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\nItems restored: {items_restored}\nLogging error: {str(e)}\n"
                                write_log_local("restore_backup", fallback_content)
                            except Exception:
                                pass
                        
                        # Imposta il flag prima del riavvio per evitare operazioni nel finally
                        restarting_kodi = True
                        xbmc.executebuiltin("RestartApp")
                        return
    
    except zipfile.BadZipFile:
        result = "Error: Invalid or corrupted backup file"
        xbmcgui.Dialog().notification("OptiKlean", "Invalid backup file", xbmcgui.NOTIFICATION_ERROR, 3000)
        
    except Exception as e:
        error_msg = str(e)
        result = f"Error: {error_msg}"
        
        # Log dettagliato per il debug
        xbmc.log(f"OptiKlean: Restore error: {error_msg}", xbmc.LOGERROR)
        xbmc.log(f"OptiKlean: Backup file deleted: {backup_file_deleted}", xbmc.LOGDEBUG)
        xbmc.log(f"OptiKlean: Cleanup temp backup: {cleanup_temp_backup}", xbmc.LOGDEBUG)
        xbmc.log(f"OptiKlean: Restarting Kodi: {restarting_kodi}", xbmc.LOGDEBUG)
        
        # Se l'errore è "No such file or directory" e il file è stato cancellato, non è un vero errore
        if backup_file_deleted and ("No such file or directory" in error_msg or "Errno 2" in error_msg):
            result = "Success"
            xbmc.log("OptiKlean: Ignoring 'No such file or directory' error as backup file was deleted by user", xbmc.LOGINFO)
            # Non mostrare notifica di errore
        else:
            # Errore legittimo
            if not backup_file_deleted:
                xbmcgui.Dialog().notification("OptiKlean", f"Restore failed: {error_msg}", xbmcgui.NOTIFICATION_ERROR, 5000)
            else:
                xbmcgui.Dialog().notification("OptiKlean", "Restore completed but encountered logging error", xbmcgui.NOTIFICATION_WARNING, 5000)
        
    finally:
        # Se Kodi si sta riavviando, evita operazioni che potrebbero fallire
        if restarting_kodi:
            xbmc.log("OptiKlean: Skipping cleanup operations due to Kodi restart", xbmc.LOGINFO)
            return
            
        # Cleanup temp directory - use robust local path method
        temp_extract_path = safe_path_join(addon_data_path, "temp_restore")
        if xbmcvfs.exists(temp_extract_path):
            try:
                # Convert to local path and use shutil.rmtree for reliability
                local_temp_path = xbmcvfs.translatePath(temp_extract_path)
                if os.path.exists(local_temp_path):
                    shutil.rmtree(local_temp_path)
                    xbmc.log(f"OptiKlean: Cleaned up temp directory: {temp_extract_path}", xbmc.LOGINFO)
                else:
                    # Fallback: try with xbmcvfs if local path doesn't exist
                    try:
                        dirs, files = xbmcvfs.listdir(temp_extract_path)
                        # Simple non-recursive cleanup - remove files only
                        for f in files:
                            try:
                                file_path = safe_path_join(temp_extract_path, f)
                                xbmcvfs.delete(file_path)
                            except Exception:
                                pass  # Ignore individual file errors
                        # Try to remove the directory
                        xbmcvfs.rmdir(temp_extract_path)
                    except Exception:
                        pass  # Ignore xbmcvfs cleanup errors
            except Exception as e:
                xbmc.log(f"OptiKlean: Error cleaning temp directory: {str(e)}", xbmc.LOGWARNING)
        
        # Cleanup temporary backup file if it was copied from network
        if cleanup_temp_backup and temp_backup_file:
            try:
                # Controlla se il file temporaneo è lo stesso del file di backup originale
                is_same_file = (temp_backup_file == backup_file_original)
                
                # Se il file di backup è stato cancellato e è lo stesso file temporaneo, salta la pulizia
                if backup_file_deleted and is_same_file:
                    xbmc.log(f"OptiKlean: Skipping temp file cleanup - same as deleted backup file: {temp_backup_file}", xbmc.LOGDEBUG)
                else:
                    # Controlla se il file esiste prima di tentare la cancellazione
                    file_exists = False
                    try:
                        file_exists = xbmcvfs.exists(temp_backup_file)
                    except Exception as check_e:
                        xbmc.log(f"OptiKlean: Error checking temp file existence: {str(check_e)}", xbmc.LOGDEBUG)
                        file_exists = False
                    
                    if file_exists:
                        # Aggiungi debug logging per la pulizia del file temporaneo
                        xbmc.log(f"OptiKlean: DEBUG - Cleaning up temp backup file: {temp_backup_file}", xbmc.LOGDEBUG)
                        xbmc.log(f"OptiKlean: DEBUG - Backup file deleted flag: {backup_file_deleted}", xbmc.LOGDEBUG)
                        
                        xbmcvfs.delete(temp_backup_file)
                        xbmc.log(f"OptiKlean: Cleaned up temporary backup file: {temp_backup_file}", xbmc.LOGINFO)
                    else:
                        xbmc.log(f"OptiKlean: Temp backup file already deleted or doesn't exist: {temp_backup_file}", xbmc.LOGDEBUG)
            except Exception as e:
                # Se il file di backup è stato cancellato, questo potrebbe causare errori, ignora
                if backup_file_deleted and ("No such file or directory" in str(e) or "Errno 2" in str(e)):
                    xbmc.log(f"OptiKlean: Ignoring temp file cleanup error (backup was deleted): {str(e)}", xbmc.LOGDEBUG)
                else:
                    xbmc.log(f"OptiKlean: Error cleaning temporary backup file: {str(e)}", xbmc.LOGWARNING)
        
        # Write log con riepilogo errori incluso - solo se non è già stato scritto prima del riavvio
        try:
            # Protezione robusta per il nome del file di backup
            if backup_file_original and backup_file_original != "—":
                try:
                    backup_display_name = backup_file_original.split('/')[-1]
                except (AttributeError, IndexError):
                    backup_display_name = str(backup_file_original)
            else:
                backup_display_name = "—"
            
            # Sanifica il contenuto per evitare caratteri problematici
            safe_backup_display_name = backup_display_name.replace('\x00', '').strip()[:255]
            safe_backup_original = str(backup_file_original).replace('\x00', '').strip()[:500] if backup_file_original else "—"
            safe_restore_type = str(restore_type).replace('\x00', '').strip()[:100]
            safe_result = str(result).replace('\x00', '').strip()[:200]
            
            # Se il file di backup è stato cancellato, indica questo nel log
            if backup_file_deleted:
                safe_result += " (backup file deleted after restore)"
            
            log_content = (
                f"Restore type     : {safe_restore_type}\n"
                f"Backup file      : {safe_backup_display_name}\n"
                f"Source path      : {safe_backup_original}\n"
                f"Size             : {size_mb} MB\n"
                f"Items restored   : {items_restored}\n"
                f"Result           : {safe_result}\n"
            )
        except Exception as e:
            # Fallback sicuro se c'è qualsiasi problema con le variabili
            xbmc.log(f"OptiKlean: Error preparing log content, using fallback: {str(e)}", xbmc.LOGWARNING)
            log_content = (
                f"Restore type     : {restore_type if 'restore_type' in locals() else 'Unknown'}\n"
                f"Backup file      : Error processing filename\n"
                f"Source path      : Error processing path\n"
                f"Size             : {size_mb if 'size_mb' in locals() else 0} MB\n"
                f"Items restored   : {items_restored if 'items_restored' in locals() else 0}\n"
                f"Result           : {result if 'result' in locals() else 'Error'}\n"
            )
        
        # Aggiungi riepilogo errori al log solo se failed_files è definita
        try:
            if 'failed_files' in locals() and failed_files:
                log_content += f"\nErrors encountered ({len(failed_files)} files):\n"
                for file_path, error in failed_files:
                    log_content += f"• {file_path}: {error}\n"
        except Exception as e:
            xbmc.log(f"OptiKlean: Error processing failed files list: {str(e)}", xbmc.LOGWARNING)
        
        # Scrivi il log con gestione degli errori migliorata
        try:
            # Se il file di backup è stato cancellato, aggiungi un delay per evitare problemi di timing
            if backup_file_deleted:
                xbmc.log("OptiKlean: Backup file was deleted, adding delay before logging", xbmc.LOGDEBUG)
                import time as time_module
                time_module.sleep(0.5)  # Breve pausa per evitare problemi di sincronizzazione
            
            write_log_local("restore_backup", log_content)
            xbmc.log("OptiKlean: Restore log written successfully", xbmc.LOGINFO)
        except Exception as e:
            # Log dettagliato dell'errore per debug
            xbmc.log(f"OptiKlean: Error writing restore log - Error: {str(e)}", xbmc.LOGERROR)
            xbmc.log(f"OptiKlean: Log content length: {len(log_content) if 'log_content' in locals() else 'N/A'}", xbmc.LOGERROR)
            xbmc.log(f"OptiKlean: Backup file deleted flag: {backup_file_deleted}", xbmc.LOGERROR)
            
            # Tentativo di scrittura fallback con contenuto minimo
            try:
                fallback_content = f"Restore completed with error in logging\nTimestamp: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\nError: {str(e)}\nBackup deleted: {backup_file_deleted}\n"
                write_log_local("restore_backup", fallback_content)
                xbmc.log("OptiKlean: Fallback log written successfully", xbmc.LOGINFO)
            except Exception as e2:
                xbmc.log(f"OptiKlean: Even fallback log failed: {str(e2)}", xbmc.LOGERROR)

def collect_skin_items_for_backup():
    """Comprehensive skin backup with all component prefixes """
    # Get translated paths
    addons_path = xbmcvfs.translatePath("special://home/addons/")
    addon_data_path = xbmcvfs.translatePath("special://profile/addon_data/")
    userdata_path = xbmcvfs.translatePath("special://profile/")
    
    backup_items = []
    backed_up_items = []

    # Debug: Verify base paths
    xbmc.log(f"OptiKlean: Addons path: {addons_path} (exists: {os.path.exists(addons_path)})", xbmc.LOGINFO)
    xbmc.log(f"OptiKlean: Addon data path: {addon_data_path} (exists: {os.path.exists(addon_data_path)})", xbmc.LOGINFO)

    # 1. Include guisettings.xml with verification
    gui_settings_file = os.path.join(userdata_path, "guisettings.xml")
    if os.path.exists(gui_settings_file):
        try:
            with open(gui_settings_file, 'rb') as f:
                f.read(1)  # Test file access
            backup_items.append((gui_settings_file, "guisettings.xml"))
            backed_up_items.append("GUI settings")
            xbmc.log("OptiKlean: Verified guisettings.xml for backup", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"OptiKlean: Failed to access guisettings.xml: {str(e)}", xbmc.LOGERROR)

    # 2. Complete list of all skin-related prefixes
    skin_prefixes = (
        # Core skin components
        "skin.",
        "script.skin.",
        "script.skinhelper.",
        "script.skinshortcuts",
        "script.skinvariables",
        
        # Visual elements
        "resource.images.skinbackgrounds.",
        "resource.images.skinicons.",
        "resource.images.skinfanart.",
        "resource.images.skinlogos.",
        "resource.images.skinposters.",
        "resource.images.skinwidgets.",
        
        # Media resources
        "resource.images.studios.",
        "resource.images.moviegenreicons.",
        "resource.images.weathericons.",
        "resource.images.recordlabels.",
        "resource.images.musicgenreicons.",
        "resource.images.countryflags.",
        "resource.images.languageflags.",
        "resource.images.moviecountryicons.",
        "resource.images.tvshowgenreicons.",
        "resource.images.studiopacks.",
        
        # UI elements
        "resource.uisounds.",
        "resource.font.",
        
        # Popular skin frameworks
        "script.embuary.",
        "script.arctic.",
        "script.aura.",
        "script.titan.",
        "script.confluence.",
        "script.estuary.",
        "script.nexus.",
        "script.amber.",
        "script.colorbox.",
        
        # Helper scripts
        "script.skin.helper.",
        "script.skin.widgets.",
        "script.skin.shortcuts.",
        "script.extendedinfo",
        "script.artwork.helper"
    )

    # 3. First scan addons directory and collect skin addons
    skin_addons = set()
    try:
        if os.path.exists(addons_path):
            folders = [f for f in os.listdir(addons_path) 
                      if os.path.isdir(os.path.join(addons_path, f))]
            xbmc.log(f"OptiKlean: Found {len(folders)} folders in addons directory", xbmc.LOGINFO)

            for folder in folders:
                if any(folder.startswith(p) for p in skin_prefixes):
                    skin_addons.add(folder)
                    addon_dir = os.path.join(addons_path, folder)
                    
                    # Verify the addon contains valid files
                    try:
                        test_files = [
                            f for f in os.listdir(addon_dir)
                            if f.endswith(('.xml', '.py', '.json')) or f == 'addon.xml'
                        ]
                        if not test_files:
                            xbmc.log(f"OptiKlean: Skipping {folder} - no valid files found", xbmc.LOGWARNING)
                            continue
                    except Exception as e:
                        xbmc.log(f"OptiKlean: Cannot scan {folder}: {str(e)}", xbmc.LOGWARNING)
                        continue

                    # Add to backup
                    backup_items.append((addon_dir, f"addons/{folder}"))
                    
                    # Classify for logging
                    if folder.startswith("skin."):
                        item_type = "Skin"
                    elif folder.startswith("script.skinhelper"):
                        item_type = "Skin Helper"
                    elif folder.startswith("resource.images"):
                        item_type = "Skin Resource"
                    elif folder in ("script.skinshortcuts", "script.skinvariables"):
                        item_type = "Skin Utility"
                    else:
                        item_type = "Skin Component"
                    
                    backed_up_items.append(f"{item_type}: {folder}")
                    xbmc.log(f"OptiKlean: Verified {item_type}: {folder}", xbmc.LOGINFO)

    except Exception as e:
        xbmc.log(f"OptiKlean: Error scanning addons directory: {str(e)}", xbmc.LOGERROR)

    # 4. Now scan addon_data directory for standalone skin data folders
    try:
        if os.path.exists(addon_data_path):
            data_folders = [f for f in os.listdir(addon_data_path) 
                           if os.path.isdir(os.path.join(addon_data_path, f))]
            
            for folder in data_folders:
                # Include if:
                # 1. Matches skin pattern AND
                # 2. Either has corresponding addon OR is a skin data folder
                if any(folder.startswith(p) for p in skin_prefixes) and \
                   (folder in skin_addons or folder.startswith("skin.")):
                    
                    data_dir = os.path.join(addon_data_path, folder)
                    if os.path.exists(data_dir):
                        # Add data folder to backup (don't check if empty)
                        backup_items.append((data_dir, f"addon_data/{folder}"))
                        
                        # Determine if this is standalone data (no corresponding addon)
                        if folder not in skin_addons:
                            backed_up_items.append(f"Standalone Skin Data: {folder}")
                            xbmc.log(f"OptiKlean: Found standalone skin data: {folder}", xbmc.LOGINFO)
                        else:
                            backed_up_items.append(f"Skin Data: {folder}")
                            xbmc.log(f"OptiKlean: Found skin data: {folder}", xbmc.LOGINFO)

    except Exception as e:
        xbmc.log(f"OptiKlean: Error scanning addon_data directory: {str(e)}", xbmc.LOGERROR)

    # Final verification
    xbmc.log(f"OptiKlean: Final backup items count: {len(backup_items)}", xbmc.LOGINFO)
    for src, dest in backup_items:
        if not os.path.exists(src):
            xbmc.log(f"  WARNING: Backup source missing: {src} -> {dest}", xbmc.LOGWARNING)
        else:
            xbmc.log(f"  Verified: {src} -> {dest}", xbmc.LOGDEBUG)

    return backup_items, backed_up_items
