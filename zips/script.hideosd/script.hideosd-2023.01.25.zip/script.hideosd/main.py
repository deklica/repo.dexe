# -*- coding: utf-8 -*-
import sys
import xbmcaddon

if __name__ == '__main__':
    if len(sys.argv) <= 1:
        ADDON = xbmcaddon.Addon()
        ADDON.openSettings()