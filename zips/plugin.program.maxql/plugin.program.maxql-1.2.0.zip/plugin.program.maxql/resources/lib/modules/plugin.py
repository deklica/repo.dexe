import xbmc
import xbmcplugin
import xbmcaddon
import xbmcgui
import sys
import os
from .params import Params
from .menu import main_menu
from resources.lib.modules import maxql
from .maxql import fen_forks, venom_forks, shadow_forks, oath_forks, other, addon_list

addon_icon = 'special://home/addons/plugin.program.maxql/icon.png'

handle = int(sys.argv[1])

def router(paramstring):

    p = Params(paramstring)
    xbmc.log(str(p.get_params()),xbmc.LOGDEBUG)

    mode = p.get_mode()
    
    xbmcplugin.setContent(handle, 'files')

    if mode is None:
        main_menu()
        
    elif mode == 1:           
        for item in addon_list:
        #FEN & FORKS
            if item in fen_forks:
                addon = xbmcaddon.Addon(item)
                addon.setSetting("results_quality_movie", 'SD, 720p, 1080p')
                addon.setSetting("results_quality_episode", 'SD, 720p, 1080p')
                addon.setSetting("autoplay_quality_movie", 'SD, 720p, 1080p')
                addon.setSetting("autoplay_quality_episode", 'SD, 720p, 1080p')
        #VENOM & FORKS
            if item in venom_forks:
                addon = xbmcaddon.Addon(item)
                addon.setSetting("hosts.quality", 'SD, 720p, 1080p')
        #SHADOW & FORKS
            if item in shadow_forks:
                addon = xbmcaddon.Addon(item)
                addon.setSetting("max_q", '1')
                addon.setSetting("max_q_tv", '1')
        #OATH & FORKS
            if item in oath_forks:
                addon = xbmcaddon.Addon(item)
                addon.setSetting("hosts.quality", '1')
        #OTHER
            if item in other:
                if 'seren' in item:
                    addon = xbmcaddon.Addon(item)
                    addon.setSetting("general.maxResolution", '1')
                if 'otaku' in item:
                    addon = xbmcaddon.Addon(item)
                    addon.setSetting("general.maxResolution", '1')
                if 'testing' in item:
                    addon = xbmcaddon.Addon(item)
                    addon.setSetting("general.maxResolution", '3')
                if 'fenlight' in item:
                    from resources.lib.modules import maxql_db
                    maxql_db.enable_fenlt_1080p()
                    xbmc.executebuiltin('PlayMedia(plugin://plugin.video.fenlight/?mode=sync_settings&amp;silent=true)')
                    xbmc.sleep(2000)
                if 'gears' in item:
                    addon = xbmcaddon.Addon(item)
                    addon.setSetting("hosts.quality", '1')
                if 'scrubs' in item:
                    addon = xbmcaddon.Addon(item)
                    addon.setSetting("quality.max", '1')
            
        xbmcgui.Dialog().notification('MaxQL', '1080P Max Enabled!', addon_icon, 3000)

    elif mode == 2:
        for item in addon_list:
            if item in fen_forks:
                addon = xbmcaddon.Addon(item)
                addon.setSetting("results_quality_movie", 'SD, 720p, 1080p, 4K')
                addon.setSetting("results_quality_episode", 'SD, 720p, 1080p, 4K')
                addon.setSetting("autoplay_quality_movie", 'SD, 720p, 1080p, 4K')
                addon.setSetting("autoplay_quality_episode", 'SD, 720p, 1080p, 4K')
            if item in venom_forks:
                addon = xbmcaddon.Addon(item)
                addon.setSetting("hosts.quality", 'SD, 720p, 1080p, 4K')
            if item in shadow_forks:
                addon = xbmcaddon.Addon(item)
                addon.setSetting("max_q", '0')
                addon.setSetting("max_q_tv", '0')
            if item in oath_forks:
                addon = xbmcaddon.Addon(item)
                addon.setSetting("hosts.quality", '2')
            if item in other:
                if 'seren' in item:
                    addon = xbmcaddon.Addon(item)
                    addon.setSetting("general.maxResolution", '0')
                if 'otaku' in item:
                    addon = xbmcaddon.Addon(item)
                    addon.setSetting("general.maxResolution", '0')
                if 'testing' in item:
                    addon = xbmcaddon.Addon(item)
                    addon.setSetting("general.maxResolution", '4')
                if 'fenlight' in item:
                    from resources.lib.modules import maxql_db
                    maxql_db.enable_fenlt_4k()
                    xbmc.executebuiltin('PlayMedia(plugin://plugin.video.fenlight/?mode=sync_settings&amp;silent=true)')
                    xbmc.sleep(2000)
                if 'gears' in item:
                    addon = xbmcaddon.Addon(item)
                    addon.setSetting("hosts.quality", '2')
                if 'scrubs' in item:
                    addon = xbmcaddon.Addon(item)
                    addon.setSetting("quality.max", '0')

        xbmcgui.Dialog().notification('MaxQL', '4K Max Enabled!', addon_icon, 3000)

        
    elif mode == 3:
        for item in addon_list:
            if item in fen_forks:
                addon = xbmcaddon.Addon(item)
                addon.setSetting("filter_dv", '0')
            if item in oath_forks:
                addon = xbmcaddon.Addon(item)
                addon.setSetting("remove.dv", 'false')
            if item in other:
                if 'seren' in item:
                    addon = xbmcaddon.Addon(item)
                    chk_seren_ftr = addon.getSetting("general.filters")
                    single_ftr = 'DV'
                    additional_ftr1 = ',DV'
                    additional_ftr2 = 'DV,'
                    if str(chk_seren_ftr) == single_ftr:
                        addon.setSetting("general.filters", "AV1")
                    if additional_ftr1 in chk_seren_ftr:
                        current = str(addon.getSetting("general.filters"))
                        new = current.replace(",DV", "")
                        addon.setSetting("general.filters", new)
                    if additional_ftr2 in chk_seren_ftr:
                        current = str(addon.getSetting("general.filters"))
                        new = current.replace("DV,", "")
                        addon.setSetting("general.filters", new)     
                if 'fenlight' in item:
                    from resources.lib.modules import maxql_db
                    maxql_db.disable_fenlt_dv()
                    xbmc.executebuiltin('PlayMedia(plugin://plugin.video.fenlight/?mode=sync_settings&amp;silent=true)')
                    xbmc.sleep(2000)
                if 'gears' in item:
                    addon = xbmcaddon.Addon(item)
                    addon.setSetting("remove.dolby.vision", 'false')
            
        xbmcgui.Dialog().notification('MaxQL', 'Dolby Vision Enabled!', addon_icon, 3000)
        
    elif mode == 4:
        for item in addon_list:
            if item in fen_forks:
                addon = xbmcaddon.Addon(item)
                addon.setSetting("filter_dv", '1')
            if item in venom_forks:
                addon = xbmcaddon.Addon(item)
                addon.setSetting("remove.dolby.vision", 'true')
            if item in oath_forks:
                addon = xbmcaddon.Addon(item)
                addon.setSetting("remove.dv", 'true')
            if item in other:
                if 'seren' in item:
                    addon = xbmcaddon.Addon(item)
                    chk_seren_ftr = addon.getSetting("general.filters")
                    single_ftr = 'DV'
                    additional_ftr = ',DV'
                    if str(chk_seren_ftr) != '' and single_ftr not in str(chk_seren_ftr):
                        addon.setSetting("general.filters", chk_seren_ftr + additional_ftr)
                    else:
                        addon.setSetting("general.filters", single_ftr)     
                if 'fenlight' in item:
                    from resources.lib.modules import maxql_db
                    maxql_db.enable_fenlt_dv()
                    xbmc.executebuiltin('PlayMedia(plugin://plugin.video.fenlight/?mode=sync_settings&amp;silent=true)')
                    xbmc.sleep(2000)
                if 'gears' in item:
                    addon = xbmcaddon.Addon(item)
                    addon.setSetting("remove.dolby.vision", 'true')
                    
            xbmcgui.Dialog().notification('MaxQL', 'Dolby Vision Disabled!', addon_icon, 3000)

    elif mode == 5:
        for item in addon_list:
            if item in fen_forks:
                addon = xbmcaddon.Addon(item)
                addon.setSetting("include_3d_results", 'true')
            if item in venom_forks:
                addon = xbmcaddon.Addon(item)
                addon.setSetting("remove.3D.sources", 'false')
            if item in shadow_forks:
                addon = xbmcaddon.Addon(item)
                addon.setSetting("encoding_filter", 'true')
                addon.setSetting("3d", 'true')
                addon.setSetting("encoding_filter_tv", 'true')
                addon.setSetting("3d_tv", 'true')
            if item in other:
                if 'seren' in item:
                    addon = xbmcaddon.Addon(item)
                    chk_seren_ftr = addon.getSetting("general.filters")
                    single_ftr = '3D'
                    additional_ftr = ',3D'
                    if str(chk_seren_ftr) != '' and single_ftr not in str(chk_seren_ftr):
                        addon.setSetting("general.filters", chk_seren_ftr + additional_ftr) 
                    else:
                        addon.setSetting("general.filters", single_ftr)  
                if 'fenlight' in item:
                    from resources.lib.modules import maxql_db
                    maxql_db.enable_fenlt_3d()
                    xbmc.executebuiltin('PlayMedia(plugin://plugin.video.fenlight/?mode=sync_settings&amp;silent=true)')
                    xbmc.sleep(2000)
                if 'gears' in item:
                    addon = xbmcaddon.Addon(item)
                    addon.setSetting("remove.3D.sources", 'false')
                    
            xbmcgui.Dialog().notification('MaxQL', '3D Enabled!', addon_icon, 3000)

    elif mode == 6:
        for item in addon_list:
            if item in fen_forks:
                addon = xbmcaddon.Addon(item)
                addon.setSetting("include_3d_results", 'false')
            if item in venom_forks:
                addon = xbmcaddon.Addon(item)
                addon.setSetting("remove.3D.sources", 'true')
            if item in shadow_forks:
                addon = xbmcaddon.Addon(item)
                addon.setSetting("encoding_filter", 'false')
                addon.setSetting("3d", 'false')
                addon.setSetting("encoding_filter_tv", 'false')
                addon.setSetting("3d_tv", 'false')
            if item in other:
                if 'seren' in item:
                    addon = xbmcaddon.Addon(item)
                    chk_seren_ftr = addon.getSetting("general.filters")
                    single_ftr = '3D'
                    additional_ftr1 = ',3D'
                    additional_ftr2 = '3D,'
                    if str(chk_seren_ftr) == '3D':
                        addon.setSetting("general.filters", "AV1")
                    if additional_ftr1 in chk_seren_ftr:
                        current = str(addon.getSetting("general.filters"))
                        new = current.replace(",3D", "")
                        addon.setSetting("general.filters", new)
                    if additional_ftr2 in chk_seren_ftr:
                        current = str(addon.getSetting("general.filters"))
                        new = current.replace("3D,", "")
                        addon.setSetting("general.filters", new)
                if 'fenlight' in item:
                    from resources.lib.modules import maxql_db
                    maxql_db.disable_fenlt_3d()
                    xbmc.executebuiltin('PlayMedia(plugin://plugin.video.fenlight/?mode=sync_settings&amp;silent=true)')
                    xbmc.sleep(2000)
                if 'gears' in item:
                    addon = xbmcaddon.Addon(item)
                    addon.setSetting("remove.3D.sources", 'true')

            xbmcgui.Dialog().notification('MaxQL', '3D Disabled!', addon_icon, 3000)

    elif mode == 7:
        for item in addon_list:
            if item in fen_forks:
                addon = xbmcaddon.Addon(item)
                addon.setSetting("auto_play_movie", 'true')
                addon.setSetting("auto_play_episode", 'true')
            if item in venom_forks:
                addon = xbmcaddon.Addon(item)
                addon.setSetting("play.mode.movie", '1')
                addon.setSetting("play.mode.tv", '1')
            if item in shadow_forks:
                addon = xbmcaddon.Addon(item)
                addon.setSetting("one_click", 'true')
                addon.setSetting("one_click_tv", 'true')
            if item in oath_forks:
                addon = xbmcaddon.Addon(item)
                addon.setSetting("hosts.mode", '2')
            if item in other:
                if 'seren' in item:
                    addon = xbmcaddon.Addon(item)
                    addon.setSetting("general.playstyleMovie", '0')
                    addon.setSetting("general.playstyleEpisodes", '0')
                if 'otaku' in item:
                    addon = xbmcaddon.Addon(item)
                    addon.setSetting("general.playstyle.movie", '0')
                    addon.setSetting("general.playstyle.episodes", '0')
                if 'testing' in item:
                    addon = xbmcaddon.Addon(item)
                    addon.setSetting("general.playstyle.movie", '0')
                    addon.setSetting("general.playstyle.episodes", '0') 
                if 'fenlight' in item:
                    from resources.lib.modules import maxql_db
                    maxql_db.enable_fenlt_ap()
                    xbmc.executebuiltin('PlayMedia(plugin://plugin.video.fenlight/?mode=sync_settings&amp;silent=true)')
                    xbmc.sleep(2000)
                if 'gears' in item:
                    addon = xbmcaddon.Addon(item)
                    addon.setSetting("play.mode", '1')
                if 'scrubs' in item:
                    addon = xbmcaddon.Addon(item)
                    addon.setSetting("hosts.mode", '2')

            xbmcgui.Dialog().notification('MaxQL', 'Auto-Play Enabled!', addon_icon, 3000)

    elif mode == 8:
        for item in addon_list:
            if item in fen_forks:
                addon = xbmcaddon.Addon(item)
                addon.setSetting("auto_play_movie", 'false')
                addon.setSetting("auto_play_episode", 'false')
            if item in venom_forks:
                addon = xbmcaddon.Addon(item)
                addon.setSetting("play.mode.movie", '0')
                addon.setSetting("play.mode.tv", '0')
            if item in shadow_forks:
                addon = xbmcaddon.Addon(item)
                addon.setSetting("one_click", 'false')
                addon.setSetting("one_click_tv", 'false')
            if item in oath_forks:
                addon = xbmcaddon.Addon(item)
                addon.setSetting("hosts.mode", '1')
            if item in other:
                if 'seren' in item:
                    addon = xbmcaddon.Addon(item)
                    addon.setSetting("general.playstyleMovie", '1')
                    addon.setSetting("general.playstyleEpisodes", '1')
                if 'otaku' in item:
                    addon = xbmcaddon.Addon(item)
                    addon.setSetting("general.playstyle.movie", '1')
                    addon.setSetting("general.playstyle.episode", '1')
                if 'testing' in item:
                    addon = xbmcaddon.Addon(item)
                    addon.setSetting("general.playstyle.movie", '1')
                    addon.setSetting("general.playstyle.episode", '1')
                if 'fenlight' in item:
                    from resources.lib.modules import maxql_db
                    maxql_db.enable_fenlt_ap()
                    xbmc.executebuiltin('PlayMedia(plugin://plugin.video.fenlight/?mode=sync_settings&amp;silent=true)')
                    xbmc.sleep(2000)
                if 'gears' in item:
                    addon = xbmcaddon.Addon(item)
                    addon.setSetting("play.mode", '0')
                if 'scrubs' in item:
                    addon = xbmcaddon.Addon(item)
                    addon.setSetting("hosts.mode", '1')
                    
            xbmcgui.Dialog().notification('MaxQL', 'Auto-Play Disabled!', addon_icon, 3000)

    xbmcplugin.endOfDirectory(handle)
