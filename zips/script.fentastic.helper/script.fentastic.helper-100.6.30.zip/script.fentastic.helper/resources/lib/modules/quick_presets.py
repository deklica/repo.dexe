# -*- coding: utf-8 -*-
"""Skin-only presets. Full user backups remain in backup_restore.py."""
import json
import os
import re
import shutil
import sqlite3
import tempfile
import zipfile
import xml.etree.ElementTree as ET
from contextlib import closing

import xbmc
import xbmcgui
import xbmcvfs
from modules.backup_restore import get_backup_directory, skin_id

TITLE = 'FENtastic Plus Presets'
MAX_PRESETS = 6
DATA = xbmcvfs.translatePath('special://profile/addon_data/script.fentastic.helper/')
SETTINGS = xbmcvfs.translatePath('special://profile/addon_data/%s/settings.xml' % skin_id)
SKIN_XML = xbmcvfs.translatePath('special://skin/xml/')
STATE = os.path.join(DATA, 'quick_preset_active.json')
CACHE = os.path.join(DATA, 'cpath_cache.db')
ICON = xbmcvfs.translatePath('special://home/addons/script.fentastic.helper/resources/icon.png')


def _directory():
    path = os.path.join(get_backup_directory(), 'Quick_Presets')
    os.makedirs(path, exist_ok=True)
    return path


def _files():
    return sorted((f for f in os.listdir(_directory()) if f.lower().endswith('.zip') and
                   os.path.isfile(os.path.join(_directory(), f))), key=str.casefold)


def _menu_files():
    return sorted(f for f in os.listdir(SKIN_XML) if os.path.isfile(os.path.join(SKIN_XML, f))
                  and (f.lower().startswith('script-fentastic') and f.lower().endswith('.xml')
                       or f.lower() == 'includes_mainmenu.xml'))


def _active():
    try:
        with open(STATE, encoding='utf-8') as f:
            return json.load(f).get('name')
    except (OSError, ValueError, TypeError):
        return None


def _set_active(name):
    os.makedirs(DATA, exist_ok=True)
    tmp = STATE + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump({'name': name}, f)
    os.replace(tmp, STATE)


def clear_active_preset():
    if _active() is not None:
        _set_active(None)
        _populate_presets()


def _color(method, value=None):
    params = {'setting': 'lookandfeel.skincolors'}
    if value is not None:
        params['value'] = value
    response = json.loads(xbmc.executeJSONRPC(json.dumps({
        'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params})))
    if 'error' in response:
        raise RuntimeError(str(response['error']))
    return response['result'] if method.endswith('SetSettingValue') else response['result']['value']


def _settings(data):
    root = ET.fromstring(data)
    if root.tag != 'settings':
        raise ValueError('Invalid skin settings XML')
    result = {}
    for node in root.iter('setting'):
        key = node.get('id')
        if key and re.fullmatch(r'[A-Za-z0-9_.-]+', key):
            result[key] = (node.get('type', 'string').lower(), node.text or '')
    return result


def _apply_setting(key, setting):
    kind, value = setting
    if kind in ('bool', 'boolean'):
        xbmc.executebuiltin('Skin.SetBool(%s)' % key if value.lower() in ('true', '1')
                            else 'Skin.Reset(%s)' % key)
    elif value:
        safe = value.replace('\\', '\\\\').replace('"', '\\"').replace('\r', '').replace('\n', '')
        xbmc.executebuiltin('Skin.SetString(%s,"%s")' % (key, safe))
    else:
        xbmc.executebuiltin('Skin.Reset(%s)' % key)


def _snapshot_cache(archive):
    if not os.path.isfile(CACHE):
        return
    with tempfile.TemporaryDirectory(prefix='fentastic_preset_cache_') as temp:
        snapshot = os.path.join(temp, 'cache.db')
        with closing(sqlite3.connect(CACHE, timeout=10)) as source:
            with closing(sqlite3.connect(snapshot, timeout=10)) as dest:
                source.backup(dest)
        archive.write(snapshot, 'cpath_cache.db')


def save_preset():
    dialog = xbmcgui.Dialog()
    name = dialog.input('Enter Preset Name', type=xbmcgui.INPUT_ALPHANUM).strip()
    if not name:
        return
    if name in ('.', '..') or name.endswith(('.', ' ')) or not re.fullmatch(r'[^\\/:*?"<>|\x00-\x1f]+', name):
        dialog.ok(TITLE, 'Invalid preset name.')
        return
    files = _files()
    match = next((f for f in files if f[:-4].casefold() == name.casefold()), None)
    if not match and len(files) >= MAX_PRESETS:
        dialog.ok(TITLE, 'Maximum of six quick presets reached.')
        return
    filename = match or name + '.zip'
    dest = os.path.join(_directory(), filename)
    if match and not dialog.yesno(TITLE, 'Overwrite preset: %s?' % filename[:-4]):
        return
    staged = dest + '.tmp'
    first_preset = not files
    enable_top_bar = (first_preset and dialog.yesno(
        TITLE, 'Show My Presets in the top bar?', nolabel='No', yeslabel='Yes'))
    try:
        # Respect the user's choice before capturing the first preset.
        if enable_top_bar:
            xbmc.executebuiltin('Skin.SetBool(Enable.TopBarMyPresets)')
        with open(SETTINGS, 'rb') as f:
            settings = f.read()
        _settings(settings)
        if enable_top_bar:
            # Kodi may not have flushed Skin.SetBool to settings.xml yet.
            # Ensure the archived snapshot includes the enabled setting.
            root = ET.fromstring(settings)
            setting = next((node for node in root.iter('setting')
                            if node.get('id') == 'Enable.TopBarMyPresets'), None)
            if setting is None:
                setting = ET.SubElement(root, 'setting', {'id': 'Enable.TopBarMyPresets', 'type': 'bool'})
            setting.set('type', 'bool')
            setting.text = 'true' if enable_top_bar else 'false'
            settings = ET.tostring(root, encoding='utf-8', xml_declaration=True)

        xmls = _menu_files()
        if not xmls:
            raise ValueError('No custom menu/widget files found')
        color = _color('Settings.GetSettingValue')
        with zipfile.ZipFile(staged, 'w', zipfile.ZIP_DEFLATED) as archive:
            archive.writestr('skin_settings/settings.xml', settings)
            archive.writestr('skin_color.json', json.dumps({'lookandfeel.skincolors': color}))
            for filename_xml in xmls:
                archive.write(os.path.join(SKIN_XML, filename_xml), 'skin_files/' + filename_xml)
            _snapshot_cache(archive)
        os.replace(staged, dest)
        # A newly saved preset matches the current configuration.
        _set_active(filename)
        _populate_presets()
        dialog.notification(TITLE, 'Preset saved: %s' % filename[:-4], ICON, 3000)
    except Exception as exc:
        xbmc.log('FENtastic Plus preset save failed: %s' % exc, xbmc.LOGERROR)
        dialog.ok(TITLE, 'Unable to save preset:[CR]%s' % exc)
    finally:
        if os.path.isfile(staged):
            os.remove(staged)


def restore_preset(filename):
    dialog = xbmcgui.Dialog()
    if filename not in _files():
        dialog.ok(TITLE, 'Preset not found.')
        return
    try:
        with zipfile.ZipFile(os.path.join(_directory(), filename)) as archive:
            if archive.testzip() is not None:
                raise ValueError('Corrupt preset ZIP')
            names = archive.namelist()
            allowed = {'skin_settings/settings.xml', 'skin_color.json', 'cpath_cache.db'}
            if any(n not in allowed and not (n.startswith('skin_files/') and
                   re.fullmatch(r'[A-Za-z0-9_.-]+\.xml', n[11:])) for n in names):
                raise ValueError('Unexpected file in preset ZIP')
            if 'skin_settings/settings.xml' not in names or 'skin_color.json' not in names:
                raise ValueError('Incomplete preset')
            xmls = [n for n in names if n.startswith('skin_files/')]
            if not xmls:
                raise ValueError('Preset has no menu/widget files')
            settings = _settings(archive.read('skin_settings/settings.xml'))
            with open(SETTINGS, 'rb') as f:
                original_settings = _settings(f.read())
            color = json.loads(archive.read('skin_color.json').decode('utf-8'))['lookandfeel.skincolors']
            if not isinstance(color, str) or not color:
                raise ValueError('Invalid skin colour')
            # Validate all XML before any changes to the live skin.
            for n in xmls:
                ET.fromstring(archive.read(n))
            with tempfile.TemporaryDirectory(prefix='fentastic_preset_restore_') as temp:
                originals = {}
                existing = _menu_files()
                for n in set(existing) | {os.path.basename(m) for m in xmls}:
                    path = os.path.join(SKIN_XML, n)
                    originals[n] = open(path, 'rb').read() if os.path.isfile(path) else None
                old_color = _color('Settings.GetSettingValue')
                cache_original = os.path.join(temp, 'cache_original.db')
                if 'cpath_cache.db' in names:
                    cache_new = os.path.join(temp, 'cache_new.db')
                    with open(cache_new, 'wb') as f:
                        f.write(archive.read('cpath_cache.db'))
                    with closing(sqlite3.connect(cache_new)) as db:
                        if db.execute('PRAGMA integrity_check').fetchone()[0] != 'ok':
                            raise ValueError('Invalid widget cache')
                    if os.path.isfile(CACHE):
                        with closing(sqlite3.connect(CACHE, timeout=10)) as src:
                            with closing(sqlite3.connect(cache_original, timeout=10)) as dst:
                                src.backup(dst)
                try:
                    for n in xmls:
                        dest = os.path.join(SKIN_XML, os.path.basename(n))
                        staged = dest + '.preset_tmp'
                        with open(staged, 'wb') as f:
                            f.write(archive.read(n))
                        os.replace(staged, dest)
                    for n in existing:
                        if 'skin_files/' + n not in xmls:
                            os.remove(os.path.join(SKIN_XML, n))
                    # Preserve the device's backup location and other backup-only settings.
                    settings.pop('backup_directory', None)
                    # The icon animation state belongs to the device, not a saved preset.
                    settings.pop('FENtastic.Preset.SwitchIconOn', None)
                    for key in original_settings.keys() - settings.keys():
                        if key not in ('backup_directory', 'FENtastic.Preset.SwitchIconOn'):
                            xbmc.executebuiltin('Skin.Reset(%s)' % key)
                    for key, value in settings.items():
                        _apply_setting(key, value)
                    _color('Settings.SetSettingValue', color)
                    if 'cpath_cache.db' in names:
                        os.makedirs(DATA, exist_ok=True)
                        with closing(sqlite3.connect(cache_new)) as src:
                            with closing(sqlite3.connect(CACHE)) as dst:
                                src.backup(dst)
                except Exception:
                    for n, content in originals.items():
                        dest = os.path.join(SKIN_XML, n)
                        if content is None:
                            if os.path.isfile(dest):
                                os.remove(dest)
                        else:
                            with open(dest, 'wb') as f:
                                f.write(content)
                    for key, value in original_settings.items():
                        if key not in ('backup_directory', 'FENtastic.Preset.SwitchIconOn'):
                            _apply_setting(key, value)
                    _color('Settings.SetSettingValue', old_color)
                    if os.path.isfile(cache_original):
                        with closing(sqlite3.connect(cache_original)) as src:
                            with closing(sqlite3.connect(CACHE)) as dst:
                                src.backup(dst)
                    raise
        _set_active(filename)
        # Alternate the top-bar switch graphic after each successful restore.
        xbmc.executebuiltin('Skin.ToggleSetting(FENtastic.Preset.SwitchIconOn)')
        xbmc.executebuiltin('ReloadSkin()')
        dialog.notification(TITLE, '%s Preset Active' % filename[:-4], ICON, 3000)
    except Exception as exc:
        xbmc.log('FENtastic Plus preset restore failed: %s' % exc, xbmc.LOGERROR)
        dialog.ok(TITLE, 'Unable to switch preset:[CR]%s' % exc)


# Dialog properties live on Home so they survive closing/reopening custom windows.
PRESET_WINDOW = xbmcgui.Window(10000)


def _populate_presets():
    files = _files()
    active = _active()
    if active and active in files:
        PRESET_WINDOW.setProperty("FENtastic.Preset.ActiveName", active[:-4])
    else:
        PRESET_WINDOW.clearProperty("FENtastic.Preset.ActiveName")
    for i in range(MAX_PRESETS):
        name_key = 'FENtastic.Preset.Name.%d' % i
        display_key = 'FENtastic.Preset.Display.%d' % i
        active_key = 'FENtastic.Preset.Active.%d' % i
        if i < len(files):
            label = files[i][:-4]
            PRESET_WINDOW.setProperty(name_key, label)
            PRESET_WINDOW.setProperty(display_key, label)
            PRESET_WINDOW.setProperty(active_key, 'true' if files[i] == active else 'false')
        else:
            PRESET_WINDOW.clearProperty(name_key)
            PRESET_WINDOW.clearProperty(display_key)
            PRESET_WINDOW.clearProperty(active_key)
    return files


def select_preset(direct=False):
    files = _populate_presets()
    if direct:
        PRESET_WINDOW.setProperty('FENtastic.DirectDialog1127', 'true')
    else:
        PRESET_WINDOW.clearProperty('FENtastic.DirectDialog1127')
    if not files:
        xbmcgui.Dialog().ok(TITLE, 'No saved quick presets found.')
        xbmc.executebuiltin('ActivateWindow(1126)')
        return
    xbmc.executebuiltin('ActivateWindow(1130)' if direct else 'ActivateWindow(1127)')


def manage_presets():
    files = _populate_presets()
    if not files:
        xbmcgui.Dialog().ok(TITLE, 'No saved quick presets found.')
        xbmc.executebuiltin('ActivateWindow(1126)')
        return
    xbmc.executebuiltin('ActivateWindow(1128)')


def apply_preset(index, direct=False):
    files = _files()
    if 0 <= index < len(files):
        if not direct and not xbmcgui.Dialog().yesno(
                'FENtastic Plus',
                "Are you sure you want to apply the '[COLOR gold]%s[/COLOR]' preset?[CR][CR]This will overwrite your current menus and widgets." % files[index][:-4],
                nolabel='No', yeslabel='Yes'):
            _populate_presets()
            xbmc.executebuiltin('ActivateWindow(1127)')
            return
        # Give the custom dialog time to close before restoring/reloading the skin.
        xbmc.sleep(100)
        PRESET_WINDOW.clearProperty('FENtastic.DirectDialog1127')
        restore_preset(files[index])
    else:
        xbmcgui.Dialog().ok(TITLE, 'Preset not found.')
        _populate_presets()
        xbmc.executebuiltin('ActivateWindow(1130)' if direct else 'ActivateWindow(1127)')


def preset_actions(index):
    files = _files()
    if not 0 <= index < len(files):
        xbmcgui.Dialog().ok(TITLE, 'Preset not found.')
        _populate_presets()
        xbmc.executebuiltin('ActivateWindow(1128)')
        return
    PRESET_WINDOW.setProperty('FENtastic.Preset.Selected', files[index])
    xbmc.executebuiltin('ActivateWindow(1129)')


def preset_action(action):
    dialog = xbmcgui.Dialog()
    filename = PRESET_WINDOW.getProperty('FENtastic.Preset.Selected')
    files = _files()
    if filename not in files:
        dialog.ok(TITLE, 'Selected preset no longer exists.')
    elif action == 'rename':
        name = dialog.input('Rename Preset', defaultt=filename[:-4], type=xbmcgui.INPUT_ALPHANUM).strip()
        if name:
            if name in ('.', '..') or name.endswith(('.', ' ')) or not re.fullmatch(r'[^\\/:*?"<>|\x00-\x1f]+', name):
                dialog.ok(TITLE, 'Invalid preset name.')
            else:
                dest = name + '.zip'
                if any(f.casefold() == dest.casefold() for f in files if f != filename):
                    dialog.ok(TITLE, 'A preset with that name already exists.')
                elif dest != filename:
                    try:
                        os.replace(os.path.join(_directory(), filename), os.path.join(_directory(), dest))
                        if _active() == filename:
                            _set_active(dest)
                    except OSError as exc:
                        dialog.ok(TITLE, 'Unable to rename preset:[CR]%s' % exc)
    elif action == 'delete':
        if dialog.yesno(TITLE, 'Delete preset: %s?' % filename[:-4], nolabel='Cancel', yeslabel='Delete'):
            try:
                os.remove(os.path.join(_directory(), filename))
                if _active() == filename:
                    _set_active(None)
            except OSError as exc:
                dialog.ok(TITLE, 'Unable to delete preset:[CR]%s' % exc)
    _populate_presets()
    PRESET_WINDOW.clearProperty('FENtastic.Preset.Selected')
    xbmc.executebuiltin('ActivateWindow(1128)' if _files() else 'ActivateWindow(1126)')
