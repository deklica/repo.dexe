"""Vidcore-only playback scrobbling using Cosmos's Simkl API implementation."""
import json
import math
import queue
import threading
import time
import xbmc
import xbmcaddon
import xbmcgui
from urllib.parse import parse_qsl, urlsplit
from resources.lib import simkl, simkl_next

KEY = 'Vidcore.Simkl.Playback'
HEARTBEAT = 'Vidcore.Simkl.ServiceAlive'


def matches_playback(path, pending):
    """Kodi may report the original plugin URL rather than its resolved stream."""
    path = path.split('|', 1)[0]
    if path == pending.get('path'):
        return True
    route = urlsplit(path)
    if route.scheme != 'plugin' or route.netloc != 'plugin.video.vidcore':
        return False
    params = dict(parse_qsl(route.query))
    if params.get('action') not in ('vidcore_sources', 'vidcore_play', 'vidcore_provider_play'):
        return False
    meta = pending.get('meta') or {}
    kind = 'movie' if meta.get('content') == 'movie' else 'tv'
    if params.get('tmdb_id') != str(meta.get('tmdb')) or params.get('kind', 'movie') != kind:
        return False
    return kind == 'movie' or all(str(params.get(key)) == str(meta.get(key)) for key in ('season', 'episode'))


class Tracker(xbmc.Player):
    def __init__(self):
        super().__init__()
        self.meta = None
        self.progress = 0.0
        self.active_path = ''
        self.start_lock = threading.RLock()
        self.events = queue.Queue()
        self.worker_thread = threading.Thread(target=self.worker, daemon=True)
        self.worker_thread.start()

    def worker(self):
        while True:
            event = self.events.get()
            if event is None:
                return
            verb, meta, progress = event
            try:
                self.dispatch_event(verb, meta, progress)
            except Exception as exc:
                from resources.lib import debug_bundle
                debug_bundle.error('Simkl playback event', verb)

    def dispatch_event(self, verb, meta, progress):
        if xbmcaddon.Addon('plugin.video.vidcore').getSetting('simkl_scrobble') == 'false':
            return
        if '_simkl_account' in meta and meta['_simkl_account'] != simkl._account_cache_key():
            # A queued event belongs to the connection active at playback
            # selection, never to a subsequently connected account.
            return
        if not simkl.has_token():
            # An unlinked account is normal; do not attempt unauthenticated events.
            return
        xbmc.log('VIDCORE Simkl playback event: %s progress=%.2f' % (verb, progress), xbmc.LOGINFO)
        confirmed = simkl.scrobble(verb, meta, progress, require_watched=verb == 'stop')
        if verb == 'stop' and confirmed:
            simkl_next.completed(meta)

    def sample(self):
        with self.start_lock:
            if self.meta and self.isPlayingVideo():
                try:
                    total = self.getTotalTime()
                    if total > 0:
                        self.progress = max(0.0, min(100.0, self.getTime() / total * 100))
                except RuntimeError:
                    pass

    def emit(self, verb):
        with self.start_lock:
            if self.meta:
                self.events.put((verb, dict(self.meta), self.progress))

    def onAVStarted(self):
        with self.start_lock:
            self.bind_playback()

    def bind_playback(self):
        window = xbmcgui.Window(10000)
        try:
            try:
                pending = json.loads(window.getProperty(KEY) or '{}')
            except (ValueError, TypeError):
                pending = None
            if not isinstance(pending, dict):
                window.clearProperty(KEY)
                pending = {}
            if pending:
                try:
                    age = time.time() - float(pending.get('at', 0))
                    valid = (math.isfinite(age) and 0 <= age <= 120
                             and isinstance(pending.get('meta'), dict)
                             and isinstance(pending.get('path'), str)
                             and bool(pending['path']))
                except (ValueError, TypeError, OverflowError):
                    valid = False
                if not valid:
                    window.clearProperty(KEY)
                    pending = {}
            path = self.getPlayingFile().split('|', 1)[0]
            if self.meta and matches_playback(path, {'path': self.active_path, 'meta': self.meta}) and not pending:
                # The polling fallback can bind before Kodi delivers onAVStarted.
                # A second callback for that same playback must not stop it.
                self.sample()
                return
            self.finish()
            if not pending or not matches_playback(path, pending):
                return
            window.clearProperty(KEY)
            self.meta = dict(pending['meta'])
            if '_simkl_account' not in self.meta:
                # Compatibility with pending playback from an older invoker.
                self.meta['_simkl_account'] = simkl._account_cache_key() if simkl.has_token() else ''
            self.active_path = pending['path']
            self.progress = 0.0
            self.sample()
            self.emit('start')
        except (ValueError, TypeError, KeyError, RuntimeError):
            pass

    def onPlayBackPaused(self):
        with self.start_lock:
            self.sample()
            self.emit('pause')

    def onPlayBackResumed(self):
        with self.start_lock:
            self.sample()
            self.emit('start')

    def onPlayBackSeek(self, position_ms, _offset_ms):
        with self.start_lock:
            if self.meta and self.isPlayingVideo():
                try:
                    total = self.getTotalTime()
                    if total > 0:
                        self.progress = max(0.0, min(100.0, position_ms / (total * 1000.0) * 100))
                except RuntimeError:
                    pass

    def finish(self, ended=False):
        with self.start_lock:
            meta = self.meta
            progress = 100.0 if ended else self.progress
            self.meta = None
            self.active_path = ''
            self.progress = 0.0
            if meta:
                self.events.put(('stop', dict(meta), progress))

    def onPlayBackStopped(self):
        self.finish()

    def onPlayBackEnded(self):
        self.finish(ended=True)

    def onPlayBackError(self):
        self.finish()

    def shutdown(self):
        # The FIFO sentinel lets queued playback updates finish before exit,
        # including the final stop when an earlier network request is slow.
        self.events.put(None)
        self.worker_thread.join()


if __name__ == '__main__':
    window = xbmcgui.Window(10000)
    try:
        alive = float(window.getProperty(HEARTBEAT) or 0)
    except ValueError:
        alive = 0
    if time.time() - alive > 10:
        window.setProperty(HEARTBEAT, str(time.time()))
        window.clearProperty('Vidcore.Simkl.ServiceStarting')
        xbmc.log('VIDCORE Simkl playback service started', xbmc.LOGINFO)
        monitor = xbmc.Monitor()
        tracker = Tracker()
        try:
            while not monitor.waitForAbort(1):
                window.setProperty(HEARTBEAT, str(time.time()))
                # Recover a start callback missed while launching the service.
                if tracker.meta is None and tracker.isPlayingVideo() and window.getProperty(KEY):
                    tracker.onAVStarted()
                tracker.sample()
                simkl_next.refresh_menu(tracker)
        finally:
            tracker.finish()
            tracker.shutdown()
            window.clearProperty(HEARTBEAT)
