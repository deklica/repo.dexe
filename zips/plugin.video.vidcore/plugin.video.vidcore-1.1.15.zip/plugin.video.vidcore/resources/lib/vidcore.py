"""TMDB catalogue with a modal Vidcore provider picker and Kodi playback."""
from urllib.parse import urlencode
from urllib.request import Request, urlopen
import re
import json
import base64
import uuid
import time
from datetime import date as calendar_date

import xbmcgui
import xbmcplugin
import xbmc

from . import tmdb
from . import search_history
from .aesgcm import aes_gcm_decrypt
from . import cinetaro
from . import cinejoy
from . import hydrahd
from . import rivestream
from . import vidnest
from . import vidbolt
from . import vidlove
from . import srstop
from . import lulustream
from . import streamtape
from . import doodstream
from . import byse
from . import voe
from . import morencius
from . import vidara
from . import streamplay
from . import hdhub
from . import twoembed
from . import dulo
from . import movieuniverse

_PICKER_DETAILS = {}

VIDROCK_AES_KEY = bytes.fromhex('7f3e9c2a8b5d1f4e6a9c3b7d2e5f8a1c4b6d9e2f5a8c1b4d7e9f2a5c8b1d4e7f')
STREAM_HEADERS = {'User-Agent': 'Mozilla/5.0', 'Referer': 'https://vidrock.net/',
                  'Origin': 'https://vidrock.net', 'Accept': '*/*'}
ADAPTIVE_PROVIDERS = frozenset(('luna', 'nova', 'atlas', 'astra', 'vidnest', 'vidlove', 'nest', 'jupiter', 'savefiles (hls)', 'lulustream', 'streamtape', 'hdhub', 'cinejoy'))
ADAPTIVE_PROVIDERS = ADAPTIVE_PROVIDERS | {'2embed', 'doodstream', 'byse', 'voe', 'dulo', 'morencius', 'vidara', 'streamplay', 'vidbolt'}
ADAPTIVE_PROVIDERS = ADAPTIVE_PROVIDERS | {'hydrahd'}
ADAPTIVE_PROVIDERS = ADAPTIVE_PROVIDERS | {'rivestream'}
ADAPTIVE_PROVIDERS = ADAPTIVE_PROVIDERS | {'adrock'}
ADAPTIVE_PROVIDERS = ADAPTIVE_PROVIDERS | {'movieuniverse'}
SRSTOP_RESOLVERS = {'SaveFiles (HLS)': srstop, 'LuluStream': lulustream,
                    'Streamtape': streamtape, 'DoodStream': doodstream,
                    'Byse': byse, 'VOE': voe, 'Morencius': morencius,
                    'Vidara': vidara, 'Streamplay': streamplay}


def _has_aired(entry, today):
    """Only advertise episodes with a confirmed air date up to today."""
    try:
        return calendar_date.fromisoformat(entry.get('air_date') or '') <= today
    except (ValueError, TypeError):
        return False


def _episode_released(params, today=None):
    """Check direct/bookmarked routes as well as the visible episode list."""
    if params.get('kind', 'movie') != 'tv':
        return True
    try:
        tmdb_id = str(params.get('tmdb_id', ''))
        season = int(params.get('season', 0))
        episode = int(params.get('episode', 0))
        if not tmdb_id.isdigit() or season < 0 or episode < 1:
            return False
        details = tmdb.get_episode_meta(tmdb_id, season, episode) or {}
        if params.get('simkl_next_episode') == 'true':
            from . import simkl_next
            official = simkl_next.cached_episode(params)
            if official.get('air_date'):
                details = dict(official, **details)
                details['air_date'] = official['air_date']
        _PICKER_DETAILS[('episode', tmdb_id, season, episode)] = details
        return _has_aired(details, today or calendar_date.today())
    except Exception:
        # Unknown dates or unavailable metadata must not trigger provider scans.
        return False


def _install_adaptive():
    """Install through Kodi, or enable an existing disabled installation."""
    def details():
        response = json.loads(xbmc.executeJSONRPC(json.dumps({
            'jsonrpc': '2.0', 'id': 1, 'method': 'Addons.GetAddonDetails',
            'params': {'addonid': 'inputstream.adaptive', 'properties': ['enabled']}})))
        return response.get('result', {}).get('addon')
    try:
        addon = details()
        if addon is None:
            xbmc.executebuiltin('InstallAddon(inputstream.adaptive)', True)
            addon = details()
        if addon is not None and not addon.get('enabled'):
            xbmc.executeJSONRPC(json.dumps({
                'jsonrpc': '2.0', 'id': 1, 'method': 'Addons.SetAddonEnabled',
                'params': {'addonid': 'inputstream.adaptive', 'enabled': True}}))
            addon = details()
        if addon and addon.get('enabled'):
            xbmcgui.Dialog().notification('Vidcore', 'InputStream Adaptive is installed and enabled.')
        else:
            xbmcgui.Dialog().ok('Vidcore',
                'InputStream Adaptive is not enabled. Install or enable it in Kodi add-ons. '
                'Some Linux installations require the kodi-inputstream-adaptive system package.')
    except (ValueError, TypeError, RuntimeError):
        xbmcgui.Dialog().ok('Vidcore', 'Unable to verify InputStream Adaptive. Check Kodi add-ons.')


def _catalogue_title_allowed(row):
    """Hide Japanese-original titles, including translated display titles."""
    return str(row.get('original_language') or '').strip().lower() != 'ja'


def _picker_media_info(meta, kind, tmdb_id, season, episode):
    """Build a media summary without confusing show and episode metadata."""
    title = meta.get('title') or ('Movie' if kind == 'movie' else 'TV show')
    detail = meta
    context = 'MOVIE'
    if kind != 'movie':
        context = 'SEASON %02d / EPISODE %02d' % (season, episode)
        detail = _PICKER_DETAILS.get(('episode', str(tmdb_id), season, episode), {})
    facts = []
    premiered = detail.get('air_date') if kind != 'movie' else detail.get('premiered')
    if premiered:
        facts.append(('Aired ' if kind != 'movie' else 'Released ') + premiered)
    if detail.get('runtime'):
        facts.append('%d min' % (detail['runtime'] // 60))
    if detail.get('rating'):
        facts.append('Rating %.1f / 10' % detail['rating'])
    return {
        'title': title,
        'subtitle': (detail.get('name') or 'Episode %d' % episode)
                    if kind != 'movie' else (meta.get('tagline') or ''),
        'context': context,
        'facts': '  /  '.join(facts),
        'genres': meta.get('genre') or '',
        'plot': (detail.get('overview') if kind != 'movie' else detail.get('plot'))
                or meta.get('plot') or 'Synopsis unavailable.',
        'art': detail.get('still') or meta.get('fanart') or meta.get('poster') or '',
    }


def _pick_source(sources, kind, tmdb_id, season=0, episode=0, host_picker=False, live_sources=None, scan_state=None, checked_sources=None, source_groups=None):
    """Show Vidcore media details while retaining provider tuple indices."""
    from .source_finder_dialog import LinkPickerDialog, ADDON_PATH

    meta = dict(_PICKER_DETAILS.get((kind, str(tmdb_id)), {}))
    title = meta.get('title') or ('Movie' if kind == 'movie' else 'TV show')
    context = 'Movie' if kind == 'movie' else 'S%02d E%02d' % (season, episode)
    def quality(name, stream):
        from .source_quality import source_summary
        return source_summary(name, stream, checked_sources or {}, source_groups or {}, host_picker)

    def rows():
        if live_sources is not None:
            sources[:] = live_sources()
        return [
        {'label': 'SaveFiles' if name == 'SaveFiles (HLS)' else name,
         'key': repr((name, _stream)),
         'meta': ('Hosts listed for %s on SRStop' % context
                  if name == 'SRStop' else 'Vidrock servers / %s' % context
                  if name == 'AdRock' else '%s / %s' % (
                      context, 'Via SRStop' if host_picker else 'Checked stream')) +
                  ((' / ' if str(stream_type).lower() == 'hosts' else ' / ' + str(stream_type).upper() + ' / ') + quality(name, _stream)[1] if quality(name, _stream)[1] else ''),
         'format_label': quality(name, _stream)[0] or {'hls': 'HLS', 'mp4': 'MP4', 'hosts': 'HOSTS'}.get(str(stream_type).lower(), 'AUTO')}
        for name, _stream, stream_type in sources
    ]
    links = rows()
    dialog = LinkPickerDialog(
        'VidCoreSourcePicker.xml',
        ADDON_PATH, 'Default', '720p',
        quality_label=title, poster=meta.get('poster', ''), links=links,
        media_info=_picker_media_info(meta, kind, tmdb_id, season, episode),
        links_provider=rows if live_sources else None, scan_state=scan_state,
        media_provider=lambda: _picker_media_info(
            _PICKER_DETAILS.get((kind, str(tmdb_id)), {}), kind, tmdb_id, season, episode))
    try:
        dialog.doModal()
        selected = dialog.selected_index
        return selected if selected is not None and 0 <= selected < len(sources) else -1
    finally:
        del dialog


def _pick_provider(sources, kind, tmdb_id, season, episode, srstop_hosts=(),
                   source_groups=None, checked_sources=None, live_availability=None, scan_state=None):
    """Browse nested sources; Back returns to the provider picker."""
    source_groups = source_groups or {}
    checked_sources = checked_sources or {}
    def checked_hosts(names):
        return [(name, '', checked_sources[('SRStop', name)]['type'])
                for name in names if name in SRSTOP_RESOLVERS
                and ('SRStop', name) in checked_sources]

    hosts = checked_hosts(srstop_hosts)
    def refresh():
        if live_availability is not None:
            fresh_sources, fresh_checked, fresh_groups, fresh_hosts = live_availability()
            sources[:] = fresh_sources
            checked_sources.clear()
            checked_sources.update(fresh_checked)
            source_groups.clear()
            source_groups.update(fresh_groups)
            hosts[:] = checked_hosts(fresh_hosts)
        return sources

    def group_sources(name):
        refresh()
        return [(label, key, checked_sources[key]['type'])
                for key, label in source_groups.get(name, [])]

    def host_sources():
        refresh()
        return hosts

    while True:
        index = _pick_source(sources, kind, tmdb_id, season, episode,
                             live_sources=refresh if live_availability else None, scan_state=scan_state,
                             checked_sources=checked_sources, source_groups=source_groups)
        if index < 0:
            return None
        source = sources[index]
        if source[0] in source_groups:
            rows = source_groups[source[0]]
            if not rows:
                continue
            candidates = [(label, key, checked_sources[key]['type'])
                          for key, label in rows]
            index = _pick_source(candidates, kind, tmdb_id, season, episode,
                                 live_sources=(lambda name=source[0]: group_sources(name)) if live_availability else None,
                                 scan_state=scan_state, checked_sources=checked_sources)
            if index >= 0:
                _label, key, stream_type = candidates[index]
                return source[0], key, stream_type
            continue
        if source[0] != 'SRStop':
            return source
        if not hosts:
            continue
        index = _pick_source(hosts, kind, tmdb_id, season, episode, host_picker=True,
                             live_sources=host_sources if live_availability else None, scan_state=scan_state,
                             checked_sources=checked_sources)
        if index >= 0:
            return hosts[index]


def _debug_bundle_event(tag, detail):
    """Write VidCore source diagnostics to the optional Cosmos debug bundle."""
    try:
        from . import debug_bundle
        if debug_bundle.is_enabled():
            debug_bundle.log('VidCore ' + str(tag), detail)
    except Exception:
        pass


def _check_picker_sources(sources, kind, tmdb_id, season, episode,
                          dulo_servers, srstop_hosts, adrock_sources=(), hydrahd_servers=(), progress=None, on_ready=None, source_cache=None, rive_embeds=()):
    """Resolve and check media before exposing providers, including SRStop."""
    from .vidcore_availability import check_sources
    def values(rows):
        return rows() if callable(rows) else rows

    def host_streams(rows, resolver, prefix=None):
        for index, row in enumerate(values(rows) or []):
            try:
                result = resolver(row['url'])
                if result:
                    result = dict(result, label=row.get('label') or 'Source')
                    if prefix:
                        result['_source_key'] = prefix + (index,)
                    yield result
            except Exception:
                continue

    def adrock_streams():
        for server, url, source_type in values(adrock_sources) or []:
            if str(server).casefold() not in ('nova', 'atlas', 'astra'):
                yield {'url': url, 'type': source_type, 'headers': dict(STREAM_HEADERS),
                       'label': server, '_source_key': ('AdRock', str(server).casefold())}

    def direct_vidrock(server, url, source_type):
        if callable(adrock_sources):
            fresh = values(adrock_sources) or []
            match = next((row for row in fresh if str(row[0]).casefold() == str(server).casefold()), None)
            if not match:
                return None
            _name, url, source_type = match
        elif source_cache is not None and source_cache.reused_discovery:
            from . import shared_requests
            fresh = shared_requests.fetch(
                ('vidrock', kind, str(tmdb_id), season, episode),
                lambda: _vidrock_sources(kind, tmdb_id, season, episode), ttl=10, timeout=8)
            match = next((row for row in fresh if str(row[0]).casefold() == str(server).casefold()), None)
            if not match:
                return None
            _name, url, source_type = match
        return {'url': url, 'type': source_type, 'headers': dict(STREAM_HEADERS)}
    jobs, groups = [], {'Dulo': [], 'HDHub': [], 'AdRock': [], 'Cinejoy': [], 'HydraHD': [], 'RiveStream': [], 'VidLove': [], 'MovieUniverse': []}
    from .vidcore_scan_dialog import create_progress
    owns_progress = progress is None
    if owns_progress:
        progress = create_progress()
    try:
        if hasattr(progress, 'begin_checks'):
            progress.begin_checks()
        for name, stream, stream_type in sources:
            if name == 'SRStop':
                for host in (SRSTOP_RESOLVERS if callable(srstop_hosts) else srstop_hosts):
                    resolver = SRSTOP_RESOLVERS.get(host)
                    if resolver is not None:
                        jobs.append((('SRStop', host), lambda resolver=resolver, host=host:
                                     resolver.resolve(tmdb_id, season, episode)
                                     if host in (values(srstop_hosts) or {}) else None))
                continue
            if name == 'AdRock':
                jobs.append(('AdRock', lambda: {'discovered_sources': adrock_streams()}))
                continue
            if name == 'HydraHD':
                jobs.append(('HydraHD', lambda: {'discovered_sources':
                    host_streams(hydrahd_servers, hydrahd.resolve_server)}))
                continue
            if name == 'Dulo':
                jobs.append(('Dulo', lambda: {'discovered_sources':
                    host_streams(dulo_servers, dulo.resolve_server)}))
                continue
            if name == 'HDHub':
                jobs.append(('HDHub', lambda: {'discovered_sources':
                    hdhub.discover(tmdb_id, kind, season, episode)}))
                continue
            if name == 'MovieUniverse':
                jobs.append(('MovieUniverse', lambda: {'discovered_sources':
                    movieuniverse.discover(tmdb_id, kind, season, episode)}))
                continue
            if name == 'RiveStream':
                for server in rivestream.SERVERS:
                    key = ('RiveStream', server)
                    groups[name].append((key, server.title()))
                    jobs.append((key, lambda server=server: rivestream.resolve_server(
                        server, tmdb_id, kind, season, episode)))
                embed_lookups = (rive_embeds if isinstance(rive_embeds, dict)
                                 else {'all': rive_embeds})
                for provider, lookup in embed_lookups.items():
                    jobs.append(('RiveEmbed:' + provider, lambda lookup=lookup, provider=provider:
                        {'discovered_sources': host_streams(lookup, rivestream.resolve_embed,
                                                          ('RiveStream', 'embed', provider))}))
                continue
            if name == 'Cinejoy':
                for server in cinejoy.SERVERS:
                    key = ('Cinejoy', server)
                    groups[name].append((key, server))
                    jobs.append((key, lambda server=server: cinejoy.resolve_server(
                        server, tmdb_id, kind, season, episode)))
                continue
            if name == 'VidLove':
                for backend, label in vidlove.SERVERS:
                    key = ('VidLove', backend)
                    groups[name].append((key, label))
                    jobs.append((key, lambda backend=backend, stream=stream:
                                 vidlove.resolve(stream, backend=backend)))
                continue
            if name in ('VidNest', '2Embed', 'VidBolt'):
                resolver = {'VidNest': vidnest, 'VidLove': vidlove, '2Embed': twoembed,
                            'VidBolt': vidbolt}[name]
                job = lambda resolver=resolver, stream=stream: resolver.resolve(stream)
            elif name == 'Nest':
                job = lambda: cinetaro.resolve(tmdb_id, kind, season, episode)
            elif name == 'Jupiter':
                job = lambda: _jupiter_source(kind, tmdb_id, season, episode)
            elif name in ('Nova', 'Atlas', 'Astra'):
                job = lambda name=name, stream=stream, stream_type=stream_type: direct_vidrock(name, stream, stream_type)
            else:
                job = lambda stream=stream, stream_type=stream_type: {
                    'url': stream, 'type': stream_type, 'headers': dict(STREAM_HEADERS)}
            jobs.append((name, job))
        all_groups = groups
        def filtered(checked, log=False):
            groups = {name: list(rows) for name, rows in all_groups.items()}
            for group in ('HDHub', 'AdRock', 'HydraHD', 'Dulo', 'MovieUniverse'):
                groups[group] = [(key, stream.get('label') or group + ' source')
                                 for key, stream in checked.items()
                                 if isinstance(key, tuple) and key[0] == group]
            groups['RiveStream'].extend((key, stream.get('label') or 'Embed source')
                                        for key, stream in checked.items()
                                        if isinstance(key, tuple) and key[:2] == ('RiveStream', 'embed'))
            hosts = [host for host in SRSTOP_RESOLVERS if ('SRStop', host) in checked]
            groups = {name: [(key, label) for key, label in rows if key in checked]
                      for name, rows in groups.items()}
            available = []
            for name, stream, stream_type in sources:
                if name == 'SRStop':
                    if hosts:
                        available.append((name, stream, 'hosts'))
                elif name in groups:
                    if groups[name]:
                        available.append((name, stream, 'hosts'))
                elif name in checked:
                    available.append((name, stream, checked[name]['type']))
                if log:
                    _debug_bundle_event('AVAILABILITY', '%s provider=%s result=%s' % (
                        _media_context(kind, tmdb_id, season, episode), _safe_source_name(name),
                        'available' if available and available[-1][0] == name else 'hidden'))
            return available, checked, groups, hosts
        ready = (lambda snapshot: on_ready(lambda: filtered(snapshot()[0]), snapshot)) if on_ready else None
        options = {'on_ready': ready, 'source_cache': source_cache} if ready or source_cache is not None else {}
        checked = check_sources(jobs, progress, xbmc.Monitor(), **options)
        return filtered(checked, log=True) if checked is not None else None
    finally:
        if owns_progress:
            progress.close()


def _media_context(kind, tmdb_id, season, episode):
    return (f'media={kind} tmdb_id={tmdb_id} '
            f'season={season} episode={episode}')


def _safe_source_name(value):
    """Keep provider labels compact and single-line in exported diagnostics."""
    return re.sub(r'[^A-Za-z0-9_. -]', '?', str(value or ''))[:60]


def _jupiter_source(kind, tmdb_id, season=0, episode=0):
    """Resolve VidCore's Jupiter (Movy Phoenix) using the current TMDB ID."""
    query = {'id': tmdb_id, 'type': kind}
    if kind == 'tv':
        query.update(season=season, episode=episode)
    endpoint = 'https://vidrack.created.app/api/sources/movy?' + urlencode(query)
    with urlopen(Request(endpoint, headers={'User-Agent': 'Mozilla/5.0',
                                           'Accept': 'application/json'}), timeout=20) as response:
        data = json.loads(response.read(2 * 1024 * 1024).decode('utf-8'))
    sources = data.get('sources', []) if isinstance(data, dict) else []
    sources = [s for s in sources if isinstance(s, dict)] if isinstance(sources, list) else []
    preferred = [s for s in sources if 'phoenix-1080p' in str(s.get('provider', ''))
                 or ('Phoenix' in str(s.get('label', ''))
                     and '1080' in str(s.get('quality', '')))]
    # A broken preferred backend must not hide the other returned streams.
    candidates = preferred + [row for row in sources if row not in preferred]
    from .vidcore_availability import check_stream
    for source in candidates[:8]:
        url = source.get('url', '')
        if not isinstance(url, str) or not url.startswith(('https://', 'http://')):
            continue
        headers = {'User-Agent': 'Mozilla/5.0'}
        if isinstance(source.get('headers'), dict):
            headers.update({k: v for k, v in source['headers'].items()
                            if isinstance(k, str) and isinstance(v, str)})
        checked = check_stream({'url': url, 'type': source.get('type') or 'hls',
                                'headers': headers})
        if checked:
            return checked
    return None


def _vidrock_sources(kind, tmdb_id, season=0, episode=0):
    """Resolve the Vidrock player embedded as AdRock by 7reels.

    7reels passes TMDB IDs directly to Vidrock for movies and TV episodes;
    use the player's API rather than scraping the surrounding watch page.
    """
    path = 'tv/%s/%s/%s' % (tmdb_id, season, episode) if kind == 'tv' else 'movie/%s' % tmdb_id
    request = Request('https://vidrock.net/api/' + path,
                      headers=dict(STREAM_HEADERS, Accept='application/json',
                                   Referer='https://vidrock.net/' + path))
    with urlopen(request, timeout=12) as response:
        raw = response.read(2 * 1024 * 1024 + 1)
    if len(raw) > 2 * 1024 * 1024:
        return []
    data = json.loads(raw.decode('utf-8', errors='replace'))
    out = []
    for name, entry in data.items() if isinstance(data, dict) else []:
        if not isinstance(entry, dict) or not entry.get('url'):
            continue
        try:
            encoded = entry['url'].replace('-', '+').replace('_', '/')
            encoded += '=' * ((4 - len(encoded) % 4) % 4)
            blob = base64.b64decode(encoded)
            url = aes_gcm_decrypt(VIDROCK_AES_KEY, blob[:12], blob[12:])
            if isinstance(url, bytes):
                url = url.decode('utf-8')
            from urllib.parse import urlsplit
            parts = urlsplit(url)
            if (parts.scheme in ('http', 'https') and parts.hostname
                    and not parts.username and not parts.password
                    and not any(ord(c) < 33 for c in url)):
                out.append((name, url, entry.get('type', 'hls')))
        except Exception as exc:
            xbmc.log('VIDCORE Vidrock source %s failed: %s' % (name, exc), xbmc.LOGWARNING)
    return out


def _track_playback(li, url, params):
    """Attach playback identity and hand it to Vidcore's Simkl service."""
    tmdb_id = str(params.get('tmdb_id') or '').strip()
    kind = params.get('kind', 'movie')
    if not tmdb_id.isdigit() or kind not in ('movie', 'tv'):
        return
    details = (_PICKER_DETAILS.get((kind, tmdb_id)) or
               tmdb._SESSION_META_CACHE.get('%s:%s' % (
                   'movie' if kind == 'movie' else 'tvshow', tmdb_id)) or {})
    if not isinstance(details, dict):
        details = {}
    content = 'movie' if kind == 'movie' else 'episode'
    try:
        display = dict(details)
        if kind == 'tv':
            season = int(params.get('season') or 0)
            episode = int(params.get('episode') or 0)
            episode_details = (_PICKER_DETAILS.get(('episode', tmdb_id, season, episode))
                               or tmdb.get_episode_meta(tmdb_id, season, episode) or {})
            display.update({
                'title': episode_details.get('name') or 'Episode %d' % episode,
                'tvshowtitle': details.get('title') or params.get('title') or '',
                'season': season, 'episode': episode,
                'plot': episode_details.get('overview') or '',
                'rating': episode_details.get('rating') or 0,
                'runtime': episode_details.get('runtime') or 0,
                'premiered': episode_details.get('air_date') or '',
                'year': int(episode_details['air_date'][:4]) if episode_details.get('air_date') else 0,
                'votes': 0, 'tagline': '', 'originaltitle': '',
                'thumb': episode_details.get('still') or details.get('poster') or '',
            })
        tmdb.apply_to_listitem(li, display, content=content)
        tag = li.getVideoInfoTag()
        tag.setMediaType(content)
        tag.setUniqueIDs({'tmdb': tmdb_id}, 'tmdb')
        if kind == 'tv':
            tag.setTvShowTitle(display['tvshowtitle'])
            tag.setSeason(int(params.get('season') or 0))
            tag.setEpisode(int(params.get('episode') or 0))
    except Exception as exc:
        xbmc.log('VIDCORE playback display metadata: %s' % exc, xbmc.LOGWARNING)
    # Tracking must not depend on optional artwork or InfoTag support.
    try:
        meta = {'title': details.get('title') or params.get('title') or tmdb_id,
                'year': details.get('year', ''), 'tmdb': tmdb_id,
                'content': content, 'season': params.get('season'),
                'episode': params.get('episode'),
                'simkl_next_episode': params.get('simkl_next_episode') == 'true'}
        from . import simkl
        meta['_simkl_account'] = simkl._account_cache_key() if simkl.has_token() else ''
        xbmcgui.Window(10000).setProperty('Vidcore.Simkl.Playback', json.dumps(
            {'path': url.split('|', 1)[0], 'at': time.time(), 'meta': meta}))
    except Exception as exc:
        xbmc.log('VIDCORE playback metadata: %s' % exc, xbmc.LOGWARNING)


def _play_stream(handle, url, source_type='hls', provider='', stream_headers=None,
                 refresh_source='', tracking_params=None, proxy_opener=None,
                 proxy_refresh_tokens=False, native_hls=False, refresh_backend='', rivestream_refresh=None):
    """Start a source with the headers/properties Kodi needs."""
    provider_name = str(provider or '').strip().casefold()
    stream_kind = str(source_type or '').strip().casefold()
    # Verified media type takes precedence over misleading signed URL paths.
    is_hls = stream_kind == 'hls' or stream_kind not in ('dash', 'mp4', 'mkv') and '.m3u8' in url.lower()
    is_dash = stream_kind == 'dash' or not is_hls and stream_kind not in ('mp4', 'mkv') and '.mpd' in url.lower()
    use_adaptive = provider_name in ADAPTIVE_PROVIDERS and (is_hls or is_dash) and not (is_hls and native_hls)
    if use_adaptive and not xbmc.getCondVisibility('System.HasAddon(inputstream.adaptive)'):
        if is_hls:
            # Kodi's built-in player can handle HLS without another add-on.
            # Keep the same provider headers and local relay when needed.
            use_adaptive = False
        else:
            _install_adaptive()
            if not xbmc.getCondVisibility('System.HasAddon(inputstream.adaptive)'):
                xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
                return

    proxy = None
    headers_source = STREAM_HEADERS if stream_headers is None else stream_headers
    if not (is_hls or is_dash) and hasattr(proxy_opener, 'start_relay'):
        # Abyss checks use its decrypting opener; start the local MP4 relay
        # only after selection, so unselected sources leave no server threads.
        proxy = proxy_opener.start_relay()
        url = proxy.url
    if is_hls and provider_name in ('nova', 'atlas', 'vidnest', 'nest', 'adrock', 'dulo', 'lulustream', 'vidbolt', 'cinejoy', 'hydrahd', 'rivestream', 'movieuniverse', '2embed'):
        from .vidcore_proxy import Proxy
        refresh_callback = None
        if provider_name == 'vidbolt' and refresh_source:
            refresh_callback = lambda: vidbolt.resolve(refresh_source, backend=refresh_backend)
        elif provider_name == 'rivestream' and isinstance(rivestream_refresh, dict):
            refresh_callback = lambda: rivestream.resolve_server(**rivestream_refresh)
        proxy = Proxy(
            url,
            headers_source,
            refresh_tokens=proxy_refresh_tokens if provider_name == 'dulo' else provider_name not in ('adrock', 'nest', 'lulustream', 'vidbolt', 'cinejoy', 'hydrahd', 'rivestream', 'movieuniverse', '2embed'),
            refresh_callback=refresh_callback,
            request_opener=proxy_opener)
        url = proxy.url
        if provider_name == 'vidbolt' and refresh_callback:
            xbmc.log('VIDCORE VidBolt: automatic playback link renewal enabled', xbmc.LOGINFO)
        if provider_name == 'lulustream':
            xbmc.log('VIDCORE LuluStream: HLS relay active; preserving playback headers and cookies',
                     xbmc.LOGINFO)
    headers = urlencode(headers_source)
    li = xbmcgui.ListItem(path=url if use_adaptive else url + '|' + headers)
    li.setProperty('IsPlayable', 'true')
    li.setContentLookup(False)
    if is_hls or is_dash:
        li.setMimeType('application/dash+xml' if is_dash else 'application/vnd.apple.mpegurl')
        li.setContentLookup(False)
        if use_adaptive:
            li.setProperty('inputstream', 'inputstream.adaptive')
            # Kodi 21+ detects the manifest from its MIME type. Older
            # InputStream Adaptive releases still require this property.
            try:
                kodi_major = int(xbmc.getInfoLabel('System.BuildVersion').split('.', 1)[0])
            except (ValueError, TypeError):
                kodi_major = 20
            if kodi_major < 21:
                li.setProperty('inputstream.adaptive.manifest_type',
                               'mpd' if is_dash else 'hls')
            li.setProperty('inputstream.adaptive.manifest_headers', headers)
            li.setProperty('inputstream.adaptive.stream_headers', headers)
    else:
        li.setMimeType('video/x-matroska' if stream_kind == 'mkv' else 'video/mp4')
    if tracking_params:
        _track_playback(li, url, tracking_params)
    xbmc.log('VIDCORE playback selected: provider=%s type=%s native_hls=%s renewal=%s' % (
        _safe_source_name(provider), stream_kind, bool(native_hls),
        bool(rivestream_refresh) or provider_name == 'vidbolt' and bool(refresh_source)), xbmc.LOGINFO)
    xbmcplugin.setResolvedUrl(handle, True, li)
    if proxy:
        proxy.keep_alive()


def run(action, params, handle, add_directory, build_url, icon, fanart):
    if action in ('vidcore_sources', 'vidcore_play', 'vidcore_provider_play') and not _episode_released(params):
        xbmcgui.Dialog().notification('Vidcore', 'Episode is not released yet, or its release date cannot be verified.')
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return
    def _play_tracked_stream(*args, **kwargs):
        kwargs['tracking_params'] = params
        return _play_stream(*args, **kwargs)

    def finish(content='files', succeeded=True):
        xbmcplugin.setContent(handle, content)
        xbmcplugin.endOfDirectory(handle, succeeded=succeeded, cacheToDisc=False)

    if action == 'vidcore_play':
        kind = params.get('kind', 'movie')
        tmdb_id = str(params.get('tmdb_id', ''))
        if kind == 'movie':
            page_url = 'https://vidrock.net/movie/%s' % tmdb_id
        else:
            page_url = 'https://vidrock.net/tv/%s/%s/%s' % (
                tmdb_id, params.get('season', 0), params.get('episode', 0))
        stream = ''
        source_type, provider = 'auto', ''
        try:
            sources = _vidrock_sources(kind, tmdb_id, params.get('season', 0), params.get('episode', 0))
            if sources:
                provider, stream, source_type = sources[0]
        except Exception as exc:
            xbmc.log('VIDCORE Vidrock API resolver failed: %s' % exc, xbmc.LOGWARNING)
        try:
            if stream:
                raise StopIteration
            request = Request(page_url, headers={'User-Agent': 'Mozilla/5.0'})
            body = urlopen(request, timeout=15).read().decode('utf-8', errors='replace')
            candidates = re.findall(r'https?://[^\"\'<> ]+\.(?:m3u8|mp4)(?:\?[^\"\'<> ]*)?', body, re.I)
            stream = candidates[0] if candidates else ''
        except StopIteration:
            pass
        except Exception as exc:
            xbmc.log('VIDCORE Vidrock resolver failed: %s' % exc, xbmc.LOGWARNING)
        if stream:
            _play_tracked_stream(handle, stream, source_type=source_type, provider=provider)
        else:
            xbmcgui.Dialog().notification('Vidcore', 'Unable to resolve a playback stream.')
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    if action == 'vidcore_provider_play':
        stream = params.get('stream_url', '')
        if stream.startswith(('http://', 'https://')):
            item = xbmcgui.ListItem(path=stream)
            item.setProperty('IsPlayable', 'true')
            _track_playback(item, item.getPath(), params)
            xbmcplugin.setResolvedUrl(handle, True, item)
        else:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    def item(label, target, info=None, thumb='', folder=True, description='', **values):
        if values.get('kind') == 'tv':
            if target == 'vidcore_seasons':
                values.setdefault('title', (info or {}).get('title') or label)
            elif target in ('vidcore_episodes', 'vidcore_sources'):
                values.setdefault('title', params.get('title', ''))
        add_directory(label, build_url(action=target, **values),
                      thumb=thumb or icon, fanart=fanart,
                      info=info or {'title': label, 'plot': description}, is_folder=folder,
                      is_playable=target == 'vidcore_sources')

    if action == 'vidcore_root':
        item('Search', 'vidcore_search_menu',
             description='Search for movies or TV shows by title or keyword.')
        item('Movies', 'vidcore_menu', kind='movie',
             description='Search movies or browse current releases, upcoming titles, popular movies and top-rated favourites.')
        item('TV Shows', 'vidcore_menu', kind='tv',
             description='Search TV shows or browse shows on the air, episodes airing today, popular series and top-rated favourites.')
        item('Popular People', 'vidcore_people',
             description='Browse popular actors and other film and TV people, then explore their movie and TV credits.')
        item('My Tracking', 'vidcore_tracking', description='Manage your tracking account, lists and watched history.')
        item('Tools', 'vidcore_tools',
             description='Open Vidcore settings, install or configure InputStream Adaptive, or clear Vidcore caches.')
        item('Changelog', 'changelog', folder=False,
             info={'title': 'Changelog', 'plot': 'Read the latest Vidcore changes.'})
        finish()
        return

    if action == 'vidcore_tracking':
        item('Simkl', 'simkl_root', description='Connect your Simkl account to track playback, browse your custom lists and watchlists, find your next episodes, and view your latest watched history. Sync Simkl to check for updates.')
        finish()
        return

    if action == 'vidcore_search_menu':
        item('Search Movies', 'vidcore_search', kind='movie', search_id=uuid.uuid4().hex,
             description='Find movies by entering a title or keyword.')
        item('Movie Search History', 'vidcore_history', history_kind='movie',
             description='View and repeat your saved movie searches.')
        item('Search TV Shows', 'vidcore_search', kind='tv', search_id=uuid.uuid4().hex,
             description='Find TV shows by entering a title or keyword.')
        item('TV Show Search History', 'vidcore_history', history_kind='tv',
             description='View and repeat your saved TV show searches.')
        finish()
        return

    if action == 'vidcore_tools':
        item('Report a Bug', 'vidcore_report_bug', folder=False,
             description='How to collect the Kodi log for a Vidcore bug report.')
        item('Vidcore Settings', 'vidcore_settings', folder=False,
             description='Open Vidcore settings to configure metadata caching, provider country fallback and API keys.')
        try:
            adaptive_details = json.loads(xbmc.executeJSONRPC(json.dumps({
                'jsonrpc': '2.0', 'id': 1, 'method': 'Addons.GetAddonDetails',
                'params': {'addonid': 'inputstream.adaptive', 'properties': ['enabled']}})))
            adaptive_installed = bool(adaptive_details.get('result', {}).get('addon'))
        except (ValueError, TypeError, AttributeError, RuntimeError):
            adaptive_installed = xbmc.getCondVisibility('System.HasAddon(inputstream.adaptive)')
        if not adaptive_installed:
            item('Install InputStream Adaptive', 'vidcore_install_adaptive', folder=False,
                 description='Install InputStream Adaptive through Kodi.')
        item('InputStream Settings', 'vidcore_adaptive_settings', folder=False,
             description='Open InputStream Adaptive settings to configure stream quality and playback.')
        item('Clear Cache', 'vidcore_cache_clear', folder=False,
             description="Clear Vidcore metadata and source caches only. Keep settings, Simkl connection, search history, Kodi artwork and other add-ons' caches.")
        finish()
        return

    if action == 'vidcore_report_bug':
        import xbmcvfs
        xbmcgui.Dialog().ok('Report a Vidcore Bug',
            'Enable Detailed Vidcore logging in Vidcore Settings, repeat the problem, '
            'then send kodi.log with the title, episode and what went wrong. '
            'Disable detailed logging afterwards. Other addons may include private data; review the log before sharing.\n\nLog: ' +
            xbmcvfs.translatePath('special://logpath/kodi.log'))
        return

    if action == 'vidcore_country_select':
        from . import country_picker
        country_picker.show()
        return

    if action == 'vidcore_settings':
        from . import settings_dialog
        settings_dialog.show()
        return

    if action == 'vidcore_install_adaptive':
        _install_adaptive()
        return

    if action == 'vidcore_adaptive_settings':
        import xbmcaddon
        try:
            xbmcaddon.Addon('inputstream.adaptive').openSettings()
        except RuntimeError:
            xbmcgui.Dialog().ok('Vidcore',
                'InputStream Adaptive is unavailable. Use Install InputStream Adaptive in Tools first.')
        return

    if action == 'vidcore_cache_clear':
        from . import cache
        try:
            cache.clear()
            xbmcgui.Dialog().notification('Vidcore', 'Vidcore cache cleared.')
            xbmc.executebuiltin('Container.Refresh')
        except OSError as exc:
            xbmc.log('VIDCORE cache cleanup failed: %s' % exc, xbmc.LOGWARNING)
            xbmcgui.Dialog().ok('Vidcore', 'Vidcore cache cleanup is incomplete. Other cleanup steps were attempted.\n\n' + str(exc) + '\n\nPlease try again or restart Kodi.')
        return

    if action == 'vidcore_history_clear':
        scope = params.get('history_kind', 'all')
        try:
            search_history.clear(scope if scope in ('movie', 'tv') else None)
            xbmcgui.Window(10000).clearProperty('Vidcore.SearchSessions')
            xbmcgui.Dialog().notification('Vidcore', 'Search history cleared.')
            xbmc.executebuiltin('Container.Refresh')
        except OSError:
            xbmcgui.Dialog().notification('Vidcore', 'Unable to clear search history.')
        return

    if action == 'vidcore_history':
        scope = params.get('history_kind', 'all')
        rows = [row for row in search_history.load()
                if scope == 'all' or row['kind'] == scope]
        if rows:
            item('Clear Search History', 'vidcore_history_clear', folder=False,
                 history_kind=scope,
                 description='Clear saved searches from this search history.')
            for row in rows:
                label = row['query']
                if scope == 'all':
                    label += ' — Movies' if row['kind'] == 'movie' else ' — TV Shows'
                item(label, 'vidcore_search', kind=row['kind'], query=row['query'],
                     description='Search %s again for "%s".' % (
                         'movies' if row['kind'] == 'movie' else 'TV shows', row['query']))
        else:
            xbmcgui.Dialog().notification('Vidcore', 'No search history yet.')
        finish()
        return

    if action == 'vidcore_unavailable':
        xbmcgui.Dialog().ok('Vidcore', 'Playback sources are not enabled yet.')
        return

    kind = params.get('kind', 'movie')
    if kind not in ('movie', 'tv'):
        finish(succeeded=False)
        return

    if action == 'vidcore_menu':
        media_label = 'movies' if kind == 'movie' else 'TV shows'
        menu_categories = [
            ('Popular', 'popular', 'Browse %s currently popular on TMDB.' % media_label),
            ('Top Rated', 'top_rated', 'Browse the highest-rated %s on TMDB.' % media_label),
        ]
        for label, category, description in menu_categories:
            item(label, 'vidcore_list', kind=kind, category=category, description=description)
        item('Providers', 'vidcore_watch_providers', kind=kind,
             description='Browse %s by streaming service in the country detected from this device\'s internet connection. Availability data from TMDB and JustWatch.' % media_label)
        if kind == 'movie':
            release_categories = [
                ('Now Playing', 'now_playing', 'Browse movies currently showing in cinemas.'),
                ('Upcoming', 'upcoming', 'Explore movies with upcoming cinema releases.'),
            ]
        else:
            release_categories = [
                ('Airing Today', 'airing_today', 'Browse TV shows with episodes scheduled to air today.'),
                ('On the Air', 'on_the_air', 'Browse TV shows with episodes scheduled to air in the next seven days.'),
            ]
        for label, category, description in release_categories:
            item(label, 'vidcore_list', kind=kind, category=category, description=description)
        finish()
        return

    if action == 'vidcore_watch_providers':
        region = str(params.get('watch_region') or '').upper()
        if not re.fullmatch(r'[A-Z]{2}', region):
            region = tmdb.watch_region()
        providers = tmdb.get_watch_providers(kind, region)
        if providers is None:
            xbmcgui.Dialog().notification('Vidcore', 'Unable to load providers. Please try again.')
            finish(succeeded=False)
            return
        providers = [row for row in providers if row.get('provider_id')]
        page_size = 20
        page_count = max(1, (len(providers) + page_size - 1) // page_size)
        try:
            page = max(1, min(page_count, int(params.get('page', 1))))
        except (TypeError, ValueError):
            page = 1
        start = (page - 1) * page_size
        if page > 1:
            item('Previous Page (%d/%d)' % (page - 1, page_count),
                 'vidcore_watch_providers', kind=kind, page=page - 1,
                 watch_region=region)
        for row in providers[start:start + page_size]:
            name = row.get('provider_name') or 'Streaming service'
            item(name, 'vidcore_list', kind=kind, provider_id=row['provider_id'],
                 watch_region=region, thumb=tmdb._img(row.get('logo_path')),
                 description='Browse %s available on %s in %s. Availability data from TMDB and JustWatch.' % (
                     'movies' if kind == 'movie' else 'TV shows', name, region))
        if not providers:
            xbmcgui.Dialog().notification('Vidcore', 'No providers found for %s.' % region)
        if page < page_count:
            item('Next Page (%d/%d)' % (page + 1, page_count),
                 'vidcore_watch_providers', kind=kind, page=page + 1,
                 watch_region=region)
        finish()
        return

    if action == 'vidcore_people':
        try:
            page = max(1, min(500, int(params.get('page', 1))))
        except (TypeError, ValueError):
            page = 1
        people, total_pages = tmdb.get_popular_people_page(page)
        if not people:
            xbmcgui.Dialog().notification('Vidcore', 'Unable to load popular people. Please try again.')
            finish(succeeded=False)
            return
        for person in people:
            name = person.get('name', 'Unknown')
            person_id = person.get('id', '')
            known_for = person.get('known_for', [])
            known_for_titles = ', '.join(
                item.get('title') or item.get('name') or '' 
                for item in known_for[:3]
            ) if known_for else ''
            label = name + (f' ({known_for_titles})' if known_for_titles else '')
            info = {'title': name, 'plot': f'Known for: {known_for_titles}' if known_for_titles else ''}
            thumb = tmdb._img(person.get('profile_path'), 'w185')
            item(label, 'vidcore_person_credits', info=info, thumb=thumb,
                 person_id=person_id, person_name=name)
        if page < min(total_pages, 500):
            item('Next Page', 'vidcore_people', page=page + 1)
        finish('actors')
        return

    if action == 'vidcore_person_credits':
        person_id = params.get('person_id', '')
        person_name = params.get('person_name', 'Unknown')
        if not person_id:
            finish(succeeded=False)
            return
        credits = tmdb.get_person_credits(person_id)
        cast_items = [row for row in credits.get('cast', [])
                      if _catalogue_title_allowed(row)]
        cast_items = tmdb.fill_missing_synopses(cast_items)
        if not cast_items:
            xbmcgui.Dialog().notification('Vidcore', f'No credits found for {person_name}.')
            finish(succeeded=True)
            return
        for item_data in cast_items:
            if not item_data.get('id'):
                continue
            title = item_data.get('title') or item_data.get('name') or 'Untitled'
            date = item_data.get('release_date') or item_data.get('first_air_date') or ''
            year = date[:4] if date else ''
            label = title + (f' ({year})' if year else '')
            character = item_data.get('character', '')
            plot = item_data.get('overview') or (f'as {character}' if character else '')
            media_type = 'movie' if item_data.get('media_type') == 'movie' else 'tvshow'
            kind = 'movie' if item_data.get('media_type') == 'movie' else 'tv'
            info = {'title': title, 'plot': plot, 'mediatype': media_type}
            thumb = tmdb._img(item_data.get('poster_path'))
            item(label, 'vidcore_seasons' if kind == 'tv' else 'vidcore_sources',
                 info=info, thumb=thumb, folder=kind == 'tv', kind=kind,
                 tmdb_id=item_data['id'])
        finish('movies')
        return

    if action in ('vidcore_list', 'vidcore_search'):
        query = params.get('query', '').strip()
        if action == 'vidcore_search' and not query:
            # Kodi may rerun the original directory URL after playback or Back.
            # Store the query against that search's URL token, not a global
            # last-query value which would mix separate searches or media types.
            window = xbmcgui.Window(10000)
            key = 'Vidcore.SearchSessions'
            try:
                sessions = json.loads(window.getProperty(key) or '{}')
                if not isinstance(sessions, dict):
                    sessions = {}
            except (ValueError, TypeError):
                sessions = {}
            session = kind + ':' + params.get('search_id', 'legacy')
            query = sessions.get(session, '')
            if not query:
                query = xbmcgui.Dialog().input('Search Vidcore — Movies' if kind == 'movie'
                                              else 'Search Vidcore — TV Shows').strip()
                if query:
                    sessions[session] = query
                    while len(sessions) > 50:
                        del sessions[next(iter(sessions))]
                    window.setProperty(key, json.dumps(sessions))
            if not query:
                finish(succeeded=False)
                return
            # Continue directly into the result request after the dialog.
            # Redirecting the container here can discard the newly entered
            # query on Kodi builds that reuse the old plugin URL.
            action = 'vidcore_list'
        try:
            page = max(1, min(500, int(params.get('page', 1))))
        except (TypeError, ValueError):
            page = 1
        category = params.get('category', 'popular')
        if query and page == 1:
            try:
                search_history.remember(query, kind)
            except OSError:
                xbmc.log('VIDCORE: unable to save search history', xbmc.LOGWARNING)
        allowed_categories = ('popular', 'top_rated', 'now_playing', 'upcoming') if kind == 'movie' else ('popular', 'top_rated', 'on_the_air', 'airing_today')
        if category not in allowed_categories:
            category = 'popular'
        endpoint = 'search/' + kind if query else kind + '/' + category
        arguments = {'api_key': tmdb._api_key(), 'page': page,
                     'language': 'en-US', 'include_adult': 'false'}
        if query:
            arguments['query'] = query
        provider_id = str(params.get('provider_id') or '')
        region = str(params.get('watch_region') or '').upper()
        if provider_id and not query:
            if not provider_id.isascii() or not provider_id.isdigit() or int(provider_id) < 1:
                finish(succeeded=False)
                return
            region = region if re.fullmatch(r'[A-Z]{2}', region) else tmdb.watch_region()
            endpoint = 'discover/' + kind
            arguments.update({'with_watch_providers': provider_id,
                              'watch_region': region,
                              'with_watch_monetization_types': 'flatrate|free|ads',
                              'sort_by': 'popularity.desc'})
        data = tmdb._fetch('https://api.themoviedb.org/3/' + endpoint + '?' + urlencode(arguments))
        if not isinstance(data, dict):
            xbmcgui.Dialog().notification('Vidcore', 'Unable to load TMDB titles. Please try again.')
            finish(succeeded=False)
            return
        results = [row for row in data.get('results') or []
                   if _catalogue_title_allowed(row)]
        results = tmdb.fill_missing_synopses(results, kind)
        for row in results:
            if not row.get('id'):
                continue
            title = row.get('title') or row.get('name') or 'Untitled'
            date = row.get('release_date') or row.get('first_air_date') or ''
            label = title + (' (%s)' % date[:4] if date else '')
            info = {'title': title, 'plot': row.get('overview') or '',
                    'mediatype': 'movie' if kind == 'movie' else 'tvshow'}
            item(label, 'vidcore_seasons' if kind == 'tv' else 'vidcore_sources',
                 info=info, thumb=tmdb._img(row.get('poster_path')),
                 folder=kind == 'tv', kind=kind, tmdb_id=row['id'])
        if not results:
            xbmcgui.Dialog().notification('Vidcore', 'No matching titles on this page.')
        if page < min(int(data.get('total_pages') or 0), 500):
            item('Next Page', action, kind=kind, category=category, query=query, page=page + 1,
                 provider_id=provider_id, watch_region=region)
        finish('movies' if kind == 'movie' else 'tvshows')
        return

    tmdb_id = str(params.get('tmdb_id', ''))
    if not tmdb_id.isdigit():
        finish(succeeded=False)
        return
    if action == 'vidcore_seasons':
        today = calendar_date.today()
        for season in tmdb.get_tv_seasons(tmdb_id):
            if not _has_aired(season, today):
                # Specials and older seasons sometimes lack a season date.
                # Keep them only when they contain a confirmed aired episode.
                if season.get('air_date') or not any(
                        _has_aired(episode, today) for episode in
                        tmdb.get_tv_episodes(tmdb_id, season['number'])):
                    continue
            item(season['name'], 'vidcore_episodes',
                 info={'title': season['name'], 'plot': season['overview'],
                       'mediatype': 'season', 'season': season['number']},
                 thumb=season['poster'], kind='tv', tmdb_id=tmdb_id,
                 season=season['number'])
        finish('seasons')
        return
    if action == 'vidcore_sources':
        season, episode = 0, 0
        try:
            season = max(0, int(params.get('season', 0)))
            episode = max(0, int(params.get('episode', 0)))
        except (TypeError, ValueError):
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
            return
        import threading
        from .source_cache import SourceCache
        source_cache = SourceCache((kind, tmdb_id, season, episode))
        def load_picker_details():
            try:
                _PICKER_DETAILS[(kind, tmdb_id)] = tmdb.get_metadata(
                    tmdb_id, 'movie' if kind == 'movie' else 'tvshow') or {}
            except Exception:
                pass
        threading.Thread(target=load_picker_details, name='vidcore-picker-metadata', daemon=True).start()
        live_choice = []
        from . import shared_requests
        from .vidcore_scan_dialog import create_progress
        discovery_jobs = [('Vidrock', lambda: _vidrock_sources(kind, tmdb_id, season, episode))]
        if kind == 'movie' or episode > 0:
            for embed_provider in rivestream.EMBED_PROVIDERS:
                discovery_jobs.append(('RiveEmbed:' + embed_provider,
                    lambda embed_provider=embed_provider: rivestream.discover_embeds(
                        embed_provider, tmdb_id, kind, season, episode)))
            discovery_jobs.extend([
                ('HydraHD', lambda: hydrahd.discover(tmdb_id, kind, season, episode)),
                ('Dulo', lambda: dulo.discover(tmdb_id, kind, season, episode))])
        if kind == 'tv' and episode > 0:
            discovery_jobs.append(('SRStop', lambda: srstop.discover_hosts(
                tmdb.get_metadata(tmdb_id, 'tv') or {}, season, episode)))
        progress = create_progress()
        discovered = source_cache.discovery() or {}
        discovery_lookups = dict(discovery_jobs)
        fresh_discovery = {}
        discovery_lock = threading.Lock()
        discovery_stopped = threading.Event()

        def lookup(name):
            if name in discovered:
                return discovered[name]
            def read():
                value = discovery_lookups[name]()
                if value is not None:
                    with discovery_lock:
                        if not discovery_stopped.is_set():
                            fresh_discovery[name] = value
                return value
            return shared_requests.fetch(
                ('picker-discovery', name, kind, tmdb_id, season, episode),
                read, ttl=10, timeout=30)

        try:
            adrock_sources = lambda: lookup('Vidrock') or []
            rive_embeds = {provider: (lambda provider=provider: lookup('RiveEmbed:' + provider) or [])
                           for provider in rivestream.EMBED_PROVIDERS}
            sources = [(name, '', 'hls') for name in ('Nova', 'Atlas', 'Astra')]
            sources.append(('AdRock', '', 'hosts'))
            vidrock_mappings = [_safe_source_name(source[0]) for source in discovered.get('Vidrock', [])]
            embed = vidnest.embed_url(tmdb_id, kind, season, episode)
            if embed:
                sources.append(('VidNest', embed, 'hls'))
            embed = vidbolt.embed_url(tmdb_id, kind, season, episode)
            if embed:
                sources.append(('VidBolt', embed, 'hls'))
            embed = vidlove.embed_url(tmdb_id, kind, season, episode)
            if embed:
                sources.append(('VidLove', embed, 'hls'))
            embed = twoembed.embed_url(tmdb_id, kind, season, episode)
            if embed:
                sources.append(('2Embed', embed, 'hls'))
            embed = cinetaro.embed_url(tmdb_id, kind, season, episode)
            if embed:
                sources.append(('Nest', embed, 'hls'))
            if kind == 'movie' or episode > 0:
                sources.append(('Jupiter', '', 'hls'))
                sources.append(('HDHub', '', 'api'))
                sources.append(('Cinejoy', '', 'hosts'))
                sources.append(('RiveStream', '', 'hosts'))
                sources.append(('MovieUniverse', '', 'hosts'))
            hydrahd_servers = lambda: lookup('HydraHD') or []
            sources.append(('HydraHD', '', 'hosts'))
            dulo_servers = lambda: lookup('Dulo') or []
            sources.append(('Dulo', '', 'hosts'))
            srstop_hosts = {}
            if kind == 'tv' and episode > 0:
                srstop_hosts = lambda: lookup('SRStop') or {}
                sources.append(('SRStop', '', 'hosts'))
            _debug_bundle_event(
                'SOURCE MAP',
                f'{_media_context(kind, tmdb_id, season, episode)} '
                f'mapped=Nova,Atlas,Astra(Vidrock); AdRock(Vidrock:{",".join(vidrock_mappings) or "none"}); '
                'VidNest; VidBolt(Gaiaflix movie/TV); VidLove; Nest(Cinetaro); Dulo(movie/TV servers); HydraHD(movie/TV servers); '
                'Jupiter(Movy Phoenix); HDHub(CineWave); Cinejoy(Nebula,Lisbon,Athens); RiveStream(%s); MovieUniverse(VSrcH movie/TV servers); SaveFiles, LuluStream, Streamtape, DoodStream, Byse and VOE via SRStop (TV only)' % ','.join(rivestream.SERVERS),
            )
            def show_ready(filtered, snapshot):
                progress.close()
                live_sources, live_checked, live_groups, live_hosts = filtered()
                live_choice.append(_pick_provider(
                    live_sources, kind, tmdb_id, season, episode, live_hosts,
                    source_groups=live_groups, checked_sources=live_checked,
                    live_availability=filtered, scan_state=snapshot))
            availability = _check_picker_sources(
                sources, kind, tmdb_id, season, episode, dulo_servers, srstop_hosts,
                adrock_sources=adrock_sources, hydrahd_servers=hydrahd_servers,
                progress=progress, on_ready=show_ready, source_cache=source_cache,
                rive_embeds=rive_embeds)
        finally:
            with discovery_lock:
                discovery_stopped.set()
                finished_discovery = dict(fresh_discovery)
            if finished_discovery:
                source_cache.save_discovery(finished_discovery)
            progress.close()
        if availability is None:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
            return
        sources, checked_sources, checked_groups, checked_hosts = availability
        source_list = ','.join(
            '%s:%s' % (_safe_source_name(name), _safe_source_name(source_type))
            for name, _stream, source_type in sources) or 'none'
        _debug_bundle_event(
            'SOURCES',
            f'{_media_context(kind, tmdb_id, season, episode)} '
            f'available={source_list}',
        )
        if not sources:
            xbmcgui.Dialog().notification('Vidcore', 'No playback providers are available.')
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
            return
        choice = live_choice[0] if live_choice else _pick_provider(
            sources, kind, tmdb_id, season, episode, checked_hosts,
            source_groups=checked_groups, checked_sources=checked_sources)
        if choice is None:
            _debug_bundle_event('SOURCE',
                                f'{_media_context(kind, tmdb_id, season, episode)} selection cancelled')
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
            return
        provider, stream, source_type = choice
        _debug_bundle_event('SOURCE',
                            f'{_media_context(kind, tmdb_id, season, episode)} '
                            f'selected={_safe_source_name(provider)}')
        if provider in checked_hosts and provider in SRSTOP_RESOLVERS:
            resolved = checked_sources[('SRStop', provider)]
        elif provider in checked_groups:
            resolved = checked_sources[stream]
        else:
            resolved = checked_sources[provider]
        from .vidcore_availability import selected_source
        resolved = selected_source(resolved, provider, stream)
        if not resolved:
            xbmcgui.Dialog().notification('Vidcore', 'This source expired or is unavailable. Reopen sources to choose another stream.')
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
            return
        _debug_bundle_event('RESOLVE', '%s provider=%s result=playable type=%s' % (
            _media_context(kind, tmdb_id, season, episode), _safe_source_name(provider),
            _safe_source_name(resolved['type'])))
        _play_tracked_stream(
            handle, resolved['url'], resolved['type'], provider,
            stream_headers=resolved.get('headers'), refresh_source=stream,
            proxy_opener=resolved.get('opener'),
            proxy_refresh_tokens=resolved.get('refresh_tokens', False),
            native_hls=resolved.get('native_hls', False),
            refresh_backend=resolved.get('vidbolt_backend', ''),
            rivestream_refresh=resolved.get('rivestream_refresh'))
        return
    if action == 'vidcore_episodes':
        try:
            season = max(0, int(params.get('season', 0)))
        except (TypeError, ValueError):
            finish(succeeded=False)
            return
        today = calendar_date.today()
        episodes = [episode for episode in tmdb.get_tv_episodes(tmdb_id, season)
                    if _has_aired(episode, today)]
        page_size = 50
        page_count = max(1, (len(episodes) + page_size - 1) // page_size)
        try:
            page = max(1, min(page_count, int(params.get('page', 1))))
        except (TypeError, ValueError):
            page = 1
        start = (page - 1) * page_size
        if page > 1:
            item('Previous Page (%d/%d)' % (page - 1, page_count),
                 'vidcore_episodes', kind='tv', tmdb_id=tmdb_id,
                 season=season, page=page - 1)
        for episode in episodes[start:start + page_size]:
            item('%02d. %s' % (episode['number'], episode['name']), 'vidcore_sources',
                 info={'title': episode['name'], 'plot': episode['overview'],
                       'mediatype': 'episode', 'season': season,
                       'episode': episode['number'], 'duration': episode['runtime']},
                 thumb=episode['still'], folder=False, kind='tv', tmdb_id=tmdb_id,
                 season=season, episode=episode['number'])
        if page < page_count:
            item('Next Page (%d/%d)' % (page + 1, page_count),
                 'vidcore_episodes', kind='tv', tmdb_id=tmdb_id,
                 season=season, page=page + 1)
        finish('episodes')
        return
    finish(succeeded=False)
