"""Resolve SRStop VOE episode links without executing player scripts."""
import base64
import codecs
import json
import re
import time
from html import unescape
from http.cookiejar import CookieJar
from urllib.parse import urljoin, urlsplit
from urllib.request import Request, build_opener, HTTPCookieProcessor

from . import srstop

HOSTS = frozenset(('voe.sx', 'jeremyparticipantanything.com',
                   'teresapoliticallearn.com', 'shannoncoldalready.com',
                   'susanexpectcare.com'))
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36'


def is_url(url):
    parts = urlsplit(str(url or ''))
    host = (parts.hostname or '').lower()
    host = host[4:] if host.startswith('www.') else host
    return bool(parts.scheme in ('http', 'https') and not parts.username
                and host in HOSTS
                and re.fullmatch(r'/(?:e/)?[A-Za-z0-9]+/?', parts.path))


def _b64(value):
    return base64.b64decode(value + '=' * (-len(value) % 4)).decode('utf-8')


def _decode(value, tokens):
    value = codecs.decode(value, 'rot_13')
    for token in tokens:
        value = value.replace(token, '')
    value = ''.join(chr(ord(char) - 3) for char in _b64(value))
    return json.loads(_b64(value[::-1]))


def _sources(body, page, fetch):
    found = []
    # Current player encodes a JSON source object and supplies removal
    # tokens in its adjacent script. Decode data only, never evaluate JS.
    encoded = re.search(r'<script\b[^>]*type=["\']application/json["\'][^>]*>\s*(\[.*?\])\s*</script>\s*<script\b[^>]*src=["\']([^"\']+)', body, re.S | re.I)
    if encoded:
        values = json.loads(encoded[1])
        script = fetch(urljoin(page, unescape(encoded[2])), page)[0]
        table = re.search(r"\[(?:'[^\w\s]{2}'\s*,?\s*){1,9}\]", script)
        if values and isinstance(values[0], str) and table:
            data = _decode(values[0], re.findall(r"'([^']+)'", table[0]))
            if isinstance(data, dict):
                found.extend(data.get(key) for key in ('file', 'source', 'direct_access_url'))
    # Older players expose HLS/MP4 as plain URLs or base64 strings.
    for match in re.finditer(r'''["'](?:hls|mp4)["']\s*:\s*["']([^"']+)["']''', body):
        value = unescape(match[1]).replace('\\/', '/')
        if not value.startswith(('http://', 'https://')):
            try:
                value = _b64(value)
            except (ValueError, UnicodeError):
                continue
        found.append(value)
    urls = list(dict.fromkeys(value for value in found if isinstance(value, str)
                             and urlsplit(value).scheme in ('http', 'https')
                             and urlsplit(value).netloc))
    return sorted(urls, key=lambda url: '.m3u8' not in urlsplit(url).path.lower())


def _resolve_host_page(url):
    if not is_url(url):
        return None
    deadline = time.monotonic() + 40
    jar = CookieJar()
    opener = build_opener(HTTPCookieProcessor(jar))

    def fetch(target, referer):
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise srstop.SourceError('VOE resolution timed out. Try another host.')
        with opener.open(Request(target, headers={'User-Agent': UA, 'Referer': referer}),
                         timeout=min(12, remaining)) as response:
            body = response.read(2 * 1024 * 1024 + 1)
            final = response.geturl()
        if len(body) > 2 * 1024 * 1024:
            raise srstop.SourceError('VOE returned an oversized player response.')
        return body.decode('utf-8', 'replace'), final

    page = url
    visited = set()
    for _ in range(4):
        if page in visited:
            break
        visited.add(page)
        body, page = fetch(page, srstop.BASE + '/')
        redirect = re.search(r'''window\.location\.href\s*=\s*["']([^"']+)["']''', body)
        if redirect and 'currentUrl' in body:
            target = urljoin(page, unescape(redirect[1]))
            if not is_url(target):
                raise srstop.SourceError('VOE redirected to an unsupported player domain.')
            page = target
            continue
        for media in _sources(body, page, fetch):
            headers = {'User-Agent': UA, 'Referer': page}
            request = Request(media)
            jar.add_cookie_header(request)
            if request.get_header('Cookie'):
                headers['Cookie'] = request.get_header('Cookie')
            stream = {'url': media, 'type': 'hls' if '.m3u8' in urlsplit(media).path.lower() else 'mp4',
                      'headers': headers}
            from .vidcore_availability import check_stream
            checked = check_stream(stream)
            if checked:
                return checked
        break
    return None


def resolve(tmdb_id, season, episode):
    from . import tmdb
    try:
        links = srstop.discover_voe(tmdb.get_metadata(tmdb_id, 'tv'), season, episode)
        for link in links:
            try:
                stream = _resolve_host_page(link['url'])
                if stream:
                    return stream
            except Exception:
                continue
        return {'error': 'No VOE source passed the playback check. Choose another host.'}
    except srstop.SourceError as exc:
        return {'error': str(exc)}
    except Exception:
        return {'error': 'SRStop / VOE could not resolve this episode. Please try again.'}
