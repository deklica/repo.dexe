"""Vidcore always uses its bundled dialogs."""


def use_native_dialogs():
    # Ignore legacy saved preferences after removal of the native-dialog option.
    return False
