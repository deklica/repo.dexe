"""Clear only Vidcore-owned caches, completing independent cleanup steps."""
import os
import shutil
import sqlite3


def clear():
    import xbmcgui
    import xbmcvfs
    from . import tmdb, srstop, shared_requests, fanarttv, metadata_cache

    failures = []

    def attempt(label, operation):
        try:
            operation()
        except (OSError, sqlite3.Error, ValueError, RuntimeError):
            failures.append(label)

    # Validate disk scope before any deletion. A rejected path must not stop
    # safe cleanup of Vidcore's independent in-memory caches.
    try:
        profile = os.path.realpath(xbmcvfs.translatePath(
            'special://profile/addon_data/plugin.video.vidcore/'))
        target = os.path.join(profile, 'metadata_cache')
        resolved = os.path.realpath(target)
        if os.path.commonpath((profile, resolved)) != profile or resolved == profile:
            raise OSError('Cache path is outside the Vidcore profile')
    except (OSError, ValueError, RuntimeError):
        failures.append('private disk cache (unsafe or unavailable path)')
    else:
        attempt('metadata/source database', lambda: metadata_cache.clear(target))

        def remove_legacy(name):
            old = os.path.join(target, name)
            if os.path.islink(old):
                os.unlink(old)
            elif os.path.isdir(old):
                if os.path.commonpath((profile, os.path.realpath(old))) != profile:
                    raise OSError('Artwork cache path is outside the Vidcore profile')
                shutil.rmtree(old)
            elif os.path.exists(old):
                os.remove(old)

        # Retain the database generation marker used to reject old writers.
        for name in ('metadata.json', 'metadata.json.tmp', 'art'):
            attempt('legacy ' + name, lambda name=name: remove_legacy(name))

    attempt('shared request memory', shared_requests.clear)
    attempt('metadata memory', tmdb._SESSION_META_CACHE.clear)
    attempt('TVDB ID memory', tmdb._TVDB_ID_CACHE.clear)
    attempt('artwork health', lambda: tmdb._TMDB_ART_HEALTH.update({'checked': 0.0, 'ok': True}))
    attempt('Fanart memory', fanarttv.clear_cache)
    attempt('source page memory', srstop.clear_cache)
    attempt('country detection', lambda: xbmcgui.Window(10000).clearProperty('Vidcore.WatchRegion'))

    if failures:
        raise OSError('Could not clear: ' + ', '.join(failures))
