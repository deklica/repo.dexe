"""Vidcore's release browser, using the local changelog as its only source."""
import os
import re

import xbmcgui


def parse_releases(text):
    releases = []
    current = None
    for line in text.splitlines():
        match = re.fullmatch(r'(\d+(?:\.\d+)+)\s*-\s*(\d{4}-\d{2}-\d{2})', line.strip())
        if match:
            current = {'version': match[1], 'date': match[2], 'lines': []}
            releases.append(current)
        elif current is not None:
            current['lines'].append(line)
    for release in releases:
        release['body'] = '\n'.join(release.pop('lines')).strip() or 'No changes recorded.'
    return releases or [{'version': 'Changelog', 'date': '',
                         'body': text.strip() or 'No changes recorded yet.'}]


def format_notes(body):
    """Unwrap source-file continuations and distinguish section headings."""
    paragraphs = []
    for block in re.split(r'\n\s*\n', body.strip()):
        text = ' '.join(line.strip() for line in block.splitlines())
        if text and text.isupper() and not text.startswith('-'):
            text = '[B][COLOR FF70E0CE]' + text + '[/COLOR][/B]'
        paragraphs.append(text)
    return '\n\n'.join(paragraphs)


class ChangelogDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.releases = kwargs.pop('releases')
        self.index = -1
        super().__init__(*args, **kwargs)

    def onInit(self):
        self.index = -1
        listing = self.getControl(5100)
        listing.reset()
        items = []
        for index, release in enumerate(self.releases):
            item = xbmcgui.ListItem(label=release['version'])
            item.setProperty('date', release['date'])
            item.setProperty('badge', 'LATEST' if index == 0 else '')
            items.append(item)
        listing.addItems(items)
        listing.selectItem(0)
        self.refresh()
        self.setFocusId(5100)
        self._navigation_hint(5100)

    def refresh(self):
        index = self.getControl(5100).getSelectedPosition()
        if not 0 <= index < len(self.releases) or index == self.index:
            return
        self.index = index
        release = self.releases[index]
        self.setProperty('vc_release', 'Version ' + release['version'])
        self.setProperty('vc_date', release['date'])
        self.setProperty('vc_count', '%d / %d releases' % (index + 1, len(self.releases)))
        self.getControl(5101).setText(format_notes(release['body']))
        self.getControl(5101).scroll(0)

    def onAction(self, action):
        if action.getId() in (9, 10, 92, 216):
            self.close()
        else:
            self.refresh()

    def onFocus(self, control_id):
        self.refresh()
        self._navigation_hint(control_id)

    def _navigation_hint(self, control_id):
        if control_id == 5104:
            hint = 'Up/Down: scroll   Left: releases   Right: Close'
        elif control_id == 5102:
            hint = 'OK: close   Left/Up: notes   Down: releases'
        else:
            hint = 'Up/Down: releases   Right: notes   Back: close'
        self.setProperty('vc_navigation', hint)

    def onClick(self, control_id):
        if control_id == 5102:
            self.close()
        elif control_id == 5103:
            # Mouse paging changes selection without clicking the release list.
            self.refresh()
        elif control_id == 5100:
            self.refresh()
            self.setFocusId(5104)
            self._navigation_hint(5104)


def show(addon_path):
    try:
        with open(os.path.join(addon_path, 'changelog.txt'), encoding='utf-8-sig') as source:
            text = source.read()
    except (OSError, UnicodeError):
        text = 'Unable to read changelog.txt from the Vidcore addon folder.'
    from .skin_support import use_native_dialogs
    if use_native_dialogs():
        xbmcgui.Dialog().textviewer('Vidcore Changelog', text)
        return
    dialog = ChangelogDialog('VidCoreChangelog.xml', addon_path, 'Default', '720p',
                             releases=parse_releases(text))
    try:
        dialog.doModal()
    finally:
        del dialog
