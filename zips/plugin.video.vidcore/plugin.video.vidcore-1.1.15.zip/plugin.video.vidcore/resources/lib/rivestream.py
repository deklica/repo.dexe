"""RiveStream's public movie/episode source API."""
import json
from urllib.parse import parse_qs, parse_qsl, urlencode, urlsplit
from urllib.request import Request, urlopen

API = 'https://scrapper.rivestream.app/api/provider'
SERVERS = ('mirage', 'apogee', 'vanguard', 'abyss', 'pulse', 'citadel')
EMBED_PROVIDERS = ('self', 'prime')
EMBED_HOSTS = frozenset(('streamtape.com', 'streamtape.to', 'streamtape.net',
                         'bysesukior.com', 'bysesayeveum.com', 'bysewihe.com',
                         'bysekoze.com', 'byseraguci.com'))
HEADERS = {'User-Agent': 'Mozilla/5.0', 'Accept': 'application/json',
           'Referer': 'https://www.rivestream.app/',
           'Origin': 'https://www.rivestream.app'}


def _http_url(value):
    if not isinstance(value, str) or any(ord(c) < 33 for c in value):
        return False
    try:
        parts = urlsplit(value)
        return (parts.scheme in ('https', 'http') and bool(parts.hostname)
                and not parts.username and not parts.password)
    except ValueError:
        return False


def source(row):
    """Use the original media and headers supplied in Rive's proxy wrapper."""
    if not isinstance(row, dict):
        return None
    url = row.get('url')
    if not _http_url(url):
        return None
    headers = row.get('headers') or {}
    if not isinstance(headers, dict):
        return None
    parts = urlsplit(url)
    if parts.hostname == 'proxy.valhallastream.com' and parts.path == '/m3u8':
        query = parse_qs(parts.query)
        url = query.get('url', [''])[0]
        try:
            supplied = json.loads(query.get('headers', ['{}'])[0])
        except (ValueError, TypeError):
            return None
        if not isinstance(supplied, dict):
            return None
        headers = dict(headers, **supplied)
    if not _http_url(url):
        return None
    if any(not isinstance(k, str) or not isinstance(v, str)
           or '\r' in k + v or '\n' in k + v for k, v in headers.items()):
        return None
    return {'url': url, 'type': 'mp4' if row.get('format') == 'mp4' else 'hls',
            'headers': dict({'User-Agent': HEADERS['User-Agent']}, **headers)}


def resolve_server(server, tmdb_id, kind='movie', season=0, episode=0):
    """Return verified media, trying alternate sources from the same server."""
    identifier = str(tmdb_id)
    if (server not in SERVERS or kind not in ('movie', 'tv')
            or not identifier.isascii() or not identifier.isdigit()
            or int(identifier) < 1):
        return None
    query = {'provider': server, 'id': identifier}
    try:
        if server == 'abyss':
            from . import abyss
            return abyss.resolve(tmdb_id, kind, season, episode)
        if kind == 'tv':
            season, episode = int(season), int(episode)
            if season < 0 or episode < 1:
                return None
            query.update(season=season, episode=episode)
        with urlopen(Request(API + '?' + urlencode(query), headers=HEADERS),
                     timeout=12) as response:
            raw = response.read(2 * 1024 * 1024 + 1)
        if len(raw) > 2 * 1024 * 1024:
            return None
        data = json.loads(raw)
        payload = data.get('data') if isinstance(data, dict) else None
        rows = payload.get('sources') if isinstance(payload, dict) else None
        if not isinstance(rows, list):
            return None
        from .vidcore_availability import check_stream
        for row in rows[:8]:
            result = source(row)
            if result:
                result['rivestream_refresh'] = dict(server=server, tmdb_id=identifier,
                    kind=kind, season=season, episode=episode)
                checked = check_stream(result)
                if checked:
                    return checked
        return None
    except Exception:
        return None


def embed_rows(data, provider):
    """Keep known resolvable file hosts, never HTML players as media URLs."""
    payload = data.get('data') if isinstance(data, dict) else None
    rows = payload.get('sources') if isinstance(payload, dict) else None
    if provider not in EMBED_PROVIDERS or not isinstance(rows, list):
        return []
    result, seen = [], set()
    for row in rows:
        url = row.get('link') if isinstance(row, dict) else None
        if not _http_url(url) or url in seen:
            continue
        host = urlsplit(url).hostname or ''
        host = host[4:] if host.startswith('www.') else host
        if host not in EMBED_HOSTS:
            continue
        label = str(row.get('host') or host)
        label = ''.join(c for c in label if c.isalnum() or c in ' ._-')[:70]
        result.append({'url': url, 'label': '%s embed / %s' % (provider.title(), label)})
        seen.add(url)
        if len(result) >= 12:
            break
    return result


def discover_embeds(provider, tmdb_id, kind='movie', season=0, episode=0):
    identifier = str(tmdb_id)
    if (provider not in EMBED_PROVIDERS or kind not in ('movie', 'tv')
            or not identifier.isascii() or not identifier.isdigit() or int(identifier) < 1):
        return []
    query = {'provider': provider, 'id': identifier}
    try:
        if kind == 'tv':
            season, episode = int(season), int(episode)
            if season < 0 or episode < 1:
                return []
            query.update(season=season, episode=episode)
        endpoint = API.rsplit('/', 1)[0] + '/embed?' + urlencode(query)
        with urlopen(Request(endpoint, headers=HEADERS), timeout=8) as response:
            raw = response.read(2 * 1024 * 1024 + 1)
        return embed_rows(json.loads(raw), provider) if len(raw) <= 2 * 1024 * 1024 else []
    except Exception:
        return []


def resolve_embed(url):
    if not _http_url(url):
        return None
    host = urlsplit(url).hostname or ''
    host = host[4:] if host.startswith('www.') else host
    if host not in EMBED_HOSTS:
        return None
    from . import provider_resolvers
    try:
        media = (provider_resolvers.resolve_streamtape(url) if host.startswith('streamtape.')
                 else provider_resolvers.resolve_bysesukior(url))
        if not isinstance(media, str):
            return None
        media, _, encoded_headers = media.partition('|')
        if not _http_url(media):
            return None
        return {'url': media, 'headers': dict(parse_qsl(encoded_headers)),
                'type': 'hls' if '.m3u8' in urlsplit(media).path.lower() else 'mp4'}
    except Exception:
        return None
