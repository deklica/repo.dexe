"""Cinetaro Primus API client for the Vidcore source picker."""
import json
import base64
import hashlib
import socket
from urllib.parse import urlencode
from urllib.request import Request, urlopen

import xbmc


BASE_URL = 'https://cinetaro.to/src/player/sub.php'
API_URL = 'https://cinextream.cc/api/proxy'
HEADERS = {'User-Agent': 'Mozilla/5.0', 'Referer': 'https://cinextream.cc/'}


def embed_url(tmdb_id, content='movie', season=None, episode=None):
    """Return the Cinetaro wrapper route used by its Primus server."""
    tmdb_id = str(tmdb_id or '').strip()
    if not tmdb_id.isdigit() or int(tmdb_id) < 1:
        return ''
    if content == 'movie':
        episode_id = tmdb_id + '-movie'
        episode_number = 1
    else:
        try:
            season, episode_number = int(season), int(episode)
        except (TypeError, ValueError):
            return ''
        if season < 0 or episode_number < 1:
            return ''
        episode_id = '%s-%s-%s' % (tmdb_id, season, episode_number)
    query = {
        'id': episode_id,
        'server': 'maple',
        'embed': 'true',
        'ep': episode_number,
        'skip': 'true',
        'autoPlay': '1',
        'asi': '1',
    }
    return BASE_URL + '?' + urlencode(query)


def api_url(tmdb_id, content='movie', season=None, episode=None, server='Nest'):
    """Build the direct Cinetaro/Nest stream API route."""
    params = {'server': server, 'tmdb': str(tmdb_id),
              'type': 'movie' if content == 'movie' else 'series'}
    if content != 'movie':
        params.update(season=season, episode=episode)
    return API_URL + '?' + urlencode(params)


def _urls(value, headers=None):
    if isinstance(value, str):
        if value.startswith(('http://', 'https://')):
            yield value, dict(headers or {})
    elif isinstance(value, dict):
        own_headers = value.get('headers') if isinstance(value.get('headers'), dict) else headers
        for key, item in value.items():
            if key == 'headers':
                continue
            yield from _urls(item, own_headers)
    elif isinstance(value, list):
        for item in value:
            yield from _urls(item, headers)


def _decode_response(data, tmdb_id):
    """Equivalent of the player's normalizeBuffer response decoder."""
    if not isinstance(data, dict) or 'enc' not in data:
        return data
    key = hashlib.sha256((str(tmdb_id) +
                          'c1n3t4r-0bf5c4t10n-s4lt-v1-2024-09').encode('utf-8')).digest()
    encoded = base64.b64decode(data['enc'], validate=True)
    decoded = bytes(value ^ key[i % 32] ^ ((i * 7 + 13) & 255)
                    for i, value in enumerate(encoded))
    return json.loads(decoded.decode('utf-8'))


def resolve(tmdb_id, content='movie', season=None, episode=None, server='Nest'):
    """Fetch and verify an HLS URL returned by a Cinetaro backend."""
    if server != 'Nest' or not embed_url(tmdb_id, content, season, episode):
        return None
    for server in (server,):
        endpoint = api_url(tmdb_id, content, season, episode, server)
        try:
            request = Request(endpoint, headers=HEADERS)
            with urlopen(request, timeout=15) as response:
                raw = response.read().decode('utf-8', errors='replace')
            data = _decode_response(json.loads(raw), tmdb_id)
            xbmc.log('VIDCORE %s API returned %d bytes' % (server, len(raw)), xbmc.LOGINFO)
            if not isinstance(data, dict):
                raise ValueError('Unexpected decoded API response')
            # Nest's top-level source is an embed, not a media URL.
            candidates = list(_urls(data.get('data') or {}, HEADERS))
            seen = set()
            for candidate, source_headers in candidates:
                if candidate in seen:
                    continue
                seen.add(candidate)
                # The backend may return a signed, extensionless playlist URL.
                # Probe the response instead of requiring a .m3u8 suffix.
                try:
                    probe_headers = dict(HEADERS)
                    probe_headers.update(source_headers or {})
                    probe = Request(candidate, headers=probe_headers)
                    with urlopen(probe, timeout=12) as response:
                        sample = response.read(4096)
                        final = response.geturl()
                        content_type = (response.headers.get('Content-Type') or '').lower()
                    if sample.lstrip().startswith(b'#EXTM3U') or 'mpegurl' in content_type:
                        xbmc.log('VIDCORE %s verified HLS playlist' % server, xbmc.LOGINFO)
                        return {'url': final, 'type': 'hls', 'headers': probe_headers}
                except Exception as exc:
                    if isinstance(getattr(exc, 'reason', None), socket.gaierror):
                        xbmc.log('VIDCORE %s media host DNS resolution failed' % server, xbmc.LOGWARNING)
                        return {'error': '%s returned a media host that cannot be resolved (DNS failure). '
                                         'Try another source.' % server}
                    xbmc.log('VIDCORE %s stream probe failed: %s status=%s' % (
                        server, type(exc).__name__, getattr(exc, 'code', '')), xbmc.LOGWARNING)
        except Exception as exc:
            xbmc.log('VIDCORE %s API failed: %s status=%s' % (
                server, type(exc).__name__, getattr(exc, 'code', '')), xbmc.LOGWARNING)
    xbmc.log('VIDCORE %s returned no verified media source' % server, xbmc.LOGWARNING)
    return None
