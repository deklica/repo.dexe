# -*- coding: utf-8 -*-
"""Built-in Streamtape, Byse and Vidara resolvers used by Vidcore.

Return a playable URL or None, with optional Kodi request headers.
"""
import re
import json
import base64
from html import unescape
from urllib.parse import urlparse, urlencode, parse_qs
from urllib.request import urlopen, Request
from urllib.error import HTTPError, URLError

import xbmc

from .aesgcm import aes_gcm_decrypt

# Debug bundler — optional; no-ops gracefully when disabled or not installed
try:
    from . import debug_bundle as _db
    def _dblog(tag, detail): _db.log(tag, detail)
except Exception:
    def _dblog(tag, detail): pass

UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
      '(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36')

# Streamtape callers use this to distinguish removed content from other failures.
_last_resolver_error = ''


def _post(url, data, referer=None, timeout=20, extra_headers=None):
    """POST form-data to *url*. *data* is a dict encoded as application/x-www-form-urlencoded."""
    from urllib.parse import urlencode as _urlencode
    headers = {
        'User-Agent': UA,
        'Accept': 'application/json, text/javascript, */*; q=0.01',
        'Accept-Language': 'en-US,en;q=0.9',
        'Content-Type': 'application/x-www-form-urlencoded',
        'X-Requested-With': 'XMLHttpRequest',
    }
    if referer:
        headers['Referer'] = referer
        p = urlparse(referer)
        if p.netloc:
            headers['Origin'] = f'{p.scheme}://{p.netloc}'
    if extra_headers:
        headers.update(extra_headers)
    post_data = _urlencode(data).encode('utf-8') if isinstance(data, dict) else data
    short_data = (data if isinstance(data, str) else str(data))[:120]
    _dblog('POST→', f'{url}  data={short_data}')
    try:
        req = Request(url, data=post_data, headers=headers)
        with urlopen(req, timeout=timeout) as r:
            body = r.read().decode('utf-8', errors='replace')
            _dblog('POST←', f'{len(body)}B  preview={body[:200]}')
            return body, r.url
    except (HTTPError, URLError) as e:
        xbmc.log(f'VIDCORE resolver POST failed {url}: {e}', xbmc.LOGWARNING)
        _dblog('POST-FAIL', f'{url}  error={e}')
        return '', url


def _fetch(url, referer=None, timeout=20, extra_headers=None):
    headers = {
        'User-Agent': UA,
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9',
    }
    if referer:
        headers['Referer'] = referer
    if extra_headers:
        headers.update(extra_headers)
    _dblog('GET→', url)
    try:
        req = Request(url, headers=headers)
        with urlopen(req, timeout=timeout) as r:
            body = r.read().decode('utf-8', errors='replace')
            _dblog('GET←', f'{len(body)}B  final={r.url}')
            return body, r.url
    except (HTTPError, URLError) as e:
        xbmc.log(f'VIDCORE resolver fetch failed {url}: {e}', xbmc.LOGWARNING)
        _dblog('GET-FAIL', f'{url}  error={e}')
        return '', url
    except Exception as e:
        xbmc.log(f'VIDCORE resolver fetch error {url}: {e}', xbmc.LOGERROR)
        _dblog('GET-ERR', f'{url}  error={e}')
        return '', url


# ── Packed JS unpacker (Dean Edwards p,a,c,k,e,d) ─────────────────────────
_PACKED_RE = re.compile(
    r"eval\(function\(p,a,c,k,e,(?:r|d)\)\{.*?\}\s*\('(.*?)',\s*(\d+)\s*,"
    r"\s*(\d+)\s*,\s*'(.*?)'\.split\('\|'\)",
    re.DOTALL,
)


def _unpack(packed_js):
    """Unpack a Dean Edwards p.a.c.k.e.r packed JS payload."""
    m = _PACKED_RE.search(packed_js)
    if not m:
        return ''
    payload, _radix, _count, symtab = m.groups()
    radix = int(_radix)
    count = int(_count)
    words = symtab.split('|')

    def _b(n):
        # base36+ encoder – mirrors the JS p,a,c,k,e,d encoder.
        digits = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
        if n == 0:
            return '0'
        r = []
        num = n
        while num:
            num, d = divmod(num, radix)
            r.append(digits[d])
        return ''.join(reversed(r))

    out = payload
    # Replace word tokens — must process longer first to avoid prefix collisions.
    for i in range(count - 1, -1, -1):
        sym = _b(i)
        if not sym:
            continue
        word = words[i] if i < len(words) else ''
        if word == '':
            continue
        out = re.sub(r'\b' + re.escape(sym) + r'\b', word, out)
    # Decode escapes
    out = out.replace('\\\\', '\\').replace("\\'", "'").replace('\\"', '"')
    return out


# ── Streamtape ────────────────────────────────────────────────────────────
def _is_streamtape(url):
    h = (urlparse(url).netloc or '').lower().replace('www.', '')
    return h.startswith('streamtape.') or h.startswith('streamta.pe') or \
        h.startswith('shavetape.') or h.startswith('strcloud.') or \
        h.startswith('strtape.') or h.startswith('streamadblocker.')


def _streamtape_expression(expression):
    """Decode only string concatenation and numeric substring/slice calls."""
    rest, chunks = expression.strip(), []
    while rest:
        wrapped = rest.startswith('(')
        if wrapped:
            rest = rest[1:].lstrip()
        match = re.match(r"""(["'])((?:\\.|(?!\1).)*)\1""", rest, re.S)
        if not match:
            return ''
        value = re.sub(r'\\([/\\\x27"])', r'\1', match[2])
        rest = rest[match.end():].lstrip()
        if wrapped:
            if not rest.startswith(')'):
                return ''
            rest = rest[1:].lstrip()
        while rest.startswith('.'):
            operation = re.match(r'\.(?:substring|slice)\(\s*(\d+)\s*\)', rest)
            if not operation:
                return ''
            value = value[int(operation[1]):]
            rest = rest[operation.end():].lstrip()
        chunks.append(value)
        if not rest:
            break
        if not rest.startswith('+'):
            return ''
        rest = rest[1:].lstrip()
        if not rest:
            return ''
    return unescape(''.join(chunks))


def _streamtape_media_url(body):
    # Later assignments replace earlier decoy values. Do not execute page JS.
    assignments = re.findall(
        r"""document\.getElementById\(\s*['"](?:robotlink|ideoolink|videolink|botlink)['"]\s*\)\.innerHTML\s*=\s*([^;]+);""",
        body)
    for expression in reversed(assignments):
        value = _streamtape_expression(expression)
        if value.startswith('//'):
            value = 'https:' + value
        parts = urlparse(value)
        if (parts.scheme in ('http', 'https') and _is_streamtape(value)
                and parts.path == '/get_video' and parse_qs(parts.query).get('id')
                and parse_qs(parts.query).get('token')):
            if 'stream' not in parse_qs(parts.query):
                value += '&stream=1'
            return value
    return None


def resolve_streamtape(url):
    global _last_resolver_error
    _last_resolver_error = ''
    parsed = urlparse(url)
    path = parsed.path or '/'
    m = re.search(r'/(?:e|v|embed)/([A-Za-z0-9_\-]+)', path, re.I)
    if not m:
        return None
    vid = m.group(1)
    host = parsed.netloc
    embed = f'https://{host}/e/{vid}'
    try:
        with urlopen(Request(embed, headers={'User-Agent': UA,
                                             'Referer': f'https://{host}/'}),
                     timeout=12) as response:
            html = response.read(2 * 1024 * 1024 + 1).decode('utf-8', errors='replace')
            embed = response.geturl()
    except HTTPError as exc:
        if exc.code in (404, 410):
            _last_resolver_error = 'removed'
        return None
    except (URLError, OSError):
        return None
    if not html:
        return None
    if re.search(r'Video\s+(?:not found|has been (?:removed|deleted))', html, re.I):
        _last_resolver_error = 'removed'
        return None
    media = _streamtape_media_url(html)
    if media:
        return media + '|' + urlencode({'User-Agent': UA, 'Referer': embed})
    return None


def _byse_b64url_decode(s):
    s = s.replace('-', '+').replace('_', '/')
    s += '=' * ((-len(s)) % 4)
    return base64.b64decode(s)


def _byse_key_slots(version, n_parts):
    """Return the two 1-based slot indices for the AES key.

    Original scheme (versions 1-20): slots are [v, 31-v].
    Extended scheme (versions 21+): slots are [v, (n_parts+1-v)], which
    generalises the mirror pattern to arbitrary table sizes.
    """
    try:
        v = int(str(version).strip())
    except (TypeError, ValueError):
        return []

    # ── Original scheme: version 1-20, table of exactly 30 parts ──────────
    if 1 <= v <= 20:
        a, b = v, 31 - v
        if 1 <= a <= n_parts and 1 <= b <= n_parts:
            return [a, b]

    # ── Extended scheme: generalised mirror for larger tables ──────────────
    if 1 <= v <= n_parts:
        a = v
        b = n_parts + 1 - v
        if a != b and 1 <= b <= n_parts:
            return [a, b]

    return []


def _byse_try_decrypt(key_parts, slots, iv_b64, payload_b64):
    """Attempt decryption with given 1-based slots. Returns plaintext or None."""
    try:
        key = b''.join(_byse_b64url_decode(key_parts[i - 1]) for i in slots)
        iv = _byse_b64url_decode(iv_b64)
        payload = _byse_b64url_decode(payload_b64)
        return aes_gcm_decrypt(key, iv, payload)
    except Exception:
        return None


def _byse_pick_source(sources):
    """From a Fiilemoon /api/source data list, return the best (stream, type) pair.

    Prefers MP4 over HLS — MP4 is a single request so Kodi's header
    propagation issues in adaptive-stream chains do not apply.
    Returns (url_string, type_string) or ('', '').
    """
    if not isinstance(sources, list) or not sources:
        return ('', '')
    mp4s = [s for s in sources
            if (s.get('type') or '').lower() in ('mp4', 'video/mp4')
            and s.get('file')]
    hls  = [s for s in sources
            if (s.get('type') or '').lower() in ('hls', 'm3u8', 'application/x-mpegurl')
            or '.m3u8' in (s.get('file') or '')]
    others = [s for s in sources if s.get('file')]
    if mp4s:
        mp4s.sort(key=lambda s: int(re.search(r'\d+', s.get('label') or '0').group()),
                  reverse=True)
        return (mp4s[0]['file'], 'mp4')
    if hls:
        f = hls[0].get('file') or ''
        return (f, 'hls') if f else ('', '')
    if others:
        return (others[0].get('file') or '', 'unknown')
    return ('', '')


def resolve_bysesukior(url):
    """Resolve a bysesukior.com (Fiilemoon) /d/<code> or /e/<code> link.

    Strategy:
      1. POST /api/source/<code>  — Fiilemoon player-facing API; returns
         plain (unencrypted) MP4/HLS URLs per-request.  These have fresh
         CDN tokens and do not suffer from HLS header-propagation issues.
      2. GET  /api/videos/<code>  — backend API returning AES-encrypted
         playback blob; decrypt and extract HLS URL (original approach).
         Used as fallback when the POST returns nothing useful.
    """
    m = re.search(r'/(?:d|e)/([A-Za-z0-9]+)', urlparse(url).path)
    if not m:
        return None
    code   = m.group(1)
    host = (urlparse(url).hostname or '').lower()
    host = host[4:] if host.startswith('www.') else host
    host = host if host in ('bysesukior.com', 'bysesayeveum.com', 'bysewihe.com', 'bysekoze.com', 'byseraguci.com') else 'bysesukior.com'
    origin = 'https://' + host
    embed = f'{origin}/e/{code}'

    # ── Step 1: POST /api/source/<code> (Fiilemoon player API) ────────────
    xbmc.log(f'VIDCORE bysesukior: POSTing to /api/source/{code}', xbmc.LOGINFO)
    post_body, _ = _post(
        f'{origin}/api/source/{code}',
        data={'r': embed, 'd': host},
        referer=embed,
    )
    xbmc.log('VIDCORE bysesukior: POST response received', xbmc.LOGINFO)
    if post_body:
        try:
            pdata = json.loads(post_body)
            if pdata.get('success') and pdata.get('data'):
                sources = pdata['data']
                xbmc.log('VIDCORE bysesukior: usable POST source data received',
                         xbmc.LOGINFO)
                stream, stype = _byse_pick_source(sources)
                if stream:
                    xbmc.log(
                        f'VIDCORE bysesukior: POST {stype} stream selected',
                        xbmc.LOGINFO)
                    return (f'{stream}'
                            f'|User-Agent={UA}'
                            f'&Referer={embed}'
                            f'&Origin={origin}')
                else:
                    xbmc.log(
                        f'VIDCORE bysesukior: POST returned no usable source '
                        '(response contained no usable source)', xbmc.LOGWARNING)
            else:
                xbmc.log(
                    f'VIDCORE bysesukior: POST success={pdata.get("success")} '
                    f'msg={pdata.get("msg")} — falling back to AES path',
                    xbmc.LOGWARNING)
        except ValueError as e:
            xbmc.log(f'VIDCORE bysesukior: POST JSON parse failed: {e}',
                     xbmc.LOGWARNING)
    else:
        xbmc.log(f'VIDCORE bysesukior: POST returned empty body, '
                 f'falling back to AES path', xbmc.LOGWARNING)

    # ── Step 2: GET /api/videos/<code> + AES decrypt (fallback) ───────────
    xbmc.log(f'VIDCORE bysesukior: trying AES path for {url}', xbmc.LOGINFO)
    api_url = f'{origin}/api/videos/{code}'
    body, _final = _fetch(api_url, referer=embed,
                          extra_headers={'Accept': 'application/json'})
    if not body:
        body, _final = _fetch(f'{origin}/api/source/{code}',
                              referer=embed,
                              extra_headers={'Accept': 'application/json'})
    if not body:
        xbmc.log(f'VIDCORE bysesukior: AES API returned empty body for {url}',
                 xbmc.LOGWARNING)
        return None

    try:
        data = json.loads(body)
    except ValueError as e:
        xbmc.log(f'VIDCORE bysesukior: JSON parse failed for {url}: {e}',
                 xbmc.LOGWARNING)
        return None

    # ── Locate the playback blob (handle both flat and nested layouts) ──────
    playback = data.get('playback') or data.get('data', {}) or {}
    if not isinstance(playback, dict):
        playback = {}

    # Some API revisions nest it one level deeper under 'video'
    if not playback.get('key_parts') and isinstance(data.get('video'), dict):
        playback = data['video'].get('playback') or {}

    key_parts = playback.get('key_parts') or []
    iv_b64    = playback.get('iv', '')
    payload_b64 = playback.get('payload', '')

    if not key_parts or not iv_b64 or not payload_b64:
        xbmc.log(
            f'VIDCORE bysesukior: missing playback fields for {url}. '
            f'Keys present: {list(playback.keys())}',
            xbmc.LOGWARNING,
        )
        return None

    n_parts = len(key_parts)
    version  = playback.get('version', '')

    # ── Primary: use the documented version→slots formula ──────────────────
    slots = _byse_key_slots(version, n_parts)
    if slots:
        plaintext = _byse_try_decrypt(key_parts, slots, iv_b64, payload_b64)
        if plaintext is None:
            xbmc.log(
                f'VIDCORE bysesukior: decrypt failed (version={version}, '
                f'slots={slots}, n_parts={n_parts}) for {url}',
                xbmc.LOGWARNING,
            )
    else:
        plaintext = None
        xbmc.log(
            f'VIDCORE bysesukior: no valid slots for version={version}, '
            f'n_parts={n_parts} — will try brute-force for {url}',
            xbmc.LOGWARNING,
        )

    # ── Fallback: scan mirror pairs when the formula yields nothing ─────────
    if plaintext is None:
        xbmc.log(f'VIDCORE bysesukior: brute-forcing slot pairs for {url}',
                 xbmc.LOGINFO)
        for a in range(1, n_parts + 1):
            b = n_parts + 1 - a
            if b <= a or b > n_parts:
                continue
            candidate = _byse_try_decrypt(key_parts, [a, b], iv_b64, payload_b64)
            if candidate is not None:
                xbmc.log(
                    f'VIDCORE bysesukior: brute-force found slots [{a},{b}] '
                    f'for version={version}',
                    xbmc.LOGINFO,
                )
                plaintext = candidate
                break

    if plaintext is None:
        xbmc.log(f'VIDCORE bysesukior: all decryption attempts failed for {url}',
                 xbmc.LOGERROR)
        return None

    try:
        info = json.loads(plaintext)
    except (ValueError, TypeError) as e:
        xbmc.log(f'VIDCORE bysesukior: plaintext JSON parse failed for {url}: {e}',
                 xbmc.LOGWARNING)
        return None

    sources = info.get('sources') or []
    if not sources:
        xbmc.log(f'VIDCORE bysesukior: no sources in decrypted payload for {url}',
                 xbmc.LOGWARNING)
        return None

    xbmc.log(f'VIDCORE bysesukior: AES sources={sources}', xbmc.LOGINFO)
    sources.sort(key=lambda s: int(s.get('height') or 0), reverse=True)
    stream = sources[0].get('url')
    if not stream:
        xbmc.log(f'VIDCORE bysesukior: sources[0] has no url key for {url}',
                 xbmc.LOGWARNING)
        return None
    xbmc.log(f'VIDCORE bysesukior: AES stream → {stream} for {url}', xbmc.LOGINFO)
    return (f'{stream}'
            f'|User-Agent={UA}'
            f'&Referer={embed}'
            f'&Origin={origin}')


_VIDARA_STREAM_RE = re.compile(
    r'["\']?(?:file|src|url)["\']?\s*[:=]\s*["\']'
    r'(https?://[^"\']+\.(?:m3u8|mp4)[^"\']*)["\']',
    re.IGNORECASE,
)


def _vidara_pick_best(sources):
    """Pick the best stream from a Filelions-style sources list.

    Prefers HLS (type='hls' or .m3u8 URL) then highest-label mp4.
    Returns the chosen ``file`` URL string, or '' if nothing usable.
    """
    if not isinstance(sources, list) or not sources:
        return ''
    hls = [s for s in sources if 'hls' in (s.get('type') or '')
           or '.m3u8' in (s.get('file') or '')]
    if hls:
        return hls[0].get('file') or ''
    # Sort mp4 sources by numeric label descending (e.g. "1080", "720")
    mp4 = [s for s in sources if s.get('file')]
    mp4.sort(key=lambda s: int(re.search(r'\d+', s.get('label', '0') or '0').group()), reverse=True)
    return mp4[0].get('file') or '' if mp4 else ''


def resolve_vidara(url):
    """Resolve a vidara.so /e/<ID> embed page to a direct HLS or mp4 stream.

    Tries strategies in order:
      1. POST /api/stream — JSON body {filecode, device:"web"} → streaming_url
         (the real player API discovered by reading the inline JS; this is what
         the browser uses and it returns a signed HLS URL directly)
      2. POST /api/source/<code> — form-encoded (legacy Filelions API)
      3. POST /api/source/<code> — JSON body (newer Filelions variant)
      4. GET  /api/videos/<code>, /api/embed/<code>, /api/play/<code>
      5. GET  /api/source/<code> — AES blob fallback
      6. Scrape the embed page HTML:
           a. JWPlayer .setup() sources array extraction
           b. Named regex for file/src/url keys pointing at .m3u8/.mp4
           c. Broad scan for .m3u8/.mp4 URLs anywhere in the page
           d. CDN-path scan for HLS-style paths without an explicit extension
    """
    parsed = urlparse(url)
    m = re.search(r'/(?:e|d)/([A-Za-z0-9_\-]+)', parsed.path)
    if not m:
        xbmc.log(f'VIDCORE vidara: no embed ID in {url}', xbmc.LOGWARNING)
        return None
    code = m.group(1)
    host = (parsed.hostname or '').lower()
    host = host[4:] if host.startswith('www.') else host
    if host not in ('vidara.so', 'vidara.to', 'gbsagbo.com'):
        return None
    origin = 'https://' + host
    embed = f'{origin}/e/{code}'

    def _return_stream(stream, strategy):
        xbmc.log(f'VIDCORE vidara: {strategy} → {stream[:80]} for {url}',
                 xbmc.LOGINFO)
        return (f'{stream}'
                f'|User-Agent={UA}'
                f'&Referer={embed}'
                f'&Origin={origin}')

    def _try_sources(data, label):
        sources = (data.get('data') or data.get('sources')
                   or (data.get('video') or {}).get('sources') or [])
        s = _vidara_pick_best(sources)
        if s:
            return _return_stream(s, label)
        # Also try AES decrypt (Filelions bysesukior-style playback blob)
        playback = data.get('playback') or (data.get('data') or {}) if not isinstance(data.get('data'), list) else {}
        if not isinstance(playback, dict):
            playback = {}
        kp  = playback.get('key_parts') or []
        iv  = playback.get('iv', '')
        pay = playback.get('payload', '')
        if kp and iv and pay:
            plaintext = _byse_try_decrypt(kp, _byse_key_slots(playback.get('version', ''), len(kp)), iv, pay)
            if plaintext is None:
                for a in range(1, len(kp) + 1):
                    b = len(kp) + 1 - a
                    if b <= a or b > len(kp):
                        continue
                    plaintext = _byse_try_decrypt(kp, [a, b], iv, pay)
                    if plaintext:
                        break
            if plaintext:
                try:
                    info = json.loads(plaintext)
                    srcs = info.get('sources') or []
                    if srcs:
                        srcs.sort(key=lambda x: int(x.get('height') or 0), reverse=True)
                        s2 = srcs[0].get('url') or srcs[0].get('file') or ''
                        if s2:
                            return _return_stream(s2, f'{label}+AES')
                except Exception:
                    pass
        return None

    # ── 1. POST /api/stream — the real player API ─────────────────────────
    # Discovered by reading the inline JS on the embed page:
    #   fetch("/api/stream", {method:"POST",
    #     headers:{"Content-Type":"application/json"},
    #     body: JSON.stringify({filecode: filecode, device: "web"})})
    # Response: {"streaming_url": "https://...", "thumbnail": "...", ...}
    _stream_body = json.dumps({'filecode': code, 'device': 'web'}).encode('utf-8')
    _stream_resp, _ = _post(
        f'{origin}/api/stream',
        data=_stream_body,
        referer=embed,
        extra_headers={
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'Origin': origin,
        },
    )
    if _stream_resp:
        try:
            _stream_data = json.loads(_stream_resp)
            _su = _stream_data.get('streaming_url', '')
            if _su and _su.startswith('http'):
                xbmc.log(f'VIDCORE vidara: /api/stream → {_su[:80]} for {url}',
                         xbmc.LOGINFO)
                _dblog('VIDARA-STREAM-API', _su)
                return _return_stream(_su, '/api/stream')
        except ValueError:
            pass

    # ── 2. POST /api/source/<code> — form-encoded (3 referrer variants) ───
    _referers = ['https://rugby24.net/', '', embed]
    for _vi, _r in enumerate(_referers):
        api_url = f'{origin}/api/source/{code}'
        body, _ = _post(api_url, data={'r': _r, 'd': host}, referer=embed)
        xbmc.log(f'VIDCORE vidara: POST-form{_vi+1} response received', xbmc.LOGINFO)
        if body:
            try:
                result = _try_sources(json.loads(body), f'POST-form{_vi+1}')
                if result:
                    return result
            except ValueError:
                pass

    # ── 2. POST /api/source/<code> — JSON body ────────────────────────────
    for _r in ['https://rugby24.net/', '', embed]:
        json_body = json.dumps({'r': _r, 'd': host}).encode('utf-8')
        body_j, _ = _post(
            f'{origin}/api/source/{code}',
            data=json_body,
            referer=embed,
            extra_headers={'Content-Type': 'application/json',
                           'Accept': 'application/json'},
        )
        xbmc.log(f'VIDCORE vidara: POST-json response received', xbmc.LOGINFO)
        if body_j:
            try:
                result = _try_sources(json.loads(body_j), 'POST-json')
                if result:
                    return result
            except ValueError:
                pass

    # ── 3. GET /api/videos/<code> ─────────────────────────────────────────
    for api_path in (f'/api/videos/{code}', f'/api/embed/{code}', f'/api/play/{code}'):
        body3, _ = _fetch(
            f'{origin}{api_path}',
            referer=embed,
            extra_headers={'Accept': 'application/json',
                           'X-Requested-With': 'XMLHttpRequest'},
        )
        if body3:
            try:
                result = _try_sources(json.loads(body3), f'GET{api_path}')
                if result:
                    return result
            except ValueError:
                pass

    # ── 4. GET /api/source/<code> — AES blob fallback ────────────────────
    body4, _ = _fetch(
        f'{origin}/api/source/{code}',
        referer=embed,
        extra_headers={'Accept': 'application/json',
                       'X-Requested-With': 'XMLHttpRequest'},
    )
    if body4:
        try:
            result = _try_sources(json.loads(body4), 'GET-api-source')
            if result:
                return result
        except ValueError:
            pass

    # ── 5. Scrape the embed page HTML ─────────────────────────────────────
    xbmc.log(f'VIDCORE vidara: API failed, falling back to page scrape for {url}',
             xbmc.LOGINFO)
    html, _ = _fetch(embed, referer=origin + '/',
                     extra_headers={'Origin': origin})
    if not html:
        xbmc.log(f'VIDCORE vidara: embed page fetch also failed for {url}',
                 xbmc.LOGWARNING)
        return None

    unpacked = _unpack(html) or ''
    search_text = unpacked + html
    xbmc.log(f'VIDCORE vidara: HTML preview (first 600): {html[:600]}',
             xbmc.LOGINFO)
    _dblog('VIDARA-HTML', f'first 400: {html[:400]}')

    # 5a. JWPlayer sources array — grab the JSON array from .setup({sources:[...]})
    #     or from a standalone  var sources = [...]  declaration.
    for _src_pat in (
        r'\.setup\s*\(\s*\{[^}]{0,500}["\']sources["\']?\s*:\s*(\[.*?\])',
        r'(?:var\s+)?sources\s*=\s*(\[(?:[^[\]]|\[[^\[\]]*\]){1,2000}\])',
        r'["\']sources["\']?\s*:\s*(\[.*?\])',
    ):
        _sm = re.search(_src_pat, search_text, re.DOTALL | re.IGNORECASE)
        if _sm:
            try:
                _srcs = json.loads(_sm.group(1))
                _s = _vidara_pick_best(_srcs)
                if _s:
                    return _return_stream(_s, 'HTML-jwp-sources')
            except Exception:
                pass

    # 5b. Named key regex — file/src/url → .m3u8 or .mp4
    m2 = _VIDARA_STREAM_RE.search(search_text)
    if m2:
        return _return_stream(m2.group(1), 'HTML-key-regex')

    # 5c. Broad scan — any .m3u8 or .mp4 URL anywhere in the page
    m3 = re.search(
        r'(https?://[^\s"\'<>\\]+\.(?:m3u8|mp4)(?:\?[^\s"\'<>\\]*)?)',
        search_text, re.IGNORECASE,
    )
    if m3:
        return _return_stream(m3.group(1), 'HTML-broad-scan')

    # 5d. CDN-path scan — HLS-style URLs without an explicit .m3u8 extension
    #     (some Filelions CDNs serve manifests at paths like /hls2/<id>/master)
    m4 = re.search(
        r'(https?://[^\s"\'<>\\]+/(?:hls|hls2|m3u8|master|stream|playlist)'
        r'(?:/[^\s"\'<>\\]*)?(?:\?[^\s"\'<>\\]*)?)',
        search_text, re.IGNORECASE,
    )
    if m4:
        return _return_stream(m4.group(1), 'HTML-cdn-path-scan')

    xbmc.log(f'VIDCORE vidara: all strategies exhausted for {url}',
             xbmc.LOGWARNING)
    return None
