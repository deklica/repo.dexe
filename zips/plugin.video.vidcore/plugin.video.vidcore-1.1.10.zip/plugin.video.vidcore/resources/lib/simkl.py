"""
Simkl integration for Vidcore

Minimal tracker support for auth, watchlist syncing, and history marking.
"""


import json


import math


import os


import hashlib


import base64


import secrets




import time


import threading


from datetime import datetime, timezone


from email.utils import parsedate_to_datetime


from urllib.parse import urlencode, urlsplit, quote_plus


from urllib.request import Request, urlopen


from urllib.error import HTTPError, URLError


import xbmc


import xbmcaddon


import xbmcgui




import xbmcvfs


from .auth_dialog import AuthDialog


ADDON_ID = 'plugin.video.vidcore'


ADDON = xbmcaddon.Addon(ADDON_ID)


ADDON_PATH = xbmcvfs.translatePath(xbmcaddon.Addon(ADDON_ID).getAddonInfo('path'))


ICON_SIMKL = os.path.join(ADDON_PATH, 'resources', 'media', 'menu', 'simkl.png')


DATA_PATH = xbmcvfs.translatePath(f'special://profile/addon_data/{ADDON_ID}/')


TOKEN_FILE = os.path.join(DATA_PATH, 'simkl_token.json')
LIST_CACHE_FILE = os.path.join(DATA_PATH, 'simkl_lists_cache.json')


API_BASE = 'https://api.simkl.com'


APP_NAME = 'vidcore-kodi'


APP_VERSION = ADDON.getAddonInfo('version')


UA = f'{APP_NAME}/{APP_VERSION}'


DEFAULT_CLIENT_ID = 'cb7cc25535d48f516c5cbe0eedca439771598e0df4c09af4d8698909ec52a34f'


LEGACY_CLIENT_ID = 'ad8431d5f7dca2827ca626a6922ba0a8cfa090963f79422114dfb358c26ee527'


SIMKL_SCOPE = 'media:read media:write'


def _log(message, level=xbmc.LOGINFO):
    """Write Simkl diagnostics with a searchable Kodi-log prefix."""
    xbmc.log(f'[VIDCORE Simkl] {message}', level)


def _debug_bundle_event(tag, detail):
    """Write safe Simkl request diagnostics to the optional Cosmos bundle."""
    try:
        from . import debug_bundle
        if debug_bundle.is_enabled():
            debug_bundle.log('Simkl ' + str(tag), detail)
    except Exception:
        pass


def _debug_http_result(method, url, status, data=None):
    """Record an HTTP outcome without exporting query strings or request data."""
    path = urlsplit(url).path
    summary = f'{str(method or "GET").upper()} {path} -> HTTP {status}'
    if status in (400, 401) and isinstance(data, dict):
        error = data.get('error') or data.get('code') or ''
        description = (data.get('error_description') or data.get('message')
                       or data.get('detail') or '')

        def clean(value, limit):
            return ' '.join(str(value).replace('\r', ' ').replace('\n', ' ').split())[:limit]

        error = clean(error, 100)
        description = clean(description, 240)
        if error:
            summary += f'; error={error}'
        if description:
            summary += f'; description={description}'
    _debug_bundle_event('HTTP', summary)


def _pkce_pair():
    verifier = secrets.token_urlsafe(64)
    digest = hashlib.sha256(verifier.encode('ascii')).digest()
    challenge = base64.urlsafe_b64encode(digest).rstrip(b'=').decode('ascii')
    return verifier, challenge


_request_lock = threading.Lock()


_scrobble_lock = threading.Lock()


_token_refresh_lock = threading.Lock()


_last_request_time = 0.0


_CUSTOM_LIST_CACHE = {}


_SYNC_WRITE_PATHS = frozenset((
    '/sync/history',
    '/sync/history/remove',
    '/sync/add-to-list',
    '/sync/ratings',
    '/sync/ratings/remove',
    '/sync/watched',
))


_TRANSIENT_STATUSES = frozenset((429, 500, 502, 503))


_MAX_TRANSIENT_ATTEMPTS = 5


_MAX_RETRY_DELAY = 60


def _throttle():
    from . import simkl_store
    simkl_store.throttle(DATA_PATH)


def _ensure_dir():
    if not xbmcvfs.exists(DATA_PATH):
        xbmcvfs.mkdirs(DATA_PATH)
    if not os.path.isdir(DATA_PATH):
        os.makedirs(DATA_PATH, exist_ok=True)


def _simkl_icon():
    """Return the path to the Simkl icon, falling back to the default addon icon."""
    return ICON_SIMKL if xbmcvfs.exists(ICON_SIMKL) else os.path.join(ADDON_PATH, 'icon.png')


def _save_token(data, refreshing=False):
    _ensure_dir()
    if not refreshing:
        ADDON.setSetting('simkl_cache_identity', secrets.token_hex(16))
        ADDON.setSetting('simkl_user_id', '')
        ADDON.setSetting('simkl_username', '')
    data = dict(data or {})
    data['stored_at'] = int(time.time())
    try:
        with open(TOKEN_FILE, 'w', encoding='utf-8') as fp:
            json.dump(data, fp)
        try:
            os.chmod(TOKEN_FILE, 0o600)
        except OSError:
            pass
    except OSError as e:
        xbmc.log(f'Simkl save token failed: {e}', xbmc.LOGERROR)
    # Also save to settings for ReAuth compatibility
    try:
        ADDON.setSetting('simkl_access_token', data.get('access_token', ''))
        ADDON.setSetting('simkl_refresh_token', data.get('refresh_token', ''))
        ADDON.setSetting('simkl_expires_in', str(data.get('expires_in', '')))
        ADDON.setSetting('simkl_stored_at', str(data.get('stored_at', '')))
    except Exception as e:
        xbmc.log(f'Simkl save token to settings failed: {e}', xbmc.LOGWARNING)


def _load_token():
    # Try settings first for ReAuth compatibility
    access_token = ADDON.getSetting('simkl_access_token')
    if access_token:
        try:
            expires_in = int(ADDON.getSetting('simkl_expires_in'))
        except (ValueError, TypeError):
            expires_in = 0
        try:
            stored_at = int(ADDON.getSetting('simkl_stored_at'))
        except (ValueError, TypeError):
            stored_at = 0
        
        token_data = {
            'access_token': access_token,
            'refresh_token': ADDON.getSetting('simkl_refresh_token'),
            'expires_in': expires_in,
            # Older installs did not persist the token timestamp. Treat those
            # tokens as long-lived until Simkl rejects them instead of forcing
            # a refresh on every API operation.
            'stored_at': stored_at,
        }
        return token_data

    # Fallback to file
    if os.path.isfile(TOKEN_FILE):
        try:
            with open(TOKEN_FILE, 'r', encoding='utf-8') as fp:
                return json.load(fp)
        except (OSError, ValueError):
            pass
    return None


def _delete_token():
    try:
        if os.path.isfile(TOKEN_FILE):
            os.remove(TOKEN_FILE)
    except OSError:
        pass
    try:
        ADDON.setSetting('simkl_access_token', '')
        ADDON.setSetting('simkl_refresh_token', '')
        ADDON.setSetting('simkl_expires_in', '')
        ADDON.setSetting('simkl_auth_done', 'false')
        ADDON.setSetting('simkl_username', '')
        ADDON.setSetting('simkl_user_id', '')
    except Exception:
        pass


def _credentials():
    cid = DEFAULT_CLIENT_ID
    if cid == LEGACY_CLIENT_ID:
        cid = DEFAULT_CLIENT_ID
    # The registered Simkl app is a public device client.  Ignore any legacy
    # secret left in Kodi settings and never send a client_secret to AUTH V2.
    csec = ''
    return cid, csec


def _build_api_url(path, params=None):
    cid, _ = _credentials()
    query = {'client_id': cid, 'app-name': APP_NAME, 'app-version': APP_VERSION}
    if params:
        query.update(params)
    return f'{API_BASE}{path}?{urlencode(query)}'


def _account_cache_key():
    identity = ADDON.getSetting('simkl_cache_identity')
    if identity:
        return identity
    token = (_load_token() or {}).get('access_token') or ''
    identity = hashlib.sha256(token.encode('utf-8')).hexdigest()
    ADDON.setSetting('simkl_cache_identity', identity)
    return identity


def _sync_snapshot(force=False, resource=None, on_progress=None, resource_ttl=None,
                   refresh_resources=False):
    from . import simkl_store
    if not is_authorized():
        return None, False
    try:
        result, ok = simkl_store.sync(DATA_PATH, _account_cache_key(),
            lambda path, **kwargs: _http_json(path, method='POST' if path == '/users/settings' else 'GET',
                                             headers=_auth_headers(), **kwargs),
            force=force, resource=resource, on_progress=on_progress, resource_ttl=resource_ttl,
            refresh_resources=refresh_resources)
        if not ok:
            _log('Sync incomplete; retaining previous snapshot and cursor', xbmc.LOGWARNING)
        return result, ok
    except (OSError, simkl_store.sqlite3.Error) as exc:
        _log(f'Sync cache unavailable: {exc}', xbmc.LOGWARNING)
        return None, False


def _load_list_cache():
    """Read persisted API cooldowns from Vidcore's own profile."""
    if not os.path.isfile(LIST_CACHE_FILE):
        return {}
    try:
        with open(LIST_CACHE_FILE, 'r', encoding='utf-8') as fp:
            data = json.load(fp)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def _http_json(path, method='GET', payload=None, headers=None, timeout=20, params=None,
               _retry_rate_limit=True, _retry_auth=True):
    global _LAST_API_ERROR
    method = str(method or 'GET').upper()
    key = 'cooldown:' + _account_cache_key()
    cache = _load_list_cache()
    client_cooldown = cache.get('cooldown:client') or {}
    account_cooldown = cache.get(key) or {}
    cooldowns = [client_cooldown]
    if headers and headers.get('Authorization'):
        cooldowns.append(account_cooldown)
    cooldown = max(cooldowns, key=lambda item: float(item.get('until') or 0))
    if cooldown.get('until', 0) > time.time():
        status = int(cooldown.get('status') or 429)
        _LAST_API_ERROR = cooldown.get('message') or 'Simkl API limit reached; try later'
        _debug_bundle_event('COOLDOWN', f'{method} {path} -> HTTP {status}; request skipped')
        return status, {'error': cooldown.get('error') or 'rate_limit',
                        'message': _LAST_API_ERROR}, {}

    # Kodi directory requests must return control promptly.  The sync/cache
    # layer defers failed GETs and serves the last good snapshot, while
    # user-initiated writes use the documented exponential retry policy.
    attempts = (
        _MAX_TRANSIENT_ATTEMPTS
        if _retry_rate_limit and method != 'GET'
        else 1
    )
    delay = 1
    result = (0, None, {})
    for attempt in range(attempts):
        with _request_lock:
            result = _http_json_request(path, method, payload, headers, timeout, params)
        status, data, response_headers = result
        if status == 429 and isinstance(data, dict) and data.get('error') in (
                'user_limit_exceeded', 'app_limit_exceeded'):
            # Daily allowances cannot recover during a short retry loop.
            break
        if status not in _TRANSIENT_STATUSES or attempt >= attempts - 1:
            break

        if status == 429:
            # Daily errors already stop above. Burst errors clear in a second;
            # Retry-After on these can carry the unrelated daily reset.
            wait = 1
        else:
            wait = min(delay, _MAX_RETRY_DELAY)
        _log(
            f'{method} {path} transient HTTP {status}; '
            f'retry {attempt + 2}/{attempts} in {wait}s',
            xbmc.LOGWARNING,
        )
        _debug_bundle_event(
            'RETRY', f'{method} {urlsplit(_build_api_url(path, params=params)).path} '
            f'-> HTTP {status}; retry '
            f'{attempt + 2}/{attempts} after {wait}s',
        )
        time.sleep(wait)
        delay = min(delay * 2, _MAX_RETRY_DELAY)

    if _retry_rate_limit and _is_sync_write_rate_limit(path, method, result):
        _log(f'Simkl: sync write returned a rate-limit response; retrying once: {path}',
             xbmc.LOGWARNING)
        _debug_bundle_event(
            'RETRY', f'{method} {urlsplit(_build_api_url(path, params=params)).path} '
            '-> HTTP 400 rate_limit; retrying after 3s',
        )
        time.sleep(3)
        with _request_lock:
            result = _http_json_request(path, method, payload, headers, timeout, params)

    status, data, response_headers = result
    # Access tokens can be revoked or rotated between the proactive refresh
    # check and the actual request.  Red Light handles this by reloading the
    # settings database, refreshing once, and replaying the original request.
    # Do the same here, but never recurse more than once.
    missing_token = isinstance(data, dict) and data.get('error') == 'user_token_required'
    if status == 401 and not missing_token and _retry_auth and headers and headers.get('Authorization'):
        failed_token = headers['Authorization'].removeprefix('Bearer ').strip()
        refreshed = _refresh_token(force=True, expected_access_token=failed_token)
        if refreshed:
            fresh_headers = _auth_headers()
            if fresh_headers:
                return _http_json(path, method=method, payload=payload,
                                  headers=fresh_headers, timeout=timeout,
                                  params=params, _retry_rate_limit=_retry_rate_limit,
                                  _retry_auth=False)
    if status in (200, 201, 204) and ((method == 'POST' and (path in _SYNC_WRITE_PATHS or path.startswith('/scrobble/'))) or
                                      (method == 'DELETE' and path.startswith('/sync/playback/'))):
        try:
            _invalidate_ratings_cache()
        except Exception as exc:
            _log(f'Cache invalidation failed: {exc}', xbmc.LOGWARNING)
    _LAST_API_ERROR = ''
    if status not in (200, 201, 204):
        if status == 429:
            retry = next((v for k, v in response_headers.items() if k.lower() == 'retry-after'), 60)
            quota_error = data.get('error') if isinstance(data, dict) else ''
            delay = (_retry_after_seconds({'Retry-After': retry}, ceiling=None)
                     if quota_error in ('user_limit_exceeded', 'app_limit_exceeded') else 1)
            daily = isinstance(data, dict) and data.get('error') == 'user_limit_exceeded'
            _LAST_API_ERROR = ('Simkl daily account API limit reached' if daily else 'Simkl API rate limit reached')
            _LAST_API_ERROR += ' — retry after ' + datetime.fromtimestamp(time.time() + delay).strftime('%H:%M')
            cooldown_key = (key if headers and headers.get('Authorization') and
                            quota_error != 'app_limit_exceeded' else 'cooldown:client')
            cache[cooldown_key] = {
                'until': time.time() + delay,
                'status': 429,
                'error': 'rate_limit',
                'message': _LAST_API_ERROR,
            }
            _ensure_dir()
            try:
                with open(LIST_CACHE_FILE, 'w', encoding='utf-8') as fp:
                    json.dump(cache, fp)
            except OSError:
                pass
        elif status == 412:
            _LAST_API_ERROR = (
                'Simkl client temporarily blocked (HTTP 412 client_id_failed); '
                'fresh requests are paused'
            )
            cache['cooldown:client'] = {
                'until': time.time() + 15 * 60,
                'status': 412,
                'error': 'client_id_failed',
                'message': _LAST_API_ERROR,
            }
            _ensure_dir()
            try:
                with open(LIST_CACHE_FILE, 'w', encoding='utf-8') as fp:
                    json.dump(cache, fp)
            except OSError:
                pass
        elif status == 401 and isinstance(data, dict) and data.get('error') == 'user_token_required':
            _LAST_API_ERROR = 'Simkl request requires an access token; this is a request authentication error'
        elif status in (401, 403):
            _LAST_API_ERROR = 'Simkl authorization/access denied — reconnect or check account access'
        elif status == 0:
            _LAST_API_ERROR = 'Cannot connect to Simkl'
        else:
            _LAST_API_ERROR = 'Simkl request failed (HTTP %s)' % status
    return result


def _http_json_request(path, method='GET', payload=None, headers=None, timeout=20, params=None):
    _throttle()
    url = _build_api_url(path, params=params)
    hdr = {'Content-Type': 'application/json', 'User-Agent': UA}
    if headers:
        hdr.update(headers)
    body = json.dumps(payload).encode('utf-8') if payload is not None else None
    try:
        req = Request(url, data=body, headers=hdr, method=method)
        with urlopen(req, timeout=timeout) as r:
            raw = r.read().decode('utf-8', errors='replace')
            try:
                data = json.loads(raw) if raw else {}
            except ValueError:
                data = {'_raw': raw}
            result = (r.getcode(), data, dict(r.headers.items()))
            _debug_http_result(method, url, r.getcode(), data)
            _log(f'{method} {path} -> {r.getcode()}', xbmc.LOGINFO)
            return result
    except HTTPError as e:
        raw = ''
        try:
            raw = e.read().decode('utf-8', errors='replace')
        except Exception:
            pass
        try:
            data = json.loads(raw) if raw else {}
        except ValueError:
            data = {'_raw': raw}
        result = (e.code, data, dict(e.headers.items() if e.headers else []))
        _debug_http_result(method, url, e.code, data)
        _log(f'{method} {path} -> {e.code}', xbmc.LOGWARNING)
        _log_api_error_detail(method, path, e.code, data)
        return result
    except URLError as e:
        _debug_bundle_event('HTTP ERROR', f'{method} {urlsplit(url).path} -> network error (URLError)')
        _log(f'{method} {path} URL error: {e.reason}', xbmc.LOGERROR)
        return 0, None, {}
    except Exception as e:
        _debug_bundle_event('HTTP ERROR', f'{method} {urlsplit(url).path} -> request error ({type(e).__name__})')
        _log(f'{method} {path} HTTP error: {e}', xbmc.LOGERROR)
        return 0, None, {}


def _log_api_error_detail(method, path, status, data):
    """Log safe Simkl error fields for client/request errors, never payloads."""
    if status not in (400, 401):
        return
    if isinstance(data, dict):
        error = data.get('error') or data.get('code') or ''
        detail = (data.get('error_description') or data.get('message')
                  or data.get('detail') or '')
    else:
        error = detail = ''

    def clean(value, limit):
        return ' '.join(str(value).replace('\r', ' ').replace('\n', ' ').split())[:limit]

    error = clean(error, 100) or 'unavailable'
    detail = clean(detail, 240) or 'no API error description returned'
    level = xbmc.LOGINFO if error.lower() in (
        'authorization_pending', 'slow_down'
    ) else xbmc.LOGWARNING
    _log(
        f'HTTP {status} details for {str(method).upper()} {path}: '
        f'error={error}; description={detail}',
        level,
    )


def _retry_after_seconds(headers, ceiling=_MAX_RETRY_DELAY):
    """Parse Retry-After; persistent daily cooldowns must not be capped."""
    raw = next(
        (value for key, value in (headers or {}).items()
         if str(key).lower() == 'retry-after'),
        86400 if ceiling is None else 5,
    )
    try:
        value = int(float(raw))
    except (TypeError, ValueError, OverflowError):
        try:
            retry_at = parsedate_to_datetime(str(raw))
            if retry_at.tzinfo is None:
                retry_at = retry_at.replace(tzinfo=timezone.utc)
            value = int((retry_at - datetime.now(timezone.utc)).total_seconds())
        except (TypeError, ValueError, OverflowError):
            value = 86400 if ceiling is None else 5
    return max(2, min(value, ceiling)) if ceiling is not None else max(2, value)


def _is_sync_write_rate_limit(path, method, result):
    """Keep compatibility with Simkl's legacy 400 sync-write response."""
    status, data, _headers = result
    if str(method or 'GET').upper() != 'POST' or path not in _SYNC_WRITE_PATHS or status != 400:
        return False
    return isinstance(data, dict) and str(data.get('error') or '').lower() == 'rate_limit'


def _http_form(path, method='POST', payload=None, headers=None, timeout=20, params=None):
    method = str(method or 'POST').upper()
    url = _build_api_url(path, params=params)
    hdr = {'Content-Type': 'application/x-www-form-urlencoded', 'User-Agent': UA}
    if headers:
        hdr.update(headers)
    body = urlencode(payload).encode('utf-8') if payload is not None else None
    delay = 1
    for attempt in range(_MAX_TRANSIENT_ATTEMPTS):
        _throttle()
        with _request_lock:
            try:
                req = Request(url, data=body, headers=hdr, method=method)
                with urlopen(req, timeout=timeout) as r:
                    raw = r.read().decode('utf-8', errors='replace')
                    try:
                        data = json.loads(raw) if raw else {}
                    except ValueError:
                        data = {'_raw': raw}
                    status = r.getcode()
                    response_headers = dict(r.headers.items())
                    _debug_http_result(method, url, status, data)
                    _log(f'{method} {path} -> {status}', xbmc.LOGINFO)
            except HTTPError as e:
                raw = ''
                try:
                    raw = e.read().decode('utf-8', errors='replace')
                except Exception:
                    pass
                try:
                    data = json.loads(raw) if raw else {}
                except ValueError:
                    data = {'_raw': raw}
                status = e.code
                response_headers = dict(e.headers.items() if e.headers else [])
                _debug_http_result(method, url, status, data)
                _log(f'{method} {path} -> {status}', xbmc.LOGWARNING)
                _log_api_error_detail(method, path, status, data)
            except URLError as e:
                _debug_bundle_event('HTTP ERROR', f'{method} {urlsplit(url).path} -> network error (URLError)')
                _log(f'{method} {path} URL error: {e.reason}', xbmc.LOGERROR)
                return 0, None, {}
            except Exception as e:
                _debug_bundle_event('HTTP ERROR', f'{method} {urlsplit(url).path} -> request error ({type(e).__name__})')
                _log(f'{method} {path} HTTP error: {e}', xbmc.LOGERROR)
                return 0, None, {}

        if status not in _TRANSIENT_STATUSES or attempt >= _MAX_TRANSIENT_ATTEMPTS - 1:
            return status, data, response_headers
        wait = _retry_after_seconds(response_headers) if status == 429 else min(delay, _MAX_RETRY_DELAY)
        _log(
            f'{method} {path} transient HTTP {status}; '
            f'retry {attempt + 2}/{_MAX_TRANSIENT_ATTEMPTS} in {wait}s',
            xbmc.LOGWARNING,
        )
        _debug_bundle_event(
            'RETRY', f'{method} {urlsplit(url).path} -> HTTP {status}; retry '
            f'{attempt + 2}/{_MAX_TRANSIENT_ATTEMPTS} after {wait}s',
        )
        time.sleep(wait)
        delay = min(delay * 2, _MAX_RETRY_DELAY)

    return status, data, response_headers


def _token_needs_refresh(tok):
    if not tok:
        return True
    try:
        stored_at = int(tok.get('stored_at', 0))
        expires_in = int(tok.get('expires_in', 30 * 86400))  # Default 30 days
    except (TypeError, ValueError, OverflowError):
        return True
    if not stored_at:
        return False
    return (time.time() - stored_at) > (expires_in * 0.8)


def _refresh_token(force=False, expected_access_token=None):
    # Simkl refresh tokens are single-use. Re-check the token while holding a
    # process-wide lock so simultaneous Kodi requests cannot consume the same
    # refresh token twice.
    with _token_refresh_lock:
        tok = _load_token()
        if not tok or not tok.get('refresh_token'):
            return False
        if expected_access_token and tok.get('access_token') != expected_access_token:
            return bool(tok.get('access_token'))
        if not force and not _token_needs_refresh(tok):
            return True

        cid, csec = _credentials()
        refresh_payload = {
            'client_id': cid,
            'refresh_token': tok['refresh_token'],
            'grant_type': 'refresh_token',
            'scope': SIMKL_SCOPE,
        }
        status, data, _ = _http_form(
            '/oauth2/token',
            method='POST',
            payload=refresh_payload,
        )
        if status == 200 and isinstance(data, dict) and data.get('access_token'):
            _account_cache_key()
            _save_token(data, refreshing=True)
            xbmc.log('Simkl: token refreshed', xbmc.LOGINFO)
            return True

        xbmc.log(f'Simkl refresh failed: {status}', xbmc.LOGWARNING)
        # Do not delete the token on refresh failure. This allows ReAuth to manage
        # the token independently and avoids a race condition where we delete a
        # token that ReAuth has just refreshed.
        return False


def _get_access_token():
    tok = _load_token()
    if not tok:
        _log('access token lookup: no saved token found', xbmc.LOGDEBUG)
        return None
    if _token_needs_refresh(tok) and tok.get('refresh_token'):
        _log('access token lookup: token requires refresh', xbmc.LOGDEBUG)
        if not _refresh_token():
            # Never keep using an expired credential after refresh failure.
            _log('access token lookup: refresh failed', xbmc.LOGWARNING)
            return None
        tok = _load_token()
    access_token = (tok or {}).get('access_token')
    _log(f'access token lookup: {"available" if access_token else "missing"}',
         xbmc.LOGDEBUG if access_token else xbmc.LOGWARNING)
    return access_token


def is_authorized():
    authorized = bool(_get_access_token())
    _log(f'authorization check: {"authorized" if authorized else "not authorized"}',
         xbmc.LOGDEBUG)
    return authorized


def has_token():
    """Cheap local check for menu construction; network refresh is deferred."""
    token = _load_token()
    return bool(isinstance(token, dict) and token.get('access_token'))


def _auth_headers():
    access_token = _get_access_token()
    if not access_token:
        return None
    cid, _ = _credentials()
    return {'Authorization': f'Bearer {access_token}', 'simkl-api-key': cid}


def _scrobble_payload(meta):
    """Build a robust singular item payload required by /scrobble/*.

    Simkl expects movies as {"movie": {...}} and TV/anime episodes as
    {"show": {...}, "episode": {...}} or {"anime": {...}, "episode": {...}}.
    This function ensures all required fields are present for reliable scrobbling.
    """
    xbmc.log('Simkl: building scrobble payload', xbmc.LOGDEBUG)
    if not meta:
        return None

    title = str(meta.get('title') or '').strip()
    content_type_from_meta = str(meta.get('content') or 'movie').lower()
    year = str(meta.get('year') or '').strip()
    season = meta.get('season')
    episode = meta.get('episode')
    
    if not title:
        xbmc.log("Simkl: _scrobble_payload missing title.", xbmc.LOGWARNING)
        return None

    # The guide accepts every known external ID and falls back to title/year.
    # Preserve IDs already nested under ``ids`` as well as the flat metadata
    # fields used by Cosmos playback routes.
    supplied_ids = meta.get('ids') if isinstance(meta.get('ids'), dict) else {}
    ids = {}
    for key in ('simkl', 'imdb', 'tmdb', 'tvdb', 'mal', 'anidb', 'anilist', 'kitsu'):
        value = supplied_ids.get(key)
        if value in (None, ''):
            value = meta.get(key)
        if value in (None, ''):
            value = meta.get(f'{key}_id')
        if value in (None, ''):
            continue
        value = str(value).strip()
        if not value:
            continue
        if key == 'tmdb' and value.isdigit():
            value = int(value)
        ids[key] = value

    if not ids and not year:
        xbmc.log(
            'Simkl: scrobble payload needs an ID or a title/year fallback',
            xbmc.LOGWARNING,
        )
        return None

    # Base object for a movie or a show.
    media_object = {'title': title, 'ids': ids}
    if year:
        try: media_object['year'] = int(year)
        except (ValueError, TypeError): pass

    # Handle movies
    if 'movie' in content_type_from_meta:
        return {'movie': media_object}

    # Simkl-native anime uses an absolute episode number without a season.
    # TMDB/TVDB-primary anime uses the ordinary show/season coordinates; a
    # TMDB ID may identify several separate Simkl anime titles.
    if 'anime' in content_type_from_meta:
        try:
            episode_no = int(episode)
        except (TypeError, ValueError):
            return None
        if episode_no < 1:
            return None
        native_ids = any(key in ids for key in ('simkl', 'mal', 'anilist', 'anidb', 'kitsu'))
        if native_ids and (meta.get('anime_numbering') == 'absolute' or season in (None, '')):
            return {'anime': media_object, 'episode': {'number': episode_no}}
        try:
            season_no = int(season)
        except (TypeError, ValueError):
            return None
        if season_no < 0 or not any(key in ids for key in ('tmdb', 'tvdb')):
            return None
        show_object = dict(media_object, ids={key: value for key, value in ids.items()
                                              if key in ('tmdb', 'tvdb', 'imdb')})
        return {'show': show_object, 'episode': {'season': season_no,
                                                 'number': episode_no}}

    # Handle ordinary TV episodes.
    if any(x in content_type_from_meta for x in ('tv', 'show', 'episode', 'anime')):
        try:
            season_no = int(season)
            episode_no = int(episode)
        except (TypeError, ValueError):
            xbmc.log("Simkl: scrobble payload missing valid season/episode", xbmc.LOGWARNING)
            return None
        
        episode_object = {'season': season_no, 'number': episode_no}
        
        return {'show': media_object, 'episode': episode_object}

    xbmc.log(f"Simkl: _scrobble_payload unknown content type: {content_type_from_meta}", xbmc.LOGWARNING)
    return None


def scrobble(verb, meta, progress=0.0, require_watched=False):
    """Report a real playback event to Simkl using their dedicated scrobble endpoints."""
    if verb not in ('start', 'pause', 'stop'):
        return False

    if not is_authorized():
        xbmc.log(f'Simkl scrobble {verb}: Not authorized - skipping', xbmc.LOGINFO)
        return False

    payload = _scrobble_payload(meta)
    if payload is None:
        xbmc.log(f'Simkl scrobble {verb}: Failed to build valid payload', xbmc.LOGWARNING)
        return False

    headers = _auth_headers()

    try:
        p = float(progress or 0)
        if not math.isfinite(p):
            raise ValueError
    except (TypeError, ValueError, OverflowError):
        p = 0.0

    payload['progress'] = round(max(0.0, min(100.0, p)), 2)

    # SIMKL permits only one scrobble operation per user at a time. Keep
    # playback events ordered even though resume.py dispatches them in daemon
    # threads, and do not retry a 429 here: the next real player event is the
    # documented retry point and avoids duplicate scrobbles.
    with _scrobble_lock:
        status, data, _ = _http_json(
            f'/scrobble/{verb}',
            method='POST',
            payload=payload,
            headers=headers,
            timeout=8,
            _retry_rate_limit=False,
        )

    already_watched = (
        status == 409
        and isinstance(data, dict)
        and bool(data.get('watched_at'))
    )
    ok = (200 <= (status or 0) < 300) or already_watched
    action = data.get('action') if isinstance(data, dict) else None
    watched = already_watched or (ok and action == 'scrobble')
    if ok:
        xbmc.log(
            f'Simkl scrobble {verb} -> {status} '
            f'{"ALREADY WATCHED" if already_watched else "SUCCESS"} '
            f'progress={payload["progress"]:.2f} action={action} watched={watched}',
            xbmc.LOGINFO,
        )
    else:
        xbmc.log(
            f'Simkl scrobble {verb} -> {status} FAILED',
            xbmc.LOGWARNING,
        )
    # A successful stop below 80% is only a saved pause point. Never let
    # callers mistake HTTP success for confirmed remote watch history.
    return bool(watched) if require_watched else ok


def scrobble_start(meta, progress=0.0):
    return scrobble('start', meta, progress)


def scrobble_pause(meta, progress=0.0):
    return scrobble('pause', meta, progress)


def scrobble_stop(meta, progress=0.0):
    return scrobble('stop', meta, progress)


def _sync_result_ok(status, data):
    """A successful duplicate write is a no-op, not an error."""
    if status not in (200, 201, 204):
        return False
    if status == 204:
        return True
    return (isinstance(data, dict) and not data.get('error') and
            not any((data.get('not_found') or {}).values()))


def add_to_history(meta):
    """Add an item to Simkl watch history. Does not show notifications."""
    if not is_authorized():
        return False

    content = (meta.get('content') or 'movie').lower()

    title = meta.get('title')
    year = meta.get('year')
    tmdb = meta.get('tmdb')
    imdb = meta.get('imdb')
    season = meta.get('season')
    episode = meta.get('episode')

    payload = {'movies': [], 'shows': [], 'anime': []}
    watched_at = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())

    is_show = content in ('tv', 'tvshow', 'episode', 'show')
    is_anime = content in ('anime', 'anime_episode')

    if content == 'movie':
        movie = _build_item_payload(
            title, year=year, tmdb=tmdb, imdb=imdb, content='movie',
        )
        if movie:
            movie['watched_at'] = watched_at
            payload['movies'].append(movie)
    elif is_show:
        if season not in (None, '') and episode not in (None, ''):
            item = _build_show_episode_payload(
                title, year=year, tmdb=tmdb, imdb=imdb,
                season=season, episode=episode, watched_at=watched_at,
            )
            if item:
                payload['shows'].append(item)
            else:
                xbmc.log(f'Simkl: Failed to build episode payload for history. {title} S{season}E{episode}', xbmc.LOGWARNING)
                return False
        else:
            item = _build_item_payload(title, year=year, tmdb=tmdb, imdb=imdb, content='show')
            if season not in (None, ''):
                item['seasons'] = [{'number': int(season)}]
            else:
                item['status'] = 'completed'
            payload['shows'].append(item)
    elif is_anime:
        if season and episode:
            item = _build_show_episode_payload(
                title, year=year, tmdb=tmdb, imdb=imdb, content='anime',
                season=season, episode=episode, watched_at=watched_at,
            )
            if item:
                payload['anime'].append(item)
            else:
                xbmc.log(f'Simkl: Failed to build anime episode payload for history. {title} S{season}E{episode}', xbmc.LOGWARNING)
                return False
        else:
            xbmc.log(f'Simkl: Cannot add anime to history without episode details: {title}', xbmc.LOGWARNING)
            return False


    status, data, _ = _http_json(
        '/sync/history',
        method='POST',
        payload=payload,
        headers=_auth_headers(),
    )
    if _sync_result_ok(status, data):
        xbmc.log(f'Simkl: Added to history: {title}', xbmc.LOGINFO)
        return True
    xbmc.log(f'Simkl: Failed to add to history. Status: {status}', xbmc.LOGWARNING)
    return False


def remove_from_history(meta):
    """Remove an item from Simkl watch history."""
    if not is_authorized():
        return False

    content = (meta.get('content') or 'movie').lower()
    title = meta.get('title')
    year = meta.get('year')
    tmdb = meta.get('tmdb')
    imdb = meta.get('imdb')
    season = meta.get('season')
    episode = meta.get('episode')

    payload = {'movies': [], 'shows': [], 'anime': []}

    is_show = content in ('tv', 'tvshow', 'episode', 'show')
    is_anime = content in ('anime', 'anime_episode')

    item = None
    if content == 'movie':
        item = _build_item_payload(title, year=year, tmdb=tmdb, imdb=imdb, content='movie')
        if item:
            payload['movies'].append(item)
    elif is_show:
        if season not in (None, '') and episode not in (None, ''):
            item = _build_show_episode_payload(
                title, year=year, tmdb=tmdb, imdb=imdb,
                content='show', season=season, episode=episode,
            )
        else:
            item = _build_item_payload(
                title, year=year, tmdb=tmdb, imdb=imdb, content='show',
            )
            # A parent-show history action should unmark its watched seasons
            # while keeping the show in the user's library. An item with no
            # seasons would remove the library entry entirely.
            seasons = [{'number': int(season)}] if season not in (None, '') else []
            for season_item in (meta.get('seasons') or []):
                try:
                    seasons.append({'number': int(season_item.get('number'))})
                except (AttributeError, TypeError, ValueError):
                    continue
            if item and seasons:
                item['seasons'] = seasons
        if item:
            payload['shows'].append(item)
    elif is_anime:
        item = _build_show_episode_payload(title, year=year, tmdb=tmdb, imdb=imdb, content='anime', season=season, episode=episode) if season and episode else _build_item_payload(title, year=year, tmdb=tmdb, imdb=imdb, content='anime')
        if item:
            # The current remove-history contract accepts anime under shows[].
            payload['shows'].append(item)
    
    if not any(payload.values()):
        xbmc.log('Simkl: Failed to build remove from history payload.', xbmc.LOGWARNING)
        return False

    if is_show and episode in (None, '') and not item.get('seasons'):
        # Refuse a broad removal without explicit season scopes: that can
        # delete watchlist membership rather than simply clear watched history.
        return False
    status, data, _ = _http_json('/sync/history/remove', method='POST', payload=payload, headers=_auth_headers())

    if _sync_result_ok(status, data):
        return True

    xbmc.log(f'Simkl: Failed to remove from history. Status: {status}', xbmc.LOGWARNING)
    return False


def _download_qr_code(data):
    tmp = None
    try:
        import tempfile
        # Preserve the complete authorization URI for QR-based sign-in.
        qr_target = data or ''
        qr_api = (
            'https://api.qrserver.com/v1/create-qr-code/'
            '?size=450x450&margin=4&format=png&data=' + quote_plus(qr_target)
        )
        req = Request(qr_api, headers={'User-Agent': UA})
        with urlopen(req, timeout=20) as r:
            img_bytes = r.read(1024 * 1024 + 1)
        if len(img_bytes) > 1024 * 1024 or not img_bytes.startswith(b'\x89PNG\r\n\x1a\n'):
            raise ValueError('Invalid QR image response')
        tmp = tempfile.NamedTemporaryFile(delete=False, suffix='.png')
        tmp.write(img_bytes)
        tmp.close()
        return tmp.name
    except Exception as e:
        if tmp:
            try:
                tmp.close()
                os.remove(tmp.name)
            except Exception:
                pass
        raise


def _run_plain_auth_dialog(service_name, user_code, verification_url,
                            expires_in, interval, poll_fn):
    dialog = xbmcgui.DialogProgress()
    dialog.create(f'{service_name} Authorization', '')
    start = time.time()
    while True:
        elapsed = time.time() - start
        remaining = expires_in - elapsed
        if remaining <= 0 or dialog.iscanceled():
            dialog.close()
            return False
        dialog.update(
            max(0, int(100 - (elapsed / expires_in) * 100)),
            f'Go to: [COLOR skyblue]{verification_url}[/COLOR]\n\n'
            f'Enter Code: [COLOR yellow]{user_code}[/COLOR]\n\n'
            f'Time remaining: {int(remaining)}s',
        )
        time.sleep(interval)
        if dialog.iscanceled() or time.time() - start >= expires_in:
            dialog.close()
            return False
        try:
            outcome = poll_fn()
        except Exception:
            continue
        if dialog.iscanceled() or time.time() - start >= expires_in:
            dialog.close()
            return False
        if outcome == 'success':
            dialog.close()
            return True
        if outcome == 'denied':
            dialog.close()
            return False
        if outcome == 'slow_down':
            interval += 5


def _run_device_auth_window(service_name, user_code, verification_url,
                             verification_label, expires_in, interval, poll_fn):
    from .skin_support import use_native_dialogs
    if use_native_dialogs():
        return _run_plain_auth_dialog(service_name, user_code, verification_url,
                                      expires_in, interval, poll_fn)
    from queue import Queue, Empty
    started = time.monotonic()
    qr_path = ''
    dialog = None
    stop = threading.Event()
    outcomes = Queue()
    try:
        try:
            qr_path = _download_qr_code(verification_url)
        except Exception as exc:
            xbmc.log('Simkl QR unavailable: ' + type(exc).__name__, xbmc.LOGWARNING)
        remaining = max(0, expires_in - (time.monotonic() - started))
        if remaining <= 0:
            return False
        dialog = AuthDialog(
            'AuthDialog.xml', ADDON_PATH, 'Default', '720p',
            service_name=service_name, user_code=user_code,
            verification_url=verification_url, verification_label=verification_label,
            expires_in=int(remaining), qr_path=qr_path, icon_path=_simkl_icon())

        def poll():
            poll_interval = max(1, interval)
            while not stop.wait(poll_interval):
                if time.monotonic() - started >= expires_in:
                    return
                try:
                    outcome = poll_fn()
                except Exception as exc:
                    xbmc.log('Simkl auth poll error: ' + type(exc).__name__, xbmc.LOGWARNING)
                    continue
                if stop.is_set():
                    return
                if outcome == 'slow_down':
                    poll_interval += 5
                elif outcome in ('success', 'denied'):
                    outcomes.put(outcome)
                    return

        dialog.show()
        thread = threading.Thread(target=poll, name='vidcore-simkl-auth', daemon=True)
        thread.start()
        monitor = xbmc.Monitor()
        # Only this Kodi invoker reads/writes the dialog controls.
        while not monitor.abortRequested() and not dialog.canceled:
            xbmc.sleep(100)
            remaining = max(0, expires_in - (time.monotonic() - started))
            if dialog.canceled or remaining <= 0:
                return False
            if dialog.ready:
                dialog.update_remaining(remaining)
            elif time.monotonic() - started > 30:
                return False
            try:
                outcome = outcomes.get_nowait()
            except Empty:
                continue
            if outcome == 'success':
                dialog.mark_authorized()
                return True
            dialog.mark_denied()
            return False
        return False
    finally:
        stop.set()
        if dialog is not None:
            dialog.close()
        if qr_path:
            try:
                os.remove(qr_path)
            except OSError:
                pass


def authorize():
    cid, _ = _credentials()
    if not cid:
        xbmcgui.Dialog().notification(
            'Simkl', 'Please enter a Simkl client ID in Settings first',
            xbmcgui.NOTIFICATION_WARNING, 4000,
        )
        return False

    # The bundled VIDCORE client is registered as an OAuth 2.0 app.  SIMKL
    # therefore requires its device endpoint rather than /oauth/pin (which
    # returns unauthorized_client for this client type).
    try:
        verifier, challenge = _pkce_pair()
        status, data, _ = _http_form(
            '/oauth2/device',
            method='POST',
            payload={
                'client_id': cid,
                'scope': SIMKL_SCOPE,
                'code_challenge': challenge,
                'code_challenge_method': 'S256',
            },
        )
    except Exception as exc:
        xbmc.log(f'Simkl device authorization request failed: {exc}', xbmc.LOGWARNING)
        status, data = 0, None

    if status == 200 and isinstance(data, dict) and data.get('user_code') and data.get('device_code'):
        user_code = data.get('user_code')
        device_code = data.get('device_code')
        verification_url = (
            data.get('verification_uri')
            or data.get('verification_url')
            or 'https://simkl.com/pin'
        )
        verification_uri_complete = data.get('verification_uri_complete') or verification_url
        expires_in = int(data.get('expires_in') or 900)
        interval = max(2, int(data.get('interval') or 5))

        pending_token = []

        def _poll_device_code():
            status, tokdata, _ = _http_form(
                '/oauth2/token',
                method='POST',
                payload={
                    'client_id': cid,
                    'device_code': device_code,
                    'grant_type': 'urn:ietf:params:oauth:grant-type:device_code',
                    'code_verifier': verifier,
                },
            )
            if status == 0 or status == 429 or status >= 500:
                return None
            if isinstance(tokdata, dict):
                error = str(tokdata.get('error') or '').strip().lower()
                description = str(
                    tokdata.get('error_description') or tokdata.get('message') or ''
                ).replace('\r', ' ').replace('\n', ' ').strip()[:240]
                if status != 200 or error:
                    expected = error in ('authorization_pending', 'slow_down')
                    log_level = xbmc.LOGINFO if expected else xbmc.LOGWARNING
                    xbmc.log(
                        f'Simkl device token response: HTTP {status}; '
                        f'error={error or "none"}'
                        + (f'; description={description}' if description else ''),
                        log_level,
                    )
                if status == 200 and tokdata.get('access_token'):
                    # Commit only after the user-facing dialog accepts success.
                    pending_token[:] = [tokdata]
                    return 'success'
                if error == 'authorization_pending':
                    return None
                if error == 'slow_down':
                    return 'slow_down'
                if error:
                    return 'denied'

            # A malformed/expired device request must not be treated as a
            # pending authorization.  Otherwise the dialog keeps sending
            # /oauth2/token and produces a repeated 400 loop.
            if status >= 400:
                xbmc.log(
                    f'Simkl device token response: HTTP {status}; '
                    'no JSON error details returned',
                    xbmc.LOGWARNING,
                )
                return 'denied'

            return None

        ok = _run_device_auth_window(
            service_name='Simkl',
            user_code=user_code,
            verification_url=verification_uri_complete,
            verification_label=verification_url,
            expires_in=expires_in,
            interval=interval,
            poll_fn=_poll_device_code,
        )
        if ok and pending_token:
            _save_token(pending_token[0])
            ADDON.setSetting('simkl_auth_done', 'true')
            try:
                _refresh_profile()
            except Exception:
                pass
            xbmcgui.Dialog().notification('Simkl', 'Authorization successful', xbmcgui.NOTIFICATION_INFO, 3000)
            return True

        xbmcgui.Dialog().notification('Simkl', 'Device authorization timed out or failed', xbmcgui.NOTIFICATION_ERROR, 3500)
        return False

    detail = ''
    if isinstance(data, dict):
        detail = data.get('error_description') or data.get('message') or data.get('error') or ''
    xbmcgui.Dialog().notification(
        'Simkl',
        f'Device authorization failed ({status})' + (f': {detail}' if detail else ''),
        xbmcgui.NOTIFICATION_ERROR, 4000,
    )
    return False


def revoke():
    # AUTH V2 revokes the grant when either token is submitted. Always remove
    # local credentials, including when the remote service cannot be reached.
    token = _load_token() or {}
    value = token.get('refresh_token') or token.get('access_token')
    try:
        if value:
            cid, _ = _credentials()
            status, _data, _headers = _http_form('/oauth2/revoke', method='POST',
                payload={'client_id': cid, 'token': value}, timeout=8)
            if status != 200:
                xbmc.log('VIDCORE Simkl remote revocation unavailable; disconnecting locally', xbmc.LOGWARNING)
    except Exception as exc:
        xbmc.log('VIDCORE Simkl revocation failed: ' + type(exc).__name__, xbmc.LOGWARNING)
    finally:
        _delete_token()
    xbmcgui.Dialog().notification('Simkl', 'Simkl account disconnected', xbmcgui.NOTIFICATION_INFO, 3000)


def _build_item_payload(title, year='', tmdb='', imdb='', content='movie', season='', episode=''):
    payload = {'title': title or 'Untitled'}
    if year:
        try:
            payload['year'] = int(year)
        except ValueError:
            pass
    ids = {}
    if tmdb:
        try:
            ids['tmdb'] = int(tmdb)
        except ValueError:
            pass
    if imdb:
        ids['imdb'] = imdb
    if ids:
        payload['ids'] = ids
    if content == 'movie':
        return payload
    if content == 'show' or not season:
        return payload
    payload['season'] = int(season)
    payload['episode'] = int(episode)
    return payload


def _build_show_episode_payload(title, year='', tmdb='', imdb='', content='show',
                                 season='', episode='', watched_at=None):
    """Build the nested show payload used by Simkl list/history endpoints."""
    show = _build_item_payload(
        title=title,
        year=year,
        tmdb=tmdb,
        imdb=imdb,
        content=content,
    )
    try:
        season_no = int(season)
        episode_no = int(episode)
    except (TypeError, ValueError):
        return None

    episode_item = {'number': episode_no}
    if watched_at:
        episode_item['watched_at'] = watched_at
    show['seasons'] = [{
        'number': season_no,
        'episodes': [episode_item],
    }]
    return show


def sync_watchlist(force=False):
    _data, ok = _sync_snapshot(force=force)
    return ok


def _get_history(media_type):
    library, ok = _sync_snapshot()
    if library is None:
        return None
    return [row for row in library.get(media_type, {}).values()
            if row.get('status') == 'completed' or
            (media_type != 'movies' and (row.get('watched_episodes_count') or row.get('seasons')))]


def _get_list(list_name):
    if str(list_name).startswith('custom:'):
        return _CUSTOM_LIST_CACHE.get(str(list_name), [])
    media = None
    if ':' in str(list_name):
        media, list_name = list_name.split(':', 1)
    library, _ok = _sync_snapshot()
    if library is None:
        return None
    return [(kind, item) for kind, rows in library.items() for item in rows.values()
            if (not media or kind == media) and item.get('status') == list_name]


def _invalidate_ratings_cache():
    from . import simkl_store
    simkl_store.invalidate(DATA_PATH, _account_cache_key())


def _refresh_profile():
    """Recover profile identity for existing authorizations as well as new ones."""
    headers = _auth_headers()
    if not headers:
        return False
    data, _ok = _sync_snapshot(resource=lambda a: (
        '/users/settings', {}, (a.get('settings') or {}).get('all')))
    if not isinstance(data, dict):
        return False
    user = data.get('user') or {}
    name = user.get('name') or user.get('username') or ''
    user_id = (data.get('account') or {}).get('id') or user.get('id') or user.get('user_id')
    ADDON.setSetting('simkl_username', str(name))
    ADDON.setSetting('simkl_user_id', str(user_id or ''))
    return bool(user_id)
