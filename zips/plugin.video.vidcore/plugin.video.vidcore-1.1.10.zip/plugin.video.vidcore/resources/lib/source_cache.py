"""Short-lived source hints and recent provider health, cleared with caches."""
import json
import time
import math
from . import metadata_cache


class SourceCache:
    def __init__(self, media, root=None):
        if root is None:
            import xbmcvfs
            root = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.vidcore/metadata_cache')
        self.root = root
        try:
            self.generation = metadata_cache.generation(root)
        except (OSError, metadata_cache.sqlite3.Error):
            self.generation = None
        self.media = 'vidcore:sources:v1:' + json.dumps(media, separators=(',', ':'))
        self.previous = metadata_cache.get(root, self.media)
        if not isinstance(self.previous, dict):
            self.previous = {}
        if not isinstance(self.previous.get('discovery'), dict):
            self.previous.pop('discovery', None)
        streams = self.previous.get('streams')
        self.previous['streams'] = ({key: value for key, value in streams.items()
                                     if isinstance(value, dict)} if isinstance(streams, dict) else {})
        self.reused_discovery = bool(self.discovery())
        self.health = metadata_cache.get(root, 'vidcore:source-health:v1')
        if not isinstance(self.health, dict):
            self.health = {}

    def _save(self, key, value, ttl):
        if self.generation is not None:
            metadata_cache.put(self.root, key, value, ttl, generation=self.generation)

    def discovery(self):
        rows = self.previous.get('discovery') or {}
        saved = self.previous.get('discovery_times') or {}
        if not isinstance(rows, dict) or not isinstance(saved, dict):
            return None
        now = time.time()
        fresh = {}
        for name, value in rows.items():
            try:
                age = now - float(saved.get(name, 0))
            except (ValueError, TypeError, OverflowError):
                continue
            if value and 0 <= age < 180:
                fresh[name] = value
        return fresh or None

    def save_discovery(self, value):
        rows = self.previous.setdefault('discovery', {})
        saved = self.previous.setdefault('discovery_times', {})
        if not isinstance(rows, dict):
            rows = self.previous['discovery'] = {}
        if not isinstance(saved, dict):
            saved = self.previous['discovery_times'] = {}
        for name, result in value.items():
            rows[name] = result
            saved[name] = time.time()
        self._save(self.media, self.previous, 180)

    @staticmethod
    def key(key):
        return json.dumps(key, separators=(',', ':'))

    def stream(self, key):
        stream = self.previous.get('streams', {}).get(self.key(key))
        if (isinstance(key, tuple) and key[0] == 'RiveStream'
                and key[1] in ('mirage', 'apogee', 'vanguard')
                and stream and not stream.get('rivestream_refresh')):
            # Re-resolve pre-renewal hints rather than play an expiring URL
            # without knowing which provider/title must refresh it.
            return None
        return stream

    def success(self, key, stream):
        # Stateful openers/cookie jars cannot be reconstructed from JSON.
        if stream.get('opener') is not None:
            return
        fields = ('url', 'type', 'headers', 'label', 'minimum_duration', 'advertised_heights',
                  'native_hls', 'refresh_tokens', 'vidbolt_backend', 'rivestream_refresh')
        safe = {field: stream[field] for field in fields if field in stream}
        self.previous.setdefault('streams', {})[self.key(key)] = safe
        self._save(self.media, self.previous, 180)

    def record(self, key, success, elapsed):
        name = key[0] + '/' + str(key[1]) if isinstance(key, tuple) else str(key)
        row = self.health[name] = self._health_row(name)
        try:
            elapsed = float(elapsed)
            if not math.isfinite(elapsed) or elapsed < 0:
                elapsed = 10.0
        except (ValueError, TypeError, OverflowError):
            elapsed = 10.0
        row['score'] = .7 * row['score'] + .3 * int(success)
        row['seconds'] = .7 * row['seconds'] + .3 * elapsed
        row['updated'] = time.time()
        self._save('vidcore:source-health:v1', self.health, 3600)

    def rank(self, job):
        key = job[0]
        name = key[0] + '/' + str(key[1]) if isinstance(key, tuple) else str(key)
        row = self._health_row(name)
        return (-row['score'], row['seconds'])

    def _health_row(self, name):
        row = self.health.get(name)
        if not isinstance(row, dict):
            row = {}
        result = {}
        for key, fallback in (('score', .5), ('seconds', 10.0)):
            try:
                value = float(row.get(key, fallback))
                if not math.isfinite(value) or value < 0 or (key == 'score' and value > 1):
                    value = fallback
            except (ValueError, TypeError, OverflowError):
                value = fallback
            result[key] = value
        return result
