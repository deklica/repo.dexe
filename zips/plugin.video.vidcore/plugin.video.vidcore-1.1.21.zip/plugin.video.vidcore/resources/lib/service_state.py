"""Validate playback-service heartbeats without trusting damaged timestamps."""
import math
import time


def is_recent(value, now=None, maximum_age=10):
    try:
        age = (time.time() if now is None else now) - float(value)
    except (TypeError, ValueError, OverflowError):
        return False
    return math.isfinite(age) and 0 <= age <= maximum_age
