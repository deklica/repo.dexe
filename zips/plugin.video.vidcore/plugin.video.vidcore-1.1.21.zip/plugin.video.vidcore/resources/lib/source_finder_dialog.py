"""Vidcore source picker. Derived from Cosmos by Zeus768, GPL-2.0-only."""

# =============================================================================
# Live source picker controls and selection
# =============================================================================
import threading
import time
import xbmc
import xbmcgui
import xbmcaddon
ADDON_PATH = xbmcaddon.Addon('plugin.video.vidcore').getAddonInfo('path')
_LP_LIST = 4001
_LP_PLAY = 4003

# --- Shared provider, host and stream picker -------------------------------
class LinkPickerDialog(xbmcgui.WindowXMLDialog):
    """Browse live provider, host and stream rows in Vidcore's bundled UI.

    Return a selected row index, or None on Back/Cancel. Persistent sessions
    reuse the visible window while navigating between providers and streams.
    """

    def __init__(self, *args, **kwargs):
        self.quality_label = kwargs.pop('quality_label', '')
        self.group_name = kwargs.pop('group_name', '')
        self.picker_mode = kwargs.pop('picker_mode', 'sources')
        self.keep_open = kwargs.pop('keep_open', False)
        self._shown = False
        self.poster = kwargs.pop('poster', '')
        self.icon_path = kwargs.pop('icon_path', '')
        self.links = kwargs.pop('links', [])
        self.media_info = kwargs.pop('media_info', {})
        self.links_provider = kwargs.pop('links_provider', None)
        self.scan_state = kwargs.pop('scan_state', None)
        self.media_provider = kwargs.pop('media_provider', None)
        self._closed = threading.Event()
        self._ready = threading.Event()
        self.current_index = 0
        self.selected_index = None
        self._next_live_update = 0.0
        super().__init__(*args, **kwargs)

    def _refresh_selection_banner(self):
        if not self.links:
            self.setProperty('lp_play_enabled', 'false')
            self.setProperty('lp_play_label', 'Checking sources…' if getattr(self, '_scan_active', False) else 'No sources available')
            return
        self.setProperty('lp_play_enabled', 'true')
        item = self.links[self.current_index]
        try:
            self.setProperty('lp_sel_icon', self.icon_path or '')
            self.setProperty('lp_sel_title', item.get('label', ''))
            self.setProperty('lp_sel_meta', item.get('meta', ''))
            self.setProperty('lp_sel_cache', item.get('cache_label', 'UNKNOWN'))
            self.setProperty('lp_sel_format', item.get('format_label', 'AUTO'))
            self.setProperty('lp_play_label', item.get('action_label') or 'Play ' + item.get('label', 'source'))
        except Exception as e:
            xbmc.log(f'LinkPickerDialog banner error: {e}', xbmc.LOGERROR)

    def onInit(self):
        try:
            self.setProperty('lp_quality_label', self.quality_label)
            self.setProperty('lp_group_title', (self.group_name + ' streams') if self.group_name else 'Choose a stream')
            heading = ('Choose an episode host' if self.picker_mode == 'hosts' else
                       self.group_name + ' streams' if self.group_name else 'Choose your source')
            self.setProperty('lp_picker_heading', heading)
            self.setProperty('lp_picker_brand', 'SRSTOP' if self.picker_mode == 'hosts' else
                             'STREAMS' if self.group_name else 'SOURCE PICKER')
            self.setProperty('lp_picker_subtitle', 'Choose a stream to play. Back returns to providers.'
                             if self.group_name else 'Verified hosts for this episode. Select one to play.'
                             if self.picker_mode == 'hosts' else 'Sources appear here as soon as they are ready.')
            self.setProperty('lp_poster', self.poster or '')
            self.setProperty('lp_count', str(len(self.links)))
            self._scan_summary = 'Checking more sources…' if self.scan_state is not None else 'Ready'
            self.setProperty('lp_scan_status', '%d available · %s' % (len(self.links), self._scan_summary))
            self.setProperty('lp_empty_message', 'Finding and checking sources…')
            self._scan_active = self.scan_state is not None
            self.setProperty('lp_play_enabled', 'false')
            self.setProperty('lp_play_label', 'Checking sources…' if self._scan_active else 'No sources available')
            for key in ('title', 'subtitle', 'context', 'facts', 'genres', 'plot', 'art'):
                self.setProperty('lp_media_' + key, str(self.media_info.get(key) or ''))
        except Exception as e:
            xbmc.log(f'LinkPickerDialog header error: {e}', xbmc.LOGERROR)

        try:
            listctl = self.getControl(_LP_LIST)
            listctl.reset()
            for i, item in enumerate(self.links):
                li = xbmcgui.ListItem(label=item.get('label', ''))
                li.setProperty('source_index', str(i + 1))
                li.setProperty('meta', item.get('meta', ''))
                li.setProperty('icon', item.get('icon') or self.icon_path or '')
                li.setProperty('cache_label', item.get('cache_label', 'UNKNOWN'))
                li.setProperty('format_label', item.get('format_label', 'AUTO'))
                li.setProperty('selected', 'true' if i == self.current_index else 'false')
                listctl.addItem(li)
            if self.links:
                listctl.selectItem(self.current_index)
        except Exception as e:
            xbmc.log(f'LinkPickerDialog list error: {e}', xbmc.LOGERROR)

        self._refresh_selection_banner()

        # The list is now populated: start remote navigation on the sources.
        if self.links:
            self.setFocusId(_LP_LIST)
        else:
            self.setFocusId(4006)
        self._navigation_hint(_LP_LIST)
        self._ready.set()

    def close(self):
        self._closed.set()
        if not self.keep_open:
            super().close()

    # --- Reuse the visible window while entering/leaving provider groups ---
    def configure(self, **values):
        for name, value in values.items():
            setattr(self, name, value)
        self.current_index = 0
        self.selected_index = None
        self._next_live_update = 0.0

    def dispose(self):
        self.keep_open = False
        self.close()
        self._shown = False

    # --- Update live ---
    def _update_live(self):
        # Keep remote events responsive at 50 ms without rebuilding source
        # summaries and querying metadata twenty times a second.
        now = time.monotonic()
        if now < self._next_live_update:
            return
        self._next_live_update = now + .25
        if self.scan_state is not None:
            _results, count, total, active = self.scan_state()
            self._scan_active = active
            if not self.links:
                self._refresh_selection_banner()
            self._scan_summary = '%d still checking' % max(0, total - count) if active else (
                'Scan complete' if count == total else 'Scan time limit reached')
            message = 'Finding and checking sources…' if active else 'No playable sources found. Back to return.'
            if self.getProperty('lp_empty_message') != message:
                self.setProperty('lp_empty_message', message)
        if self.media_provider is not None:
            details = self.media_provider()
            for key in ('title', 'subtitle', 'context', 'facts', 'genres', 'plot', 'art'):
                value = str(details.get(key) or '')
                if self.getProperty('lp_media_' + key) != value:
                    self.setProperty('lp_media_' + key, value)
        if self.links_provider is None:
            status = '%d available · %s' % (len(self.links), self._scan_summary)
            if self.getProperty('lp_scan_status') != status:
                self.setProperty('lp_scan_status', status)
            return
        rows = self.links_provider()
        status = '%d available · %s' % (len(rows), self._scan_summary)
        if self.getProperty('lp_scan_status') != status:
            self.setProperty('lp_scan_status', status)
        if rows == self.links:
            return
        listing = self.getControl(_LP_LIST)
        position = listing.getSelectedPosition()
        key = self.links[position].get('key') if 0 <= position < len(self.links) else None
        focus = self.getFocusId()
        was_empty = not self.links
        previous = self.links
        self.links = rows
        position = next((index for index, row in enumerate(rows) if row.get('key') == key), 0)
        # Keep the live list attached: reset() briefly empties it and moves
        # focus on every source arrival or quality/count change.
        for index, row in enumerate(rows):
            existing = index < len(previous)
            item = listing.getListItem(index) if existing else xbmcgui.ListItem()
            old = previous[index] if existing else {}
            if not existing or old.get('label') != row.get('label'):
                item.setLabel(row.get('label', ''))
            if not existing:
                item.setProperty('source_index', str(index + 1))
            for name in ('meta', 'icon', 'cache_label', 'format_label'):
                if not existing or old.get(name) != row.get(name):
                    item.setProperty(name, str(row.get(name) or ''))
            if not existing or (index == self.current_index) != (index == position):
                item.setProperty('selected', 'true' if index == position else 'false')
            if not existing:
                listing.addItem(item)
        if not rows and focus in (_LP_LIST, 4002, _LP_PLAY):
            self.setFocusId(4006)
            focus = 4006
        for index in range(len(previous) - 1, len(rows) - 1, -1):
            listing.removeItem(index)
        if rows:
            if listing.getSelectedPosition() != position:
                listing.selectItem(position)
            self.current_index = position
            self._refresh_selection_banner()
            if was_empty and focus == 4006:
                focus = _LP_LIST
        else:
            self.current_index = 0
            for name in ('title', 'meta', 'icon', 'cache', 'format'):
                self.setProperty('lp_sel_' + name, '')
            self._refresh_selection_banner()
            if focus in (_LP_LIST, 4002, _LP_PLAY):
                focus = 4005
        self.setProperty('lp_count', str(len(rows)))
        if self.getFocusId() != focus:
            self.setFocusId(focus)
        self._navigation_hint(focus)

    def doModal(self):
        if self.links_provider is None and not self.keep_open:
            return super().doModal()
        # Kodi callbacks and list updates run on this invoker, never workers.
        self._closed.clear()
        self._ready.clear()
        if self._shown:
            self.onInit()
        else:
            self.show()
            self._shown = True
        monitor = xbmc.Monitor()
        started = time.monotonic()
        while not self._closed.is_set() and not monitor.abortRequested():
            xbmc.sleep(50)
            if self._closed.is_set():
                break
            if self._ready.is_set():
                self._update_live()
            elif time.monotonic() - started > 5:
                self.close()
        if not self._closed.is_set():
            self.close()

    def _mark_current(self, new_index):
        try:
            listctl = self.getControl(_LP_LIST)
            size = listctl.size()
            if self.current_index != new_index and 0 <= self.current_index < size:
                listctl.getListItem(self.current_index).setProperty('selected', 'false')
            if 0 <= new_index < size:
                listctl.getListItem(new_index).setProperty('selected', 'true')
        except Exception as e:
            xbmc.log(f'LinkPickerDialog mark error: {e}', xbmc.LOGERROR)
        self.current_index = new_index
        self._refresh_selection_banner()

    def _sync_highlighted_source(self):
        """Keep the preview and Play target aligned with the list cursor."""
        try:
            pos = self.getControl(_LP_LIST).getSelectedPosition()
        except Exception:
            return
        if 0 <= pos < len(self.links) and pos != self.current_index:
            self._mark_current(pos)

    def onFocus(self, controlId):
        self._sync_highlighted_source()
        self._navigation_hint(controlId)

    def _navigation_hint(self, control_id):
        if control_id == 4006:
            hint = 'OK: return · Back: return'
        elif control_id == _LP_PLAY:
            hint = 'OK: play · Left/Up: sources · Back: return'
        elif control_id == 4005:
            hint = 'Up/Down: scroll plot · Right: sources · Back: return'
        else:
            hint = 'OK: play · Left: plot · Right: Play · Back: return'
        self.setProperty('lp_navigation', hint)

    def onClick(self, controlId):
        if controlId == 4006:
            self.selected_index = None
            self.close()
        elif controlId == _LP_LIST:
            try:
                pos = self.getControl(_LP_LIST).getSelectedPosition()
            except Exception:
                pos = -1
            if 0 <= pos < len(self.links):
                _item = self.links[pos]
                xbmc.log(
                    f'VIDCORE [CLICK] LinkPicker  list click  pos={pos}'
                    f'  label={_item.get("label","")[:80]!r}',
                    xbmc.LOGDEBUG,
                )
                # Clicking a link plays it directly - no need to highlight
                # it first and then hit the separate Play button.
                self._mark_current(pos)
                self.selected_index = pos
                self.close()
        elif controlId == _LP_PLAY:
            self._sync_highlighted_source()
            xbmc.log(
                f'VIDCORE [CLICK] LinkPicker  Play button  current_index={self.current_index}',
                xbmc.LOGDEBUG,
            )
            try:
                pos = self.getControl(_LP_LIST).getSelectedPosition()
            except Exception:
                return
            if 0 <= pos < len(self.links):
                self.selected_index = pos
                self.close()

    def onAction(self, action):
        self._sync_highlighted_source()
        if action.getId() in (
            xbmcgui.ACTION_NAV_BACK,
            xbmcgui.ACTION_PREVIOUS_MENU,
        ):
            xbmc.log(
                f'VIDCORE [CLICK] LinkPicker  back/cancel action={action.getId()}',
                xbmc.LOGDEBUG,
            )
            self.selected_index = None
            self.close()
