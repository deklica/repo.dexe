# -*- coding: utf-8 -*-
"""Built-in Streamtape, Byse and Vidara resolvers used by Vidcore.

Return a playable URL or None, with optional Kodi request headers.
"""

# =============================================================================
# Streamtape, Byse and Vidara player resolvers
# =============================================================================
import re
import json
import base64
import time
from http.cookiejar import CookieJar
from html import unescape
from urllib.parse import urlparse, urlencode, parse_qs
from urllib.request import urlopen, Request, build_opener, HTTPCookieProcessor
from urllib.error import HTTPError, URLError

import xbmc

from .aesgcm import aes_gcm_decrypt
from . import srstop_hosts, srstop

# Debug bundler — optional; no-ops gracefully when disabled or not installed
try:
    from . import debug_bundle as _db
    def _dblog(tag, detail): _db.log(tag, detail)
except Exception:
    def _dblog(tag, detail): pass

UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
      '(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36')

# Streamtape callers use this to distinguish removed content from other failures.
_last_resolver_error = ''


# --- HTTP request transport and diagnostics --------------------------------
def _post(url, data, referer=None, timeout=20, extra_headers=None, opener=None):
    """POST form-data to *url*. *data* is a dict encoded as application/x-www-form-urlencoded."""
    from urllib.parse import urlencode as _urlencode
    headers = {
        'User-Agent': UA,
        'Accept': 'application/json, text/javascript, */*; q=0.01',
        'Accept-Language': 'en-US,en;q=0.9',
        'Content-Type': 'application/x-www-form-urlencoded',
        'X-Requested-With': 'XMLHttpRequest',
    }
    if referer:
        headers['Referer'] = referer
        p = urlparse(referer)
        if p.netloc:
            headers['Origin'] = f'{p.scheme}://{p.netloc}'
    if extra_headers:
        headers.update(extra_headers)
    post_data = _urlencode(data).encode('utf-8') if isinstance(data, dict) else data
    short_data = (data if isinstance(data, str) else str(data))[:120]
    _dblog('POST→', f'{url}  data={short_data}')
    try:
        req = Request(url, data=post_data, headers=headers)
        open_url = opener.open if opener is not None else urlopen
        with open_url(req, timeout=timeout) as r:
            raw = r.read(2 * 1024 * 1024 + 1)
            if len(raw) > 2 * 1024 * 1024:
                return '', r.url
            body = raw.decode('utf-8', errors='replace')
            _dblog('POST←', f'{len(body)}B  preview={body[:200]}')
            return body, r.url
    except (HTTPError, URLError, OSError) as e:
        xbmc.log(f'VIDCORE resolver POST failed {url}: {e}', xbmc.LOGWARNING)
        _dblog('POST-FAIL', f'{url}  error={e}')
        return '', url


def _fetch(url, referer=None, timeout=20, extra_headers=None, opener=None):
    headers = {
        'User-Agent': UA,
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9',
    }
    if referer:
        headers['Referer'] = referer
    if extra_headers:
        headers.update(extra_headers)
    _dblog('GET→', url)
    try:
        req = Request(url, headers=headers)
        open_url = opener.open if opener is not None else urlopen
        with open_url(req, timeout=timeout) as r:
            raw = r.read(2 * 1024 * 1024 + 1)
            if len(raw) > 2 * 1024 * 1024:
                return '', r.url
            body = raw.decode('utf-8', errors='replace')
            _dblog('GET←', f'{len(body)}B  final={r.url}')
            return body, r.url
    except (HTTPError, URLError, OSError) as e:
        xbmc.log(f'VIDCORE resolver fetch failed {url}: {e}', xbmc.LOGWARNING)
        _dblog('GET-FAIL', f'{url}  error={e}')
        return '', url
    except Exception as e:
        xbmc.log(f'VIDCORE resolver fetch error {url}: {e}', xbmc.LOGERROR)
        _dblog('GET-ERR', f'{url}  error={e}')
        return '', url


# --- One cookie session and total time budget per API resolver ---------------
def _session_requests(timeout=40):
    opener = build_opener(HTTPCookieProcessor(CookieJar()))
    deadline = time.monotonic() + timeout
    def call(operation, *args, **kwargs):
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise srstop.SourceError('Player API resolution timed out. Choose another host.')
        kwargs.update(timeout=min(8, remaining), opener=opener)
        return operation(*args, **kwargs)
    return (lambda *a, **k: call(_post, *a, **k),
            lambda *a, **k: call(_fetch, *a, **k))


# ── Packed JS unpacker (Dean Edwards p,a,c,k,e,d) ─────────────────────────


# --- Packed JavaScript decoding --------------------------------------------
def _unpack(packed_js):
    """Share the bounded, single-pass player unpacker used by LuluStream."""
    from .lulustream import _unpack as unpack
    return '\n'.join(unpack(packed_js))


# ── Streamtape ────────────────────────────────────────────────────────────
# --- Streamtape URL extraction and resolution ------------------------------
def _is_streamtape(url):
    return srstop_hosts.is_domain('Streamtape', url)


def _streamtape_expression(expression):
    """Decode only string concatenation and numeric substring/slice calls."""
    rest, chunks = expression.strip(), []
    while rest:
        wrapped = rest.startswith('(')
        if wrapped:
            rest = rest[1:].lstrip()
        match = re.match(r"""(["'])((?:\\.|(?!\1).)*)\1""", rest, re.S)
        if not match:
            return ''
        value = re.sub(r'\\([/\\\x27"])', r'\1', match[2])
        rest = rest[match.end():].lstrip()
        if wrapped:
            if not rest.startswith(')'):
                return ''
            rest = rest[1:].lstrip()
        while rest.startswith('.'):
            operation = re.match(r'\.(?:substring|slice)\(\s*(\d+)\s*\)', rest)
            if not operation:
                return ''
            value = value[int(operation[1]):]
            rest = rest[operation.end():].lstrip()
        chunks.append(value)
        if not rest:
            break
        if not rest.startswith('+'):
            return ''
        rest = rest[1:].lstrip()
        if not rest:
            return ''
    return unescape(''.join(chunks))


def _streamtape_media_url(body):
    # Later assignments replace earlier decoy values. Do not execute page JS.
    assignments = re.findall(
        r"""document\.getElementById\(\s*['"](?:robotlink|ideoolink|videolink|botlink)['"]\s*\)\.innerHTML\s*=\s*([^;]+);""",
        body)
    for expression in reversed(assignments):
        value = _streamtape_expression(expression)
        if value.startswith('//'):
            value = 'https:' + value
        parts = urlparse(value)
        if (parts.scheme in ('http', 'https') and _is_streamtape(value)
                and parts.path == '/get_video' and parse_qs(parts.query).get('id')
                and parse_qs(parts.query).get('token')):
            if 'stream' not in parse_qs(parts.query):
                value += '&stream=1'
            return value
    return None


def resolve_streamtape(url):
    global _last_resolver_error
    _last_resolver_error = ''
    if not srstop_hosts.matches('Streamtape', url):
        return None
    parsed = urlparse(url)
    path = parsed.path or '/'
    m = re.search(r'/(?:e|v|embed)/([A-Za-z0-9_\-]+)', path, re.I)
    if not m:
        return None
    vid = m.group(1)
    host = parsed.netloc
    embed = f'{parsed.scheme}://{host}/e/{vid}'
    if parsed.query:
        embed += '?' + parsed.query
    try:
        with urlopen(Request(embed, headers={'User-Agent': UA,
                                             'Referer': f'https://{host}/'}),
                     timeout=12) as response:
            html = response.read(2 * 1024 * 1024 + 1).decode('utf-8', errors='replace')
            embed = response.geturl()
    except HTTPError as exc:
        if exc.code in (404, 410):
            _last_resolver_error = 'removed'
        return None
    except (URLError, OSError):
        return None
    if not srstop_hosts.accept_redirect('Streamtape', url, embed):
        return None
    if not html:
        return None
    if re.search(r'Video\s+(?:not found|has been (?:removed|deleted))', html, re.I):
        _last_resolver_error = 'removed'
        return None
    media = _streamtape_media_url(html)
    if media:
        return media + '|' + urlencode({'User-Agent': UA, 'Referer': embed})
    return None


# --- Byse key decoding and source decryption -------------------------------
def _byse_b64url_decode(s):
    s = s.replace('-', '+').replace('_', '/')
    s += '=' * ((-len(s)) % 4)
    return base64.b64decode(s)


def _byse_key_slots(version, n_parts):
    """Return the two 1-based slot indices for the AES key.

    Original scheme (versions 1-20): slots are [v, 31-v].
    Extended scheme (versions 21+): slots are [v, (n_parts+1-v)], which
    generalises the mirror pattern to arbitrary table sizes.
    """
    try:
        v = int(str(version).strip())
    except (TypeError, ValueError):
        return []

    # ── Original scheme: version 1-20, table of exactly 30 parts ──────────
    if 1 <= v <= 20:
        a, b = v, 31 - v
        if 1 <= a <= n_parts and 1 <= b <= n_parts:
            return [a, b]

    # ── Extended scheme: generalised mirror for larger tables ──────────────
    if 1 <= v <= n_parts:
        a = v
        b = n_parts + 1 - v
        if a != b and 1 <= b <= n_parts:
            return [a, b]

    return []


# --- Playback schema normalization and authenticated key rotation -----------
def _playback_blob(data, depth=0):
    if not isinstance(data, dict) or depth > 3:
        return None
    if isinstance(data.get('key_parts'), list):
        return data
    for key in ('playback', 'data', 'video'):
        found = _playback_blob(data.get(key), depth + 1)
        if found is not None:
            return found
    return None


def _decrypt_playback(data):
    blob = _playback_blob(data)
    if not blob:
        return None
    parts = blob.get('key_parts')
    if not 1 <= len(parts) <= 128 or any(not isinstance(p, str) or len(p) > 128 for p in parts):
        return None
    try:
        decoded = [_byse_b64url_decode(part) for part in parts]
        iv = _byse_b64url_decode(blob.get('iv', ''))
        payload = _byse_b64url_decode(blob.get('payload', ''))
    except (ValueError, TypeError, AttributeError):
        return None
    if len(iv) != 12 or not 16 <= len(payload) <= 2 * 1024 * 1024:
        return None
    slots = _byse_key_slots(blob.get('version'), len(parts))
    candidates = []
    if slots:
        candidates.append(b''.join(decoded[i - 1] for i in slots))
    # Current players concatenate every part when there is no slot mapping.
    candidates.append(b''.join(decoded))
    candidates.extend(decoded[i] + decoded[-1 - i] for i in range(len(parts) // 2))
    seen = set()
    for key in candidates:
        if len(key) not in (16, 24, 32) or key in seen:
            continue
        seen.add(key)
        try:
            value = json.loads(aes_gcm_decrypt(key, iv, payload))
            if isinstance(value, dict):
                return value
        except (ValueError, UnicodeError):
            continue
    return None


def _source_rows(data, depth=0):
    if isinstance(data, list):
        return [row for row in data if isinstance(row, dict)]
    if not isinstance(data, dict) or depth > 3:
        return []
    for key in ('sources', 'data', 'video'):
        rows = _source_rows(data.get(key), depth + 1)
        if rows:
            return rows
    return []


def _byse_pick_source(sources):
    """From a Fiilemoon /api/source data list, return the best (stream, type) pair.

    Prefers MP4 over HLS — MP4 is a single request so Kodi's header
    propagation issues in adaptive-stream chains do not apply.
    Returns (url_string, type_string) or ('', '').
    """
    if not isinstance(sources, list) or not sources:
        return ('', '')
    sources = [s for s in sources if isinstance(s, dict)
               and isinstance(s.get('file'), str) and s['file'].strip()]
    mp4s = [s for s in sources
            if str(s.get('type') or '').lower() in ('mp4', 'video/mp4')
            and s.get('file')]
    hls  = [s for s in sources
            if str(s.get('type') or '').lower() in ('hls', 'm3u8', 'application/x-mpegurl')
            or '.m3u8' in (s.get('file') or '')]
    others = [s for s in sources if s.get('file')]
    if mp4s:
        def quality(source):
            from .source_quality import advertised_heights
            heights = advertised_heights(str(source.get('label') or ''))
            if heights:
                return heights[0]
            match = re.search(r'\d+', str(source.get('label') or ''))
            return int(match.group()) if match else 0
        mp4s.sort(key=quality, reverse=True)
        return (mp4s[0]['file'], 'mp4')
    if hls:
        f = hls[0].get('file') or ''
        return (f, 'hls') if f else ('', '')
    if others:
        return (others[0].get('file') or '', 'unknown')
    return ('', '')


# --- Byse player API resolution --------------------------------------------
def resolve_bysesukior(url):
    """Use the current Byse settings/playback API, retaining legacy players."""
    if not srstop_hosts.matches('Byse', url):
        return None
    parsed = urlparse(url)
    code = srstop_hosts.file_code('Byse', url)
    origin = parsed.scheme + '://' + parsed.netloc
    embed = f'{origin}/e/{code}' + ('?' + parsed.query if parsed.query else '')
    post, fetch = _session_requests(timeout=55)
    parent = embed
    body, _ = fetch(origin + f'/api/videos/{code}/details', referer=embed,
                    extra_headers={'Accept': 'application/json'})
    try:
        details = json.loads(body)
    except (ValueError, TypeError):
        details = None
    frame = details.get('embed_frame_url') if isinstance(details, dict) else None
    frame_parts = srstop_hosts.parts(frame) if isinstance(frame, str) else None
    if frame_parts:
        origin = frame_parts.scheme + '://' + frame_parts.netloc
        embed = origin + '/'
    api_headers = {'Accept': 'application/json', 'Origin': origin, 'Referer': embed}
    if frame_parts:
        api_headers['X-Embed-Parent'] = parent

    def result(data):
        nonlocal embed, origin
        decoded = _decrypt_playback(data)
        stream = _byse_encrypted_source(_source_rows(decoded or data))
        if not stream:
            stream, _ = _byse_pick_source(_source_rows(data))
        if stream and urlparse(stream).scheme in ('http', 'https'):
            return stream + '|' + urlencode({'User-Agent': UA, 'Referer': embed, 'Origin': origin})
        return None

    # Current frontend requests settings before posting to the playback route.
    for prefix in ('', 'embed/'):
        settings_url = f'{origin}/api/videos/{code}/{prefix}settings'
        body, _ = fetch(settings_url, referer=embed, extra_headers=api_headers)
        try:
            settings = json.loads(body)
        except (ValueError, TypeError):
            settings = None
        if not isinstance(settings, dict) or not any(
                key in settings for key in ('captcha_required', 'premium_only', 'download_allowed')):
            continue
        if settings.get('captcha_required'):
            from . import byse_challenge
            monitor_factory = getattr(xbmc, 'Monitor', None)
            monitor = monitor_factory() if monitor_factory else None
            cancelled = monitor.abortRequested if monitor is not None else None
            data = byse_challenge.playback(post, origin, code, prefix, api_headers, UA,
                                           cancelled=cancelled)
        else:
            playback_url = f'{origin}/api/videos/{code}/{prefix}playback'
            body, final = post(playback_url, data=b'{}', referer=embed,
                               extra_headers=dict(api_headers, **{'Content-Type': 'application/json'}))
            if not frame_parts:
                embed = srstop_hosts.player_after_api_redirect('Byse', embed, playback_url, final)
                origin = urlparse(embed).scheme + '://' + urlparse(embed).netloc
            try:
                data = json.loads(body)
            except (ValueError, TypeError):
                data = None
        resolved = result(data)
        if resolved:
            return resolved
        # A recognized modern player has no legacy endpoints to probe.
        return None

    api_url = f'{origin}/api/source/{code}'
    body, final = post(api_url, data={'r': embed, 'd': parsed.hostname}, referer=embed)
    embed = srstop_hosts.player_after_api_redirect('Byse', embed, api_url, final)
    migrated = urlparse(embed)
    origin = migrated.scheme + '://' + migrated.netloc
    for attempt in range(3):
        try:
            resolved = result(json.loads(body))
        except (ValueError, TypeError):
            resolved = None
        if resolved:
            return resolved
        if attempt < 2:
            path = f'/api/videos/{code}' if attempt == 0 else f'/api/source/{code}'
            body, _ = fetch(origin + path, referer=embed, extra_headers={'Accept': 'application/json'})
    return None


# --- Encrypted Byse source selection ---------------------------------------
def _byse_encrypted_source(sources):
    """Select usable encrypted-response rows without trusting height types."""
    if not isinstance(sources, list):
        return ''
    rows = [row for row in sources if isinstance(row, dict)
            and isinstance(row.get('url'), str) and row['url'].strip()]
    def height(row):
        value = str(row.get('height') or '')
        from .source_quality import advertised_heights
        heights = advertised_heights(value)
        if heights:
            return heights[0]
        match = re.fullmatch(r'\d+', value.strip())
        return int(match[0]) if match else 0
    return max(rows, key=height)['url'] if rows else ''


_VIDARA_STREAM_RE = re.compile(
    r'["\']?(?:file|src|url)["\']?\s*[:=]\s*["\']'
    r'(https?://[^"\']+\.(?:m3u8|mp4)[^"\']*)["\']',
    re.IGNORECASE,
)


# --- Vidara source selection and resolution --------------------------------
def _vidara_pick_best(sources):
    """Pick the best stream from a Filelions-style sources list.

    Prefers HLS (type='hls' or .m3u8 URL) then highest-label mp4.
    Returns the chosen ``file`` URL string, or '' if nothing usable.
    """
    if not isinstance(sources, list) or not sources:
        return ''
    sources = [s for s in sources if isinstance(s, dict)
               and isinstance(s.get('file'), str)
               and s['file'].startswith(('https://', 'http://'))]
    hls = [s for s in sources if 'hls' in str(s.get('type') or '').lower()
           or '.m3u8' in s['file'].lower()]
    if hls:
        return hls[0].get('file') or ''
    # Auto/non-numeric labels rank below advertised resolutions.
    def quality(row):
        from .source_quality import advertised_heights
        heights = advertised_heights(str(row.get('label') or ''))
        if heights:
            return heights[0]
        match = re.search(r'\d+', str(row.get('label') or ''))
        return int(match[0]) if match else 0
    return max(sources, key=quality)['file'] if sources else ''


def resolve_vidara(url):
    """Resolve a vidara.so /e/<ID> embed page to a direct HLS or mp4 stream.

    Tries strategies in order:
      1. POST /api/stream — JSON body {filecode, device:"web"} → streaming_url
         (the real player API discovered by reading the inline JS; this is what
         the browser uses and it returns a signed HLS URL directly)
      2. POST /api/source/<code> — form-encoded (legacy Filelions API)
      3. POST /api/source/<code> — JSON body (newer Filelions variant)
      4. GET  /api/videos/<code>, /api/embed/<code>, /api/play/<code>
      5. GET  /api/source/<code> — AES blob fallback
      6. Scrape the embed page HTML:
           a. JWPlayer .setup() sources array extraction
           b. Named regex for file/src/url keys pointing at .m3u8/.mp4
           c. Broad scan for .m3u8/.mp4 URLs anywhere in the page
           d. CDN-path scan for HLS-style paths without an explicit extension
    """
    post, fetch = _session_requests()
    parsed = urlparse(url)
    m = re.search(r'/(?:e|d)/([A-Za-z0-9_\-]+)', parsed.path)
    if not m:
        xbmc.log(f'VIDCORE vidara: no embed ID in {url}', xbmc.LOGWARNING)
        return None
    code = m.group(1)
    host = (parsed.hostname or '').lower()
    host = host[4:] if host.startswith('www.') else host
    if not srstop_hosts.matches('Vidara', url):
        return None
    origin = parsed.scheme + '://' + parsed.netloc
    embed = f'{origin}/e/{code}'
    if parsed.query:
        embed += '?' + parsed.query

    def _return_stream(stream, strategy):
        xbmc.log(f'VIDCORE vidara: {strategy} → {stream[:80]} for {url}',
                 xbmc.LOGINFO)
        return stream + '|' + urlencode({'User-Agent': UA, 'Referer': embed, 'Origin': origin})

    def _try_sources(data, label):
        decoded = _decrypt_playback(data)
        rows = _source_rows(decoded or data)
        normalized = [dict(row, file=row.get('file') or row.get('url') or '') for row in rows]
        stream = _vidara_pick_best(normalized)
        return _return_stream(stream, label) if stream else None

    # ── 1. POST /api/stream — the real player API ─────────────────────────
    # Discovered by reading the inline JS on the embed page:
    #   fetch("/api/stream", {method:"POST",
    #     headers:{"Content-Type":"application/json"},
    #     body: JSON.stringify({filecode: filecode, device: "web"})})
    # Response: {"streaming_url": "https://...", "thumbnail": "...", ...}
    _stream_body = json.dumps({'filecode': code, 'device': 'web'}).encode('utf-8')
    _stream_resp, final_api = post(
        f'{origin}/api/stream',
        data=_stream_body,
        referer=embed,
        extra_headers={
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'Origin': origin,
        },
    )
    embed = srstop_hosts.player_after_api_redirect(
        'Vidara', embed, f'{origin}/api/stream', final_api)
    migrated = urlparse(embed)
    origin, host = migrated.scheme + '://' + migrated.netloc, migrated.hostname
    if _stream_resp:
        try:
            _stream_data = json.loads(_stream_resp)
            _su = _stream_data.get('streaming_url', '') if isinstance(_stream_data, dict) else ''
            if isinstance(_su, str) and urlparse(_su).scheme in ('http', 'https') and urlparse(_su).netloc:
                xbmc.log(f'VIDCORE vidara: /api/stream → {_su[:80]} for {url}',
                         xbmc.LOGINFO)
                _dblog('VIDARA-STREAM-API', _su)
                return _return_stream(_su, '/api/stream')
        except ValueError:
            pass

    # ── 2. POST /api/source/<code> — form-encoded (3 referrer variants) ───
    _referers = [embed, '', 'https://rugby24.net/']
    for _vi, _r in enumerate(_referers):
        api_url = f'{origin}/api/source/{code}'
        body, _ = post(api_url, data={'r': _r, 'd': host}, referer=embed)
        xbmc.log(f'VIDCORE vidara: POST-form{_vi+1} response received', xbmc.LOGINFO)
        if body:
            try:
                result = _try_sources(json.loads(body), f'POST-form{_vi+1}')
                if result:
                    return result
            except ValueError:
                pass

    # ── 2. POST /api/source/<code> — JSON body ────────────────────────────
    for _r in [embed, '', 'https://rugby24.net/']:
        json_body = json.dumps({'r': _r, 'd': host}).encode('utf-8')
        body_j, _ = post(
            f'{origin}/api/source/{code}',
            data=json_body,
            referer=embed,
            extra_headers={'Content-Type': 'application/json',
                           'Accept': 'application/json'},
        )
        xbmc.log(f'VIDCORE vidara: POST-json response received', xbmc.LOGINFO)
        if body_j:
            try:
                result = _try_sources(json.loads(body_j), 'POST-json')
                if result:
                    return result
            except ValueError:
                pass

    # ── 3. GET /api/videos/<code> ─────────────────────────────────────────
    for api_path in (f'/api/videos/{code}', f'/api/embed/{code}', f'/api/play/{code}'):
        body3, _ = fetch(
            f'{origin}{api_path}',
            referer=embed,
            extra_headers={'Accept': 'application/json',
                           'X-Requested-With': 'XMLHttpRequest'},
        )
        if body3:
            try:
                result = _try_sources(json.loads(body3), f'GET{api_path}')
                if result:
                    return result
            except ValueError:
                pass

    # ── 4. GET /api/source/<code> — AES blob fallback ────────────────────
    body4, _ = fetch(
        f'{origin}/api/source/{code}',
        referer=embed,
        extra_headers={'Accept': 'application/json',
                       'X-Requested-With': 'XMLHttpRequest'},
    )
    if body4:
        try:
            result = _try_sources(json.loads(body4), 'GET-api-source')
            if result:
                return result
        except ValueError:
            pass

    # ── 5. Scrape the embed page HTML ─────────────────────────────────────
    xbmc.log(f'VIDCORE vidara: API failed, falling back to page scrape for {url}',
             xbmc.LOGINFO)
    html, _ = fetch(embed, referer=origin + '/',
                     extra_headers={'Origin': origin})
    if not html:
        xbmc.log(f'VIDCORE vidara: embed page fetch also failed for {url}',
                 xbmc.LOGWARNING)
        return None

    unpacked = _unpack(html) or ''
    search_text = unpacked + html
    xbmc.log(f'VIDCORE vidara: HTML preview (first 600): {html[:600]}',
             xbmc.LOGINFO)
    _dblog('VIDARA-HTML', f'first 400: {html[:400]}')

    # 5a. JWPlayer sources array — grab the JSON array from .setup({sources:[...]})
    #     or from a standalone  var sources = [...]  declaration.
    for _src_pat in (
        r'\.setup\s*\(\s*\{[^}]{0,500}["\']sources["\']?\s*:\s*(\[.*?\])',
        r'(?:var\s+)?sources\s*=\s*(\[(?:[^[\]]|\[[^\[\]]*\]){1,2000}\])',
        r'["\']sources["\']?\s*:\s*(\[.*?\])',
    ):
        _sm = re.search(_src_pat, search_text, re.DOTALL | re.IGNORECASE)
        if _sm:
            try:
                _srcs = json.loads(_sm.group(1))
                _s = _vidara_pick_best(_srcs)
                if _s:
                    return _return_stream(_s, 'HTML-jwp-sources')
            except Exception:
                pass

    # 5b. Named key regex — file/src/url → .m3u8 or .mp4
    m2 = _VIDARA_STREAM_RE.search(search_text)
    if m2:
        return _return_stream(m2.group(1), 'HTML-key-regex')

    # 5c. Broad scan — any .m3u8 or .mp4 URL anywhere in the page
    m3 = re.search(
        r'(https?://[^\s"\'<>\\]+\.(?:m3u8|mp4)(?:\?[^\s"\'<>\\]*)?)',
        search_text, re.IGNORECASE,
    )
    if m3:
        return _return_stream(m3.group(1), 'HTML-broad-scan')

    # 5d. CDN-path scan — HLS-style URLs without an explicit .m3u8 extension
    #     (some Filelions CDNs serve manifests at paths like /hls2/<id>/master)
    m4 = re.search(
        r'(https?://[^\s"\'<>\\]+/(?:hls|hls2|m3u8|master|stream|playlist)'
        r'(?:/[^\s"\'<>\\]*)?(?:\?[^\s"\'<>\\]*)?)',
        search_text, re.IGNORECASE,
    )
    if m4:
        return _return_stream(m4.group(1), 'HTML-cdn-path-scan')

    xbmc.log(f'VIDCORE vidara: all strategies exhausted for {url}',
             xbmc.LOGWARNING)
    return None
