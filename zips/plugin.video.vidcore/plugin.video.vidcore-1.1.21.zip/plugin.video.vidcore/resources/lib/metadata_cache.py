"""Bounded TMDB response cache shared by Kodi plugin invocations."""

# =============================================================================
# Bounded SQLite response cache and invalidation
# =============================================================================
import hashlib
import json
import os
import sqlite3
import time


# --- Connect ---------------------------------------------------------------
def _connect(root):
    os.makedirs(root, exist_ok=True)
    connection = sqlite3.connect(os.path.join(root, 'responses.sqlite3'), timeout=2)
    try:
        connection.execute('CREATE TABLE IF NOT EXISTS responses '
                           '(key TEXT PRIMARY KEY, saved REAL, expires REAL, body TEXT, body_bytes INTEGER NOT NULL)')
        connection.execute('CREATE TABLE IF NOT EXISTS cache_state '
                           '(id INTEGER PRIMARY KEY, generation INTEGER NOT NULL)')
        # Migrate existing caches once. Size accounting then reads a compact
        # covering index rather than loading every JSON payload on each write.
        if 'body_bytes' not in {row[1] for row in connection.execute('PRAGMA table_info(responses)')}:
            with connection:
                connection.execute('BEGIN IMMEDIATE')
                if 'body_bytes' not in {row[1] for row in connection.execute('PRAGMA table_info(responses)')}:
                    connection.execute('ALTER TABLE responses ADD COLUMN body_bytes INTEGER NOT NULL DEFAULT 0')
                    connection.execute('UPDATE responses SET body_bytes=length(CAST(body AS BLOB))')
        connection.execute('CREATE INDEX IF NOT EXISTS responses_saved_size ON responses(saved, body_bytes)')
    except BaseException:
        connection.close()
        raise
    return connection


def _generation(connection):
    row = connection.execute('SELECT generation FROM cache_state WHERE id=1').fetchone()
    return row[0] if row else 0


def generation(root):
    connection = _connect(root)
    try:
        return _generation(connection)
    finally:
        connection.close()


def clear(root):
    """Invalidate old writers atomically, keeping the generation across clears."""
    connection = _connect(root)
    try:
        with connection:
            connection.execute('BEGIN IMMEDIATE')
            next_generation = _generation(connection) + 1
            connection.execute('INSERT OR REPLACE INTO cache_state VALUES (1, ?)',
                               (next_generation,))
            connection.execute('DELETE FROM responses')
        connection.execute('VACUUM')
    finally:
        connection.close()


def get(root, url, stale=False):
    connection = None
    try:
        connection = _connect(root)
        row = connection.execute('SELECT saved, expires, body FROM responses WHERE key=?',
                                 (hashlib.sha256(url.encode()).hexdigest(),)).fetchone()
        return _decode_row(row, time.time(), stale)
    except (OSError, sqlite3.Error, ValueError):
        pass
    finally:
        if connection is not None:
            connection.close()
    return None


# --- Read related entries and invalidation state with one connection --------
def read_snapshot(root, urls):
    connection = None
    try:
        connection = _connect(root)
        with connection:
            connection.execute('BEGIN')
            generation = _generation(connection)
            rows = [(url, connection.execute(
                'SELECT saved, expires, body FROM responses WHERE key=?',
                (hashlib.sha256(url.encode()).hexdigest(),)).fetchone()) for url in dict.fromkeys(urls)]
    except (OSError, sqlite3.Error, ValueError, TypeError):
        return None, {}
    finally:
        if connection is not None:
            connection.close()
    # Release the read transaction before parsing potentially large JSON bodies.
    now = time.time()
    values = {}
    for url, row in rows:
        value = _decode_row(row, now, False)
        if value is not None:
            values[url] = value
    return generation, values


def _decode_row(row, now, stale):
    try:
        if row and row[0] <= now and (row[1] > now or stale and now - row[0] < 7 * 86400):
            return json.loads(row[2])
    except (TypeError, ValueError):
        pass
    return None


# --- Put -------------------------------------------------------------------
def put(root, url, value, ttl, generation=None):
    put_many(root, [(url, value, ttl)], generation=generation)


# --- Save related scan hints with one connection, transaction and pruning ---
def put_many(root, entries, generation=None):
    now = time.time()
    rows = []
    for url, value, ttl in entries:
        try:
            body = json.dumps(value, ensure_ascii=False)
            body_bytes = len(body.encode('utf-8'))
            if body_bytes <= 2 * 1024 * 1024:
                rows.append((hashlib.sha256(url.encode()).hexdigest(), now, now + ttl, body, body_bytes))
        except (ValueError, TypeError, AttributeError):
            continue
    if not rows:
        return
    connection = None
    try:
        connection = _connect(root)
        with connection:
            connection.execute('BEGIN IMMEDIATE')
            if generation is not None and generation != _generation(connection):
                return
            connection.executemany('INSERT OR REPLACE INTO responses '
                                   '(key, saved, expires, body, body_bytes) VALUES (?, ?, ?, ?, ?)', rows)
            connection.execute('DELETE FROM responses WHERE saved < ?', (now - 7 * 86400,))
            # Cap response payloads at 20 MB, dropping oldest entries first.
            total = connection.execute('SELECT COALESCE(SUM(body_bytes),0) FROM responses').fetchone()[0]
            if total > 20 * 1024 * 1024:
                for key, size in connection.execute('SELECT key, body_bytes FROM responses ORDER BY saved').fetchall():
                    connection.execute('DELETE FROM responses WHERE key=?', (key,))
                    total -= size
                    if total <= 20 * 1024 * 1024:
                        break
        if os.path.getsize(os.path.join(root, 'responses.sqlite3')) > 30 * 1024 * 1024:
            connection.execute('VACUUM')
    except (OSError, sqlite3.Error, ValueError, TypeError):
        pass
    finally:
        if connection is not None:
            connection.close()
