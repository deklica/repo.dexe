"""Native Byse access challenges; no browser scripts or device profiling."""

# =============================================================================
# Ephemeral signatures, bounded native proof-of-work and playback authorization
# =============================================================================
import base64
import hashlib
import json
import secrets
import struct
import sys
import time
from array import array
from functools import lru_cache
from operator import itemgetter

from . import srstop


# --- P-256 challenge signatures without collecting client device details -----
def _b64(value):
    return base64.urlsafe_b64encode(value).decode('ascii').rstrip('=')


def attest_payload(challenge, user_agent):
    from .cinejoy import _G, _N, _multiply
    nonce = challenge.get('nonce')
    identifier = challenge.get('challenge_id')
    if not isinstance(nonce, str) or not 1 <= len(nonce) <= 512 or not isinstance(identifier, str):
        raise srstop.SourceError('Byse returned an invalid access challenge.')
    private = secrets.randbelow(_N - 1) + 1
    public = _multiply(private, _G)
    digest = int.from_bytes(hashlib.sha256(nonce.encode('utf-8')).digest(), 'big')
    while True:
        ephemeral = secrets.randbelow(_N - 1) + 1
        r = _multiply(ephemeral, _G)[0] % _N
        s = pow(ephemeral, -1, _N) * (digest + r * private) % _N
        if r and s:
            break
    return {
        'challenge_id': identifier, 'nonce': nonce,
        'viewer_id': '', 'device_id': '',
        'signature': _b64(r.to_bytes(32, 'big') + s.to_bytes(32, 'big')),
        'public_key': {'kty': 'EC', 'crv': 'P-256', 'ext': True,
                       'key_ops': ['verify'],
                       'x': _b64(public[0].to_bytes(32, 'big')),
                       'y': _b64(public[1].to_bytes(32, 'big'))},
        'client': {'user_agent': user_agent},
        'storage': {}, 'attributes': {'entropy': 'low'},
    }


# --- Player proof-of-work: independent 32-bit lanes inside Python integers ----
def _round(state, mask):
    a, b, c, d = state
    a = (a + b) & mask
    d ^= a
    d = ((d << 16) | (d >> 16)) & mask
    c = (c + d) & mask
    b ^= c
    b = ((b << 12) | (b >> 20)) & mask
    a = (a + b) & mask
    d ^= a
    d = ((d << 8) | (d >> 24)) & mask
    c = (c + d) & mask
    b ^= c
    b = ((b << 7) | (b >> 25)) & mask
    return a, b, c, d


def _seed(value):
    state = (1779033703, 3144134277, 1013904242, 2773480762)
    for byte in value:
        a = (state[0] + byte) & 0xffffffff
        state = _round((((a << 7) | (a >> 25)) & 0xffffffff,) + state[1:], 0xffffffff)
    return state


@lru_cache(maxsize=16)
def _batch_layout(count):
    """Reuse immutable masks and packing layouts across proof-of-work batches."""
    layout = struct.Struct('<%dQ' % count)
    width = layout.size
    ones = ((1 << (64 * count)) - 1) // ((1 << 64) - 1)
    mask = ones * 0xffffffff
    lookup_mask = ones * 511
    offsets = sum(lane << (64 * lane) for lane in range(count))
    return layout, width, ones, mask, lookup_mask, offsets


def _work_batch(prefix, start, count):
    """Return each candidate's first output word; never execute remote code."""
    layout, width, ones, mask, lookup_mask, offsets = _batch_layout(count)
    state = tuple(word * ones for word in prefix)
    candidates = [str(start + lane) for lane in range(count)]
    for position in range(len(candidates[0])):
        values = int.from_bytes(layout.pack(*(ord(value[position]) for value in candidates)), 'little')
        a = (state[0] + values) & mask
        state = _round((((a << 7) | (a >> 25)) & mask,) + state[1:], mask)
    for _ in range(8):
        state = _round(state, mask)
    rows = []
    for _ in range(512):
        state = _round(state, mask)
        rows.append(state[0] ^ state[2])
    table = array('Q')
    table.frombytes(b''.join(row.to_bytes(width, 'little') for row in rows))
    if sys.byteorder != 'little':
        table.byteswap()
    view = memoryview(table)
    for _ in range(2):
        for index in range(512):
            value = rows[index]
            addresses = layout.unpack(((value & lookup_mask) * count + offsets).to_bytes(width, 'little'))
            selected = itemgetter(*addresses)(table)
            if count == 1:
                selected = (selected,)
            gathered = int.from_bytes(layout.pack(*selected), 'little')
            mixed = (value + gathered) & mask
            mixed = ((mixed << 13) | (mixed >> 19)) & mask
            mixed ^= (rows[(index + 1) & 511] * 2654435761) & mask
            rows[index] = mixed
            if sys.byteorder == 'little':
                view[index * count:(index + 1) * count] = memoryview(mixed.to_bytes(width, 'little')).cast('Q')
            else:
                table[index * count:(index + 1) * count] = array('Q', layout.unpack(mixed.to_bytes(width, 'little')))
            state = _round((state[0] ^ mixed,) + state[1:], mask)
    state = _round(state, mask)
    value = state[0]
    for row in rows[:64]:
        value = (value + row) & mask
        value = ((value << 5) | (value >> 27)) & mask
        value ^= (row * 2246822519) & mask
    return layout.unpack((value ^ state[2]).to_bytes(width, 'little'))


def solve(nonce, difficulty, timeout=40, cancelled=None):
    if (not isinstance(nonce, str) or not 1 <= len(nonce) <= 512
            or not nonce.isascii() or type(difficulty) is not int or not 0 <= difficulty <= 24):
        raise srstop.SourceError('Byse returned an unsupported proof-of-work challenge.')
    if difficulty == 0:
        return '0'
    seed = _seed((nonce + ':').encode('ascii'))
    limit = time.monotonic() + min(max(timeout, 0), 40)
    start, boundary = 0, 10
    bits = (0xffffffff << (32 - difficulty)) & 0xffffffff
    while time.monotonic() < limit:
        if cancelled and cancelled():
            raise srstop.SourceError('Byse verification cancelled.')
        count = min(512, boundary - start)
        for offset, word in enumerate(_work_batch(seed, start, count)):
            if not word & bits:
                return str(start + offset)
        start += count
        if start == boundary:
            boundary *= 10
    raise srstop.SourceError('Byse proof-of-work timed out. Try another source.')


# --- Attest, verify proof-of-work, then authorize playback --------------------
def playback(post, origin, code, prefix, headers, user_agent, cancelled=None):
    def request(path, payload, extra=None):
        request_headers = dict(headers)
        request_headers.update({'Content-Type': 'application/json', 'Accept': 'application/json'})
        request_headers.update(extra or {})
        body, _ = post(origin + path,
                       data=json.dumps(payload, separators=(',', ':')).encode('utf-8'),
                       referer=headers['Referer'], extra_headers=request_headers)
        try:
            value = json.loads(body)
        except (ValueError, TypeError):
            value = None
        if not isinstance(value, dict):
            raise srstop.SourceError('Byse access verification returned an invalid response.')
        return value

    challenge = request('/api/videos/access/challenge', {})
    attestation = request('/api/videos/access/attest', attest_payload(challenge, user_agent))
    if any(not isinstance(attestation.get(key), str) or not attestation[key]
           for key in ('token', 'viewer_id', 'device_id')):
        raise srstop.SourceError('Byse could not authorize this native client.')
    fingerprint = {key: attestation[key] for key in ('token', 'viewer_id', 'device_id')}
    fingerprint['confidence'] = attestation.get('confidence', 0)
    route = '/api/videos/%s/%s' % (code, prefix)
    challenge = request(route + 'captcha', {'fingerprint': fingerprint})
    if (challenge.get('algorithm') not in (None, 'sha256-leading-zero-bits')
            or not isinstance(challenge.get('pow_token'), str) or not challenge['pow_token']):
        raise srstop.SourceError('Byse returned an unsupported verification algorithm.')
    # Despite the API's historical algorithm label, the shipped player uses
    # the bounded memory-mixing function above, not plain SHA-256.
    solution = solve(challenge.get('pow_nonce'), challenge.get('pow_difficulty'), cancelled=cancelled)
    verified = request(route + 'captcha/verify', {
        'fingerprint': fingerprint, 'pow_token': challenge['pow_token'], 'solution': solution})
    token = verified.get('token')
    if not isinstance(token, str) or not token:
        raise srstop.SourceError('Byse did not accept the native verification result.')
    return request(route + 'playback', {'fingerprint': fingerprint},
                   {'X-Captcha-Token': token})
