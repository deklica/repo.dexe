"""Recognize SRStop host migrations from labelled episode links and redirects."""

# =============================================================================
# Provider identity, supported player paths and temporary mirror recognition
# =============================================================================
import re
import threading
import time
from urllib.parse import urlsplit, urlunsplit

DOMAINS = {
    'SaveFiles (HLS)': ('savefiles.com',),
    'LuluStream': ('lulustream.com', 'luluvdo.com', 'lulust.com', 'luluvid.com',
                   'lplaygo.com'),
    'Streamtape': ('streamta.pe',),
    'DoodStream': ('ds2play.com', 'ds2video.com', 'playmogo.com'),
    'Byse': ('bysesayeveum.com', 'bysesukior.com', 'bysewihe.com',
             'bysekoze.com', 'byseraguci.com'),
    'VOE': ('voe.sx', 'jeremyparticipantanything.com', 'teresapoliticallearn.com',
            'shannoncoldalready.com', 'susanexpectcare.com'),
    'Morencius': ('morencius.com',),
    'Vidara': ('vidara.to', 'vidara.so', 'gbsagbo.com'),
    'Streamplay': ('straemplay.org', 'streamplay.to'),
}
PATHS = {
    'SaveFiles (HLS)': r'/(?:embed-)?([A-Za-z0-9]{12})(?:\.html)?/?',
    'LuluStream': r'/(?:embed-|e/|d/)?([A-Za-z0-9]{6,})(?:\.html)?/?',
    'Streamtape': r'/(?:e|v|embed)/([A-Za-z0-9_-]+?)(?:\.html)?(?:/[^?#]*)?',
    'DoodStream': r'/(?:e|d|embed)/([A-Za-z0-9_-]+?)(?:\.html)?(?:/[^?#]*)?',
    'Byse': r'/(?:d|e|download)/([A-Za-z0-9]+)(?:/[^?#]*)?',
    'VOE': r'/(?:e/)?([A-Za-z0-9]+)/?',
    'Morencius': r'/(?:e/|embed/|file/|download/|embed-)?([A-Za-z0-9]+)(?:\.html)?/?',
    'Vidara': r'/(?:e|d)/([A-Za-z0-9_-]+)/?',
    'Streamplay': r'/(?:e/|d/|embed/|embed-)?([A-Za-z0-9_-]+?)(?:\.html)?/?',
}
LABELS = {
    'SaveFiles (HLS)': r'save[\s_-]*files',
    'LuluStream': r'lulu(?:[\s_-]*(?:stream|vdo|vid))?|lplaygo',
    'Streamtape': r'stream[\s_-]*tape',
    'DoodStream': r'dood(?:[\s_-]*stream)?|playmogo',
    'Byse': r'byse(?:sayeveum|sukior|wihe|koze|raguci)?|fiilemoon',
    'VOE': r'voe',
    'Morencius': r'morencius',
    'Vidara': r'vidara',
    'Streamplay': r'str[ae]{2}m[\s_-]*play',
}
_MIRRORS = {}
_LOCK = threading.Lock()


# --- URL validation and built-in host identity -----------------------------
def parts(url):
    try:
        parsed = urlsplit(url)
        host = re.sub(r'^www\.', '', (parsed.hostname or '').lower())
        if (parsed.scheme not in ('http', 'https') or parsed.username is not None
                or parsed.password is not None or parsed.port not in (None, 80, 443)
                or not re.fullmatch(r'(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z]{2,}', host)
                or host.endswith(('.localhost', '.local', '.internal'))
                or any(char.isspace() or ord(char) < 32 for char in url)):
            return None
        return parsed
    except (ValueError, TypeError):
        return None


def _builtin(provider, host):
    if host in DOMAINS.get(provider, ()):
        return True
    if provider == 'Streamtape':
        return bool(re.fullmatch(
            r'(?:streamtape|shavetape|strcloud|strtape|streamadblocker)\.[a-z]{2,}', host))
    if provider == 'DoodStream':
        return bool(re.fullmatch(
            r'(?:d[a-z0-9]*ood[a-z]*|d0+d|ds2play|ds2video|playmogo)\.[a-z]{2,}', host))
    return False


def is_domain(provider, url):
    parsed = parts(url)
    if parsed is None:
        return False
    host = re.sub(r'^www\.', '', parsed.hostname.lower())
    if _builtin(provider, host):
        return True
    with _LOCK:
        return time.monotonic() - _MIRRORS.get((provider, host), float('-inf')) < 3600


def file_code(provider, url):
    parsed = parts(url)
    match = re.fullmatch(PATHS.get(provider, r'(?!)'), parsed.path, re.I) if parsed else None
    return match[1] if match else ''


def matches(provider, url):
    return bool(file_code(provider, url) and is_domain(provider, url))


# --- Learn mirrors only from episode labels or same-file player redirects ---
def _remember(provider, url):
    parsed = parts(url)
    if parsed is None or not file_code(provider, url):
        return False
    host = re.sub(r'^www\.', '', parsed.hostname.lower())
    if any(other != provider and _builtin(other, host) for other in DOMAINS):
        return False
    with _LOCK:
        if any(other != provider and domain == host and time.monotonic() - at < 3600
               for (other, domain), at in _MIRRORS.items()):
            return False
        if len(_MIRRORS) >= 128 and (provider, host) not in _MIRRORS:
            _MIRRORS.pop(next(iter(_MIRRORS)))
        _MIRRORS[provider, host] = time.monotonic()
    return True


def accept_link(provider, url, label):
    """Called only with anchor metadata from the matched SRStop episode."""
    labelled = {name for name, pattern in LABELS.items()
                if re.search(r'(?<![A-Za-z0-9])(?:' + pattern + r')(?![A-Za-z0-9])',
                             label, re.I)}
    if labelled and labelled != {provider}:
        return False
    if matches(provider, url):
        return True
    return labelled == {provider} and _remember(provider, url)


def accept_redirect(provider, source, target):
    """Retain file identity across host changes; never guess another provider."""
    code = file_code(provider, source)
    return bool(matches(provider, source) and code
                and file_code(provider, target) == code and _remember(provider, target))


def player_after_api_redirect(provider, player, endpoint, final):
    """Apply a same-endpoint API migration to subsequent player requests."""
    before, after, original = parts(endpoint), parts(final), parts(player)
    if before is None or after is None or original is None or before.path != after.path:
        return player
    target = urlunsplit((after.scheme, after.netloc, original.path, original.query, ''))
    return target if accept_redirect(provider, player, target) else player
