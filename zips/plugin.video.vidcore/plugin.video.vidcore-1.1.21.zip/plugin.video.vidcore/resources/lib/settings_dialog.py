"""Vidcore settings with native-addon storage and a branded dialog."""

# =============================================================================
# Settings preferences and custom settings dialog
# =============================================================================
import os
from datetime import datetime
import re
import xml.etree.ElementTree as ET
from urllib.parse import urlencode
import xbmc
import xbmcaddon
import xbmcgui

FIELDS = ('diagnostic_logging', 'metadata_cache_enabled', 'tmdb_watch_region',
          'tmdb_api_key', 'fanarttv_api_key', 'simkl_scrobble', 'simkl_min_progress', 'simkl_resume', 'local_tracking')


SECTIONS = (
    ('Metadata', 'Artwork & region', 'settings_category_metadata_v2.png', 'Metadata, artwork and streaming catalogue region'),
    ('Playback', 'History & resume', 'settings_category_playback_v2.png', 'Local watched history and playback completion'),
    ('Simkl', 'Account & sync', 'settings_category_simkl_v2.png', 'Account connection, cloud resume and syncing'),
    ('Advanced', 'Diagnostics', 'settings_category_advanced_v2.png', 'Logging and troubleshooting'),
)


# --- Load preferences ------------------------------------------------------
def load_preferences(addon, defaults):
    values = {}
    for key in FIELDS:
        value = addon.getSetting(key).strip()
        if key == 'tmdb_watch_region':
            value = value.upper()
            if not re.fullmatch('[A-Z]{2}', value):
                value = defaults[key]
        elif key == 'simkl_min_progress':
            from .simkl_playback import watched_threshold
            value = str(watched_threshold(value))
        elif key in ('diagnostic_logging', 'metadata_cache_enabled', 'simkl_scrobble', 'simkl_resume', 'local_tracking'):
            value = value.lower()
            if value not in ('true', 'false'):
                value = defaults[key]
        values[key] = value or defaults[key]
    return values


# --- Settings Dialog -------------------------------------------------------
class SettingsDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.addon = kwargs.pop('addon')
        self.draft = kwargs.pop('draft')
        self.defaults = kwargs.pop('defaults')
        self.saved = load_preferences(self.addon, self.defaults)
        self.section = kwargs.pop('section', 0)
        self.positions = kwargs.pop('positions', {index: 0 for index in range(len(SECTIONS))})
        self.initial_focus = kwargs.pop('focus', 6000)
        self.rows = []
        self.result = None
        self._populating = False
        super().__init__(*args, **kwargs)

    def onInit(self):
        self.setProperty('vc_settings_version', 'v' + self.addon.getAddonInfo('version'))
        self._populating = True
        listing = self.getControl(6000)
        listing.reset()
        for name, description, icon, _subtitle in SECTIONS:
            item = xbmcgui.ListItem(label=name, label2=description)
            item.setProperty('icon', os.path.join(self.addon.getAddonInfo('path'), 'resources', 'media', icon))
            listing.addItem(item)
        listing.selectItem(self.section)
        self._populating = False
        self.populate()
        self.setFocusId(self.initial_focus)

    def populate(self, position=None):
        if self._populating:
            return
        self._populating = True
        try:
            self._populate(position)
        finally:
            self._populating = False

    # --- Populate ---
    def _populate(self, position=None):
        if position is None:
            position = self.positions.get(self.section, 0)
        self.positions[self.section] = position
        if self.section == 0:
            self.rows = [
                ('Metadata cache', 'metadata_cache_enabled', 'bool', 'Reuse TMDB responses for faster browsing. Clear stored data from Tools > Clear Cache.'),
                ('Provider region', 'tmdb_watch_region', 'country', 'Fallback country for streaming catalogues if automatic detection fails.'),
                ('TMDB API key', 'tmdb_api_key', 'text', 'The included key is ready to use. Enter a personal key only if you need one.'),
                ('Fanart.tv API key', 'fanarttv_api_key', 'text', 'Fetch backup artwork when TMDB images are missing or unavailable.')]
        elif self.section == 1:
            self.rows = [
                ('Local playback tracking', 'local_tracking', 'bool', 'Save watched history and offer local resume on this device, without a Simkl account.'),
                ('Mark watched at', 'simkl_min_progress', 'percentage', 'Choose when local history and connected Simkl tracking mark a title watched (50–100%).')]
        elif self.section == 3:
            self.rows = [('Diagnostic logging', 'diagnostic_logging', 'bool', 'Add extra source details to kodi.log while troubleshooting.')]
        else:
            from . import simkl
            connected = simkl.has_token()
            self._connected = connected
            from . import simkl_store
            checked = simkl_store.last_checked(simkl.DATA_PATH, simkl._account_cache_key()) if connected else 0
            try:
                sync_description = 'Last synced: ' + datetime.fromtimestamp(checked).strftime('%d %b %Y, %H:%M') if checked else 'Refresh watchlists and history'
            except (ValueError, OverflowError, OSError):
                sync_description = 'Refresh watchlists and history'
            self.rows = [
                ('Simkl account', '', 'info', 'Connect Simkl to access watchlists, next episodes and playback tracking.'),
                ('Simkl playback tracking', 'simkl_scrobble', 'bool', 'Sync playback start, pause and stop events with your connected account.'),
                ('Resume from Simkl', 'simkl_resume', 'bool', 'Offer to resume from a saved Simkl position when starting a title.'),
                ('Sync now', '', 'sync', 'Refresh your Simkl lists now. Unsaved preferences are kept.'),
                ('Disconnect Simkl' if connected else 'Connect Simkl', '', 'disconnect' if connected else 'connect', 'Connection changes apply immediately; other preferences apply when saved.')]
        name, _description, _icon, subtitle = SECTIONS[self.section]
        self.setProperty('vc_settings_section', name)
        self.setProperty('vc_settings_subtitle', subtitle)
        self.setProperty('vc_settings_count', str(len(self.rows)))
        dirty = any(self.draft.get(key) != self.saved.get(key) for key in FIELDS)
        self.setProperty('vc_settings_dirty', 'true' if dirty else 'false')
        self.setProperty('vc_settings_save_status', 'Unsaved changes' if dirty else 'No unsaved changes')
        listing = self.getControl(6001)
        listing.reset()
        items = []
        for label, key, kind, help_text in self.rows:
            value = self.draft.get(key, '')
            if kind == 'bool':
                value = 'ON' if value == 'true' else 'OFF'
            elif kind == 'text':
                value = ('Included key' if not value or value == self.defaults.get(key)
                         else 'Personal key')
            elif kind == 'country':
                from . import country_picker
                value = dict(country_picker.countries(None, value)).get(value, value)
            elif kind == 'percentage':
                value += '%'
            elif kind == 'sync':
                value = 'Sync' if connected else 'Connect first'
            elif kind == 'info':
                value = 'Connected' if connected else 'Not connected'
            elif kind in ('connect', 'disconnect'):
                value = 'Disconnect' if kind == 'disconnect' else 'Connect'
            item = xbmcgui.ListItem(label=label, label2=value)
            descriptions = {
                'diagnostic_logging': 'Extra detail for troubleshooting',
                'metadata_cache_enabled': 'Reuse TMDB responses for faster browsing',
                'tmdb_watch_region': 'Used if automatic country detection fails',
                'tmdb_api_key': 'Metadata, search and streaming services',
                'fanarttv_api_key': 'Backup posters and backgrounds',
                'simkl_scrobble': 'Sync watching progress with your account',
                'local_tracking': 'Watched history and resume saved on this device',
                'simkl_min_progress': 'Completion threshold for watched history',
                'simkl_resume': 'Continue from a saved position across devices',
            }
            item.setProperty('description', descriptions.get(key,
                sync_description if kind == 'sync' else
                'Manage your connection' if kind in ('connect', 'disconnect') else
                (self.addon.getSetting('simkl_username') or 'Connect to bring your watchlists to Vidcore')))
            item.setProperty('enabled', 'true' if kind == 'bool' and value == 'ON' else 'false')
            item.setProperty('kind', kind)
            item.setProperty('key_label', ('Included' if value == 'Included key' else 'Personal') if kind == 'text' else '')
            items.append(item)
        listing.addItems(items)
        listing.selectItem(max(0, min(position, len(self.rows) - 1)))
        self.update_help()

    def update_help(self):
        position = self.getControl(6001).getSelectedPosition()
        if 0 <= position < len(self.rows):
            text = self.rows[position][3]
            if self.getProperty('vc_settings_help') != text:
                self.setProperty('vc_settings_help', text)

    def onFocus(self, control_id):
        if self._populating:
            return
        self.sync_section()
        self.update_help()

    def sync_section(self):
        if self._populating:
            return
        position = self.getControl(6001).getSelectedPosition()
        if position >= 0:
            self.positions[self.section] = position
        section = self.getControl(6000).getSelectedPosition()
        if section in range(len(SECTIONS)) and section != self.section:
            self.section = section
            self.populate()
        elif self.section == 2:
            from . import simkl
            if simkl.has_token() != self._connected:
                self.populate(position)

    def onAction(self, action):
        if action.getId() in (9, 10, 92):
            if self.getFocusId() != 6000:
                self.setFocusId(6000)
                return
            self.close()
            return
        if action.getId() == 216:
            self.close()
            return
        self.sync_section()
        self.update_help()

    # --- On Click ---
    def onClick(self, control_id):
        if control_id == 6000:
            self.sync_section()
            self.setFocusId(6001)
        elif control_id == 6002:
            self.result = 'save'
            self.close()
        elif control_id == 6003:
            self.close()
        elif control_id == 6004:
            self.draft.update(self.defaults)
            self.populate()
            self.setFocusId(6004)
        elif control_id == 6001:
            self.sync_section()
            position = self.getControl(6001).getSelectedPosition()
            if not 0 <= position < len(self.rows):
                return
            label, key, kind, _help = self.rows[position]
            if kind == 'info':
                return
            if kind == 'bool':
                self.draft[key] = 'false' if self.draft[key] == 'true' else 'true'
            elif kind == 'percentage':
                from . import watched_threshold_dialog
                selected = watched_threshold_dialog.choose(self.addon.getAddonInfo('path'), self.draft[key])
                if selected is not None:
                    self.draft[key] = str(selected)
            elif kind == 'sync':
                from . import simkl
                if not simkl.has_token():
                    xbmcgui.Dialog().notification('Simkl', 'Connect Simkl first')
                    return
                self.result = 'sync'
                self.close()
                return
            elif kind == 'text':
                keyboard = xbmc.Keyboard(self.draft[key], label)
                keyboard.doModal()
                if keyboard.isConfirmed():
                    self.draft[key] = keyboard.getText().strip() or self.defaults[key]
            elif kind == 'country':
                from . import country_picker, tmdb
                data = tmdb._fetch('https://api.themoviedb.org/3/watch/providers/regions?' + urlencode(
                    {'api_key': self.draft['tmdb_api_key'] or self.defaults['tmdb_api_key'],
                     'language': 'en-US'}), timeout=5)
                countries = country_picker.countries(data, self.draft[key])
                selected = next((i for i, row in enumerate(countries) if row[0] == self.draft[key]), -1)
                index = xbmcgui.Dialog().select('Provider country fallback',
                    ['%s (%s)' % (name, code) for code, name in countries], preselect=selected)
                if 0 <= index < len(countries):
                    self.draft[key] = countries[index][0]
            elif kind in ('connect', 'disconnect'):
                self.result = kind
                self.close()
                return
            self.populate(position)
            self.setFocusId(6001)


# --- Show ------------------------------------------------------------------
def show():
    addon = xbmcaddon.Addon('plugin.video.vidcore')
    path = addon.getAddonInfo('path')
    schema = ET.parse(os.path.join(path, 'resources', 'settings.xml'))
    defaults = {row.get('id'): row.get('default', '') for row in schema.iter('setting')
                if row.get('id') in FIELDS}
    initial = {key: addon.getSetting(key) for key in FIELDS}
    draft = load_preferences(addon, defaults)
    section = 0
    positions = {index: 0 for index in range(len(SECTIONS))}
    focus = 6000
    while True:
        dialog = SettingsDialog('VidCoreSettings.xml', path, 'Default', '720p',
                                addon=addon, draft=draft, defaults=defaults, section=section,
                                positions=positions, focus=focus)
        # Kodi can update a hovered list selection after onAction returns.
        # Observe the settled selection so category, rows and help stay together.
        from threading import Event, Thread
        stopped = Event()

        def follow_selection():
            while not stopped.wait(0.12):
                if dialog.rows and not dialog._populating:
                    try:
                        dialog.sync_section()
                        dialog.update_help()
                    except RuntimeError:
                        return  # Window controls have been released.

        watcher = Thread(target=follow_selection, name='VidcoreSettingsSelection', daemon=True)
        watcher.start()
        try:
            dialog.doModal()
        finally:
            stopped.set()
            watcher.join()
        result = dialog.result
        section = dialog.section
        del dialog
        if result == 'save':
            failed = []
            changed = set()
            for key, value in draft.items():
                if value != initial[key]:
                    try:
                        addon.setSetting(key, value)
                    except (RuntimeError, OSError):
                        failed.append(key)
                    else:
                        changed.add(key)
                        initial[key] = value
            if 'tmdb_watch_region' in changed:
                xbmcgui.Window(10000).clearProperty('Vidcore.WatchRegion')
            if any(key in changed for key in
                   ('tmdb_api_key', 'fanarttv_api_key', 'metadata_cache_enabled')):
                from . import tmdb
                tmdb._SESSION_META_CACHE.clear()
                tmdb._TVDB_ID_CACHE.clear()
                tmdb._TMDB_ART_HEALTH.update({'checked': 0.0, 'ok': True})
                if 'fanarttv_api_key' in changed:
                    tmdb.fanarttv.clear_cache()
            if failed:
                xbmcgui.Dialog().notification('Vidcore',
                    'Some preferences could not be saved. Your edits are kept; please retry.',
                    xbmcgui.NOTIFICATION_ERROR, 5000)
                focus = 6002
                continue
            return
        if result not in ('connect', 'disconnect', 'sync'):
            return
        focus = 6001
        from . import simkl
        if result == 'sync':
            xbmcgui.Dialog().notification('Simkl', 'Syncing lists and history…')
            _data, ok = simkl._sync_snapshot(force=True, refresh_resources=True)
            xbmcgui.Dialog().notification('Simkl', 'Sync complete' if ok else 'Sync failed; saved data retained')
        elif result == 'connect':
            simkl.authorize()
        else:
            simkl.revoke()
