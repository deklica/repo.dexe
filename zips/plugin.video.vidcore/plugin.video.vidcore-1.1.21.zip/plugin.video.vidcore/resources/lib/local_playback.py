"""Profile-local playback progress and watched history, independent of Simkl."""
import math
import os
import sqlite3
import time
from .simkl_playback import watched_threshold


def _root():
    import xbmcvfs
    return xbmcvfs.translatePath('special://profile/addon_data/plugin.video.vidcore/')


def identity(meta):
    tmdb = str(meta.get('tmdb') or meta.get('tmdb_id') or '')
    if not tmdb.isdigit():
        return None
    if meta.get('content') == 'movie' or meta.get('kind') == 'movie':
        return 'movie:' + tmdb
    if meta.get('content') not in ('episode',) and meta.get('kind') != 'tv':
        return None
    try:
        season, episode = int(meta['season']), int(meta['episode'])
        if season >= 0 and episode > 0:
            return 'episode:%s:%d:%d' % (tmdb, season, episode)
    except (KeyError, ValueError, TypeError, OverflowError):
        pass
    return None


def _connect(root):
    os.makedirs(root, exist_ok=True)
    db = sqlite3.connect(os.path.join(root, 'playback.sqlite3'), timeout=2)
    try:
        db.execute('CREATE TABLE IF NOT EXISTS playback '
                   '(media TEXT PRIMARY KEY, progress REAL NOT NULL, watched INTEGER NOT NULL, updated REAL NOT NULL)')
    except BaseException:
        db.close()
        raise
    return db


def record(meta, progress, threshold=80, root=None):
    key = identity(meta)
    try:
        progress = float(progress)
    except (TypeError, ValueError, OverflowError):
        return
    if not key or not math.isfinite(progress) or progress <= 0:
        return
    progress = max(0, min(100, progress))
    db = None
    try:
        db = _connect(root if root is not None else _root())
        with db:
            # Serialize the read/modify/write so another playback cannot undo
            # a watched flag committed between our read and replacement.
            db.execute('BEGIN IMMEDIATE')
            previous = db.execute('SELECT watched FROM playback WHERE media=?', (key,)).fetchone()
            watched = int(progress >= watched_threshold(threshold) or bool(previous and previous[0]))
            db.execute('INSERT OR REPLACE INTO playback VALUES (?,?,?,?)',
                       (key, progress, watched, time.time()))
    except (OSError, sqlite3.Error, RuntimeError):
        pass
    finally:
        if db is not None:
            db.close()


def snapshot(root=None):
    db = None
    try:
        folder = root if root is not None else _root()
        if not os.path.isfile(os.path.join(folder, 'playback.sqlite3')):
            return {}
        db = _connect(folder)
        return {key: {'progress': progress, 'watched': bool(watched)}
                for key, progress, watched in db.execute('SELECT media, progress, watched FROM playback')}
    except (OSError, sqlite3.Error, RuntimeError):
        return {}
    finally:
        if db is not None:
            db.close()


def get(meta, root=None):
    """Read one title through its primary key instead of loading all history."""
    key = identity(meta)
    if key is None:
        return {}
    db = None
    try:
        folder = root if root is not None else _root()
        if not os.path.isfile(os.path.join(folder, 'playback.sqlite3')):
            return {}
        db = _connect(folder)
        row = db.execute('SELECT progress, watched FROM playback WHERE media=?', (key,)).fetchone()
        return {'progress': row[0], 'watched': bool(row[1])} if row else {}
    except (OSError, sqlite3.Error, RuntimeError):
        return {}
    finally:
        if db is not None:
            db.close()


def resume(meta):
    row = get(meta)
    progress = row.get('progress', 0)
    return progress if not row.get('watched') and 0 < progress < 100 else 0
