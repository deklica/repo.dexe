"""Simkl completion preferences and saved playback matching."""
import math


def watched_threshold(value):
    try:
        value = int(value)
    except (TypeError, ValueError, OverflowError):
        return 80
    return max(50, min(100, value))


def resume_progress(rows, params, details=None):
    """Match media IDs and exact episode numbers; never match by title alone."""
    if not isinstance(rows, list):
        return 0
    details = details or {}
    movie = params.get('kind', 'movie') == 'movie'
    expected = {'tmdb': params.get('tmdb_id'), 'imdb': details.get('imdb_id'),
                'tvdb': details.get('tvdb_id')}
    expected = {key: str(value) for key, value in expected.items() if value}
    target_episode = None
    if not movie:
        try:
            target_episode = (int(params['season']), int(params['episode']))
        except (KeyError, TypeError, ValueError, OverflowError):
            return 0
    latest = ('', 0)
    for row in rows:
        if not isinstance(row, dict):
            continue
        media = row.get('movie' if movie else 'show')
        if not isinstance(media, dict) or not isinstance(media.get('ids'), dict):
            continue
        ids = media['ids']
        comparable = [(value, str(ids[key])) for key, value in expected.items()
                      if ids.get(key)]
        if not comparable or any(left != right for left, right in comparable):
            continue
        if not movie:
            episode = row.get('episode')
            if not isinstance(episode, dict):
                continue
            try:
                if (int(episode['season']), int(episode['number'])) != target_episode:
                    continue
            except (KeyError, TypeError, ValueError, OverflowError):
                continue
        try:
            progress = float(row.get('progress', 0))
        except (ValueError, TypeError, OverflowError):
            continue
        if math.isfinite(progress) and 0 < progress < 100:
            latest = max(latest, (str(row.get('paused_at') or ''), progress))
    return latest[1]


def offer_resume(params, details=None):
    """Return a chosen percentage, zero for fresh playback, or None on cancel."""
    from . import simkl
    from . import local_playback
    local = local_playback.resume(params) if simkl.ADDON.getSetting('local_tracking') != 'false' else 0
    remote = simkl.ADDON.getSetting('simkl_resume') != 'false' and simkl.has_token()
    headers = simkl._auth_headers() if remote else None
    kind = 'movies' if params.get('kind', 'movie') == 'movie' else 'episodes'
    progress = 0
    if headers:
        status, rows, _ = simkl._http_json('/sync/playback/' + kind, headers=headers,
                                         timeout=5, _retry_rate_limit=False)
        progress = resume_progress(rows, params, details) if status == 200 else 0
    source = 'Simkl' if progress else 'local'
    progress = progress or local
    if not progress:
        return 0
    from . import resume_dialog
    return resume_dialog.choose(simkl.ADDON.getAddonInfo('path'), progress, source)
