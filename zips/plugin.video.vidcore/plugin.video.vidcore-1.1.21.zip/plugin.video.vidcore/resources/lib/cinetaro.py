"""Cinetaro Primus API client for the Vidcore source picker."""

# =============================================================================
# Cinetaro embed discovery and stream resolution
# =============================================================================
import json
import base64
import hashlib
import socket
from urllib.parse import urlencode
from urllib.request import Request, urlopen

import xbmc


BASE_URL = 'https://cinextream.cc/api/embed'
API_URL = 'https://cinextream.cc/api/proxy'
HEADERS = {'User-Agent': 'Mozilla/5.0', 'Referer': 'https://cinextream.cc/'}


# --- Return Cinextream's current movie or exact TV episode player ----------
def embed_url(tmdb_id, content='movie', season=None, episode=None):
    """Return Cinextream's current movie or exact TV episode player."""
    tmdb_id = str(tmdb_id or '').strip()
    if not tmdb_id.isdigit() or int(tmdb_id) < 1:
        return ''
    if content == 'movie':
        return BASE_URL + '/movie/' + tmdb_id
    else:
        try:
            season, episode_number = int(season), int(episode)
        except (TypeError, ValueError):
            return ''
        if season < 0 or episode_number < 1:
            return ''
        return BASE_URL + '/tv/%s/%d/%d' % (tmdb_id, season, episode_number)


def api_url(tmdb_id, content='movie', season=None, episode=None, server='Nest'):
    """Build the direct Cinetaro/Nest stream API route."""
    # Keep the picker's Nest label; the upstream vidnest backend is now Ernest.
    params = {'server': 'Ernest' if server == 'Nest' else server, 'tmdb': str(tmdb_id),
              'type': 'movie' if content == 'movie' else 'series'}
    if content != 'movie':
        params.update(season=season, episode=episode)
    return API_URL + '?' + urlencode(params)


def _urls(value, headers=None):
    if isinstance(value, str):
        if value.startswith(('http://', 'https://')):
            yield value, dict(headers or {})
    elif isinstance(value, dict):
        own_headers = value.get('headers') if isinstance(value.get('headers'), dict) else headers
        for key, item in value.items():
            if key == 'headers':
                continue
            yield from _urls(item, own_headers)
    elif isinstance(value, list):
        for item in value:
            yield from _urls(item, headers)


def _decode_response(data, tmdb_id):
    """Equivalent of the player's normalizeBuffer response decoder."""
    if not isinstance(data, dict) or 'enc' not in data:
        return data
    key = hashlib.sha256((str(tmdb_id) +
                          'c1n3t4r-0bf5c4t10n-s4lt-v1-2024-09').encode('utf-8')).digest()
    encoded = base64.b64decode(data['enc'], validate=True)
    decoded = bytes(value ^ key[i % 32] ^ ((i * 7 + 13) & 255)
                    for i, value in enumerate(encoded))
    return json.loads(decoded.decode('utf-8'))


# --- Fetch and verify an HLS URL returned by a Cinetaro backend ------------
def resolve(tmdb_id, content='movie', season=None, episode=None, server='Nest'):
    """Fetch and verify an HLS URL returned by a Cinetaro backend."""
    if server != 'Nest' or not embed_url(tmdb_id, content, season, episode):
        return None
    dns_failure = False
    for server in (server,):
        endpoint = api_url(tmdb_id, content, season, episode, server)
        try:
            request = Request(endpoint, headers=HEADERS)
            with urlopen(request, timeout=15) as response:
                raw = response.read(2 * 1024 * 1024 + 1)
            if len(raw) > 2 * 1024 * 1024:
                raise ValueError('Cinetaro response exceeds size limit')
            raw = raw.decode('utf-8', errors='replace')
            data = _decode_response(json.loads(raw), tmdb_id)
            xbmc.log('VIDCORE %s API returned %d bytes' % (server, len(raw)), xbmc.LOGINFO)
            if not isinstance(data, dict):
                raise ValueError('Unexpected decoded API response')
            # Nest's top-level source is an embed, not a media URL.
            candidates = list(_urls(data.get('data') or {}, HEADERS))
            seen = set()
            for candidate, source_headers in candidates:
                if candidate in seen:
                    continue
                seen.add(candidate)
                # The backend may return a signed, extensionless playlist URL.
                # Probe the response instead of requiring a .m3u8 suffix.
                try:
                    probe_headers = dict(HEADERS)
                    probe_headers.update(source_headers or {})
                    probe = Request(candidate, headers=probe_headers)
                    with urlopen(probe, timeout=12) as response:
                        sample = response.read(4096)
                        final = response.geturl()
                        content_type = (response.headers.get('Content-Type') or '').lower()
                    if sample.lstrip().startswith(b'#EXTM3U') or 'mpegurl' in content_type:
                        xbmc.log('VIDCORE %s verified HLS playlist' % server, xbmc.LOGINFO)
                        return {'url': final, 'type': 'hls', 'headers': probe_headers}
                except Exception as exc:
                    if isinstance(getattr(exc, 'reason', None), socket.gaierror):
                        xbmc.log('VIDCORE %s media host DNS resolution failed' % server, xbmc.LOGWARNING)
                        dns_failure = True
                        continue
                    xbmc.log('VIDCORE %s stream probe failed: %s status=%s' % (
                        server, type(exc).__name__, getattr(exc, 'code', '')), xbmc.LOGWARNING)
        except Exception as exc:
            xbmc.log('VIDCORE %s API failed: %s status=%s' % (
                server, type(exc).__name__, getattr(exc, 'code', '')), xbmc.LOGWARNING)
    xbmc.log('VIDCORE %s returned no verified media source' % server, xbmc.LOGWARNING)
    if dns_failure:
        return {'error': '%s returned no playable source; a media host could not be resolved (DNS failure). '
                         'Try another source.' % server}
    return None
