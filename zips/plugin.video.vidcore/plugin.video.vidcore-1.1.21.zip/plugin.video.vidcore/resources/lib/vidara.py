"""Resolve Vidara and its mirrors from the matched SRStop episode."""

# =============================================================================
# Vidara host detection and episode sources
# =============================================================================
from urllib.parse import parse_qsl, urlsplit
from . import srstop, srstop_hosts



# --- Is url ----------------------------------------------------------------
def is_url(url):
    return srstop_hosts.matches('Vidara', url)


def resolve(tmdb_id, season, episode, links=None):
    from . import tmdb, provider_resolvers
    try:
        links = links if links is not None else srstop.discover_vidara(tmdb.get_metadata(tmdb_id, 'tv'), season, episode)
        for link in links:
            try:
                media = provider_resolvers.resolve_vidara(link['url'])
                if not media:
                    continue
                url, _, encoded = media.partition('|')
                if urlsplit(url).scheme not in ('http', 'https'):
                    continue
                stream = {'url': url, 'headers': dict(parse_qsl(encoded)),
                          'type': 'hls' if '.m3u8' in urlsplit(url).path.lower() else 'mp4'}
                if srstop.probe_stream(stream):
                    return stream
            except Exception:
                continue
        return {'error': 'No Vidara source passed the playback check. Choose another host.'}
    except srstop.SourceError as exc:
        return {'error': str(exc)}
    except Exception:
        return {'error': 'SRStop / Vidara could not resolve this episode. Please try again.'}
