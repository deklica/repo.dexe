"""Vidcore's release browser, using the local changelog as its only source."""

# =============================================================================
# Release note parsing and changelog dialog
# =============================================================================
import os
import re
import textwrap

import xbmcgui


# --- Parse releases --------------------------------------------------------
def parse_releases(text):
    releases = []
    current = None
    for line in text.splitlines():
        match = re.fullmatch(r'v?(\d+(?:\.\d+)+)\s*(?:-\s*|\()(\d{4}-\d{2}-\d{2})\)?', line.strip())
        if match:
            current = {'version': match[1], 'date': match[2], 'lines': []}
            releases.append(current)
        elif current is not None and not re.fullmatch(r'=+', line.strip()):
            current['lines'].append(line)
    for release in releases:
        release['body'] = '\n'.join(release.pop('lines')).strip() or 'No changes recorded.'
    return releases or [{'version': 'Changelog', 'date': '',
                         'body': text.strip() or 'No changes recorded yet.'}]


def format_notes(body):
    """Use readable headings and hanging bullets within the notes column."""
    paragraphs = []
    previous_heading = False
    for block in re.split(r'\n\s*\n|\n(?=- )', body.strip()):
        text = ' '.join(line.strip() for line in block.splitlines())
        bullet = text.startswith('- ')
        heading_block = text and text.isupper() and not bullet
        if heading_block:
            heading = text.capitalize()
            for word in ('HTTP', 'HLS', 'API', 'TV', 'AES', 'GCM', 'SRStop', 'Byse', 'HDHub', 'VOE', 'Kodi'):
                heading = re.sub(r'\b' + re.escape(word) + r'\b', word, heading, flags=re.I)
            text = '[B][COLOR FF38B6FF]' + heading + '[/COLOR][/B]'
        elif text.startswith('- '):
            text = textwrap.fill(text[2:], width=94, initial_indent='• ',
                                 subsequent_indent='   ', break_long_words=False,
                                 break_on_hyphens=False)
        if text:
            separator = '\n' if previous_heading and bullet else '\n\n'
            paragraphs.append((separator if paragraphs else '') + text)
            previous_heading = bool(heading_block)
    return ''.join(paragraphs)


# --- Preserve every note while separating release theme and topics ----------
def release_sections(body):
    theme, sections = [], []
    current = None
    for block in re.split(r'\n\s*\n|\n(?=- )', body.strip()):
        text = ' '.join(line.strip() for line in block.splitlines())
        if not text:
            continue
        if text.isupper() and not text.startswith('-'):
            current = {'title': text.capitalize(), 'body': []}
            sections.append(current)
        elif current is None and not text.startswith('-'):
            theme.append(text)
        else:
            if current is None:
                current = {'title': 'Changes', 'body': []}
                sections.append(current)
            current['body'].append(block.strip())
    result = [{'title': section['title'], 'body': '\n\n'.join(section['body'])}
              for section in sections if section['body']]
    if not result:
        result = [{'title': 'Release notes', 'body': body.strip() or 'No changes recorded.'}]
    return ' '.join(theme), result


def grouped_release(body):
    """Group categorized entries for display, keeping the saved notes intact."""
    entries = []
    for line in body.splitlines():
        if not line.strip() or re.fullmatch(r'=+', line.strip()):
            continue
        match = re.fullmatch(r'- (Added|Improved|Fixed|Maintenance) / ([^:]+): (.+)', line.strip())
        if not match:
            return release_sections(body)
        entries.append(match.groups())
    if not entries:
        return release_sections(body)
    groups = {}
    for kind, topic, detail in entries:
        lower = topic.casefold()
        if any(word in lower for word in ('settings', 'preferences', 'percentage picker', 'version styling')):
            group = 'Settings & interface'
        elif 'simkl' in lower:
            group = 'Simkl'
        elif any(word in lower for word in ('playback', 'watched', 'resume', 'hls', 'audio')):
            group = 'Playback'
        elif any(word in lower for word in ('source', 'srstop', 'picker', 'scan', 'provider')):
            group = 'Sources & pickers'
        elif kind == 'Maintenance':
            group = 'Maintenance & verification'
        else:
            group = 'Core & performance'
        topics = groups.setdefault(group, {})
        topics.setdefault(topic, []).append(detail)
    sections = []
    for group, topics in groups.items():
        chunks = []
        for topic, details in topics.items():
            if len(details) > 1:
                chunks.append('[B]' + topic + '[/B]')
                chunks.extend('- ' + detail for detail in details)
            else:
                chunks.append('- [B]' + topic + ':[/B] ' + details[0])
        sections.append({'title': group, 'body': '\n\n'.join(chunks)})
    summary = 'Updates to ' + ', '.join(name.lower() for name in list(groups)[:3]) + '.'
    return summary, sections


def section_label(title):
    labels = {'more ways to watch': 'Sources', 'playback and audio': 'Playback & audio',
              'the vidcore picker': 'Source pickers', 'core performance': 'Performance',
              'keeping the core clean': 'Code maintenance', 'provider connections': 'Provider handling',
              'checked and still open': 'Release checks'}
    return labels.get(title.casefold(), title)


def display_date(value):
    from datetime import date
    try:
        return date.fromisoformat(value).strftime('%d %b %Y')
    except (ValueError, TypeError):
        return str(value or '')


# --- Quiet version navigation and one continuous reading area ---------------
class ChangelogDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.releases = kwargs.pop('releases')
        self.index = -1
        super().__init__(*args, **kwargs)

    def onInit(self):
        self.index = -1
        listing = self.getControl(5100)
        listing.reset()
        items = []
        for index, release in enumerate(self.releases):
            item = xbmcgui.ListItem(label=release['version'])
            item.setProperty('badge', 'Latest' if index == 0 else '')
            item.setProperty('release_date', display_date(release['date']))
            items.append(item)
        listing.addItems(items)
        listing.selectItem(0)
        self.refresh()
        self.setFocusId(5100)

    def refresh(self):
        index = self.getControl(5100).getSelectedPosition()
        if not 0 <= index < len(self.releases) or index == self.index:
            return
        self.index = index
        release = self.releases[index]
        self.setProperty('vc_release', release['version'])
        self.setProperty('vc_date', display_date(release['date']))
        theme, sections = grouped_release(release['body'])
        self.setProperty('vc_release_summary', theme)
        body = '\n\n'.join(section_label(section['title']).upper() + '\n\n' + section['body']
                           for section in sections)
        self.getControl(5101).setText(format_notes(body))
        self.getControl(5101).scroll(0)

    def onAction(self, action):
        if action.getId() == 216:
            self.close()
        elif action.getId() in (9, 10, 92):
            # Back leaves the reading/Close area before leaving the dialog.
            # Preserve the selected release and its reading position.
            if self.getFocusId() != 5100:
                self.setFocusId(5100)
            else:
                self.close()
        else:
            self.refresh()

    def onFocus(self, control_id):
        self.refresh()

    def onClick(self, control_id):
        if control_id == 5102:
            self.close()
        elif control_id == 5103:
            self.refresh()
        elif control_id == 5100:
            self.refresh()
            self.setFocusId(5104)


# --- Show ------------------------------------------------------------------
def show(addon_path):
    try:
        with open(os.path.join(addon_path, 'changelog.txt'), encoding='utf-8-sig') as source:
            text = source.read()
    except (OSError, UnicodeError):
        text = 'Unable to read changelog.txt from the Vidcore addon folder.'
    dialog = ChangelogDialog('VidCoreChangelog.xml', addon_path, 'Default', '720p',
                             releases=parse_releases(text))
    try:
        dialog.doModal()
    finally:
        del dialog
