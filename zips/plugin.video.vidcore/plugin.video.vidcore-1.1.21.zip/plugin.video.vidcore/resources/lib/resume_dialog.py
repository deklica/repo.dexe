"""Compact Vidcore resume prompt for local and Simkl playback."""
import xbmcgui


class ResumeDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.progress = kwargs.pop('progress')
        self.source = kwargs.pop('source')
        self.result = None
        super().__init__(*args, **kwargs)

    def onInit(self):
        self.setProperty('vc_resume_detail', 'Saved %s playback · %.1f%% watched' % (self.source, self.progress))
        self.setFocusId(6300)

    def onClick(self, control_id):
        if control_id in (6300, 6301, 6302):
            self.result = self.progress if control_id == 6300 else 0 if control_id == 6301 else None
            self.close()

    def onAction(self, action):
        if action.getId() in (9, 10, 92, 216):
            self.close()


def choose(path, progress, source):
    dialog = ResumeDialog('VidCoreResume.xml', path, 'Default', '720p', progress=progress, source=source)
    dialog.doModal()
    result = dialog.result
    del dialog
    return result
