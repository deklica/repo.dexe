"""Resolve SRStop Byse links using Cosmos's native AES-GCM player resolver."""

# =============================================================================
# Byse episode source resolution
# =============================================================================
from urllib.parse import parse_qsl, urlsplit

from . import provider_resolvers, srstop, tmdb


# --- Resolve ---------------------------------------------------------------
def resolve(tmdb_id, season, episode, links=None):
    try:
        links = links if links is not None else srstop.discover_byse(tmdb.get_metadata(tmdb_id, 'tv'), season, episode)
        verification_error = ''
        for link in links:
            try:
                media = provider_resolvers.resolve_bysesukior(link['url'])
                if not media:
                    continue
                url, _, encoded_headers = media.partition('|')
                if urlsplit(url).scheme not in ('http', 'https'):
                    continue
                stream = {'url': url,
                          'type': 'hls' if '.m3u8' in urlsplit(url).path.lower() else 'mp4',
                          'headers': dict(parse_qsl(encoded_headers))}
                if srstop.probe_stream(stream):
                    return stream
            except srstop.SourceError as exc:
                if 'browser verification' in str(exc):
                    verification_error = str(exc)
                continue
            except Exception:
                continue
        if verification_error:
            return {'error': verification_error, '_retryable': False}
        return {'error': 'No Byse source passed the playback check. Choose another host.'}
    except srstop.SourceError as exc:
        return {'error': str(exc)}
    except Exception:
        return {'error': 'SRStop / Byse could not resolve this episode. Please try again.'}
