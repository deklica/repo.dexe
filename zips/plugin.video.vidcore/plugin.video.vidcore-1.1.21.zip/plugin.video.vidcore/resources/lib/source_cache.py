"""Short-lived source hints and recent provider health, cleared with caches."""

# =============================================================================
# Discovery hints, playable streams and provider health
# =============================================================================
import json
import time
import math
from . import metadata_cache


# --- Source Cache ----------------------------------------------------------
class SourceCache:
    def __init__(self, media, root=None):
        if root is None:
            import xbmcvfs
            root = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.vidcore/metadata_cache')
        self.root = root
        self._deferred = False
        self._pending_writes = {}
        self._last_flush = 0.0
        self.media = 'vidcore:sources:v1:' + json.dumps(media, separators=(',', ':'))
        self.generation, saved = metadata_cache.read_snapshot(root, (self.media, 'vidcore:source-health:v1'))
        self.previous = saved.get(self.media)
        if not isinstance(self.previous, dict):
            self.previous = {}
        if not isinstance(self.previous.get('discovery'), dict):
            self.previous.pop('discovery', None)
        streams = self.previous.get('streams')
        self.previous['streams'] = ({key: value for key, value in streams.items()
                                     if isinstance(value, dict)} if isinstance(streams, dict) else {})
        if not isinstance(self.previous.get('stream_times'), dict):
            self.previous['stream_times'] = {}
        self.reused_discovery = bool(self.discovery())
        self.health = saved.get('vidcore:source-health:v1')
        if not isinstance(self.health, dict):
            self.health = {}

    def _save(self, key, value, ttl):
        if self.generation is not None:
            if self._deferred:
                self._pending_writes[key] = (value, ttl)
            else:
                metadata_cache.put(self.root, key, value, ttl, generation=self.generation)

    # --- Coalesce scan updates while keeping cache clear generations intact ---
    def defer_writes(self):
        self._deferred = True

    def flush(self, force=False):
        now = time.monotonic()
        if not self._pending_writes or not force and now - self._last_flush < .5:
            return
        pending, self._pending_writes = self._pending_writes, {}
        metadata_cache.put_many(self.root, [(key, value, ttl) for key, (value, ttl) in pending.items()],
                                generation=self.generation)
        self._last_flush = now

    def finish_writes(self):
        try:
            self.flush(force=True)
        finally:
            self._deferred = False

    def discovery(self):
        rows = self.previous.get('discovery') or {}
        saved = self.previous.get('discovery_times') or {}
        if not isinstance(rows, dict) or not isinstance(saved, dict):
            return None
        now = time.time()
        fresh = {}
        for name, value in rows.items():
            try:
                age = now - float(saved.get(name, 0))
            except (ValueError, TypeError, OverflowError):
                continue
            if value and 0 <= age < 180:
                fresh[name] = value
        return fresh or None

    def save_discovery(self, value):
        rows = self.previous.setdefault('discovery', {})
        saved = self.previous.setdefault('discovery_times', {})
        if not isinstance(rows, dict):
            rows = self.previous['discovery'] = {}
        if not isinstance(saved, dict):
            saved = self.previous['discovery_times'] = {}
        now = time.time()
        for name, result in value.items():
            rows[name] = result
            saved[name] = now
        self._save(self.media, self.previous, 180)

    @staticmethod
    def key(key):
        return json.dumps(key, separators=(',', ':'))

    def stream(self, key):
        # Old per-host hints contain only the first successful SRStop link.
        if isinstance(key, tuple) and len(key) == 2 and key[0] == 'SRStop':
            return None
        encoded = self.key(key)
        stream = self.previous.get('streams', {}).get(encoded)
        try:
            age = time.time() - float(self.previous['stream_times'].get(encoded, 0))
        except (TypeError, ValueError, OverflowError):
            return None
        if not 0 <= age < 180:
            return None
        if (isinstance(key, tuple) and len(key) >= 2 and key[0] == 'RiveStream'
                and key[1] in ('mirage', 'apogee', 'vanguard', 'pulse', 'citadel')
                and stream and not stream.get('rivestream_refresh')):
            # Re-resolve pre-renewal hints rather than play an expiring URL
            # without knowing which provider/title must refresh it.
            return None
        return stream

    def success(self, key, stream):
        encoded = self.key(key)
        # Stateful openers/cookie jars cannot be reconstructed from JSON.
        if stream.get('opener') is not None:
            if self.previous['streams'].pop(encoded, None) is not None:
                self.previous['stream_times'].pop(encoded, None)
                self._save(self.media, self.previous, 180)
            return
        fields = ('url', 'type', 'headers', 'label', 'minimum_duration', 'advertised_heights',
                  'native_hls', 'refresh_tokens', 'vidbolt_backend', 'rivestream_refresh', 'stremio_refresh')
        safe = {field: stream[field] for field in fields if field in stream}
        self.previous['streams'][encoded] = safe
        self.previous['stream_times'][encoded] = time.time()
        self._save(self.media, self.previous, 180)

    def record(self, key, success, elapsed):
        name = self._health_name(key)
        row = self.health[name] = self._health_row(name)
        try:
            elapsed = float(elapsed)
            if not math.isfinite(elapsed) or elapsed < 0:
                elapsed = 10.0
        except (ValueError, TypeError, OverflowError):
            elapsed = 10.0
        row['score'] = .7 * row['score'] + .3 * int(success)
        row['seconds'] = .7 * row['seconds'] + .3 * elapsed
        row['updated'] = time.time()
        self._save('vidcore:source-health:v1', self.health, 3600)

    def rank(self, job):
        key = job[0]
        name = self._health_name(key)
        row = self._health_row(name)
        return (-row['score'], row['seconds'])

    @staticmethod
    def _health_name(key):
        if isinstance(key, tuple) and len(key) >= 2:
            return str(key[0]) + '/' + str(key[1])
        return str(key)

    def _health_row(self, name):
        row = self.health.get(name)
        if not isinstance(row, dict):
            row = {}
        try:
            age = time.time() - float(row.get('updated', 0))
            if not 0 <= age < 3600:
                row = {}
        except (TypeError, ValueError, OverflowError):
            row = {}
        result = {}
        for key, fallback in (('score', .5), ('seconds', 10.0)):
            try:
                value = float(row.get(key, fallback))
                if not math.isfinite(value) or value < 0 or (key == 'score' and value > 1):
                    value = fallback
            except (ValueError, TypeError, OverflowError):
                value = fallback
            result[key] = value
        return result
