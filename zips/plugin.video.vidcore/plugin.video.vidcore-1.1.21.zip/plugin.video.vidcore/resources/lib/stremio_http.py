"""Ready-to-use public HTTP add-ons through Stremio's JSON protocol."""

# =============================================================================
# Public manifests, catalogue identity and verified-picker HTTP candidates
# =============================================================================
import hashlib
import ipaddress
import json
import re
from urllib.parse import quote, unquote, urlsplit
from urllib.request import Request, urlopen

from . import shared_requests

# Public, unconfigured endpoints checked without accounts or debrid credentials.
PROVIDERS = {
    'PlavioHD': 'https://hd.plavio.site/manifest.json',
    'CNCVerse': 'https://cncverse.dpdns.org/manifest.json',
    'Flix-Streams Free': 'https://free.flixnest.app/manifest.json',
}
ADAPTIVE_PROVIDERS = frozenset(name.casefold() for name in PROVIDERS)
_JSON_LIMIT = 4 * 1024 * 1024
_HEADER_NAME = re.compile(r"^[!#$%&'*+.^_`|~0-9A-Za-z-]+$")
_OMIT_HEADERS = frozenset((
    'host', 'connection', 'content-length', 'transfer-encoding', 'upgrade',
    'proxy-authorization', 'proxy-connection', 'te', 'trailer', 'range', 'accept-encoding',
))


# --- Bounded public requests, shared across concurrent source lookups ---------
def _json(url, ttl=20, timeout=15, fresh=False):
    def read():
        with urlopen(Request(url, headers={'User-Agent': 'Mozilla/5.0',
                                          'Accept': 'application/json'}), timeout=timeout) as response:
            raw = response.read(_JSON_LIMIT + 1)
        if len(raw) > _JSON_LIMIT:
            raise ValueError('HTTP add-on response exceeds size limit')
        value = json.loads(raw)
        if not isinstance(value, dict):
            raise ValueError('HTTP add-on returned an invalid object')
        return value
    key = ('stremio-http-refresh' if fresh else 'stremio-http', url)
    return shared_requests.fetch(key, read, ttl=min(ttl, 5) if fresh else ttl, timeout=timeout)


def _stream_resource(manifest, kind):
    if not isinstance(manifest, dict):
        return None
    hints = manifest.get('behaviorHints') or {}
    if isinstance(hints, dict) and hints.get('configurationRequired') is True:
        return None
    types = manifest.get('types')
    resources = manifest.get('resources')
    if not isinstance(types, list) or not isinstance(resources, list) or kind not in types:
        return None
    for resource in resources:
        if resource == 'stream':
            prefixes = manifest.get('idPrefixes') or []
            return prefixes if isinstance(prefixes, list) else None
        if isinstance(resource, dict) and resource.get('name') == 'stream':
            resource_types = resource.get('types') or types
            if isinstance(resource_types, list) and kind in resource_types:
                prefixes = resource.get('idPrefixes') or manifest.get('idPrefixes') or []
                return prefixes if isinstance(prefixes, list) else None
    return None


def _identifier(prefixes, tmdb_id, kind, season, episode):
    prefixes = [prefix for prefix in prefixes if isinstance(prefix, str)]
    if not prefixes or any('tmdb:'.startswith(prefix) for prefix in prefixes):
        identifier = 'tmdb:' + tmdb_id
    elif any('tt'.startswith(prefix) for prefix in prefixes):
        from . import tmdb
        imdb = shared_requests.fetch(
            ('stremio-imdb', kind, tmdb_id),
            lambda: (tmdb.get_metadata(tmdb_id, 'movie' if kind == 'movie' else 'tv') or {}).get('imdb_id', ''),
            ttl=300, timeout=15)
        if not isinstance(imdb, str) or not re.fullmatch(r'tt[0-9]+', imdb):
            return None
        identifier = imdb
    else:
        return None
    return identifier + (':%d:%d' % (season, episode) if kind == 'series' else '')


# --- Keep direct HTTP media and declared headers; exclude other transports ---
def _http_url(value):
    if not isinstance(value, str) or not value or any(c.isspace() or ord(c) < 32 for c in value):
        return False
    try:
        parts = urlsplit(value)
        host = (parts.hostname or '').lower()
        if host == 'localhost' or host.endswith(('.localhost', '.local', '.internal')):
            return False
        try:
            if not ipaddress.ip_address(host).is_global:
                return False
        except ValueError:
            pass
        return bool(parts.scheme in ('http', 'https') and parts.hostname
                    and parts.username is None and parts.password is None
                    and (parts.port is None or 1 <= parts.port <= 65535))
    except ValueError:
        return False


def _headers(row, hints):
    proxy = hints.get('proxyHeaders') or {}
    if not isinstance(proxy, dict):
        return None
    headers = {'User-Agent': 'Mozilla/5.0'}
    for values in (row.get('headers'), proxy.get('request')):
        if values is None:
            continue
        if not isinstance(values, dict) or len(values) > 64:
            return None
        for name, value in values.items():
            if (not isinstance(name, str) or not _HEADER_NAME.fullmatch(name)
                    or not isinstance(value, str) or len(value) > 8192
                    or any(ord(c) < 32 and c != '\t' or ord(c) == 127 for c in value)):
                return None
            if name.lower() not in _OMIT_HEADERS:
                headers[name.title()] = value
    return headers if len(headers) <= 64 else None


def _text(value):
    if not isinstance(value, str):
        return ''
    return ' '.join(re.sub(r'[\x00-\x1f\x7f]', ' ', value).split()).replace('[', '(').replace(']', ')')


# --- Prefer English-capable releases; never infer audio from subtitle tags ----
def _foreign_only(row, filename):
    declared = row.get('languages') or row.get('language')
    if isinstance(declared, str):
        declared = re.split(r'[,/;+|\s]+', declared)
    if isinstance(declared, list):
        codes = {value.casefold() for value in declared if isinstance(value, str)}
        if codes & {'en', 'eng', 'english', 'en-us', 'en-gb'}:
            return False
        known = {'hi', 'hin', 'hindi', 'ta', 'tam', 'tamil', 'te', 'tel', 'telugu',
                 'fr', 'fra', 'fre', 'french', 'de', 'deu', 'ger', 'german',
                 'es', 'spa', 'spanish', 'it', 'ita', 'italian', 'ru', 'rus', 'russian',
                 'pt', 'por', 'portuguese', 'ja', 'jpn', 'japanese', 'ko', 'kor', 'korean'}
        if codes and codes <= known:
            return True
    # Providers commonly declare audio in release filenames or description
    # lines. Ignore subtitle-only lines to retain English with foreign subs.
    description = row.get('description') or row.get('title') or ''
    lines = description.splitlines() if isinstance(description, str) else []
    audio = ' '.join([str(row.get('name') or ''), filename] + [
        line for line in lines if not re.search(r'\b(subs?|subtitles?|subbed)\b', line, re.I)])
    if re.search(r'(?<!\w)(english|eng|en|multi|dual)(?!\w)|🇬🇧|🇺🇸', audio, re.I):
        return False
    return bool(re.search(
        r'(?<!\w)(hindi|tamil|telugu|malayalam|kannada|bengali|french|german|spanish|'
        r'italian|russian|portuguese|japanese|korean|vostfr|truefrench)(?!\w)|🇮🇳|🇫🇷|🇩🇪|🇪🇸|🇷🇺',
        audio, re.I))


def stream(row, provider):
    if not isinstance(row, dict) or row.get('error') or row.get('infoHash') or row.get('externalUrl'):
        return None
    url = row.get('url')
    if not _http_url(url):
        return None
    hints = row.get('behaviorHints') or {}
    if not isinstance(hints, dict):
        return None
    if row.get('drm') or row.get('drmKeyId') or row.get('drmKey'):
        return None
    path = unquote(urlsplit(url).path).lower().rstrip('/')
    filename = hints.get('filename') or ''
    if not isinstance(filename, str):
        filename = ''
    if _foreign_only(row, filename):
        return None
    if any(value.lower().endswith(('.torrent', '.zip', '.rar', '.7z', '.tar.gz')) for value in (path, filename)):
        return None
    headers = _headers(row, hints)
    if headers is None:
        return None
    name = _text(row.get('name'))
    description = _text(row.get('description') or row.get('title') or filename)
    label = name + (' / ' + description if description else '')
    if any(message in label.casefold() for message in (
            'configuration required', 'cookie required', 'api key required', 'no streams found', 'not configured')):
        return None
    identity = hashlib.sha256(json.dumps(
        [name, description, filename], ensure_ascii=False).encode('utf-8')).hexdigest()[:24]
    from .source_quality import advertised_heights
    media_type = ('hls' if '.m3u8' in path else 'dash' if '.mpd' in path
                  else 'mkv' if path.endswith('.mkv') else 'mp4' if path.endswith('.mp4') else 'auto')
    return {'url': url, 'type': media_type, 'headers': headers,
            'label': (label or provider)[:500], '_source_key': (provider, identity),
            'advertised_heights': advertised_heights(label + ' ' + filename)}


# --- Discover movie/episode candidates and retain stable renewal identity ----
def discover(provider, tmdb_id, kind='movie', season=0, episode=0, fresh=False):
    manifest_url = PROVIDERS.get(provider)
    identifier = str(tmdb_id)
    if not manifest_url or kind not in ('movie', 'tv', 'series') or not re.fullmatch(r'[0-9]+', identifier) or int(identifier) < 1:
        return []
    resource_kind = 'movie' if kind == 'movie' else 'series'
    try:
        season, episode = (int(season), int(episode)) if resource_kind == 'series' else (0, 0)
        if season < 0 or resource_kind == 'series' and episode < 1:
            return []
        manifest = _json(manifest_url, ttl=3600, timeout=8)
        prefixes = _stream_resource(manifest, resource_kind)
        if prefixes is None:
            return []
        media_id = _identifier(prefixes, identifier, resource_kind, season, episode)
        if not media_id:
            return []
        base = manifest_url.rsplit('/', 1)[0]
        payload = _json('%s/stream/%s/%s.json' % (base, resource_kind, quote(media_id, safe=':')), fresh=fresh)
        rows = payload.get('streams')
        if not isinstance(rows, list):
            return []
        candidates, seen = [], set()
        for row in rows[:200]:
            candidate = stream(row, provider)
            if candidate is None:
                continue
            signature = (candidate['url'], tuple(sorted(candidate['headers'].items())))
            if signature in seen:
                continue
            seen.add(signature)
            identity = candidate['_source_key'][1]
            candidate['stremio_refresh'] = dict(provider=provider, tmdb_id=identifier, kind=kind,
                season=season, episode=episode, identity=identity)
            candidates.append(candidate)
        # Offer each available quality before filling slots with more mirrors
        # of one large release. Media validation remains in the scan workers.
        qualities = {}
        for candidate in candidates:
            heights = candidate['advertised_heights']
            qualities.setdefault(heights[0] if heights else 0, []).append(candidate)
        ordered = [group[index] for index in range(max(map(len, qualities.values()), default=0))
                   for group in qualities.values() if index < len(group)]
        # Renewal searches every bounded response row: provider reordering
        # must not hide the selected release behind the picker's 24-row cap.
        return ordered if fresh else ordered[:24]
    except (OSError, ValueError, TypeError, OverflowError):
        return []


def renew(provider, tmdb_id, kind, season, episode, identity):
    """Refresh the selected variant without silently switching its identity."""
    for candidate in discover(provider, tmdb_id, kind, season, episode, fresh=True):
        if candidate['_source_key'][1] == identity:
            result = dict(candidate)
            result.pop('_source_key', None)
            return result
    return None
