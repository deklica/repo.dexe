"""Find SRStop TV episode links and probe SaveFiles MP4 streams."""

# =============================================================================
# SRStop episode discovery, host extraction and verification
# =============================================================================
import json
import re
import time
import threading
import unicodedata
from html import unescape
from html.parser import HTMLParser
from urllib.parse import urlencode, urljoin, urlsplit
from urllib.request import Request, urlopen
from . import srstop_hosts

BASE = 'https://srstop.link'
API = 'https://savefiles.com/api/file/direct_link'
HEADERS = {'User-Agent': 'Mozilla/5.0', 'Referer': BASE + '/'}
_PAGE_CACHE = {}
_PAGE_LOCKS = {}
_CACHE_LOCK = threading.Lock()
_CACHE_GENERATION = 0


# --- Page cache and diagnostics --------------------------------------------
def clear_cache():
    global _CACHE_GENERATION
    with _CACHE_LOCK:
        _CACHE_GENERATION += 1
        _PAGE_CACHE.clear()


def _log(message, level=None):
    """Log safe SaveFiles diagnostics without URLs, file codes or API keys."""
    try:
        import xbmc
        xbmc.log('VIDCORE SaveFiles: ' + message,
                 xbmc.LOGINFO if level is None else level)
    except Exception:
        pass


class SourceError(Exception):
    """A safe user-facing source resolution error."""


class _Links(HTMLParser):
    def __init__(self, body):
        super().__init__(convert_charrefs=True)
        self.links = []
        self.current = None
        self.feed(body)

    def handle_starttag(self, tag, attrs):
        if tag == 'a':
            self.current = [dict(attrs), '']
        elif self.current is not None and tag == 'img':
            image = dict(attrs)
            self.current[1] += ' ' + (image.get('alt') or '') + ' ' + (image.get('title') or '')

    def handle_data(self, data):
        if self.current is not None:
            self.current[1] += ' ' + data

    def handle_endtag(self, tag):
        if tag == 'a' and self.current is not None:
            self.links.append(self.current)
            self.current = None


# --- Episode page request transport ----------------------------------------
def _fetch(url, timeout=15):
    """Share SRStop pages across host resolvers in the same scan."""
    if urlsplit(url).hostname != 'srstop.link':
        return _fetch_uncached(url, timeout)
    with _CACHE_LOCK:
        lock = _PAGE_LOCKS.setdefault(url, threading.Lock())
        generation = _CACHE_GENERATION
    if not lock.acquire(timeout=timeout):
        raise SourceError('Shared SRStop page request timed out.')
    try:
        with _CACHE_LOCK:
            cached = _PAGE_CACHE.get(url)
        if cached and time.monotonic() - cached[0] < 60:
            return cached[1]
        body = _fetch_uncached(url, timeout)
        with _CACHE_LOCK:
            if generation == _CACHE_GENERATION:
                if url not in _PAGE_CACHE and len(_PAGE_CACHE) >= 64:
                    _PAGE_CACHE.pop(next(iter(_PAGE_CACHE)))
                _PAGE_CACHE[url] = (time.monotonic(), body)
        return body
    finally:
        lock.release()


def _fetch_uncached(url, timeout=15):
    try:
        with urlopen(Request(url, headers=HEADERS), timeout=timeout) as response:
            body = response.read(4 * 1024 * 1024 + 1)
        if len(body) > 4 * 1024 * 1024:
            raise ValueError('Oversized response')
        return body.decode('utf-8', errors='replace')
    except Exception:
        # Network exception text may contain the configured API key or a
        # signed media URL, so only expose a fixed message.
        raise SourceError('Unable to contact SRStop or SaveFiles. Please try again.') from None


def _json(url, timeout=15):
    try:
        return json.loads(_fetch(url, timeout))
    except (ValueError, TypeError):
        raise SourceError('The source returned an unexpected response.') from None


# --- Show matching and episode lookup --------------------------------------
def _site_url(value):
    url = urljoin(BASE + '/', str(value or ''))
    parts = urlsplit(url)
    if (parts.scheme == 'https' and parts.netloc == 'srstop.link'
            and parts.path.startswith('/show/')):
        return url
    return ''


def _normal(value):
    value = unicodedata.normalize('NFKD', unescape(str(value or ''))).casefold()
    return ''.join(char for char in value if char.isalnum())


def match_show(rows, meta):
    """Match by external ID, or one unique exact title and year."""
    if not isinstance(rows, list):
        raise SourceError('SRStop returned an unexpected search response.')
    matches, fallback = [], []
    names = {_normal(meta.get(key)) for key in ('title', 'originaltitle')}
    names.discard('')
    for row in rows:
        if not isinstance(row, dict) or not _site_url(row.get('permalink')):
            continue
        pairs = [(str(meta.get(a) or ''), str(row.get(b) or ''))
                 for a, b in (('imdb_id', 'imdb_id'), ('tvdb_id', 'ttvdb_id'))]
        if any(left and right and left != right for left, right in pairs):
            continue
        if any(left and left == right for left, right in pairs):
            matches.append(row['permalink'])
        elif (_normal(row.get('title')) in names and meta.get('year')
              and str(row.get('year')) == str(meta['year'])):
            fallback.append(row['permalink'])
    candidates = list(dict.fromkeys(matches or fallback))
    if len(candidates) != 1:
        raise SourceError('No unambiguous matching show was found on SRStop.')
    return candidates[0]



def _find_show(meta):
    """Retry a shortened search, retaining strict ID/title-year matching."""
    titles = list(dict.fromkeys(str(meta.get(key) or '').strip()
                                for key in ('title', 'originaltitle')))
    titles = [title for title in titles if title]
    if not titles:
        raise SourceError('Show metadata is unavailable.')
    queries = list(dict.fromkeys(titles + [' '.join(title.split()[:3])
                                          for title in titles
                                          if len(title.split()) > 3]))
    for query in queries:
        rows = _json(BASE + '/ajax/search.php?' + urlencode({'q': query}))
        try:
            return match_show(rows, meta)
        except SourceError:
            if not isinstance(rows, list):
                raise
    raise SourceError('No unambiguous matching show was found on SRStop.')


def episode_url(body, season, episode, show=''):
    suffix = '/season/%d/episode/%d' % (season, episode)
    show_path = urlsplit(_site_url(show)).path.rstrip('/') if show else ''
    for attrs, _text in _Links(body).links:
        url = _site_url(attrs.get('href'))
        path = urlsplit(url).path.rstrip('/')
        if not url or not path.endswith(suffix):
            continue
        if show:
            prefix = path[:-len(suffix)]
            # SRStop uses both the show slug and episode-specific slugs,
            # e.g. /show/the-simpsons-s37e01/season/37/episode/1.
            tagged = re.fullmatch(re.escape(show_path) + r'-s(\d+)e(\d+)', prefix, re.I)
            if prefix != show_path and not (
                    tagged and int(tagged[1]) == season and int(tagged[2]) == episode):
                continue
        return url
    raise SourceError('This episode is not listed on SRStop.')


def _episode_page(meta, season, episode):
    """Match standard seasons first, then explicit TMDB year-season names."""
    show = _find_show(meta)
    try:
        page = _fetch(show.rstrip('/') + '/season/%d' % season)
        return episode_url(page, season, episode, show)
    except SourceError:
        pass
    from . import tmdb
    if not meta.get('tmdb_id'):
        raise SourceError('This episode is not listed on SRStop.')
    seasons = tmdb.get_tv_seasons(meta['tmdb_id'])
    selected = next((row for row in seasons if row.get('number') == season), {})
    # Do not guess from air dates: only named calendar/sporting seasons map.
    match = re.fullmatch(r'(?:Season\s+)?((?:19|20)\d{2})(?:\s*[/\-]\s*(\d{2}|\d{4}))?',
                         selected.get('name', '').strip(), re.I)
    if not match:
        raise SourceError('This episode is not listed on SRStop.')
    first = int(match[1])
    last = int(match[2]) if match[2] else first
    if last < 100:
        last += first // 100 * 100
        if last < first:
            last += 100
    for year in dict.fromkeys((last, first)):
        if year == season:
            continue
        try:
            page = _fetch(show.rstrip('/') + '/season/%d' % year)
            return episode_url(page, year, episode, show)
        except SourceError:
            continue
    raise SourceError('This episode is not listed on SRStop.')


# --- Host link decoding and extraction -------------------------------------
def _decode_link(value):
    """Decode SRStop's hex character-offset links without executing scripts."""
    match = re.search(r"dbneg\(['\"]([0-9a-fA-F-]+)['\"]\)", value or '')
    if not match:
        return ''
    try:
        numbers = [int(part, 16) for part in match[1].split('-')]
        offset = numbers[0] - ord('h')
        result = ''.join(chr(number - offset) for number in numbers)
        return result if result.startswith(('https://', 'http://')) else ''
    except (ValueError, OverflowError, IndexError):
        return ''




# --- Labelled host discovery with original URLs and quality ranking ----------
def _host_links(body, provider):
    found, seen = [], set()
    anchors = _Links(body).links if isinstance(body, str) else body
    for attrs, text in anchors:
        url = _decode_link(attrs.get('onclick')) or unescape(attrs.get('href') or '')
        label = ' '.join([text] + [attrs.get(key) or '' for key in
                                 ('title', 'aria-label', 'data-host', 'data-provider')])
        if url in seen or not srstop_hosts.accept_link(provider, url, label):
            continue
        seen.add(url)
        quality = re.search(r'\b(2160|1080|720|480|360)(?:p)?\b', text, re.I)
        row = {'url': url, 'quality': int(quality[1]) if quality else 0}
        if provider in ('SaveFiles (HLS)', 'LuluStream'):
            row['code'] = srstop_hosts.file_code(provider, url)
        found.append(row)
    return sorted(found, key=lambda row: row['quality'], reverse=True)


def savefiles_links(body):
    return _host_links(body, 'SaveFiles (HLS)')


def lulustream_links(body):
    return _host_links(body, 'LuluStream')


def streamtape_links(body):
    return _host_links(body, 'Streamtape')


# --- Episode host discovery ------------------------------------------------
def discover_hosts(meta, season, episode):
    """List only supported hosts linked on the exact matched show episode."""
    season, episode = int(season), int(episode)
    if season < 0 or episode < 1:
        raise SourceError('A valid season and episode are required.')
    url = _episode_page(meta, season, episode)
    body = _Links(_fetch(url)).links
    parsers = (('SaveFiles (HLS)', savefiles_links),
               ('LuluStream', lulustream_links),
               ('Streamtape', streamtape_links),
               ('DoodStream', doodstream_links), ('Byse', byse_links), ('VOE', voe_links),
               ('Morencius', morencius_links), ('Vidara', vidara_links),
               ('Streamplay', streamplay_links))
    return {name: links for name, parser in parsers
            for links in [parser(body)] if links}


def discover(meta, season, episode):
    url = _episode_page(meta, season, episode)
    links = savefiles_links(_fetch(url))
    if not links:
        _log('SRStop episode has no SaveFiles links (season=%s episode=%s)' %
             (season, episode), _warning_level())
        raise SourceError('No SaveFiles links are listed for this episode.')
    qualities = ','.join('%sp' % link['quality'] if link['quality'] else 'unknown'
                         for link in links)
    _log('SRStop episode links found (season=%s episode=%s count=%d qualities=%s)' %
         (season, episode, len(links), qualities))
    return links


# --- Additional host extractors and discovery helpers ----------------------
def doodstream_links(body):
    return _host_links(body, 'DoodStream')


def discover_doodstream(meta, season, episode):
    """Find DoodStream/Playmogo links for the exact matched show episode."""
    url = _episode_page(meta, season, episode)
    links = doodstream_links(_fetch(url))
    if not links:
        raise SourceError('No DoodStream or Playmogo links are listed for this episode.')
    return links


def discover_lulustream(meta, season, episode):
    """Find LuluStream links on the SRStop episode page."""
    url = _episode_page(meta, season, episode)
    links = lulustream_links(_fetch(url))
    if not links:
        raise SourceError('No LuluStream links are listed for this episode.')
    _log('SRStop LuluStream links found (season=%s episode=%s count=%d)' %
         (season, episode, len(links)))
    return links


def discover_streamtape(meta, season, episode):
    """Find Streamtape links on the matched SRStop episode page."""
    url = _episode_page(meta, season, episode)
    links = streamtape_links(_fetch(url))
    if not links:
        raise SourceError('No Streamtape links are listed for this episode.')
    _log('SRStop Streamtape links found (season=%s episode=%s count=%d)' %
         (season, episode, len(links)))
    return links


def byse_links(body):
    return _host_links(body, 'Byse')


def discover_byse(meta, season, episode):
    """Find Byse sources for the matched show and exact episode."""
    url = _episode_page(meta, season, episode)
    links = byse_links(_fetch(url))
    if not links:
        raise SourceError('No Byse links are listed for this episode.')
    return links


def voe_links(body):
    return _host_links(body, 'VOE')


def morencius_links(body):
    return _host_links(body, 'Morencius')


def discover_morencius(meta, season, episode):
    url = _episode_page(meta, season, episode)
    links = morencius_links(_fetch(url))
    if not links:
        raise SourceError('No Morencius links are listed for this episode.')
    return links


def discover_voe(meta, season, episode):
    url = _episode_page(meta, season, episode)
    links = voe_links(_fetch(url))
    if not links:
        raise SourceError('No VOE links are listed for this episode.')
    return links


def vidara_links(body):
    return _host_links(body, 'Vidara')


def streamplay_links(body):
    return _host_links(body, 'Streamplay')


def discover_streamplay(meta, season, episode):
    url = _episode_page(meta, season, episode)
    links = streamplay_links(_fetch(url))
    if not links:
        raise SourceError('No Streamplay links are listed for this episode.')
    return links


def discover_vidara(meta, season, episode):
    url = _episode_page(meta, season, episode)
    links = vidara_links(_fetch(url))
    if not links:
        raise SourceError('No Vidara links are listed for this episode.')
    return links


# --- Media probes and playable source selection ----------------------------
def _warning_level():
    try:
        import xbmc
        return xbmc.LOGWARNING
    except Exception:
        return None


def probe_stream(stream, timeout=8):
    """Read a small validation sample from a real candidate; never play it."""
    stream_type = stream.get('type')
    if stream_type not in ('hls', 'mp4'):
        _log('validation sample rejected (unsupported stream type)')
        return False
    _log('reading validation sample from real %s candidate (playback uses the resolved stream URL)' %
         stream_type)
    headers = dict(stream.get('headers') or {})
    headers.update({'Range': 'bytes=0-16383', 'Accept-Encoding': 'identity'})
    try:
        with urlopen(Request(stream['url'], headers=headers), timeout=timeout) as response:
            if response.status not in (200, 206):
                _log('validation sample failed (type=%s http_status=%s)' %
                     (stream_type, response.status), _warning_level())
                return False
            if response.status == 206 and not re.match(
                    r'bytes 0-\d+/\d+', response.headers.get('Content-Range', '')):
                _log('validation sample failed (type=%s invalid_range_response)' %
                     stream_type, _warning_level())
                return False
            sample = response.read(16384)
        if stream_type == 'hls':
            valid = sample.lstrip().startswith(b'#EXTM3U') and b'#EXT-X-' in sample
        else:
            valid = False
            offset = 0
            while offset + 16 <= len(sample):
                size = int.from_bytes(sample[offset:offset + 4], 'big')
                box = sample[offset + 4:offset + 8]
                if size < 8:
                    break
                if box == b'ftyp':
                    valid = size >= 16 and offset + size <= len(sample) and len(sample) > offset + size
                    break
                if box not in (b'free', b'skip', b'wide'):
                    break
                offset += size
        _log('validation sample %s (type=%s bytes=%d; sample is not played)' %
             ('passed' if valid else 'failed', stream_type, len(sample)),
             None if valid else _warning_level())
        return valid
    except Exception as exc:
        _log('validation sample request failed (type=%s error=%s)' %
             (stream_type, type(exc).__name__), _warning_level())
        return False


def direct_stream(key, code, deadline=None):
    timeout = min(12, max(1, deadline - time.monotonic())) if deadline else 12
    # SaveFiles' API docs require hls=1 to request an HLS manifest.
    data = _json(API + '?' + urlencode({'key': key, 'file_code': code, 'hls': '1'}), timeout)
    if not isinstance(data, dict) or str(data.get('status')) != '200':
        status = str(data.get('status', 'unknown')) if isinstance(data, dict) else 'invalid-response'
        status = status if re.fullmatch(r'[0-9]{3}', status) else 'invalid-response'
        _log('direct-link API rejected candidate (status=%s)' % status, _warning_level())
        raise SourceError('SaveFiles could not resolve this file. Check API access or try another link.')
    result = data.get('result')
    if not isinstance(result, dict):
        raise SourceError('SaveFiles returned no playable file.')
    # SaveFiles only returns its HLS manifest when HLS is enabled for the
    # account. Prefer this so Kodi can use InputStream Adaptive. If that
    # option is unavailable, retain the already-tested native MP4 path.
    hls_url = result.get('hls_direct')
    if isinstance(hls_url, str) and urlsplit(hls_url).scheme in ('http', 'https') and urlsplit(hls_url).netloc:
        stream = {'url': hls_url, 'type': 'hls', 'headers': {'User-Agent': 'Mozilla/5.0'}}
        probe_timeout = min(8, max(1, deadline - time.monotonic())) if deadline else 8
        if probe_stream(stream, probe_timeout):
            _log('real candidate accepted (type=hls); returning resolved playback URL')
            return stream
        _log('HLS candidate rejected; checking available MP4 versions', _warning_level())
    versions = result.get('versions') or []
    if not isinstance(versions, list):
        versions = []
    ranks = {'o': 4, 'h': 3, 'n': 2, 'l': 1}
    versions = sorted((item for item in versions if isinstance(item, dict)),
                      key=lambda item: ranks.get(item.get('name'), 0), reverse=True)
    for index, version in enumerate(versions, 1):
        if deadline is not None and time.monotonic() >= deadline:
            break
        url = version.get('url')
        if not isinstance(url, str) or urlsplit(url).scheme not in ('http', 'https') or not urlsplit(url).netloc:
            continue
        stream = {'url': url, 'type': 'mp4', 'headers': {'User-Agent': 'Mozilla/5.0'}}
        probe_timeout = min(8, max(1, deadline - time.monotonic())) if deadline else 8
        if probe_stream(stream, probe_timeout):
            _log('real candidate accepted (type=mp4 version_rank=%d); returning resolved playback URL' % index)
            return stream
        _log('MP4 version candidate rejected (rank=%d)' % index, _warning_level())
    raise SourceError('No accessible MP4 version was found for this file.')


def working_stream(key, links):
    """Try ranked SaveFiles files until an HLS or MP4 probe passes."""
    deadline = time.monotonic() + 60
    _log('checking %d real SaveFiles episode candidate(s); no test media is used for playback' %
         len(links))
    for index, link in enumerate(links, 1):
        if time.monotonic() >= deadline:
            break
        try:
            stream = direct_stream(key, link['code'], deadline)
            _log('episode candidate %d/%d selected for playback (type=%s)' %
                 (index, len(links), stream.get('type', 'unknown')))
            return stream
        except SourceError:
            _log('episode candidate %d/%d could not be resolved' %
                 (index, len(links)), _warning_level())
            continue
    raise SourceError('No SaveFiles source passed the playback check. Files may be unavailable or account access may be restricted.')


def resolve(tmdb_id, season, episode, links=None):
    import xbmcaddon
    from . import tmdb

    key = xbmcaddon.Addon('plugin.video.vidcore').getSetting('savefiles_api_key').strip()
    if not key:
        _log('resolution stopped (API key is not configured)', _warning_level())
        return {'error': 'SaveFiles API access is not configured in Vidcore.'}
    _log('resolving real episode stream (tmdb_id=%s season=%s episode=%s)' %
         (tmdb_id, season, episode))
    try:
        meta = tmdb.get_metadata(tmdb_id, 'tv')
        stream = working_stream(key, links if links is not None else discover(meta, season, episode))
        _log('resolution complete (type=%s; selected real episode stream)' % stream['type'])
        return stream
    except SourceError as exc:
        _log('resolution failed (%s)' % str(exc), _warning_level())
        return {'error': str(exc)}
    except Exception as exc:
        _log('resolution failed (unexpected error=%s)' % type(exc).__name__, _warning_level())
        return {'error': 'SRStop / SaveFiles could not resolve this episode. Please try again.'}


# --- Bounded recovery from stale episode links ------------------------------
def resolve_host(provider, resolver, tmdb_id, season, episode, refresh=False):
    """Retry failed host resolution once after refreshing SRStop discovery."""
    from . import shared_requests
    if not refresh:
        result = resolver(tmdb_id, season, episode)
        if isinstance(result, dict) and result.get('_retryable') is False:
            return result
        if isinstance(result, dict) and result.get('url') and not result.get('error'):
            return result
    def rediscover():
        from . import tmdb
        clear_cache()
        return discover_hosts(tmdb.get_metadata(tmdb_id, 'tv'), season, episode)
    fresh = shared_requests.fetch(
        ('srstop-refresh', str(tmdb_id), int(season), int(episode)),
        rediscover, ttl=15, timeout=30)
    if provider not in fresh:
        return {'error': 'This host is no longer listed for the episode. Choose another host.'}
    return resolver(tmdb_id, season, episode)
