"""Branded Vidcore watched-percentage selection."""
import xbmcgui
from .simkl_playback import watched_threshold


class WatchedThresholdDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.current = watched_threshold(kwargs.pop('current', 80))
        self.result = None
        super().__init__(*args, **kwargs)

    def onInit(self):
        self.setProperty('vc_threshold_current', '%d%%' % self.current)
        listing = self.getControl(6200)
        listing.reset()
        items = []
        for value in range(50, 101):
            item = xbmcgui.ListItem(label='%d%%' % value)
            item.setProperty('detail', 'Current setting' if value == self.current else
                             'Simkl default' if value == 80 else '')
            items.append(item)
        listing.addItems(items)
        listing.selectItem(self.current - 50)
        self.setFocusId(6200)

    def onClick(self, control_id):
        if control_id == 6200:
            position = self.getControl(6200).getSelectedPosition()
            if 0 <= position <= 50:
                self.result = 50 + position
                self.close()
        elif control_id == 6201:
            self.close()

    def onAction(self, action):
        if action.getId() in (9, 10, 92, 216):
            self.close()


def choose(path, current):
    dialog = WatchedThresholdDialog('VidCoreWatchedThreshold.xml', path, 'Default', '720p',
                                   current=current)
    dialog.doModal()
    result = dialog.result
    del dialog
    return result
