# Simkl integration audit — 1.1.9

Checked against the official documentation at https://api.simkl.org on 2026-10-27.

## Account connection

Vidcore uses AUTH V2 device authorization with S256 PKCE and the `media:read media:write` scopes. The custom authorization window displays the verification address and code. Token polling follows the supplied interval and increases the interval on `slow_down`. Temporary network, server and rate-limit errors leave authorization pending. Tokens are saved only after the dialog accepts success; cancellation cannot commit a late response.

Disconnect submits the saved refresh token (or access token) to `/oauth2/revoke`, then removes local credentials even if the remote call fails. Simkl revokes the grant for this sign-in rather than every device on the account.

## Submenus

| Menu | Behaviour |
| --- | --- |
| Watching / On Hold | Shows and anime; movies do not support these statuses. |
| Plan to Watch / Completed / Dropped | Separate Movies and Shows sections. |
| Watched History | Local library snapshot, ordered by latest available watched timestamp. |
| Next Episodes | Next released unwatched TV episode from Simkl, matched to a playable TMDB entry. |
| My Lists | Lazy, paginated custom-list browsing for PRO/VIP accounts. |
| Sync Simkl | Force an activity check and invalidate cached resource pages for the next visit. |

Titles without a usable TMDB match remain unavailable rather than opening a guessed title. Anime-specific episode numbering is not converted into TV episode coordinates by this menu audit.

## Sync and custom lists

The first sync reads `/sync/activities` before obtaining the library. Later checks compare activity timestamps and use the previous `all` timestamp as `date_from`. Deletions are reconciled with `extended=simkl_ids_only`. A failed download rolls back the transaction so the saved cursor is retained.

`400 max_items` responses are split by media type, then by valid status buckets when necessary, preserving the original query flags and delta cursor. If an individual bucket still exceeds the server limit, the sync fails safely and keeps its previous snapshot.

Custom lists are fetched only when opened. Index pages use the activity timestamp; item pages use the list's `updated_at`. Automatic lists also have a bounded cache lifetime. Back-navigation reuses cached pages. Explicit Sync marks resource pages dirty without eagerly downloading all lists.

## Playback and context actions

Scrobbling sends start, pause, resume/start and stop on player events. Local progress sampling and seeks do not send periodic API requests. Natural completion reports 100%. A stop counts as watched only when Simkl confirms a scrobble or reports an already-watched conflict. Confirmed episode completion refreshes Next Episodes, including playback launched from the normal catalogue.

Plan to Watch uses `/sync/add-to-list`; watched and unwatched actions use `/sync/history` and `/sync/history/remove`. Episode payloads use nested show, season and episode objects. Whole-show unwatching remains explicitly scoped to known seasons to avoid deleting watchlist membership accidentally.

## Validation and limits

Automated tests cover authorization cancellation and transient errors, scrobble response handling, special-season episode payloads, valid status submenus, oversized-library splitting, manual cache invalidation and local disconnect after remote failure. Tests use mocked API responses and temporary SQLite databases. This audit does not perform writes to a live Simkl account or claim end-to-end account verification.

## Official references

- https://api.simkl.org/authentication
- https://api.simkl.org/api-reference/oauth2-tokens
- https://api.simkl.org/conventions/headers
- https://api.simkl.org/conventions/list-statuses
- https://api.simkl.org/guides/sync
- https://api.simkl.org/guides/scrobble
- https://api.simkl.org/guides/mark-as-watched
- https://api.simkl.org/guides/custom-lists
