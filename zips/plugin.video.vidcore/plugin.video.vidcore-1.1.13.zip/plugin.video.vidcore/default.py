# Vidcore derived from Cosmos by Zeus768 and Enigma. GPL-2.0-only.
import os
import sys
import time
from urllib.parse import parse_qsl, urlencode
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
from resources.lib import vidcore


def show_startup_notice(icon):
    window = xbmcgui.Window(10000)
    key = 'Vidcore.StartupNoticeShown'
    folder = xbmc.getInfoLabel('Container.FolderPath').lower()
    inside_vidcore = folder.startswith('plugin://plugin.video.vidcore/')
    # Kodi reruns the root directory on Back. Keep the flag while navigating
    # within Vidcore, but reset it when entering from another directory.
    if inside_vidcore and window.getProperty(key) == 'true':
        return
    window.setProperty(key, 'true')
    xbmcgui.Dialog().notification(
        'Vidcore', 'Any issues? Please report them to @enigmawiz on Telegram.',
        icon, 15000, False)


def run(argv):
    handle = int(argv[1])
    addon = xbmcaddon.Addon()
    path = addon.getAddonInfo('path')
    window = xbmcgui.Window(10000)
    try:
        last_service = max(float(window.getProperty('Vidcore.Simkl.ServiceAlive') or 0),
                           float(window.getProperty('Vidcore.Simkl.ServiceStarting') or 0))
    except ValueError:
        last_service = 0
    if time.time() - last_service > 10:
        window.setProperty('Vidcore.Simkl.ServiceStarting', str(time.time()))
        xbmc.executebuiltin('RunScript("%s")' % os.path.join(path, 'service.py'))
    icon = os.path.join(path, 'icon.jpg')
    fanart = os.path.join(path, 'fanart.jpg')
    params = dict(parse_qsl(argv[2].lstrip('?')))
    action = params.pop('action', 'vidcore_root')
    from resources.lib import debug_bundle
    debug_bundle.log('ROUTE', 'version=%s action=%s kind=%s tmdb=%s season=%s episode=%s' % (
        addon.getAddonInfo('version'), action, params.get('kind', ''),
        params.get('tmdb_id', ''), params.get('season', ''), params.get('episode', '')))
    if action == 'vidcore_root':
        show_startup_notice(icon)
    from resources.lib import simkl
    simkl_connected = simkl.has_token()
    def build_url(**values):
        return argv[0] + '?' + urlencode(values)
    def add_directory(label, url, thumb='', fanart=fanart, info=None, is_folder=True, is_playable=False, metadata=None):
        identity = dict(parse_qsl(url.split('?', 1)[-1]))
        if (not thumb or thumb == icon) and not metadata:
            from resources.lib import menu_icons
            thumb = menu_icons.artwork(path, label, identity) or thumb
        item = xbmcgui.ListItem(label=label)
        item.setArt({'icon': thumb or icon, 'thumb': thumb or icon, 'poster': thumb or icon, 'fanart': fanart})
        if info:
            from resources.lib import tmdb
            tmdb.apply_directory_info(item, info)
        if metadata:
            from resources.lib import tmdb
            tmdb.apply_to_listitem(item, metadata, content=metadata.get('content', 'movie'))
            if metadata.get('tmdb_id'):
                item.getVideoInfoTag().setUniqueIDs({'tmdb': str(metadata['tmdb_id'])}, 'tmdb')
        if is_playable:
            item.setProperty('IsPlayable', 'true')
        from resources.lib import simkl_context
        context = simkl_context.actions(identity, label, info, metadata, simkl_connected, build_url)
        if context:
            item.addContextMenuItems(context)
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=is_folder)
    if action == 'changelog':
        from resources.lib import changelog_dialog
        changelog_dialog.show(path)
        xbmcplugin.endOfDirectory(handle)
    elif action == 'settings':
        from resources.lib import settings_dialog
        settings_dialog.show()
        xbmcplugin.endOfDirectory(handle)
    elif action.startswith('simkl_'):
        from resources.lib import simkl_ui
        simkl_ui.run(action, params, handle, add_directory, build_url)
    elif action.startswith('vidcore_'):
        vidcore.run(action, params, handle, add_directory, build_url, icon, fanart)
    else:
        xbmcplugin.endOfDirectory(handle, succeeded=False)

if __name__ == '__main__':
    try:
        run(sys.argv)
    except Exception:
        from resources.lib import debug_bundle
        debug_bundle.error('Unhandled menu error')
        xbmcgui.Dialog().notification('Vidcore', 'Unable to open. See Kodi log.', xbmcgui.NOTIFICATION_ERROR)
