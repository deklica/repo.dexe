# Vidcore

Independent Kodi movie and TV add-on, version 1.1.13. Derived from Cosmos code by Zeus768 and Enigma under GPL-2.0-only. Source attribution is retained; Cosmos and Cosmos Lite do not need to be installed.

## Requirements

- Kodi with Python 3.
- InputStream Adaptive is optional. HLS streams use Kodi's built-in player when it is absent. Vidcore offers installation or enabling it for selected DASH sources that require it; some Linux distributions require their system package instead.
- Internet access for catalogues, metadata and playback providers.

Playback resolvers are bundled with Vidcore. ResolveURL, Cosmos, Cosmos Lite, Google Drive, YouTube and InputStream Helper are not required. No additional Python packages need to be installed.

On a fresh Kodi install, open Add-ons > Video add-ons > Vidcore, browse or search for a title, then choose a checked source. Included metadata keys work without setup; Simkl sign-in is optional. The branded dialogs use fonts available in Kodi's default Estuary skin. Vidcore's custom source pickers, settings and Simkl authorization window are the default on every skin. Native dialogs are available only as an explicit General setting; their source picker includes Film / episode details and Refresh available sources. Vidcore never changes the user's global skin or add-on database.

Kodi may show dependencies from its repository catalogue as well as the installed add-on. The repository must publish the updated manifest for its dependency listing to reflect this release.

## Browsing and playback

Browse and search movies, TV shows and people using TMDB metadata. Streaming-service catalogues use the country detected from your internet connection; a VPN uses its exit country. The General country setting is the fallback when detection fails. Japanese-original titles are excluded from catalogue listings.

Select a movie or episode to discover available playback sources. Provider discovery and stream checks run together, with one worker slot offered to each provider before its extra servers. The source picker opens after the first stream passes checks and continues updating as other checks finish. Selecting a source or pressing Back stops the scan. Availability varies by provider and title; a successful check does not guarantee uninterrupted playback.

The picker shows artwork, episode details and quality badges where available. Quality badges describe advertised HLS qualities or detected MP4 dimensions; adaptive playback selects its own quality. Some streams use a local relay to preserve request headers or support seeking.

MovieUniverse sources use the selected TMDB ID and exact season and episode. Supported VSrcH servers appear only after their playlists and video samples pass checks.

## Simkl

Connect through Settings > Simkl or My Tracking > Simkl. Vidcore uses its own authorization and account-scoped cache. Playback tracking requires authorization and scrobbling to be enabled.

Simkl menus include watching lists, watched history and Next Episodes. Catalogue context menus support Plan to Watch and watched/unwatched updates. Next Episodes shows the next released unwatched episode for each watching show and refreshes after confirmed watched playback. Entries without a playable TMDB match cannot be played from the catalogue.

My Lists displays supported custom lists returned by Simkl and requires a PRO/VIP account. Lists load when opened. Use Sync Simkl for a manual refresh; routine menu navigation reuses cached data.

## Maintenance

For bug reports, enable **Detailed Vidcore logging** in Vidcore Settings, reproduce the issue, then send `kodi.log` with the movie/show, episode and steps that failed. Tools > Report a Bug shows the log location. Detailed logging includes menu routes, source results and timing; errors include diagnostic traces. Vidcore filters credentials and signed URLs from these diagnostics. Other addons write to the same log, so review it before sharing. Disable detailed logging after reporting. Nothing is uploaded automatically.

Use Tools > Clear Cache to clear Vidcore metadata, source hints and Kodi-cached artwork owned by Vidcore. Shared TMDB and Fanart.tv artwork, other add-on caches, settings, sign-in and saved search history are kept. Cached streams are checked again before use. Open Changelog from the root menu for release history. Restart Kodi after updates that change the playback service.

Vidcore keeps its settings and caches separate from Cosmos. It does not host content.
