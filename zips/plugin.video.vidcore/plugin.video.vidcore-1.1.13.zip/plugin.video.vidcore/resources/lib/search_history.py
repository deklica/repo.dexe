"""Persistent, bounded Vidcore searches in the active Kodi profile."""
import json
import os
import tempfile
import time


def _path():
    import xbmcvfs
    return xbmcvfs.translatePath('special://profile/addon_data/plugin.video.vidcore/search_history.json')


def load(path=None):
    try:
        with open(path or _path(), encoding='utf-8') as handle:
            rows = json.load(handle)
        if not isinstance(rows, list):
            return []
        return [row for row in rows if isinstance(row, dict)
                and row.get('kind') in ('movie', 'tv')
                and isinstance(row.get('query'), str) and row['query'].strip()][:50]
    except (OSError, ValueError):
        return []


def _save(rows, path=None):
    target = path or _path()
    folder = os.path.dirname(os.path.abspath(target))
    os.makedirs(folder, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8',
                                         dir=folder, prefix='search_history-',
                                         suffix='.tmp', delete=False) as handle:
            temporary = handle.name
            json.dump(rows, handle, ensure_ascii=False)
        for attempt in range(5):
            try:
                os.replace(temporary, target)
                break
            except PermissionError as exc:
                # Windows can briefly lock the destination during another save.
                if getattr(exc, 'winerror', None) not in (5, 32, 33) or attempt == 4:
                    raise
                time.sleep(.02 * (attempt + 1))
    finally:
        if temporary and os.path.exists(temporary):
            os.remove(temporary)


def remember(query, kind, path=None):
    query = query.strip()
    if not query or kind not in ('movie', 'tv'):
        return
    rows = [row for row in load(path)
            if (row['kind'], row['query'].casefold()) != (kind, query.casefold())]
    _save(([{'query': query, 'kind': kind}] + rows)[:50], path)


def clear(kind=None, path=None):
    _save([row for row in load(path) if row['kind'] != kind] if kind else [], path)
