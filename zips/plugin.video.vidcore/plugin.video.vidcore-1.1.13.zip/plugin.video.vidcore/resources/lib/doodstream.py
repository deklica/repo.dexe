"""Resolve SRStop DoodStream/Playmogo episode links to checked native media."""
import re
import secrets
import string
import time
from html import unescape
from http.cookiejar import CookieJar
from urllib.error import HTTPError
from urllib.parse import urlencode, urljoin, urlsplit, urlunsplit
from urllib.request import Request, build_opener, HTTPCookieProcessor

from . import srstop

UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
      '(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36')
HOST = re.compile(r'(?:d[a-z0-9]*ood[a-z]*|d0+d|ds2play|ds2video|playmogo)\.[a-z]{2,}', re.I)
PATH = re.compile(r'/(?:e|d|embed)/([A-Za-z0-9_-]+)(?:\.html)?(?:/[^?#]*)?', re.I)


def is_url(url):
    parts = urlsplit(str(url or ''))
    host = (parts.hostname or '').lower()
    host = host[4:] if host.startswith('www.') else host
    return bool(parts.scheme in ('https', 'http') and not parts.username and
                HOST.fullmatch(host) and PATH.fullmatch(parts.path))


def _embed_url(url):
    if not is_url(url):
        raise srstop.SourceError('This is not a supported DoodStream or Playmogo link.')
    parts = urlsplit(url)
    code = PATH.fullmatch(parts.path)[1]
    return urlunsplit((parts.scheme, parts.netloc, '/e/' + code, parts.query, ''))


def _candidate(body, embed, fetch):
    """Decode the player's pass_md5/makePlay flow without executing scripts."""
    body = unescape(body).replace('\\/', '/')
    endpoint = re.search(r'(/pass_md5/[A-Za-z0-9_/-]+)', body)
    if endpoint:
        prefix = fetch(urljoin(embed, endpoint[1]), embed).strip()
        if urlsplit(prefix).scheme not in ('https', 'http') or any(char.isspace() for char in prefix):
            raise srstop.SourceError('DoodStream returned an invalid media response.')
        token = re.search(r'[?&]token=([A-Za-z0-9_-]+)', body)
        token = token[1] if token else endpoint[1].rstrip('/').rsplit('/', 1)[-1]
        random = ''.join(secrets.choice(string.ascii_letters + string.digits) for _ in range(10))
        return prefix + random + '?' + urlencode({'token': token, 'expiry': int(time.time() * 1000)})
    media = re.search(r'''["']?(?:file|src)["']?\s*[:=]\s*["'](https?://[^"'<>]+\.(?:mp4|m3u8)(?:\?[^"'<>]*)?)["']''', body, re.I)
    return media[1] if media else ''


def _resolve_host_page(url, deadline=None):
    deadline = deadline or time.monotonic() + 45
    original = _embed_url(url)
    # SRStop retains legacy Dood domains; Playmogo is also accepted directly.
    pages = [original]
    if (urlsplit(original).hostname or '').lower() not in ('playmogo.com', 'www.playmogo.com'):
        parts = urlsplit(original)
        pages.append(urlunsplit(('https', 'playmogo.com', parts.path, parts.query, '')))
    jar = CookieJar()
    opener = build_opener(HTTPCookieProcessor(jar))
    blocked = False

    def fetch(target, referer):
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise srstop.SourceError('DoodStream resolution timed out. Try another source.')
        try:
            with opener.open(Request(target, headers={'User-Agent': UA, 'Referer': referer}),
                             timeout=min(12, remaining)) as response:
                raw = response.read(2 * 1024 * 1024 + 1)
                final = response.geturl()
        except HTTPError as exc:
            if exc.code == 403:
                raise srstop.SourceError('DoodStream / Playmogo requires a browser verification challenge. Try another source.') from None
            raise
        if len(raw) > 2 * 1024 * 1024:
            raise srstop.SourceError('DoodStream returned an oversized player response.')
        return raw.decode('utf-8', 'replace'), final

    for page in pages:
        if time.monotonic() >= deadline:
            break
        try:
            body, embed = fetch(page, srstop.BASE + '/')
            if not is_url(embed):
                continue
            stream = _candidate(body, embed, lambda target, ref: fetch(target, ref)[0])
            if not stream:
                continue
            headers = {'User-Agent': UA, 'Referer': embed}
            request = Request(stream)
            jar.add_cookie_header(request)
            if request.get_header('Cookie'):
                headers['Cookie'] = request.get_header('Cookie')
            kind = 'hls' if '.m3u8' in urlsplit(stream).path.lower() else 'mp4'
            result = {'url': stream, 'type': kind, 'headers': headers}
            if srstop.probe_stream(result, timeout=min(8, max(1, deadline - time.monotonic()))):
                return result
        except srstop.SourceError as exc:
            blocked = blocked or 'verification challenge' in str(exc)
        except Exception:
            continue
    if blocked:
        raise srstop.SourceError('DoodStream / Playmogo requires a browser verification challenge. Try another source.')
    return None


def resolve(tmdb_id, season, episode):
    try:
        from . import tmdb
        links = srstop.discover_doodstream(tmdb.get_metadata(tmdb_id, 'tv'), season, episode)
        deadline = time.monotonic() + 45
        blocked = False
        for link in links:
            if time.monotonic() >= deadline:
                break
            try:
                stream = _resolve_host_page(link['url'], deadline)
                if stream:
                    return stream
            except srstop.SourceError as exc:
                blocked = blocked or 'verification challenge' in str(exc)
        if blocked:
            return {'error': 'DoodStream / Playmogo requires a browser verification challenge. Try another source.'}
        return {'error': 'SRStop DoodStream links did not return a playable stream. Try another source.'}
    except srstop.SourceError as exc:
        return {'error': str(exc)}
    except Exception:
        return {'error': 'SRStop / DoodStream could not resolve this episode. Please try again.'}
