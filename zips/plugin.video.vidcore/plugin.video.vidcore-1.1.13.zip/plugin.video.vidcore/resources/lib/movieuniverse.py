"""MovieUniverse's TMDB routes and its native Videm movie/episode streams."""
import json
import re
import time
from html.parser import HTMLParser
from http.cookiejar import CookieJar
from urllib.parse import urlencode, urljoin, urlsplit
from urllib.request import HTTPCookieProcessor, Request, build_opener

BASE = 'https://movieuniverse.skin'
PLAYER_HOSTS = frozenset(('videm.buzz', 'videm.xyz'))
UA = 'Mozilla/5.0'
LIMIT = 2 * 1024 * 1024


def _diagnostic(detail):
    from . import debug_bundle
    debug_bundle.log('MovieUniverse', detail)


def watch_url(tmdb_id, kind='movie', season=0, episode=0):
    identifier = str(tmdb_id)
    if not identifier.isdigit() or int(identifier) < 1:
        return ''
    if kind == 'movie':
        return BASE + '/watch-movieuniverse-' + identifier
    if kind == 'tv':
        try:
            season, episode = int(season), int(episode)
        except (ValueError, TypeError):
            return ''
        if season >= 0 and episode > 0:
            # These separators belong to the site's path, not its query.
            return BASE + '/watch-tv-%s&season=%s&episode=%s' % (identifier, season, episode)
    return ''


class _Servers(HTMLParser):
    def __init__(self):
        super().__init__()
        self.urls = []

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == 'a' and 'server-item' in attrs.get('class', '').split():
            match = re.match(r"\s*go\(\s*(['\"])(https://[^'\"]+)\1\s*,", attrs.get('onclick', ''))
            if match:
                self.urls.append(match[2])
        elif tag == 'iframe' and attrs.get('id') == 'iframesrc':
            self.urls.append(attrs.get('data-src') or attrs.get('src') or '')


def player_url(body, tmdb_id, kind, season=0, episode=0):
    """Only follow a server actually listed for the requested title/episode."""
    parser = _Servers()
    parser.feed(body)
    for url in parser.urls:
        parts = urlsplit(url)
        if parts.scheme != 'https' or parts.hostname not in PLAYER_HOSTS or parts.port not in (None, 443):
            continue
        if parts.username or parts.password:
            continue
        match = re.fullmatch(r'/embed/(movie|tv)/(tt\d+|\d+)(?:/(\d+)/(\d+))?/?', parts.path)
        if not match or match[1] != kind:
            continue
        identifier = match[2]
        if identifier.isdigit() and int(identifier) != int(tmdb_id):
            continue
        if kind == 'tv':
            # The site supplies TMDB IDs for TV. Never use its movie route
            # or an IMDb-only wrapper which loses the season and episode.
            if not identifier.isdigit() or (int(match[3] or -1), int(match[4] or -1)) != (int(season), int(episode)):
                continue
        elif match[3] is not None:
            continue
        return url
    return ''


def player_config(body, url, kind, season=0, episode=0):
    match = re.search(r'\bvar\s+Q\s*=\s*', body)
    if not match:
        return None
    config = json.JSONDecoder().raw_decode(body[match.end():])[0]
    if not isinstance(config, dict) or config.get('type') != kind:
        return None
    identifier = urlsplit(url).path.split('/')[3]
    config_id = str(config.get('id', ''))
    if not re.fullmatch(r'(?:tt)?\d+', config_id):
        return None
    if (identifier.startswith('tt') or config_id.isdigit()) and config_id != identifier:
        return None
    if kind == 'tv' and (int(config.get('s', -1)), int(config.get('e', -1))) != (int(season), int(episode)):
        return None
    return config


class _Session:
    def __init__(self):
        self.opener = build_opener(HTTPCookieProcessor(CookieJar()))
        self.deadline = time.monotonic() + 45

    def read(self, url, referer):
        remaining = self.deadline - time.monotonic()
        if remaining <= 0:
            raise TimeoutError('MovieUniverse discovery timed out')
        headers = {'User-Agent': UA, 'Referer': referer, 'Accept-Encoding': 'identity'}
        with self.opener.open(Request(url, headers=headers), timeout=min(8, remaining)) as response:
            data, final = response.read(LIMIT + 1), response.geturl()
        if len(data) > LIMIT:
            raise ValueError('Oversized MovieUniverse response')
        return data.decode('utf-8-sig'), final


def discover(tmdb_id, kind='movie', season=0, episode=0):
    """Yield fresh native candidates; the common checker validates media bytes."""
    page = watch_url(tmdb_id, kind, season, episode)
    if not page:
        return
    session = _Session()
    stage = 'watch page'
    try:
        body, final = session.read(page, BASE + '/home')
        if final.rstrip('/') != page:
            _diagnostic('watch page redirected away from requested title')
            return
        player = player_url(body, tmdb_id, kind, season, episode)
        if not player:
            _diagnostic('watch page has no matching Videm player')
            return
        player_origin = 'https://' + urlsplit(player).hostname
        stage = 'player page'
        body, final = session.read(player, page)
        # Relative API calls in Videm use its <base href="/">.
        if (urlsplit(final).scheme != 'https'
                or urlsplit(final).hostname != urlsplit(player).hostname
                or urlsplit(final).port not in (None, 443)
                or urlsplit(final).username or urlsplit(final).password
                or urlsplit(final).path != urlsplit(player).path):
            _diagnostic('player redirected away from requested title')
            return
        stage = 'player configuration'
        config = player_config(body, player, kind, season, episode)
        if not config or not isinstance(config.get('t'), str):
            _diagnostic('player configuration missing or does not match title')
            return
        ssr = config.get('ssr')
        servers = ssr.get('servers') if isinstance(ssr, dict) else None
        if not isinstance(servers, list):
            _diagnostic('player configuration has no server list')
            return
        _diagnostic('player returned %d servers' % len(servers))
        seen = set()
        for server in servers[:8]:
            if not isinstance(server, dict) or not isinstance(server.get('ref'), str):
                continue
            ref = server['ref']
            if not ref or ref in seen:
                continue
            seen.add(ref)
            try:
                endpoint = player_origin + '/api.php?' + urlencode({'a': 'play', 'ref': ref, 't': config['t']})
                body, _ = session.read(endpoint, player)
                data = json.loads(body)
                if not isinstance(data, dict) or not isinstance(data.get('url'), str):
                    _diagnostic('server API returned no media URL')
                    continue
                media = urljoin(player_origin, data['url'])
                parts = urlsplit(media)
                if (parts.scheme != 'https' or parts.hostname != urlsplit(player).hostname
                        or parts.path != '/_stream' or parts.username or parts.password
                        or parts.port not in (None, 443)):
                    _diagnostic('server API returned an unsupported media route')
                    continue
                label = re.sub(r'[^A-Za-z0-9 ._-]', '', str(server.get('name') or 'VSrcH'))[:50]
                _diagnostic('checking media candidate: ' + label)
                yield {'url': media, 'type': 'hls', 'label': label,
                       'headers': {'User-Agent': UA, 'Referer': player, 'Origin': player_origin},
                       'opener': session.opener, 'minimum_duration': 600 if kind == 'movie' else 120}
            except Exception as exc:
                # A failed server must not hide the remaining servers.
                _diagnostic('server request failed: %s: %s' % (type(exc).__name__, exc))
                continue
    except Exception as exc:
        _diagnostic('%s failed: %s: %s' % (stage, type(exc).__name__, exc))
        try:
            import xbmc
            xbmc.log('VIDCORE MovieUniverse discovery failed: ' + type(exc).__name__, xbmc.LOGWARNING)
        except ImportError:
            pass
