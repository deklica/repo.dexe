"""Vidcore settings with native-addon storage and a branded dialog."""
import os
import xml.etree.ElementTree as ET
from urllib.parse import urlencode
import xbmc
import xbmcaddon
import xbmcgui

FIELDS = ('native_dialogs', 'diagnostic_logging', 'metadata_cache_enabled', 'tmdb_watch_region',
          'tmdb_api_key', 'fanarttv_api_key', 'simkl_scrobble')


class SettingsDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.addon = kwargs.pop('addon')
        self.draft = kwargs.pop('draft')
        self.defaults = kwargs.pop('defaults')
        self.section = kwargs.pop('section', 0)
        self.positions = {0: 0, 1: 0}
        self.rows = []
        self.result = None
        super().__init__(*args, **kwargs)

    def onInit(self):
        self.setProperty('vc_settings_version', 'v' + self.addon.getAddonInfo('version'))
        listing = self.getControl(6000)
        listing.reset()
        for name in ('General', 'Simkl'):
            listing.addItem(xbmcgui.ListItem(label=name))
        listing.selectItem(self.section)
        self.populate()
        self.setFocusId(6000)

    def populate(self, position=None):
        if position is None:
            position = self.positions[self.section]
        self.positions[self.section] = position
        if self.section == 0:
            self.rows = [
                ('Use native Kodi dialogs', 'native_dialogs', 'bool', 'Optional alternative to Vidcore\'s custom dialogs. Leave OFF for Vidcore source pickers, settings and Simkl authorization.'),
                ('Detailed Vidcore logging', 'diagnostic_logging', 'bool', 'Record source checks and errors in kodi.log. Enable while reproducing a bug, then turn it off.'),
                ('Cache TMDB metadata', 'metadata_cache_enabled', 'bool', 'Reuse metadata between visits. Clear saved metadata and artwork from Tools > Clear Cache.'),
                ('Provider country fallback', 'tmdb_watch_region', 'country', 'Choose the fallback country for streaming-service catalogues. Automatic country detection stays enabled.'),
                ('TMDB API key', 'tmdb_api_key', 'text', 'Use the included key or enter your own TMDB API key.'),
                ('Fanart.tv API key', 'fanarttv_api_key', 'text', 'Artwork fallback when TMDB artwork is missing or unavailable.')]
        else:
            connected = bool(self.addon.getSetting('simkl_access_token'))
            self.rows = [
                ('Simkl account', '', 'info', 'Connect Simkl to use watching lists, next episodes and playback tracking.'),
                ('Scrobble playback to Simkl', 'simkl_scrobble', 'bool', 'Send playback start, pause and stop events to your connected Simkl account.'),
                ('Disconnect Simkl' if connected else 'Connect Simkl', '', 'disconnect' if connected else 'connect', 'Account connection changes take effect immediately. Other preferences are saved with Save.')]
        self.setProperty('vc_settings_section', 'GENERAL' if self.section == 0 else 'SIMKL')
        self.setProperty('vc_settings_count', str(len(self.rows)))
        media = os.path.join(self.addon.getAddonInfo('path'), 'resources', 'media', 'menu')
        self.setProperty('vc_settings_sidebar_icon', os.path.join(
            media, 'settings.png' if self.section == 0 else 'simkl.png'))
        self.setProperty('vc_settings_sidebar_title',
                         'Make it yours' if self.section == 0 else 'Your watchlist, connected')
        self.setProperty('vc_settings_sidebar_text',
                         'Fine-tune your menus, metadata and regional catalogues.'
                         if self.section == 0 else
                         'Keep your watching lists and playback history in sync.')
        self.setProperty('vc_settings_sidebar_status',
                         'Save to apply preferences' if self.section == 0 else
                         'Simkl connected' if connected else 'Simkl not connected')
        listing = self.getControl(6001)
        listing.reset()
        for label, key, kind, help_text in self.rows:
            value = self.draft.get(key, '')
            if kind == 'bool':
                value = 'ON' if value == 'true' else 'OFF'
            elif kind == 'text':
                value = ('Included key' if not value or value == self.defaults.get(key)
                         else 'Personal key')
            elif kind == 'info':
                value = 'Connected' if self.addon.getSetting('simkl_access_token') else 'Not connected'
            elif kind in ('connect', 'disconnect'):
                value = 'Open'
            item = xbmcgui.ListItem(label=label, label2=value)
            listing.addItem(item)
        listing.selectItem(min(position, len(self.rows) - 1))
        self.update_help()

    def update_help(self):
        position = self.getControl(6001).getSelectedPosition()
        if 0 <= position < len(self.rows):
            text = self.rows[position][3]
            if self.getProperty('vc_settings_help') != text:
                self.setProperty('vc_settings_help', text)

    def onFocus(self, control_id):
        self.sync_section()
        self.update_help()

    def sync_section(self):
        position = self.getControl(6001).getSelectedPosition()
        if position >= 0:
            self.positions[self.section] = position
        section = self.getControl(6000).getSelectedPosition()
        if section in (0, 1) and section != self.section:
            self.section = section
            self.populate()

    def onAction(self, action):
        if action.getId() in (9, 10, 92):
            if self.getFocusId() != 6000:
                self.setFocusId(6000)
                return
            self.close()
            return
        if action.getId() == 216:
            self.close()
            return
        self.sync_section()
        self.update_help()

    def onClick(self, control_id):
        if control_id == 6000:
            self.sync_section()
            self.setFocusId(6001)
        elif control_id == 6002:
            self.result = 'save'
            self.close()
        elif control_id == 6003:
            self.close()
        elif control_id == 6004:
            self.result = 'defaults'
            self.close()
        elif control_id == 6001:
            position = self.getControl(6001).getSelectedPosition()
            if not 0 <= position < len(self.rows):
                return
            label, key, kind, _help = self.rows[position]
            if kind == 'bool':
                self.draft[key] = 'false' if self.draft[key] == 'true' else 'true'
            elif kind == 'text':
                keyboard = xbmc.Keyboard(self.draft[key], label)
                keyboard.doModal()
                if keyboard.isConfirmed():
                    self.draft[key] = keyboard.getText().strip()
            elif kind == 'country':
                from . import country_picker, tmdb
                data = tmdb._fetch('https://api.themoviedb.org/3/watch/providers/regions?' + urlencode(
                    {'api_key': tmdb._api_key(), 'language': 'en-US'}), timeout=5)
                countries = country_picker.countries(data, self.draft[key])
                selected = next((i for i, row in enumerate(countries) if row[0] == self.draft[key]), -1)
                index = xbmcgui.Dialog().select('Provider country fallback',
                    ['%s (%s)' % (name, code) for code, name in countries], preselect=selected)
                if 0 <= index < len(countries):
                    self.draft[key] = countries[index][0]
            elif kind in ('connect', 'disconnect'):
                self.result = kind
                self.close()
                return
            self.populate(position)


def show():
    from .skin_support import use_native_dialogs
    if use_native_dialogs():
        xbmcaddon.Addon('plugin.video.vidcore').openSettings()
        return
    addon = xbmcaddon.Addon('plugin.video.vidcore')
    path = addon.getAddonInfo('path')
    schema = ET.parse(os.path.join(path, 'resources', 'settings.xml'))
    defaults = {row.get('id'): row.get('default', '') for row in schema.iter('setting')
                if row.get('id') in FIELDS}
    initial = {key: addon.getSetting(key) or defaults[key] for key in FIELDS}
    draft = dict(initial)
    section = 0
    while True:
        dialog = SettingsDialog('VidCoreSettings.xml', path, 'Default', '720p',
                                addon=addon, draft=draft, defaults=defaults, section=section)
        dialog.doModal()
        result = dialog.result
        section = dialog.section
        del dialog
        if result == 'defaults':
            for key in FIELDS:
                addon.setSetting(key, defaults[key])
            initial.update(defaults)
            draft.update(defaults)
            xbmcgui.Window(10000).clearProperty('Vidcore.WatchRegion')
            xbmcgui.Dialog().notification('Vidcore', 'Default preferences restored')
            continue
        if result == 'save':
            for key, value in draft.items():
                if value != initial[key]:
                    addon.setSetting(key, value)
            if draft['tmdb_watch_region'] != initial['tmdb_watch_region']:
                xbmcgui.Window(10000).clearProperty('Vidcore.WatchRegion')
            return
        if result not in ('connect', 'disconnect'):
            return
        from . import simkl
        if result == 'connect':
            simkl.authorize()
        else:
            simkl.revoke()
