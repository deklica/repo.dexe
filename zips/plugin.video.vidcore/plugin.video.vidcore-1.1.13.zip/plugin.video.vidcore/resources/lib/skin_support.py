"""Use Vidcore's bundled dialogs unless native dialogs are explicitly chosen."""
import xbmcaddon


def use_native_dialogs():
    return xbmcaddon.Addon('plugin.video.vidcore').getSetting('native_dialogs') == 'true'
