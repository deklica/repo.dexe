"""Bounded checks of clear DASH initialization and first media segments."""
import re
import xml.etree.ElementTree as ET
from urllib.parse import urljoin


def check(data, base, read, minimum=0):
    root = ET.fromstring(data)
    # Strip namespaces so inherited addressing works with either MPD form.
    for element in root.iter():
        element.tag = element.tag.rsplit('}', 1)[-1]
    if root.tag != 'MPD' or root.find('.//ContentProtection') is not None:
        return False
    if minimum:
        match = re.fullmatch(r'PT(?:(\d+(?:\.\d+)?)H)?(?:(\d+(?:\.\d+)?)M)?(?:(\d+(?:\.\d+)?)S)?',
                             root.get('mediaPresentationDuration', ''))
        if not match or sum(float(v or 0) * unit for v, unit in zip(match.groups(), (3600, 60, 1))) < minimum:
            return False

    def probe(chain):
        address = base
        template, segment_list, segment_base = {}, None, None
        timeline = None
        for element in chain:
            child_base = element.findtext('BaseURL')
            if child_base:
                address = urljoin(address, child_base.strip())
            child = element.find('SegmentTemplate')
            if child is not None:
                template.update(child.attrib)
                if child.find('SegmentTimeline') is not None:
                    timeline = child.find('SegmentTimeline')
            if element.find('SegmentList') is not None:
                segment_list = element.find('SegmentList')
            if element.find('SegmentBase') is not None:
                segment_base = element.find('SegmentBase')
        representation = chain[-1]

        def expand(value):
            first = timeline.find('S') if timeline is not None else None
            values = {'RepresentationID': representation.get('id', ''),
                      'Bandwidth': representation.get('bandwidth', ''),
                      'Number': template.get('startNumber', '1'),
                      'Time': first.get('t', '0') if first is not None else '0'}
            def replace(match):
                value = values[match[1]]
                width = int(match[2]) if match[2] else 0
                if width > 20:
                    raise ValueError('Invalid DASH number width')
                return str(value).zfill(width)
            value = value.replace('$$', '\x00')
            value = re.sub(r'\$(RepresentationID|Bandwidth|Number|Time)(?:%0(\d+)d)?\$', replace, value)
            if '$' in value:
                raise ValueError('Unsupported DASH template')
            return urljoin(address, value.replace('\x00', '$'))

        urls = []
        if template.get('media'):
            if template.get('initialization'):
                urls.append((expand(template['initialization']), None))
            urls.append((expand(template['media']), None))
        elif segment_list is not None:
            initialization = segment_list.find('Initialization')
            if initialization is not None:
                urls.append((urljoin(address, initialization.get('sourceURL', '')),
                             initialization.get('range')))
            segment = segment_list.find('SegmentURL')
            if segment is None:
                return False
            urls.append((urljoin(address, segment.get('media', '')), segment.get('mediaRange')))
        elif address != base:
            # A single MP4 or SegmentBase can be sampled with a byte range.
            if segment_base is not None:
                initialization = segment_base.find('Initialization')
                if initialization is not None and initialization.get('sourceURL'):
                    urls.append((urljoin(address, initialization.get('sourceURL')), initialization.get('range')))
            urls.append((address, None))
        else:
            return False
        for url, byte_range in dict.fromkeys(urls):
            if byte_range and not re.fullmatch(r'\d+-\d+', byte_range):
                return False
            sample, _ = read(url, media=True, byte_range=byte_range)
            if len(sample) < 8 or sample[4:8] not in (
                    b'ftyp', b'styp', b'moof', b'sidx', b'mdat', b'emsg', b'moov'):
                return False
        return True

    period = root.find('Period')
    if period is None:
        return False
    groups = {}
    for adaptation in period.findall('AdaptationSet')[:8]:
        kind = adaptation.get('contentType', '') or adaptation.get('mimeType', '').split('/')[0]
        representations = adaptation.findall('Representation')
        if not kind and representations:
            kind = representations[0].get('mimeType', '').split('/')[0]
        if kind in ('text', 'image') or adaptation.get('mimeType') == 'application/ttml+xml':
            continue
        groups.setdefault(kind or 'media', []).append(adaptation)
    budget = 12
    for adaptations in groups.values():
        valid = False
        for adaptation in adaptations:
            for representation in adaptation.findall('Representation')[:4]:
                if budget <= 0:
                    break
                budget -= 1
                try:
                    if probe((root, period, adaptation, representation)):
                        valid = True
                        break
                except (OSError, ValueError, KeyError):
                    continue
            if valid:
                break
        if not valid:
            return False
    return bool(groups)
