"""Named country selection for the automatic provider-country fallback."""
import re
from urllib.parse import urlencode

# Offline choices when TMDB cannot provide its supported regions.
_FALLBACK = {
    'AR': 'Argentina', 'AU': 'Australia', 'AT': 'Austria', 'BE': 'Belgium',
    'BR': 'Brazil', 'BG': 'Bulgaria', 'CA': 'Canada', 'CL': 'Chile',
    'CO': 'Colombia', 'HR': 'Croatia', 'CZ': 'Czechia', 'DK': 'Denmark',
    'EG': 'Egypt', 'FI': 'Finland', 'FR': 'France', 'DE': 'Germany',
    'GR': 'Greece', 'HK': 'Hong Kong', 'HU': 'Hungary', 'IN': 'India',
    'ID': 'Indonesia', 'IE': 'Ireland', 'IL': 'Israel', 'IT': 'Italy',
    'JP': 'Japan', 'MY': 'Malaysia', 'MX': 'Mexico', 'NL': 'Netherlands',
    'NZ': 'New Zealand', 'NG': 'Nigeria', 'NO': 'Norway', 'PK': 'Pakistan',
    'PE': 'Peru', 'PH': 'Philippines', 'PL': 'Poland', 'PT': 'Portugal',
    'RO': 'Romania', 'SA': 'Saudi Arabia', 'SG': 'Singapore', 'ZA': 'South Africa',
    'KR': 'South Korea', 'ES': 'Spain', 'SE': 'Sweden', 'CH': 'Switzerland',
    'TW': 'Taiwan', 'TH': 'Thailand', 'TR': 'Turkey', 'UA': 'Ukraine',
    'AE': 'United Arab Emirates', 'GB': 'United Kingdom', 'US': 'United States',
    'VE': 'Venezuela', 'VN': 'Vietnam',
}


def countries(data, current='GB'):
    choices = {}
    rows = data.get('results') if isinstance(data, dict) else None
    for row in rows if isinstance(rows, list) else []:
        if not isinstance(row, dict):
            continue
        code = str(row.get('iso_3166_1') or '').upper()
        name = str(row.get('english_name') or row.get('native_name') or '').strip()
        if re.fullmatch('[A-Z]{2}', code) and name:
            choices[code] = name
    if not choices:
        choices.update(_FALLBACK)
    if re.fullmatch('[A-Z]{2}', current):
        choices.setdefault(current, _FALLBACK.get(current, current))
    return sorted(choices.items(), key=lambda row: row[1].casefold())


def show():
    import xbmcaddon
    import xbmcgui
    from . import tmdb
    addon = xbmcaddon.Addon('plugin.video.vidcore')
    current = (addon.getSetting('tmdb_watch_region') or 'GB').strip().upper()
    if not re.fullmatch('[A-Z]{2}', current):
        current = 'GB'
    url = 'https://api.themoviedb.org/3/watch/providers/regions?' + urlencode(
        {'api_key': tmdb._api_key(), 'language': 'en-US'})
    rows = countries(tmdb._fetch(url, timeout=5), current)
    labels = ['%s (%s)' % (name, code) for code, name in rows]
    selected = next((i for i, row in enumerate(rows) if row[0] == current), -1)
    index = xbmcgui.Dialog().select('Provider country fallback / ' + current,
                                    labels, preselect=selected)
    if 0 <= index < len(rows):
        code, name = rows[index]
        addon.setSetting('tmdb_watch_region', code)
        xbmcgui.Window(10000).clearProperty('Vidcore.WatchRegion')
        xbmcgui.Dialog().notification('Vidcore', 'Fallback: %s (%s)' % (name, code))
    from . import settings_dialog
    settings_dialog.show()
