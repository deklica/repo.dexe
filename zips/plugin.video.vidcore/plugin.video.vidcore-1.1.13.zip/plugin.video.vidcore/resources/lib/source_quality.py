"""Read resolution metadata from already-fetched stream bytes."""
import re


def standard_height(width, height):
    """Label cropped widescreen video by its standard quality class."""
    nominal = max(height, width * 9 / 16)
    return min((240, 360, 480, 576, 720, 1080, 1440, 2160, 4320),
               key=lambda value: abs(value - nominal))


def hls_heights(text):
    heights = set()
    for line in text.splitlines():
        if line.startswith('#EXT-X-STREAM-INF:'):
            match = re.search(r'(?:[:,])\s*RESOLUTION=(\d+)x(\d+)(?:,|$)', line)
            if match and 0 < int(match[1]) <= 16384 and 0 < int(match[2]) <= 16384:
                heights.add(standard_height(int(match[1]), int(match[2])))
    return sorted(heights, reverse=True)


def mp4_height(data):
    # tkhd stores display width/height as the final two 16.16 fixed values.
    start = 0
    heights = []
    while True:
        pos = data.find(b'tkhd', start)
        if pos < 0:
            return max(heights, default=0)
        start = pos + 4
        if pos < 4 or pos + 5 > len(data):
            continue
        size = int.from_bytes(data[pos - 4:pos], 'big')
        version = data[pos + 4]
        expected = 92 if version == 0 else 104 if version == 1 else 0
        if not expected or size != expected or pos - 4 + size > len(data):
            continue
        end = pos - 4 + size
        width = int.from_bytes(data[end - 8:end - 4], 'big') >> 16
        height = int.from_bytes(data[end - 4:end], 'big') >> 16
        if 0 < width <= 16384 and 0 < height <= 16384:
            heights.append(standard_height(width, height))


def advertised_heights(text):
    """Read explicit resolution labels, never bare numbers or file sizes."""
    heights = {int(value) for value in re.findall(
        r'(?i)(?<!\w)(240|360|480|576|720|1080|1440|2160|4320)p\b', text)}
    if re.search(r'(?i)(?<!\w)4k\b', text):
        heights.add(2160)
    if re.search(r'(?i)(?<!\w)8k\b', text):
        heights.add(4320)
    return sorted(heights, reverse=True)


def describe(streams):
    heights = sorted({int(h) for stream in streams for h in (
        stream.get('quality_heights') or stream.get('advertised_heights', []))}, reverse=True)
    if not heights:
        return '', ''
    badge = '%dp' % heights[0]
    advertised = any(stream.get('quality_origin') == 'manifest' or
                     (not stream.get('quality_heights') and stream.get('advertised_heights'))
                     for stream in streams)
    detail = ('Advertised qualities: ' if advertised else 'Resolution: ') + ', '.join('%dp' % h for h in heights)
    return badge, detail


def source_summary(name, stream, checked, groups, host_picker=False):
    """Combine verified child qualities for a provider or describe one link."""
    if not host_picker and name in groups:
        keys = [key for key, _label in groups[name]]
    elif name == 'SRStop' and not host_picker:
        keys = [key for key in checked if isinstance(key, tuple) and key[0] == 'SRStop']
    else:
        keys = [('SRStop', name) if host_picker else stream if isinstance(stream, tuple) else name]
    return describe([checked[key] for key in keys if key in checked])
