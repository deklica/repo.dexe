"""Map navigation entries to local Vidcore artwork."""
import os
import re


def icon_name(label, values):
    label = re.sub(r'\[/?(?:COLOR[^\]]*|B|I)\]', '', label, flags=re.I).strip().lower()
    if label.startswith('next page'):
        return 'next'
    if label.startswith('previous page'):
        return 'previous'
    if values.get('tmdb_id'):
        return None
    # Media groups have the same action as their parent status menu.
    if label == 'movies':
        return 'movies'
    if label in ('shows', 'tv shows'):
        return 'tv'
    action = values.get('action', '')
    fixed = {
        'vidcore_search_menu': 'search', 'vidcore_people': 'people',
        'vidcore_tracking': 'tracking', 'vidcore_tools': 'tools',
        'changelog': 'changelog', 'settings': 'settings',
        'vidcore_settings': 'settings', 'vidcore_install_adaptive': 'install',
        'vidcore_report_bug': 'tools',
        'vidcore_adaptive_settings': 'adaptive', 'vidcore_cache_clear': 'clear',
        'vidcore_history_clear': 'clear_history',
        'vidcore_watch_providers': 'providers', 'simkl_root': 'simkl',
        'simkl_auth': 'connect', 'simkl_revoke': 'disconnect',
        'simkl_sync': 'sync', 'simkl_next_episodes': 'next_episodes',
        'simkl_history': 'history', 'simkl_custom_lists': 'lists',
        'simkl_custom_items': 'lists',
    }
    if action in fixed:
        return fixed[action]
    if action == 'vidcore_history':
        return 'tv_history' if values.get('history_kind') == 'tv' else 'movie_history'
    if action == 'vidcore_menu':
        return 'tv' if values.get('kind') == 'tv' else 'movies'
    if action == 'vidcore_search':
        return 'search_tv' if values.get('kind') == 'tv' else 'search_movies'
    if action == 'vidcore_list' and not values.get('provider_id'):
        category = values.get('category')
        if category in ('popular', 'top_rated', 'now_playing', 'upcoming', 'airing_today', 'on_the_air'):
            return category
    if action == 'simkl_list':
        return {'watching': 'watching', 'plantowatch': 'plan',
                'completed': 'completed', 'hold': 'hold', 'dropped': 'dropped'}.get(values.get('status'))
    return None


def artwork(addon_path, label, values):
    name = icon_name(label, values)
    return os.path.join(addon_path, 'resources', 'media', 'menu', name + '.png') if name else ''
