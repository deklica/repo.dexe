"""Resolve the VidBolt player embedded by 7reels for movies and TV.

The endpoint paths and public player keys match VidBolt's Gaiaflix module.
No user account key or browser execution is required.
"""
import json
import re
from http.cookiejar import CookieJar
from urllib.parse import urlencode, urljoin, urlsplit, parse_qs
from urllib.request import Request, build_opener, HTTPCookieProcessor

BASE = 'https://vidbolt.xyz'
MOVIE_API = 'https://api.movy.lol'
TV_API = 'https://img.animecurx.tech'
SCRAPER_API = 'https://scraper.vidbolt.xyz'
MOVIE_KEY = '0f461eaa465bb2a7acd037425217f2f209ef540a3171e1ac'
TV_KEY = 'streamrip_secret_2026'
HEADERS = {'User-Agent': 'Mozilla/5.0', 'Referer': BASE + '/', 'Origin': BASE}


def _log(message):
    try:
        import xbmc
        xbmc.log('VIDCORE VidBolt: ' + message, xbmc.LOGINFO)
    except ImportError:
        pass


def embed_url(tmdb_id, kind='movie', season=0, episode=0):
    identifier = str(tmdb_id or '').strip()
    if not identifier.isdigit() or int(identifier) < 1:
        return ''
    if kind == 'movie':
        return BASE + '/embed/movie/' + identifier
    if kind != 'tv':
        return ''
    try:
        season, episode = int(season), int(episode)
    except (TypeError, ValueError):
        return ''
    if season < 0 or episode < 1:
        return ''
    return BASE + '/embed/tv/%s/%d/%d' % (identifier, season, episode)


def _candidates(data, base):
    if not isinstance(data, dict):
        return []
    rows = data.get('sources')
    rows = rows if isinstance(rows, list) else []
    if not rows and data.get('m3u8_path'):
        rows = [{'url': data['m3u8_path'], 'type': 'm3u8'}]
    streams, seen = [], set()
    for row in rows:
        if not isinstance(row, dict) or not isinstance(row.get('url'), str):
            continue
        if re.search(r'\borion\b', str(row.get('name') or ''), re.I):
            continue
        raw = row['url'].strip()
        if not raw:
            continue
        parsed = urlsplit(raw)
        if parsed.scheme and parsed.scheme not in ('http', 'https'):
            continue
        # Match the player's handling of API-relative download paths.
        url = raw if parsed.scheme else urljoin(base + '/', re.sub(r'^downloads/', '', raw.lstrip('/')))
        parsed = urlsplit(url)
        if parsed.scheme not in ('http', 'https') or not parsed.netloc or url in seen:
            continue
        seen.add(url)
        source_type = str(row.get('type') or '').lower()
        kind = 'hls' if source_type in ('m3u8', 'hls') or 'mpegurl' in source_type or '.m3u8' in parsed.path else 'mp4'
        headers = dict(HEADERS)
        supplied = row.get('headers')
        if isinstance(supplied, dict):
            for name, value in supplied.items():
                if str(name).lower() in ('user-agent', 'referer', 'origin', 'accept') and isinstance(value, str):
                    if '\r' not in value and '\n' not in value:
                        headers[name] = value
        streams.append({'url': url, 'type': kind, 'headers': headers})
    return streams


def _api_streams(endpoint, base, opener, backend):
    try:
        request = Request(endpoint, headers=dict(HEADERS, Accept='application/json'))
        with opener.open(request, timeout=12) as response:
            body = response.read(2 * 1024 * 1024 + 1)
        if len(body) > 2 * 1024 * 1024:
            return None
        data = json.loads(body.decode('utf-8'))
        if backend == 'site':
            # Current public player returns {stream: {server, sources, ...}}.
            data = data.get('stream') if isinstance(data, dict) else None
        # These are VOD backends. Reject short music videos, trailers and
        # placeholder playlists even when their bytes are valid media.
        query = parse_qs(urlsplit(endpoint).query)
        target = query.get('path', [urlsplit(endpoint).path])[0]
        minimum = 120 if '/tv/' in target or query.get('type') == ['tv'] else 600
        from .vidcore_availability import check_stream
        for stream in _candidates(data, base)[:8]:
            stream['opener'] = opener
            stream['vidbolt_backend'] = backend
            stream['minimum_duration'] = minimum
            checked = check_stream(stream)
            if checked:
                _log('resolved playable %s stream with duration check via %s' % (checked['type'], backend))
                return checked
    except Exception as exc:
        _log('%s backend unavailable (%s)' % (backend, type(exc).__name__))
    return None


def resolve(url, backend=''):
    """Fetch current streams and accept the first with valid media and keys."""
    parsed = urlsplit(url)
    match = re.fullmatch(r'/embed/(movie)/(\d+)|/embed/(tv)/(\d+)/(\d+)/(\d+)', parsed.path)
    if parsed.scheme != 'https' or parsed.hostname != 'vidbolt.xyz' or not match:
        return None
    if match[1]:
        base, key = MOVIE_API, MOVIE_KEY
        path = '/api/source/' + match[2]
        kind, identifier = 'movie', match[2]
        params = {'tmdbId': identifier}
    else:
        base, key = TV_API, TV_KEY
        path = '/api/tv/%s/%s/%s' % (match[4], match[5], match[6])
        kind, identifier = 'tv', match[4]
        params = {'tmdbId': identifier, 'season': match[5], 'episode': match[6]}
    opener = build_opener(HTTPCookieProcessor(CookieJar()))
    if backend in ('', 'site'):
        site_params = {'type': kind, 'id': identifier}
        if kind == 'tv':
            site_params.update(season=match[5], episode=match[6])
        stream = _api_streams(BASE + '/api/resolve?' + urlencode(site_params), BASE, opener, 'site')
        if stream:
            return stream
    if backend in ('', 'gaiaflix'):
        endpoint = base + path + '?' + urlencode({'api_key': key, 'apikey': key})
        stream = _api_streams(endpoint, base, opener, 'gaiaflix')
        if stream:
            return stream
    if backend in ('', 'quasar'):
        endpoint = SCRAPER_API + '/scrape/Quasar/%s/tmdb%s?%s' % (kind, identifier, urlencode(params))
        stream = _api_streams(endpoint, SCRAPER_API, opener, 'quasar')
        if stream:
            return stream
    if backend in ('', 'vidrock'):
        # Match VidBolt's public local proxy module. The default backend
        # does not cover every title; this scraper resolves by TMDB ID.
        scrape_path = '/scrape/VidRock/%s/tmdb%s?%s' % (kind, identifier, urlencode(params))
        endpoint = BASE + '/api/proxy?' + urlencode({'path': scrape_path})
        stream = _api_streams(endpoint, BASE, opener, 'vidrock')
        if stream:
            return stream
    _log('no backend returned playable media')
    return None
