"""Resolve SRStop Byse links using Cosmos's native AES-GCM player resolver."""
from urllib.parse import parse_qsl, urlsplit

from . import provider_resolvers, srstop, tmdb


def resolve(tmdb_id, season, episode):
    try:
        links = srstop.discover_byse(tmdb.get_metadata(tmdb_id, 'tv'), season, episode)
        for link in links:
            try:
                media = provider_resolvers.resolve_bysesukior(link['url'])
                if not media:
                    continue
                url, _, encoded_headers = media.partition('|')
                if urlsplit(url).scheme not in ('http', 'https'):
                    continue
                stream = {'url': url,
                          'type': 'hls' if '.m3u8' in urlsplit(url).path.lower() else 'mp4',
                          'headers': dict(parse_qsl(encoded_headers))}
                if srstop.probe_stream(stream):
                    return stream
            except Exception:
                continue
        return {'error': 'No Byse source passed the playback check. Choose another host.'}
    except srstop.SourceError as exc:
        return {'error': str(exc)}
    except Exception:
        return {'error': 'SRStop / Byse could not resolve this episode. Please try again.'}
