"""HydraHD's movie/episode server menu and official domain failover."""
import json
import re
import threading
import time
from html.parser import HTMLParser
from urllib.parse import parse_qsl, urlencode, urljoin, urlsplit
from urllib.request import Request, urlopen
from . import shared_requests

STATUS_URL = 'https://hydrahd.info/'
FALLBACK_DOMAINS = ('hydrahd.ws', 'hydrahd.com', 'hydrahd.io', 'hydrahd.cc',
                    'hydrahd.me', 'hydrahd.ac')
UA = 'Mozilla/5.0'
_domains = ()
_checked_at = 0
_lock = threading.Lock()


def _read(url, referer, timeout=8):
    return shared_requests.fetch(('hydrahd', url, referer),
                                 lambda: _read_uncached(url, referer, timeout), timeout=timeout)


def _read_uncached(url, referer, timeout=8):
    with urlopen(Request(url, headers={'User-Agent': UA, 'Referer': referer,
                                     'Cache-Control': 'no-cache'}), timeout=timeout) as response:
        raw = response.read(2 * 1024 * 1024 + 1)
        final = response.geturl()
    if len(raw) > 2 * 1024 * 1024:
        raise ValueError('Oversized HydraHD response')
    return raw.decode('utf-8', 'replace'), final


class _Links(HTMLParser):
    def __init__(self, body):
        super().__init__(convert_charrefs=True)
        self.links = []
        self.feed(body)

    def handle_starttag(self, tag, attrs):
        if tag == 'a':
            self.links.append(dict(attrs).get('href', ''))


def status_domains(body):
    """Disabled cards have no Visit link; ignore prose and commented markup."""
    result = []
    for link in _Links(body).links:
        parts = urlsplit(link)
        host = (parts.hostname or '').lower()
        if (parts.scheme == 'https' and re.fullmatch(r'hydrahd\.[a-z]{2,10}', host)
                and host not in ('hydrahd.info', 'hydrahd.ru')
                and not parts.username and host not in result):
            result.append(host)
    return tuple(result)


def domains():
    global _domains, _checked_at
    with _lock:
        if time.monotonic() - _checked_at < 900 and _domains:
            return _domains
        try:
            body, final = _read(STATUS_URL, STATUS_URL)
            if urlsplit(final).hostname != 'hydrahd.info':
                raise ValueError('Unexpected status redirect')
            active = status_domains(body)
            if not active:
                raise ValueError('No active domains')
            _domains = active
        except Exception:
            _domains = _domains or FALLBACK_DOMAINS
        _checked_at = time.monotonic()
        return _domains


class _Servers(HTMLParser):
    def __init__(self, body):
        super().__init__(convert_charrefs=True)
        self.rows = []
        self.current = None
        self.label = False
        self.feed(body)

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == 'div':
            self.current = None
            if ('iframe-server-button' in attrs.get('class', '').split()
                    and 'premium' not in attrs.get('class', '').split()):
                self.current = {'url': attrs.get('data-link', ''), 'label': ''}
                self.rows.append(self.current)
        if tag == 'p':
            self.label = self.current is not None and not self.current['label']

    def handle_endtag(self, tag):
        if tag == 'p':
            self.label = False

    def handle_data(self, data):
        if self.label and self.current is not None:
            self.current['label'] += data.strip()


def servers(body, tmdb_id, kind='movie', season=0, episode=0):
    from . import dulo_resolvers, twoembed
    supported = set(dulo_resolvers.HOSTS) | {'vixsrc.to', 'player.vidlove.cc', '2embed.cc'}
    result, seen = [], set()
    expected = (kind, str(tmdb_id), str(int(season)) if kind == 'tv' else '',
                str(int(episode)) if kind == 'tv' else '')
    for row in _Servers(body).rows:
        url = row['url']
        if not dulo_resolvers.http_url(url) or url in seen:
            continue
        parts = urlsplit(url)
        host = re.sub(r'^www\.', '', parts.hostname or '')
        if host not in supported:
            continue
        if host == '2embed.cc':
            canonical = twoembed.embed_url(tmdb_id, kind, season, episode)
            if not canonical:
                continue
            if kind == 'movie':
                matches = (parts.path.rstrip('/') in (
                    '/embed/' + str(tmdb_id), '/embed/movie/' + str(tmdb_id))
                    and not parts.query)
            else:
                matches = (parts.path.rstrip('/') == urlsplit(canonical).path
                           and not parts.query)
                if parts.path.rstrip('/') == '/embedtv/' + str(tmdb_id):
                    # Some menus separate the episode fields with '?' rather
                    # than placing the ampersands in the legacy path.
                    fields = parse_qsl(parts.query, keep_blank_values=True)
                    matches = (len(fields) == 2 and dict(fields) == {
                        's': str(int(season)), 'e': str(int(episode))})
            if not matches:
                continue
            url = canonical
            if url in seen:
                continue
        else:
            try:
                ident = dulo_resolvers.identity(url)
            except ValueError:
                continue
            if ident != expected:
                continue
        label = (row['label'] or host).replace('[', '(').replace(']', ')')
        result.append({'url': url, 'label': '%s / %s' % (label[:80], host)})
        seen.add(url)
    return result


def discover(tmdb_id, kind='movie', season=0, episode=0):
    from . import tmdb
    if not str(tmdb_id).isdigit() or int(tmdb_id) < 1 or kind not in ('movie', 'tv'):
        raise ValueError('Invalid HydraHD media identifier')
    season, episode = int(season), int(episode)
    if kind == 'tv' and (season < 0 or episode < 1):
        raise ValueError('Invalid episode')
    meta = tmdb.get_metadata(tmdb_id, kind) or {}
    imdb = meta.get('imdb_id') or ''
    if not re.fullmatch(r'tt\d+', imdb):
        return []
    params = {'i': imdb, 't': str(tmdb_id)}
    if kind == 'tv':
        params.update(s=str(season), e=str(episode))
    path = '/ajax/%s_0.php?' % ('mov' if kind == 'movie' else 'tv') + urlencode(params)
    active = domains()
    deadline = time.monotonic() + 25
    for host in active:
        if time.monotonic() >= deadline:
            break
        base = 'https://' + host
        try:
            body, final = _read(base + path, base + '/',
                                timeout=min(8, max(1, deadline - time.monotonic())))
            if (urlsplit(final).hostname not in active
                    or urlsplit(final).path != urlsplit(path).path):
                continue
            rows = servers(body, tmdb_id, kind, season, episode)
            if rows:
                return rows
        except Exception:
            continue
    return []


def resolve_server(url):
    from . import dulo_resolvers, twoembed, vidlove
    host = re.sub(r'^www\.', '', urlsplit(url).hostname or '')
    if host == 'player.vidlove.cc':
        return vidlove.resolve(url)
    if host == '2embed.cc':
        return twoembed.resolve(url)
    if host != 'vixsrc.to':
        return dulo_resolvers.resolve(url)
    # Hydra2's API returns a short-lived embed URL; never cache these tokens.
    route = urlsplit(url).path.rstrip('/')
    if not re.fullmatch(r'/(?:movie/\d+|tv/\d+/\d+/\d+)', route):
        return None
    body, _ = _read('https://vixsrc.to/api' + route + '?lang=en', url)
    src = json.loads(body).get('src')
    if not isinstance(src, str):
        return None
    embed = urljoin('https://vixsrc.to/', src)
    if urlsplit(embed).hostname != 'vixsrc.to' or not urlsplit(embed).path.startswith('/embed/'):
        return None
    body, final = _read(embed, 'https://vixsrc.to/')
    if urlsplit(final).hostname != 'vixsrc.to':
        return None
    block = re.search(r'window\.masterPlaylist\s*=\s*\{(.*?)\n\s*\}\s*(?:;|(?=window\.))', body, re.S)
    if not block:
        return None
    playlist = re.search(r"\burl\s*:\s*['\"]([^'\"]+)['\"]", block[1])
    params = dict(re.findall(r"['\"](token|expires|asn)['\"]\s*:\s*['\"]([^'\"]*)['\"]", block[1]))
    if not playlist or not params.get('token') or not params.get('expires'):
        return None
    target = urlsplit(playlist[1])
    if target.scheme != 'https' or target.hostname != 'vixsrc.to' or not target.path.startswith('/playlist/'):
        return None
    query = dict(parse_qsl(target.query))
    query.update(params, h='1', lang='en')
    return {'url': target._replace(query=urlencode(query)).geturl(), 'type': 'hls',
            'headers': {'User-Agent': UA, 'Referer': 'https://vixsrc.to/',
                        'Origin': 'https://vixsrc.to'}}
