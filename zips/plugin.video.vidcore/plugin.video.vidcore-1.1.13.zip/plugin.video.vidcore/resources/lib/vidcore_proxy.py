"""Local HLS relay preserving provider headers, tokens and segment packaging."""
import re
import json
import secrets
import threading
import time
import tempfile
import shutil
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from http.client import IncompleteRead
from urllib.parse import urljoin, urlsplit, parse_qsl, urlencode, urlunsplit
from urllib.request import Request, urlopen


def video_bytes(data):
    if not data.startswith(b'\x89PNG\r\n\x1a\n'):
        return data
    # Require five consecutive TS sync bytes to avoid matching image data.
    for offset in range(min(len(data) - 752, 65536)):
        if all(data[offset + n * 188] == 0x47 for n in range(5)):
            return data[offset:]
    raise ValueError('Image response contains no MPEG-TS video')


def _download(response):
    """Buffer for safe retry, spilling large segments to disk instead of RAM."""
    body = tempfile.SpooledTemporaryFile(max_size=1024 * 1024)
    try:
        with response:
            base, status = response.geturl(), response.status
            content_range = response.headers.get('Content-Range')
            expected = response.headers.get('Content-Length')
            while True:
                chunk = response.read(256 * 1024)
                if not chunk:
                    break
                body.write(chunk)
            size = body.tell()
            if expected is not None and size != int(expected):
                raise OSError('Truncated upstream media')
        body.seek(0)
        return body, size, base, status, content_range
    except BaseException:
        body.close()
        raise


class Proxy:
    def __init__(self, url, headers, refresh_tokens=True, refresh_callback=None, request_opener=None):
        self.headers = headers
        self.refresh_tokens = refresh_tokens
        self.open = request_opener.open if request_opener is not None else urlopen
        parsed = urlsplit(url)
        self.token = dict(parse_qsl(parsed.query)).get('token', '') if refresh_tokens else ''
        self.expires = dict(parse_qsl(parsed.query)).get('expires', '') if refresh_tokens else ''
        self.refresh_callback = refresh_callback
        self.token_host = parsed.netloc
        self.root_upstream = url
        self.last_token_refresh = time.monotonic()
        self.last_refresh_attempt = 0
        self.refresh_lock = threading.Lock()
        self.urls = {}
        self.paths = {}
        self.url_seen = {}
        self.manifests = {}
        self.last_prune = 0
        self.lock = threading.Lock()
        self.last_request = time.monotonic()
        owner = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args):
                pass

            def do_GET(self):
                with owner.lock:
                    upstream = owner.urls.get(self.path)
                if not upstream:
                    self.send_error(404)
                    return
                owner.last_request = time.monotonic()
                body = None
                sent = False
                try:
                    try:
                        owner.refresh_if_due()
                    except Exception:
                        # A failed proactive renewal must not break a URL
                        # that may still work. Retry renewal on rejection.
                        pass
                    with owner.lock:
                        upstream = owner.urls.get(self.path, upstream)
                    request_url = owner.authorize(upstream)
                    request_headers = dict(owner.headers)
                    if self.headers.get('Range'):
                        request_headers['Range'] = self.headers['Range']
                    try:
                        response = owner.open(Request(request_url, headers=request_headers), timeout=8)
                    except Exception as first_error:
                        code = getattr(first_error, 'code', None)
                        if code in (401, 403, 404) and (owner.refresh_callback or owner.token):
                            if owner.refresh_callback:
                                owner.refresh_from_source()
                            else:
                                owner.refresh_token()
                        elif not (code in (408, 429, 500, 502, 503, 504)
                                  or isinstance(first_error, (TimeoutError, ConnectionError))
                                  or isinstance(getattr(first_error, 'reason', None), (TimeoutError, ConnectionError))):
                            raise
                        with owner.lock:
                            upstream = owner.urls.get(self.path, upstream)
                        request_headers = dict(owner.headers)
                        if self.headers.get('Range'):
                            request_headers['Range'] = self.headers['Range']
                        response = owner.open(Request(owner.authorize(upstream), headers=request_headers), timeout=8)
                    for body_attempt in range(2):
                        try:
                            body, size, base, status, content_range = _download(response)
                            data = body.read(65536 + 752)
                            if status == 206 and data.startswith(b'\x89PNG\r\n\x1a\n'):
                                body.close()
                                body = None
                                request_headers = {key: value for key, value in request_headers.items()
                                                   if key.lower() != 'range'}
                                complete = owner.open(Request(owner.authorize(upstream), headers=request_headers), timeout=8)
                                body, size, base, status, content_range = _download(complete)
                                if status != 200 or content_range:
                                    raise OSError('Upstream did not return a complete segment')
                                data = body.read(65536 + 752)
                            break
                        except (OSError, TimeoutError, IncompleteRead):
                            if body is not None:
                                body.close()
                                body = None
                            if body_attempt:
                                raise
                            # Nothing has been sent to Kodi yet: retry the
                            # same complete segment without duplicating bytes.
                            response = owner.open(Request(owner.authorize(upstream), headers=request_headers), timeout=8)
                    manifest_data = data[3:] if data.startswith(b'\xef\xbb\xbf') else data
                    if manifest_data.lstrip().startswith(b'#EXTM3U'):
                        status, content_range = 200, None
                        lines = []
                        if size > 1024 * 1024:
                            raise ValueError('Manifest exceeds size limit')
                        body.seek(0)
                        manifest = body.read().decode('utf-8-sig').lstrip()
                        references = set()
                        def register(url, suffix):
                            local = owner.register(url, suffix)
                            references.add(urlsplit(local).path)
                            return local
                        master = '#EXT-X-STREAM-INF:' in manifest
                        for line in manifest.splitlines():
                            if line and not line.startswith('#'):
                                line = register(urljoin(base, line.strip()),
                                                      '.m3u8' if master else None)
                            elif 'URI="' in line:
                                suffix = '.mp4' if line.startswith('#EXT-X-MAP:') else '.key' if line.startswith('#EXT-X-KEY:') else '.m3u8'
                                line = re.sub(r'URI="([^"]+)"',
                                              lambda m: 'URI="' + register(urljoin(base, m[1]), suffix) + '"', line)
                            lines.append(line)
                        data = ('\n'.join(lines) + '\n').encode('utf-8')
                        owner.update_manifest(self.path, references)
                        mime = 'application/vnd.apple.mpegurl'
                        length = len(data)
                        body.close()
                        body = None
                    else:
                        decoded = video_bytes(data)
                        if len(decoded) != len(data):
                            status, content_range = 200, None
                        offset = len(data) - len(decoded)
                        body.seek(offset)
                        length = size - offset
                        data = decoded
                        if data[:32].decode('utf-8-sig', errors='replace').lstrip().startswith('WEBVTT'):
                            mime = 'text/vtt'
                        else:
                            mime = 'video/mp2t' if data.startswith(b'G') else 'application/octet-stream'
                    self.send_response(status)
                    self.send_header('Content-Type', mime)
                    self.send_header('Content-Length', str(length))
                    if content_range:
                        self.send_header('Content-Range', content_range)
                        self.send_header('Accept-Ranges', 'bytes')
                    self.end_headers()
                    sent = True
                    if body is None:
                        self.wfile.write(data)
                    else:
                        shutil.copyfileobj(body, self.wfile, length=256 * 1024)
                except (OSError, ValueError, IncompleteRead) as exc:
                    try:
                        from . import debug_bundle
                        debug_bundle.error('Playback relay', upstream)
                        import xbmc
                        xbmc.log('VIDCORE stream proxy failed: %s%s' % (
                            type(exc).__name__, ' HTTP %s' % exc.code if hasattr(exc, 'code') else ''), xbmc.LOGWARNING)
                    except Exception:
                        pass
                    if not sent:
                        self.send_error(502, 'Stream upstream unavailable')
                    self.close_connection = True
                finally:
                    if body is not None:
                        body.close()
                    owner.last_request = time.monotonic()

        self.server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        self.server.daemon_threads = True
        self.url = self.register(url, '.m3u8')
        self.root_path = urlsplit(self.url).path
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()

    def authorize(self, url):
        if not self.token or urlsplit(url).netloc != self.token_host:
            return url
        parsed = urlsplit(url)
        query = dict(parse_qsl(parsed.query))
        if self.token:
            query['token'] = self.token
        if self.expires:
            query['expires'] = self.expires
        return urlunsplit((parsed.scheme, parsed.netloc, parsed.path, urlencode(query), parsed.fragment))

    def refresh_token(self):
        origin = 'https://' + self.token_host
        with self.open(Request(origin + '/generate.php', headers=self.headers), timeout=12) as response:
            token = response.read(4096).decode('utf-8').strip()
        if token.startswith('{'):
            data = json.loads(token)
            token = data.get('token') or data.get('data') or data.get('string') or data.get('result') or ''
            self.expires = str(data.get('expires', self.expires))
        if token:
            self.token = token
            self.last_token_refresh = time.monotonic()

    def refresh_if_due(self):
        """Refresh from an active Kodi request, not only the keep-alive loop."""
        if not (self.refresh_callback or self.token):
            return
        if time.monotonic() - self.last_token_refresh < 120:
            return
        if time.monotonic() - self.last_refresh_attempt < 30:
            return
        if not self.refresh_lock.acquire(False):
            return
        try:
            if time.monotonic() - self.last_token_refresh >= 120:
                self.last_refresh_attempt = time.monotonic()
                if self.refresh_callback:
                    self._refresh_from_source()
                else:
                    self.refresh_token()
        finally:
            self.refresh_lock.release()

    def refresh_from_source(self):
        with self.refresh_lock:
            self._refresh_from_source()

    def _refresh_from_source(self):
        import xbmc
        fresh = self.refresh_callback()
        fresh_url = fresh.get('url') if isinstance(fresh, dict) else fresh
        if not isinstance(fresh_url, str) or urlsplit(fresh_url).scheme not in ('http', 'https'):
            raise ValueError('source refresh returned no URL')
        old_root = self.root_upstream
        old_parts, new_parts = urlsplit(old_root), urlsplit(fresh_url)
        old_dir = old_parts.path.rsplit('/', 1)[0] + '/'
        new_dir = new_parts.path.rsplit('/', 1)[0] + '/'
        old_query = dict(parse_qsl(old_parts.query))
        query = dict(parse_qsl(new_parts.query))
        with self.lock:
            if isinstance(fresh, dict):
                if fresh.get('headers') is not None:
                    self.headers = dict(fresh['headers'])
                if fresh.get('opener') is not None:
                    self.open = fresh['opener'].open
            # Source renewal must respect the provider's token protocol.
            # A refreshed URL may drop tokens or switch to another signature.
            self.token = query.get('token', '') if self.refresh_tokens else ''
            self.expires = query.get('expires', '') if self.refresh_tokens else ''
            # A refreshed signature can rotate the playlist URL as well as
            # its token. Replace the registered root mapping so Kodi's next
            # manifest reload reaches the new upstream playlist.
            for path, registered in list(self.urls.items()):
                if registered == old_root:
                    self.urls[path] = fresh_url
                elif isinstance(fresh, dict):
                    # VidBolt returns the same media with refreshed URLs.
                    # Keep Kodi's existing local child URLs usable when the
                    # CDN directory or shared authorization query rotates.
                    parts = urlsplit(registered)
                    if parts.netloc == old_parts.netloc and parts.path.startswith(old_dir):
                        child_query = dict(parse_qsl(parts.query))
                        original_query = dict(child_query)
                        for name, value in query.items():
                            if name in old_query and child_query.get(name) == old_query[name]:
                                child_query[name] = value
                        for name in ('token', 'expires'):
                            if (name in old_query and name not in query
                                    and child_query.get(name) == old_query[name]):
                                child_query.pop(name, None)
                        self.urls[path] = urlunsplit((new_parts.scheme, new_parts.netloc,
                            new_dir + parts.path[len(old_dir):],
                            urlencode(child_query) if child_query != original_query else parts.query,
                            parts.fragment))
            self.paths = {url: path for path, url in self.urls.items()}
            self.root_upstream = fresh_url
            self.token_host = new_parts.netloc
        self.last_token_refresh = time.monotonic()
        xbmc.log('VIDCORE stream: renewed playback source', xbmc.LOGINFO)

    def register(self, url, suffix=None):
        if self.token and urlsplit(url).netloc == self.token_host:
            parsed = urlsplit(url)
            query = dict(parse_qsl(parsed.query))
            query.setdefault('token', self.token)
            url = urlunsplit((parsed.scheme, parsed.netloc, parsed.path,
                              urlencode(query), parsed.fragment))
        with self.lock:
            path = self.paths.get(url)
            if path is None:
                # FFmpeg checks HLS segment extensions.
                extension = urlsplit(url).path.rsplit('.', 1)[-1].lower()
                if suffix is None:
                    suffix = '.' + extension if extension in ('m3u8', 'mp4', 'm4s', 'ts', 'aac', 'vtt', 'webvtt') else '.ts'
                path = '/' + secrets.token_urlsafe(24) + suffix
                self.urls[path] = url
                self.paths[url] = path
            self.url_seen[path] = time.monotonic()
        return 'http://127.0.0.1:%d%s' % (self.server.server_address[1], path)

    def update_manifest(self, path, references):
        """Retain current playlists and a grace window for queued segments.

        VOD playlists retain every segment for seeking; sliding live playlists
        release old segments once they leave all playlists and the grace window.
        """
        now = time.monotonic()
        with self.lock:
            self.manifests[path] = references
            if now - self.last_prune < 30:
                return
            self.last_prune = now
            needed = {self.root_path}
            # Follow only reachable manifests, so retired renditions cannot
            # keep their old segments alive indefinitely.
            pending = [self.root_path]
            while pending:
                current = pending.pop()
                for child in self.manifests.get(current, ()):
                    if child not in needed:
                        needed.add(child)
                        pending.append(child)
            for old in list(self.urls):
                if old not in needed and now - self.url_seen.get(old, now) > 300:
                    url = self.urls.pop(old)
                    if self.paths.get(url) == old:
                        self.paths.pop(url, None)
                    self.url_seen.pop(old, None)
                    self.manifests.pop(old, None)

    def keep_alive(self):
        import xbmc
        monitor = xbmc.Monitor()
        player = xbmc.Player()
        try:
            while not monitor.abortRequested():
                # Signed provider URLs commonly expire after about five
                # minutes. Refresh with headroom so the next manifest reload
                # does not receive an already-expired URL.
                if (self.refresh_callback or self.token) and time.monotonic() - self.last_token_refresh >= 120:
                    try:
                        self.refresh_if_due()
                    except Exception as exc:
                        import xbmc
                        xbmc.log('VIDCORE stream: background token refresh failed: %s' %
                                 type(exc).__name__, xbmc.LOGWARNING)
                if time.monotonic() - self.last_request > 45 and not player.isPlayingVideo():
                    break
                if monitor.waitForAbort(1):
                    break
        finally:
            self.server.shutdown()
            self.server.server_close()
