"""Bounded single-flight sharing for identical public discovery reads."""
import threading
import time

_lock = threading.Lock()
_values = {}
_pending = {}


def fetch(key, read, ttl=30, timeout=8):
    with _lock:
        cached = _values.get(key)
        if cached and time.monotonic() - cached[0] < ttl:
            return cached[1]
        event = _pending.get(key)
        owner = event is None
        if owner:
            event = _pending[key] = threading.Event()
    if not owner:
        if not event.wait(timeout):
            raise TimeoutError('Shared provider request timed out')
        with _lock:
            cached = _values.get(key)
        if cached and time.monotonic() - cached[0] < ttl:
            return cached[1]
        raise OSError('Shared provider request failed')
    try:
        value = read()
        with _lock:
            if _pending.get(key) is event:
                if len(_values) >= 128:
                    _values.pop(next(iter(_values)))
                _values[key] = (time.monotonic(), value)
        return value
    finally:
        with _lock:
            if _pending.get(key) is event:
                _pending.pop(key, None)
            event.set()


def clear():
    with _lock:
        _values.clear()
        pending = list(_pending.values())
        _pending.clear()
        for event in pending:
            event.set()
