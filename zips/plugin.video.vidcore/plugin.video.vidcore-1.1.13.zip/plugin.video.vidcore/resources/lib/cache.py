"""Clear Vidcore-owned cached data without resetting user settings/history."""
import os
import shutil
import json
import sqlite3
from urllib.parse import unquote, urlsplit


def _is_artwork(url):
    """Only local artwork inside Vidcore's own install or profile directory."""
    import xbmcvfs
    value = str(url or '')
    for _ in range(4):
        decoded = unquote(value)
        if decoded == value:
            break
        value = decoded
    while value.lower().startswith('image://'):
        value = value[8:]
    try:
        parts = urlsplit(value)
        # Shared image-CDN URLs cannot be attributed exclusively to Vidcore.
        if parts.scheme.lower() in ('http', 'https'):
            return False
        if parts.scheme.lower() == 'file':
            value = unquote(parts.path)
            if parts.netloc:
                value = '//' + parts.netloc + value
            elif os.name == 'nt' and len(value) > 2 and value[0] == '/' and value[2] == ':':
                value = value[1:]
        elif parts.scheme and parts.scheme.lower() != 'special' and len(parts.scheme) != 1:
            return False
        value = xbmcvfs.translatePath(value)
        candidate = os.path.normcase(os.path.realpath(value))
        roots = (os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
                 xbmcvfs.translatePath('special://profile/addon_data/plugin.video.vidcore/'))
        for root in roots:
            root = os.path.normcase(os.path.realpath(root))
            if candidate != root and os.path.commonpath((root, candidate)) == root:
                return True
    except (OSError, ValueError, TypeError):
        pass
    return False


def _clear_textures():
    """Use Kodi's API so its database, files and loaded textures stay in sync."""
    import xbmc
    query = {'jsonrpc': '2.0', 'id': 1, 'method': 'Textures.GetTextures',
             'params': {'properties': ['url'], 'filter': {'or': [
                 {'field': 'url', 'operator': 'contains', 'value': value}
                 for value in ('plugin.video.vidcore',)
             ]}}}
    try:
        reply = json.loads(xbmc.executeJSONRPC(json.dumps(query)))
        textures = reply['result']['textures']
        if not isinstance(textures, list):
            raise ValueError('Invalid texture list')
        ids = set()
        for texture in textures:
            if _is_artwork(texture.get('url')):
                texture_id = texture.get('textureid')
                if type(texture_id) is not int or texture_id < 0:
                    raise ValueError('Invalid texture ID')
                ids.add(texture_id)
        failures = 0
        ids = sorted(ids)
        for start in range(0, len(ids), 50):
            batch = [{'jsonrpc': '2.0', 'id': texture_id,
                      'method': 'Textures.RemoveTexture',
                      'params': {'textureid': texture_id}}
                     for texture_id in ids[start:start + 50]]
            replies = json.loads(xbmc.executeJSONRPC(json.dumps(batch)))
            if not isinstance(replies, list):
                raise ValueError('Invalid texture removal response')
            successful = {row.get('id') for row in replies
                          if isinstance(row, dict) and row.get('result') == 'OK'
                          and 'error' not in row}
            failures += sum(request['id'] not in successful for request in batch)
        if failures:
            raise OSError('Some cached artwork could not be cleared')
        return len(ids)
    except (ValueError, TypeError, KeyError, AttributeError) as exc:
        raise OSError('Kodi artwork cache could not be cleared') from exc


def clear():
    import xbmcgui
    import xbmcvfs
    from . import tmdb
    from . import srstop
    from . import shared_requests
    from . import fanarttv
    from . import metadata_cache
    shared_requests.clear()

    profile = os.path.realpath(xbmcvfs.translatePath(
        'special://profile/addon_data/plugin.video.vidcore/'))
    target = os.path.join(profile, 'metadata_cache')
    # Never follow a relocated cache directory outside the addon profile.
    resolved = os.path.realpath(target)
    if os.path.commonpath((profile, resolved)) != profile or resolved == profile:
        raise OSError('Cache path is outside the Vidcore profile')
    try:
        metadata_cache.clear(target)
    except sqlite3.Error as exc:
        raise OSError('Metadata cache could not be cleared') from exc
    # Retain the invalidation marker; remove legacy offline metadata and artwork.
    for name in ('metadata.json', 'metadata.json.tmp', 'art'):
        old = os.path.join(target, name)
        if os.path.islink(old):
            os.unlink(old)
        elif os.path.isdir(old):
            if os.path.commonpath((profile, os.path.realpath(old))) != profile:
                raise OSError('Artwork cache path is outside the Vidcore profile')
            shutil.rmtree(old)
        elif os.path.exists(old):
            os.remove(old)
    tmdb._SESSION_META_CACHE.clear()
    tmdb._TVDB_ID_CACHE.clear()
    tmdb._TMDB_ART_HEALTH.update({'checked': 0.0, 'ok': True})
    fanarttv.clear_cache()
    srstop.clear_cache()
    window = xbmcgui.Window(10000)
    window.clearProperty('Vidcore.SearchSessions')
    window.clearProperty('Vidcore.WatchRegion')
    return _clear_textures()
