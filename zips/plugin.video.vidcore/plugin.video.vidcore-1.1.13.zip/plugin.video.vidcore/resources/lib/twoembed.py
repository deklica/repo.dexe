"""Resolve 2Embed's movie/episode routes and nested Vidsrc/Swish wrappers."""
import re
import json
from http.cookiejar import CookieJar
from html import unescape
from html.parser import HTMLParser
from urllib.parse import urlencode, urljoin, urlsplit
from urllib.request import Request, urlopen, build_opener, HTTPCookieProcessor
from urllib.error import HTTPError, URLError

BASE = 'https://www.2embed.cc'
UA = 'Mozilla/5.0'
LIMIT = 2 * 1024 * 1024


def embed_url(tmdb_id, kind='movie', season=0, episode=0):
    identifier = str(tmdb_id)
    if not identifier.isascii() or not identifier.isdigit() or int(identifier) < 1:
        return ''
    if kind == 'movie':
        return BASE + '/embed/movie/' + identifier
    if kind == 'tv':
        try:
            season, episode = int(season), int(episode)
        except (ValueError, TypeError):
            return ''
        if season >= 0 and episode > 0:
            # Ampersands belong to the documented path, not a query string.
            return BASE + '/embedtv/%s&s=%d&e=%d' % (identifier, season, episode)
    return ''


class _Frames(HTMLParser):
    def __init__(self):
        super().__init__()
        self.urls = []

    def handle_starttag(self, tag, attrs):
        if tag.lower() == 'iframe':
            attrs = dict(attrs)
            self.urls.append(attrs.get('data-src') or attrs.get('src') or '')


def player_url(body, page):
    return next(iter(player_urls(body, page)), '')


def _wrapper_url(target):
    parts = urlsplit(target)
    if parts.scheme != 'https' or parts.username or parts.password:
        return False
    if parts.hostname == 'streamsrcs.2embed.cc':
        return parts.path == '/swish'
    if parts.hostname in ('2embed.cc', 'www.2embed.cc'):
        return bool(re.fullmatch(r'/(?:embed/(?:movie/\d+|tt\d+|\d+)|embedtv/(?:tt)?\d+&s=\d+&e=[1-9]\d*)/?', parts.path))
    if parts.hostname == 'vidsrc.buzz':
        return (bool(re.fullmatch(r'/embed/movie/(?:tt)?\d+/?', parts.path))
                or bool(re.fullmatch(r'/embed/tv/(?:tt)?\d+/\d+/[1-9]\d*/?', parts.path))
                or parts.path == '/pl/playerswish.php')
    return False


def player_urls(body, page):
    """Read lazy iframes and the site's JSON-escaped Swish configuration."""
    seen = set()
    texts = [body]
    for _ in range(4):
        decoded = unescape(texts[-1]).replace('\\/', '/').replace('\\"', '"')
        if decoded == texts[-1]:
            break
        texts.append(decoded)
    for text in texts:
        parser = _Frames()
        parser.feed(text)
        links = list(parser.urls)
        if urlsplit(page).hostname == 'vidsrc.buzz':
            links.extend(re.findall(r'"swish"\s*:\s*"([^"\s]+)"', text))
        for raw in links:
            target = urljoin(page, unescape(raw))
            if target not in seen and _wrapper_url(target):
                seen.add(target)
                yield target


def find_host(url, opener=None):
    queue, seen = [(url, 'https://watch.cinewave.qzz.io/')], set()
    while queue and len(seen) < 8:
        page, referer = queue.pop(0)
        if page in seen:
            continue
        seen.add(page)
        try:
            body = _page(page, referer, opener)
        except (HTTPError, URLError, TimeoutError, ValueError):
            # Another wrapper on the same title may still work.
            continue
        host = host_url(body)
        if host:
            return host, page
        queue.extend((target, page) for target in player_urls(body, page) if target not in seen)
    return '', ''


def host_url(body):
    parser = _Frames()
    parser.feed(body)
    for raw in parser.urls:
        # swish.js in the capture prefixes this identifier with this host.
        if re.fullmatch(r'[a-zA-Z0-9]{12}', raw):
            return 'https://2vcdn.skin/e/' + raw
        target = urljoin('https://2vcdn.skin/', raw)
        parts = urlsplit(target)
        if (parts.scheme == 'https' and parts.hostname == '2vcdn.skin'
                and re.fullmatch(r'/e/[a-zA-Z0-9]{12}/?', parts.path)):
            return target
    return ''


def media_urls(body, page='https://2vcdn.skin/'):
    from .lulustream import _unpack, _unescape_js
    seen = set()
    texts = [body] + list(_unpack(body))
    # Match the player's preferred same-origin relay before its CDN fallbacks.
    for text in texts:
        for match in re.finditer(r'\b(?:var|let|const)\s+links\s*=\s*', text):
            try:
                links = json.JSONDecoder().raw_decode(text[match.end():])[0]
            except ValueError:
                continue
            if not isinstance(links, dict):
                continue
            for key in ('hls4', 'hls3', 'hls2'):
                raw = links.get(key)
                if not isinstance(raw, str) or not raw:
                    continue
                url = urljoin(page, unescape(raw))
                parts = urlsplit(url)
                if (parts.scheme in ('https', 'http') and parts.hostname
                        and not parts.username and not parts.password and url not in seen):
                    seen.add(url)
                    yield url
    for text in texts:
        for raw in re.findall(r'''https?://[^\s"'<>\\]+''', _unescape_js(text)):
            url = unescape(raw)
            if urlsplit(url).path.lower().endswith(('.txt', '.m3u8')) and url not in seen:
                seen.add(url)
                yield url


def _page(url, referer, opener=None):
    open_url = opener.open if opener is not None else urlopen
    with open_url(Request(url, headers={'User-Agent': UA, 'Referer': referer}), timeout=12) as response:
        body = response.read(LIMIT + 1)
    if len(body) > LIMIT:
        raise ValueError('Oversized player page')
    return body.decode('utf-8', errors='replace')


def _failure(stage, reason):
    message = '2Embed %s: %s' % (stage, reason)
    try:
        import xbmc
        xbmc.log('VIDCORE ' + message, xbmc.LOGWARNING)
    except ImportError:
        pass
    return {'error': message + ' Try another source.', 'stage': stage}


def _native_sources(url, opener):
    """Read native Vidsrc servers before trying the older Swish wrapper."""
    from .movieuniverse import _Session, player_config
    route = urlsplit(url).path
    movie = re.fullmatch(r'/embed/movie/(\d+)', route)
    tv = re.fullmatch(r'/embedtv/(\d+)&s=(\d+)&e=([1-9]\d*)', route)
    if not movie and not tv:
        return
    kind = 'movie' if movie else 'tv'
    identifier = movie[1] if movie else tv[1]
    season, episode = (0, 0) if movie else (int(tv[2]), int(tv[3]))
    expected = '/embed/movie/' + identifier if movie else '/embed/tv/%s/%d/%d' % (identifier, season, episode)
    session = _Session()
    session.opener = opener
    queue, seen = [(url, 'https://watch.cinewave.qzz.io/')], set()
    while queue and len(seen) < 8:
        page, referer = queue.pop(0)
        if page in seen:
            continue
        seen.add(page)
        try:
            body, final = session.read(page, referer)
            if not _wrapper_url(final) or urlsplit(final).path != urlsplit(page).path:
                continue
            parts = urlsplit(final)
            if parts.hostname != 'vidsrc.buzz' or parts.path.rstrip('/') != expected:
                queue.extend((child, final) for child in player_urls(body, final) if child not in seen)
                continue
            config = player_config(body, final, kind, season, episode)
            if not config or not isinstance(config.get('t'), str):
                continue
            ssr = config.get('ssr') or {}
            servers = ssr.get('servers') if isinstance(ssr, dict) else None
            if not isinstance(servers, list):
                continue
            refs = set()
            for server in servers[:8]:
                if not isinstance(server, dict) or not isinstance(server.get('ref'), str):
                    continue
                ref = server['ref']
                if not ref or ref in refs:
                    continue
                refs.add(ref)
                try:
                    endpoint = 'https://vidsrc.buzz/pl/api.php?' + urlencode({'a': 'play', 'ref': ref, 't': config['t']})
                    raw, _ = session.read(endpoint, final)
                    data = json.loads(raw)
                    if not isinstance(data, dict) or not isinstance(data.get('url'), str):
                        continue
                    media = urljoin('https://vidsrc.buzz/pl/', data['url'])
                    target = urlsplit(media)
                    if (target.scheme != 'https' or target.hostname != 'vidsrc.buzz'
                            or target.port not in (None, 443) or target.username or target.password
                            or target.path != '/_stream'):
                        continue
                    yield {'url': media, 'type': 'hls', 'opener': opener,
                           'headers': {'User-Agent': UA, 'Referer': final, 'Origin': 'https://vidsrc.buzz'},
                           'minimum_duration': 600 if kind == 'movie' else 120}
                except (HTTPError, URLError, TimeoutError, ValueError):
                    continue
        except (HTTPError, URLError, TimeoutError, ValueError, TypeError, KeyError):
            continue


def resolve(url):
    parts = urlsplit(url)
    if (parts.scheme != 'https' or parts.hostname not in ('2embed.cc', 'www.2embed.cc')
            or not re.fullmatch(r'/(?:embed/movie/\d+|embedtv/\d+&s=\d+&e=[1-9]\d*)', parts.path)):
        return None
    stage = 'embed page'
    try:
        opener = build_opener(HTTPCookieProcessor(CookieJar()))
        from .vidcore_availability import check_stream
        for candidate in _native_sources(url, opener):
            checked = check_stream(candidate)
            if checked:
                return checked
        host, wrapper = find_host(url, opener)
        if not host:
            return _failure(stage, 'no reachable supported video host was listed.')
        stage = 'video host'
        headers = {'User-Agent': UA, 'Referer': host}
        body = _page(host, wrapper, opener)
        if 'file is no longer available' in body.lower():
            return _failure(stage, 'the host says this file has expired or been deleted.')
        candidates = list(media_urls(body, host))[:4]
        if not candidates:
            return _failure(stage, 'no HLS media links were found.')
        stage = 'media stream'
        reason = 'the host returned data instead of an HLS playlist.'
        for candidate in candidates:
            try:
                with opener.open(Request(candidate, headers=headers), timeout=12) as response:
                    sample = response.read(4096)
                    final = response.geturl()
                if sample.decode('utf-8-sig', errors='replace').lstrip().startswith('#EXTM3U'):
                    return {'url': final, 'type': 'hls', 'headers': headers, 'opener': opener}
            except HTTPError as exc:
                reason = 'the media server returned HTTP %s.' % exc.code
                continue
            except (URLError, TimeoutError):
                reason = 'the media server could not be reached or timed out.'
                continue
            except Exception as exc:
                reason = 'media validation failed (%s).' % type(exc).__name__
                continue
        return _failure(stage, reason)
    except HTTPError as exc:
        return _failure(stage, 'the provider returned HTTP %s.' % exc.code)
    except (URLError, TimeoutError):
        return _failure(stage, 'the provider could not be reached or timed out.')
    except Exception as exc:
        return _failure(stage, 'resolution failed (%s).' % type(exc).__name__)
