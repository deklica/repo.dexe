"""Cinejoy/Wing source discovery, using the player's v2 wire protocol."""
import hashlib
import hmac
import json
import os
from urllib.parse import urlsplit
from urllib.request import Request, urlopen

import xbmc

from .aesgcm import AES, _gctr, _ghash, aes_gcm_decrypt

API_URL = 'https://api.wing.st'
HEADERS = {'User-Agent': 'Mozilla/5.0', 'Referer': 'https://cinejoy.pk/',
           'Origin': 'https://cinejoy.pk'}
SERVERS = ('Nebula', 'Lisbon', 'Athens')
# Public server key and protocol version from Cinejoy's crush.wasm, 2026-10-11.
# No downloaded code is executed; upstream key rotation fails closed.
_PUBLIC = bytes.fromhex(
    '045c88a0ae33c683a4872590b04b22f4774a4fe1c6ecf74785c74a919a71207ca94'
    'f9e6b5a7854c3aa3b44ee46bc444fea694b9f23bcd80f864ecbef48c1ef6e14')
_KEY_ID = 2
_PREFIX = b'lumen-gate-v2'
_P = 0xffffffff00000001000000000000000000000000ffffffffffffffffffffffff
_N = 0xffffffff00000000ffffffffffffffffbce6faada7179e84f3b9cac2fc632551
_G = (0x6b17d1f2e12c4247f8bce6e563a440f277037d812deb33a0f4a13945d898c296,
      0x4fe342e2fe1a7f9b8ee7eb4a7c0f9e162bce33576b315ececbb6406837bf51f5)


def _add(left, right):
    if left is None:
        return right
    if right is None:
        return left
    x, y = left
    u, v = right
    if x == u and (y + v) % _P == 0:
        return None
    numerator, denominator = ((3 * x * x - 3, 2 * y) if left == right
                              else (v - y, u - x))
    slope = numerator * pow(denominator % _P, _P - 2, _P) % _P
    result_x = (slope * slope - x - u) % _P
    return result_x, (slope * (x - result_x) - y) % _P


def _multiply(scalar, point):
    result = None
    while scalar:
        if scalar & 1:
            result = _add(result, point)
        point = _add(point, point)
        scalar >>= 1
    return result


def _hkdf(shared, public, direction):
    prk = hmac.new(public, shared, hashlib.sha256).digest()
    return hmac.new(prk, _PREFIX + b'|' + direction + b'\x01', hashlib.sha256).digest()


def _encrypt(key, nonce, plaintext, aad):
    aes = AES(key)
    initial = nonce + b'\x00\x00\x00\x01'
    ciphertext = _gctr(aes, nonce + b'\x00\x00\x00\x02', plaintext)
    tag = _ghash(int.from_bytes(aes.encrypt_block(b'\x00' * 16), 'big'), aad, ciphertext)
    tag = bytes(x ^ y for x, y in zip(tag, aes.encrypt_block(initial)))
    return ciphertext + tag


def _seal(path, payload, entropy=None):
    entropy = os.urandom(44) if entropy is None else entropy
    if len(entropy) != 44:
        raise ValueError('Invalid request entropy')
    counter = 0
    while True:
        digest = hashlib.sha256(_PREFIX + b'|ephemeral|' + entropy[:32]
                                + counter.to_bytes(4, 'big')).digest()
        scalar = int.from_bytes(digest, 'big')
        if 0 < scalar < _N:
            break
        counter += 1
    x, y = _multiply(scalar, _G)
    public = b'\x04' + x.to_bytes(32, 'big') + y.to_bytes(32, 'big')
    remote = (int.from_bytes(_PUBLIC[1:33], 'big'), int.from_bytes(_PUBLIC[33:], 'big'))
    shared = _multiply(scalar, remote)[0].to_bytes(32, 'big')
    request_key = _hkdf(shared, public, b'c2s')
    response_key = _hkdf(shared, public, b's2c')
    plaintext = json.dumps({'path': path, 'payload': payload},
                           separators=(',', ':'), ensure_ascii=False).encode('utf-8')
    aad = _PREFIX + bytes((0, 1, _KEY_ID)) + public
    body = bytes((2, _KEY_ID)) + public + entropy[32:] + _encrypt(
        request_key, entropy[32:], plaintext, aad)
    return body, response_key, public


def _request(path, payload):
    body, key, public = _seal(path, payload)
    headers = dict(HEADERS, **{'Content-Type': 'application/octet-stream'})
    with urlopen(Request(API_URL + '/g', data=body, headers=headers), timeout=20) as response:
        encrypted = response.read(2 * 1024 * 1024)
    aad = _PREFIX + bytes((0, 2, _KEY_ID)) + public
    decoded = aes_gcm_decrypt(key, encrypted[:12], encrypted[12:], aad)
    return json.loads(decoded.decode('utf-8'))


def _payload(tmdb_id, kind, season, episode):
    identifier = str(tmdb_id or '')
    if not identifier.isascii() or not identifier.isdigit() or int(identifier) < 1:
        raise ValueError('Invalid TMDB identifier')
    if kind not in ('movie', 'tv'):
        raise ValueError('Invalid media type')
    payload = {'tmdb': identifier}
    if kind == 'tv':
        season, episode = int(season), int(episode)
        if season < 0 or episode < 1:
            raise ValueError('Invalid episode')
        payload.update(season=str(season), episode=str(episode))
    return payload


def _media_url(value):
    if not isinstance(value, str):
        return False
    try:
        parts = urlsplit(value)
        return (parts.scheme in ('http', 'https') and bool(parts.hostname)
                and not parts.username and not parts.password)
    except ValueError:
        return False


def resolve_server(server, tmdb_id, kind='movie', season=0, episode=0):
    """Resolve one server; the picker's media check verifies the resulting URL."""
    if server not in SERVERS:
        return None
    try:
        payload = _payload(tmdb_id, kind, season, episode)
        data = _request('/%s/%s' % (server, 'movie' if kind == 'movie' else 'series'), payload)
        if not isinstance(data, dict) or data.get('status') != 200:
            return None
        result = data.get('data')
        rows = result.get('stream') if isinstance(result, dict) else None
        if not isinstance(rows, list):
            return None
        for row in rows:
            if not isinstance(row, dict):
                continue
            url = row.get('playlist')
            source_type = 'mp4' if row.get('type') == 'mp4' else 'hls'
            if row.get('type') == 'file' and isinstance(row.get('qualities'), dict):
                qualities = row['qualities']
                candidates = sorted(qualities, key=lambda quality: int(quality)
                                    if str(quality).isdigit() else 0, reverse=True)
                url = next((qualities[quality].get('url') for quality in candidates
                            if isinstance(qualities[quality], dict)
                            and _media_url(qualities[quality].get('url'))), None)
                source_type = 'mp4'
            if _media_url(url):
                resolved = {'url': url, 'type': source_type, 'headers': dict(HEADERS)}
                # Nebula muxes AAC and video into the same fMP4 fragments.
                # Adaptive detects AAC but can stall its sample reader; Kodi's
                # native FFmpeg HLS demuxer handles both tracks together.
                if server == 'Nebula' and source_type == 'hls':
                    resolved['native_hls'] = True
                return resolved
    except Exception as exc:
        # Avoid logging signed links or binary response/key material.
        xbmc.log('VIDCORE Cinejoy %s discovery failed (%s)' %
                 (server, type(exc).__name__), xbmc.LOGWARNING)
    return None
