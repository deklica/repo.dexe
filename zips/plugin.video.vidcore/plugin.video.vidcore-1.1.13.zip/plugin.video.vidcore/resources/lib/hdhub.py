"""HDHub stream catalogue used by CineWave, with Kodi source selection."""
import json
import re
from urllib.parse import quote, urlsplit
from urllib.request import Request, urlopen

BASE = 'https://hdhub.thevolecitor.qzz.io'
# Public configuration from CineWave: no TorBox account, descending quality.
CONFIG = 'eyJ0b3Jib3giOiJ1bnNldCIsInF1YWxpdGllcyI6IjIxNjBwLDEwODBwLDcyMHAiLCJzb3J0IjoiZGVzYyJ9'
HEADERS = {'User-Agent': 'Mozilla/5.0', 'Referer': 'https://watch.cinewave.qzz.io/'}


def _log(message):
    import xbmc
    xbmc.log('VIDCORE HDHub: ' + message, xbmc.LOGINFO)


def api_url(tmdb_id, kind='movie', season=0, episode=0, imdb_id=''):
    if not str(tmdb_id).isdigit() or int(tmdb_id) < 1 or kind not in ('movie', 'tv'):
        raise ValueError('Invalid media identifier')
    identifier = imdb_id if re.fullmatch(r'tt\d+', str(imdb_id)) else 'tmdb:' + str(tmdb_id)
    if kind == 'tv':
        season, episode = int(season), int(episode)
        if season < 0 or episode < 1:
            raise ValueError('Invalid episode')
        identifier += ':%d:%d' % (season, episode)
    return '%s/%s/stream/%s/%s.json' % (
        BASE, CONFIG, 'series' if kind == 'tv' else 'movie', quote(identifier, safe=':'))


def sources(data):
    """Exclude external links, torrents, and CineWave's unsupported hosts."""
    rows = data.get('streams') if isinstance(data, dict) else None
    if not isinstance(rows, list):
        return []
    result, seen = [], set()
    for row in rows:
        if not isinstance(row, dict):
            continue
        url = row.get('url')
        if not isinstance(url, str) or url in seen:
            continue
        try:
            parts = urlsplit(url)
        except ValueError:
            continue
        if parts.scheme not in ('http', 'https') or not parts.hostname:
            continue
        name = str(row.get('name') or 'HDHub')
        description = str(row.get('description') or '')
        text = (name + ' ' + description).lower()
        if any(word in text for word in (
                '10gbps download only', 'file not found', 'castle', 'hubcdn', 'pixeldrain')):
            continue
        hints = row.get('behaviorHints')
        hints = hints if isinstance(hints, dict) else {}
        proxy_headers = hints.get('proxyHeaders')
        proxy_headers = proxy_headers if isinstance(proxy_headers, dict) else {}
        headers = dict(HEADERS)
        for extra in (row.get('headers'), proxy_headers.get('request')):
            if isinstance(extra, dict):
                for key, value in extra.items():
                    if (isinstance(key, str) and isinstance(value, str)
                            and not any(c in key + value for c in '\r\n')):
                        headers[key] = value
        label = name + (' — ' + ' | '.join(description.splitlines()) if description else '')
        # Remote labels must not inject Kodi formatting commands.
        label = label.replace('[', '(').replace(']', ')')
        from .source_quality import advertised_heights
        quality = advertised_heights(name + ' ' + description + ' ' + str(hints.get('filename') or ''))
        result.append({'url': url, 'headers': headers, 'label': label[:500],
                       'advertised_heights': quality})
        seen.add(url)
    return result


def media_type(sample):
    text_sample = sample[3:] if sample.startswith(b'\xef\xbb\xbf') else sample
    stripped = text_sample.lstrip()
    if stripped.startswith(b'#EXTM3U'):
        return 'hls'
    if stripped.startswith((b'<?xml', b'<MPD')) and b'<MPD' in stripped:
        return 'dash'
    if sample.startswith(b'\x1a\x45\xdf\xa3'):
        return 'mkv'
    if len(sample) >= 12 and sample[4:8] == b'ftyp':
        return 'mp4'
    return ''


def discover(tmdb_id, kind='movie', season=0, episode=0):
    """Load candidates without opening a selection dialog."""
    from . import tmdb
    meta = tmdb.get_metadata(tmdb_id, kind) or {}
    endpoint = api_url(tmdb_id, kind, season, episode, meta.get('imdb_id', ''))
    with urlopen(Request(endpoint, headers=HEADERS), timeout=30) as response:
        raw = response.read(4 * 1024 * 1024 + 1)
    if len(raw) > 4 * 1024 * 1024:
        raise ValueError('Oversized response')
    return sources(json.loads(raw.decode('utf-8')))


def resolve(tmdb_id, kind='movie', season=0, episode=0):
    import xbmcgui
    try:
        candidates = discover(tmdb_id, kind, season, episode)
        _log('catalogue returned %d playable candidate(s)' % len(candidates))
        if not candidates:
            return {'error': 'HDHub has no playable sources for this title.'}
        choice = xbmcgui.Dialog().select('HDHub — choose a stream',
                                         [item['label'] for item in candidates])
        if choice < 0:
            return {'cancelled': True}
        selected = candidates[choice]
        headers = dict(selected['headers'])
        probe_headers = dict(headers, Range='bytes=0-4095', **{'Accept-Encoding': 'identity'})
        with urlopen(Request(selected['url'], headers=probe_headers), timeout=15) as response:
            sample = response.read(4096)
        stream_type = media_type(sample)
        if not stream_type:
            return {'error': 'The selected HDHub link did not return video. Please choose another stream.'}
        _log('selected source resolved (type=%s)' % stream_type)
        # Keep the original signed URL: resolving it afresh preserves any
        # redirect behavior without sending the byte-range header to Kodi.
        return {'url': selected['url'], 'type': stream_type, 'headers': headers}
    except Exception as exc:
        _log('resolution failed (%s; HTTP %s)' %
             (type(exc).__name__, getattr(exc, 'code', 'n/a')))
        return {'error': 'HDHub could not load this source. The link may have expired; try another stream or try again later.'}
