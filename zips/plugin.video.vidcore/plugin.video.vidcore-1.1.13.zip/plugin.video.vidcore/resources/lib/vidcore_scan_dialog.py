"""Native, cancellable progress while waiting for the first checked source."""
import xbmcgui
import time


class SourceScanProgress:
    """Close before opening a source picker; repeated closes are harmless."""

    def __init__(self):
        self.started = time.monotonic()
        self.last_status = None
        self.dialog = xbmcgui.DialogProgress()
        self.dialog.create('Vidcore', 'Finding and checking playback sources...')

    def update(self, *args):
        if self.dialog is not None:
            self.dialog.update(*args)

    def begin_checks(self):
        pass

    def update_discovery(self, *args):
        pass

    def update_sources(self, *args):
        checked, total, available = args
        elapsed = int(time.monotonic() - self.started)
        status = (checked, total, available, elapsed)
        if status == self.last_status:
            return
        self.last_status = status
        if available:
            message = 'Checked %d of %d sources; %d available' % (checked, total, available)
        else:
            message = ('Checked %d of %d sources; waiting for a verified stream (%ds)'
                       % (checked, total, elapsed))
        self.update(int(100 * checked / max(1, total)), message)

    def iscanceled(self):
        return self.dialog is not None and self.dialog.iscanceled()

    def close(self):
        if self.dialog is not None:
            self.dialog.close()
            self.dialog = None


def create_progress():
    return SourceScanProgress()
