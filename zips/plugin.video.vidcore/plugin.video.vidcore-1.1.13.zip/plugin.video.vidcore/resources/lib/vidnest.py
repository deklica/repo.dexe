"""VidNest provider API resolver for native Kodi HLS playback."""
import re
import base64
import json
import hashlib
import secrets
from urllib.parse import urlsplit
from urllib.request import Request, urlopen

import xbmc

BASE_URL = 'https://vidnest.fun'
STREAM_KEY = 'K3p8vQ2mX9rL5wZ0fN7bG1sH4tJ6dC9_y8S3wM1nQ5pL2'


def _decode_response(data):
    """Support the current player's authenticated v2 response and legacy data."""
    if not isinstance(data, dict):
        raise ValueError('Invalid VidNest response')
    if data.get('v') == 2 and data.get('d'):
        from .aesgcm import aes_gcm_decrypt
        encoded = data['d']
        payload = base64.urlsafe_b64decode(encoded + '=' * (-len(encoded) % 4))
        key = hashlib.sha256((str(data['n']) + '|' + STREAM_KEY).encode()).digest()
        data = json.loads(aes_gcm_decrypt(key, payload[:12], payload[12:]).decode())
    elif data.get('encrypted'):
        alphabet = 'RB0fpH8ZEyVLkv7c2i6MAJ5u3IKFDxlS1NTsnGaqmXYdUrtzjwObCgQP94hoeW+/='
        standard = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/='
        encoded = data['data'].translate(str.maketrans(alphabet, standard))
        data = json.loads(base64.b64decode(encoded).decode('utf-8'))
    if not isinstance(data, dict):
        raise ValueError('Invalid VidNest stream data')
    return data


def _content_kind(content):
    """Normalize the media names used by the different Cosmos routes."""
    value = str(content or '').strip().lower()
    if value in ('movie', 'film'):
        return 'movie'
    if value in ('tv', 'tvshow', 'show', 'series', 'episode'):
        return 'tv'
    return ''


def embed_url(tmdb_id, content='movie', season=None, episode=None):
    """Return the documented VidNest player URL for a TMDB item."""
    tmdb_id = str(tmdb_id or '').strip()
    if not tmdb_id.isdigit() or int(tmdb_id) < 1:
        return ''
    kind = _content_kind(content)
    if kind == 'movie':
        return f'{BASE_URL}/movie/{tmdb_id}'
    if kind != 'tv':
        return ''
    try:
        season, episode = int(season), int(episode)
    except (TypeError, ValueError):
        return ''
    if season >= 0 and episode > 0:
        return f'{BASE_URL}/tv/{tmdb_id}/{season}/{episode}'
    return ''


def resolve(url):
    """Resolve the web player's provider API to a verified HLS stream."""
    parsed = urlsplit(url)
    if parsed.hostname != 'vidnest.fun' or not re.fullmatch(
            r'/(?:movie/\d+|tv/\d+/\d+/\d+)', parsed.path):
        return None
    for provider in ('yflix', 'rogflix', 'videasy'):
        try:
            request = Request('https://new.vidnest.fun/' + provider + parsed.path + '?_n=' + secrets.token_urlsafe(16),
                              headers={'User-Agent': 'Mozilla/5.0', 'Referer': BASE_URL + '/',
                                       'Origin': BASE_URL, 'Accept': 'application/json'})
            with urlopen(request, timeout=12) as response:
                data = _decode_response(json.loads(response.read(2 * 1024 * 1024).decode('utf-8')))
            stream = str(data.get('url') or '').strip()
            if urlsplit(stream).scheme not in ('https', 'http'):
                continue
            headers = {'User-Agent': 'Mozilla/5.0', 'Referer': BASE_URL + '/'}
            for key, value in (data.get('headers') or {}).items():
                if key.strip().lower() in ('user-agent', 'referer', 'origin', 'accept'):
                    headers[key.strip()] = str(value).strip()
            with urlopen(Request(stream, headers=headers), timeout=12) as response:
                prefix = response.read(4096).decode('utf-8-sig', errors='replace')
                stream = response.geturl()
            if not prefix.lstrip().startswith('#EXTM3U'):
                continue
            xbmc.log('VIDCORE VidNest: verified HLS from %s' % provider, xbmc.LOGINFO)
            return {'url': stream, 'headers': headers, 'type': 'hls', 'provider': provider}
        except Exception as exc:
            xbmc.log('VIDCORE VidNest: %s failed (%s%s)' % (
                provider, type(exc).__name__,
                ' HTTP %s' % exc.code if hasattr(exc, 'code') else ''), xbmc.LOGWARNING)
    return None
