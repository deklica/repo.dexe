"""Build Simkl actions only for real Vidcore media rows, without API reads."""
import json


def item_meta(identity, label, info=None, metadata=None):
    if identity.get('action') not in ('vidcore_sources', 'vidcore_seasons', 'vidcore_episodes') or 'page' in identity:
        return None
    if identity.get('kind') not in ('movie', 'tv'):
        return None
    info, metadata = info or {}, metadata or {}
    try:
        tmdb_id = int(identity.get('tmdb_id'))
        if tmdb_id <= 0:
            return None
        season = int(identity['season']) if identity.get('season') not in (None, '') else None
        episode = int(identity['episode']) if identity.get('episode') not in (None, '') else None
        if season is not None and season < 0 or episode is not None and (episode < 1 or season is None):
            return None
    except (ValueError, TypeError):
        return None
    content = 'movie' if identity['kind'] == 'movie' else 'episode' if episode is not None else 'show'
    return {'tmdb': str(tmdb_id), 'content': content,
        'title': metadata.get('tvshowtitle') or identity.get('title') or metadata.get('title') or info.get('title') or label,
        'year': metadata.get('year') or info.get('year') or '',
        'season': season if content != 'movie' else None,
        'episode': episode if content != 'movie' else None}


def actions(identity, label, info, metadata, connected, build_url):
    if not connected:
        return []
    meta = item_meta(identity, label, info, metadata)
    if meta is None:
        return []
    scope = ('movie' if meta['content'] == 'movie' else 'episode' if meta['episode'] is not None
             else 'season' if meta['season'] is not None else 'entire show')
    list_scope = 'movie' if meta['content'] == 'movie' else 'show'
    labels = [('Simkl: Add %s to Plan to Watch' % list_scope, 'watchlist'),
              ('Simkl: Mark %s watched' % scope, 'watched'),
              ('Simkl: Mark %s unwatched' % scope, 'unwatched')]
    return [(label, 'RunPlugin(%s)' % build_url(action='simkl_update', operation=operation, payload=json.dumps(meta)))
            for label, operation in labels]
