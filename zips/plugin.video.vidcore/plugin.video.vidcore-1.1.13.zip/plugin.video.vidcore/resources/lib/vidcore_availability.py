"""Bounded media checks for the Vidcore picker; never start playback."""
import re
import time
import threading
from queue import Queue, Empty
from urllib.parse import urljoin, urlsplit
from urllib.request import Request, urlopen
from urllib.error import HTTPError


def _mp4_duration(data):
    """Read a bounded Movie Header atom without downloading the video."""
    start = 0
    while True:
        pos = data.find(b'mvhd', start)
        if pos < 0:
            return None
        start = pos + 4
        if pos < 4:
            continue
        size = int.from_bytes(data[pos - 4:pos], 'big')
        if size < 32 or pos + size - 4 > len(data):
            continue
        version = data[pos + 4]
        offset = pos + (24 if version == 1 else 16)
        if version not in (0, 1):
            continue
        scale = int.from_bytes(data[offset:offset + 4], 'big')
        duration = int.from_bytes(data[offset + 4:offset + (12 if version == 1 else 8)], 'big')
        if scale:
            return duration / scale


def check_stream(source):
    """Check a manifest and media sample using the playback headers/cookies."""
    if not isinstance(source, dict) or source.get('error') or not source.get('url'):
        return None
    from .hdhub import media_type
    from .vidcore_proxy import video_bytes
    try:
        headers = dict(source.get('headers') or {})
        if any(not isinstance(key, str) or not isinstance(value, str)
               for key, value in headers.items()):
            return None
        opener = source.get('opener')
        open_url = opener.open if opener is not None else urlopen
    except (TypeError, ValueError, AttributeError):
        return None

    def read(url, media=False, range_request=True, byte_range=None):
        if urlsplit(url).scheme not in ('http', 'https'):
            raise ValueError('Unsupported media URL')
        request_headers = dict(headers, **{'Accept-Encoding': 'identity'})
        if media and range_request:
            request_headers['Range'] = 'bytes=' + byte_range if byte_range else 'bytes=0-65535'
        try:
            response = open_url(Request(url, headers=request_headers), timeout=8)
        except HTTPError as exc:
            if not media or not range_request or exc.code != 416:
                raise
            # Some valid files/servers reject even a bounded probe range.
            exc.close()
            request_headers.pop('Range', None)
            response = open_url(Request(url, headers=request_headers), timeout=8)
        with response:
            if response.status not in (200, 206):
                raise ValueError('Media unavailable')
            return response.read(65536 if media else 1024 * 1024), response.geturl()

    hls_budget = [12]
    def check_hls(data, base, depth=0):
        nonlocal native_hls
        if depth >= 4 or hls_budget[0] <= 0:
            raise ValueError('HLS playlist limit reached')
        hls_budget[0] -= 1
        if len(data) >= 65536:
            data, base = read(base)
        text = data.decode('utf-8-sig').lstrip()
        if not text.startswith('#EXTM3U'):
            raise ValueError('Invalid HLS playlist')
        urls = [line.strip() for line in text.splitlines()
                if line.strip() and not line.lstrip().startswith('#')]
        if not urls:
            raise ValueError('Empty HLS playlist')
        if '#EXT-X-STREAM-INF:' in text:
            for index, url in enumerate(urls):
                if hls_budget[0] <= 0:
                    break
                hls_budget[0] -= 1
                previous_native_hls = native_hls
                try:
                    child, child_base = read(urljoin(base, url))
                    verified, heights = check_hls(child, child_base, depth + 1)
                    # Keep adaptive playback when the preferred branch works.
                    # After a failure, play the verified branch directly so
                    # Kodi cannot select the same broken variant again.
                    return ((base, hls_heights(text)) if index == 0 and verified == child_base
                            else (verified, heights))
                except (OSError, ValueError, UnicodeError):
                    native_hls = previous_native_hls
                    continue
            raise ValueError('No playable HLS variants')
        if minimum:
            duration = sum(float(value) for value in re.findall(r'#EXTINF:([\d.]+)', text))
            if '#EXT-X-ENDLIST' not in text or duration < minimum:
                raise ValueError('HLS media check failed')
        # Check encryption keys and initialization data as well.
        encrypted = False
        for line in text.splitlines():
            if line.startswith(('#EXT-X-KEY:', '#EXT-X-MAP:')):
                if line.startswith('#EXT-X-KEY:') and 'METHOD=NONE' not in line:
                    if 'METHOD=AES-128' not in line:
                        raise ValueError('HLS media check failed')
                    encrypted = True
                match = re.search(r'URI="([^"]+)"', line)
                if encrypted and line.startswith('#EXT-X-KEY:') and not match:
                    raise ValueError('HLS media check failed')
                if match:
                    sample, _ = read(urljoin(base, match[1]), media=True, range_request=False)
                    if not sample or (line.startswith('#EXT-X-KEY:') and len(sample) != 16):
                        raise ValueError('HLS media check failed')
                    if line.startswith('#EXT-X-MAP:') and not encrypted:
                        from .dulo_resolvers import mp4_handlers
                        handlers = mp4_handlers(sample)
                        if b'vide' in handlers and b'soun' in handlers:
                            native_hls = True
        sample, _ = read(urljoin(base, urls[0]), media=True, range_request=False)
        if not sample or sample.lstrip().lower().startswith(
                (b'<!doctype', b'<html', b'<?xml', b'{"error', b'#extm3u')):
            raise ValueError('HLS media check failed')
        if not encrypted:
            sample = video_bytes(sample)
            ts = len(sample) > 376 and all(sample[i * 188] == 0x47 for i in range(3))
            mp4 = len(sample) > 8 and sample[4:8] in (
                b'ftyp', b'styp', b'moof', b'sidx', b'mdat', b'emsg')
            aac = sample.startswith(b'ID3') or (
                len(sample) > 2 and sample[0] == 255 and sample[1] & 246 == 240)
            if not (ts or mp4 or aac):
                raise ValueError('HLS media check failed')
        return base, []

    try:
        manifest = str(source.get('type') or '').lower() in ('hls', 'dash') or '.m3u8' in source['url'].lower()
        data, base = read(source['url'], media=not manifest)
        stream_type = media_type(data)
        if not stream_type:
            return None
        from .source_quality import hls_heights, mp4_height
        quality_heights = []
        quality_origin = ''
        native_hls = bool(source.get('native_hls'))
        if stream_type != 'hls':
            height = mp4_height(data)
            if height:
                quality_heights, quality_origin = [height], 'container'
        minimum = float(source.get('minimum_duration') or 0)
        if minimum and stream_type not in ('hls', 'dash'):
            duration = _mp4_duration(data)
            if duration is None:
                # MP4 metadata commonly lives at the end of the file.
                request_headers = dict(headers, **{'Range': 'bytes=-262144', 'Accept-Encoding': 'identity'})
                with open_url(Request(base, headers=request_headers), timeout=8) as response:
                    duration = _mp4_duration(response.read(262144))
            if duration is None or duration < minimum:
                return None
        if stream_type == 'hls':
            verified_url, quality_heights = check_hls(data, base)
            if verified_url != base:
                source = dict(source, url=verified_url)
            if quality_heights:
                quality_origin = 'manifest'
        elif stream_type == 'dash':
            from .dash_check import check as check_dash
            if not check_dash(data, base, read, minimum):
                return None
        # Keep original signed URLs and any provider-specific relay options.
        result = dict(source, type=stream_type, _checked_at=time.monotonic())
        if native_hls and stream_type == 'hls':
            result['native_hls'] = True
        # Recompute metadata on every verification; never retain stale hints.
        result.pop('quality_heights', None)
        result.pop('quality_origin', None)
        if quality_heights:
            result.update(quality_heights=quality_heights, quality_origin=quality_origin)
        return result
    except Exception as exc:
        from . import debug_bundle
        debug_bundle.log('STREAM CHECK ERROR', '%s %s: %s' % (source.get('url', ''), type(exc).__name__, exc))
        return None


def selected_source(source, provider='', refresh_source=''):
    """Recheck links left in an open picker; renew supported expired links."""
    if not isinstance(source, dict):
        return None
    try:
        age = time.monotonic() - float(source.get('_checked_at', 0))
        if '_checked_at' in source and 0 <= age < 60:
            return source
    except (ValueError, TypeError, OverflowError):
        pass
    checked = check_stream(source)
    if checked:
        return checked
    try:
        if provider.casefold() == 'vidbolt' and refresh_source:
            from . import vidbolt
            fresh = vidbolt.resolve(refresh_source, backend=source.get('vidbolt_backend', ''))
        elif isinstance(source.get('rivestream_refresh'), dict):
            from . import rivestream
            fresh = rivestream.resolve_server(**source['rivestream_refresh'])
        else:
            return None
        return check_stream(fresh)
    except Exception:
        return None


def discover_sources(jobs, progress, monitor, timeout=30):
    """Bound the entire lookup stage, including multi-request resolvers.

    Workers return data only; Kodi controls and cancellation stay on the caller.
    A slow DNS lookup or drip-feeding server cannot block opening the picker.
    """
    completed = Queue()
    stop = threading.Event()
    results = {}
    deadline = time.monotonic() + timeout
    try:
        import xbmc
        callbacks = getattr(xbmc, 'sleep', lambda ms: None)
    except ImportError:
        callbacks = lambda ms: None

    def worker(key, lookup):
        try:
            value = lookup()
        except Exception:
            value = None
        if not stop.is_set():
            completed.put((key, value))

    for key, lookup in jobs:
        threading.Thread(target=worker, args=(key, lookup),
                         name='vidcore-discover-' + str(key), daemon=True).start()
    count = 0
    try:
        while count < len(jobs) and time.monotonic() < deadline:
            callbacks(10)
            if monitor.abortRequested() or progress.iscanceled():
                return None
            try:
                key, value = completed.get(timeout=min(.05, max(0, deadline - time.monotonic())))
            except Empty:
                continue
            count += 1
            if value is not None:
                results[key] = value
            if hasattr(progress, 'update_discovery'):
                progress.update_discovery(count, len(jobs))
            else:
                progress.update(int(100 * count / max(1, len(jobs))),
                                'Discovering providers... %d of %d complete' % (count, len(jobs)))
        # Preserve results queued immediately before the deadline.
        while True:
            try:
                key, value = completed.get_nowait()
            except Empty:
                break
            if value is not None:
                results[key] = value
        return results
    finally:
        stop.set()


def _same_stream(left, right):
    """Compare exact media URLs and request/playback state, ignoring labels."""
    fields = ('url', 'type', 'native_hls', 'refresh_tokens',
              'vidbolt_backend', 'rivestream_refresh')
    if any(left.get(field) != right.get(field) for field in fields):
        return False
    # Cookie jars and custom decrypting openers must retain their own state.
    if left.get('opener') is not right.get('opener'):
        return False
    def headers(source):
        return {key.lower(): value for key, value in
                (source.get('headers') or {}).items()}
    return headers(left) == headers(right)


def check_sources(jobs, progress, monitor, timeout=60, idle_timeout=None, on_ready=None, source_cache=None):
    """Return checked links promptly, without joining stalled network workers."""
    work, completed = Queue(), Queue()
    stop = threading.Event()
    results = {}
    successful_keys = set()
    total = len(jobs)
    count = 0
    started = time.monotonic()
    deadline = started + timeout
    try:
        import xbmc
        service_callbacks = getattr(xbmc, 'sleep', lambda milliseconds: None)
    except ImportError:
        service_callbacks = lambda milliseconds: None

    if source_cache is not None:
        jobs = sorted(jobs, key=source_cache.rank)
    # Start one job per provider before filling slots with its other servers.
    # Otherwise a slow provider's server list can occupy every worker.
    families = {}
    for key, resolve in jobs:
        family = key[0] if isinstance(key, tuple) else key
        if family in ('Nova', 'Atlas', 'Astra'):
            family = 'AdRock'
        if isinstance(family, str) and family.startswith('RiveEmbed:'):
            family = 'RiveStream'
        families.setdefault(family, []).append((key, resolve))
    jobs = [rows[index] for index in range(max((len(rows) for rows in families.values()), default=0))
            for rows in families.values() if index < len(rows)]
    for job in jobs:
        work.put(job)

    def worker():
        while not stop.is_set():
            try:
                key, resolve = work.get_nowait()
            except Empty:
                return
            resolved = None
            job_started = time.monotonic()
            try:
                cached = source_cache.stream(key) if source_cache is not None else None
                resolved = check_stream(cached) if cached else None
                source = None if resolved else resolve()
                if isinstance(source, dict) and 'discovered_sources' in source:
                    candidates = iter(source['discovered_sources'] or [])
                    index = 0
                    while not stop.is_set():
                        try:
                            row = next(candidates)
                        except StopIteration:
                            break
                        if not isinstance(row, dict):
                            continue
                        row = dict(row)
                        child_key = row.pop('_source_key', (key, index))
                        index += 1
                        checked = check_stream(row)
                        if checked and not stop.is_set():
                            completed.put((child_key, checked, time.monotonic() - job_started, True))
                    source = None
                if not stop.is_set() and resolved is None:
                    resolved = check_stream(source)
            except Exception:
                from . import debug_bundle
                if debug_bundle.is_enabled():
                    debug_bundle.error('Source lookup', str(key))
            if not stop.is_set():
                completed.put((key, resolved, time.monotonic() - job_started, False))

    def accept(entry):
        nonlocal count
        key, resolved, elapsed, child = entry
        from . import debug_bundle
        debug_bundle.log('SOURCE CHECK', 'source=%s result=%s elapsed=%.2fs' % (
            key, 'available' if resolved else 'unavailable', elapsed))
        if not child:
            count += 1
        if resolved:
            successful_keys.add(key)
            if not any(other_key != key and _same_stream(resolved, other)
                       for other_key, other in results.items()):
                results[key] = resolved
            if source_cache is not None:
                source_cache.success(key, resolved)
        if source_cache is not None and not child:
            group_success = isinstance(key, str) and any(
                isinstance(found, tuple) and found[0] == key for found in successful_keys)
            if isinstance(key, str) and key.startswith('RiveEmbed:'):
                group_success = any(isinstance(found, tuple) and
                                    found[:3] == ('RiveStream', 'embed', key.partition(':')[2])
                                    for found in successful_keys)
            source_cache.record(key, bool(resolved) or group_success, elapsed)

    def snapshot():
        # Invoked by the picker on the Kodi thread; no worker touches controls.
        while True:
            try:
                accept(completed.get_nowait())
            except Empty:
                break
        active = count < total and time.monotonic() < deadline and not monitor.abortRequested()
        if not active:
            stop.set()
        return dict(results), count, total, active

    try:
        # Daemon workers cannot hold up the picker or Python shutdown. They
        # never touch Kodi controls and discard results after this scan ends.
        for index in range(min(12, total)):
            threading.Thread(target=worker, name='cosmos-source-check-%d' % index,
                             daemon=True).start()
        while count < total and time.monotonic() < deadline:
            # Kodi dispatches WindowXML callbacks while xbmc.sleep runs.
            # Queue.get alone leaves Cancel clicks pending in the invoker.
            service_callbacks(10)
            if monitor.abortRequested():
                return None
            if progress.iscanceled():
                # Keep successes already produced by workers, including any
                # queued since the last UI update. Never wait for more work.
                stop.set()
                while True:
                    try:
                        entry = completed.get_nowait()
                    except Empty:
                        break
                    accept(entry)
                return results
            try:
                entry = completed.get(timeout=0.1)
            except Empty:
                pass
            else:
                accept(entry)
            if hasattr(progress, 'update_sources'):
                progress.update_sources(count, total, len(results))
            else:
                progress.update(int(100 * count / max(1, total)),
                                'Checked %d of %d sources; %d available' %
                                (count, total, len(results)))
            # Publish the successful count before the picker closes progress.
            if results and on_ready is not None:
                on_ready(snapshot)
                return snapshot()[0]
        return snapshot()[0]
    finally:
        stop.set()
