"""Bounded TMDB response cache shared by Kodi plugin invocations."""
import hashlib
import json
import os
import sqlite3
import time


def _connect(root):
    os.makedirs(root, exist_ok=True)
    connection = sqlite3.connect(os.path.join(root, 'responses.sqlite3'), timeout=2)
    connection.execute('CREATE TABLE IF NOT EXISTS responses '
                       '(key TEXT PRIMARY KEY, saved REAL, expires REAL, body TEXT)')
    connection.execute('CREATE TABLE IF NOT EXISTS cache_state '
                       '(id INTEGER PRIMARY KEY, generation INTEGER NOT NULL)')
    return connection


def _generation(connection):
    row = connection.execute('SELECT generation FROM cache_state WHERE id=1').fetchone()
    return row[0] if row else 0


def generation(root):
    connection = _connect(root)
    try:
        return _generation(connection)
    finally:
        connection.close()


def clear(root):
    """Invalidate old writers atomically, keeping the generation across clears."""
    connection = _connect(root)
    try:
        with connection:
            connection.execute('BEGIN IMMEDIATE')
            next_generation = _generation(connection) + 1
            connection.execute('INSERT OR REPLACE INTO cache_state VALUES (1, ?)',
                               (next_generation,))
            connection.execute('DELETE FROM responses')
        connection.execute('VACUUM')
    finally:
        connection.close()


def get(root, url, stale=False):
    connection = None
    try:
        connection = _connect(root)
        row = connection.execute('SELECT saved, expires, body FROM responses WHERE key=?',
                                 (hashlib.sha256(url.encode()).hexdigest(),)).fetchone()
        now = time.time()
        if row and row[0] <= now and (row[1] > now or stale and now - row[0] < 7 * 86400):
            return json.loads(row[2])
    except (OSError, sqlite3.Error, ValueError):
        pass
    finally:
        if connection is not None:
            connection.close()
    return None


def put(root, url, value, ttl, generation=None):
    connection = None
    try:
        body = json.dumps(value, ensure_ascii=False)
        if len(body.encode('utf-8')) > 2 * 1024 * 1024:
            return
        connection = _connect(root)
        now = time.time()
        with connection:
            connection.execute('BEGIN IMMEDIATE')
            if generation is not None and generation != _generation(connection):
                return
            connection.execute('INSERT OR REPLACE INTO responses VALUES (?, ?, ?, ?)',
                               (hashlib.sha256(url.encode()).hexdigest(), now, now + ttl, body))
            connection.execute('DELETE FROM responses WHERE saved < ?', (now - 7 * 86400,))
            # Cap response payloads at 20 MB, dropping oldest entries first.
            total = connection.execute('SELECT COALESCE(SUM(length(CAST(body AS BLOB))),0) FROM responses').fetchone()[0]
            if total > 20 * 1024 * 1024:
                for key, size in connection.execute('SELECT key, length(CAST(body AS BLOB)) FROM responses ORDER BY saved').fetchall():
                    connection.execute('DELETE FROM responses WHERE key=?', (key,))
                    total -= size
                    if total <= 20 * 1024 * 1024:
                        break
        if os.path.getsize(os.path.join(root, 'responses.sqlite3')) > 30 * 1024 * 1024:
            connection.execute('VACUUM')
    except (OSError, sqlite3.Error, ValueError, TypeError):
        pass
    finally:
        if connection is not None:
            connection.close()
