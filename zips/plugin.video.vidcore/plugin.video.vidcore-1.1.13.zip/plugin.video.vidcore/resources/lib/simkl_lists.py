"""Lazy, account-scoped Simkl custom list browsing with persistent page caches."""
import xbmc
import xbmcgui
import xbmcplugin
from . import simkl, tmdb

PAGE_SIZE = 20
MAX_PAGE = 10000 // PAGE_SIZE


def page_number(value):
    try:
        return max(1, min(MAX_PAGE, int(value)))
    except (TypeError, ValueError):
        return 1


def profile():
    data, _ok = simkl._sync_snapshot(resource=lambda activity: (
        '/users/settings', {}, (activity.get('settings') or {}).get('all')))
    if not isinstance(data, dict) or data.get('error'):
        raise ValueError('Account information unavailable; try Sync Simkl later')
    account, user = data.get('account') or {}, data.get('user') or {}
    tier = str(account.get('type') or '').lower()
    if tier not in ('pro', 'vip'):
        raise ValueError('Simkl custom lists require a PRO or VIP account')
    user_id = account.get('id') or user.get('id') or user.get('user_id')
    if not str(user_id).isdigit():
        raise ValueError('Could not identify your Simkl account')
    return str(user_id), tier


def index(user_id, tier, page):
    data, _ok = simkl._sync_snapshot(resource=lambda activity: (
        '/lists/user/' + user_id,
        {'page': page, 'limit': PAGE_SIZE, 'sort': 'name', 'direction': 'asc',
         'followed': 'true', 'collaborants': 'true'},
        [tier, ((activity.get('custom_lists') or {}).get('lists') or {}).get('all')]))
    return checked(data, 'lists')


def checked(data, field):
    if not isinstance(data, dict):
        raise ValueError('Lists unavailable; saved data retained — try Sync Simkl later')
    if data.get('error'):
        if data['error'] == 'premium_only':
            raise ValueError('Simkl custom lists require a PRO or VIP account')
        if data['error'] == 'oauth2_token_required':
            raise ValueError('Reconnect Simkl to authorize access to custom lists')
        raise ValueError('Simkl list access is currently unavailable')
    if not isinstance(data.get(field), list):
        raise ValueError('Simkl returned an unexpected list response')
    return data


def menu(action, params, handle, add_directory, build_url):
    if not simkl.has_token():
        xbmcgui.Dialog().notification('Simkl My Lists', 'Authorize Simkl first')
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return
    page = page_number(params.get('page', 1))
    try:
        user_id, tier = profile()
        if action == 'simkl_custom_lists':
            data = index(user_id, tier, page)
            for item in data['lists']:
                if not isinstance(item, dict) or not str(item.get('id')).isdigit():
                    continue
                name = item.get('name') or 'Untitled list'
                count = (item.get('counts') or {}).get('items')
                label = '%s (%s)' % (name, count) if count is not None else name
                description = item.get('description') or {}
                plot = (description.get('full') or description.get('short') or '') if isinstance(description, dict) else str(description)
                add_directory(label, build_url(action='simkl_custom_items', list_id=str(item['id']), index_page=str(page)),
                    info={'title': name, 'plot': plot}, is_folder=True)
            values = {}
        else:
            index_page = page_number(params.get('index_page', 1))
            discovered = index(user_id, tier, index_page)
            list_id = str(params.get('list_id') or '')
            selected = next((item for item in discovered['lists'] if str(item.get('id')) == list_id), None)
            if not selected or not list_id.isdigit():
                raise ValueError('List index changed or access removed; reopen My Lists')
            auto = selected.get('type') in ('auto', 'automatic')
            data, _ok = simkl._sync_snapshot(resource=lambda _activity: (
                '/lists/' + list_id, {'page': page, 'limit': PAGE_SIZE, 'extended': 'full'},
                [tier, selected.get('updated_at')]), resource_ttl=86400 if auto else None)
            data = checked(data, 'items')
            media_type = data.get('media_type') or selected.get('media_type') or 'movies'
            for item in data['items']:
                if not isinstance(item, dict):
                    continue
                kind = 'movie' if media_type == 'movies' or item.get('type') == 'movie' else 'tv'
                ids = item.get('ids') or {}
                tmdb_id = ids.get('tmdb')
                if not tmdb_id and ids.get('imdb'):
                    tmdb_id = tmdb.find_by_imdb_id(ids['imdb'], 'movie' if kind == 'movie' else 'tvshow')
                title = item.get('title') or 'Untitled'
                if not tmdb_id:
                    add_directory(title + ' (no TMDB match)', build_url(action='simkl_next_info', reason='No playable TMDB match for this title'), is_folder=False)
                    continue
                content = 'movie' if kind == 'movie' else 'tvshow'
                try:
                    metadata = dict(tmdb.get_metadata(str(tmdb_id), content) or {})
                except Exception as exc:
                    xbmc.log('VIDCORE Simkl list metadata: ' + type(exc).__name__, xbmc.LOGWARNING)
                    metadata = {}
                metadata.update({'content': content, 'tmdb_id': str(tmdb_id)})
                metadata['title'] = metadata.get('title') or title
                metadata['plot'] = metadata.get('plot') or item.get('overview') or ''
                url = build_url(action='vidcore_sources' if kind == 'movie' else 'vidcore_seasons', kind=kind,
                    tmdb_id=str(tmdb_id), title=metadata['title'])
                add_directory(metadata['title'], url, metadata=metadata, is_folder=kind != 'movie', is_playable=kind == 'movie')
            values = {'list_id': list_id, 'index_page': str(index_page)}
        pagination = data.get('pagination') or {}
        current = page_number(pagination.get('page', page))
        total = page_number(pagination.get('total_pages', 1))
        if current > 1:
            add_directory('Previous page (%s of %s)' % (current - 1, total), build_url(action=action, page=str(current - 1), **values))
        if current < total:
            add_directory('Next page (%s of %s)' % (current + 1, total), build_url(action=action, page=str(current + 1), **values))
        if not data.get('lists' if action == 'simkl_custom_lists' else 'items'):
            add_directory('No lists found' if action == 'simkl_custom_lists' else 'This list is empty', build_url(action='simkl_root'))
        xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
    except (ValueError, TypeError, OSError) as exc:
        xbmcgui.Dialog().notification('Simkl My Lists', str(exc))
        xbmcplugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)
