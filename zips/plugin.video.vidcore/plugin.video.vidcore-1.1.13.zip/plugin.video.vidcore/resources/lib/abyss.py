"""Abyss MP4 configuration decoder and range-preserving playback relay."""
import base64
import hashlib
import json
import re
import secrets
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlencode, urlsplit
from urllib.request import Request, urlopen
from urllib.error import HTTPError

from .aesgcm import AES

BASE = 'https://primesrc.me'
PLAYER = 'https://player.abyssplayer.com'
HEADERS = {'User-Agent': 'Mozilla/5.0', 'Referer': PLAYER + '/', 'Origin': PLAYER}
PREFIX_SIZE = 65536


class ProviderChallenge(ValueError):
    """The provider returned a browser challenge instead of API data."""


def crypt(data, seed, offset=0):
    """Abyss uses ASCII MD5 as AES-256 key and its first 16 bytes as counter."""
    key = hashlib.md5(str(seed).encode('utf-8')).hexdigest().encode('ascii')
    aes = AES(key)
    counter = int.from_bytes(key[:16], 'big') + offset // 16
    skip = offset % 16
    result = bytearray()
    while len(result) < len(data):
        pad = aes.encrypt_block(counter.to_bytes(16, 'big'))[skip:]
        part = data[len(result):len(result) + len(pad)]
        result.extend(x ^ y for x, y in zip(part, pad))
        counter += 1
        skip = 0
    return bytes(result)


def _http(value):
    if not isinstance(value, str) or any(ord(c) < 33 for c in value):
        return False
    try:
        p = urlsplit(value)
        return p.scheme == 'https' and bool(p.hostname) and not p.username and not p.password
    except ValueError:
        return False


def _read(url, headers, limit=2 * 1024 * 1024):
    try:
        response = urlopen(Request(url, headers=headers), timeout=8)
    except HTTPError as exc:
        if exc.code == 403:
            body = exc.read(16384).lower()
            challenged = (exc.headers.get('cf-mitigated') == 'challenge'
                          or b'<title>just a moment' in body)
            if challenged:
                exc.close()
                raise ProviderChallenge('Provider requires browser verification') from exc
        raise
    with response:
        data = response.read(limit + 1)
    if len(data) > limit:
        raise ValueError('Oversized Abyss response')
    return data


def decode_config(body):
    match = re.search(r'\b(?:const|let|var)\s+datas\s*=\s*["\']([A-Za-z0-9+/=]+)', body)
    if not match:
        raise ValueError('Abyss configuration missing')
    # atob returns a binary JS string, including Latin-1 encrypted bytes.
    data = json.loads(base64.b64decode(match[1]).decode('latin1'))
    seed = '%s:%s:%s' % (data['user_id'], data['slug'], data['md5_id'])
    if isinstance(data.get('media'), str):
        data['media'] = json.loads(crypt(data['media'].encode('latin1'), seed))
    return data


def _range(value, size):
    if not value:
        return 0, size - 1
    match = re.fullmatch(r'bytes=(\d*)-(\d*)', value.strip())
    if not match or not any(match.groups()):
        raise ValueError('Invalid range')
    first, last = match.groups()
    start = int(first) if first else max(0, size - int(last))
    end = min(size - 1, int(last)) if first and last else size - 1
    if start < 0 or start >= size or end < start:
        raise ValueError('Unsatisfiable range')
    return start, end


class _Response:
    def __init__(self, raw, start, prefix):
        self.raw, self.position, self.prefix = raw, start, prefix
        self.status, self.headers = raw.status, raw.headers

    def read(self, size=-1):
        data = self.raw.read(size)
        count = min(len(data), max(0, len(self.prefix) - self.position))
        if count:
            data = self.prefix[self.position:self.position + count] + data[count:]
        self.position += len(data)
        return data

    def geturl(self):
        return self.raw.geturl()

    def close(self):
        self.raw.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()


class Media:
    """Decrypt only the first 64 KiB; later MP4 bytes remain unmodified."""
    def __init__(self, url, size):
        self.url, self.size = url, int(size)
        headers = dict(HEADERS, Range='bytes=0-%d' % (PREFIX_SIZE - 1))
        with urlopen(Request(url, headers=headers), timeout=8) as response:
            data = response.read(PREFIX_SIZE)
            content_range = response.headers.get('Content-Range', '')
            if (response.status != 206 or not content_range.startswith('bytes 0-')
                    or not content_range.endswith('/%d' % self.size)
                    or len(data) < min(PREFIX_SIZE, self.size)):
                raise ValueError('Abyss CDN does not support byte ranges')
        self.prefix = crypt(data, urlsplit(url).path.rsplit('/', 1)[-1])
        if self.prefix[4:8] != b'ftyp' or b'moov' not in self.prefix:
            raise ValueError('Abyss decryption did not produce an MP4 header')

    def open(self, request, timeout=8):
        if request.full_url != self.url:
            raise ValueError('Unexpected Abyss media URL')
        headers = dict(HEADERS)
        wanted = request.get_header('Range')
        start, end = _range(wanted, self.size)
        if wanted:
            headers['Range'] = 'bytes=%d-%d' % (start, end)
        raw = urlopen(Request(self.url, headers=headers), timeout=min(timeout, 8))
        expected = 'bytes %d-' % start
        if wanted and (raw.status != 206 or not raw.headers.get('Content-Range', '').startswith(expected)):
            raw.close()
            raise ValueError('Abyss CDN returned the wrong byte range')
        return _Response(raw, start, self.prefix)

    def start_relay(self):
        return Relay(self)


class Relay:
    def __init__(self, media):
        owner = self
        self.last_request = time.monotonic()
        path = '/' + secrets.token_urlsafe(24) + '.mp4'

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *_args):
                pass

            def do_HEAD(self):
                self.serve(True)

            def do_GET(self):
                self.serve(False)

            def serve(self, head_only):
                if self.path != path:
                    self.send_error(404)
                    return
                try:
                    start, end = _range(self.headers.get('Range'), media.size)
                except ValueError:
                    self.send_response(416)
                    self.send_header('Content-Range', 'bytes */%d' % media.size)
                    self.end_headers()
                    return
                owner.last_request = time.monotonic()
                length = end - start + 1
                response = None
                sent = False
                retries = 0
                try:
                    if not head_only:
                        response = media.open(Request(media.url, headers={'Range': 'bytes=%d-%d' % (start, end)}))
                    self.send_response(206 if self.headers.get('Range') else 200)
                    self.send_header('Content-Type', 'video/mp4')
                    self.send_header('Accept-Ranges', 'bytes')
                    self.send_header('Content-Length', str(length))
                    if self.headers.get('Range'):
                        self.send_header('Content-Range', 'bytes %d-%d/%d' % (start, end, media.size))
                    self.end_headers()
                    sent = True
                    while response is not None and length > 0:
                        try:
                            data = response.read(min(length, 256 * 1024))
                            if not data:
                                raise OSError('Truncated Abyss media')
                        except OSError:
                            if retries >= 2:
                                raise
                            retries += 1
                            response.close()
                            offset = end - length + 1
                            response = media.open(Request(media.url, headers={'Range': 'bytes=%d-%d' % (offset, end)}))
                            continue
                        self.wfile.write(data)
                        length -= len(data)
                        owner.last_request = time.monotonic()
                except (OSError, ValueError) as exc:
                    try:
                        import xbmc
                        xbmc.log('VIDCORE Abyss relay failed (%s%s)' % (
                            type(exc).__name__, ' HTTP %s' % exc.code if hasattr(exc, 'code') else ''), xbmc.LOGWARNING)
                    except ImportError:
                        pass
                    if not sent:
                        self.send_error(502, 'Abyss media unavailable')
                    self.close_connection = True
                finally:
                    if response:
                        response.close()

        self.server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        self.server.daemon_threads = True
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.url = 'http://127.0.0.1:%d%s' % (self.server.server_address[1], path)

    def close(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=1)

    def keep_alive(self):
        import xbmc
        monitor, player = xbmc.Monitor(), xbmc.Player()
        try:
            while not monitor.waitForAbort(1):
                if time.monotonic() - self.last_request > 30 and not player.isPlayingVideo():
                    break
        finally:
            self.close()


def resolve_player(url):
    """Resolve a fresh Abyss player URL; no relay starts during discovery."""
    if not _http(url) or urlsplit(url).hostname != 'player.abyssplayer.com':
        return None
    data = decode_config(_read(url, dict(HEADERS, Referer=BASE + '/')).decode('utf-8'))
    if data.get('slug') != urlsplit(url).path.strip('/'):
        return None
    rows = data.get('media', {}).get('mp4', {}).get('sources', [])
    # Multipart and service-worker-only sources require a different transport.
    rows = [r for r in rows if isinstance(r, dict) and r.get('path')
            and _http(r.get('url')) and not r.get('partSize') and r.get('codec') == 'h264']
    for row in sorted(rows, key=lambda r: int(r.get('res_id') or 0), reverse=True):
        url = row['url'].rstrip('/') + '/' + row['path'].lstrip('/')
        if not _http(url):
            continue
        try:
            media = Media(url, row['size'])
            return {'url': url, 'type': 'mp4', 'headers': dict(HEADERS), 'opener': media,
                    'label': 'Abyss / ' + str(row.get('label') or 'MP4')}
        except (OSError, ValueError, KeyError):
            continue
    return None


def _cache_root(root):
    if root is not None:
        return root
    try:
        import xbmcvfs
        return xbmcvfs.translatePath('special://profile/addon_data/plugin.video.vidcore/metadata_cache')
    except ImportError:
        return None


def _hint_key(tmdb_id, kind, season, episode):
    return 'abyss:player:v1:' + json.dumps([kind, str(tmdb_id), int(season), int(episode)])


def remember_player(tmdb_id, kind, season, episode, url, root=None):
    """Remember an inspected player for this exact title/episode, not media tokens."""
    root = _cache_root(root)
    if root and _http(url) and urlsplit(url).hostname == 'player.abyssplayer.com':
        from . import metadata_cache
        metadata_cache.put(root, _hint_key(tmdb_id, kind, season, episode), url, 86400)


def resolve(tmdb_id, kind='movie', season=0, episode=0):
    identifier = str(tmdb_id)
    if not identifier.isascii() or not identifier.isdigit() or int(identifier) < 1 or kind not in ('movie', 'tv'):
        return None
    params = {'tmdb': identifier, 'type': kind}
    try:
        if kind == 'tv':
            season, episode = int(season), int(episode)
            if season < 0 or episode < 1:
                return None
            params.update(season=season, episode=episode)
        root = _cache_root(None)
        if root:
            from . import metadata_cache
            hint = metadata_cache.get(root, _hint_key(tmdb_id, kind, season, episode))
            if hint:
                try:
                    resolved = resolve_player(hint)
                    if resolved:
                        return resolved
                except (OSError, ValueError, KeyError, TypeError):
                    pass
        referer = BASE + '/embed/' + kind + '?' + urlencode(params)
        headers = dict(HEADERS, Referer=referer, Origin=BASE, Accept='application/json')
        data = json.loads(_read(BASE + '/api/v1/s?' + urlencode(params), headers))
        info = data.get('info') or {}
        if kind == 'tv':
            entry = info.get('episode') or {}
            if int(entry.get('season', -1)) != season or int(entry.get('episode', -1)) != episode:
                return None
        for row in data.get('servers') or []:
            if not isinstance(row, dict) or str(row.get('name', '')).casefold() != 'abyss':
                continue
            try:
                result = json.loads(_read(BASE + '/api/v1/l?' + urlencode({'key': row['key']}), headers))
                if _http(result.get('link')):
                    resolved = resolve_player(result['link'])
                    if resolved:
                        remember_player(tmdb_id, kind, season, episode, result['link'])
                        return resolved
            except ProviderChallenge:
                # This is a site-wide browser gate; more link requests cannot fix it.
                raise
            except (OSError, ValueError, KeyError, TypeError):
                # One expired/unreachable file must not hide another Abyss file.
                continue
    except (OSError, ValueError, KeyError, TypeError) as exc:
        try:
            import xbmc
            xbmc.log('VIDCORE RiveStream Abyss discovery failed (%s%s)' % (
                type(exc).__name__, ' HTTP %s' % exc.code if hasattr(exc, 'code') else ''),
                xbmc.LOGWARNING)
            if isinstance(exc, ProviderChallenge):
                xbmc.log('VIDCORE Abyss: PrimeSrc requires browser verification; choose another source.',
                         xbmc.LOGWARNING)
        except ImportError:
            pass
        return None
    return None
