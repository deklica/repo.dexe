"""Simkl menus using Vidcore's existing movie and episode routes."""
import json
from datetime import datetime, timezone
import xbmc
import xbmcgui
import xbmcplugin
from . import simkl, tmdb

PAGE_SIZE = 20


def watched_time(entry):
    values = [entry.get('last_watched_at'), entry.get('watched_at')]
    for season in entry.get('seasons') or []:
        values.extend(episode.get('watched_at') for episode in season.get('episodes') or [])
    timestamps = []
    for value in values:
        try:
            parsed = datetime.fromisoformat(str(value).replace('Z', '+00:00'))
            if parsed.tzinfo is None:
                parsed = parsed.replace(tzinfo=timezone.utc)
            timestamps.append(parsed.timestamp())
        except (TypeError, ValueError, OverflowError, OSError):
            pass
    return max(timestamps, default=float('-inf'))


def page_rows(rows, requested):
    pages = max(1, (len(rows) + PAGE_SIZE - 1) // PAGE_SIZE)
    try:
        page = max(1, min(pages, int(requested)))
    except (TypeError, ValueError):
        page = 1
    start = (page - 1) * PAGE_SIZE
    return rows[start:start + PAGE_SIZE], page, pages


def run(action, params, handle, add_directory, build_url):
    if action in ('simkl_custom_lists', 'simkl_custom_items'):
        from . import simkl_lists
        simkl_lists.menu(action, params, handle, add_directory, build_url)
        return
    if action == 'simkl_next_info':
        xbmcgui.Dialog().ok('Simkl Next Episodes', params.get('reason', 'Episode unavailable'))
        return
    if action == 'simkl_next_episodes':
        from . import simkl_next
        simkl_next.menu(params, handle, add_directory, build_url)
        return
    def row(label, target, folder=True, metadata=None, **values):
        options = {'is_folder': folder, 'is_playable': target == 'vidcore_sources'}
        if metadata:
            options['metadata'] = metadata
        add_directory(label, build_url(action=target, **values), **options)

    if action == 'simkl_auth':
        if simkl.authorize():
            xbmc.executebuiltin('Container.Refresh')
        return
    if action == 'simkl_revoke':
        simkl.revoke()
        xbmc.executebuiltin('Container.Refresh')
        return
    if action == 'simkl_update':
        if not simkl.is_authorized():
            xbmcgui.Dialog().notification('Simkl', 'Authorize Simkl first')
            return
        from . import simkl_context
        try:
            supplied = json.loads(params['payload'])
            meta = simkl_context.item_meta({'action': 'vidcore_sources',
                'kind': 'movie' if supplied.get('content') == 'movie' else 'tv',
                'tmdb_id': supplied.get('tmdb'), 'season': supplied.get('season'),
                'episode': supplied.get('episode'), 'title': supplied.get('title')}, supplied.get('title'),
                info={'year': supplied.get('year')})
        except (ValueError, TypeError, KeyError, AttributeError):
            meta = None
        operation = params.get('operation')
        if meta is None or operation not in ('watchlist', 'watched', 'unwatched'):
            xbmcgui.Dialog().notification('Simkl', 'Invalid media action')
            return
        if operation == 'unwatched' and meta['content'] == 'show' and meta['season'] is None:
            meta['seasons'] = tmdb.get_tv_seasons(meta['tmdb'])
            if not meta['seasons']:
                xbmcgui.Dialog().notification('Simkl', 'Cannot load seasons to mark this show unwatched')
                return
        if operation == 'watchlist':
            media = simkl._build_item_payload(meta.get('title'), meta.get('year'), meta.get('tmdb'), content='movie' if meta['content'] == 'movie' else 'show')
            key = 'movies' if meta.get('content') == 'movie' else 'shows'
            status, data, _ = simkl._http_json('/sync/add-to-list', method='POST',
                payload={key: [dict(media, to='plantowatch')]}, headers=simkl._auth_headers())
            ok = simkl._sync_result_ok(status, data)
        else:
            ok = (simkl.remove_from_history(meta) if operation == 'unwatched' else simkl.add_to_history(meta))
        success = {'watchlist': 'Added to Plan to Watch', 'watched': 'Marked watched', 'unwatched': 'Marked unwatched'}
        xbmcgui.Dialog().notification('Simkl', success[operation] if ok else 'Update failed; check Kodi log')
        if ok:
            xbmc.executebuiltin('Container.Refresh')
        return
    if action == 'simkl_sync':
        if not simkl.has_token():
            xbmcgui.Dialog().notification('Sync Simkl', 'Authorize Simkl first')
            return
        dialog = xbmcgui.Dialog()
        dialog.notification('Sync Simkl', 'Syncing — checking for new content…', time=2500, sound=False)
        result = {}
        def progress(stage, detail):
            if stage == 'complete':
                result.update(detail)
            elif stage == 'deferred':
                result['deferred'] = True
            elif stage == 'lists_changed':
                result['lists_changed'] = True
            elif stage in ('initial', 'updating', 'removing'):
                message = {'initial': 'Downloading your library…',
                           'updating': 'Updating new content and watched history…',
                           'removing': 'Updating removed content…'}[stage]
                dialog.notification('Sync Simkl', message, time=2500, sound=False)
        _data, ok = simkl._sync_snapshot(force=True, on_progress=progress, refresh_resources=True)
        if ok:
            if any(result.get(key, 0) for key in ('added', 'updated', 'removed')):
                message = 'Synced: %s added, %s updated, %s removed titles' % (
                    result.get('added', 0), result.get('updated', 0), result.get('removed', 0))
            elif result.get('lists_changed'):
                message = 'Synced — list updates will load when opened'
            else:
                message = 'Up to date — no new content or history changes'
        else:
            message = 'Sync deferred — try again later' if result.get('deferred') else 'Sync failed — saved content retained'
        dialog.notification('Sync Simkl', message, time=5000, sound=False)
        return
    if action == 'simkl_root':
        connected = simkl.has_token()
        if not connected:
            row('[COLOR green]Authorize Simkl[/COLOR]', 'simkl_auth', False)
        if connected:
            row('Next Episodes', 'simkl_next_episodes')
            row('Watching', 'simkl_list', status='watching')
            row('Plan to Watch', 'simkl_list', status='plantowatch')
            row('My Lists', 'simkl_custom_lists')
            row('Watched History', 'simkl_history')
            for label, status in [('Completed', 'completed'), ('On Hold', 'hold'), ('Dropped', 'dropped')]:
                row(label, 'simkl_list', status=status)
            row('Sync Simkl', 'simkl_sync', False)
            row('[COLOR red]Disconnect Simkl[/COLOR]', 'simkl_revoke', False)
    else:
        if not simkl.is_authorized():
            xbmcgui.Dialog().notification('Simkl', 'Authorize Simkl in Settings first')
        else:
            group = params.get('media')
            status = params.get('status', 'plantowatch')
            shows_only = action == 'simkl_list' and status in ('watching', 'hold')
            if group not in ('movies', 'shows'):
                values = {'status': params.get('status', 'plantowatch')} if action == 'simkl_list' else {}
                if not shows_only:
                    row('Movies', action, media='movies', **values)
                row('Shows', action, media='shows', **values)
                xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
                return
            if shows_only and group == 'movies':
                xbmcgui.Dialog().ok('Simkl', 'Movies do not use Watching or On Hold. Choose Plan to Watch, Completed or Dropped.')
                xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
                return
            if action == 'simkl_history':
                kinds = ('movies',) if group == 'movies' else ('shows', 'anime')
                rows = []
                for kind in kinds:
                    history = simkl._get_history(kind)
                    if history is None:
                        xbmcgui.Dialog().notification('Simkl', 'History is unavailable. Please try again later.')
                        xbmcplugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)
                        return
                    rows.extend((kind, item) for item in history)
            else:
                rows = simkl._get_list(params.get('status', 'plantowatch'))
                if rows is None:
                    xbmcgui.Dialog().notification('Simkl', 'Lists are unavailable. Please try again later.')
                    xbmcplugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)
                    return
                rows = [(kind, entry) for kind, entry in rows
                        if kind == 'movies' and group == 'movies' or kind in ('shows', 'anime') and group == 'shows']
            def title_key(row):
                entry = row[1]
                media = entry.get('movie') or entry.get('show') or entry.get('anime') or entry
                return str(media.get('title') or 'Untitled').strip().casefold()
            rows = sorted(rows, key=title_key)
            if action == 'simkl_history':
                rows.sort(key=lambda row: watched_time(row[1]), reverse=True)
            rows, page, pages = page_rows(rows, params.get('page', '1'))
            navigation = {'status': params.get('status', 'plantowatch')} if action == 'simkl_list' else {}
            navigation['media'] = group
            if page > 1:
                row('Previous page (%s of %s)' % (page - 1, pages), action, page=str(page - 1), **navigation)
            for kind, entry in rows:
                media = entry.get('movie') or entry.get('show') or entry.get('anime') or entry
                ids = media.get('ids') or {}
                content = 'movie' if kind == 'movies' else 'tv'
                tmdb_id = ids.get('tmdb')
                if not tmdb_id and ids.get('imdb'):
                    tmdb_id = tmdb.find_by_imdb_id(ids['imdb'], 'movie' if content == 'movie' else 'tvshow')
                if not tmdb_id:
                    row((media.get('title') or 'Untitled') + ' (no TMDB match)', 'simkl_next_info', False,
                        reason='No playable TMDB match is available for this title.')
                    continue
                metadata_type = 'movie' if content == 'movie' else 'tvshow'
                try:
                    details = tmdb.get_metadata(str(tmdb_id), metadata_type) or {}
                except Exception as exc:
                    xbmc.log('VIDCORE Simkl TMDB metadata: %s' % exc, xbmc.LOGWARNING)
                    details = {}
                metadata = dict(details)
                metadata.update({'tmdb_id': str(tmdb_id), 'content': metadata_type})
                metadata['title'] = metadata.get('title') or media.get('title') or 'Untitled'
                if not metadata.get('year'):
                    try:
                        metadata['year'] = int(media.get('year') or 0)
                    except (TypeError, ValueError):
                        metadata['year'] = 0
                row(metadata['title'], 'vidcore_sources' if content == 'movie' else 'vidcore_seasons',
                    folder=content != 'movie', metadata=metadata, kind=content, tmdb_id=str(tmdb_id), title=metadata['title'])
            if page < pages:
                row('Next page (%s of %s)' % (page + 1, pages), action, page=str(page + 1), **navigation)
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
