"""Resolve Morencius links discovered on the matched SRStop episode."""
import re
from urllib.parse import urlsplit, urlunsplit
from urllib.request import Request, urlopen

from . import srstop


def is_url(url):
    try:
        parts = urlsplit(str(url or ''))
        host = (parts.hostname or '').lower()
        host = host[4:] if host.startswith('www.') else host
        return bool(parts.scheme in ('http', 'https') and not parts.username
                    and host == 'morencius.com'
                    and re.fullmatch(r'/(?:e/|embed/|file/|download/|embed-)?[A-Za-z0-9]+(?:\.html)?/?', parts.path))
    except ValueError:
        return False


def _resolve_host_page(url):
    if not is_url(url):
        return None
    from .lulustream import UA
    parts = urlsplit(url)
    code = parts.path.rstrip('/').rsplit('/', 1)[-1]
    code = re.sub(r'^embed-|\.html$', '', code)
    page = urlunsplit((parts.scheme, parts.netloc, '/embed/' + code, parts.query, ''))
    with urlopen(Request(page, headers={'User-Agent': UA, 'Referer': srstop.BASE + '/'}), timeout=12) as response:
        final = response.geturl()
        body = response.read(2 * 1024 * 1024 + 1)
    if len(body) > 2 * 1024 * 1024:
        return None
    for stream in _candidates(body.decode('utf-8', 'replace'), final):
        stream['headers'] = {'User-Agent': UA, 'Referer': final}
        if srstop.probe_stream(stream):
            return stream
    return None


def _candidates(body, page):
    """Read signed HLS fields referenced by the packed JW Player setup."""
    from .lulustream import _unpack, _candidates as player_candidates
    from html import unescape
    from urllib.parse import urljoin
    found = []
    for text in [body] + list(_unpack(body)):
        for match in re.finditer(r'''(?<![\w])["']?(hls[234]?)["']?\s*:\s*(["'])(.*?)\2''', text):
            target = urljoin(page, unescape(match[3]).replace('\\/', '/'))
            if urlsplit(target).scheme not in ('http', 'https') or not urlsplit(target).netloc:
                continue
            if not any(item['url'] == target for item in found):
                found.append({'url': target, 'type': 'hls'})
    for stream in player_candidates(body, page):
        if not any(item['url'] == stream['url'] for item in found):
            found.append(stream)
    return found


def resolve(tmdb_id, season, episode):
    from . import tmdb
    try:
        links = srstop.discover_morencius(tmdb.get_metadata(tmdb_id, 'tv'), season, episode)
        for link in links:
            try:
                stream = _resolve_host_page(link['url'])
                if stream:
                    return stream
            except Exception:
                continue
        return {'error': 'No Morencius source passed the playback check. Choose another host.'}
    except srstop.SourceError as exc:
        return {'error': str(exc)}
    except Exception:
        return {'error': 'SRStop / Morencius could not resolve this episode. Please try again.'}
