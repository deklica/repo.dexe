"""Persistent, transactional Simkl read cache shared by Kodi invocations."""
import json
import os
import sqlite3
import time
from contextlib import contextmanager

TYPES = ('shows', 'movies', 'anime')
BLOCKS = ('tv_shows', 'movies', 'anime')
WATCH_BUCKETS = ('watching', 'plantowatch', 'hold', 'completed', 'dropped', 'notinteresting')
TTL = 900


@contextmanager
def token_lock(folder):
    """Serialize token rotation across Kodi's separate Python interpreters."""
    db = connect(folder, 'simkl_tokens.db')
    try:
        # Refresh includes bounded HTTP retries, so allow another invoker to
        # finish that operation before reloading its newly saved credentials.
        db.execute('PRAGMA busy_timeout=180000')
        db.execute('BEGIN IMMEDIATE')
        yield
        db.commit()
    finally:
        db.close()


def connect(folder, name='simkl_sync.db'):
    os.makedirs(folder, exist_ok=True)
    # A sync can hold the write transaction while the API request is in
    # flight.  Kodi may open the same menu from more than one invocation, so
    # let the second invocation wait instead of treating normal contention as
    # a failed sync.
    db = sqlite3.connect(os.path.join(folder, name), timeout=10)
    db.execute('PRAGMA busy_timeout=10000')
    db.execute('CREATE TABLE IF NOT EXISTS state (key TEXT PRIMARY KEY, value TEXT)')
    return db


def read(db, key):
    row = db.execute('SELECT value FROM state WHERE key=?', (key,)).fetchone()
    try:
        value = json.loads(row[0]) if row else {}
    except (ValueError, TypeError):
        return {}
    # Sync snapshots and throttle records are objects. Treat damaged cache
    # entries as a miss so the next request can rebuild them.
    return value if isinstance(value, dict) else {}


def write(db, key, value):
    db.execute('INSERT OR REPLACE INTO state VALUES (?,?)', (key, json.dumps(value)))


def throttle(folder):
    # A separate database avoids contention with the sync transaction.
    db = connect(folder, 'simkl_requests.db')
    try:
        db.execute('PRAGMA busy_timeout=10000')
        db.execute('BEGIN IMMEDIATE')
        last = read(db, 'last').get('at', 0)
        time.sleep(max(0, 1.5 - (time.time() - last)))
        write(db, 'last', {'at': time.time()})
        db.commit()
    finally:
        db.close()


def identity(item):
    if not isinstance(item, dict):
        raise ValueError('Invalid Simkl item')
    media = item.get('movie') or item.get('show') or item.get('anime') or item
    if not isinstance(media, dict):
        raise ValueError('Invalid Simkl media item')
    ids = media.get('ids') or item.get('ids') or {}
    if not isinstance(ids, dict):
        raise ValueError('Invalid Simkl identifiers')
    for key in ('simkl', 'simkl_id', 'imdb', 'tmdb', 'tvdb'):
        if ids.get(key) is not None:
            return ('simkl' if key == 'simkl_id' else key) + ':' + str(ids[key])
    raise ValueError('Simkl item missing an identifier')


def library_response(data):
    if not isinstance(data, dict) or data.get('error'):
        raise ValueError('Invalid library response')
    result = {}
    for kind in TYPES:
        rows = data.get(kind, [])
        if not isinstance(rows, list):
            raise ValueError('Invalid library section')
        result[kind] = {identity(row): row for row in rows}
    return result


def invalidate(folder, account):
    db = connect(folder)
    try:
        db.execute('BEGIN IMMEDIATE')
        state = read(db, account)
        state['checked'] = 0
        state['dirty'] = True
        state.pop('retry_at', None)
        write(db, account, state)
        db.commit()
    finally:
        db.close()


def fetch_library(request, params):
    """Split oversized sync responses, retaining the same delta cursor."""
    status, data, headers = request('/sync/all-items', params=params)
    if status != 400 or not isinstance(data, dict) or data.get('error') != 'max_items':
        return status, data, headers
    combined = {kind: [] for kind in TYPES}
    for kind in TYPES:
        endpoint = '/sync/all-items/' + kind
        status, data, headers = request(endpoint, params=params)
        if status == 400 and isinstance(data, dict) and data.get('error') == 'max_items':
            statuses = ('plantowatch', 'completed', 'dropped') if kind == 'movies' else WATCH_BUCKETS[:5]
            for bucket in statuses:
                status, part, headers = request(endpoint + '/' + bucket, params=params)
                if status != 200:
                    return status, part, headers
                library_response(part)
                combined[kind].extend(part.get(kind, []))
        else:
            if status != 200:
                return status, data, headers
            library_response(data)
            combined[kind].extend(data.get(kind, []))
    return 200, combined, {}


def sync(folder, account, request, force=False, resource=None, on_progress=None, resource_ttl=None,
         refresh_resources=False):
    """Commit data and cursor together; failed work never advances its cursor."""
    db = connect(folder)
    state = read(db, account)
    counts = {'added': 0, 'updated': 0, 'removed': 0}
    def report(stage, detail=None):
        if on_progress:
            try:
                on_progress(stage, detail or {})
            except Exception:
                pass
    try:
        db.execute('BEGIN IMMEDIATE')
        state = read(db, account)
        now = time.time()
        if not force and now < state.get('retry_at', 0):
            report('deferred')
            raise ValueError('Sync retry deferred')
        if force or now - state.get('checked', 0) >= TTL:
            report('checking')
            status, activities, _ = request('/sync/activities')
            if status != 200 or not isinstance(activities, dict) or not activities.get('all'):
                raise ValueError('Activity check failed')
            old = state.get('activity', {})
            params = dict(extended='full', episode_watched_at='yes',
                          include_all_episodes='yes', next_watch_info='yes')
            if 'library' not in state:
                # The unfiltered endpoint returns all media sections in one
                # response.  Besides being faster, this avoids spending three
                # full-library requests on the first menu open.
                report('initial')
                status, data, _ = fetch_library(request, params)
                if status != 200:
                    raise ValueError('Initial library download failed')
                state['library'] = library_response(data)
                counts['added'] = sum(len(rows) for rows in state['library'].values())
            elif old.get('all') != activities['all']:
                if ((old.get('custom_lists') or {}).get('lists') or {}).get('all') != ((activities.get('custom_lists') or {}).get('lists') or {}).get('all'):
                    report('lists_changed')
                changed = any((old.get(block) or {}).get(bucket) !=
                              (activities.get(block) or {}).get(bucket)
                              for block in BLOCKS for bucket in WATCH_BUCKETS)
                if changed:
                    params['date_from'] = old['all']
                    report('updating')
                    status, data, _ = fetch_library(request, params)
                    if status != 200:
                        raise ValueError('Library delta failed')
                    delta = library_response(data)
                    for kind in TYPES:
                        for key, row in delta[kind].items():
                            previous = state['library'][kind].get(key)
                            if previous is None:
                                counts['added'] += 1
                            elif previous != row:
                                counts['updated'] += 1
                        state['library'][kind].update(delta[kind])
                removed = any((old.get(b) or {}).get('removed_from_list') !=
                              (activities.get(b) or {}).get('removed_from_list') for b in BLOCKS)
                if removed:
                    report('removing')
                    status, data, _ = fetch_library(request, {'extended': 'simkl_ids_only'})
                    if status != 200:
                        raise ValueError('Deletion reconciliation failed')
                    present = library_response(data)
                    for kind in TYPES:
                        counts['removed'] += sum(key not in present[kind] for key in state['library'][kind])
                        state['library'][kind] = {key: row for key, row in state['library'][kind].items()
                                                  if key in present[kind]}
            state.update(activity=activities, checked=now, dirty=False)
        if refresh_resources:
            # Explicit Sync invalidates lazy pages without downloading every
            # custom list. The next opened page fetches fresh contents.
            for cached in state.get('resources', {}).values():
                if isinstance(cached, dict):
                    cached['dirty'] = True
        if resource:
            path, params, stamp = resource(state.get('activity', {}))
            records = state.setdefault('resources', {})
            key = path + json.dumps(params, sort_keys=True)
            previous = records.get(key, {})
            expired = resource_ttl is not None and now - previous.get('fetched_at', 0) >= resource_ttl
            if previous.get('dirty') or previous.get('stamp') != stamp or 'data' not in previous or expired:
                status, data, _ = request(path, params=params)
                access_error = (path.startswith('/lists/') and isinstance(data, dict) and
                                data.get('error') in ('premium_only', 'oauth2_token_required'))
                if status != 200 or not isinstance(data, (dict, list)) or (isinstance(data, dict) and data.get('error') and not access_error):
                    raise ValueError('Resource download failed')
                records[key] = {'stamp': stamp, 'data': data, 'fetched_at': now}
            result = records[key]['data']
        else:
            result = state.get('library')
        state.pop('retry_at', None)
        write(db, account, state)
        db.commit()
        report('complete', counts)
        return result, True
    except (ValueError, KeyError, TypeError, OSError, sqlite3.Error) as exc:
        db.rollback()
        if str(exc) != 'Sync retry deferred':
            report('failed')
        # Preserve the old snapshot and back off failed menu requests.
        state = read(db, account)
        try:
            if isinstance(exc, sqlite3.Error):
                raise exc
            if time.time() >= state.get('retry_at', 0):
                state['retry_at'] = time.time() + TTL
            write(db, account, state)
            db.commit()
        except sqlite3.Error:
            db.rollback()
        if resource:
            path, params, _ = resource(state.get('activity', {}))
            key = path + json.dumps(params, sort_keys=True)
            return state.get('resources', {}).get(key, {}).get('data'), False
        return state.get('library'), False
    finally:
        db.close()
