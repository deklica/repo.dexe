"""Next unwatched TV episodes from Simkl's activity-checked library."""
from datetime import date
import re
from urllib.parse import parse_qsl, urlsplit
import xbmc
import xbmcgui
import xbmcplugin
from . import simkl, tmdb

REFRESH_KEY = 'Vidcore.Simkl.NextEpisodesRefresh'


def next_rows(library):
    rows = []
    shows = library.get('shows') if isinstance(library, dict) else None
    if not isinstance(shows, dict):
        return rows
    for item in shows.values():
        if not isinstance(item, dict) or not isinstance(item.get('show'), dict):
            continue
        if not isinstance(item['show'].get('ids', {}), dict):
            continue
        info = item.get('next_to_watch_info')
        if not isinstance(info, dict):
            info = {}
        if item.get('status') != 'watching' or not item.get('next_to_watch'):
            continue
        try:
            season, episode = int(info['season']), int(info['episode'])
        except (KeyError, TypeError, ValueError):
            match = re.fullmatch(r'S(\d+)E(\d+)', str(item.get('next_to_watch')), re.I)
            if not match:
                continue
            season, episode = map(int, match.groups())
        if season < 0 or episode < 1:
            continue
        air_date = str(info.get('date') or '')[:10]
        if air_date:
            try:
                if date.fromisoformat(air_date) > date.today():
                    continue
            except ValueError:
                pass
        rows.append((item, season, episode))
    return sorted(rows, key=lambda row: str((row[0].get('show') or {}).get('title') or '').casefold())


def menu(params, handle, add_directory, build_url):
    from .simkl_ui import page_rows
    if not simkl.is_authorized():
        add_directory('[COLOR green]Authorize Simkl[/COLOR]', build_url(action='simkl_auth'), is_folder=False)
        xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
        return
    library, ok = simkl._sync_snapshot()
    if not ok:
        xbmcgui.Dialog().notification('Simkl', 'Could not refresh next episodes; showing saved data')
    rows, page, pages = page_rows(next_rows(library), params.get('page', '1'))
    def navigation(label, destination):
        add_directory(label, build_url(action='simkl_next_episodes', page=str(destination)))
    if page > 1:
        navigation('Previous page (%s of %s)' % (page - 1, pages), page - 1)
    rendered = 0
    for item, season, episode in rows:
        media = item.get('show') or {}
        ids = media.get('ids') or {}
        tmdb_id = ids.get('tmdb')
        if not tmdb_id and ids.get('imdb'):
            tmdb_id = tmdb.find_by_imdb_id(ids['imdb'], 'tvshow')
        info = item.get('next_to_watch_info')
        if not isinstance(info, dict):
            info = {}
        try:
            episode_meta = (tmdb.get_episode_meta(str(tmdb_id), season, episode) or {}) if tmdb_id else {}
            details = dict(tmdb.get_metadata(str(tmdb_id), 'tvshow') or {}) if tmdb_id else {}
        except (ValueError, TypeError, OSError) as exc:
            xbmc.log('VIDCORE Simkl next episode metadata: %s' % exc, xbmc.LOGWARNING)
            episode_meta, details = {}, {}
        air_date = str(info.get('date') or episode_meta.get('air_date') or '')[:10]
        try:
            released = date.fromisoformat(air_date) <= date.today()
        except ValueError:
            released = False
        title = details.get('title') or media.get('title') or 'Untitled'
        name = episode_meta.get('name') or info.get('title') or 'Episode %s' % episode
        details.update({'title': name, 'tvshowtitle': title, 'content': 'episode',
            'tmdb_id': str(tmdb_id or ''), 'season': season, 'episode': episode,
            'plot': episode_meta.get('overview') or details.get('plot', ''),
            'premiered': air_date, 'runtime': episode_meta.get('runtime', 0),
            'rating': episode_meta.get('rating', 0), 'thumb': episode_meta.get('still') or details.get('poster', '')})
        playable = bool(tmdb_id) and released
        label = '%s - S%02dE%02d - %s' % (title, season, episode, name)
        if playable:
            url = build_url(action='vidcore_sources', kind='tv', tmdb_id=str(tmdb_id),
                season=str(season), episode=str(episode), title=title, simkl_next_episode='true')
        else:
            reason = 'No TMDB match is available for this show.' if not tmdb_id else 'The release date cannot be verified.'
            label += ' (unavailable)'
            url = build_url(action='simkl_next_info', reason=reason)
        add_directory(label, url, metadata=details, is_folder=False, is_playable=playable)
        rendered += 1
    if not rendered:
        add_directory('No released next episodes on this page', build_url(action='simkl_root'), is_folder=True)
    if page < pages:
        navigation('Next page (%s of %s)' % (page + 1, pages), page + 1)
    xbmcplugin.setContent(handle, 'episodes')
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def completed(meta):
    """Only called after Simkl confirms the episode was marked watched."""
    if meta.get('content') != 'episode':
        return
    simkl._sync_snapshot(force=True)
    xbmcgui.Window(10000).setProperty(REFRESH_KEY, 'true')


def cached_episode(params):
    """Verify an episode against Simkl's cache when TMDB has no episode data."""
    library, _ok = simkl._sync_snapshot()
    for item, season, episode in next_rows(library):
        media = item.get('show') or {}
        ids = media.get('ids') or {}
        if str(season) != str(params.get('season')) or str(episode) != str(params.get('episode')):
            continue
        tmdb_id = ids.get('tmdb')
        if not tmdb_id and ids.get('imdb'):
            tmdb_id = tmdb.find_by_imdb_id(ids['imdb'], 'tvshow')
        if tmdb_id and str(tmdb_id) == str(params.get('tmdb_id')):
            info = item.get('next_to_watch_info')
            if not isinstance(info, dict):
                info = {}
            return {'name': info.get('title', ''), 'overview': info.get('title', ''),
                    'air_date': str(info.get('date') or '')[:10]}
    return {}


def refresh_menu(player):
    window = xbmcgui.Window(10000)
    if window.getProperty(REFRESH_KEY) != 'true' or player.isPlayingVideo():
        return
    route = urlsplit(xbmc.getInfoLabel('Container.FolderPath'))
    if route.netloc == 'plugin.video.vidcore' and dict(parse_qsl(route.query)).get('action') == 'simkl_next_episodes':
        window.clearProperty(REFRESH_KEY)
        xbmc.executebuiltin('Container.Refresh')
