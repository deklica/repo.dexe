"""Vidcore diagnostics in Kodi's log, with sensitive details removed."""
import re
import traceback
from urllib.parse import urlsplit
import xbmc
import xbmcaddon

def is_enabled():
    try:
        return xbmcaddon.Addon('plugin.video.vidcore').getSetting('diagnostic_logging') == 'true'
    except Exception:
        return False


def sanitize(value):
    text = str(value)
    # Signed media URLs and URL paths can carry credentials, not just queries.
    def redact_url(match):
        try:
            return 'https://' + (urlsplit(match[0]).hostname or '[host]') + '/[redacted]'
        except ValueError:
            return '[URL redacted]'
    text = re.sub(r'https?://[^\s\"\'<>]+', redact_url, text, flags=re.I)
    text = re.sub(r'(?im)^(\s*(?:cookie|set-cookie|authorization)\s*:\s*).*$', r'\1[redacted]', text)
    text = re.sub(r'(?i)\bBearer\s+[^\s,\"\']+', 'Bearer [redacted]', text)
    text = re.sub(r'''(?ix)(["']?(?:access_token|refresh_token|token|api_key|apikey|client_secret|authorization|cookie|password|device_code|user_code)["']?\s*[:=]\s*)(?:"[^"]*"|'[^']*'|[^\s,;}]+)''', r'\1[redacted]', text)
    text = re.sub(r'(?i)([A-Z]:[\\/]Users[\\/])[^\\/\s]+', r'\1[user]', text)
    return text[:6000]

def log(tag, detail):
    if is_enabled():
        xbmc.log('VIDCORE %s: %s' % (sanitize(tag), sanitize(detail)), xbmc.LOGINFO)


def error(tag, detail=''):
    """Errors remain visible with detailed diagnostics switched off."""
    trace = traceback.format_exc()
    if trace.strip() == 'NoneType: None':
        trace = ''
    xbmc.log('VIDCORE ERROR %s: %s' % (sanitize(tag), sanitize(str(detail) + '\n' + trace)), xbmc.LOGERROR)
