"""Vidcore source picker. Derived from Cosmos by Zeus768, GPL-2.0-only."""
import threading
import time
import xbmc
import xbmcgui
import xbmcaddon
ADDON_PATH = xbmcaddon.Addon('plugin.video.vidcore').getAddonInfo('path')
_LP_LIST = 4001
_LP_PLAY = 4003

class LinkPickerDialog(xbmcgui.WindowXMLDialog):
    """Scrollable link list for a single quality tier.

    ``links`` is a list of dicts: ``{label, meta, icon}``. Set
    ``self.selected_index`` (or ``None`` if canceled) when the user presses
    Play. ``icon`` should be an absolute path to one of the quality tile
    PNGs, matching the tier the caller filtered to.
    """

    def __init__(self, *args, **kwargs):
        self.quality_label = kwargs.pop('quality_label', '')
        self.poster = kwargs.pop('poster', '')
        self.icon_path = kwargs.pop('icon_path', '')
        self.links = kwargs.pop('links', [])
        self.media_info = kwargs.pop('media_info', {})
        self.links_provider = kwargs.pop('links_provider', None)
        self.scan_state = kwargs.pop('scan_state', None)
        self.media_provider = kwargs.pop('media_provider', None)
        self._closed = threading.Event()
        self._ready = threading.Event()
        self.current_index = 0
        self.selected_index = None
        super().__init__(*args, **kwargs)

    def _refresh_selection_banner(self):
        if not self.links:
            return
        item = self.links[self.current_index]
        try:
            self.setProperty('lp_sel_icon', self.icon_path or '')
            self.setProperty('lp_sel_title', item.get('label', ''))
            self.setProperty('lp_sel_meta', item.get('meta', ''))
            self.setProperty('lp_sel_cache', item.get('cache_label', 'UNKNOWN'))
            self.setProperty('lp_sel_format', item.get('format_label', 'AUTO'))
        except Exception as e:
            xbmc.log(f'LinkPickerDialog banner error: {e}', xbmc.LOGERROR)

    def onInit(self):
        try:
            self.setProperty('lp_quality_label', self.quality_label)
            self.setProperty('lp_poster', self.poster or '')
            self.setProperty('lp_count', str(len(self.links)))
            self.setProperty('lp_scan_status', 'Scanning for sources...' if self.scan_state is not None
                             else 'Choose a source to start playback')
            for key in ('title', 'subtitle', 'context', 'facts', 'genres', 'plot', 'art'):
                self.setProperty('lp_media_' + key, str(self.media_info.get(key) or ''))
        except Exception as e:
            xbmc.log(f'LinkPickerDialog header error: {e}', xbmc.LOGERROR)

        try:
            listctl = self.getControl(_LP_LIST)
            listctl.reset()
            for i, item in enumerate(self.links):
                li = xbmcgui.ListItem(label=item.get('label', ''))
                li.setProperty('source_index', str(i + 1))
                li.setProperty('meta', item.get('meta', ''))
                li.setProperty('icon', item.get('icon') or self.icon_path or '')
                li.setProperty('cache_label', item.get('cache_label', 'UNKNOWN'))
                li.setProperty('format_label', item.get('format_label', 'AUTO'))
                li.setProperty('selected', 'true' if i == self.current_index else 'false')
                listctl.addItem(li)
            if self.links:
                listctl.selectItem(self.current_index)
        except Exception as e:
            xbmc.log(f'LinkPickerDialog list error: {e}', xbmc.LOGERROR)

        self._refresh_selection_banner()

        # The list is now populated: start remote navigation on the sources.
        if self.links:
            self.setFocusId(_LP_LIST)
        self._navigation_hint(_LP_LIST)
        self._ready.set()

    def close(self):
        self._closed.set()
        super().close()

    def _update_live(self):
        if self.scan_state is not None:
            _results, count, total, active = self.scan_state()
            self.setProperty('lp_scan_status', 'Scanning %d remaining' % max(0, total - count)
                             if active else 'Scan complete' if count == total else 'Scan time limit reached')
        if self.media_provider is not None:
            details = self.media_provider()
            for key in ('title', 'subtitle', 'context', 'facts', 'genres', 'plot', 'art'):
                value = str(details.get(key) or '')
                if self.getProperty('lp_media_' + key) != value:
                    self.setProperty('lp_media_' + key, value)
        if self.links_provider is None:
            return
        rows = self.links_provider()
        if rows == self.links:
            return
        listing = self.getControl(_LP_LIST)
        position = listing.getSelectedPosition()
        key = self.links[position].get('key') if 0 <= position < len(self.links) else None
        focus = self.getFocusId()
        if focus in (_LP_LIST, 4002):
            # Kodi cannot keep focus on a list while reset() empties it.
            self.setFocusId(_LP_PLAY)
        self.links = rows
        listing.reset()
        for index, row in enumerate(rows):
            item = xbmcgui.ListItem(label=row.get('label', ''))
            item.setProperty('source_index', str(index + 1))
            for name in ('meta', 'icon', 'cache_label', 'format_label'):
                item.setProperty(name, str(row.get(name) or ''))
            listing.addItem(item)
        position = next((index for index, row in enumerate(rows) if row.get('key') == key), 0)
        if rows:
            listing.selectItem(position)
            self._mark_current(position)
        else:
            self.current_index = 0
            for name in ('title', 'meta', 'icon', 'cache', 'format'):
                self.setProperty('lp_sel_' + name, '')
            if focus in (_LP_LIST, 4002, _LP_PLAY):
                focus = 4005
        self.setProperty('lp_count', str(len(rows)))
        self.setFocusId(focus)
        self._navigation_hint(focus)

    def doModal(self):
        from .skin_support import use_native_dialogs
        if use_native_dialogs():
            return self._native_picker()
        if self.links_provider is None:
            return super().doModal()
        # Kodi callbacks and list updates run on this invoker, never workers.
        self.show()
        monitor = xbmc.Monitor()
        started = time.monotonic()
        while not self._closed.is_set() and not monitor.abortRequested():
            xbmc.sleep(50)
            if self._closed.is_set():
                break
            if self._ready.is_set():
                self._update_live()
            elif time.monotonic() - started > 5:
                self.close()
        if not self._closed.is_set():
            self.close()

    def _native_picker(self):
        """Use the active skin's selection dialog without custom fonts/XML."""
        while True:
            active = False
            if self.scan_state is not None:
                _results, _count, _total, active = self.scan_state()
            if self.links_provider is not None:
                self.links = self.links_provider()
            if self.media_provider is not None:
                self.media_info = self.media_provider()
            rows = []
            for link in self.links:
                item = xbmcgui.ListItem(label=link.get('label', ''),
                                        label2=link.get('meta', ''))
                item.setArt({'thumb': self.media_info.get('art') or self.poster})
                rows.append(item)
            source_count = len(rows)
            rows.append(xbmcgui.ListItem(label='Film / episode details'))
            if active:
                rows.append(xbmcgui.ListItem(label='Refresh available sources',
                                            label2='The scan is still running'))
            title = self.media_info.get('title') or self.quality_label or 'Vidcore sources'
            selected = xbmcgui.Dialog().select(title, rows, useDetails=True)
            if selected < 0:
                self.selected_index = None
                return
            if selected < source_count:
                self.selected_index = selected
                return
            if selected == source_count:
                info = self.media_info
                xbmcgui.Dialog().textviewer(title, '\n\n'.join(str(info.get(key) or '')
                    for key in ('context', 'subtitle', 'facts', 'genres', 'plot')))

    def _mark_current(self, new_index):
        try:
            listctl = self.getControl(_LP_LIST)
            for i in range(listctl.size()):
                item = listctl.getListItem(i)
                item.setProperty('selected', 'true' if i == new_index else 'false')
        except Exception as e:
            xbmc.log(f'LinkPickerDialog mark error: {e}', xbmc.LOGERROR)
        self.current_index = new_index
        self._refresh_selection_banner()

    def _sync_highlighted_source(self):
        """Keep the preview and Play target aligned with the list cursor."""
        try:
            pos = self.getControl(_LP_LIST).getSelectedPosition()
        except Exception:
            return
        if 0 <= pos < len(self.links) and pos != self.current_index:
            self._mark_current(pos)

    def onFocus(self, controlId):
        self._sync_highlighted_source()
        self._navigation_hint(controlId)

    def _navigation_hint(self, control_id):
        if control_id == _LP_PLAY:
            hint = 'OK: play · Left/Up: sources · Back: return'
        elif control_id == 4005:
            hint = 'Up/Down: scroll plot · Right: sources · Back: return'
        else:
            hint = 'OK: play · Left: plot · Right: Play · Back: return'
        self.setProperty('lp_navigation', hint)

    def onClick(self, controlId):
        if controlId == _LP_LIST:
            try:
                pos = self.getControl(_LP_LIST).getSelectedPosition()
            except Exception:
                pos = -1
            if 0 <= pos < len(self.links):
                _item = self.links[pos]
                xbmc.log(
                    f'VIDCORE [CLICK] LinkPicker  list click  pos={pos}'
                    f'  label={_item.get("label","")[:80]!r}',
                    xbmc.LOGDEBUG,
                )
                # Clicking a link plays it directly - no need to highlight
                # it first and then hit the separate Play button.
                self._mark_current(pos)
                self.selected_index = pos
                self.close()
        elif controlId == _LP_PLAY:
            self._sync_highlighted_source()
            xbmc.log(
                f'VIDCORE [CLICK] LinkPicker  Play button  current_index={self.current_index}',
                xbmc.LOGDEBUG,
            )
            try:
                pos = self.getControl(_LP_LIST).getSelectedPosition()
            except Exception:
                return
            if 0 <= pos < len(self.links):
                self.selected_index = pos
                self.close()

    def onAction(self, action):
        self._sync_highlighted_source()
        if action.getId() in (
            xbmcgui.ACTION_NAV_BACK,
            xbmcgui.ACTION_PREVIOUS_MENU,
        ):
            xbmc.log(
                f'VIDCORE [CLICK] LinkPicker  back/cancel action={action.getId()}',
                xbmc.LOGDEBUG,
            )
            self.selected_index = None
            self.close()
