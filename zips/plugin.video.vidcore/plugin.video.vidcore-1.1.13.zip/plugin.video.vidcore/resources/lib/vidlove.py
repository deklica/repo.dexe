"""VidLove player embed and API resolver for the Vidcore source picker."""
import html
import json
import re
from urllib.parse import urljoin, urlsplit, urlencode
from urllib.request import Request, urlopen

import xbmc

BASE_URL = 'https://player.vidlove.cc'
HEADERS = {'User-Agent': 'Mozilla/5.0', 'Referer': BASE_URL + '/',
           'Accept': 'text/html,application/xhtml+xml,application/json,*/*'}
SERVERS = (('moviebox2', 'Barbarian King 2.0'), ('moviebox', 'Barbarian King'),
           ('dcloud', 'Electro Dragon'), ('tcloud', 'Ice Wizard'), ('vidapi', 'Archer Queen'))


def embed_url(tmdb_id, content='movie', season=None, episode=None):
    """Build the documented VidLove embed URL."""
    tmdb_id = str(tmdb_id or '').strip()
    if not tmdb_id.isdigit() or int(tmdb_id) < 1:
        return ''
    if content == 'movie':
        return '%s/embed/movie/%s' % (BASE_URL, tmdb_id)
    try:
        season, episode = int(season), int(episode)
    except (TypeError, ValueError):
        return ''
    if season >= 0 and episode > 0:
        return '%s/embed/tv/%s/%s/%s' % (BASE_URL, tmdb_id, season, episode)
    return ''


def _urls(body, page):
    text = html.unescape(body).replace('\\/', '/')
    pattern = r'''(?:https?:)?//[^\s"'<>\\]+?(?:\.m3u8|\.mp4)(?:\?[^\s"'<>\\]*)?'''
    for raw in re.findall(pattern, text, re.I):
        value = urljoin(page, raw)
        if value.startswith(('http://', 'https://')):
            yield value


def _json_urls(value):
    """Yield media URLs from the player API's nested source response."""
    if isinstance(value, dict):
        for key, item in value.items():
            if isinstance(item, str) and item.startswith(('http://', 'https://')):
                # VidLove has used url, file, source, link and provider-specific
                # field names. Keep any URL here; verification below rejects
                # posters, pages and non-media responses.
                yield item
            else:
                yield from _json_urls(item)
    elif isinstance(value, list):
        for item in value:
            yield from _json_urls(item)
    elif isinstance(value, str) and value.startswith(('http://', 'https://')):
        yield value


def _episode_duration(data, season, episode):
    """Reject wrong episode metadata; require a substantial episode runtime."""
    meta = data.get('meta') or {}
    if not isinstance(meta, dict):
        raise ValueError('Invalid episode metadata')
    for key, requested in (('season_number', season), ('episode_number', episode)):
        if meta.get(key) is not None and int(meta[key]) != int(requested):
            raise ValueError('Wrong episode metadata')
    runtime = float(meta.get('runtime') or 0)
    return max(180, runtime * 30)


def resolve(url, backend=''):
    """Follow the embed's iframe/player layers and verify HLS or MP4 output."""
    parsed = urlsplit(url)
    if parsed.hostname != 'player.vidlove.cc' or not re.fullmatch(
            r'/embed/(?:movie/\d+|tv/\d+/\d+/\d+)', parsed.path):
        return None
    parts = parsed.path.strip('/').split('/')
    if backend and backend not in dict(SERVERS):
        return None
    if not backend:
        for server, _label in SERVERS:
            result = resolve(url, backend=server)
            if result:
                return result
        return None
    if parts[1] == 'movie':
        api_url = 'https://api.vidlove.cc/movie?id=%s&mode=json' % parts[2]
    else:
        api_url = 'https://api.vidlove.cc/tv?id=%s&season=%s&episode=%s&mode=json' % (
            parts[2], parts[3], parts[4])
    api_url += '&' + urlencode({'sources': backend})
    queue, seen = [(api_url, BASE_URL + '/')], set()
    while queue and len(seen) < 20:
        page, referer = queue.pop(0)
        if page in seen:
            continue
        seen.add(page)
        try:
            with urlopen(Request(page, headers=dict(HEADERS, Referer=referer)), timeout=15) as response:
                raw_body = response.read()
                body = raw_body.decode('utf-8', errors='replace')
                page = response.geturl()
            try:
                data = json.loads(body)
            except (TypeError, ValueError):
                data = None
            xbmc.log('VIDCORE VidLove API response: %s bytes' % len(raw_body), xbmc.LOGINFO)
            minimum_duration = (_episode_duration(data, parts[3], parts[4])
                                if parts[1] == 'tv' and isinstance(data, dict) else 0)
            source = data.get('source') if isinstance(data, dict) else None
            source_data = (source or data.get('sources') or data.get('data') or {}
                           if isinstance(data, dict) else data)
            candidates = list(_json_urls(source_data)) if data is not None else list(_urls(body, page))
            media_headers = dict(HEADERS)
            if isinstance(source, dict) and isinstance(source.get('headers'), dict):
                for key, value in source['headers'].items():
                    if key.strip().lower() in ('user-agent', 'referer', 'origin', 'accept'):
                        media_headers = {k: v for k, v in media_headers.items()
                                         if k.lower() != key.strip().lower()}
                        media_headers[key.strip()] = str(value).strip()
            for candidate in dict.fromkeys(candidates):
                try:
                    with urlopen(Request(candidate, headers=media_headers), timeout=12) as response:
                        sample = response.read(4096)
                        final = response.geturl()
                    if sample.decode('utf-8-sig', errors='replace').lstrip().startswith('#EXTM3U'):
                        stream_type = 'hls'
                    elif len(sample) >= 12 and sample[4:8] == b'ftyp':
                        stream_type = 'mp4'
                    else:
                        continue
                    from .vidcore_availability import check_stream
                    checked = check_stream({'url': final, 'type': stream_type,
                                            'headers': media_headers,
                                            'minimum_duration': minimum_duration})
                    if checked:
                        return checked
                except Exception as exc:
                    xbmc.log('VIDCORE VidLove probe failed: %s status=%s' % (
                        type(exc).__name__, getattr(exc, 'code', '')), xbmc.LOGWARNING)
            if data is not None:
                xbmc.log('VIDCORE VidLove: no verified source for backend %s' % backend, xbmc.LOGDEBUG)
                continue
            for raw in re.findall(r'''<(?:iframe|source)[^>]+(?:src|data-src)=['"]([^'"]+)''', body, re.I):
                child = urljoin(page, html.unescape(raw))
                if urlsplit(child).scheme in ('http', 'https'):
                    queue.append((child, page))
        except Exception as exc:
            xbmc.log('VIDCORE VidLove resolver failed: %s' % type(exc).__name__, xbmc.LOGWARNING)
    xbmc.log('VIDCORE VidLove: no verified media URL returned', xbmc.LOGDEBUG)
    return None
