import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
import os
import os.path
import sys
from datetime import datetime
try:  # Python 3
    from urllib.parse import parse_qsl
except ImportError:  # Python 2
    from urlparse import parse_qsl
from libs.common import logging
from libs.common import var
from libs.gui import menu


def _close_kodi_or_later():
    # The change is already made; closing Kodi only makes the add-ons read it. Back or the X
    # means "not yet" (the user's rule, 2026-10-04): this used to be an OK box that closed Kodi
    # whichever way it was dismissed.
    if xbmcgui.Dialog().yesno('ReAuthorize', 'Close Kodi now to finish?[CR][CR]The change is saved. '
                              'Add-ons pick it up the next time Kodi starts.',
                              nolabel='Not yet', yeslabel='Close Kodi'):
        os._exit(1)
    xbmc.executebuiltin('Addon.OpenSettings(script.module.reauthorize)')


import re as _re

# The Crew 3.x reads its Trakt key from keys.py, so ReAuthorize (1.3.8) swaps the whole
# CLIENT_ID / CLIENT_SECRET lines and leaves what they said in a comment. Put that back.
_CREW_MARKED = _re.compile(r'^(CLIENT_ID|CLIENT_SECRET)(\s*=\s*).*?# ReAuthorize; was: (.+?)\s*$', _re.M)

def _crew_restore(data):
    return _CREW_MARKED.sub(lambda m: m.group(1) + m.group(2) + m.group(3), data)


# The Trakt add-on 3.9.0 keeps its key as a list of numbers; ReAuthorize (1.3.8) swaps those
# two lines the same way. Put back what they said.
_TRAKTADDON_MARKED = _re.compile(r'^([ \t]*__client_(?:id|secret)[^=\r\n]*=[ \t]*)\[[^\]\r\n]*\][ \t]*# ReAuthorize; was: '
                                 r'(\[[^\]\r\n]*\])[ \t]*$', _re.M)

def _traktaddon_restore(data):
    return _TRAKTADDON_MARKED.sub(lambda m: m.group(1) + m.group(2), data)


def _tmdbmovies_config():
    # TMDb Movies 1.1.308 moved config.py from resources/lib/ to resources/lib/core/.
    # Both places are looked at, the same way the Trakt sync does.
    path = var.path_tmdbmovies
    return path if os.path.isfile(path) else os.path.join(os.path.dirname(path), 'core', 'config.py')

accountmgr = xbmcaddon.Addon("script.module.reauthorize")
addon = xbmcaddon.Addon
addonObject = addon('script.module.reauthorize-core')
addonInfo = addonObject.getAddonInfo
getLangString = xbmcaddon.Addon().getLocalizedString
condVisibility = xbmc.getCondVisibility
execute = xbmc.executebuiltin
monitor = xbmc.Monitor()
joinPath = os.path.join
dialog = xbmcgui.Dialog()
date_time = datetime.now()
date = date_time.strftime('Date: %Y-%m-%d  Time: %H:%M')

amgr_icon = joinPath(os.path.join(xbmcaddon.Addon('script.module.reauthorize-core').getAddonInfo('path'), 'resources', 'icons'), 'accountmgr.png')
rd_icon = joinPath(os.path.join(xbmcaddon.Addon('script.module.reauthorize-core').getAddonInfo('path'), 'resources', 'icons'), 'realdebrid.png')
pm_icon = joinPath(os.path.join(xbmcaddon.Addon('script.module.reauthorize-core').getAddonInfo('path'), 'resources', 'icons'), 'premiumize.png')
ad_icon = joinPath(os.path.join(xbmcaddon.Addon('script.module.reauthorize-core').getAddonInfo('path'), 'resources', 'icons'), 'alldebrid.png')
trakt_icon = joinPath(os.path.join(xbmcaddon.Addon('script.module.reauthorize-core').getAddonInfo('path'), 'resources', 'icons'), 'trakt.png')
torbox_icon = joinPath(os.path.join(xbmcaddon.Addon('script.module.reauthorize-core').getAddonInfo('path'), 'resources', 'icons'), 'torbox.png')
easyd_icon = joinPath(os.path.join(xbmcaddon.Addon('script.module.reauthorize-core').getAddonInfo('path'), 'resources', 'icons'), 'easydebrid.png')
offcloud_icon = joinPath(os.path.join(xbmcaddon.Addon('script.module.reauthorize-core').getAddonInfo('path'), 'resources', 'icons'), 'offcloud.png')
easy_icon = joinPath(os.path.join(xbmcaddon.Addon('script.module.reauthorize-core').getAddonInfo('path'), 'resources', 'icons'), 'easynews.png')
file_icon = joinPath(os.path.join(xbmcaddon.Addon('script.module.reauthorize-core').getAddonInfo('path'), 'resources', 'icons'), 'filepursuit.png')

class Router:
    def __init__(self):
        self.route = None
        self.params = {}

    def _log_params(self, paramstring):
        _url = sys.argv[0]

        self.params = dict(parse_qsl(paramstring))

        logstring = '{0}: '.format(_url)
        for param in self.params:
            logstring += '[ {0}: {1} ] '.format(param, self.params[param])

        logging.log(logstring, level=xbmc.LOGDEBUG)

        return self.params

    def dispatch(self, handle, paramstring):
        self._log_params(paramstring)

        mode = self.params['mode'] if 'mode' in self.params else None
        url = self.params['url'] if 'url' in self.params else None
        name = self.params['name'] if 'name' in self.params else None
        action = self.params['action'] if 'action' in self.params else None

        from libs import traktit, debridit_rd, debridit_pm, debridit_ad, tbit, edit, offit, easyit, fileit, extit, metait_all, jsonit

        # MAIN MENU - opened from Video add-ons, where core is listed and people look first.
        # Core on its own does nothing useful, so send them to ReAuthorize itself: open it, or
        # offer to install it from the repository (people kept installing only core, 2026-10-02).
        if mode is None:
            if xbmc.getCondVisibility('System.HasAddon(script.module.reauthorize)'):
                xbmc.executebuiltin('RunScript(script.module.reauthorize)')
            elif xbmcgui.Dialog().yesno('ReAuthorize',
                                        'Install ReAuthorize now?[CR][CR]This is only its helper. '
                                        'ReAuthorize itself is what you open and sign in with.'):
                xbmc.executebuiltin('InstallAddon(script.module.reauthorize)')
            self._finish(handle)

        elif mode == 'trakt':  # Trakt Account Viewer
            menu.trakt_menu()
            self._finish(handle)

        elif mode == 'realdebrid':  # Real-Debrid Account Viewer
            menu.debrid_menu()
            self._finish(handle)

        elif mode == 'premiumize':  # Premiumize Account Viewer
            menu.premiumize_menu()
            self._finish(handle)

        elif mode == 'alldebrid':  # All-Debird Account Viewer
            menu.alldebrid_menu()
            self._finish(handle)

        elif mode == 'torbox':  # TorBox Account Viewer
            menu.torbox_menu()
            self._finish(handle)

        elif mode == 'easydebrid':  # Easy Debrid Account Viewer
            menu.easydebrid_menu()
            self._finish(handle)

        elif mode == 'offcloud':  # OffCloud Account Viewer
            menu.offcloud_menu()
            self._finish(handle)

        elif mode == 'easynews':  # Easynews Account Viewer
            menu.easynews_menu()
            self._finish(handle)

        elif mode == 'filepursuit':  # Filepursuit Account Viewer
            menu.filepursuit_menu()
            self._finish(handle)

        elif mode == 'extproviders':  # External Providers Account Viewer
            menu.ext_menu()
            self._finish(handle)



        # OPEN ADDON SETTINGS
        elif mode == 'opensettings_tk':  # Trakt
            from libs import traktit
            traktit.open_settings(name)
            xbmc.executebuiltin('Container.Refresh()')

        elif mode == 'opensettings_rd':  # Real Debrid
            from libs import debridit_rd
            debridit_rd.open_settings(name)
            xbmc.executebuiltin('Container.Refresh()')

        elif mode == 'opensettings_pm':  # Premiumize
            from libs import debridit_pm
            debridit_pm.open_settings(name)
            xbmc.executebuiltin('Container.Refresh()')

        elif mode == 'opensettings_ad':  # All-Debrid
            from libs import debridit_ad
            debridit_ad.open_settings(name)
            xbmc.executebuiltin('Container.Refresh()')

        elif mode == 'opensettings_all':  # Debrid All
            from libs import debridit_all
            debridit_all.open_settings(name)
            xbmc.executebuiltin('Container.Refresh()')

        elif mode == 'opensettings_tb':  # TorBox
            from libs import tbit
            tbit.open_settings(name)
            xbmc.executebuiltin('Container.Refresh()')

        elif mode == 'opensettings_ed':  # Easy Debrid
            from libs import edit
            edit.open_settings(name)
            xbmc.executebuiltin('Container.Refresh()')

        elif mode == 'opensettings_oc':  # OffCloud
            from libs import offit
            offit.open_settings(name)
            xbmc.executebuiltin('Container.Refresh()')

        elif mode == 'opensettings_en':  # Easynews
            from libs import easyit
            easyit.open_settings(name)
            xbmc.executebuiltin('Container.Refresh()')

        elif mode == 'opensettings_fp':  # Filepursuit
            from libs import fileit
            fileit.open_settings(name)
            xbmc.executebuiltin('Container.Refresh()')

        elif mode == 'opensettings_md':  # Metadata
            from libs import metait_all
            metait_all.open_settings(name)
            xbmc.executebuiltin('Container.Refresh()')

        elif mode == 'opensettings_ext':  # External Providers
            from libs import extit
            extit.open_settings(name)
            xbmc.executebuiltin('Container.Refresh()')

        # TRAKT MANAGER
        elif mode == 'savetrakt':  # Save Trakt Data
            traktit.trakt_it('update', name)
        elif mode == 'restoretrakt':  # Recover All Saved Trakt Data
            try:
                if xbmcvfs.exists(var.trakt_backup): # Skip restore if no trakt folder present in backup folder
                    path = os.listdir(var.trakt_backup)
                    if len(path) != 0: # Skip restore if no saved data in backup folder
                        var.restore_synclist()
                        traktit.trakt_it_restore('restore', name)
                        accountmgr.setSetting("trakt.synclist", 'true')
                        accountmgr.setSetting("sync.tk.service", "true")
                        if xbmcvfs.exists(var.chk_genocide):
                            # Every installed add-on is a Trakt target now; there is no list file to look in.
                            accountmgr.setSetting("genocide_traktsync", 'true')
                        else:
                            pass
                        accountmgr.setSetting("api.service", "true") #Enable API Check Service
                        xbmcgui.Dialog().notification('ReAuthorize', 'Trakt Data Restored!', trakt_icon, 3000)
                        xbmc.sleep(3000)
                        _close_kodi_or_later()
                    else:
                        xbmcgui.Dialog().notification('ReAuthorize', 'No Trakt Data to Restore!', trakt_icon, 3000)
                        xbmc.sleep(3000)
                        xbmc.executebuiltin('Dialog.Close(all,true)')
                        xbmc.executebuiltin('Addon.OpenSettings(script.module.reauthorize)')
                else:
                    xbmcgui.Dialog().notification('ReAuthorize', 'No Trakt Data to Restore!', trakt_icon, 3000)
                    xbmc.sleep(3000)
                    xbmc.executebuiltin('Dialog.Close(all,true)')
                    xbmc.executebuiltin('Addon.OpenSettings(script.module.reauthorize)')
            except:
                xbmc.log('%s: Router.py Restore Trakt Failed!' % var.amgr, xbmc.LOGINFO)
        elif mode == 'addontrakt':  # Clear All Addon Trakt Data
            #Revoke Account Manager/Custom API keys for all add-ons
            if accountmgr.getSetting('trakt.token') != '':
                pass
            else:
                accountmgr.setSetting("api.service", "false") #Disable API Check Service
            if xbmcvfs.exists(var.chk_seren): #Check if add-on is installed
                try:
                    with open(var.path_seren,'r') as f:
                        data = f.read()

                    client = data.replace(var.client_am,var.seren_client).replace(var.secret_am,var.seren_secret)

                    with open(var.path_seren,'w') as f:
                        f.write(client)
                except:
                    xbmc.log('%s: Traktit.py Revoke API Seren Failed!' % var.amgr, xbmc.LOGINFO)

            if xbmcvfs.exists(var.chk_coal):
                try:
                    with open(var.path_coal,'r') as f:
                        data = f.read()

                    client = data.replace(var.client_am,var.coal_client).replace(var.secret_am,var.coal_secret)

                    with open(var.path_coal,'w') as f:
                        f.write(client)
                except:
                    xbmc.log('%s: Traktit.py Revoke API Coalition Failed!' % var.amgr, xbmc.LOGINFO)

            if xbmcvfs.exists(var.chk_pov):
                try:
                    addon = xbmcaddon.Addon("plugin.video.pov")
                    addon.setSetting("trakt.client_id", var.pov_client)
                    addon.setSetting("trakt.client_secret", var.pov_secret)
                except:
                    xbmc.log('%s: Traktit.py Revoke API POV Failed!' % var.amgr, xbmc.LOGINFO)

            if xbmcvfs.exists(var.chk_shadow):
                try:
                    with open(var.path_shadow,'r') as f:
                        data = f.read()

                    client = data.replace(var.client_am,var.shadow_client).replace(var.secret_am,var.shadow_secret)

                    with open(var.path_shadow,'w') as f:
                        f.write(client)
                except:
                    xbmc.log('%s: Traktit.py Revoke API Shadow Failed!' % var.amgr, xbmc.LOGINFO)

            if xbmcvfs.exists(var.chk_ghost):
                try:
                    with open(var.path_ghost,'r') as f:
                        data = f.read()

                    client = data.replace(var.client_am,var.ghost_client).replace(var.secret_am,var.ghost_secret)

                    with open(var.path_ghost,'w') as f:
                        f.write(client)
                except:
                    xbmc.log('%s: Traktit.py Revoke API Ghost Failed!' % var.amgr, xbmc.LOGINFO)

            if xbmcvfs.exists(var.chk_blueballs):
                try:
                    with open(var.path_blueballs,'r') as f:
                        data = f.read()

                    client = data.replace(var.client_am,var.blueballs_client).replace(var.secret_am,var.blueballs_secret)

                    with open(var.path_blueballs,'w') as f:
                        f.write(client)
                except:
                    xbmc.log('%s: Traktit.py Revoke API Blue Balls Failed!' % var.amgr, xbmc.LOGINFO)

            if xbmcvfs.exists(var.chk_twisted):
                try:
                    with open(var.path_twisted,'r') as f:
                        data = f.read()

                    client = data.replace(var.client_am,var.twisted_client).replace(var.secret_am,var.twisted_secret)

                    with open(var.path_twisted,'w') as f:
                        f.write(client)
                except:
                    xbmc.log('%s: Traktit.py Revoke API Twisted Failed!' % var.amgr, xbmc.LOGINFO)

            if xbmcvfs.exists(var.chk_base):
                try:
                    with open(var.path_base,'r') as f:
                        data = f.read()

                    client = data.replace(var.client_am,var.base_client).replace(var.secret_am,var.base_secret)

                    with open(var.path_base,'w') as f:
                        f.write(client)
                except:
                    xbmc.log('%s: Traktit.py Revoke API Base Failed!' % var.amgr, xbmc.LOGINFO)

            if xbmcvfs.exists(var.chk_chains):
                try:
                    with open(var.path_chains,'r') as f:
                        data = f.read()

                    client = data.replace(var.client_am,var.chains_client).replace(var.secret_am,var.chains_secret)

                    with open(var.path_chains,'w') as f:
                        f.write(client)
                except:
                    xbmc.log('%s: Traktit.py Revoke API Chain Reaction Failed!' % var.amgr, xbmc.LOGINFO)

            if xbmcvfs.exists(var.chk_asgard):
                try:
                    with open(var.path_asgard,'r') as f:
                        data = f.read()

                    client = data.replace(var.client_am,var.asgard_client).replace(var.secret_am,var.asgard_secret)

                    with open(var.path_asgard,'w') as f:
                        f.write(client)
                except:
                    xbmc.log('%s: Traktit.py Revoke API Asgard Failed!' % var.amgr, xbmc.LOGINFO)

            if xbmcvfs.exists(var.chk_patriot):
                try:
                    with open(var.path_patriot,'r') as f:
                        data = f.read()

                    client = data.replace(var.client_am,var.patriot_client).replace(var.secret_am,var.patriot_secret)

                    with open(var.path_patriot,'w') as f:
                        f.write(client)
                except:
                    xbmc.log('%s: Traktit.py Revoke API Patriot Failed!' % var.amgr, xbmc.LOGINFO)

            if xbmcvfs.exists(var.chk_blackl):
                try:
                    with open(var.path_blackl,'r') as f:
                        data = f.read()

                    client = data.replace(var.client_am,var.blackl_client).replace(var.secret_am,var.blackl_secret)

                    with open(var.path_blackl,'w') as f:
                        f.write(client)
                except:
                    xbmc.log('%s: Traktit.py Revoke API Black Lightning Failed!' % var.amgr, xbmc.LOGINFO)

            if xbmcvfs.exists(var.chk_tmdbmovies):
                try:
                    with open(_tmdbmovies_config(),'r') as f:
                        data = f.read()

                    client = data.replace(var.client_am,var.tmdbmovies_client).replace(var.secret_am,var.tmdbmovies_secret)

                    with open(_tmdbmovies_config(),'w') as f:
                        f.write(client)
                except:
                    xbmc.log('%s: Traktit.py Revoke API TMDb Movies Failed!' % var.amgr, xbmc.LOGINFO)

            if xbmcvfs.exists(var.chk_aliunde):
                try:
                    with open(var.path_aliunde,'r') as f:
                        data = f.read()

                    client = data.replace(var.client_am,var.aliunde_client).replace(var.secret_am,var.aliunde_secret)

                    with open(var.path_aliunde,'w') as f:
                        f.write(client)
                except:
                    xbmc.log('%s: Traktit.py Revoke API Aliunde Failed!' % var.amgr, xbmc.LOGINFO)

            if xbmcvfs.exists(var.chk_gratisred):
                try:
                    with open(var.path_gratisred,'r') as f:
                        data = f.read()

                    client = data.replace(var.client_am,var.gratisred_client).replace(var.secret_am,var.gratisred_secret)

                    with open(var.path_gratisred,'w') as f:
                        f.write(client)
                except:
                    xbmc.log('%s: Traktit.py Revoke API GratisRed Failed!' % var.amgr, xbmc.LOGINFO)

            if xbmcvfs.exists(var.chk_genocide):
                try:
                    with open(var.path_genocide,'r') as f:
                        data = f.read()

                    client = data.replace(var.client_am,var.genocide_client).replace(var.secret_am,var.genocide_secret)

                    with open(var.path_genocide,'w') as f:
                        f.write(client)
                except:
                    xbmc.log('%s: Traktit.py Revoke API Chains Genocide Failed!' % var.amgr, xbmc.LOGINFO)

            if xbmcvfs.exists(var.chk_newgenocide):
                try:
                    with open(var.path_newgenocide,'r') as f:
                        data = f.read()

                    client = data.replace(var.client_am,var.genocide_client).replace(var.secret_am,var.genocide_secret)

                    with open(var.path_newgenocide,'w') as f:
                        f.write(client)
                except:
                    xbmc.log('%s: Traktit.py Revoke API Genocide Failed!' % var.amgr, xbmc.LOGINFO)

            if xbmcvfs.exists(var.chk_crew):
                try:
                    with open(var.path_crew,'r') as f:
                        data = f.read()

                    client = _crew_restore(data).replace(var.client_am,var.crew_client).replace(var.secret_am,var.crew_secret)

                    with open(var.path_crew,'w') as f:
                        f.write(client)
                except:
                    xbmc.log('%s: Traktit.py Revoke API The Crew Failed!' % var.amgr, xbmc.LOGINFO)

            if xbmcvfs.exists(var.chk_scrubs):
                try:
                    with open(var.path_scrubs,'r') as f:
                        data = f.read()

                    client = data.replace(var.client_am,var.scrubs_client).replace(var.secret_am,var.scrubs_secret)

                    with open(var.path_scrubs,'w') as f:
                        f.write(client)
                except:
                    xbmc.log('%s: Traktit.py Revoke API Scrubs V2 Failed!' % var.amgr, xbmc.LOGINFO)

            if xbmcvfs.exists(var.chk_tmdbh):
                try:
                    with open(var.path_tmdbh,'r') as f:
                        data = f.read()

                    client = data.replace(var.client_am,var.tmdbh_client).replace(var.secret_am,var.tmdbh_secret)

                    with open(var.path_tmdbh,'w') as f:
                        f.write(client)
                except:
                    xbmc.log('%s: Traktit.py Revoke API TMDbH Failed!' % var.amgr, xbmc.LOGINFO)

            if xbmcvfs.exists(var.chk_trakt):
                try:
                    with open(var.path_trakt,'r') as f:
                        data = f.read()

                    client = _traktaddon_restore(data).replace(var.client_am,var.trakt_client).replace(var.secret_am,var.trakt_secret)

                    with open(var.path_trakt,'w') as f:
                        f.write(client)
                except:
                    xbmc.log('%s: Traktit.py Revoke API Trakt Addon Failed!' % var.amgr, xbmc.LOGINFO)

            if xbmcvfs.exists(var.chk_allaccounts):
                try:
                    with open(var.path_allaccounts,'r') as f:
                        data = f.read()

                    client = data.replace(var.client_am,var.allacts_client).replace(var.secret_am,var.allacts_secret)

                    with open(var.path_allaccounts,'w') as f:
                        f.write(client)
                except:
                    xbmc.log('%s: Traktit.py Revoke API All Accounts Failed!' % var.amgr, xbmc.LOGINFO)

            if xbmcvfs.exists(var.chk_myaccounts):
                try:
                    with open(var.path_myaccounts,'r') as f:
                        data = f.read()

                    client = data.replace(var.client_am,var.myacts_client).replace(var.secret_am,var.myacts_secret)

                    with open(var.path_myaccounts,'w') as f:
                        f.write(client)
                except:
                    xbmc.log('%s: Traktit.py Revoke API My Accounts Failed!' % var.amgr, xbmc.LOGINFO)

            traktit.trakt_it_revoke('clearaddon', name)
            var.delete_synclist()
            accountmgr.setSetting("trakt.synclist", 'false')
            accountmgr.setSetting("sync.tk.service", "false")
            xbmcgui.Dialog().notification('ReAuthorize', 'All Add-ons Revoked!', trakt_icon, 3000)
            xbmc.sleep(3000)
            _close_kodi_or_later()
        elif mode == 'cleartrakt':  # Clear All Saved Trakt Data
            try:
                if xbmcvfs.exists(var.trakt_backup): # Skip clearing data if no Trakt folder present in backup folder
                    path = os.listdir(var.trakt_backup)
                    if len(path) != 0: # Skip clearing data if no saved data in backup folder
                        accountmgr.setSetting('tk_backup_date', 'Date: 0000-00-00   Time: 00:00')
                        data = os.listdir(var.trakt_backup)
                        for file in data:
                            files = os.path.join(var.trakt_backup, file)
                            if os.path.isfile(files):
                                os.remove(files)
                        xbmcgui.Dialog().notification('ReAuthorize', 'Trakt Data Cleared!', trakt_icon, 3000)
                    else:
                        xbmcgui.Dialog().notification('ReAuthorize', 'No Trakt Data to Clear!', trakt_icon, 3000)
                        xbmc.sleep(3000)
                        xbmc.executebuiltin('Dialog.Close(all,true)')
                        xbmc.executebuiltin('Addon.OpenSettings(script.module.reauthorize)')
                else:
                    xbmcgui.Dialog().notification('ReAuthorize', 'No Trakt Data to Clear!', trakt_icon, 3000)
                    xbmc.sleep(3000)
                    xbmc.executebuiltin('Dialog.Close(all,true)')
                    xbmc.executebuiltin('Addon.OpenSettings(script.module.reauthorize)')
            except:
                xbmc.log('%s: Router.py Clear Trakt Failed!' % var.amgr, xbmc.LOGINFO)

        # DEBRID MANAGER RD
        elif mode == 'addondebrid_rd':  # Clear All Addon Debrid Data
            debridit_rd.debrid_it('wipeaddon', name)
            accountmgr.setSetting("sync.rd.service", "false")
            jsonit.realizer_rvk()
            xbmcgui.Dialog().notification('ReAuthorize', 'All Add-ons Revoked!', rd_icon, 3000)

        # DEBRID MANAGER PM
        elif mode == 'addondebrid_pm':  # Clear All Addon Debrid Data
            debridit_pm.debrid_it('wipeaddon', name)
            accountmgr.setSetting("sync.pm.service", "false")
            xbmcgui.Dialog().notification('ReAuthorize', 'All Add-ons Revoked!', pm_icon, 3000)

        # DEBRID MANAGER AD
        elif mode == 'addondebrid_ad':  # Clear All Addon Debrid Data
            debridit_ad.debrid_it('wipeaddon', name)
            accountmgr.setSetting("sync.ad.service", "false")
            xbmcgui.Dialog().notification('ReAuthorize', 'All Add-ons Revoked!', ad_icon, 3000)

        # TORBOX MANAGER
        elif mode == 'savetorbox':  # Save Data
            tbit.tb_it('update', name)
        elif mode == 'addontb':  # Clear All Addon OffCloud Data
            tbit.tb_it('wipeaddon', name)
            accountmgr.setSetting("sync.torbox.service", "false")
            xbmcgui.Dialog().notification('ReAuthorize', 'All Add-ons Revoked!', torbox_icon, 3000)

        # EASY DEBRID MANAGER
        elif mode == 'saveeasydebrid':  # Save Data
            edit.ed_it('update', name)
        elif mode == 'addoned':  # Clear All Addon OffCloud Data
            edit.ed_it('wipeaddon', name)
            accountmgr.setSetting("sync.eastd.service", "false")
            xbmcgui.Dialog().notification('ReAuthorize', 'All Add-ons Revoked!', easyd_icon, 3000)

        # OFFCLOUD MANAGER
        elif mode == 'saveoffcloud':  # Save Data
            offit.offc_it('update', name)
        elif mode == 'addonoffc':  # Clear All Addon OffCloud Data
            offit.offc_it('wipeaddon', name)
            accountmgr.setSetting("sync.offc.service", "false")
            xbmcgui.Dialog().notification('ReAuthorize', 'All Add-ons Revoked!', offcloud_icon, 3000)

        # EASYNEWS MANAGER
        elif mode == 'addoneasy':  # Clear All Addon Easynews Data
            easyit.easy_it('wipeaddon', name)
            accountmgr.setSetting("sync.easy.service", "false")
            xbmcgui.Dialog().notification('ReAuthorize', 'All Add-ons Revoked!', easy_icon, 3000)

        # FILEPURSUIT MANAGER
        elif mode == 'addonfile':  # Clear All Addon Filepursuit Data
            fileit.filep_it('wipeaddon', name)
            accountmgr.setSetting("sync.filep.service", "false")
            xbmcgui.Dialog().notification('ReAuthorize', 'All Add-ons Revoked!', file_icon, 3000)

        #EXTERNAL PROVIDERS MANAGER

        #META DATA MANAGER

        #REVOKE ALL DEBRID ACCOUNTS

        #BACKUP ALL DEBRID ACCOUNTS

        #RESTORE ALL DEBRID ACCOUNTS

        #CLEAR ALL SAVED DATA FOR DEBRID ACCOUNTS

        # REVOKE/WIPE/CLEAN ALL ADD-ONS
        elif mode == 'wipeclean':  # Revoke all Add-ons, Clear all saved data, and restore stock API Keys for all add-ons
            xbmcgui.Dialog().notification('ReAuthorize', 'Restoring default settings, please wait!', amgr_icon, 3000)
            try:
                #Revoke Trakt
                if accountmgr.getSetting('trakt.token') != '':
                    #Revoke Account Manager/Custom API keys for all add-ons
                    if xbmcvfs.exists(var.chk_seren): #Check if add-on is installed
                        try:
                            with open(var.path_seren,'r') as f:
                                data = f.read()

                            client = data.replace(var.client_am,var.seren_client).replace(var.secret_am,var.seren_secret)

                            with open(var.path_seren,'w') as f:
                                f.write(client)
                        except:
                            xbmc.log('%s: Traktit.py Revoke API Seren Failed!' % var.amgr, xbmc.LOGINFO)

                    if xbmcvfs.exists(var.chk_coal):
                        try:
                            with open(var.path_coal,'r') as f:
                                data = f.read()

                            client = data.replace(var.client_am,var.coal_client).replace(var.secret_am,var.coal_secret)

                            with open(var.path_coal,'w') as f:
                                f.write(client)
                        except:
                            xbmc.log('%s: Traktit.py Revoke API Coalition Failed!' % var.amgr, xbmc.LOGINFO)

                    if xbmcvfs.exists(var.chk_pov):
                        try:
                            addon = xbmcaddon.Addon("plugin.video.pov")
                            addon.setSetting("trakt.client_id", var.pov_client)
                            addon.setSetting("trakt.client_secret", var.pov_secret)
                        except:
                            xbmc.log('%s: Traktit.py Revoke API POV Failed!' % var.amgr, xbmc.LOGINFO)

                    if xbmcvfs.exists(var.chk_shadow):
                        try:
                            with open(var.path_shadow,'r') as f:
                                data = f.read()

                            client = data.replace(var.client_am,var.shadow_client).replace(var.secret_am,var.shadow_secret)

                            with open(var.path_shadow,'w') as f:
                                f.write(client)
                        except:
                            xbmc.log('%s: Traktit.py Revoke API Shadow Failed!' % var.amgr, xbmc.LOGINFO)

                    if xbmcvfs.exists(var.chk_ghost):
                        try:
                            with open(var.path_ghost,'r') as f:
                                data = f.read()

                            client = data.replace(var.client_am,var.ghost_client).replace(var.secret_am,var.ghost_secret)

                            with open(var.path_ghost,'w') as f:
                                f.write(client)
                        except:
                            xbmc.log('%s: Traktit.py Revoke API Ghost Failed!' % var.amgr, xbmc.LOGINFO)

                    if xbmcvfs.exists(var.chk_blueballs):
                        try:
                            with open(var.path_blueballs,'r') as f:
                                data = f.read()

                            client = data.replace(var.client_am,var.blueballs_client).replace(var.secret_am,var.blueballs_secret)

                            with open(var.path_blueballs,'w') as f:
                                f.write(client)
                        except:
                            xbmc.log('%s: Traktit.py Revoke API Blue Balls Failed!' % var.amgr, xbmc.LOGINFO)

                    if xbmcvfs.exists(var.chk_twisted):
                        try:
                            with open(var.path_twisted,'r') as f:
                                data = f.read()

                            client = data.replace(var.client_am,var.twisted_client).replace(var.secret_am,var.twisted_secret)

                            with open(var.path_twisted,'w') as f:
                                f.write(client)
                        except:
                            xbmc.log('%s: Traktit.py Revoke API Twisted Failed!' % var.amgr, xbmc.LOGINFO)

                    if xbmcvfs.exists(var.chk_base):
                        try:
                            with open(var.path_base,'r') as f:
                                data = f.read()

                            client = data.replace(var.client_am,var.base_client).replace(var.secret_am,var.base_secret)

                            with open(var.path_base,'w') as f:
                                f.write(client)
                        except:
                            xbmc.log('%s: Traktit.py Revoke API Base Failed!' % var.amgr, xbmc.LOGINFO)

                    if xbmcvfs.exists(var.chk_chains):
                        try:
                            with open(var.path_chains,'r') as f:
                                data = f.read()

                            client = data.replace(var.client_am,var.chains_client).replace(var.secret_am,var.chains_secret)

                            with open(var.path_chains,'w') as f:
                                f.write(client)
                        except:
                            xbmc.log('%s: Traktit.py Revoke API Chain Reaction Failed!' % var.amgr, xbmc.LOGINFO)

                    if xbmcvfs.exists(var.chk_asgard):
                        try:
                            with open(var.path_asgard,'r') as f:
                                data = f.read()

                            client = data.replace(var.client_am,var.asgard_client).replace(var.secret_am,var.asgard_secret)

                            with open(var.path_asgard,'w') as f:
                                f.write(client)
                        except:
                            xbmc.log('%s: Traktit.py Revoke API Asgard Failed!' % var.amgr, xbmc.LOGINFO)

                    if xbmcvfs.exists(var.chk_patriot):
                        try:
                            with open(var.path_patriot,'r') as f:
                                data = f.read()

                            client = data.replace(var.client_am,var.patriot_client).replace(var.secret_am,var.patriot_secret)

                            with open(var.path_patriot,'w') as f:
                                f.write(client)
                        except:
                            xbmc.log('%s: Traktit.py Revoke API Patriot Failed!' % var.amgr, xbmc.LOGINFO)

                    if xbmcvfs.exists(var.chk_blackl):
                        try:
                            with open(var.path_blackl,'r') as f:
                                data = f.read()

                            client = data.replace(var.client_am,var.blackl_client).replace(var.secret_am,var.blackl_secret)

                            with open(var.path_blackl,'w') as f:
                                f.write(client)
                        except:
                            xbmc.log('%s: Traktit.py Revoke API Black Lightning Failed!' % var.amgr, xbmc.LOGINFO)

                    if xbmcvfs.exists(var.chk_tmdbmovies):
                        try:
                            with open(_tmdbmovies_config(),'r') as f:
                                data = f.read()

                            client = data.replace(var.client_am,var.tmdbmovies_client).replace(var.secret_am,var.tmdbmovies_secret)

                            with open(_tmdbmovies_config(),'w') as f:
                                f.write(client)
                        except:
                            xbmc.log('%s: Traktit.py Revoke API TMDb Movies Failed!' % var.amgr, xbmc.LOGINFO)

                    if xbmcvfs.exists(var.chk_newgenocide):
                        try:
                            with open(var.path_newgenocide,'r') as f:
                                data = f.read()

                            client = data.replace(var.client_am,var.genocide_client).replace(var.secret_am,var.genocide_secret)

                            with open(var.path_newgenocide,'w') as f:
                                f.write(client)
                        except:
                            xbmc.log('%s: Traktit.py Revoke API Genocide Failed!' % var.amgr, xbmc.LOGINFO)

                    if xbmcvfs.exists(var.chk_aliunde):
                        try:
                            with open(var.path_aliunde,'r') as f:
                                data = f.read()

                            client = data.replace(var.client_am,var.aliunde_client).replace(var.secret_am,var.aliunde_secret)

                            with open(var.path_aliunde,'w') as f:
                                f.write(client)
                        except:
                            xbmc.log('%s: Traktit.py Revoke API Aliunde Failed!' % var.amgr, xbmc.LOGINFO)

                    if xbmcvfs.exists(var.chk_gratisred):
                        try:
                            with open(var.path_gratisred,'r') as f:
                                data = f.read()

                            client = data.replace(var.client_am,var.gratisred_client).replace(var.secret_am,var.gratisred_secret)

                            with open(var.path_gratisred,'w') as f:
                                f.write(client)
                        except:
                            xbmc.log('%s: Traktit.py Revoke API GratisRed Failed!' % var.amgr, xbmc.LOGINFO)

                    if xbmcvfs.exists(var.chk_crew):
                        try:
                            with open(var.path_crew,'r') as f:
                                data = f.read()

                            client = _crew_restore(data).replace(var.client_am,var.crew_client).replace(var.secret_am,var.crew_secret)

                            with open(var.path_crew,'w') as f:
                                f.write(client)
                        except:
                            xbmc.log('%s: Traktit.py Revoke API The Crew Failed!' % var.amgr, xbmc.LOGINFO)

                    if xbmcvfs.exists(var.chk_scrubs):
                        try:
                            with open(var.path_scrubs,'r') as f:
                                data = f.read()

                            client = data.replace(var.client_am,var.scrubs_client).replace(var.secret_am,var.scrubs_secret)

                            with open(var.path_scrubs,'w') as f:
                                f.write(client)
                        except:
                            xbmc.log('%s: Traktit.py Revoke API Scrubs V2 Failed!' % var.amgr, xbmc.LOGINFO)

                    if xbmcvfs.exists(var.chk_tmdbh):
                        try:
                            with open(var.path_tmdbh,'r') as f:
                                data = f.read()

                            client = data.replace(var.client_am,var.tmdbh_client).replace(var.secret_am,var.tmdbh_secret)

                            with open(var.path_tmdbh,'w') as f:
                                f.write(client)
                        except:
                            xbmc.log('%s: Traktit.py Revoke API TMDbH Failed!' % var.amgr, xbmc.LOGINFO)

                    if xbmcvfs.exists(var.chk_trakt):
                        try:
                            with open(var.path_trakt,'r') as f:
                                data = f.read()

                            client = _traktaddon_restore(data).replace(var.client_am,var.trakt_client).replace(var.secret_am,var.trakt_secret)

                            with open(var.path_trakt,'w') as f:
                                f.write(client)
                        except:
                            xbmc.log('%s: Traktit.py Revoke API Trakt Addon Failed!' % var.amgr, xbmc.LOGINFO)

                    if xbmcvfs.exists(var.chk_allaccounts):
                        try:
                            with open(var.path_allaccounts,'r') as f:
                                data = f.read()

                            client = data.replace(var.client_am,var.allacts_client).replace(var.secret_am,var.allacts_secret)

                            with open(var.path_allaccounts,'w') as f:
                                f.write(client)
                        except:
                            xbmc.log('%s: Traktit.py Revoke API All Accounts Failed!' % var.amgr, xbmc.LOGINFO)

                    if xbmcvfs.exists(var.chk_myaccounts):
                        try:
                            with open(var.path_myaccounts,'r') as f:
                                data = f.read()

                            client = data.replace(var.client_am,var.myacts_client).replace(var.secret_am,var.myacts_secret)

                            with open(var.path_myaccounts,'w') as f:
                                f.write(client)
                        except:
                            xbmc.log('%s: Traktit.py Revoke API My Accounts Failed!' % var.amgr, xbmc.LOGINFO)

                    traktit.trakt_it_revoke('wipeaddon', name)
                    accountmgr.setSetting("sync.tk.service", "false")

                #Revoke Real-Debrid
                if accountmgr.getSetting('realdebrid.token') != '':
                    debridit_rd.debrid_it('wipeaddon', name)
                    accountmgr.setSetting("sync.rd.service", "false")
                    jsonit.realizer_rvk()

                #Revoke Premiumize
                if accountmgr.getSetting('premiumize.token') != '':
                    debridit_pm.debrid_it('wipeaddon', name)
                    accountmgr.setSetting("sync.pm.service", "false")

                #Revoke All-Debrid
                if accountmgr.getSetting('alldebrid.token') != '':
                    debridit_ad.debrid_it('wipeaddon', name)
                    accountmgr.setSetting("sync.ad.service", "false")

                #Revoke TorBox
                if not str(var.setting('torbox.token')) == '':
                    tbit.tb_it('wipeaddon', name)
                    accountmgr.setSetting("sync.torbox.service", "false")
                    accountmgr.setSetting("torbox.enabled", 'false')

                #Revoke Easy Debrid
                if not str(var.setting('easydebrid.token')) == '':
                    edit.ed_it('wipeaddon', name)
                    accountmgr.setSetting("sync.easyd.service", "false")
                    accountmgr.setSetting("easydebrid.enabled", 'false')

                #Revoke OffCloud
                if not str(var.setting('offcloud.token')) == '':
                    offit.offc_it('wipeaddon', name)
                    accountmgr.setSetting("sync.offc.service", "false")
                    accountmgr.setSetting("offcloud.enabled", 'false')

                #Revoke Easynews
                if not str(var.setting('easynews.password')) == '':
                    easyit.easy_it('wipeaddon', name)
                    accountmgr.setSetting("sync.easy.service", "false")
                    accountmgr.setSetting("easynews.enabled", 'false')

                #Revoke Filepursuit
                if not str(var.setting('filepursuit.api.key')) == '':
                    fileit.filep_it('wipeaddon', name)
                    accountmgr.setSetting("sync.filep.service", "false")
                    accountmgr.setSetting("filepursuit.enabled", 'false')

                #Revoke External Providers
                if not str(var.setting('ext.provider')) == '':
                    extit.ext_it('wipeaddon', name)
                    accountmgr.setSetting("sync.ext.service", "false")
                    accountmgr.setSetting("ext.provider", '')

                #Revoke Metadata
                if str(var.setting('fanart.tv.api.key')) != '' or str(var.setting('omdb.api.key')) != '' or str(var.setting('mdb.api.key')) != '' or str(var.setting('imdb.user')) != '' or str(var.setting('tvdb.api.key')) != '' or str(var.setting('tmdb.api.key')) != '' or str(var.setting('tmdb.username')) != '' or str(var.setting('tmdb.password')) != '' or str(var.setting('tmdb.session_id')) != '':
                    metait_all.debrid_it('wipeaddon', name)
                    accountmgr.setSetting("sync.meta.service", "false")
                    xbmc.executebuiltin("Skin.Reset(mdblist_api_key)")
                    accountmgr.setSetting("meta.enabled", 'false')


                #Clear Trakt Saved Data
                if xbmcvfs.exists(var.trakt_backup): # Skip clearing data if no folder present in backup folder
                    path = os.listdir(var.trakt_backup)
                    if len(path) != 0: # Skip clearing data if no saved data in backup folder
                        data = os.listdir(var.trakt_backup)
                        for file in data:
                            files = os.path.join(var.trakt_backup, file)
                            if os.path.isfile(files):
                                os.remove(files)

                #Clear Real-Debrid Saved Data
                if xbmcvfs.exists(var.rd_backup): # Skip clearing data if no folder present in backup folder
                    path = os.listdir(var.rd_backup)
                    if len(path) != 0: # Skip clearing data if no saved data in backup folder
                        data = os.listdir(var.rd_backup)
                        for file in data:
                            files = os.path.join(var.rd_backup, file)
                            if os.path.isfile(files):
                                os.remove(files)

                #Clear Premiumize Saved Data
                if xbmcvfs.exists(var.pm_backup): # Skip clearing data if no folder present in backup folder
                    path = os.listdir(var.pm_backup)
                    if len(path) != 0: # Skip clearing data if no saved data in backup folder
                        data = os.listdir(var.pm_backup)
                        for file in data:
                            files = os.path.join(var.pm_backup, file)
                            if os.path.isfile(files):
                                os.remove(files)

                #Clear All-Debrid Saved Data
                if xbmcvfs.exists(var.ad_backup): # Skip clearing data if no folder present in backup folder
                    path = os.listdir(var.ad_backup)
                    if len(path) != 0: # Skip clearing data if no saved data in backup folder
                        data = os.listdir(var.ad_backup)
                        for file in data:
                            files = os.path.join(var.ad_backup, file)
                            if os.path.isfile(files):
                                os.remove(files)

                #Clear TorBox Saved Data
                if xbmcvfs.exists(var.tb_backup): # Skip clearing data if no folder present in backup folder
                    path = os.listdir(var.tb_backup)
                    if len(path) != 0: # Skip clearing data if no saved data in backup folder
                        data = os.listdir(var.tb_backup)
                        for file in data:
                            files = os.path.join(var.tb_backup, file)
                            if os.path.isfile(files):
                                os.remove(files)

                #Clear Easy Debrid Saved Data
                if xbmcvfs.exists(var.ed_backup): # Skip clearing data if no folder present in backup folder
                    path = os.listdir(var.ed_backup)
                    if len(path) != 0: # Skip clearing data if no saved data in backup folder
                        data = os.listdir(var.ed_backup)
                        for file in data:
                            files = os.path.join(var.ed_backup, file)
                            if os.path.isfile(files):
                                os.remove(files)

                #Clear OffCloud Saved Data
                if xbmcvfs.exists(var.offc_backup): # Skip clearing data if no folder present in backup folder
                    path = os.listdir(var.offc_backup)
                    if len(path) != 0: # Skip clearing data if no saved data in backup folder
                        data = os.listdir(var.offc_backup)
                        for file in data:
                            files = os.path.join(var.offc_backup, file)
                            if os.path.isfile(files):
                                os.remove(files)

                #Clear Easynews Saved Data
                if xbmcvfs.exists(var.easy_backup): # Skip clearing data if no folder present in backup folder
                    path = os.listdir(var.easy_backup)
                    if len(path) != 0: # Skip clearing data if no saved data in backup folder
                        data = os.listdir(var.easy_backup)
                        for file in data:
                            files = os.path.join(var.easy_backup, file)
                            if os.path.isfile(files):
                                os.remove(files)

                #Clear Filepursuit Saved Data
                if xbmcvfs.exists(var.file_backup): # Skip clearing data if no folder present in backup folder
                    path = os.listdir(var.file_backup)
                    if len(path) != 0: # Skip clearing data if no saved data in backup folder
                        data = os.listdir(var.file_backup)
                        for file in data:
                            files = os.path.join(var.file_backup, file)
                            if os.path.isfile(files):
                                os.remove(files)

                #Clear External Providers Saved Data
                if xbmcvfs.exists(var.ext_backup): # Skip clearing data if no folder present in backup folder
                    path = os.listdir(var.ext_backup)
                    if len(path) != 0: # Skip clearing data if no saved data in backup folder
                        data = os.listdir(var.ext_backup)
                        for file in data:
                            files = os.path.join(var.ext_backup, file)
                            if os.path.isfile(files):
                                os.remove(files)

                #Clear Metadata Saved Data
                if xbmcvfs.exists(var.meta_backup): # Skip clearing data if no folder present in backup folder
                    path = os.listdir(var.meta_backup)
                    if len(path) != 0: # Skip clearing data if no saved data in backup folder
                        data = os.listdir(var.meta_backup)
                        for file in data:
                            files = os.path.join(var.meta_backup, file)
                            if os.path.isfile(files):
                                os.remove(files)
                xbmc.executebuiltin('Dialog.Close(all,true)')
                xbmc.sleep(1000)
                var.remake_settings() #Refresh settings database

            except:
                xbmc.log('%s: Router.py Revoke/Wipe/Clean Account Manager Failed!' % var.amgr, xbmc.LOGINFO)

            xbmcgui.Dialog().ok('ReAuthorize', 'All settings have been restored to default.')

    def _finish(self, handle):
        from libs.common import directory

        directory.set_view()

        xbmcplugin.setContent(handle, 'files')
        xbmcplugin.endOfDirectory(handle)
