# -*- coding: utf-8 -*-
from lib.plugin import main

# See bottom of Plugin.py.
main()
