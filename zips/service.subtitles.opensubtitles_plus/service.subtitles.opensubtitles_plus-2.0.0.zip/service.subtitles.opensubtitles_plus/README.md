In order to get the API Key:

1. Go to url - https://www.opensubtitles.com
2. Register/Login
3. On the top of the page press on the "User" logo -> API consumers -> New Consumer button
4. Give it a Name, (Recommended) checked both: 'Allow anonymous downloads' and 'Under dev'
5. Save
6. Then you will see your API details, copy the API Key and put it in addon's settings with your Username and Password.
