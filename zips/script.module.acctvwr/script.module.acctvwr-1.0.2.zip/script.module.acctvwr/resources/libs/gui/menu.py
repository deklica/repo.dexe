import xbmc, xbmcaddon, xbmcvfs
import os
from urllib.parse import quote_plus
from urllib.request import urlretrieve

from resources.libs import acct_vwr
from resources.libs.common import directory
from resources.libs.common.config import CONFIG

# Variables
translatePath = xbmcvfs.translatePath
addons = translatePath('special://home/addons/')
addon_id = 'script.module.acctmgr'

# Scraper Variables
coco_plugin_id = 'script.module.cocoscrapers'
coco_mod_plugin_id = 'script.module.cocoscrapersmod'
mag_plugin_id = 'script.module.magneto'
mag_mod_plugin_id = 'script.module.magnetomod'
viper_plugin_id = 'script.module.viperscrapers'

def trakt_menu():
    for trakt in acct_vwr.ORDER:
        # Filter only addons that support Trakt
        if not acct_vwr.ADDONS[trakt].get('default_tk'):
            continue
        if not xbmc.getCondVisibility('System.HasAddon({0})'.format(acct_vwr.ADDONS[trakt]['plugin'])):
            pass
        else:
            if xbmc.getCondVisibility('System.HasAddon({0})'.format(acct_vwr.ADDONS[trakt]['plugin'])):
                name = acct_vwr.ADDONS[trakt]['name']
                path = acct_vwr.ADDONS[trakt]['path']
                auser = acct_vwr.addon_user(trakt, 'tk')
                set_user = acct_vwr.ADDONS[trakt]['name']
                icon = acct_vwr.ADDONS[trakt]['icon'] if os.path.exists(path) else CONFIG.ICON
                fanart = acct_vwr.ADDONS[trakt]['fanart'] if os.path.exists(path) else CONFIG.ADDON_FANART
                menu = create_addon_data_menu('Trakt', trakt)
                menu.append((CONFIG.THEME1.format('{0} Settings'.format(name)),
                             'RunPlugin(plugin://{0}/?mode=opensettings&name={1}&url=trakt)'.format(CONFIG.ADDON_ID, trakt)))

                if not auser:
                    directory.add_file('{0} - [COLOR red]Not Authorized[/COLOR]'.format(name), {'name': trakt}, icon=icon, description='Your Trakt Authorizations', fanart=fanart, themeit=CONFIG.THEME2)
                else:
                    directory.add_file('{0} - [COLOR springgreen]Authorized[/COLOR]'.format(name), {'name': trakt}, icon=icon, description='Your Trakt Authorizations', fanart=fanart, themeit=CONFIG.THEME2)

                if name == 'Fen Light':
                    directory.add_file('[COLOR blue]Open [COLOR dodgerblue]Fen Light[/COLOR] Settings[/COLOR]', {'mode': 'opensettings_fenlt', 'name': 'Fen Light'}, icon=icon, fanart=fanart, menu=menu)
                elif name == 'Gears':
                    directory.add_file('[COLOR blue]Open [COLOR dodgerblue]Gears[/COLOR] Settings[/COLOR]', {'mode': 'opensettings_gears', 'name': 'Gears'}, icon=icon, fanart=fanart, menu=menu)
                else:
                    directory.add_file('[COLOR blue]Open [COLOR dodgerblue]{0}[/COLOR] Settings[/COLOR]'.format(set_user), {'mode': 'opensettings_tk', 'name': trakt}, icon=icon, fanart=fanart, menu=menu)
                directory.add_separator()

def debrid_menu():
    for debrid in acct_vwr.ORDER:
        # Filter only addons that support Real-Debrid
        if not acct_vwr.ADDONS[debrid].get('default_rd'):
            continue
        if not xbmc.getCondVisibility('System.HasAddon({0})'.format(acct_vwr.ADDONS[debrid]['plugin'])):
            pass
        else:
            if xbmc.getCondVisibility('System.HasAddon({0})'.format(acct_vwr.ADDONS[debrid]['plugin'])):
                name = acct_vwr.ADDONS[debrid]['name']
                path = acct_vwr.ADDONS[debrid]['path']
                auser = acct_vwr.addon_user(debrid, 'rd')
                set_user = acct_vwr.ADDONS[debrid]['name']
                icon = acct_vwr.ADDONS[debrid]['icon'] if os.path.exists(path) else CONFIG.ICON
                fanart = acct_vwr.ADDONS[debrid]['fanart'] if os.path.exists(path) else CONFIG.ADDON_FANART
                menu = create_addon_data_menu('Debrid', debrid)
                menu.append((CONFIG.THEME1.format('{0} Settings'.format(name)),
                             'RunPlugin(plugin://{0}/?mode=opensettings&name={1}&url=debrid)'.format(CONFIG.ADDON_ID, debrid)))

                if not auser:
                    directory.add_file('{0} - [COLOR red]Not Authorized[/COLOR]'.format(name), {'name': debrid}, icon=icon, description='Your Real-Debrid Authorizations', fanart=fanart, themeit=CONFIG.THEME2)
                else:
                    directory.add_file('{0} - [COLOR springgreen]Authorized[/COLOR]'.format(name), {'name': debrid}, icon=icon, description='Your Real-Debrid Authorizations', fanart=fanart, themeit=CONFIG.THEME2)

                if name == 'Fen Light':
                    directory.add_file('[COLOR blue]Open [COLOR dodgerblue]Fen Light[/COLOR] Settings[/COLOR]', {'mode': 'opensettings_fenlt', 'name': 'Fen Light'}, icon=icon, fanart=fanart, menu=menu)
                elif name == 'Gears':
                    directory.add_file('[COLOR blue]Open [COLOR dodgerblue]Gears[/COLOR] Settings[/COLOR]', {'mode': 'opensettings_gears', 'name': 'Gears'}, icon=icon, fanart=fanart, menu=menu)
                else:
                    directory.add_file('[COLOR blue]Open [COLOR dodgerblue]{0}[/COLOR] Settings[/COLOR]'.format(name), {'mode': 'opensettings_rd', 'name': debrid}, icon=icon, fanart=fanart, menu=menu)
                directory.add_separator()

def premiumize_menu():
    from resources.libs import acct_vwr
    for debrid in acct_vwr.ORDER:
        # Filter only addons that support Premiumize
        if not acct_vwr.ADDONS[debrid].get('default_pm'):
            continue
        if not xbmc.getCondVisibility('System.HasAddon({0})'.format(acct_vwr.ADDONS[debrid]['plugin'])):
            pass
        else:
            if xbmc.getCondVisibility('System.HasAddon({0})'.format(acct_vwr.ADDONS[debrid]['plugin'])):
                name = acct_vwr.ADDONS[debrid]['name']
                path = acct_vwr.ADDONS[debrid]['path']
                auser = acct_vwr.addon_user(debrid, 'pm')
                set_user = acct_vwr.ADDONS[debrid]['name']
                icon = acct_vwr.ADDONS[debrid]['icon'] if os.path.exists(path) else CONFIG.ICON
                fanart = acct_vwr.ADDONS[debrid]['fanart'] if os.path.exists(path) else CONFIG.ADDON_FANART
                menu = create_addon_data_menu('Debrid', debrid)
                menu.append((CONFIG.THEME1.format('{0} Settings'.format(name)),
                             'RunPlugin(plugin://{0}/?mode=opensettings&name={1}&url=debrid)'.format(CONFIG.ADDON_ID, debrid)))

                if not auser:
                    directory.add_file('{0} - [COLOR red]Not Authorized[/COLOR]'.format(name), {'name': debrid}, icon=icon, description='Your Premiumize Authorizations', fanart=fanart, themeit=CONFIG.THEME2)
                else:
                    directory.add_file('{0} - [COLOR springgreen]Authorized[/COLOR]'.format(name), {'name': debrid}, icon=icon, description='Your Premiumize Authorizations', fanart=fanart, themeit=CONFIG.THEME2)

                if name == 'Fen Light':
                    directory.add_file('[COLOR blue]Open [COLOR dodgerblue]Fen Light[/COLOR] Settings[/COLOR]', {'mode': 'opensettings_fenlt', 'name': 'Fen Light'}, icon=icon, fanart=fanart, menu=menu)
                elif name == 'Gears':
                    directory.add_file('[COLOR blue]Open [COLOR dodgerblue]Gears[/COLOR] Settings[/COLOR]', {'mode': 'opensettings_gears', 'name': 'Gears'}, icon=icon, fanart=fanart, menu=menu)
                else:
                    directory.add_file('[COLOR blue]Open [COLOR dodgerblue]{0}[/COLOR] Settings[/COLOR]'.format(name), {'mode': 'opensettings_pm', 'name': debrid}, icon=icon, fanart=fanart, menu=menu)
                directory.add_separator()

def alldebrid_menu():
    from resources.libs import acct_vwr
    for debrid in acct_vwr.ORDER:
        # Filter only addons that support All-Debrid
        if not acct_vwr.ADDONS[debrid].get('default_ad'):
            continue
        if not xbmc.getCondVisibility('System.HasAddon({0})'.format(acct_vwr.ADDONS[debrid]['plugin'])):
            pass
        else:
            if xbmc.getCondVisibility('System.HasAddon({0})'.format(acct_vwr.ADDONS[debrid]['plugin'])):
                name = acct_vwr.ADDONS[debrid]['name']
                path = acct_vwr.ADDONS[debrid]['path']
                auser = acct_vwr.addon_user(debrid, 'ad')
                set_user = acct_vwr.ADDONS[debrid]['name']
                icon = acct_vwr.ADDONS[debrid]['icon'] if os.path.exists(path) else CONFIG.ICON
                fanart = acct_vwr.ADDONS[debrid]['fanart'] if os.path.exists(path) else CONFIG.ADDON_FANART
                menu = create_addon_data_menu('Debrid', debrid)
                menu.append((CONFIG.THEME1.format('{0} Settings'.format(name)),
                             'RunPlugin(plugin://{0}/?mode=opensettings&name={1}&url=debrid)'.format(CONFIG.ADDON_ID, debrid)))

                if not auser:
                    directory.add_file('{0} - [COLOR red]Not Authorized[/COLOR]'.format(name), {'name': debrid}, icon=icon, description='Your All-Debrid Authorizations', fanart=fanart, themeit=CONFIG.THEME2)
                else:
                    directory.add_file('{0} - [COLOR springgreen]Authorized[/COLOR]'.format(name), {'name': debrid}, icon=icon, description='Your All-Debrid Authorizations', fanart=fanart, themeit=CONFIG.THEME2)

                if name == 'Fen Light':
                    directory.add_file('[COLOR blue]Open [COLOR dodgerblue]Fen Light[/COLOR] Settings[/COLOR]', {'mode': 'opensettings_fenlt', 'name': 'Fen Light'}, icon=icon, fanart=fanart, menu=menu)
                elif name == 'Gears':
                    directory.add_file('[COLOR blue]Open [COLOR dodgerblue]Gears[/COLOR] Settings[/COLOR]', {'mode': 'opensettings_gears', 'name': 'Gears'}, icon=icon, fanart=fanart, menu=menu)
                else:
                    directory.add_file('[COLOR blue]Open [COLOR dodgerblue]{0}[/COLOR] Settings[/COLOR]'.format(name), {'mode': 'opensettings_ad', 'name': debrid}, icon=icon, fanart=fanart, menu=menu)
                directory.add_separator()

def easydebrid_menu():
    for ed in acct_vwr.ORDER:
        # Filter only addons that support Easy Debrid
        if not acct_vwr.ADDONS[ed].get('default_ed'):
            continue
        if not xbmc.getCondVisibility('System.HasAddon({0})'.format(acct_vwr.ADDONS[ed]['plugin'])):
            pass
        else:
            if xbmc.getCondVisibility('System.HasAddon({0})'.format(acct_vwr.ADDONS[ed]['plugin'])):
                name = acct_vwr.ADDONS[ed]['name']
                path = acct_vwr.ADDONS[ed]['path']
                auser = acct_vwr.addon_user(ed, 'ed')
                set_user = acct_vwr.ADDONS[ed]['name']
                icon = acct_vwr.ADDONS[ed]['icon'] if os.path.exists(path) else CONFIG.ICON
                fanart = acct_vwr.ADDONS[ed]['fanart'] if os.path.exists(path) else CONFIG.ADDON_FANART
                menu = create_addon_data_menu('Easy Debrid', ed)
                menu.append((CONFIG.THEME1.format('{0} Settings'.format(name)), 'RunPlugin(plugin://{0}/?mode=opensettings&name={1}&url=ed)'.format(CONFIG.ADDON_ID, ed)))

                if not auser:
                    directory.add_file('{0} - [COLOR red]Not Authorized[/COLOR]'.format(name), {'name': ed}, icon=icon, description='Your Easy Debrid Authorizations', fanart=fanart, themeit=CONFIG.THEME2)
                else:
                    directory.add_file('{0} - [COLOR springgreen]Authorized[/COLOR]'.format(name), {'name': ed}, icon=icon, description='Your Easy Debrid Authorizations', fanart=fanart, themeit=CONFIG.THEME2)
                if name == 'Fen Light':
                    directory.add_file('[COLOR blue]Open [COLOR dodgerblue]{0}[/COLOR] Settings[/COLOR]'.format('Fen Light'), {'mode': 'opensettings_fenlt', 'name': 'Fen Light'}, icon=icon, fanart=fanart, menu=menu)
                elif name == 'Gears':
                    directory.add_file('[COLOR blue]Open [COLOR dodgerblue]{0}[/COLOR] Settings[/COLOR]'.format('Gears'), {'mode': 'opensettings_gears', 'name': 'Gears'}, icon=icon, fanart=fanart, menu=menu)
                else:
                    directory.add_file('[COLOR blue]Open [COLOR dodgerblue]{0}[/COLOR] Settings[/COLOR]'.format(set_user), {'mode': 'opensettings_ed', 'name': ed}, icon=icon, fanart=fanart, menu=menu)
                directory.add_separator()
                
def torbox_menu():
    for tb in acct_vwr.ORDER:
        # Filter only addons that support Torbox
        if not acct_vwr.ADDONS[tb].get('default_tb'):
            continue
        if not xbmc.getCondVisibility('System.HasAddon({0})'.format(acct_vwr.ADDONS[tb]['plugin'])):
            pass
        else:
            if xbmc.getCondVisibility('System.HasAddon({0})'.format(acct_vwr.ADDONS[tb]['plugin'])):
                name = acct_vwr.ADDONS[tb]['name']
                path = acct_vwr.ADDONS[tb]['path']
                auser = acct_vwr.addon_user(tb, 'tb')
                set_user = acct_vwr.ADDONS[tb]['name']
                icon = acct_vwr.ADDONS[tb]['icon'] if os.path.exists(path) else CONFIG.ICON
                fanart = acct_vwr.ADDONS[tb]['fanart'] if os.path.exists(path) else CONFIG.ADDON_FANART
                menu = create_addon_data_menu('TorBox', tb)
                menu.append((CONFIG.THEME1.format('{0} Settings'.format(name)), 'RunPlugin(plugin://{0}/?mode=opensettings&name={1}&url=tb)'.format(CONFIG.ADDON_ID, tb)))

                if not auser:
                    directory.add_file('{0} - [COLOR red]Not Authorized[/COLOR]'.format(name), {'name': tb}, icon=icon, description='Your TorBox Authorizations', fanart=fanart, themeit=CONFIG.THEME2)
                else:
                    directory.add_file('{0} - [COLOR springgreen]Authorized[/COLOR]'.format(name), {'name': tb}, icon=icon, description='Your TorBox Authorizations', fanart=fanart, themeit=CONFIG.THEME2)
                if name == 'Fen Light':
                    directory.add_file('[COLOR blue]Open [COLOR dodgerblue]{0}[/COLOR] Settings[/COLOR]'.format('Fen Light'), {'mode': 'opensettings_fenlt', 'name': 'Fen Light'}, icon=icon, fanart=fanart, menu=menu)
                elif name == 'Gears':
                    directory.add_file('[COLOR blue]Open [COLOR dodgerblue]{0}[/COLOR] Settings[/COLOR]'.format('Gears'), {'mode': 'opensettings_gears', 'name': 'Gears'}, icon=icon, fanart=fanart, menu=menu)
                else:
                    directory.add_file('[COLOR blue]Open [COLOR dodgerblue]{0}[/COLOR] Settings[/COLOR]'.format(set_user), {'mode': 'opensettings_tb', 'name': tb}, icon=icon, fanart=fanart, menu=menu)
                directory.add_separator()
                
def offcloud_menu():
    for offc in acct_vwr.ORDER:
        # Filter only addons that support OffCloud
        if not acct_vwr.ADDONS[offc].get('default_oc'):
            continue
        if not xbmc.getCondVisibility('System.HasAddon({0})'.format(acct_vwr.ADDONS[offc]['plugin'])):
            pass
        else:
            if xbmc.getCondVisibility('System.HasAddon({0})'.format(acct_vwr.ADDONS[offc]['plugin'])):
                name = acct_vwr.ADDONS[offc]['name']
                path = acct_vwr.ADDONS[offc]['path']
                auser = acct_vwr.addon_user(offc, 'oc')
                set_user = acct_vwr.ADDONS[offc]['name']
                icon = acct_vwr.ADDONS[offc]['icon'] if os.path.exists(path) else CONFIG.ICON
                fanart = acct_vwr.ADDONS[offc]['fanart'] if os.path.exists(path) else CONFIG.ADDON_FANART
                menu = create_addon_data_menu('OffCloud', offc)
                menu.append((CONFIG.THEME1.format('{0} Settings'.format(name)), 'RunPlugin(plugin://{0}/?mode=opensettings&name={1}&url=offc)'.format(CONFIG.ADDON_ID, offc)))

                if not auser:
                    directory.add_file('{0} - [COLOR red]Not Authorized[/COLOR]'.format(name), {'name': offc}, icon=icon, description='Your Offcloud Authorizations', fanart=fanart, themeit=CONFIG.THEME2)
                else:
                    directory.add_file('{0} - [COLOR springgreen]Authorized[/COLOR]'.format(name), {'name': offc}, icon=icon, description='Your Offcloud Authorizations', fanart=fanart, themeit=CONFIG.THEME2)
                if name == 'Fen Light':
                    directory.add_file('[COLOR blue]Open [COLOR dodgerblue]{0}[/COLOR] Settings[/COLOR]'.format('Fen Light'), {'mode': 'opensettings_fenlt', 'name': 'Fen Light'}, icon=icon, fanart=fanart, menu=menu)
                elif name == 'Gears':
                    directory.add_file('[COLOR blue]Open [COLOR dodgerblue]{0}[/COLOR] Settings[/COLOR]'.format('Gears'), {'mode': 'opensettings_gears', 'name': 'Gears'}, icon=icon, fanart=fanart, menu=menu)
                else:
                    directory.add_file('[COLOR blue]Open [COLOR dodgerblue]{0}[/COLOR] Settings[/COLOR]'.format(set_user), {'mode': 'opensettings_oc', 'name': offc}, icon=icon, fanart=fanart, menu=menu)
                directory.add_separator()

def easynews_menu():
    for easy in acct_vwr.ORDER:
        # Filter only addons that support Easynews
        if not acct_vwr.ADDONS[easy].get('default_en'):
            continue
        if not xbmc.getCondVisibility('System.HasAddon({0})'.format(acct_vwr.ADDONS[easy]['plugin'])):
            pass
        else:
            if xbmc.getCondVisibility('System.HasAddon({0})'.format(acct_vwr.ADDONS[easy]['plugin'])):
                name = acct_vwr.ADDONS[easy]['name']
                path = acct_vwr.ADDONS[easy]['path']
                auser = acct_vwr.addon_user(easy, 'en')
                set_user = acct_vwr.ADDONS[easy]['name']
                icon = acct_vwr.ADDONS[easy]['icon'] if os.path.exists(path) else CONFIG.ICON
                fanart = acct_vwr.ADDONS[easy]['fanart'] if os.path.exists(path) else CONFIG.ADDON_FANART
                menu = create_addon_data_menu('OffCloud', easy)
                menu.append((CONFIG.THEME1.format('{0} Settings'.format(name)), 'RunPlugin(plugin://{0}/?mode=opensettings&name={1}&url=easy)'.format(CONFIG.ADDON_ID, easy)))

                if not auser:
                    directory.add_file('{0} - [COLOR red]Not Authorized[/COLOR]'.format(name), {'name': easy}, icon=icon, description='Your Offcloud Authorizations', fanart=fanart, themeit=CONFIG.THEME2)
                else:
                    directory.add_file('{0} - [COLOR springgreen]Authorized[/COLOR]'.format(name), {'name': easy}, icon=icon, description='Your Offcloud Authorizations', fanart=fanart, themeit=CONFIG.THEME2)
                if name == 'Fen Light':
                    directory.add_file('[COLOR blue]Open [COLOR dodgerblue]{0}[/COLOR] Settings[/COLOR]'.format('Fen Light'), {'mode': 'opensettings_fenlt', 'name': 'Fen Light'}, icon=icon, fanart=fanart, menu=menu)
                elif name == 'Gears':
                    directory.add_file('[COLOR blue]Open [COLOR dodgerblue]{0}[/COLOR] Settings[/COLOR]'.format('Gears'), {'mode': 'opensettings_gears', 'name': 'Gears'}, icon=icon, fanart=fanart, menu=menu)
                else:
                    directory.add_file('[COLOR blue]Open [COLOR dodgerblue]{0}[/COLOR] Settings[/COLOR]'.format(set_user), {'mode': 'opensettings_oc', 'name': easy}, icon=icon, fanart=fanart, menu=menu)
                directory.add_separator()

def ext_menu():
    from resources.libs import extit

    for ext in extit.ORDER:
        if not xbmc.getCondVisibility('System.HasAddon({0})'.format(extit.EXTID[ext]['plugin'])):
            pass
        else:
            if xbmc.getCondVisibility('System.HasAddon({0})'.format(extit.EXTID[ext]['plugin'])):
                name = extit.EXTID[ext]['name']
                path = extit.EXTID[ext]['path']
                auser = extit.ext_user(ext)
                set_user = extit.settings(ext)
                icon = extit.EXTID[ext]['icon'] if os.path.exists(path) else CONFIG.ICON
                fanart = extit.EXTID[ext]['fanart'] if os.path.exists(path) else CONFIG.ADDON_FANART
                menu = create_addon_data_menu('External Providers', ext)
                menu.append((CONFIG.THEME1.format('{0} Settings'.format(name)), 'RunPlugin(plugin://{0}/?mode=opensettings&name={1}&url=ext)'.format(CONFIG.ADDON_ID, ext)))

                if not auser:
                    directory.add_file('{0} - [COLOR red]No Scraper Synced[/COLOR]'.format(name), {'name': ext}, icon=icon, description='Your External Provider Authorizations', fanart=fanart, themeit=CONFIG.THEME2)
                elif 'coco' in str(auser).lower():
                    if name == 'Fen':
                        directory.add_file('{0} - [COLOR springgreen]Coco Scrapers Synced[/COLOR]'.format(name), {'name': ext}, icon=icon, description='Your External Provider Authorizations\n\nGears Scrapers - Not Supported\nMagento Scrapers - Not Supported', fanart=fanart, themeit=CONFIG.THEME2)
                    else:
                        directory.add_file('{0} - [COLOR springgreen]Coco Scrapers Synced[/COLOR]'.format(name), {'name': ext}, icon=icon, description='Your External Provider Authorizations', fanart=fanart, themeit=CONFIG.THEME2)
                elif 'gears' in str(auser).lower():
                    directory.add_file('{0} - [COLOR springgreen]Gears Scrapers Synced[/COLOR]'.format(name), {'name': ext}, icon=icon, description='Your External Provider Authorizations', fanart=fanart, themeit=CONFIG.THEME2)
                elif 'magneto' in str(auser).lower():
                    directory.add_file('{0} - [COLOR springgreen]Magneto Scrapers Synced[/COLOR]'.format(name), {'name': ext}, icon=icon, description='Your External Provider Authorizations', fanart=fanart, themeit=CONFIG.THEME2)
                elif 'viper' in str(auser).lower():
                    if name == 'Fen':
                        directory.add_file('{0} - [COLOR springgreen]Viper Scrapers Synced[/COLOR]'.format(name), {'name': ext}, icon=icon, description='Your External Provider Authorizations\n\nGears Scrapers - Not Supported\nMagento Scrapers - Not Supported', fanart=fanart, themeit=CONFIG.THEME2)
                    else:
                        directory.add_file('{0} - [COLOR springgreen]Viper Scrapers Synced[/COLOR]'.format(name), {'name': ext}, icon=icon, description='Your External Provider Authorizations', fanart=fanart, themeit=CONFIG.THEME2)
                if name == 'Fen Light':
                    if any(xbmc.getCondVisibility(f'System.HasAddon({addon_id})') for addon_id in (coco_plugin_id, coco_mod_plugin_id, mag_plugin_id, mag_mod_plugin_id,viper_plugin_id)):
                        directory.add_file('[COLOR goldenrod]Change [COLOR gold]Scraper[/COLOR] Package[/COLOR]'.format(set_user), {'mode': 'fenlt_scrapers', 'name': ext}, icon=icon, description='Change External Scraper Package', fanart=fanart, menu=menu)
                        directory.add_file('[COLOR blue]Open [COLOR dodgerblue]{0}[/COLOR] Settings[/COLOR]'.format('Fen Light'), {'mode': 'opensettings_fenlt', 'name': 'Fen Light'}, icon=icon, description='Open add-on settings menu', fanart=fanart, menu=menu)
                    else:
                        directory.add_file('[COLOR blue]Open [COLOR dodgerblue]{0}[/COLOR] Settings[/COLOR]'.format('Fen Light'), {'mode': 'opensettings_fenlt', 'name': 'Fen Light'}, icon=icon, description='Open add-on settings menu', fanart=fanart, menu=menu)
                elif name == 'Gears':
                    if any(xbmc.getCondVisibility(f'System.HasAddon({addon_id})') for addon_id in (coco_plugin_id, coco_mod_plugin_id, mag_plugin_id, mag_mod_plugin_id,viper_plugin_id)):
                        directory.add_file('[COLOR goldenrod]Change [COLOR gold]Scraper[/COLOR] Package[/COLOR]'.format(set_user), {'mode': 'gears_scrapers', 'name': ext}, icon=icon, description='Change External Scraper Package', fanart=fanart, menu=menu)
                        directory.add_file('[COLOR blue]Open [COLOR dodgerblue]{0}[/COLOR] Settings[/COLOR]'.format('Gears'), {'mode': 'opensettings_gears', 'name': 'Gears'}, icon=icon, description='Open add-on settings menu', fanart=fanart, menu=menu)
                    else:
                        directory.add_file('[COLOR blue]Open [COLOR dodgerblue]{0}[/COLOR] Settings[/COLOR]'.format('Gears'), {'mode': 'opensettings_gears', 'name': 'Gears'}, icon=icon, description='Open add-on settings menu', fanart=fanart, menu=menu)
                elif name == 'Fen':
                    if any(xbmc.getCondVisibility(f'System.HasAddon({addon_id})') for addon_id in (coco_plugin_id, coco_mod_plugin_id, mag_plugin_id, mag_mod_plugin_id,viper_plugin_id)):
                        directory.add_file('[COLOR goldenrod]Change [COLOR gold]Scraper[/COLOR] Package[/COLOR]'.format(set_user), {'mode': 'fen_scrapers', 'name': ext}, icon=icon, description='Change External Scraper Package', fanart=fanart, menu=menu)
                        directory.add_file('[COLOR blue]Open [COLOR dodgerblue]{0}[/COLOR] Settings[/COLOR]'.format(set_user), {'mode': 'opensettings_ext', 'name': ext}, icon=icon, description='Open add-on settings menu', fanart=fanart, menu=menu)
                    else:
                        directory.add_file('[COLOR blue]Open [COLOR dodgerblue]{0}[/COLOR] Settings[/COLOR]'.format(set_user), {'mode': 'opensettings_ext', 'name': ext}, icon=icon, description='Open add-on settings menu', fanart=fanart, menu=menu)
                elif name == 'Umbrella':
                    if any(xbmc.getCondVisibility(f'System.HasAddon({addon_id})') for addon_id in (coco_plugin_id, coco_mod_plugin_id, mag_plugin_id, mag_mod_plugin_id,viper_plugin_id)):
                        directory.add_file('[COLOR goldenrod]Change [COLOR gold]Scraper[/COLOR] Package[/COLOR]'.format(set_user), {'mode': 'umb_scrapers', 'name': ext}, icon=icon, description='Change External Scraper Package', fanart=fanart, menu=menu)
                        directory.add_file('[COLOR blue]Open [COLOR dodgerblue]{0}[/COLOR] Settings[/COLOR]'.format(set_user), {'mode': 'opensettings_ext', 'name': ext}, icon=icon, description='Open add-on settings menu', fanart=fanart, menu=menu)
                    else:
                        directory.add_file('[COLOR blue]Open [COLOR dodgerblue]{0}[/COLOR] Settings[/COLOR]'.format(set_user), {'mode': 'opensettings_ext', 'name': ext}, icon=icon, description='Open add-on settings menu', fanart=fanart, menu=menu)
                directory.add_separator()

def create_addon_data_menu(add='', name=''):
    menu_items = []
    menu_items.append((CONFIG.THEME1.format(name.title()), ' '))
    return menu_items
