import xbmc
import xbmcgui
import xbmcaddon
import os
import time
import xbmcvfs
import sqlite3

from sqlite3 import Error
from xml.etree import ElementTree
from resources.libs.common.config import CONFIG
from resources.libs.common import logging
from resources.libs.common import tools
from resources.libs.common import var

ORDER = ['umbrella',
         'otaku',
         'simkl',
         'acctmgr']

SIMKLID = {
    'umbrella': {
        'name'     : 'Umbrella',
        'plugin'   : 'plugin.video.umbrella',
        'saved'    : 'umbrella',
        'path'     : os.path.join(CONFIG.ADDONS, 'plugin.video.umbrella'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'plugin.video.umbrella', 'icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'plugin.video.umbrella', 'fanart.jpg'),
        'file'     : os.path.join(CONFIG.SIMKLFOLD, 'umbrella_simkl'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'plugin.video.umbrella', 'settings.xml'),
        'default'  : 'simkltoken',
        'data'     : ['simklusername', 'simkltoken'],
        'activate' : 'Addon.OpenSettings(plugin.video.umbrella)'},
    'otaku': {
        'name'     : 'Otaku',
        'plugin'   : 'plugin.video.otaku',
        'saved'    : 'otaku',
        'path'     : os.path.join(CONFIG.ADDONS, 'plugin.video.otaku'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'plugin.video.otaku', 'icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'plugin.video.otaku', 'fanart.jpg'),
        'file'     : os.path.join(CONFIG.SIMKLFOLD, 'otaku_simkl'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'plugin.video.otaku', 'settings.xml'),
        'default'  : 'simkl.token',
        'data'     : ['simkl.token', 'simkl.username', 'simkl.enabled'],
        'activate' : 'Addon.OpenSettings(plugin.video.otaku)'},
    'simkl': {
        'name'     : 'Simkl TV Tracker',
        'plugin'   : 'script.simkl',
        'saved'    : 'simkl',
        'path'     : os.path.join(CONFIG.ADDONS, 'script.simkl'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'script.simkl', 'icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'script.simkl', 'fanart.png'),
        'file'     : os.path.join(CONFIG.SIMKLFOLD, 'simkl_simkl'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'script.simkl', 'settings.xml'),
        'default'  : 'token',
        'data'     : ['token'],
        'activate' : 'Addon.OpenSettings(script.simkl)'},
   'acctmgr': {
        'name'     : 'Account Manager',
        'plugin'   : 'script.module.accountmgr',
        'saved'    : 'acctmgr',
        'path'     : os.path.join(CONFIG.ADDONS, 'script.module.accountmgr'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'script.module.accountmgr', 'icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'script.module.accountmgr', 'fanart.png'),
        'file'     : os.path.join(CONFIG.SIMKLFOLD, 'acctmgr_simkl'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'script.module.accountmgr', 'settings.xml'),
        'default'  : 'simkl.token',
        'data'     : ['simkl.username', 'simkl.token'],
        'activate' : 'Addon.OpenSettings(script.module.accountmgr)'},
}

def simkl_user(who):
    user = None
    if SIMKLID[who]:
        if os.path.exists(SIMKLID[who]['path']):
            try:
                add = tools.get_addon_by_id(SIMKLID[who]['plugin'])
                user = add.getSetting(SIMKLID[who]['default'])
            except:
                pass
    return user

def simkl_it(do, who):
    if not os.path.exists(CONFIG.ADDON_DATA):
        os.makedirs(CONFIG.ADDON_DATA)
    if not os.path.exists(CONFIG.SIMKLFOLD):
        os.makedirs(CONFIG.SIMKLFOLD)
    if who == 'all':
        for log in ORDER:
            if os.path.exists(SIMKLID[log]['path']):
                try:
                    addonid = tools.get_addon_by_id(SIMKLID[log]['plugin'])
                    default = SIMKLID[log]['default']
                    user = addonid.getSetting(default)
                    update_simkl(do, log)
                except:
                    pass
            else:
                logging.log('[Simkl Data] {0}({1}) is not installed'.format(SIMKLID[log]['name'], SIMKLID[log]['plugin']), level=xbmc.LOGERROR)
    else:
        if SIMKLID[who]:
            if os.path.exists(SIMKLID[who]['path']):
                update_simkl(do, who)
        else:
            logging.log('[Simkl Data] Invalid Entry: {0}'.format(who), level=xbmc.LOGERROR)

def simkl_it_revoke(do, who):
    if not os.path.exists(CONFIG.ADDON_DATA):
        os.makedirs(CONFIG.ADDON_DATA)
    if not os.path.exists(CONFIG.SIMKLFOLD):
        os.makedirs(CONFIG.SIMKLFOLD)
    if who == 'all':
        for log in ORDER:
            if os.path.exists(SIMKLID[log]['path']):
                try:
                    addonid = tools.get_addon_by_id(SIMKLID[log]['plugin'])
                    default = SIMKLID[log]['default']
                    user = addonid.getSetting(default)
                    update_simkl(do, log)
                except:
                    pass
            else:
                logging.log('[Simkl Data] {0}({1}) is not installed'.format(SIMKLID[log]['name'], SIMKLID[log]['plugin']), level=xbmc.LOGERROR)
    else:
        if SIMKLID[who]:
            if os.path.exists(SIMKLID[who]['path']):
                update_simkl(do, who)
        else:
            logging.log('[Simkl Data] Invalid Entry: {0}'.format(who), level=xbmc.LOGERROR)

def simkl_it_restore(do, who):
    if not os.path.exists(CONFIG.ADDON_DATA):
        os.makedirs(CONFIG.ADDON_DATA)
    if not os.path.exists(CONFIG.SIMKLFOLD):
        os.makedirs(CONFIG.SIMKLFOLD)
    if who == 'all':
        for log in ORDER:
            if os.path.exists(SIMKLID[log]['path']):
                try:
                    addonid = tools.get_addon_by_id(SIMKLID[log]['plugin'])
                    default = SIMKLID[log]['default']
                    user = addonid.getSetting(default)
                    update_simkl(do, log)
                except:
                    pass
            else:
                logging.log('[Simkl Data] {0}({1}) is not installed'.format(SIMKLID[log]['name'], SIMKLID[log]['plugin']), level=xbmc.LOGERROR)
    else:
        if SIMKLID[who]:
            if os.path.exists(SIMKLID[who]['path']):
                update_simkl(do, who)
        else:
            logging.log('[Simkl Data] Invalid Entry: {0}'.format(who), level=xbmc.LOGERROR)
            
def clear_saved(who, over=False):
    if who == 'all':
        for simkl in SIMKLID:
            clear_saved(simkl,  True)
    elif SIMKLID[who]:
        file = SIMKLID[who]['file']
        if os.path.exists(file):
            os.remove(file)
    if not over:
        xbmc.executebuiltin('Container.Refresh()')

def update_simkl(do, who):
    file = SIMKLID[who]['file']
    settings = SIMKLID[who]['settings']
    data = SIMKLID[who]['data']
    addonid = tools.get_addon_by_id(SIMKLID[who]['plugin'])
    saved = SIMKLID[who]['saved']
    default = SIMKLID[who]['default']
    user = addonid.getSetting(default)
    suser = CONFIG.get_setting(saved)
    name = SIMKLID[who]['name']
    icon = SIMKLID[who]['icon']
    if do == 'update':
        if not user == '':
            try:
                root = ElementTree.Element(saved)

                for setting in data:
                    simkl = ElementTree.SubElement(root, 'simkl')
                    id = ElementTree.SubElement(simkl, 'id')
                    id.text = setting
                    value = ElementTree.SubElement(simkl, 'value')
                    value.text = addonid.getSetting(setting)

                tree = ElementTree.ElementTree(root)
                tree.write(file)
                user = addonid.getSetting(default)
                CONFIG.set_setting(saved, user)
                logging.log('Simkl Data Saved for {0}'.format(name), level=xbmc.LOGINFO)
            except Exception as e:
                logging.log("[Simkl Data] Unable to Update {0} ({1})".format(who, str(e)), level=xbmc.LOGERROR)
        else:
            logging.log('Simkl Data Not Registered for {0}'.format(name))    
    elif do == 'restore':
        if os.path.exists(file):
            tree = ElementTree.parse(file)
            root = tree.getroot()
            try:
                for setting in root.findall('simkl'):
                    id = setting.find('id').text
                    value = setting.find('value').text
                    addonid.setSetting(id, value)

                user = addonid.getSetting(default)
                CONFIG.set_setting(saved, user)
                logging.log('Simkl Data Restored for {0}'.format(name), level=xbmc.LOGINFO)
            except Exception as e:
                logging.log("[Simkl Data] Unable to Restore {0} ({1})".format(who, str(e)), level=xbmc.LOGERROR)
        else:
            logging.log('Simkl Data Not Found for {0}'.format(name))    
    elif do == 'clearaddon':
        logging.log('{0} SETTINGS: {1}'.format(name, settings))
        if os.path.exists(settings):
            try:
                tree = ElementTree.parse(settings)
                root = tree.getroot()
                
                for setting in root.findall('setting'):
                    if setting.attrib['id'] in data:
                        logging.log('Removing Setting: {0}'.format(setting.attrib))
                        root.remove(setting)
                            
                tree.write(settings)
                
                logging.log_notify("[COLOR {0}]{1}[/COLOR]".format(CONFIG.COLOR1, name),
                                   '[COLOR {0}]Addon Data: Cleared![/COLOR]'.format(CONFIG.COLOR2),
                                   2000,
                                   icon)
            except Exception as e:
                logging.log("[Simkl Info] Unable to Clear Addon {0} ({1})".format(who, str(e)), level=xbmc.LOGERROR)
        xbmc.executebuiltin('Container.Refresh()')
    elif do == 'wipeaddon':
        logging.log('{0} SETTINGS: {1}'.format(name, settings))
        if os.path.exists(settings):
            try:
                tree = ElementTree.parse(settings)
                root = tree.getroot()
                
                for setting in root.findall('setting'):
                    if setting.attrib['id'] in data:
                        logging.log('Removing Setting: {0}'.format(setting.attrib))
                        root.remove(setting)
                            
                tree.write(settings)
                
            except Exception as e:
                logging.log("[Simkl Info] Unable to Clear Addon {0} ({1})".format(who, str(e)), level=xbmc.LOGERROR)
        xbmc.executebuiltin('Container.Refresh()')

def auto_update(who):
    if who == 'all':
        for log in SIMKLID:
            if os.path.exists(SIMKLID[log]['path']):
                auto_update(log)
    elif SIMKLID[who]:
        if os.path.exists(SIMKLID[who]['path']):
            u = simkl_user(who)
            su = CONFIG.get_setting(SIMKLID[who]['saved'])
            n = SIMKLID[who]['name']
            if not u or u == '':
                return
            elif su == '':
                simkl_it('update', who)
            elif not u == su:
                dialog = xbmcgui.Dialog()

                if dialog.yesno(CONFIG.ADDONTITLE,
                                    "Would you like to save the [COLOR {0}]Simkl Data[/COLOR] for [COLOR {1}]{2}[/COLOR]?".format(CONFIG.COLOR2, CONFIG.COLOR1, n),
                                    "Addon: [COLOR springgreen][B]{0}[/B][/COLOR]".format(u),
                                    "Saved:[/COLOR] [COLOR red][B]{0}[/B][/COLOR]".format(su) if not su == '' else 'Saved:[/COLOR] [COLOR red][B]None[/B][/COLOR]',
                                    yeslabel="[B][COLOR springgreen]Save Data[/COLOR][/B]",
                                    nolabel="[B][COLOR red]No Cancel[/COLOR][/B]"):
                    simkl_it('update', who)
            else:
                simkl_it('update', who)

def import_list(who):
    if who == 'all':
        for log in SIMKLID:
            if os.path.exists(SIMKLID[log]['file']):
                import_list(log)
    elif SIMKLID[who]:
        if os.path.exists(SIMKLID[who]['file']):
            file = SIMKLID[who]['file']
            addonid = tools.get_addon_by_id(SIMKLID[who]['plugin'])
            saved = SIMKLID[who]['saved']
            default = SIMKLID[who]['default']
            suser = CONFIG.get_setting(saved)
            name = SIMKLID[who]['name']

            tree = ElementTree.parse(file)
            root = tree.getroot()

            for setting in root.findall('simkl'):
                id = setting.find('id').text
                value = setting.find('value').text

                addonid.setSetting(id, value)

            logging.log_notify("[COLOR {0}]{1}[/COLOR]".format(CONFIG.COLOR1, name),
                       '[COLOR {0}]Simkl Data: Imported![/COLOR]'.format(CONFIG.COLOR2))

def open_settings_simkl(who):
    addonid = tools.get_addon_by_id(SIMKLID[who]['plugin'])
    addonid.openSettings()
