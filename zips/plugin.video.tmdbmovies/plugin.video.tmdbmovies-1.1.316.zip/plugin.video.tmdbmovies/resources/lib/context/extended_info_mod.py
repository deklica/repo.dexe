import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs
import json
import requests
import sys
import os
import html
import threading
import random
import time
from urllib.parse import urlencode, quote
from datetime import datetime, date
from resources.lib.providers import trakt_sync
from resources.lib.providers import watched_provider

# --- FIX EROARE LOG: Fortam ID-ul daca nu este detectat ---
try:
    # Incercam sa luam instanta curenta
    ADDON = xbmcaddon.Addon()
    # Verificam daca are ID valid, altfel aruncam eroare pentru a intra in except
    _id = ADDON.getAddonInfo('id')
except:
    # Daca esueaza, fortam ID-ul cunoscut
    ADDON = xbmcaddon.Addon('plugin.video.tmdbmovies')
# ----------------------------------------------------------

ADDON_PATH = ADDON.getAddonInfo('path')

try:
    from resources.lib.core.config import API_KEY, IMG_BASE, BACKDROP_BASE
except ImportError:
    API_KEY = "8ad3c21a92a64da832c559d58cc63ab4"
    # IMG_BASE este w500 (bun pentru postere principale)
    IMG_BASE = "https://image.tmdb.org/t/p/w500" 
    # BACKDROP_BASE este w1280 (bun pentru fundal)
    BACKDROP_BASE = "https://image.tmdb.org/t/p/w1280"

# --- OPTIMIZARE VITEZA ---
# In loc de 'original' (care blocheaza Android-ul), folosim w1280 (HD)
IMG_FULL = "https://image.tmdb.org/t/p/w1280" 

# Definim o marime mica pentru listele lungi (Cast, Recomandari)
# w185 sau w342 se incarca instant
IMG_THUMB_SMALL = "https://image.tmdb.org/t/p/w342"
# -------------------------

# --- LISTA CHEI YOUTUBE (ROTATIE) ---
YOUTUBE_KEYS = [
    'AIzaSyDtgCds1-7WAuajTIj2z9hXCMTCCFvJxGc',
    'AIzaSyC8OXml2Dz3KVOMbxW5LZj45Fr7Qf9APQY',
    'AIzaSyCXAUyE5nnzbkn3ItbOaAExPVCf4Cmqk-A',
    'AIzaSyA0LiS7G-KlrlfmREcCAXjyGqa_h_zfrSE',
    'AIzaSyBOXZVC-xzrdXSAmau5UM3rG7rc8eFIuFw',
    'AIzaSyDCJJcBtvDsTH5f-7xJWeV10ZnoRZB_E50'
]
# ------------------------------------

# Imagini full resolution pentru viewer
IMG_FULL = "https://image.tmdb.org/t/p/original"

XML_VIDEO_INFO = 'ext_DialogVideoInfo.xml'
XML_ACTOR_INFO = 'ext_DialogInfo.xml'

ACTION_PREVIOUS_MENU = 10
ACTION_NAV_BACK = 92
ACTION_LEFT = 1
ACTION_RIGHT = 2
ACTION_UP = 3
ACTION_DOWN = 4
ACTION_SELECT = 7
ACTION_MOUSE_LEFT_CLICK = 100

NAVIGATION_STACK = []

def log(msg):
    xbmc.log(f"[TMDb Extended INFO] {msg}", level=xbmc.LOGINFO)

# --- FUNCTII NOI PENTRU BUTOANE (Play, Library, Settings) ---
def action_play_dialog(tmdb_id, media_type, season=None, episode=None, title=''):
    """
    Gestioneaza meniul de actiuni (Play/Browse/Search).
    Fix: Culori personalizate si Text Bold.
    """
    s_id = str(tmdb_id)
    s_season = str(season) if season is not None else '1'
    s_episode = str(episode) if episode is not None else '1'
    s_title = str(title)
    
    # Determinam tipul corect pentru Cautare
    search_type_real = 'tv' if media_type in ['tv', 'season', 'episode'] else 'movie'
    
    # --- DEFINIRE CULORI ---
    # TMDb Movies -> FFFDBD01 (Gold)
    # TMDb Helper -> FF00CED1 (Turquoise)
    # Search Title -> FF6AFB92 (Light Green)
    
    c_movies = "[COLOR FF00CED1]TMDb[/COLOR] [COLOR FFCCCCFF]Movies[/COLOR]"
    c_helper = "[COLOR FF00CED1]TMDb Helper[/COLOR]"
    c_title  = f"[COLOR FF6AFB92]'{s_title}'[/COLOR]"
    
    # 1. GENERARE ETICHETE (Toate cu [B]old)
    if media_type == 'tv':
        label_movies = f"[B]Browse Seasons ({c_movies})[/B]"
        label_helper = f"[B]Browse Seasons ({c_helper})[/B]"
    elif media_type == 'season':
        label_movies = f"[B]Browse Episodes ({c_movies})[/B]"
        label_helper = f"[B]Browse Episodes ({c_helper})[/B]"
    elif media_type == 'episode':
        label_movies = f"[B]Play Episode ({c_movies})[/B]"
        label_helper = f"[B]Play Episode ({c_helper})[/B]"
    else: 
        label_movies = f"[B]Play Movie ({c_movies})[/B]"
        label_helper = f"[B]Play Movie ({c_helper})[/B]"
        
    label_search = f"[B]Search {c_title} ({search_type_real.upper()})[/B]"
        
    options = [label_movies, label_helper, label_search]
    
    dialog = xbmcgui.Dialog()
    ret = dialog.contextmenu(options)
    
    if ret < 0: return # Cancel
    
    url = ""
    is_browsing = False
    
    # OPTIUNEA 0: TMDB MOVIES
    if ret == 0:
        base_url = "plugin://plugin.video.tmdbmovies/"
        if media_type == 'movie':
            url = f"{base_url}?mode=sources&tmdb_id={s_id}&type=movie&title={quote(s_title)}"
        elif media_type == 'episode':
            url = f"{base_url}?mode=sources&tmdb_id={s_id}&type=tv&season={s_season}&episode={s_episode}&title={quote(s_title)}"
        elif media_type == 'tv':
            url = f"{base_url}?mode=details&tmdb_id={s_id}&type=tv&title={quote(s_title)}"
            is_browsing = True
        elif media_type == 'season':
            url = f"{base_url}?mode=episodes&tmdb_id={s_id}&season={s_season}&tv_show_title={quote(s_title)}"
            is_browsing = True

    # OPTIUNEA 1: TMDB HELPER
    elif ret == 1:
        base_url = "plugin://plugin.video.themoviedb.helper/"
        if media_type == 'movie':
            url = f"{base_url}?info=play&type=movie&tmdb_id={s_id}"
        elif media_type == 'episode':
            url = f"{base_url}?info=play&type=episode&tmdb_id={s_id}&season={s_season}&episode={s_episode}"
        elif media_type == 'tv':
            url = f"{base_url}?info=details&type=tv&tmdb_id={s_id}"
            is_browsing = True
        elif media_type == 'season':
            url = f"{base_url}?info=episodes&type=tv&tmdb_id={s_id}&season={s_season}"
            is_browsing = True

    # OPTIUNEA 2: SEARCH
    elif ret == 2:
        import re
        clean_title = s_title
        # Curatam S01, S2024 etc
        match = re.search(r'\sS\d+', s_title)
        if match:
            clean_title = s_title[:match.start()]
            
        url = f"plugin://plugin.video.tmdbmovies/?mode=perform_search_query&query={quote(clean_title)}&type={search_type_real}"
        is_browsing = True

    # EXECUTIE PRIN THREAD
    if url:
        xbmc.log(f"[ExtendedInfo] Executing via Thread: {url}", xbmc.LOGINFO)
        
        def run_command():
            import xbmc
            import time
            xbmc.executebuiltin("Dialog.Close(all,true)")
            time.sleep(0.4)
            
            if is_browsing:
                xbmc.executebuiltin(f'ActivateWindow(Videos,"{url}",return)')
            else:
                xbmc.executebuiltin(f"RunPlugin({url})")

        t = threading.Thread(target=run_command)
        t.daemon = True
        t.start()

def action_options_dialog(tmdb_id, media_type, season=None, episode=None, title=''):
    # Extragem anul si imdb_id din fereastra pentru functia 'My Plays'
    imdb_id = xbmc.getInfoLabel('Window.Property(movie.imdbnumber)') or ''
    year = xbmc.getInfoLabel('Window.Property(movie.year)') or xbmc.getInfoLabel('Window.Property(year)') or ''
    
    from resources.lib.core.config import ADDON
    from resources.lib.api.tmdb_api import _allprov_colored
    options = []
    dispatch = []

    def _add(label, mode):
        options.append(label)
        dispatch.append(mode)

    if ADDON.getSetting('show_cm_trakt') != 'false':
        _add("[B][COLOR pink]My Trakt[/COLOR][/B]", 'trakt_context_menu')
    if ADDON.getSetting('show_cm_tmdb') != 'false':
        _add("[B][COLOR FF00CED1]My TMDB[/COLOR][/B]", 'tmdb_context_menu')
    if ADDON.getSetting('show_cm_mdblist') != 'false':
        _add("[B][COLOR lightskyblue]My MDBList[/COLOR][/B]", 'mdblist_context_menu')
    if ADDON.getSetting('show_cm_simkl') != 'false':
        _add("[B][COLOR mediumpurple]My Simkl[/COLOR][/B]", 'simkl_context_menu')
    if ADDON.getSetting('show_cm_punchplay') != 'false':
        _add("[B][COLOR FFFF6600]My PunchPlay[/COLOR][/B]", 'punchplay_context_menu')
    if ADDON.getSetting('all_providers_menu') == 'true':
        _add(f"[B]{_allprov_colored('All Providers', (3, 3, 2, 3, 2), ('trakt', 'tmdb', 'mdblist', 'simkl', 'punchplay'))}[/B]", 'all_providers_context_menu')
    if ADDON.getSetting('show_cm_my_plays') != 'false':
        _add("[B][COLOR FFFF69B4]My Plays[/COLOR][/B]", 'show_my_plays_menu')
    _add("[B][COLOR orange]Clear sources cache[/COLOR][/B]", 'clear_sources_context')
    _add("[B][COLOR yellow]Add to My Favorites[/COLOR][/B]", 'add_favorite')
    _add("[B][COLOR yellow]Remove from My Favorites[/COLOR][/B]", 'remove_favorite')
    _add("[B][COLOR gray]Settings (Addon)[/COLOR][/B]", 'settings_addon')

    dialog = xbmcgui.Dialog()
    ret = dialog.contextmenu(options)

    if ret < 0:
        return # Utilizatorul a anulat

    if dispatch[ret] == 'settings_addon':
        xbmcaddon.Addon('plugin.video.tmdbmovies').openSettings()
        return

    s_id = str(tmdb_id)
    addon_type = 'tvshow' if media_type == 'tv' else media_type
    base_url = "plugin://plugin.video.tmdbmovies/"

    # Dictionarul de baza pentru parametri
    params = {
        'tmdb_id': s_id,
        'type': addon_type,
        'title': title,
        'imdb_id': imdb_id
    }
    if season is not None: params['season'] = str(season)
    if episode is not None: params['episode'] = str(episode)

    # Asociem modul in functie de optiunea aleasa
    params['mode'] = dispatch[ret]
    if dispatch[ret] == 'show_my_plays_menu':
        params['year'] = year
        params['imdb_id'] = imdb_id

    # Lansam plugin-ul cu parametrii formatati (fara sa inchidem Extended Info)
    xbmc.executebuiltin(f"RunPlugin({base_url}?{urlencode(params)})")

def action_refresh_trakt():
    xbmc.executebuiltin("RunPlugin(plugin://plugin.video.tmdbmovies/?mode=trakt_sync)")
# -----------------------------------------------------------

def get_tmdb_data(endpoint, params=None):
    if params is None: params = {}
    params['api_key'] = API_KEY
    
    params['language'] = 'en-US'
    
    try:
        from resources.lib.core.config import get_plot_language_code, LANG_TO_TMDB, get_plot_img_lang
        lang_code = get_plot_language_code()
        is_non_en = lang_code != 'en'
        img_lang = get_plot_img_lang()
    except:
        lang_code = 'en'
        is_non_en = False
        img_lang = 'en,null'
    
    params['include_image_language'] = img_lang
    
    if 'include_video_language' not in params:
        params['include_video_language'] = 'en,null'
        
    if is_non_en:
        if 'append_to_response' in params:
            if 'translations' not in params['append_to_response']:
                params['append_to_response'] += ',translations'
        else:
            params['append_to_response'] = 'translations'
    
    url = f"https://api.themoviedb.org/3/{endpoint}"
    try:
        response = requests.get(url, params=params, timeout=10)
        if response.status_code == 200:
            data = response.json()
            
            if is_non_en:
                if 'translations' in data:
                    for t in data['translations'].get('translations', []):
                        if t.get('iso_639_1') == lang_code:
                            loc_data = t.get('data', {})
                            if loc_data.get('overview'): 
                                data['overview'] = loc_data['overview']
                            if loc_data.get('tagline'): 
                                data['tagline'] = loc_data['tagline']
                            break
                
                if 'images' in data:
                    imgs = data['images']
                    loc_posters = [p for p in (imgs.get('posters', []) or imgs.get('stills', [])) if p.get('iso_639_1') == lang_code]
                    if loc_posters:
                        if 'poster_path' in data: data['poster_path'] = loc_posters[0]['file_path']
                        if 'still_path' in data: data['still_path'] = loc_posters[0]['file_path']
                        
                    loc_backs = [b for b in imgs.get('backdrops', []) if b.get('iso_639_1') == lang_code]
                    if loc_backs and 'backdrop_path' in data:
                        data['backdrop_path'] = loc_backs[0]['file_path']
                        
            return data
    except Exception as e:
        log(f"API Fetch Error: {e}")
    return {}


def get_youtube_api_data(query):
    # --- CAUTARE YOUTUBE CU ROTATIE DE CHEI ---
    if not query: return []
    
    base_url = "https://www.googleapis.com/youtube/v3/search"
    
    # Incercam fiecare cheie din lista
    for api_key in YOUTUBE_KEYS:
        params = {
            'part': 'snippet',
            'q': query,
            'type': 'video',
            'maxResults': 50,
            'key': api_key,
            'relevanceLanguage': 'en'
        }
        
        try:
            xbmc.log(f"[YOUTUBE_DEBUG] Trying key ending in ...{api_key[-4:]}", level=xbmc.LOGINFO)
            r = requests.get(base_url, params=params, timeout=5)
            
            if r.status_code == 200:
                data = r.json()
                items = data.get('items', [])
                xbmc.log(f"[YOUTUBE_DEBUG] Success! Found {len(items)} videos.", level=xbmc.LOGINFO)
                return items
            elif r.status_code == 403:
                xbmc.log(f"[YOUTUBE_DEBUG] Quota Exceeded for key ...{api_key[-4:]}. Trying next...", level=xbmc.LOGINFO)
                continue # Trecem la urmatoarea cheie
            else:
                xbmc.log(f"[YOUTUBE_DEBUG] API Error: {r.status_code}", level=xbmc.LOGINFO)
                
        except Exception as e:
            xbmc.log(f"[YOUTUBE_DEBUG] Request Failed: {e}", level=xbmc.LOGINFO)
            
    xbmc.log("[YOUTUBE_DEBUG] All keys failed!", level=xbmc.LOGINFO)
    return []

_YT_IOS_UA = 'com.google.ios.youtube/20.20.7 (iPhone16,2; U; CPU iOS 18_5_0 like Mac OS X)'
_YT_SEARCH_CACHE = {}
_YT_SEARCH_TTL = 604800


def _yt_cache_get(query):
    try:
        hit = _YT_SEARCH_CACHE.get(query)
        if hit and time.time() - hit[0] < _YT_SEARCH_TTL:
            return hit[1]
    except:
        pass
    try:
        from resources.lib.core.cache import MainCache
        data = MainCache().get('ytsearch_' + query)
        if data:
            try:
                _YT_SEARCH_CACHE[query] = (time.time(), data)
            except:
                pass
            return data
    except:
        pass
    return None


def _yt_cache_set(query, items):
    try:
        _YT_SEARCH_CACHE[query] = (time.time(), items)
    except:
        pass
    try:
        from resources.lib.core.cache import MainCache
        MainCache().set('ytsearch_' + query, items, expiration=168)
    except:
        pass


def search_youtube_innertube(query, max_results=25):
    if not query:
        return []
    try:
        cpn = ''.join(random.choice('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_') for _ in range(16))
        payload = {
            'context': {'client': {
                'clientName': 'IOS',
                'clientVersion': '20.20.7',
                'deviceMake': 'Apple',
                'deviceModel': 'iPhone16,2',
                'osName': 'iOS',
                'osVersion': '18.5.0.22F76',
                'platform': 'MOBILE',
                'hl': 'en',
                'gl': 'US',
            }},
            'cpn': cpn,
            'query': query,
        }
        headers = {
            'Origin': 'https://m.youtube.com',
            'User-Agent': _YT_IOS_UA,
            'X-YouTube-Client-Name': '5',
            'X-YouTube-Client-Version': '20.20.7',
            'Content-Type': 'application/json',
        }
        r = requests.post('https://www.youtube.com/youtubei/v1/search?prettyPrint=false', data=json.dumps(payload), headers=headers, timeout=15)
        body = r.json()
    except Exception as e:
        log(f"Innertube search error: {e}")
        return []
    out = []
    seen_ids = set()

    def push(info):
        vid = (info.get('id') or '').strip()
        if vid in seen_ids or not vid:
            return
        seen_ids.add(vid)
        info['id'] = vid
        info['title'] = (info.get('title') or '').strip()
        out.append(info)
        return len(out) >= max_results

    def walk(node, cur=None):
        if len(out) >= max_results:
            return True
        if isinstance(node, dict):
            vr = node.get('videoRenderer')
            if isinstance(vr, dict):
                runs = (vr.get('title') or {}).get('runs') or []
                t = ''.join(x.get('text', '') for x in runs) if runs else ((vr.get('title') or {}).get('simpleText') or '')
                if push({'id': vr.get('videoId') or '', 'title': t}):
                    return True
            cvm_title = ''
            try:
                vd = (node.get('compactVideoModel') or {}).get('compactVideoData', {}).get('videoData', {})
                if isinstance(vd, dict) and vd.get('dragAndDropUrl'):
                    durl = vd.get('dragAndDropUrl') or ''
                    vid = durl.split('watch?v=')[1].split('&')[0].split('#')[0] if 'watch?v=' in durl else ''
                    md = vd.get('metadata') or {}
                    vt = md.get('title') or ''
                    if isinstance(vt, dict):
                        runs = vt.get('runs') or []
                        vt = ''.join(x.get('text', '') for x in runs) if runs else (vt.get('simpleText') or '')
                    det = md.get('metadataDetails') or ''
                    if isinstance(det, dict):
                        runs = det.get('runs') or []
                        det = ''.join(x.get('text', '') for x in runs) if runs else (det.get('simpleText') or '')
                    views = ''
                    published = ''
                    if det and '\u00b7' in det:
                        views, published = [x.strip() for x in det.split('\u00b7', 1)]
                    th = vd.get('thumbnail') or {}
                    srcs = th.get('image', {}).get('sources') or []
                    thumb = srcs[0].get('url') if srcs else ''
                    cvm_title = vt if isinstance(vt, str) else ''
                    if push({'id': vid, 'title': vt, 'channel': md.get('byline') or '',
                             'views_text': det, 'views': views, 'published': published,
                             'duration': th.get('timestampText') or '', 'thumb': thumb}):
                        return True
            except Exception:
                pass
            try:
                vd = ((node.get('videoWithContextData') or {}).get('videoData')) or {}
                durl = vd.get('dragAndDropUrl') or ''
                vid = durl.split('watch?v=')[1].split('&')[0].split('#')[0] if 'watch?v=' in durl else ''
                if vid and len(vid) == 11:
                    t = ''
                    try:
                        t = vd['lockupMetadata']['lockupMetadataViewModel']['title']['content'] or ''
                    except Exception:
                        pass
                    ts = None
                    try:
                        ts = (vd.get('thumbnail') or {}).get('timestampText')
                    except Exception:
                        ts = None
                    if push({'id': vid, 'title': t, 'duration': ts or ''}):
                        return True
            except Exception:
                pass
            cvm = node.get('compactVideoModel')
            if isinstance(cvm, dict):
                try:
                    cur_title = cvm['compactVideoData']['videoData']['metadata']['title']
                except Exception:
                    cur_title = ''
            else:
                cur_title = (cur or {}).get('title', '')
            w = node.get('watchEndpoint')
            if isinstance(w, dict) and w.get('videoId'):
                if push({'id': w['videoId'], 'title': cur_title or ''}):
                    return True
            for v in node.values():
                if walk(v, cur):
                    return True
        elif isinstance(node, list):
            for v in node:
                if walk(v, cur):
                    return True
        return False

    try:
        contents = body['contents']['sectionListRenderer']['contents']
    except Exception:
        contents = None
    if contents is None:
        try:
            contents = body['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['contents']
        except Exception:
            contents = []
    try:
        for sec in contents:
            if walk(sec):
                break
    except Exception as e:
        log(f"Innertube search parse error: {e}")
    return out


def _yt_valid_duration(ts):
    try:
        parts = str(ts or '').strip().split(':')
        if len(parts) not in (2, 3):
            return False
        return all(p.isdigit() and p for p in parts)
    except:
        return False


def get_youtube_related(video_id, max_results=10):
    if not video_id:
        return []
    try:
        cpn = ''.join(random.choice('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_') for _ in range(16))
        payload = {
            'context': {'client': {
                'clientName': 'IOS',
                'clientVersion': '20.20.7',
                'deviceMake': 'Apple',
                'deviceModel': 'iPhone16,2',
                'osName': 'iOS',
                'osVersion': '18.5.0.22F76',
                'platform': 'MOBILE',
                'hl': 'en',
                'gl': 'US',
            }},
            'cpn': cpn,
            'videoId': video_id,
            'contentCheckOk': True,
            'racyCheckOk': True,
        }
        headers = {
            'Origin': 'https://m.youtube.com',
            'User-Agent': _YT_IOS_UA,
            'X-YouTube-Client-Name': '5',
            'X-YouTube-Client-Version': '20.20.7',
            'Content-Type': 'application/json',
        }
        r = requests.post('https://www.youtube.com/youtubei/v1/next?prettyPrint=false', data=json.dumps(payload), headers=headers, timeout=15)
        body = r.json()
    except Exception as e:
        log(f"Innertube related error: {e}")
        return []
    out = []
    seen_ids = set()
    ts_map = {}

    def push(info, ts=None):
        vid = (info.get('id') or '').strip()
        if vid in seen_ids or not vid:
            return
        seen_ids.add(vid)
        info['id'] = vid
        info['title'] = (info.get('title') or '').strip()
        out.append(info)
        ts_map[vid] = ts
        return len(out) >= max_results

    def walk(node, cur_title=''):
        if len(out) >= max_results:
            return True
        if isinstance(node, dict):
            for key in ('videoRenderer', 'compactVideoRenderer'):
                vr = node.get(key)
                if isinstance(vr, dict):
                    vid = vr.get('videoId') or ''
                    runs = (vr.get('title') or {}).get('runs') or []
                    t = ''.join(x.get('text', '') for x in runs) if runs else ((vr.get('title') or {}).get('simpleText') or '')
                    ts = None
                    vw = ''
                    dt = ''
                    du = ''
                    try:
                        for ov in vr.get('thumbnailOverlays', []) or []:
                            tos = (ov or {}).get('thumbnailOverlayTimeStatusRenderer')
                            if isinstance(tos, dict):
                                tx = tos.get('text')
                                if isinstance(tx, dict):
                                    oruns = tx.get('runs') or []
                                    ts = ''.join(x.get('text', '') for x in oruns) if oruns else (tx.get('simpleText') or '')
                                elif isinstance(tx, str):
                                    ts = tx
                                break
                    except:
                        ts = None
                    try:
                        vw = ((vr.get('viewCountText') or {}).get('simpleText')) or ''
                    except:
                        pass
                    try:
                        dt = ((vr.get('publishedTimeText') or {}).get('simpleText')) or ''
                    except:
                        pass
                    try:
                        du = ((vr.get('lengthText') or {}).get('simpleText')) or ''
                    except:
                        pass
                    if push({'id': vid, 'title': t, 'views': vw, 'date': dt, 'duration': du or ts or ''}, ts):
                        return True
            vwd = node.get('videoWithContextData')
            if isinstance(vwd, dict):
                try:
                    vd = vwd.get('videoData') or {}
                    durl = vd.get('dragAndDropUrl') or ''
                    vid = durl.split('watch?v=')[1].split('&')[0].split('#')[0] if 'watch?v=' in durl else ''
                    if len(vid) != 11:
                        vid = ''
                    t = ''
                    try:
                        t = vd['lockupMetadata']['lockupMetadataViewModel']['title']['content'] or ''
                    except Exception:
                        pass
                    if not t:
                        try:
                            t = vwd['onTap']['innertubeCommand']['coWatchWatchEndpointWrapperCommand']['videoTitle'] or ''
                        except Exception:
                            pass
                    ts = None
                    try:
                        ts = (vd.get('thumbnail') or {}).get('timestampText')
                    except:
                        ts = None
                    ch = ''
                    vw = ''
                    dt = ''
                    try:
                        rows = vd['lockupMetadata']['lockupMetadataViewModel']['metadata']['contentMetadataViewModel']['metadataRows'] or []
                        _texts = []
                        for _row in rows:
                            for _mp in (_row.get('metadataParts') or []):
                                _c = ((_mp.get('text') or {}).get('content')) or ''
                                if _c:
                                    _texts.append(_c.strip())
                        for _tx in _texts:
                            if '\u00b7' in _tx:
                                _pp = [_x.strip() for _x in _tx.split('\u00b7')]
                                if len(_pp) >= 3:
                                    ch, vw, dt = _pp[0], _pp[1], _pp[2]
                                elif len(_pp) == 2:
                                    vw, dt = _pp
                                break
                        if not vw:
                            for _tx in _texts:
                                if 'view' in _tx.lower():
                                    vw = _tx
                                    break
                        if not ch:
                            try:
                                ch = vwd['onTap']['innertubeCommand']['coWatchWatchEndpointWrapperCommand']['ownerDisplayName'] or ''
                            except Exception:
                                pass
                    except Exception:
                        pass
                    if vid and push({'id': vid, 'title': t, 'channel': ch, 'views': vw, 'date': dt, 'duration': ts or ''}, ts):
                        return True
                except Exception:
                    pass
            cvm = node.get('compactVideoModel')
            if isinstance(cvm, dict):
                try:
                    cur_title = cvm['compactVideoData']['videoData']['metadata']['title']
                except Exception:
                    cur_title = ''
            w = node.get('watchEndpoint')
            if isinstance(w, dict) and w.get('videoId'):
                if push({'id': w['videoId'], 'title': cur_title or ''}):
                    return True
            for v in node.values():
                if walk(v, cur_title):
                    return True
        elif isinstance(node, list):
            for v in node:
                if walk(v, cur_title):
                    return True
        return False

    try:
        sections = body['contents']['twoColumnWatchNextResults']['secondaryResults']['secondaryResults']['results']
    except Exception:
        sections = []
    if not sections:
        try:
            sections = []
            for sec in body['contents']['singleColumnWatchNextResults']['results']['results']['contents']:
                if isinstance(sec, dict) and 'itemSectionRenderer' in sec:
                    sections.extend(sec['itemSectionRenderer'].get('contents', []))
        except Exception:
            sections = []
    try:
        for sec in sections:
            if walk(sec):
                break
    except Exception as e:
        log(f"Innertube related parse error: {e}")
    good = [d for d in out if ts_map.get(d.get('id')) is None or _yt_valid_duration(ts_map.get(d.get('id')))]
    if not good:
        good = out
    log(f"Innertube related OK: {len(good)} videos ({len(out) - len(good)} without duration skipped).")
    return good


def get_youtube_search_results(query, max_results=25):
    if not query:
        return []
    cached = _yt_cache_get(query)
    if cached is not None:
        return cached
    found = search_youtube_innertube(query, max_results)
    if found:
        log(f"Innertube search OK: {len(found)} videos.")
        items = [{'id': {'videoId': d.get('id')}, 'snippet': {'title': d.get('title', ''), 'channelTitle': d.get('channel', ''), 'thumbnails': {'high': {'url': d.get('thumb') or 'https://img.youtube.com/vi/' + d.get('id', '') + '/mqdefault.jpg'}}, 'publishedAt': ''}} for d in found]
        _yt_cache_set(query, items)
        return items
    items = get_youtube_api_data(query)
    if items:
        _yt_cache_set(query, items)
    return items

def _yt_ts_to_seconds(ts):
    try:
        parts = [int(x) for x in str(ts or '').strip().split(':')]
        if len(parts) == 2:
            return parts[0] * 60 + parts[1]
        if len(parts) == 3:
            return parts[0] * 3600 + parts[1] * 60 + parts[2]
    except:
        pass
    return 0


_YT_META_CACHE = {}
_YT_META_TTL = 604800


def get_youtube_video_meta(video_id):
    if not video_id:
        return {}
    try:
        hit = _YT_META_CACHE.get(video_id)
        if hit and time.time() - hit[0] < _YT_META_TTL:
            return hit[1]
    except:
        pass
    try:
        from resources.lib.core.cache import MainCache
        data = MainCache().get('ytmeta_' + video_id)
        if data:
            try:
                _YT_META_CACHE[video_id] = (time.time(), data)
            except:
                pass
            return data
    except:
        pass
    meta = {}
    try:
        cpn = ''.join(random.choice('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_') for _ in range(16))
        payload = {
            'context': {'client': {
                'clientName': 'IOS',
                'clientVersion': '20.20.7',
                'deviceMake': 'Apple',
                'deviceModel': 'iPhone16,2',
                'osName': 'iOS',
                'osVersion': '18.5.0.22F76',
                'platform': 'MOBILE',
                'hl': 'en',
                'gl': 'US',
            }},
            'cpn': cpn,
            'videoId': video_id,
            'contentCheckOk': True,
            'racyCheckOk': True,
        }
        headers = {
            'Origin': 'https://m.youtube.com',
            'User-Agent': _YT_IOS_UA,
            'X-YouTube-Client-Name': '5',
            'X-YouTube-Client-Version': '20.20.7',
            'Content-Type': 'application/json',
        }
        r = requests.post('https://www.youtube.com/youtubei/v1/player?prettyPrint=false', data=json.dumps(payload), headers=headers, timeout=15)
        body = r.json()
        vd = (body.get('videoDetails')) or {}
        try:
            dur = int(vd.get('lengthSeconds') or 0)
        except:
            dur = 0
        meta = {'description': (vd.get('shortDescription') or '').strip(),
                'channel': vd.get('author') or '',
                'channel_id': vd.get('channelId') or '',
                'duration_sec': dur}
        try:
            mf = (body.get('microformat') or {}).get('playerMicroformatRenderer') or {}
            for k in ('publishDate', 'uploadDate'):
                if mf.get(k):
                    meta['published_date'] = str(mf[k])[:10]
                    break
        except:
            pass
    except Exception as e:
        log(f"Innertube meta error: {e}")
        return {}
    try:
        _YT_META_CACHE[video_id] = (time.time(), meta)
    except:
        pass
    try:
        from resources.lib.core.cache import MainCache
        MainCache().set('ytmeta_' + video_id, meta, expiration=168)
    except:
        pass
    return meta


def format_money(val):
    if not val: return ''
    try:
        # Transformam in int pentru a elimina zecimalele, apoi punem virgula
        return f"{int(val):,}"
    except:
        return str(val)

def format_money_short(val):
    """Formateaza banii scurt: 1 Mil, 2 Bil (Fara zecimale)"""
    if not val: return ''
    try:
        val = float(val)
        if val >= 1000000000:
            # .0f inseamna 0 zecimale (rotunjit)
            return f"{val/1000000000:.0f} Bil"
        elif val >= 1000000:
            # .0f inseamna 0 zecimale
            return f"{val/1000000:.0f} Mil"
        else:
            # ,.0f pune virgula la mii si scoate zecimalele
            return f"{val:,.0f}"
    except:
        return str(val)

def format_date(date_str):
    if not date_str: return ''
    try:
        from resources.lib.core.config import _fmt_dmy
        return _fmt_dmy(date_str)
    except:
        return date_str

def format_date_short(date_str):
    if not date_str: return ''
    try:
        from resources.lib.core.config import _fmt_dmy
        return _fmt_dmy(date_str)
    except:
        return date_str

def calculate_age(birthday_str, deathday_str=None):
    if not birthday_str:
        return ''
    
    import time
    import xbmc

    try:
        # 1. Parsare manuala a datei nasterii (YYYY-MM-DD)
        # Ocolim complet datetime.strptime care da eroare
        parts = str(birthday_str).strip().split('-')
        if len(parts) != 3:
            return ''
        
        b_year = int(parts[0])
        b_month = int(parts[1])
        b_day = int(parts[2])
        
        # 2. Determinam data curenta (sau data decesului)
        if deathday_str and str(deathday_str).strip():
            d_parts = str(deathday_str).strip().split('-')
            if len(d_parts) == 3:
                now_year = int(d_parts[0])
                now_month = int(d_parts[1])
                now_day = int(d_parts[2])
            else:
                # Fallback la azi daca data decesului e gresita
                t = time.localtime()
                now_year, now_month, now_day = t.tm_year, t.tm_mon, t.tm_mday
        else:
            # Folosim time.localtime() care este low-level si sigur
            t = time.localtime()
            now_year, now_month, now_day = t.tm_year, t.tm_mon, t.tm_mday
            
        # 3. Calcul matematic pur (Scadem 1 daca ziua nasterii nu a trecut inca anul acesta)
        age = now_year - b_year
        if (now_month, now_day) < (b_month, b_day):
            age -= 1
            
        return str(age)
        
    except Exception as e:
        xbmc.log(f"[TMDb Extended INFO] Manual Age Calc Error: {e}", level=xbmc.LOGINFO)
        return ''

def get_kodi_library_movies():
    try:
        query = {
            "jsonrpc": "2.0",
            "method": "VideoLibrary.GetMovies",
            "params": {"properties": ["uniqueid", "year", "title", "playcount"]},
            "id": 1
        }
        response = xbmc.executeJSONRPC(json.dumps(query))
        data = json.loads(response)
        
        library_movies = {}
        if 'result' in data and 'movies' in data['result']:
            for movie in data['result']['movies']:
                unique_ids = movie.get('uniqueid', {})
                tmdb_id = unique_ids.get('tmdb', '')
                if tmdb_id:
                    library_movies[str(tmdb_id)] = {
                        'dbid': movie['movieid'],
                        'playcount': movie.get('playcount', 0)
                    }
        return library_movies
    except Exception as e:
        log(f"Error getting Kodi library: {e}")
        return {}

def get_kodi_library_tvshows():
    try:
        query = {
            "jsonrpc": "2.0",
            "method": "VideoLibrary.GetTVShows",
            "params": {"properties": ["uniqueid", "year", "title", "watchedepisodes", "episode"]},
            "id": 1
        }
        response = xbmc.executeJSONRPC(json.dumps(query))
        data = json.loads(response)
        
        library_shows = {}
        if 'result' in data and 'tvshows' in data['result']:
            for show in data['result']['tvshows']:
                unique_ids = show.get('uniqueid', {})
                tmdb_id = unique_ids.get('tmdb', '')
                if tmdb_id:
                    total_eps = show.get('episode', 0)
                    watched_eps = show.get('watchedepisodes', 0)
                    library_shows[str(tmdb_id)] = {
                        'dbid': show['tvshowid'],
                        'watched': watched_eps,
                        'unwatched': total_eps - watched_eps,
                        'playcount': 1 if watched_eps == total_eps and total_eps > 0 else 0
                    }
        return library_shows
    except Exception as e:
        log(f"Error getting Kodi TV library: {e}")
        return {}

def show_text_dialog(heading, text):
    dialog = xbmcgui.Dialog()
    dialog.textviewer(heading, text)

def control_exists(window, control_id):
    try:
        window.getControl(control_id)
        return True
    except:
        return False

def create_list_item_with_year(label, year_str, icon, media_type='video'):
    # --- 1. TITLU BOLD ---
    li = xbmcgui.ListItem(f"[B]{label}[/B]")
    
    li.setArt({'thumb': icon, 'poster': icon, 'icon': icon})
    
    if year_str:
        # --- 2. AN BOLD (Setam Proprietatea Year, nu doar InfoTag-ul) ---
        li.setProperty('Year', f"[B]{year_str}[/B]")
        li.setProperty('year', f"[B]{year_str}[/B]") # Dublura pentru siguranta
        
        # Setam si Label2 pentru skin-urile care il folosesc
        li.setLabel2(f"[B]{year_str}[/B]")
        
        try:
            # Setam si anul numeric pentru sortare interna
            year_int = int(year_str)
            video_info = li.getVideoInfoTag()
            video_info.setYear(year_int)
        except:
            pass
    
    return li

# --- CLASA SLIDESHOW BAZATA PE XML ---
class SlideShow(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super(SlideShow, self).__init__(*args)
        self.images = kwargs.get('images', [])
        self.index = kwargs.get('index', 0)
        self.list_id = 10001 # ID-ul listei din XML-ul tau

    def onInit(self):
        try:
            # Populam lista din XML cu imagini
            ctl = self.getControl(self.list_id)
            items = []
            for img_url in self.images:
                # Creem item-ul. Proprietatea 'Original' este folosita in XML la texture
                li = xbmcgui.ListItem(path=img_url)
                li.setProperty('Original', img_url)
                items.append(li)
            
            ctl.addItems(items)
            
            # Selectam imaginea pe care s-a dat click
            ctl.selectItem(self.index)
            # Dam focus listei pentru a putea naviga
            self.setFocusId(self.list_id)
            
        except Exception as e:
            log(f"SlideShow Init Error: {e}")
            self.close()

    def onAction(self, action):
        # Inchidem la BACK sau ESC
        if action.getId() in [ACTION_PREVIOUS_MENU, ACTION_NAV_BACK]:
            self.close()

# --- FUNCTIE APELARE (Modificata sa foloseasca XML-ul) ---
def show_full_image(window, list_id):
    try:
        ctl = window.getControl(list_id)
        size = ctl.size()
        if size == 0: return
        
        # Colectam URL-urile
        images = []
        for i in range(size):
            # In ExtendedInfo am folosit 'image_url' ca proprietate
            url = ctl.getListItem(i).getProperty('image_url')
            if url: images.append(url)
            
        if not images: return
        
        idx = ctl.getSelectedPosition()
        if idx < 0: idx = 0
        
        # Lansam fereastra folosind XML-ul tau
        # Asigura-te ca numele fisierului XML este corect!
        ss = SlideShow('ext_SlideShow.xml', ADDON_PATH, 
                       images=images, index=idx)
        ss.doModal()
        del ss
        
    except Exception as e:
        log(f"ShowImage Error: {e}")
# ---------------------------------------------------------

class SeasonInfo(xbmcgui.WindowXMLDialog):
    """Pagina pentru informatii despre un sezon"""
    
    def __init__(self, *args, **kwargs):
        super(SeasonInfo, self).__init__(*args)
        self.tv_id = kwargs.get('tv_id')
        self.season_num = kwargs.get('season_num')
        self.tv_name = kwargs.get('tv_name', '')
        self.title_text = self.tv_name
        self.meta = {}
        self.episodes = []
        self.go_back = False
        self.next_info = None
        self.poster_urls = []
        self.still_urls = []
        self.showing_text_dialog = False
        self.plot_text = ''
        
        # --- MODIFICARE: Setam fundalul default ---
        bg_fallback = os.path.join(ADDON_PATH, 'resources', 'skins', 'Default', 'media', 'texture.png')
        self.setProperty('fanart', bg_fallback)
        self.setProperty('movie.ImageFilter', bg_fallback)
        self.setProperty('ImageFilter', bg_fallback)
        
    def onInit(self):
        self.setProperty('type', 'Season')
        
        # Cerem datele sezonului
        self.meta = get_tmdb_data(
            f"tv/{self.tv_id}/season/{self.season_num}",
            {'append_to_response': 'credits,images,videos', 'include_video_language': 'en,null'}
        )
        
        # FALLBACK: Daca sezonul nu exista, deschidem info de SERIAL
        if not self.meta or self.meta.get('success') == False:
            log(f"[SeasonInfo] Season {self.season_num} not found, falling back to TV show")
            self.close()
            
            try:
                from resources.lib.context.extended_info_mod import run_extended_info
                xbmc.sleep(100)
                run_extended_info(self.tv_id, 'tv', season=None, episode=None, tv_name=self.tv_name)
            except Exception as e:
                log(f"[SeasonInfo] Fallback error: {e}")
            return
        
        # --- FIX RATING SEZON ---
        tv_meta = get_tmdb_data(f"tv/{self.tv_id}/content_ratings")
        self.tv_mpaa = ""
        if tv_meta and 'results' in tv_meta:
            for r in tv_meta['results']:
                if r['iso_3166_1'] == 'US':
                    self.tv_mpaa = r['rating']
                    break
        
        self.episodes = self.meta.get('episodes', [])
        self.update_ui()

    def load_youtube_async(self):
        date_str = self.meta.get('release_date') or self.meta.get('first_air_date') or ''
        year = date_str[:4]
        
        primary_list = []
        secondary_list = []
        
        # =========================================================================
        # PLAN A: TMDb API (precis, legat de tmdb_id)
        # =========================================================================
        log(f"[ExtendedInfo] Trying TMDb trailers for {self.title_text}.")
        
        # Pasul 1: Datele deja existente (din fetch_data)
        tmdb_videos = self.meta.get('videos', {}).get('results', [])
        has_trailer = any(v.get('type') in ['Trailer', 'Teaser'] for v in tmdb_videos)
        
        # Pasul 2: DEEP SCAN REGIONAL (Daca nu avem trailer)
        if not tmdb_videos or not has_trailer:
            log("[ExtendedInfo] Missing trailer. Initiating Regional Deep Scan...")
            
            orig_lang = self.meta.get('original_language', 'en')
            lang_code = orig_lang.split('-')[0].split('_')[0]
            
            target_locales = ['en-US']
            if lang_code == 'hi':
                target_locales = ['hi-IN', 'ta-IN', 'te-IN', 'en-US']
            elif lang_code in ('ta', 'te', 'ml', 'kn', 'bn', 'pa'):
                target_locales = [f'{lang_code}-IN', 'hi-IN', 'en-US']
            elif lang_code == 'fr':
                target_locales = ['fr-FR', 'en-US']
            elif lang_code == 'de':
                target_locales = ['de-DE', 'en-US']
            else:
                target_locales = [f'{lang_code}-US', 'en-US']
            
            safe_langs = f"{lang_code},en,null"
            base_api = "https://api.themoviedb.org/3"
            
            backup_videos = []
            
            for locale in target_locales:
                try:
                    m_type = str(getattr(self, 'media_type', '') or '')
                    if m_type not in ('movie', 'tv'):
                        m_type = 'tv' if getattr(self, 'season_num', None) is not None else 'movie'
                    vid_id = getattr(self, 'tmdb_id', None) or getattr(self, 'tv_id', None) or ''
                    deep_url = (f"{base_api}/{m_type}/{vid_id}/videos"
                                f"?api_key={API_KEY}"
                                f"&language={locale}"
                                f"&include_video_language={safe_langs}")
                    
                    r = requests.get(deep_url, timeout=2)
                    
                    if r.status_code == 200:
                        data_vid = r.json()
                        found = data_vid.get('results', [])
                        
                        if found:
                            found_trailer_here = False
                            for v in found:
                                if v.get('type') in ['Trailer', 'Teaser']:
                                    found_trailer_here = True
                                    break
                            
                            if found_trailer_here:
                                log(f"[ExtendedInfo] FOUND TRAILER in locale: {locale}")
                                tmdb_videos = found
                                break
                            else:
                                if not backup_videos:
                                    backup_videos = found
                                    
                except Exception as e:
                    log(f"[ExtendedInfo] Deep scan error on {locale}: {e}")
            
            has_new_trailer = any(v.get('type') in ['Trailer', 'Teaser'] for v in tmdb_videos)
            if not has_new_trailer and backup_videos:
                log("[ExtendedInfo] No trailer found in Deep Scan. Using backup clips.")
                tmdb_videos = backup_videos
        
        # Procesare TMDb videos
        for v in tmdb_videos:
            if v.get('site') != 'YouTube':
                continue
            v_key = v.get('key')
            v_type = v.get('type', 'Videos')
            v_name = v.get('name', 'Unknown')
            v_iso = v.get('iso_639_1', 'en')
            
            if v_iso not in ['en', 'xx', 'null']:
                v_name = f"[{v_iso.upper()}] {v_name}"
            
            is_trailer = v_type in ['Trailer', 'Teaser']
            
            video_obj = {
                'name': v_name,
                'key': v_key,
                'type': v_type,
                'official': True,
                'thumb': f"https://img.youtube.com/vi/{v_key}/mqdefault.jpg",
                'published_at': v.get('published_at', ''),
                'lang': v_iso
            }
            
            if is_trailer:
                primary_list.append(video_obj)
            else:
                secondary_list.append(video_obj)
        
        # Sortare: Limba originala sus
        if primary_list:
            orig_lang = self.meta.get('original_language', 'en')
            def smart_sort(x):
                l = x['lang']
                if l == orig_lang: return 0
                if l == 'ro': return 1
                if l == 'en': return 2
                return 3
            primary_list.sort(key=smart_sort)
        
        # =========================================================================
        # PLAN B: Google YouTube API (in randul "YouTube Videos", mereu)
        # =========================================================================
        search_query = f"{self.title_text} {year} trailer"
        yt_results = get_youtube_search_results(search_query)
        
        if yt_results:
            yt_list = []
            for item in yt_results:
                snippet = item.get('snippet', {})
                video_id = item.get('id', {}).get('videoId')
                if not video_id: continue
                
                raw_title = html.unescape(snippet.get('title', ''))
                title = ""
                for char in raw_title:
                    if ord(char) < 60000: title += char
                
                title_lower = title.lower()
                is_trailer = 'trailer' in title_lower or 'teaser' in title_lower
                
                yt_list.append({
                    'name': title,
                    'key': video_id,
                    'type': 'Trailer' if is_trailer else 'Clip',
                    'official': is_trailer,
                    'thumb': snippet.get('thumbnails', {}).get('high', {}).get('url', ''),
                    'published_at': snippet.get('publishedAt', '')
                })
            secondary_list.extend(yt_list)  # TOATE rezultatele YouTube in randul 2
        
        # =========================================================================
        # PLAN C: YouTube search direct cu yt-dlp
        # =========================================================================
        if not primary_list and not secondary_list:
            log("[ExtendedInfo] No videos found via API or TMDb. Trying YouTube search...")
            try:
                from resources.lib.context.context_trailer import search_youtube_trailer
                yt_id = search_youtube_trailer(self.title_text, year)
                if yt_id:
                    log(f"[ExtendedInfo] Found trailer via YouTube search: {yt_id}")
                    video_obj = {
                        'name': f'{self.title_text} - Trailer',
                        'key': yt_id,
                        'type': 'Trailer',
                        'official': True,
                        'thumb': f"https://img.youtube.com/vi/{yt_id}/mqdefault.jpg",
                        'published_at': '',
                        'lang': 'en'
                    }
                    primary_list.append(video_obj)
            except Exception as e:
                log(f"[ExtendedInfo] YouTube search error: {e}")
        
        self.fill_video_list(1150, primary_list)
        self.fill_video_list(350, secondary_list)

    def update_ui(self):
        season_name = self.meta.get('name', f'Season {self.season_num}')
        self.plot_text = self.meta.get('overview', '') or f"Season {self.season_num} of {self.tv_name}"
        air_date = self.meta.get('air_date', '')
        # Data formatata frumos
        air_date_formatted = format_date_short(air_date)
        # Data simpla (anul)
        year = air_date[:4] if air_date else ''
        
        poster = IMG_BASE + self.meta.get('poster_path', '') if self.meta.get('poster_path') else ''
        ep_count = len(self.episodes)
        
        # --- NOU: TITLU COMPLET ---
        # Format: "Fallout - Season 2"
        if self.tv_name:
            full_title = f"{self.tv_name} - {season_name}"
        else:
            full_title = season_name
        
        # Actualizam title_text pentru YouTube trailer search
        self.title_text = self.tv_name if self.tv_name else season_name
        # --------------------------
        
        # --- TITLURI ---
        self.setProperty('movie.title', full_title)      # ERA: season_name
        self.setProperty('movie.Title', full_title)      # ERA: season_name
        self.setProperty('title', full_title)            # ERA: season_name
        self.setProperty('movie.originaltitle', season_name)  # ERA: self.tv_name
        
        # --- DATA (SOLUTIE AGRESIVA) ---
        # 1. Setam data formatata in toate proprietatile de data
        self.setProperty('movie.Premiered', air_date_formatted)
        self.setProperty('movie.release_date', air_date_formatted)
        self.setProperty('movie.ReleaseDate', air_date_formatted)
        self.setProperty('Premiered', air_date_formatted)
        self.setProperty('ReleaseDate', air_date_formatted)
        self.setProperty('Date', air_date_formatted) # Uneori XML-ul cauta 'Date'
        
        # 2. Setam ANUL (uneori e folosit ca fallback)
        self.setProperty('movie.year', year)
        self.setProperty('movie.Year', year)
        self.setProperty('year', year)
        
        # 3. TRUC: Setam Status-ul cu DATA -> MODIFICAT
        # Lasam gol pentru ca XML-ul sa foloseasca fallback-ul si sa scrie "Release Date"
        self.setProperty('Status', "")
        self.setProperty('movie.Status', "")
        
        # Setam Rating-ul Serialului la Sezon (ca sa nu mai apara NR)
        if hasattr(self, 'tv_mpaa') and self.tv_mpaa:
            self.setProperty('movie.mpaa', self.tv_mpaa)
        
        # 4. TRUC: Setam Studio cu DATA (daca studio e gol)
        self.setProperty('movie.Studio', air_date_formatted)
        self.setProperty('Studio', air_date_formatted)

        # --- EPISOADE SI DURATION ---
        self.setProperty('TotalEpisodes', str(ep_count))
        self.setProperty('episode_count', str(ep_count))
        
        # Ascundem duration (setam gol pentru a dezactiva grupul "Duration" din XML)
        self.setProperty('movie.duration', "")
        self.setProperty('duration', "")
        
        # --- TAGLINE ---
        # Punem "8 Episodes" in tagline daca nu apare altundeva
        self.setProperty('Tagline', f"{ep_count} Episodes")
        self.setProperty('movie.Tagline', f"{ep_count} Episodes")

        # --- RESTUL ---
        self.setProperty('movie.plot', self.plot_text)
        self.setProperty('movie.Plot', self.plot_text)
        self.setProperty('plot', self.plot_text)
        self.setProperty('movie.poster', poster)
        self.setProperty('poster', poster)
        
        if self.episodes and self.episodes[0].get('still_path'):
            fanart = BACKDROP_BASE + self.episodes[0]['still_path']
            self.setProperty('movie.fanart', fanart)
            self.setProperty('fanart', fanart)
            # COMENTAM linia veche ca sa nu puna imaginea episodului ca fundal
            # self.setProperty('ImageFilter', fanart)

        # --- MODIFICARE BACKGROUND SEZON ---
        texture_path = os.path.join(ADDON_PATH, 'resources', 'skins', 'Default', 'media', 'texture.png')
        self.setProperty('movie.ImageFilter', texture_path)
        self.setProperty('ImageFilter', texture_path)
        # -----------------------------------
        
        if self.episodes:
            avg_rating = sum(e.get('vote_average', 0) for e in self.episodes) / len(self.episodes)
            self.setProperty('movie.rating', f"{avg_rating:.1f}")
            self.setProperty('movie.Rating', f"{avg_rating:.1f}")
        
        self.setProperty('PlayButtonLabel', "Browse Episodes")
        
        # --- LISTE (neschimbate) ---
        self.fill_episode_list(2000, self.episodes)
        
        # LANSARE YOUTUBE IN FUNDAL
        t = threading.Thread(target=self.load_youtube_async)
        t.daemon = True  # <--- LINIE NOUA: Opreste thread-ul la iesire
        t.start()
        
        cast = self.meta.get('credits', {}).get('cast', [])[:20]
        self.fill_cast_list(1000, cast)
        posters = self.meta.get('images', {}).get('posters', [])
        self.poster_urls = [IMG_FULL + p['file_path'] for p in posters if p.get('file_path')]
        self.fill_image_list(1250, posters, 'poster')
        stills = []
        for ep in self.episodes:
            if ep.get('still_path'):
                stills.append({'file_path': ep['still_path']})
        self.still_urls = [BACKDROP_BASE + s['file_path'] for s in stills]
        self.fill_image_list(1350, stills, 'backdrop')
        
        # --- MODIFICARE FOCUS: Setam focus pe butonul PLAY (8) ---
        try: self.setFocusId(8)
        except: pass
        
    
    def fill_episode_list(self, list_id, episodes):
        try:
            if not control_exists(self, list_id): return
            ctl = self.getControl(list_id)
            ctl.reset()
            items = []
            
            for idx, ep in enumerate(episodes):
                ep_num = ep.get('episode_number', 0)
                ep_name = ep.get('name', f'Episode {ep_num}')
                still = f"https://image.tmdb.org/t/p/w500{ep['still_path']}" if ep.get('still_path') else 'DefaultVideo.png'
                air_date = format_date_short(ep.get('air_date', ''))
                
                # --- MODIFICARE: Titlu BOLD ---
                # XML-ul pune punctul automat, noi doar ingrosam textul
                li = xbmcgui.ListItem(f"[B]{ep_name}[/B]")
                # ------------------------------
                
                v_tag = li.getVideoInfoTag()
                try: v_tag.setEpisode(int(ep_num))
                except: pass
                v_tag.setTitle(ep_name)
                v_tag.setMediaType('episode')
                
                # --- MODIFICARE: Data BOLD ---
                if air_date:
                    li.setProperty('release_date', f"[B]{air_date}[/B]")
                # -----------------------------
                
                li.setArt({'thumb': still, 'icon': still, 'poster': still})
                li.setProperty('episode_number', str(ep_num))
                li.setProperty('media_type', 'episode')
                li.setProperty('DBTYPE', 'episode')
                li.setProperty('overview', ep.get('overview', ''))
                li.setProperty('rating', str(ep.get('vote_average', 0)))
                li.setProperty('Premiered', air_date)
                
                if watched_provider.is_episode_watched(self.tv_id, self.season_num, ep_num):
                    li.setProperty('PlayCount', '1')
                    li.setProperty('Overlay', 'Watched')
                    v_tag.setPlaycount(1)
                else:
                    li.setProperty('PlayCount', '0')
                
                items.append(li)
            
            ctl.addItems(items)
        except Exception as e:
            log(f"Error filling episode list: {e}")

    def fill_video_list(self, list_id, videos):
        # --- FUNCTIE VIDEO SEZON (MODIFICATA PENTRU GOOGLE API) ---
        try:
            if not control_exists(self, list_id): return
            ctl = self.getControl(list_id)
            ctl.reset()
            
            list_items = []
            
            for v in videos:
                label = v.get('name', 'Videos')
                # Tipul (Trailer, Recap, Clip) determinat in update_ui
                v_type = v.get('type', 'Videos')
                
                is_off = v.get('official', False)
                official_str = "Official" if is_off else "Standard"
                
                date_str = v.get('published_at', '')[:4]
                
                label2 = f"{official_str} {v_type}"
                if date_str:
                    label2 += f" • {date_str}"
                
                key = v.get('key')
                if not key: continue
                
                # Thumbnail
                icon = v.get('thumb')
                if not icon:
                    icon = f"https://img.youtube.com/vi/{key}/mqdefault.jpg"
                
                li = xbmcgui.ListItem(label)
                li.setLabel2(label2)
                li.setArt({'thumb': icon, 'icon': icon})
                li.setProperty('youtube_id', key)
                
                list_items.append(li)
            
            ctl.addItems(list_items)
        except Exception as e:
            pass # Ignoram erorile minore de UI
    
    def fill_cast_list(self, list_id, cast):
        try:
            if not control_exists(self, list_id): return
            ctl = self.getControl(list_id)
            ctl.reset()
            items = []
            for c in cast:
                name = c.get('name', '')
                character = c.get('character', '')
                
                # Numele actorului (Bold)
                li = xbmcgui.ListItem(f"[B]{name}[/B]")
                
                # --- MODIFICARE: Alias PINK BOLD ---
                if character:
                    formatted_char = f"[B][COLOR FFFF69B4]{character}[/COLOR][/B]"
                    li.setLabel2(formatted_char)
                    li.setProperty('character', formatted_char)
                    li.setProperty('role', formatted_char)
                # -----------------------------------
                
                # MODIFICARE: Folosim IMG_THUMB_SMALL pentru viteza
                icon = IMG_THUMB_SMALL + c['profile_path'] if c.get('profile_path') else 'DefaultActor.png'
                li.setArt({'thumb': icon, 'icon': icon})
                li.setProperty('id', str(c.get('id', '')))
                items.append(li)
            ctl.addItems(items)
        except Exception as e: pass
    
    def fill_image_list(self, list_id, images, img_type):
        try:
            if not control_exists(self, list_id): return
            ctl = self.getControl(list_id)
            ctl.reset()
            items = []
            base = IMG_FULL if img_type == 'poster' else BACKDROP_BASE
            for idx, img in enumerate(images):
                path = img.get('file_path', '')
                if not path: continue
                url = base + path
                li = xbmcgui.ListItem()
                li.setArt({'thumb': url, 'icon': url})
                li.setProperty('image_url', url)
                items.append(li)
            ctl.addItems(items)
        except Exception as e: pass
    
    def onAction(self, action):
        if action.getId() in [ACTION_PREVIOUS_MENU, ACTION_NAV_BACK]:
            self.go_back = True
            self.close()
    
    def onClick(self, controlId):
        # PLAY -> Sezon
        if controlId == 8:
            # --- MODIFICARE: AM SCOS self.close() ---
            action_play_dialog(
                self.tv_id, 
                'season', 
                season=self.season_num, 
                title=self.tv_name
            )

        elif controlId == 445: action_options_dialog(self.tv_id, 'season', season=self.season_num, title=self.tv_name)
        elif controlId == 447: action_refresh_trakt()
        elif controlId == 446: self.close()

        # --- RESTUL ---
        elif controlId == 132: # Plot
            if self.plot_text and not self.showing_text_dialog:
                self.showing_text_dialog = True
                show_text_dialog(f"Season {self.season_num}", self.plot_text)
                self.showing_text_dialog = False

        elif controlId == 2000: # Episodes List
            item = self.getControl(2000).getSelectedItem()
            if item:
                ep_num = item.getProperty('episode_number')
                self.next_info = ('episode', ep_num)
                self.close()
        
        elif controlId == 1150 or controlId == 350: # Videos (Official & Standard)
            item = self.getControl(controlId).getSelectedItem()
            yt_id = item.getProperty('youtube_id')
            if yt_id:
                self.next_info = ('youtube_play', yt_id)
                self.close()
        
        elif controlId == 1000: # Cast
            item = self.getControl(1000).getSelectedItem()
            if item and item.getProperty('id'):
                self.next_info = ('actor', item.getProperty('id'))
                self.close()
        
        elif controlId == 1250: show_full_image(self, 1250)
        elif controlId == 1350: show_full_image(self, 1350)


class EpisodeInfo(xbmcgui.WindowXMLDialog):
    """Pagina pentru informatii despre un episod"""
    
    def __init__(self, *args, **kwargs):
        super(EpisodeInfo, self).__init__(*args)
        self.tv_id = kwargs.get('tv_id')
        self.season_num = kwargs.get('season_num')
        self.episode_num = kwargs.get('episode_num')
        self.tv_name = kwargs.get('tv_name', '')
        self.meta = {}
        self.go_back = False
        self.next_info = None
        self.plot_text = ''
        self.showing_text_dialog = False
        self.still_urls = []
        
    def onInit(self):
        log(f"[EpisodeInfo] Opening S{self.season_num}E{self.episode_num} for TV ID {self.tv_id}")
        self.setProperty('type', 'Episode') 
        
        try:
            self.meta = get_tmdb_data(
                f"tv/{self.tv_id}/season/{self.season_num}/episode/{self.episode_num}",
                {'append_to_response': 'credits,images,videos', 'include_video_language': 'en,null'}
            )
            
            # FALLBACK: Daca episodul nu exista, deschidem info de SERIAL
            if not self.meta or self.meta.get('success') == False:
                log(f"[EpisodeInfo] Episode S{self.season_num}E{self.episode_num} not found, falling back to TV show")
                self.close()
                
                # Lansam dialogul pentru serial in loc de episod
                try:
                    # Inchidem acest dialog si deschidem TVShowInfo
                    from resources.lib.context.extended_info_mod import run_extended_info
                    xbmc.sleep(100)  # Mica pauza pentru a permite inchiderea
                    run_extended_info(self.tv_id, 'tv', season=None, episode=None, tv_name=self.tv_name)
                except Exception as e:
                    log(f"[EpisodeInfo] Fallback error: {e}")
                return
            
            self.update_ui()
        except Exception as e:
            log(f"[EpisodeInfo] Error in onInit: {e}")
            self.close()
    def update_ui(self):
        try:
            ep_name = self.meta.get('name', f'Episode {self.episode_num}')
            self.plot_text = self.meta.get('overview', 'No overview available.')
            
            air_date = self.meta.get('air_date', '')
            # Format: January 01, 2024
            air_date_formatted = format_date_short(air_date) 
            
            # Daca nu avem data formatata, punem anul sau string gol
            if not air_date_formatted:
                air_date_formatted = air_date[:4] if air_date else ''

            rating = self.meta.get('vote_average', 0)
            still = BACKDROP_BASE + self.meta.get('still_path', '') if self.meta.get('still_path') else ''
            
            # NOU: Titlu complet
            season_str = f"S{int(self.season_num):02d}"
            episode_str = f"E{int(self.episode_num):02d}"

            # Format: "Fallout - S02E08 - The Strip"
            if self.tv_name:
                title = f"{self.tv_name} - {season_str}{episode_str} - {ep_name}"
            else:
                title = f"{season_str}{episode_str} - {ep_name}"

            full_title = title

            # --- TITLE & SUBTITLE ---
            self.setProperty('movie.title', title)
            self.setProperty('movie.Title', title)
            self.setProperty('title', title)
            self.setProperty('movie.originaltitle', ep_name)  # Numele original al episodului
            
            # --- RATING ---
            if rating:
                self.setProperty('movie.rating', f"{rating:.1f}")
                self.setProperty('movie.Rating', f"{rating:.1f}")
            
            # --- DATE (SOLUTIA PENTRU AFISARE SUS) ---
            # 1. Setam proprietatea 'release_date' (lowercase) exact cum ai facut la lista
            self.setProperty('release_date', air_date_formatted)
            self.setProperty('movie.release_date', air_date_formatted)
            
            # 2. Setam si variantele clasice
            self.setProperty('movie.Premiered', air_date_formatted)
            self.setProperty('Premiered', air_date_formatted)
            
            # 3. TRUC: Unele skin-uri afiseaza sus doar 'Year'. 
            # Fortam data completa in campul Year ca sa fim siguri ca apare ceva.
            self.setProperty('year', air_date_formatted)
            self.setProperty('movie.year', air_date_formatted)
            self.setProperty('movie.Year', air_date_formatted)
            
            # --- PLOT ---
            self.setProperty('movie.plot', self.plot_text)
            self.setProperty('movie.Plot', self.plot_text)
            self.setProperty('plot', self.plot_text)
            
            # --- ARTWORK ---
            if still:
                self.setProperty('movie.poster', still)
                self.setProperty('movie.fanart', still)
                self.setProperty('fanart', still)
            
            # --- MODIFICARE BACKGROUND EPISOD ---
            texture_path = os.path.join(ADDON_PATH, 'resources', 'skins', 'Default', 'media', 'texture.png')
            self.setProperty('movie.ImageFilter', texture_path)
            self.setProperty('ImageFilter', texture_path)
            # ------------------------------------
            self.setProperty('PlayButtonLabel', "Play")
            
            # --- LISTE ---
            guest_stars = self.meta.get('guest_stars', [])
            regular_cast = self.meta.get('credits', {}).get('cast', [])
            all_cast = guest_stars + regular_cast
            self.fill_cast_list(1000, all_cast[:30])
            
            stills = self.meta.get('images', {}).get('stills', [])
            self.still_urls = [IMG_FULL + s['file_path'] for s in stills if s.get('file_path')]
            self.fill_image_list(1350, stills)
            
            # --- MODIFICARE FOCUS: Setam focus pe butonul PLAY (8) ---
            try: self.setFocusId(8)
            except: pass
            # ---------------------------------------------------------

        except Exception as e:
            log(f"[EpisodeInfo] Error in update_ui: {e}")
    
    def fill_cast_list(self, list_id, cast):
        try:
            if not control_exists(self, list_id): return
            ctl = self.getControl(list_id)
            ctl.reset()
            items = []
            for c in cast:
                name = c.get('name', '')
                character = c.get('character', '')
                
                # --- FIX: Numele actorului BOLD ---
                li = xbmcgui.ListItem(f"[B]{name}[/B]")
                
                # --- FIX: Alias PINK BOLD (ca la Sezoane/Filme) ---
                if character:
                    formatted_char = f"[B][COLOR FFFF69B4]{character}[/COLOR][/B]"
                    li.setLabel2(formatted_char)
                    li.setProperty('character', formatted_char)
                    li.setProperty('role', formatted_char)
                
                icon = IMG_THUMB_SMALL + c['profile_path'] if c.get('profile_path') else 'DefaultActor.png'
                li.setArt({'thumb': icon, 'icon': icon})
                li.setProperty('id', str(c.get('id', '')))
                items.append(li)
            ctl.addItems(items)
        except: pass
    
    def fill_image_list(self, list_id, images):
        try:
            if not control_exists(self, list_id): return
            ctl = self.getControl(list_id)
            ctl.reset()
            items = []
            for idx, img in enumerate(images):
                path = img.get('file_path', '')
                if not path: continue
                url = BACKDROP_BASE + path
                li = xbmcgui.ListItem()
                li.setArt({'thumb': url, 'icon': url})
                li.setProperty('image_url', url)
                items.append(li)
            ctl.addItems(items)
        except: pass
    
    def onAction(self, action):
        if action.getId() in [ACTION_PREVIOUS_MENU, ACTION_NAV_BACK]:
            self.go_back = True
            self.close()
    
    def onClick(self, controlId):
        # PLAY -> Episod
        if controlId == 8:
            # --- MODIFICARE: AM SCOS self.close() ---
            display_title = f"{self.tv_name} S{int(self.season_num):02d}E{int(self.episode_num):02d}"
            
            action_play_dialog(
                self.tv_id, 
                'episode', 
                season=self.season_num, 
                episode=self.episode_num,
                title=display_title 
            )

        elif controlId == 445: action_options_dialog(self.tv_id, 'episode', season=self.season_num, episode=self.episode_num, title=self.tv_name)
        elif controlId == 447: action_refresh_trakt()
        elif controlId == 446: self.close()

        # --- RESTUL ---
        elif controlId == 132: # Plot
            if self.plot_text and not self.showing_text_dialog:
                self.showing_text_dialog = True
                show_text_dialog("Overview", self.plot_text)
                self.showing_text_dialog = False
        
        elif controlId == 1000: # Actor
            item = self.getControl(1000).getSelectedItem()
            if item and item.getProperty('id'):
                self.next_info = ('actor', item.getProperty('id'))
                self.close()
        
        elif controlId == 1350: show_full_image(self, 1350)


class ExtendedInfo(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super(ExtendedInfo, self).__init__(*args)
        self.tmdb_id = kwargs.get('tmdb_id')
        self.media_type = kwargs.get('media_type', 'movie')
        self.meta = {}
        self.plot_text = ''
        self.title_text = ''
        self.showing_text_dialog = False
        self.go_back = False
        self.next_info = None
        
        self.kodi_movies = {}
        self.kodi_tvshows = {}
        
        # --- MODIFICARE: Folosim direct texture.png ---
        bg_fallback = os.path.join(ADDON_PATH, 'resources', 'skins', 'Default', 'media', 'texture.png')
            
        self.setProperty('movie.fanart', bg_fallback)
        self.setProperty('fanart', bg_fallback)
        self.setProperty('ImageColor', 'FF000000')
        self.setProperty('ImageFilter', bg_fallback)
        self.setProperty('WindowColor', 'FF000000')
        self.setProperty('script.extendedinfo_running', 'True')

    def onInit(self):
        self.kodi_movies = get_kodi_library_movies()
        self.kodi_tvshows = get_kodi_library_tvshows()
        self.fetch_data()
        
    def fetch_data(self):
        # 1. Cerem metadate + VIDEOS + Limbi Indiene
        # Adaugam 'videos' si toate limbile regionale in apelul principal
        append = "credits,recommendations,similar,images,external_ids,release_dates,content_ratings,videos"
        
        endpoint = f"{self.media_type}/{self.tmdb_id}"
        
        # LIMBI (scurt, lista lunga e respinsa de API)
        all_langs = "en,null"
        
        params = {
            'append_to_response': append,
            'include_video_language': all_langs
        }
        
        data = get_tmdb_data(endpoint, params)
        
        if not data:
            self.close()
            return

        self.meta = data
        self.plot_text = self.meta.get('overview', '')
        self.title_text = self.meta.get('title') or self.meta.get('name', '')
        
        # --- LOGICA COLECTIEI ---
        self.collection_items = []
        if self.media_type == 'movie' and self.meta.get('belongs_to_collection'):
            coll_id = self.meta['belongs_to_collection']['id']
            coll_data = get_tmdb_data(f"collection/{coll_id}")
            if coll_data:
                self.collection_items = coll_data.get('parts', [])
                self.collection_items.sort(key=lambda x: x.get('release_date', ''), reverse=False)
                
                coll_name = coll_data.get('name', '')
                coll_poster = IMG_BASE + coll_data.get('poster_path', '') if coll_data.get('poster_path') else ''
                coll_backdrop = BACKDROP_BASE + coll_data.get('backdrop_path', '') if coll_data.get('backdrop_path') else ''
                coll_overview = coll_data.get('overview', '')
                
                self.setProperty('movie.set.label', coll_name)
                self.setProperty('movie.set.id', str(coll_id))
                self.setProperty('movie.set.poster', coll_poster)
                self.setProperty('movie.set.thumb', coll_poster)
                self.setProperty('movie.set.fanart', coll_backdrop)
                self.setProperty('movie.set.overview', coll_overview)
                
        # Seasons
        self.seasons_items = []
        if self.media_type == 'tv':
            seasons = self.meta.get('seasons', [])
            self.seasons_items = [s for s in seasons if s.get('season_number', 0) > 0]
            self.setProperty('TotalSeasons', str(self.meta.get('number_of_seasons', len(self.seasons_items))))
            self.setProperty('TotalEpisodes', str(self.meta.get('number_of_episodes', 0)))

        self.update_ui()
        
        try: self.setFocusId(8)
        except: pass

    def load_youtube_async(self):
        date_str = self.meta.get('release_date') or self.meta.get('first_air_date') or ''
        year = date_str[:4]
        
        primary_list = []
        secondary_list = []
        
        # =========================================================================
        # PLAN A: TMDb API (precis, legat de tmdb_id)
        # =========================================================================
        log(f"[ExtendedInfo] Trying TMDb trailers for {self.title_text}.")
        
        tmdb_videos = self.meta.get('videos', {}).get('results', [])
        has_trailer = any(v.get('type') in ['Trailer', 'Teaser'] for v in tmdb_videos)
        
        if not tmdb_videos or not has_trailer:
            log("[ExtendedInfo] Missing trailer. Initiating Regional Deep Scan...")
            
            orig_lang = self.meta.get('original_language', 'en')
            lang_code = orig_lang.split('-')[0].split('_')[0]
            
            target_locales = ['en-US']
            if lang_code == 'hi':
                target_locales = ['hi-IN', 'ta-IN', 'te-IN', 'en-US']
            elif lang_code in ('ta', 'te', 'ml', 'kn', 'bn', 'pa'):
                target_locales = [f'{lang_code}-IN', 'hi-IN', 'en-US']
            elif lang_code == 'fr':
                target_locales = ['fr-FR', 'en-US']
            elif lang_code == 'de':
                target_locales = ['de-DE', 'en-US']
            else:
                target_locales = [f'{lang_code}-US', 'en-US']
            
            safe_langs = f"{lang_code},en,null"
            base_api = "https://api.themoviedb.org/3"
            backup_videos = []
            
            # Defensiv (paritate cu SeasonInfo): rezolvam media_type/tmdb_id sigur
            m_type = str(getattr(self, 'media_type', '') or '')
            if m_type not in ('movie', 'tv'):
                m_type = 'tv' if getattr(self, 'season_num', None) is not None else 'movie'
            vid_id = getattr(self, 'tmdb_id', None) or getattr(self, 'tv_id', None) or ''
            
            for locale in target_locales:
                try:
                    deep_url = (f"{base_api}/{m_type}/{vid_id}/videos"
                                f"?api_key={API_KEY}"
                                f"&language={locale}"
                                f"&include_video_language={safe_langs}")
                    
                    r = requests.get(deep_url, timeout=3)
                    
                    if r.status_code == 200:
                        data_vid = r.json()
                        found = data_vid.get('results', [])
                        
                        if found:
                            found_trailer_here = False
                            for v in found:
                                if v.get('type') in ['Trailer', 'Teaser']:
                                    found_trailer_here = True
                                    break
                            
                            if found_trailer_here:
                                log(f"[ExtendedInfo] FOUND TRAILER in locale: {locale}")
                                tmdb_videos = found
                                break
                            else:
                                if not backup_videos: backup_videos = found
                    else:
                        log(f"[ExtendedInfo] API Error {r.status_code} for locale {locale}")
                except Exception as e:
                    log(f"[ExtendedInfo] Deep scan error on {locale}: {e}")
            
            if not tmdb_videos and backup_videos:
                log("[ExtendedInfo] Using backup clips from Deep Scan.")
                tmdb_videos = backup_videos
        
        for v in tmdb_videos:
            if v.get('site') != 'YouTube': continue
            v_key = v.get('key')
            v_type = v.get('type', 'Videos')
            v_name = v.get('name', 'Unknown')
            v_iso = v.get('iso_639_1', 'en')
            
            if v_iso not in ['en', 'xx', 'null']:
                v_name = f"[{v_iso.upper()}] {v_name}"
            
            is_trailer = v_type in ['Trailer', 'Teaser']
            
            video_obj = {
                'name': v_name,
                'key': v_key,
                'type': v_type,
                'official': True,
                'thumb': f"https://img.youtube.com/vi/{v_key}/mqdefault.jpg",
                'published_at': v.get('published_at', ''),
                'lang': v_iso
            }
            
            if is_trailer: primary_list.append(video_obj)
            else: secondary_list.append(video_obj)
        
        if primary_list:
            orig_lang = self.meta.get('original_language', 'en')
            def smart_sort(x):
                l = x['lang']
                if l == orig_lang: return 0
                if l == 'ro': return 1
                if l == 'en': return 2
                return 3
            primary_list.sort(key=smart_sort)
        
        # =========================================================================
        # PLAN B: Google YouTube API (in randul "YouTube Videos", mereu)
        # =========================================================================
        search_query = f"{self.title_text} {year} trailer"
        yt_results = get_youtube_search_results(search_query)
        
        if yt_results:
            yt_list = []
            for item in yt_results:
                snippet = item.get('snippet', {})
                video_id = item.get('id', {}).get('videoId')
                if not video_id: continue
                
                raw_title = html.unescape(snippet.get('title', ''))
                title = ""
                for char in raw_title:
                    if ord(char) < 60000: title += char
                
                title_lower = title.lower()
                is_trailer = 'trailer' in title_lower or 'teaser' in title_lower
                
                yt_list.append({
                    'name': title,
                    'key': video_id,
                    'type': 'Trailer' if is_trailer else 'Clip',
                    'official': is_trailer,
                    'thumb': snippet.get('thumbnails', {}).get('high', {}).get('url', ''),
                    'published_at': snippet.get('publishedAt', '')
                })
            secondary_list.extend(yt_list)
        
        # =========================================================================
        # PLAN C: YouTube search direct cu yt-dlp
        # =========================================================================
        if not primary_list and not secondary_list:
            log("[ExtendedInfo] No videos found. Trying YouTube search...")
            try:
                from resources.lib.context.context_trailer import search_youtube_trailer
                yt_id = search_youtube_trailer(self.title_text, year)
                if yt_id:
                    log(f"[ExtendedInfo] Found trailer via YouTube search: {yt_id}")
                    primary_list.append({
                        'name': f'{self.title_text} - Trailer',
                        'key': yt_id,
                        'type': 'Trailer',
                        'official': True,
                        'thumb': f"https://img.youtube.com/vi/{yt_id}/mqdefault.jpg",
                        'published_at': '',
                        'lang': 'en'
                    })
            except Exception as e:
                log(f"[ExtendedInfo] YouTube search error: {e}")
        
        self.fill_video_list(1150, primary_list)
        self.fill_video_list(350, secondary_list)

    def update_ui(self):
        title = self.meta.get('title') or self.meta.get('name')
        plot = self.meta.get('overview', '')
        rating = str(round(self.meta.get('vote_average', 0), 1))
        votes = f"{self.meta.get('vote_count', 0):,}"
        
        # --- DATA & STATUS FIX ---
        raw_date = self.meta.get('release_date') or self.meta.get('first_air_date') or ''
        year = raw_date[:4]
        
        # 1. AICI FORMATAM DATA (DD.MM.YYYY)
        formatted_date = format_date(raw_date)
        # ------------------------------------
        
        raw_status = self.meta.get('status', '')
        status = raw_status 
        status_map = {
            'released': 'Released', 'post production': 'Post production',
            'in production': 'In production', 'ended': 'Ended',
            'returning series': 'Continuing', 'planned': 'Planned', 'canceled': 'Canceled'
        }
        if raw_status.lower() in status_map:
            status = status_map[raw_status.lower()]

        # Durata
        duration = ""
        try:
            if self.media_type == 'movie':
                r = self.meta.get('runtime')
                if r: 
                    r = int(r)
                    duration = f"{r // 60}h {r % 60}m"
            else:
                r = self.meta.get('episode_run_time', [])
                if r and r[0]: 
                    duration = f"{int(r[0])} min"
        except:
            pass

        studio = ""
        if self.media_type == 'movie':
            if self.meta.get('production_companies'): studio = self.meta['production_companies'][0]['name']
        else:
            if self.meta.get('networks'): studio = self.meta['networks'][0]['name']

        country_text = ""
        if self.media_type == 'movie':
            pcs = self.meta.get('production_countries', [])
            if pcs:
                names = [c['name'] for c in pcs if c.get('name')]
                country_text = ", ".join(names[:3])
        else:
            origins = self.meta.get('origin_country', [])
            if origins:
                country_text = ", ".join(origins[:3])

        mpaa = ""
        if self.media_type == 'movie':
            rels = self.meta.get('release_dates', {}).get('results', [])
            for r in rels:
                if r['iso_3166_1'] == 'US':
                    for c in r['release_dates']:
                        if c['certification']: mpaa = c['certification']; break
        else:
            rels = self.meta.get('content_ratings', {}).get('results', [])
            for r in rels:
                if r['iso_3166_1'] == 'US': mpaa = r['rating']; break

        poster = IMG_BASE + self.meta.get('poster_path', '') if self.meta.get('poster_path') else ''
        
        fanart = ""
        if self.meta.get('backdrop_path'):
            fanart = BACKDROP_BASE + self.meta.get('backdrop_path')
        
        logo = ""
        logos = [x['file_path'] for x in self.meta.get('images', {}).get('logos', []) if x.get('iso_639_1') == 'en']
        if logos: logo = IMG_BASE + logos[0]

        budget = format_money_short(self.meta.get('budget', 0))
        revenue = format_money_short(self.meta.get('revenue', 0))

        # --- TRUC: GEN + TAGLINE SUB TITLU ---
        genres_list = [g['name'] for g in self.meta.get('genres', [])]
        genres_str = " • ".join(genres_list)
        tagline = self.meta.get('tagline', '').strip()
        
        final_tagline = ""
        if tagline and genres_str:
            final_tagline = f"[COLOR yellow]{tagline}[/COLOR]   |   [COLOR FF00CED1]{genres_str}[/COLOR]"
        elif tagline:
            final_tagline = tagline
        elif genres_str:
            final_tagline = f"[COLOR FF00CED1]{genres_str}[/COLOR]"

        # --- PROPRIETATI COMPLETE DIAMOND INFO ---
        props = {
            'title': title, 'Title': title,
            'originaltitle': self.meta.get('original_title') or self.meta.get('original_name', title), 
            'plot': plot, 'Plot': plot,
            'TagLine': final_tagline, 'Tagline': final_tagline,
            'rating': rating, 'Rating': rating,
            'votes': votes, 'Votes': votes,
            'year': year, 'Year': year,
            'duration': duration, 'Duration': duration,
            'studio': studio, 'Studio': studio,
            'country': country_text, 'Country': country_text,
            'mpaa': mpaa, 'MPAA': mpaa,
            'poster': poster, 'Poster': poster,
            'clearlogo': logo, 'logo': logo,
            'Budget': budget, 'Revenue': revenue,
            'Status': status,
            
            # 2. FOLOSIM DATA FORMATA PESTE TOT
            'Premiered': formatted_date,    # Era raw_date
            'Release_Date': formatted_date, # Era raw_date
            'ReleaseDate': formatted_date,  # Era release_date_formatted (neformatat inainte)
            
            'dbid': '0', 'imdbnumber': self.meta.get('external_ids', {}).get('imdb_id', '')
        }
        
        # --- MODIFICARE BACKGROUND (TEXTURE.PNG) ---
        texture_path = os.path.join(ADDON_PATH, 'resources', 'skins', 'Default', 'media', 'texture.png')

        if fanart:
            props['fanart'] = fanart
            props['Fanart'] = fanart

        self.setProperty('movie.ImageFilter', texture_path)
        self.setProperty('ImageFilter', texture_path)
        # -------------------------------------------
        
        # Eticheta dinamica pentru buton
        btn_label = "Play" if self.media_type == 'movie' else "Browse"
        self.setProperty('PlayButtonLabel', btn_label)

        for k, v in props.items():
            self.setProperty(f'movie.{k}', str(v))
            self.setProperty(k, str(v))
            
        # Log DEBUG
        log(f"UPDATE_UI: Title={title}, Status={status}, Background={texture_path}")
            
        # Log DEBUG pentru a verifica daca Status se seteaza
        log(f"UPDATE_UI: Title={title}, Status={status}, Budget={budget}")

        # --- OPTIMIZARE: POPULARE LISTE IN FUNDAL (THREADING) ---
        # Asta face ca fereastra sa apara INSTANT, iar listele se incarca imediat dupa.
        def populate_lists_worker():
            # 1. Colectie / Sezoane
            if self.media_type == 'movie' and self.collection_items:
                self.fill_media_list(250, self.collection_items, 'movie')
            elif self.media_type == 'tv' and self.seasons_items:
                self.fill_season_list(250, self.seasons_items)
                    
            # 2. Actori
            cast = self.meta.get('credits', {}).get('cast', [])
            if self.media_type == 'tv': cast = cast[:20]
            self.fill_actor_list(1000, cast)
            
            # 3. Recomandari
            recommendations = self.meta.get('recommendations', {}).get('results', [])
            if not recommendations:
                recommendations = self.meta.get('similar', {}).get('results', [])
            if recommendations:
                recommendations = self.sort_by_library_and_year(recommendations, self.media_type)
                self.fill_media_list(150, recommendations, self.media_type)

            # 4. Imagini (Posters & Backdrops)
            posters = self.meta.get('images', {}).get('posters', [])
            self.fill_image_list(1250, posters, 'poster')
            
            backdrops = self.meta.get('images', {}).get('backdrops', [])
            self.fill_image_list(1350, backdrops, 'backdrop')

            # 5. YouTube (Ultimul pas)
            self.load_youtube_async()

        # Lansam worker-ul
        t = threading.Thread(target=populate_lists_worker)
        t.daemon = True  # <--- LINIE NOUA: Permite iesirea rapida fara buffering
        t.start()
        # --------------------------------------------------------

    def sort_by_library_and_year(self, items, media_type):
        in_library = []
        not_in_library = []
        library = self.kodi_movies if media_type == 'movie' else self.kodi_tvshows
        
        for item in items:
            tmdb_id_str = str(item.get('id', ''))
            year_str = (item.get('release_date') or item.get('first_air_date') or '')[:4]
            try: year_int = int(year_str) if year_str else 0
            except: year_int = 0
            item['_year_int'] = year_int
            if tmdb_id_str in library: in_library.append(item)
            else: not_in_library.append(item)
        
        in_library.sort(key=lambda x: x['_year_int'], reverse=True)
        not_in_library.sort(key=lambda x: x['_year_int'], reverse=True)
        return in_library + not_in_library

    def fill_media_list(self, list_id, items, media_type):
        try:
            ctl = self.getControl(list_id)
            ctl.reset()
            list_items = []
            library = self.kodi_movies if media_type == 'movie' else self.kodi_tvshows
            
            media_type_tag = 'movie' if media_type == 'movie' else 'tvshow'

            for i in items:
                label = i.get('title') or i.get('name', '')
                icon = IMG_THUMB_SMALL + i['poster_path'] if i.get('poster_path') else 'DefaultVideo.png'
                year_str = (i.get('release_date') or i.get('first_air_date') or '')[:4]
                
                li = create_list_item_with_year(label, year_str, icon, media_type)
                
                # --- SETARE INFOTAG ---
                tag = li.getVideoInfoTag()
                tag.setMediaType(media_type_tag)
                tag.setTitle(label)
                # ----------------------

                li.setProperty('id', str(i['id']))
                li.setProperty('media_type', media_type)
                
                tmdb_id_str = str(i['id'])
                
                playcount = 0
                if media_type == 'movie':
                    if watched_provider.is_movie_watched(tmdb_id_str):
                        playcount = 1
                elif media_type == 'tv':
                    tag.setTvShowTitle(label)
                    watched_eps = watched_provider.get_episode_watched_count(tmdb_id_str)
                    total_eps = trakt_sync.get_tv_meta_from_db(tmdb_id_str)
                    if total_eps == 0 and watched_eps > 0:
                        try:
                            r = requests.get(f"https://api.themoviedb.org/3/tv/{tmdb_id_str}?api_key={API_KEY}", timeout=3)
                            if r.status_code == 200:
                                total_eps = r.json().get('number_of_episodes', 0)
                                if total_eps:
                                    trakt_sync.set_tv_meta_to_db(tmdb_id_str, total_eps)
                        except:
                            pass
                    if total_eps > 0:
                        li.setProperty('WatchedEpisodes', str(watched_eps))
                        li.setProperty('UnWatchedEpisodes', str(max(0, total_eps - watched_eps)))
                    elif watched_eps > 0:
                        li.setProperty('WatchedEpisodes', str(watched_eps))
                        li.setProperty('UnWatchedEpisodes', '1')
                    if watched_eps > 0 and total_eps > 0 and watched_eps >= total_eps:
                        playcount = 1
                
                # Fallback Library
                if tmdb_id_str in library:
                    info = library[tmdb_id_str]
                    li.setProperty('DBID', str(info['dbid']))
                    if info.get('playcount', 0) > 0:
                        playcount = info['playcount']

                if playcount > 0:
                    li.setProperty('PlayCount', str(playcount))
                    tag.setPlaycount(playcount)
                # -------------------

                list_items.append(li)
            ctl.addItems(list_items)
        except Exception as e:
            log(f"Error filling list {list_id}: {e}")

    def fill_season_list(self, list_id, seasons):
        try:
            from resources.lib.core.config import ADDON as _cfg_addon
            _show_specials = _cfg_addon.getSetting('show_specials') == 'true'
            ctl = self.getControl(list_id)
            ctl.reset()
            list_items = []

            for s in seasons:
                season_num = s.get('season_number', 0)
                if season_num == 0 and not _show_specials:
                    continue
                ep_count = s.get('episode_count', 0)
                
                # --- MODIFICARE: Titlu BOLD ---
                raw_label = s.get('name', f"Season {season_num}")
                label = f"[B]{raw_label}[/B]"
                # ------------------------------
                
                icon = IMG_THUMB_SMALL + s['poster_path'] if s.get('poster_path') else 'DefaultVideo.png'
                
                li = xbmcgui.ListItem(label)
                
                # --- MODIFICARE: Episoade BOLD ---
                li.setLabel2(f"[B]{ep_count} Episodes[/B]")
                # ---------------------------------
                
                li.setArt({'thumb': icon, 'poster': icon})
                li.setProperty('season_number', str(season_num))
                li.setProperty('id', str(self.tmdb_id))
                li.setProperty('media_type', 'season')
                
                # Tag
                tag = li.getVideoInfoTag()
                tag.setMediaType('season')
                tag.setTitle(raw_label)
                li.setProperty('DBTYPE', 'season')
                
                # Logica Bifa Sezon (Ramane la fel)
                watched_eps = watched_provider.get_season_watched_count(self.tmdb_id, season_num)
                unwatched = max(0, ep_count - watched_eps)
                
                li.setProperty('WatchedEpisodes', str(watched_eps))
                li.setProperty('UnWatchedEpisodes', str(unwatched))
                li.setProperty('TotalEpisodes', str(ep_count))
                
                if ep_count > 0 and watched_eps >= ep_count:
                    li.setProperty('PlayCount', '1')
                    li.setProperty('Overlay', 'Watched')
                    tag.setPlaycount(1)
                else:
                    li.setProperty('PlayCount', '0')
                    tag.setPlaycount(0)
                
                list_items.append(li)
            ctl.addItems(list_items)
        except Exception as e: 
            log(f"Error filling season list: {e}")

    def fill_actor_list(self, list_id, actors):
        try:
            ctl = self.getControl(list_id)
            ctl.reset()
            list_items = []
            for a in actors:
                name = a.get('name', '')
                character = a.get('character', '')
                
                # Nume Actor Bold
                li = xbmcgui.ListItem(f"[B]{name}[/B]")
                
                # --- MODIFICARE: Alias PINK BOLD ---
                if character:
                    formatted_char = f"[B][COLOR FFFF69B4]{character}[/COLOR][/B]"
                    li.setLabel2(formatted_char)
                    li.setProperty('Character', formatted_char)
                    li.setProperty('character', formatted_char)
                # -----------------------------------

                icon = IMG_THUMB_SMALL + a['profile_path'] if a.get('profile_path') else 'DefaultActor.png'
                li.setArt({'thumb': icon, 'icon': icon, 'poster': icon})
                li.setProperty('id', str(a['id']))
                list_items.append(li)
            ctl.addItems(list_items)
        except: pass

    # --- MODIFICARE: Lista Videoclipuri plina ---
    def fill_video_list(self, list_id, videos):
        try:
            if not control_exists(self, list_id): return
            ctl = self.getControl(list_id)
            ctl.reset()
            
            list_items = []
            
            for v in videos:
                label = v.get('name', 'Videos')
                # Aici preluam ce am setat noi manual mai sus (Trailer/Clip)
                v_type = v.get('type', 'Videos')
                
                # Daca am setat noi official=True, scriem Official, altfel Unofficial
                is_off = v.get('official', False)
                official_str = "Official" if is_off else "Unofficial"
                
                # Data (Anul)
                date_str = v.get('published_at', '')[:4]
                
                label2 = f"{official_str} {v_type}"
                if date_str:
                    label2 += f" • {date_str}"
                
                key = v.get('key')
                if not key: continue
                
                # Thumbnail
                icon = v.get('thumb')
                if not icon:
                    icon = f"https://img.youtube.com/vi/{key}/mqdefault.jpg"
                
                li = xbmcgui.ListItem(label)
                li.setLabel2(label2)
                li.setArt({'thumb': icon, 'icon': icon})
                li.setProperty('youtube_id', key)
                
                list_items.append(li)
            
            ctl.addItems(list_items)
            
        except Exception as e:
            log(f"Error filling video list {list_id}: {e}")
    # ----------------------------------------------------------

    def fill_image_list(self, list_id, images, img_type):
        try:
            ctl = self.getControl(list_id)
            ctl.reset()
            list_items = []
            base = IMG_FULL if img_type == 'poster' else BACKDROP_BASE
            for idx, img in enumerate(images):
                path = img.get('file_path', '')
                if not path: continue
                full_url = base + path
                li = xbmcgui.ListItem()
                li.setArt({'thumb': full_url, 'icon': full_url})
                li.setProperty('image_url', full_url)
                list_items.append(li)
            ctl.addItems(list_items)
        except: pass

    def get_selected_image_url(self, list_id):
        try:
            item = self.getControl(list_id).getSelectedItem()
            if item: return item.getProperty('image_url')
        except: pass
        return None

    def onAction(self, action):
        if action.getId() in [ACTION_PREVIOUS_MENU, ACTION_NAV_BACK]:
            self.go_back = True
            self.close()

    def onClick(self, controlId):
        # PLAY
        if controlId == 8:
            # --- MODIFICARE: AM SCOS self.close() ---
            # Fereastra ramane deschisa in spate. 
            # Se va inchide automat DOAR daca alegi o optiune din meniu (via action_play_dialog)
            action_play_dialog(self.tmdb_id, self.media_type, title=self.title_text)
            
        # SETTINGS
        elif controlId == 445: action_options_dialog(self.tmdb_id, self.media_type, title=self.title_text)
        # REFRESH
        elif controlId == 447: action_refresh_trakt()
        # RETURN
        elif controlId == 446: self.close()

        # --- RESTUL BUTOANELOR VECHI ---
        elif controlId == 132: # Plot
            if self.plot_text and not self.showing_text_dialog:
                self.showing_text_dialog = True
                show_text_dialog(self.title_text, self.plot_text)
                self.showing_text_dialog = False
        
        elif controlId == 1000: # Actor
            item = self.getControl(1000).getSelectedItem()
            if item and item.getProperty('id'):
                self.next_info = ('actor', item.getProperty('id'))
                self.close()
            
        elif controlId in [150, 250]: # Recommendations/Collection
            item = self.getControl(controlId).getSelectedItem()
            if item:
                media_type = item.getProperty('media_type')
                item_id = item.getProperty('id')
                if media_type == 'season':
                    season_num = item.getProperty('season_number')
                    self.next_info = ('season', {'tv_id': self.tmdb_id, 'season_num': season_num, 'tv_name': self.title_text})
                    self.close()
                elif item_id:
                    self.next_info = ('media', {'id': item_id, 'type': media_type or 'movie'})
                    self.close()
            
        elif controlId == 1150 or controlId == 350: # Videos (Official & Standard)
            item = self.getControl(controlId).getSelectedItem()
            if item and item.getProperty('youtube_id'):
                self.next_info = ('youtube_play', item.getProperty('youtube_id'))
                self.close()
        
        elif controlId == 1250: show_full_image(self, 1250) # Posters
        elif controlId == 1350: show_full_image(self, 1350) # Backdrops



class ActorInfo(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super(ActorInfo, self).__init__(*args)
        self.actor_id = kwargs.get('actor_id')
        self.meta = {}
        self.actor_name = ''
        self.biography_text = ''
        self.showing_text_dialog = False
        self.go_back = False
        self.next_info = None
        
        self.kodi_movies = {}
        self.kodi_tvshows = {}
        
        # --- MODIFICARE: Folosim direct texture.png ---
        bg_fallback = os.path.join(ADDON_PATH, 'resources', 'skins', 'Default', 'media', 'texture.png')
        
        self.setProperty('fanart', bg_fallback)
        self.setProperty('actor.ImageFilter', bg_fallback)
        self.setProperty('ImageFilter', bg_fallback)

    def onInit(self):
        self.kodi_movies = get_kodi_library_movies()
        self.kodi_tvshows = get_kodi_library_tvshows()
        
        append = 'movie_credits,tv_credits,images,tagged_images,external_ids'
        data = get_tmdb_data(f"person/{self.actor_id}", {'append_to_response': append})
        if not data:
            self.close()
            return
        self.meta = data
        
        # --- PRELUARE DATE ---
        self.actor_name = self.meta.get('name', '')
        self.biography_text = self.meta.get('biography', '')
        birthday = self.meta.get('birthday', '')
        deathday = self.meta.get('deathday', '')
        place_of_birth = self.meta.get('place_of_birth', '')
        
        # --- FILTRARE CARACTERE CIUDATE (PATRATELE) ---
        raw_aka = self.meta.get('also_known_as', [])
        clean_aka = []
        for name in raw_aka:
            is_readable = True
            for char in name:
                if ord(char) > 1000: 
                    is_readable = False
                    break
            if is_readable:
                clean_aka.append(name)
        also_known_as_str = ", ".join(clean_aka[:5]) if clean_aka else ''
        
        thumb = IMG_BASE + self.meta.get('profile_path', '') if self.meta.get('profile_path') else ''

        # --- CALCUL VARSTA SI DATA ---
        age = calculate_age(birthday, deathday)
        birthday_formatted = format_date(birthday) if birthday else ''
        deathday_formatted = format_date(deathday) if deathday else ''
        
        final_birthday_str = birthday_formatted
        if final_birthday_str and age:
            if deathday:
                final_birthday_str = f"[B]{final_birthday_str}[/B]   [COLOR gray]Died at: [B][COLOR FFFDBD01]{age}[/COLOR][/B]"
            else:
                final_birthday_str = f"[B]{final_birthday_str}[/B]   [COLOR gray]Age: [B][COLOR FFFDBD01]{age}[/COLOR][/B]"

        # --- FORMATARE BOLD ---
        if also_known_as_str: also_known_as_str = f"[B]{also_known_as_str}[/B]"
        if place_of_birth: place_of_birth = f"[B]{place_of_birth}[/B]"
        if final_birthday_str: final_birthday_str = f"{final_birthday_str}"
        if deathday_formatted: deathday_formatted = f"[B]{deathday_formatted}[/B]"

        # --- LISTE CREDITE ---
        movies = self.meta.get('movie_credits', {}).get('cast', [])
        tvshows = self.meta.get('tv_credits', {}).get('cast', [])
        
        total_movies_str = f"[B]{len(movies)}[/B]"

        # --- SETARE PROPRIETATI XML ---
        self.setProperty('actor.title', self.actor_name)
        self.setProperty('actor.name', self.actor_name)
        self.setProperty('actor.AlsoKnownAs', also_known_as_str)
        self.setProperty('actor.Birthday', final_birthday_str)
        self.setProperty('actor.Age', "") 
        self.setProperty('actor.PlaceOfBirth', place_of_birth)
        self.setProperty('actor.Deathday', deathday_formatted)
        self.setProperty('actor.Biography', self.biography_text)
        self.setProperty('actor.TotalMovies', total_movies_str)
        self.setProperty('actor.thumb', thumb)
        
        texture_path = os.path.join(ADDON_PATH, 'resources', 'skins', 'Default', 'media', 'texture.png')
        self.setProperty('actor.ImageFilter', texture_path)
        self.setProperty('ImageFilter', texture_path)

        # --- UMPLERE LISTE ---
        movies = self.sort_credits_by_library_and_year(movies, 'movie')
        tvshows = self.sort_credits_by_library_and_year(tvshows, 'tv')

        self.fill_credits(150, movies, 'movie')
        self.fill_credits(250, tvshows, 'tv')
        
        # --- MODIFICARE: LANSARE YOUTUBE IN FUNDAL (THREAD) ---
        if control_exists(self, 350):
            t = threading.Thread(target=self.fill_actor_youtube_videos, args=(350, self.actor_name, movies[:15]))
            t.daemon = True  # <--- LINIE NOUA: Previne eroarea "waiting on thread"
            t.start()
        # -----------------------------------------------------
        
        actor_images = self.meta.get('images', {}).get('profiles', [])
        if control_exists(self, 450):
            self.fill_image_list(450, actor_images, 'profile')
        
        tagged_images = self.meta.get('tagged_images', {}).get('results', [])
        if control_exists(self, 750):
            self.fill_tagged_images(750, tagged_images)

    def sort_credits_by_library_and_year(self, items, media_type):
        in_library = []
        not_in_library = []
        library = self.kodi_movies if media_type == 'movie' else self.kodi_tvshows
        for item in items:
            tmdb_id_str = str(item.get('id', ''))
            year_str = (item.get('release_date') or item.get('first_air_date') or '')[:4]
            try: year_int = int(year_str) if year_str else 0
            except: year_int = 0
            item['_year_int'] = year_int
            if tmdb_id_str in library: in_library.append(item)
            else: not_in_library.append(item)
        in_library.sort(key=lambda x: x['_year_int'], reverse=True)
        not_in_library.sort(key=lambda x: x['_year_int'], reverse=True)
        return in_library + not_in_library

    def fill_credits(self, list_id, items, m_type):
        try:
            ctl = self.getControl(list_id)
            ctl.reset()
            l_items = []
            library = self.kodi_movies if m_type == 'movie' else self.kodi_tvshows
            db_type_str = 'movie' if m_type == 'movie' else 'tvshow'
            
            for i in items:
                label = i.get('title') or i.get('name', '')
                # --- VITEZA: ICONITE MICI ---
                icon = IMG_THUMB_SMALL + i['poster_path'] if i.get('poster_path') else 'DefaultVideo.png'
                
                character = i.get('character', '')
                year_str = (i.get('release_date') or i.get('first_air_date') or '')[:4]
                
                li = create_list_item_with_year(label, year_str, icon, m_type)
                
                if character:
                    formatted_char = f"[B][COLOR FFFF69B4]{character}[/COLOR][/B]"
                    li.setProperty('Character', formatted_char)
                    li.setProperty('character', formatted_char)
                    li.setLabel2(formatted_char)

                tag = li.getVideoInfoTag()
                tag.setMediaType(db_type_str)
                tag.setTitle(label)

                li.setProperty('id', str(i['id']))
                li.setProperty('media_type', m_type)
                
                tmdb_id_str = str(i['id'])
                playcount = 0
                
                if m_type == 'movie':
                    if watched_provider.is_movie_watched(tmdb_id_str): playcount = 1
                else:
                    tag.setTvShowTitle(label)
                    watched_eps = watched_provider.get_episode_watched_count(tmdb_id_str)
                    total_eps = trakt_sync.get_tv_meta_from_db(tmdb_id_str)
                    if total_eps == 0 and watched_eps > 0:
                        try:
                            r = requests.get(f"https://api.themoviedb.org/3/tv/{tmdb_id_str}?api_key={API_KEY}", timeout=3)
                            if r.status_code == 200:
                                total_eps = r.json().get('number_of_episodes', 0)
                                if total_eps:
                                    trakt_sync.set_tv_meta_to_db(tmdb_id_str, total_eps)
                        except:
                            pass
                    if total_eps > 0:
                        li.setProperty('WatchedEpisodes', str(watched_eps))
                        li.setProperty('UnWatchedEpisodes', str(max(0, total_eps - watched_eps)))
                    elif watched_eps > 0:
                        li.setProperty('WatchedEpisodes', str(watched_eps))
                        li.setProperty('UnWatchedEpisodes', '1')
                    if watched_eps > 0 and total_eps > 0 and watched_eps >= total_eps: playcount = 1
                
                if tmdb_id_str in library:
                    info = library[tmdb_id_str]
                    li.setProperty('DBID', str(info['dbid']))
                    if m_type == 'tv':
                        if info.get('watched', 0) > 0: playcount = 1
                    else:
                        if info.get('playcount', 0) > 0: playcount = 1

                if playcount > 0:
                    li.setProperty('PlayCount', '1')
                    tag.setPlaycount(1)
                else:
                    li.setProperty('PlayCount', '0')
                    tag.setPlaycount(0)

                l_items.append(li)
            ctl.addItems(l_items)
        except Exception as e:
            log(f"Error filling credits: {e}")

    def fill_actor_youtube_videos(self, list_id, actor_name, popular_movies):
        # --- LOGICA VIDEO ACTOR: INTERVIURI & BEST OF (GOOGLE API) ---
        try:
            
            search_query = f"{actor_name} interview best moments"
            results = get_youtube_search_results(search_query)
            
            list_items = []
            if results:
                for item in results:
                    snippet = item.get('snippet', {})
                    video_id = item.get('id', {}).get('videoId')
                    if not video_id: continue
                    
                    raw_title = html.unescape(snippet.get('title', ''))
                    title = ""
                    for char in raw_title:
                        if ord(char) < 60000: title += char
                    
                    title_lower = title.lower()
                    v_type = "Video"
                    if 'interview' in title_lower or 'talk' in title_lower: v_type = "Interview"
                    elif 'funny' in title_lower or 'moments' in title_lower or 'compilation' in title_lower: v_type = "Best Moments"
                    elif 'trailer' in title_lower: v_type = "Trailer"
                    
                    date_str = snippet.get('publishedAt', '')[:4]
                    label2 = f"{v_type}"
                    if date_str: label2 += f" • {date_str}"
                    
                    icon = snippet.get('thumbnails', {}).get('high', {}).get('url', '')
                    if not icon: icon = f"https://img.youtube.com/vi/{video_id}/mqdefault.jpg"
                    
                    li = xbmcgui.ListItem(title)
                    li.setLabel2(label2)
                    li.setArt({'thumb': icon, 'icon': icon})
                    li.setProperty('youtube_id', video_id)
                    list_items.append(li)

            if control_exists(self, list_id):
                ctl = self.getControl(list_id)
                ctl.addItems(list_items)
            
        except Exception as e:
            pass

    def fill_image_list(self, list_id, images, img_type):
        try:
            ctl = self.getControl(list_id)
            ctl.reset()
            l_items = []
            base = IMG_FULL
            for idx, img in enumerate(images):
                path = img.get('file_path', '')
                if not path: continue
                full_url = base + path
                
                # --- VITEZA: THUMB MIC ---
                thumb_url = IMG_THUMB_SMALL + path
                # -------------------------
                
                li = xbmcgui.ListItem()
                li.setArt({'thumb': thumb_url, 'icon': thumb_url})
                li.setProperty('image_url', full_url)
                l_items.append(li)
            ctl.addItems(l_items)
        except: pass

    def fill_tagged_images(self, list_id, images):
        try:
            ctl = self.getControl(list_id)
            ctl.reset()
            l_items = []
            for idx, img in enumerate(images[:30]):
                path = img.get('file_path', '')
                if not path: continue
                full_url = BACKDROP_BASE + path
                
                # --- VITEZA: THUMB MIC ---
                thumb_url = IMG_THUMB_SMALL + path
                # -------------------------
                
                li = xbmcgui.ListItem()
                li.setArt({'thumb': thumb_url, 'icon': thumb_url})
                li.setProperty('image_url', full_url)
                l_items.append(li)
            ctl.addItems(l_items)
        except: pass

    def get_selected_image_url(self, list_id):
        try:
            item = self.getControl(list_id).getSelectedItem()
            if item: return item.getProperty('image_url')
        except: pass
        return None

    def onAction(self, action):
        if action.getId() in [ACTION_PREVIOUS_MENU, ACTION_NAV_BACK]:
            self.go_back = True
            self.close()

    def onClick(self, controlId):
        if controlId == 132:
            if self.biography_text and not self.showing_text_dialog:
                self.showing_text_dialog = True
                show_text_dialog(self.actor_name, self.biography_text)
                self.showing_text_dialog = False
            return
        
        if controlId == 150:
            item = self.getControl(150).getSelectedItem()
            if item and item.getProperty('id'):
                self.next_info = ('media', {'id': item.getProperty('id'), 'type': 'movie'})
                self.close()
        elif controlId == 250:
            item = self.getControl(250).getSelectedItem()
            if item and item.getProperty('id'):
                self.next_info = ('media', {'id': item.getProperty('id'), 'type': 'tv'})
                self.close()
        
        elif controlId == 350:
            item = self.getControl(350).getSelectedItem()
            if item:
                yt_id = item.getProperty('youtube_id')
                if yt_id:
                    self.next_info = ('youtube_play', yt_id)
                    self.close()
        
        elif controlId == 450:
            show_full_image(self, 450)
        
        elif controlId == 750:
            show_full_image(self, 750)


def run_extended_info(tmdb_id, media_type='movie', clear_stack=True, season=None, episode=None, tv_name=''):
    if clear_stack:
        NAVIGATION_STACK.clear()
    
    # --- LOGICA DE RUTARE (ROUTING) ---
    # Decidem ce fereastra punem prima in stiva
    
    if media_type == 'tv' and season is not None and episode is not None:
        # 1. E EPISOD -> Deschidem direct EpisodeInfo
        log(f"[RunLoop] Direct Launch: EPISODE S{season}E{episode}")
        NAVIGATION_STACK.append({
            'type': 'episode', 
            'tv_id': tmdb_id, 
            'season_num': season, 
            'episode_num': episode, 
            'tv_name': tv_name
        })
        
    elif media_type == 'tv' and season is not None:
        # 2. E SEZON -> Deschidem direct SeasonInfo
        log(f"[RunLoop] Direct Launch: SEASON {season}")
        NAVIGATION_STACK.append({
            'type': 'season', 
            'tv_id': tmdb_id, 
            'season_num': season, 
            'tv_name': tv_name
        })
        
    else:
        # 3. E FILM sau SERIAL (ROOT) -> Deschidem ExtendedInfo standard
        log(f"[RunLoop] Direct Launch: MAIN MEDIA ({media_type})")
        NAVIGATION_STACK.append({
            'type': 'media', 
            'tmdb_id': tmdb_id, 
            'media_type': media_type
        })
    # ----------------------------------
    
    while NAVIGATION_STACK:
        current = NAVIGATION_STACK[-1]
        log(f"[RunLoop] Processing Stack Item: {current['type']}")
        
        if current['type'] == 'media':
            wd = ExtendedInfo(XML_VIDEO_INFO, ADDON_PATH, 
                            tmdb_id=current['tmdb_id'], 
                            media_type=current['media_type'])
            wd.doModal()
            
            if wd.go_back:
                NAVIGATION_STACK.pop()
            elif wd.next_info:
                next_type, next_data = wd.next_info
                if next_type == 'youtube_play':
                    meta = getattr(wd, 'meta', {})
                    t = meta.get('title') or meta.get('name')
                    g = ' / '.join([x['name'] for x in meta.get('genres', [])]) if meta.get('genres') else None
                    del wd
                    play_youtube_and_return(next_data, title=t, genre=g,
                                            plot=_trailer_info_plot(meta, g)[0], studio=_trailer_info_plot(meta, g)[1] or None,
                                            tmdb_id=current.get('tmdb_id'),
                                            dbtype=current.get('media_type'))
                    continue
                else:
                    handle_next_info(wd.next_info)
            else:
                del wd
                break
            del wd
            
        elif current['type'] == 'actor':
            wd = ActorInfo(XML_ACTOR_INFO, ADDON_PATH, actor_id=current['actor_id'])
            wd.doModal()
            
            if wd.go_back:
                NAVIGATION_STACK.pop()
            elif wd.next_info:
                next_type, next_data = wd.next_info
                if next_type == 'youtube_play':
                    meta = getattr(wd, 'meta', {})
                    t = meta.get('title') or meta.get('name')
                    g = ' / '.join([x['name'] for x in meta.get('genres', [])]) if meta.get('genres') else None
                    del wd
                    play_youtube_and_return(next_data, title=t, genre=g,
                                            plot=_trailer_info_plot(meta, g)[0], studio=_trailer_info_plot(meta, g)[1] or None,
                                            tmdb_id=current.get('tmdb_id'),
                                            dbtype=current.get('media_type'))
                    continue
                else:
                    handle_next_info(wd.next_info)
            else:
                del wd
                break
            del wd
            
        elif current['type'] == 'season':
            wd = SeasonInfo(XML_VIDEO_INFO, ADDON_PATH,
                          tv_id=current['tv_id'],
                          season_num=current['season_num'],
                          tv_name=current.get('tv_name', ''))
            wd.doModal()
            
            if wd.go_back:
                NAVIGATION_STACK.pop()
            elif wd.next_info:
                next_type, next_data = wd.next_info
                if next_type == 'youtube_play':
                    meta = getattr(wd, 'meta', {}) or {}
                    # Sezonul TMDb nu are tagline/genuri: le completam din
                    # serial, altfel trailerul pleaca fara motto+gen in OSD.
                    _tg, _gn = _show_tagline_genres(current.get('tv_id'))
                    if _tg and not meta.get('tagline'):
                        meta['tagline'] = _tg
                    if _gn and not meta.get('genres'):
                        meta['genres'] = [{'name': x.strip()} for x in _gn.split(',')]
                    t = meta.get('title') or meta.get('name') or current.get('tv_name')
                    g = ' / '.join([x['name'] for x in meta.get('genres', [])]) if meta.get('genres') else None
                    del wd
                    play_youtube_and_return(next_data, title=t, genre=g,
                                            plot=_trailer_info_plot(meta, g)[0], studio=_trailer_info_plot(meta, g)[1] or None,
                                            tmdb_id=current.get('tv_id'),
                                            dbtype='tv' if current.get('type') == 'season' else None)
                    continue
                log(f"[RunLoop] Season Next Info: {wd.next_info}")
                handle_next_info_season(wd.next_info, current)
            else:
                del wd
                break
            del wd
            
        elif current['type'] == 'episode':
            wd = EpisodeInfo(XML_VIDEO_INFO, ADDON_PATH,
                           tv_id=current['tv_id'],
                           season_num=current['season_num'],
                           episode_num=current['episode_num'],
                           tv_name=current.get('tv_name', ''))
            wd.doModal()
            
            if wd.go_back:
                NAVIGATION_STACK.pop()
            elif wd.next_info:
                handle_next_info_episode(wd.next_info)
            else:
                del wd
                break
            del wd
        else:
            break
    
    NAVIGATION_STACK.clear()

_season_show_cache = {}


def _show_tagline_genres(tv_id):
    """Tagline + genurile SERIALULUI. Sezonul TMDb (tv/{id}/season/{n}) nu are
    campuri de tagline/genres, deci antetul 'motto | gen' pentru OSD-ul
    trailerului nu s-ar putea construi din meta-ul sezonului."""
    try:
        if tv_id not in _season_show_cache:
            _season_show_cache[tv_id] = get_tmdb_data(f"tv/{tv_id}") or {}
        d = _season_show_cache[tv_id]
        tg = (d.get('tagline') or '').strip()
        gn = ', '.join([g.get('name') for g in (d.get('genres') or []) if g.get('name')])
        return tg, gn
    except Exception:
        return '', ''


def _trailer_info_plot(meta, genres_str):
    tagline = ((meta or {}).get('tagline') or '').strip()
    overview = ((meta or {}).get('overview') or '').strip()
    head = ''
    if tagline and genres_str:
        head = f"[B][COLOR yellow]{tagline}[/COLOR][/B] | [B][COLOR FF00CED1]{genres_str}[/COLOR][/B]\n"
    elif tagline:
        head = f"[B][COLOR yellow]{tagline}[/COLOR][/B]\n"
    elif genres_str:
        head = f"[B][COLOR FF00CED1]{genres_str}[/COLOR][/B]\n"
    studio = ''
    try:
        cos = ((meta or {}).get('production_companies') or []) or ((meta or {}).get('networks') or [])
        if cos and isinstance(cos, list) and cos[0].get('name'):
            studio = cos[0]['name']
    except:
        pass
    return head + overview, studio


def play_youtube_and_return(yt_id, title=None, genre=None, tmdb_id=None, dbtype=None, year=None, plot=None, studio=None):
    from resources.lib.playback.trailer_player import get_trailer_mode, get_trailer_url
    mode = get_trailer_mode()
    if mode == 'youtube_plugin':
        url = f"plugin://plugin.video.youtube/play/?video_id={yt_id}"
    else:
        url = get_trailer_url(yt_id, tmdb_id=tmdb_id, dbtype=dbtype,
                              title=title, year=year, plot=plot, studio=studio)
        if genre:
            from urllib.parse import urlencode
            url = '{}&{}'.format(url, urlencode({'genre': genre}))
    li = xbmcgui.ListItem(path=url)
    if title:
        tag = li.getVideoInfoTag()
        tag.setTitle(title)
        tag.setOriginalTitle(title)
    if genre:
        tag = li.getVideoInfoTag()
        tag.setGenres([g.strip() for g in genre.replace('/', ',').split(',') if g.strip()])
    xbmc.Player().play(url, li)
    monitor = xbmc.Monitor()
    for _ in range(30):
        if xbmc.Player().isPlaying(): break
        if monitor.abortRequested(): return
        monitor.waitForAbort(0.5)
    while xbmc.Player().isPlaying() and not monitor.abortRequested():
        monitor.waitForAbort(1)

def handle_next_info(next_info):
    info_type, data = next_info
    if info_type == 'actor':
        NAVIGATION_STACK.append({'type': 'actor', 'actor_id': data})
    elif info_type == 'media':
        NAVIGATION_STACK.append({'type': 'media', 'tmdb_id': data['id'], 'media_type': data['type']})
    elif info_type == 'season':
        NAVIGATION_STACK.append({
            'type': 'season',
            'tv_id': data['tv_id'],
            'season_num': data['season_num'],
            'tv_name': data['tv_name']
        })

def handle_next_info_season(next_info, current_season):
    info_type, data = next_info
    
    if info_type == 'actor':
        NAVIGATION_STACK.append({'type': 'actor', 'actor_id': data})
        
    elif info_type == 'episode':
        # VERIFICA LINIA ASTA: Trebuie sa fie 'type': 'episode' !!!
        NAVIGATION_STACK.append({
            'type': 'episode',  # <--- Aici e cheia. Daca scrie 'season' din greseala, redeschide sezonul!
            'tv_id': current_season['tv_id'],
            'season_num': current_season['season_num'],
            'episode_num': data,
            'tv_name': current_season['tv_name']
        })

def handle_next_info_episode(next_info):
    info_type, data = next_info
    if info_type == 'actor':
        NAVIGATION_STACK.append({'type': 'actor', 'actor_id': data})