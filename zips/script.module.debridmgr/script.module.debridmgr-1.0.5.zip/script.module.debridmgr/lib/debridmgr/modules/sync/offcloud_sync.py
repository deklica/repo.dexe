import xbmc, xbmcaddon, xbmcgui
import xbmcvfs
import os

from pathlib import Path
from libs.common import var

char_remov = ["'", ",", ")","("]

#Debrid Manager OffCloud
debridmgr = xbmcaddon.Addon("script.module.debridmgr")
your_username = debridmgr.getSetting("offcloud.user")
your_password = debridmgr.getSetting("offcloud.pass")
your_userid = debridmgr.getSetting("offcloud.userid")
your_token = debridmgr.getSetting("offcloud.token")
          
class Auth:
    def offcloud_auth(self):
    #Fen Light
        try:
                if xbmcvfs.exists(var.chk_fenlt) and xbmcvfs.exists(var.chkset_fenlt): #Check that the addon is installed and settings.db exists
                    
                    #Create database connection
                    from debridmgr.modules.db import offcloud_db
                    conn = offcloud_db.create_conn(var.fenlt_settings_db)
                    
                    #Get add-on settings to compare
                    with conn:
                        cursor = conn.cursor()
                        cursor.execute('''SELECT setting_value FROM settings WHERE setting_id = ?''', ('oc.token',))
                        auth_oc = cursor.fetchone()
                        chk_auth_fenlt = str(auth_oc)
                        cursor.close()
                        
                        #Clean up database results
                        for char in char_remov:
                            chk_auth_fenlt = chk_auth_fenlt.replace(char, "")
                            
                        if not str(var.chk_debridmgr_offc) == chk_auth_fenlt: #Compare Account Mananger data to Add-on data. If they match, authorization is skipped
                            
                            #Write settings to database
                            from debridmgr.modules.db import offcloud_db
                            offcloud_db.auth_fenlt_oc()
                            var.remake_settings()
        except:
                xbmc.log('%s: Fen Light Offcloud Failed!' % var.amgr, xbmc.LOGINFO)
                pass

    #Umbrella
        try:
                if xbmcvfs.exists(var.chk_umb) and xbmcvfs.exists(var.chkset_umb):
                        chk_auth_umb = xbmcaddon.Addon('plugin.video.umbrella').getSetting("offcloudtoken")
                        if not str(var.chk_debridmgr_offc) == str(chk_auth_umb) or str(chk_auth_umb) == '':

                                addon = xbmcaddon.Addon("plugin.video.umbrella")
                                addon.setSetting("offcloud.username", your_username)
                                addon.setSetting("offcloudtoken", your_token)
                                addon.setSetting("offcloud.enable", "true")
        except:
                xbmc.log('%s: Umbrella OffCloud Failed!' % var.amgr, xbmc.LOGINFO)
                pass
            
    #POV
        try:
                if xbmcvfs.exists(var.chk_pov) and xbmcvfs.exists(var.chkset_pov):
                        chk_auth_pov = xbmcaddon.Addon('plugin.video.pov').getSetting("oc.token")
                        if not str(var.chk_debridmgr_offc) == str(chk_auth_pov) or str(chk_auth_pov) == '':

                                addon = xbmcaddon.Addon("plugin.video.pov")
                                addon.setSetting("oc.account_id", your_username)
                                addon.setSetting("oc.token", your_token)
                                addon.setSetting("oc.enabled", "true")
        except:
                xbmc.log('%s: POV OffCloud Failed!' % var.amgr, xbmc.LOGINFO)
                pass

     #The Gears
        try:
                if xbmcvfs.exists(var.chk_gears) and xbmcvfs.exists(var.chkset_gears):
                        chk_auth_gears = xbmcaddon.Addon('plugin.video.gears').getSetting("realdebrid.token")
                        if not str(var.chk_debridmgr_offc) == str(chk_auth_gears) or str(chk_auth_gears) == '':

                                addon = xbmcaddon.Addon("plugin.video.gears")
                                addon.setSetting("offcloud.username", your_username)
                                addon.setSetting("offcloud.token", your_token)
                                addon.setSetting("offcloud.enabled", "true")
        except:
                xbmc.log('%s: The Gears OffCloud Failed!' % var.amgr, xbmc.LOGINFO)
                pass

     #Chains Genocide
        try:
                if xbmcvfs.exists(var.chk_genocide and xbmcvfs.exists(var.chkset_genocide):
                        chk_auth_gears = xbmcaddon.Addon('plugin.video.genocide').getSetting("realdebrid.token")
                        if not str(var.chk_debridmgr_offc) == str(chk_auth_genocide) or str(chk_auth_genocide) == '':

                                addon = xbmcaddon.Addon("plugin.video.genocide")
                                addon.setSetting("offcloud.username", your_username)
                                addon.setSetting("offcloud.token", your_token)
                                addon.setSetting("offcloud.enabled", "true")
        except:
                xbmc.log('%s: Genocide OffCloud Failed!' % var.amgr, xbmc.LOGINFO)
                pass
            
     #Dradis
        try:
                if xbmcvfs.exists(var.chk_dradis) and xbmcvfs.exists(var.chkset_dradis):
                        chk_auth_dradis = xbmcaddon.Addon('plugin.video.dradis').getSetting("realdebrid.token")
                        if not str(var.chk_debridmgr_offc) == str(chk_auth_dradis) or str(chk_auth_dradis) == '':

                                addon = xbmcaddon.Addon("plugin.video.dradis")
                                addon.setSetting("offcloud.username", your_username)
                                addon.setSetting("offcloud.token", your_token)
                                addon.setSetting("offcloud.enabled", "true")
        except:
                xbmc.log('%s: Dradis OffCloud Failed!' % var.amgr, xbmc.LOGINFO)
                pass
