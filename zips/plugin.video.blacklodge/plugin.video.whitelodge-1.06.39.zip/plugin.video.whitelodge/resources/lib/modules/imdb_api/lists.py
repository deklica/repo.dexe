# -*- coding: utf-8 -*-

from .imdb_client import imdb_request


def advanced_search(first, after, params):
    import datetime
    now = datetime.datetime.now()

    startDate = params.get('startDate', '')
    if startDate.isdigit() and len(startDate) == 4: startDate = '%s-01-01' % startDate
    elif startDate.isdigit() and len(startDate) < 4: startDate = (now - datetime.timedelta(days=int(startDate))).strftime('%Y-%m-%d')
    else: startDate = '1888-01-01'

    endDate = params.get('endDate', '')
    if endDate.isdigit() and len(endDate) == 4: endDate = '%s-12-31' % endDate
    elif endDate.isdigit() and len(endDate) < 4: endDate = (now - datetime.timedelta(days=int(endDate))).strftime('%Y-%m-%d')
    else: endDate = now.strftime('%Y-%m-%d')

    votes = params.get('votes', '')
    if votes:
        votes = """\n              userRatingsConstraint: { ratingsCountRange: { min: %d } }""" % int(votes)

    keyword = params.get('kw', '')
    if keyword:
        keyword = ['"'+k+'"' for k in keyword.split(',')]
        keyword = """\n              keywordConstraint: { anyKeywords: [%s] }""" % ', '.join(keyword)

    genre = params.get('genre', '')
    if genre: genre = ['"'+g+'"' for g in genre.split(',')]
    excGenre = params.get('excGenre', '')
    if excGenre: excGenre = ['"'+g+'"' for g in excGenre.split(',')]
    if genre or excGenre:
        genre = """\n              genreConstraint: { allGenreIds: [%s], excludeGenreIds: [%s] }""" % (', '.join(genre), ', '.join(excGenre))

    interest = params.get('interest', '')
    if interest:
        interest = """\n              interestConstraint: { allInterestIds: ["%s"] }""" % interest

    cert = params.get('cert', '')
    if cert: cert = ', '.join(["""{ rating: "%s", region: "US" }""" % c for c in cert.split(',')])
    excCert = params.get('excCert', '')
    if excCert: excCert = ', '.join(["""{ rating: "%s", region: "US" }""" % c for c in excCert.split(',')])
    if cert or excCert:
        cert = """\n              certificateConstraint: { anyRegionCertificateRatings: [%s], excludeRegionCertificateRatings: [%s] }""" % (cert, excCert)

    lang = params.get('lang', '')
    if lang:
        lang = ['"'+l+'"' for l in lang.split(',')]
        lang = """\n              languageConstraint: { anyPrimaryLanguages: [%s] }""" % ', '.join(lang)

    awards = params.get('awards', '')
    if awards:
        awards = awards.split(',')
        event = awards[0]
        category = """, searchAwardCategoryId: "%s" """ % awards[1] if awards[1] else ''
        winner = """, winnerFilter: %s """ % awards[2] if awards[2] else ''
        awards = """\n              awardConstraint: { allEventNominations: [{ eventId: "%s"%s%s}] }""" % (event, category, winner)

    groups = params.get('groups', '')
    if groups:
        groups = """\n              rankedTitleListConstraint: { allRankedTitleLists: [{ rankRange: { max: %s }, rankedTitleListType: TOP_RATED_MOVIES }] }""" % int(groups)

    searchTerm = params.get('search', '')
    if searchTerm:
        searchTerm = """\n              titleTextConstraint: { searchTerm: "%s" }""" % searchTerm

    withName = params.get('nameId', '')
    if withName:
        withName = """\n              titleCreditsConstraint: { allCredits: [{ nameId: "%s" }] }""" % withName

    query = """
        query AdvancedSearch($first: Int!, $after: String, $titleType: [String!], $startDate: Date, $endDate: Date, $sort: AdvancedTitleSearchSort) {
          advancedTitleSearch(
            first: $first
            after: $after
            constraints: {
              titleTypeConstraint: { anyTitleTypeIds: $titleType }
              releaseDateConstraint: { releaseDateRange: { start: $startDate, end: $endDate } }%s%s%s%s%s%s%s%s%s%s
            }
            sort: $sort
          ) {
            edges {
              node {
                title {
                  id
                  titleText {
                    text
                  }
                  releaseYear {
                    year
                  }
                  releaseDate {
                    year
                    month
                    day
                  }
                  ratingsSummary {
                    aggregateRating
                    voteCount
                  }
                  plot {
                    plotText {
                      plainText
                    }
                  }
                  primaryImage {
                    url
                  }
                  certificate {
                    rating
                  }
                  runtime {
                    seconds
                  }
                }
              }
            }
            pageInfo {
              hasNextPage
              endCursor
            }
          }
        }
    """ % (votes, keyword, genre, interest, cert, lang, awards, groups, searchTerm, withName)

    variables = {
        'first': first,
        'after': after,
        'startDate': startDate,
        'endDate': endDate,
        'titleType': params['titleType'].split(','),
        'sort': {'sortBy': params['sort'].split(',')[0], 'sortOrder': params['sort'].split(',')[1]}
    }

    request = {'query': query, 'variables': variables}
    response = imdb_request(request)
    return response['data']['advancedTitleSearch']


def more_like_this(first, after, params):
    query = """
        query similar(
          $imdb: ID!
          $first: Int!
          %s
        ) {
          title(id: $imdb) {
            moreLikeThisTitles(
              first: $first
              %s
            ) {
              edges {
                node {
                  id
                  titleText {
                    text
                  }
                  releaseYear {
                    year
                  }
                  releaseDate {
                    year
                    month
                    day
                  }
                  ratingsSummary {
                    aggregateRating
                    voteCount
                  }
                  plot {
                    plotText {
                      plainText
                    }
                  }
                  primaryImage {
                    url
                  }
                  certificate {
                    rating
                  }
                  runtime {
                    seconds
                  }
                }
              }
              pageInfo {
                hasNextPage
                endCursor
              }
            }
          }
        }
    """ % ('$after: ID' if after else '', 'after: $after' if after else '')

    request = {'query': query, 'variables': {'imdb': params['imdb'], 'first': first, 'after': after}}
    response = imdb_request(request)
    return response['data']['title']['moreLikeThisTitles']


def get_customlist(first, after, params, check=False):
    query = """
        query GetListDetails($listId: ID!, $first: Int!, $after: String, $titleType: [String!], $sort: TitleListSearchSort) {
          list(id: $listId) {
            name {
              originalText
            }
            author {
              username {
                text
              }
            }
            titleListItemSearch(
              first: $first
              after: $after
              filter: { titleTypeConstraint: { anyTitleTypeIds: $titleType } }
              sort: $sort
            ) {
              edges {
                title {
                  id
                  titleText {
                    text
                  }
                  releaseYear {
                    year
                  }
                  releaseDate {
                    year
                    month
                    day
                  }
                  ratingsSummary {
                    aggregateRating
                    voteCount
                  }
                  plot {
                    plotText {
                      plainText
                    }
                  }
                  primaryImage {
                    url
                  }
                  certificate {
                    rating
                  }
                  runtime {
                    seconds
                  }
                }
              }
              pageInfo {
                hasNextPage
                endCursor
              }
            }
          }
        }
    """

    variables = {
        'first': first,
        'after': after,
        'listId': params['list'],
        'titleType': params['titleType'].split(','),
        'sort': {'by': params['sort'].split(',')[0], 'order': params['sort'].split(',')[1]}
    }

    request = {'query': query, 'variables': variables}
    response = imdb_request(request)
    if check:
        return response['data']['list']
    return response['data']['list']['titleListItemSearch']

