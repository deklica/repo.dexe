# -*- coding: utf-8 -*-

from resources.lib.modules import trakt
from resources.lib.modules import bookmarks
from resources.lib.modules import cleangenre
from resources.lib.modules import cleantitle
from resources.lib.modules import control
from resources.lib.modules import client
from resources.lib.modules import cache
from resources.lib.modules import metacache
from resources.lib.modules import playcount
from resources.lib.modules import mylists
from resources.lib.modules import workers
from resources.lib.modules import views
from resources.lib.modules import utils
from resources.lib.modules import imdb_api
from resources.lib.modules import api_keys
from resources.lib.modules import log_utils
from resources.lib.indexers import navigator

import os,sys,re,datetime
import simplejson as json

import six
from six.moves import urllib_parse, zip, range

try: from sqlite3 import dbapi2 as database
except: from pysqlite2 import dbapi2 as database

import requests


params = dict(urllib_parse.parse_qsl(sys.argv[2].replace('?',''))) if len(sys.argv) > 1 else dict()
action = params.get('action')


class movies:
    def __init__(self):
        self.list = []
        self.code = ''

        self.session = requests.Session()

        self.imdb_link = 'https://www.imdb.com'
        self.imdb_graphql_link = 'https://www.api.imdb.com'
        self.trakt_link = 'https://api.trakt.tv'
        self.tmdb_link = 'https://api.themoviedb.org/3'
        self.local_link = 'https://www.local.bm'
        self.datetime = datetime.datetime.utcnow()# - datetime.timedelta(hours = 5)
        self.systime = self.datetime.strftime('%Y%m%d%H%M%S%f')
        self.year_date = (self.datetime - datetime.timedelta(days = 365)).strftime('%Y-%m-%d')
        self.year_plus_date = (self.datetime + datetime.timedelta(days = 365)).strftime('%Y-%m-%d')
        self.months_date = (self.datetime - datetime.timedelta(days = 90)).strftime('%Y-%m-%d')
        self.today_date = self.datetime.strftime('%Y-%m-%d')
        self.trakt_user = control.setting('trakt.user').strip()
        self.imdb_user = control.setting('imdb.user').replace('ur', '')
        self.tmdb_user = control.setting('tm.user') or api_keys.tmdb_key
        self.fanart_tv_user = control.setting('fanart.tv.user')
        self.fanart_tv_headers = {'api-key': api_keys.fanarttv_key}
        if not self.fanart_tv_user == '':
            self.fanart_tv_headers.update({'client-key': self.fanart_tv_user})
        self.user = str(control.setting('fanart.tv.user')) + str(control.setting('tm.user'))
        self.lang = control.apiLanguage()['tmdb']
        self.items_per_page = str(control.setting('items.per.page')) or '20'
        self.hq_artwork = control.setting('hq.artwork') or 'false'
        self.trailer_source = control.setting('trailer.source') or '2'
        self.lists_provider = control.setting('lists.provider')
        self.country = control.setting('official.country') or 'US'

        self.fanart_tv_art_link = 'http://webservice.fanart.tv/v3/movies/%s'
        self.fanart_tv_level_link = 'http://webservice.fanart.tv/v3/level'

        ## TMDb ##
        self.tmdb_api_link = 'https://api.themoviedb.org/3/movie/%s?api_key=%s&language=%s&append_to_response=credits,release_dates,external_ids' % ('%s', self.tmdb_user, self.lang)
        self.tmdb_by_imdb = 'https://api.themoviedb.org/3/find/%s?api_key=%s&external_source=imdb_id' % ('%s', self.tmdb_user)
        self.tmdb_search_link = 'https://api.themoviedb.org/3/search/movie?api_key=%s&language=en-US&query=%s&page=1' % (self.tmdb_user, '%s')
        self.tmdb_img_link = 'https://image.tmdb.org/t/p/w%s%s'
        self.tmdb_related_link = 'https://api.themoviedb.org/3/movie/%s/similar?api_key=%s&page=1' % ('%s', self.tmdb_user)

        self.tmdb_pop_link = 'https://api.themoviedb.org/3/movie/popular?api_key=%s&page=1' % self.tmdb_user
        self.tmdb_voted_link = 'https://api.themoviedb.org/3/discover/movie?sort_by=vote_count.desc&api_key=%s&page=1' % self.tmdb_user
        self.tmdb_rating_link = 'https://api.themoviedb.org/3/movie/top_rated?api_key=%s&page=1' % self.tmdb_user
        self.tmdb_theaters_link = 'https://api.themoviedb.org/3/movie/now_playing?api_key=%s&page=1' % self.tmdb_user
        self.tmdb_featured_link = 'https://api.themoviedb.org/3/trending/movie/week?api_key=%s&page=1' % self.tmdb_user
        self.tmdb_upcoming_link = 'https://api.themoviedb.org/3/discover/movie?with_original_language=en&release_date.gte=%s&release_date.lte=%s&with_release_type=3|2&api_key=%s&page=1' % (self.today_date, self.year_plus_date, self.tmdb_user)
        self.tmdb_boxoffice_link = 'https://api.themoviedb.org/3/discover/movie?sort_by=revenue.desc&api_key=%s&page=1' % self.tmdb_user
        self.tmdb_added_link = 'https://api.themoviedb.org/3/discover/movie?primary_release_date.gte=%s&primary_release_date.lte=%s&with_release_type=4|5|6&api_key=%s&page=1' % (self.months_date, self.today_date, self.tmdb_user)

        self.tmdb_genre_link = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&with_genres=%s&language=en-US&with_watch_providers=%s&watch_region=%s&page=1' % (self.tmdb_user, '%s', '%s', '%s')
        self.tmdb_year_link = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&primary_release_year=%s&language=en-US&with_watch_providers=%s&watch_region=%s&page=1' % (self.tmdb_user, '%s', '%s', '%s')
        self.tmdb_decade_link = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&primary_release_date.gte=%s&primary_release_date.lte=%s&language=en-US&with_watch_providers=%s&watch_region=%s&page=1' % (self.tmdb_user, '%s', '%s', '%s', '%s')
        self.tmdb_language_link = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&with_original_language=%s&language=en-US&with_watch_providers=%s&watch_region=%s&page=1' % (self.tmdb_user, '%s', '%s', '%s')
        self.tmdb_certification_link = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&certification_country=US&certification=%s&language=en-US&with_watch_providers=%s&watch_region=%s&page=1' % (self.tmdb_user, '%s', '%s', '%s')

        self.tmdb_providers_avail_link = 'https://api.themoviedb.org/3/movie/%s/watch/providers?api_key=%s' % ('%s', self.tmdb_user)
        self.tmdb_providers_pop_link = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&with_watch_providers=%s&watch_region=%s&page=1' % (self.tmdb_user, '%s', self.country)
        self.tmdb_providers_voted_link = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&sort_by=vote_count.desc&with_watch_providers=%s&watch_region=%s&page=1' % (self.tmdb_user, '%s', self.country)
        self.tmdb_providers_rated_link = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&sort_by=vote_average.desc&vote_count.gte=500&with_watch_providers=%s&watch_region=%s&page=1' % (self.tmdb_user, '%s', self.country)
        self.tmdb_providers_added_link = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&primary_release_date.gte=%s&primary_release_date.lte=%s&sort_by=primary_release_date.desc&with_watch_providers=%s&watch_region=%s&page=1' % (self.tmdb_user, self.year_date, self.today_date, '%s', self.country)

        ## IMDb ##

        ##### Pseudo-links for imdb graphql api usage #####
        self.imdb_top_link = 'https://www.api.imdb.com/?query=advanced_search&params=titleType:movie,tvMovie|groups:1000|sort:RANKING,ASC&page=1&after='
        self.imdb_featured_link = 'https://www.api.imdb.com/?query=advanced_search&params=titleType:movie,tvMovie|excGenre:Documentary|lang:en|startDate:999|sort:POPULARITY,ASC&page=1&after='
        self.imdb_rating_link = 'https://www.api.imdb.com/?query=advanced_search&params=titleType:movie,tvMovie|excGenre:Documentary|votes:100000|sort:USER_RATING,DESC&page=1&after='
        self.imdb_voted_link = 'https://www.api.imdb.com/?query=advanced_search&params=titleType:movie,tvMovie|sort:USER_RATING_COUNT,DESC&page=1&after='
        self.imdb_added_link = 'https://www.api.imdb.com/?query=advanced_search&params=titleType:movie,tvMovie|excGenre:Documentary|votes:100|startDate:365|sort:RELEASE_DATE,DESC&page=1&after='
        self.imdb_boxoffice_link = 'https://www.api.imdb.com/?query=advanced_search&params=titleType:movie,tvMovie|sort:BOX_OFFICE_GROSS_DOMESTIC,DESC&page=1&after='
        self.imdb_search_link = 'https://www.api.imdb.com/?query=advanced_search&params=titleType:movie,tvMovie,short,video|search:%s|sort:POPULARITY,ASC&page=1&after='

        self.imdb_genre_link = 'https://www.api.imdb.com/?query=advanced_search&params=titleType:movie,tvMovie|genre:%s|excGenre:%s|sort:POPULARITY,ASC&page=1&after='
        self.imdb_year_link = 'https://www.api.imdb.com/?query=advanced_search&params=titleType:movie,tvMovie|startDate:%s|endDate:%s|sort:POPULARITY,ASC&page=1&after='
        self.imdb_language_link = 'https://www.api.imdb.com/?query=advanced_search&params=titleType:movie,tvMovie,short|lang:%s|sort:POPULARITY,ASC&page=1&after='
        self.imdb_certification_link = 'https://www.api.imdb.com/?query=advanced_search&params=titleType:movie,tvMovie,short|cert:%s|excCert:%s|sort:POPULARITY,ASC&page=1&after='
        self.imdb_awards_link = 'https://www.api.imdb.com/?query=advanced_search&params=titleType:movie,tvMovie,short,video|awards:%s|sort:RELEASE_DATE,DESC&page=1&after='
        self.imdb_keyword_link = 'https://www.api.imdb.com/?query=advanced_search&params=titleType:movie,tvMovie,short|kw:%s|sort:POPULARITY,ASC&page=1&after='
        self.imdb_interests_link = 'https://www.api.imdb.com/?query=advanced_search&params=titleType:movie,tvMovie,short,video|interest:%s|sort:POPULARITY,ASC&page=1&after='

        self.imdb_customlist_link = 'https://www.api.imdb.com/?query=get_customlist&params=list:%s|titleType:movie,tvMovie,short,video|sort:%s&page=1&after='
        self.imdb_related_link = 'https://www.api.imdb.com/?query=more_like_this&params=imdb:%s&page=1&after='

        self.imdb_userlists_link = 'https://www.api.imdb.com/?query=get_userlists&params=id:ur%s' % self.imdb_user
        self.imdb_watchlist_link = 'https://www.api.imdb.com/?query=get_watchlist_id&params=id:ur%s' % self.imdb_user
        #####


        ## Trakt ##
        self.trending_link = 'https://api.trakt.tv/movies/trending?limit=%s&page=1' % self.items_per_page
        self.mosts_link = 'https://api.trakt.tv/movies/%s/%s?limit=%s&page=1' % ('%s', '%s', self.items_per_page)
        self.traktlists_link = 'https://api.trakt.tv/users/me/lists'
        self.traktlikedlists_link = 'https://api.trakt.tv/users/likes/lists'
        self.traktlist_link = 'https://api.trakt.tv/users/%s/lists/%s/items?limit=%s&page=1' % ('%s', '%s', self.items_per_page)
        self.traktcollection_link = 'https://api.trakt.tv/users/me/collection/movies?limit=%s&page=1' % self.items_per_page
        self.traktwatchlist_link = 'https://api.trakt.tv/users/me/watchlist/movies?limit=%s&page=1' % self.items_per_page
        self.traktrecommendations_link = 'https://api.trakt.tv/recommendations/movies?ignore_collected=true&ignore_watchlisted=true&limit=40'
        self.trakthistory_link = 'https://api.trakt.tv/users/me/history/movies?limit=%s&page=1' % self.items_per_page
        self.trakfavorites_link = 'https://api.trakt.tv/users/me/favorites/movies?limit=%s&page=1' % self.items_per_page
        self.traktondeck_link = 'https://api.trakt.tv/sync/playback/movies?limit=%s&page=1' % self.items_per_page
        # self.search_link = 'https://api.trakt.tv/search/movie?limit=20&page=1&query='
        # self.related_link = 'https://api.trakt.tv/movies/%s/related'

        ## Local lists pseudo-links ##
        self.local_history_link = 'https://www.local.bm?query=history&page=1&after='
        self.local_ondeck_link = 'https://www.local.bm?query=ondeck&page=1&after='
        self.local_list_link = 'https://www.local.bm?query=locallist&page=1&after='


    def __del__(self):
        self.session.close()


    def get(self, url, idx=True, create_directory=True, code=''):
        try:
            try: url = getattr(self, url + '_link')
            except: pass

            try: u = urllib_parse.urlparse(url).netloc.lower()
            except: pass

            self.code = code

            if u in self.trakt_link and '/users/' in url:
                try:
                    if not '/users/me/' in url: raise Exception()
                    if url == self.trakthistory_link:
                        activity = trakt.getWatchedActivity()
                    else:
                        activity = trakt.getActivity()
                    if activity > cache.timeout(self.trakt_list, url): raise Exception()
                    self.list = cache.get(self.trakt_list, 720, url)
                except:
                    self.list = cache.get(self.trakt_list, 0, url)

                if idx == True: self.worker()

            elif u in self.trakt_link and '/sync/playback/' in url:
                self.list = self.trakt_list(url)
                self.list = sorted(self.list, key=lambda k: int(k['paused_at']), reverse=True)
                if idx == True: self.worker()

            elif u in self.trakt_link:
                self.list = cache.get(self.trakt_list, 24, url)
                if idx == True: self.worker()

            elif u in self.imdb_link:
                self.list = cache.get(self.imdb_list, 24, url)
                if idx == True: self.worker()

            elif u in self.imdb_graphql_link:
                if 'customlist' in url:
                    self.list = cache.get(self.imdb_graphql, 2, url)
                else:
                    self.list = cache.get(self.imdb_graphql, 24, url)
                if idx == True: self.worker()

            elif u in self.tmdb_link:
                self.list = cache.get(self.tmdb_list, 24, url, self.code)
                if idx == True: self.worker()

            elif u in self.local_link:
                self.list = self.local_list(url)
                if idx == True: self.worker()


            #log_utils.log('movies_get_list: ' + str(self.list))
            if idx == True and create_directory == True: self.movieDirectory(self.list)
            return self.list
        except:
            log_utils.log('movies_get', 1)
            pass


    def imdb_sort(self):
        sort = control.setting('imdb.sort.order')
        if sort == '0': return 'DATE_ADDED,DESC'
        elif sort == '1': return 'TITLE_REGIONAL,ASC'
        elif sort == '2': return 'POPULARITY,ASC'
        elif sort == '3': return 'LIST_ORDER,ASC'
        else: return 'DATE_ADDED,DESC'


    def search(self, code=''):
        code = urllib_parse.quote(code) if code else ''

        navigator.navigator().addDirectoryItem(32603, 'movieSearchterm&code=%s' % code, 'search.png', 'DefaultMovies.png')

        dbcon = database.connect(control.searchFile)
        dbcur = dbcon.cursor()

        try:
            dbcur.executescript("CREATE TABLE IF NOT EXISTS movies (ID Integer PRIMARY KEY AUTOINCREMENT, term);")
        except:
            pass

        dbcur.execute("SELECT * FROM movies ORDER BY ID DESC")
        lst = []

        delete_option = False
        for (id, term) in dbcur.fetchall():
            if term not in str(lst):
                delete_option = True
                navigator.navigator().addDirectoryItem(term.title(), 'movieSearchterm&name=%s&code=%s' % (term, code), 'search.png', 'DefaultMovies.png', context=(32644, 'movieDeleteterm&name=%s' % term))
                lst += [(term)]
        dbcur.close()

        if delete_option:
            navigator.navigator().addDirectoryItem(32605, 'clearCacheSearch&select=movies', 'tools.png', 'DefaultAddonProgram.png', isFolder=False)

        navigator.navigator().endDirectory(False)


    def search_term(self, q='', code=''):
        control.idle()
        if not q:
            q = control.inputDialog(control.lang(32010))
        if not q:
            return
        q = q.lower()

        dbcon = database.connect(control.searchFile)
        dbcur = dbcon.cursor()
        dbcur.execute("DELETE FROM movies WHERE term = ?", (q,))
        dbcur.execute("INSERT INTO movies VALUES (?,?)", (None, q))
        dbcon.commit()
        dbcur.close()
        url = self.imdb_search_link % q if (self.lists_provider == '0' and not code) else self.tmdb_search_link % urllib_parse.quote(q)
        self.get(url, code=code)


    def delete_term(self, q):
        control.idle()

        dbcon = database.connect(control.searchFile)
        dbcur = dbcon.cursor()
        dbcur.execute("DELETE FROM movies WHERE term = ?", (q,))
        dbcon.commit()
        dbcur.close()
        control.refresh()


    def mosts(self):
        keywords = [
            ('Most Played This Week', 'played', 'weekly'),
            ('Most Played This Month', 'played', 'monthly'),
            ('Most Played This Year', 'played', 'yearly'),
            ('Most Played All Time', 'played', 'all'),
            ('Most Collected This Week', 'collected', 'weekly'),
            ('Most Collected This Month', 'collected', 'monthly'),
            ('Most Collected This Year', 'collected', 'yearly'),
            ('Most Collected All Time', 'collected', 'all'),
            ('Most Watched This Week', 'watched', 'weekly'),
            ('Most Watched This Month', 'watched', 'monthly'),
            ('Most Watched This Year', 'watched', 'yearly'),
            ('Most Watched All Time', 'watched', 'all')
        ]

        for i in keywords:
            self.list.append(
                {
                    'name': i[0],
                    'url': self.mosts_link % (i[1], i[2]),
                    'image': 'trakt.png',
                    'action': 'movies'
                }
            )
        self.addDirectory(self.list)
        return self.list


    def keywords(self):
        navigator.navigator().addDirectoryItem('[I]Keyword Search...[/I]', 'movieKwSearch', 'genres/mystery.png', 'DefaultAddonsSearch.png')

        url = 'https://www.imdb.com/search/keyword/?s=kw'
        r = cache.get(client.request, 168, url)
        rows = client.parseDOM(r, 'a', attrs={'class': 'ipc-chip ipc-chip--on-base-accent2'})
        if rows:
            keywords = [client.parseDOM(row, 'span')[0].replace('&#x27;', "'") for row in rows]
        else:
            keywords = [
                'action hero', 'alternate history', 'ambiguous ending', 'american abroad', 'anime', 'anti hero', 'avant garde', 'b movie', 'bank heist', 'based on book',
                'based on play', 'based on comic', 'based on comic book', 'based on novel', 'based on novella', 'based on short story', 'battle', 'betrayal', 'biker',
                'black comedy', 'blockbuster', 'bollywood', 'breaking the fourth wall', 'business', 'caper', 'car accident', 'car chase', 'car crash', 'character name in title',
                "character's point of view camera shot", 'chick flick', 'coming of age', 'competition', 'conspiracy', 'corruption', 'criminal mastermind', 'cult', 'cult film',
                'cyberpunk', 'dark hero', 'deus ex machina', 'dialogue driven', 'dialogue driven storyline', 'directed by star', 'director cameo', 'double cross', 'dream sequence',
                'dystopia', 'ensemble cast', 'epic', 'espionage', 'experimental short', 'experimental film', 'fairy tale', 'famous line', 'famous opening theme', 'famous score',
                'fantasy sequence', 'farce', 'father daughter relationship', 'father son relationship', 'femme fatale', 'fictional biography', 'flashback', 'french new wave',
                'futuristic', 'good versus evil', 'heist', 'hero', 'high school', 'husband wife relationship', 'idealism', 'independent film', 'investigation', 'kidnapping',
                'knight', 'kung fu', 'macguffin', 'medieval times', 'mockumentary', 'monster', 'mother daughter relationship', 'mother son relationship',
                'actor playing multiple roles', 'multiple endings', 'multiple perspectives', 'multiple storylines', 'multiple time frames', 'murder', 'musical number',
                'neo noir', 'neorealism', 'ninja', 'no background score', 'no music', 'no opening credits', 'no title at beginning', 'nonlinear timeline', 'on the run',
                'one against many', 'one man army', 'opening action scene', 'organized crime', 'parenthood', 'parody', 'plot twist', 'police corruption', 'police detective',
                'post apocalypse', 'post modern', 'psychopath', 'race against time', 'redemption', 'remake', 'rescue', 'road movie', 'robbery', 'robot', 'rotoscoping', 'satire',
                'self sacrifice', 'serial killer', 'reference to william shakespeare', 'shootout', 'show within a show', 'slasher', 'southern gothic', 'spaghetti western',
                'spirituality', 'spoof', 'steampunk', 'subjective camera', 'superhero', 'supernatural power', 'surprise ending', 'swashbuckler', 'sword and sandal', 'tech noir',
                'time travel', 'title spoken by character', 'told in flashback', 'vampire', 'virtual reality', 'voice over narration', 'whistleblower', 'wilhelm scream', 'wuxia',
                'zombie'
            ]

        keywords += [
            'artificial intelligence', 'based on true story', 'christmas', 'dc comics', 'easter', 'existential', 'halloween', 'hearing characters thoughts', 'loner',
            'marvel comics', 'new year', 'official james bond series', 'private eye', 'racism', 'schizophrenia', 'star wars', 'thanksgiving'
        ]

        keywords = sorted(set(keywords))

        for kw in keywords:
            self.list.append(
                {
                    'name': kw.title(),
                    'url': self.imdb_keyword_link % kw.replace(' ', '-'),
                    'image': 'imdb.png',
                    'action': 'movies'
                }
            )
        self.addDirectory(self.list)
        return self.list


    def keyword_search(self):
        kw = control.inputDialog(control.lang(32160))
        if not kw: return
        kw = ','.join([k.strip().lower().replace(' ', '-') for k in kw.split(',')])
        url = self.imdb_keyword_link % kw
        self.get(url)


    def custom_lists(self):
        lists = [
            ('ls4159657244', 'IMDb Editors: Dangerous Love'),
            ('ls534685277', 'IMDb Editors: Essential Horror Films from Black Directors'),
            ('ls592567077', 'IMDb Editors: Family Movie Picks'),
            ('ls521170945', 'IMDb Editors: Theatrical Releases Recently Available to Stream'),
            ('ls4159670771', 'IMDb Editors: Tragic Hearts'),
            ('ls4159652924', 'IMDb Editors: Video Game Movie Adaptations'),
            ('ls066788382', 'Addiction'),
            ('ls057104247', 'Alchoholic'),
            ('ls063259747', 'Alien Invasion'),
            ('ls062392787', 'Artificial Intelligence'),
            ('ls008462416', 'Artists'),
            ('ls057631565', 'Based on a True Story'),
            ('ls066370089', 'Best Twist Ending Movies'),
            ('ls057785252', 'Biographical'),
            ('ls062218265', 'Conspiracy'),
            ('ls063204479', 'Contract Killers'),
            ('ls066198904', 'Courtroom'),
            ('ls004943234', 'Cult Horror Movies'),
            ('ls062746803', 'Disaster & Apocalyptic'),
            ('ls068335911', 'Father - Son'),
            ('ls066176690', 'Gangster'),
            ('ls020387857', 'Heist Caper Movies'),
            ('ls066780524', 'Heists, Cons, Scams & Robbers'),
            ('ls062247190', 'Heroic Bloodshed'),
            ('ls027849454', 'Horror Of The Skull Posters'),
            ('ls069754038', 'Inspirational Movies'),
            ('ls057723258', 'Love'),
            ('ls064685738', 'Man Vs. Nature'),
            ('ls066746282', 'Mental, Physical Illness and Disability Movies'),
            ('ls004043006', 'Modern Horror: Top 150'),
            ('ls066222382', 'Motivational'),
            ('ls077141747', 'Movie Clones'),
            ('ls075785141', 'Movies Based In One Room'),
            ('ls058963815', 'Movies For Intelligent People'),
            ('ls066191116', 'Music or Musical Movies'),
            ('ls062760686', 'Obscure Underrated Movies'),
            ('ls069248253', 'Old Age'),
            ('ls066502835', 'Prison & Escape'),
            ('ls021557769', 'Puff Puff Pass'),
            ('ls066797820', 'Revenge'),
            ('ls066135354', 'Road Trip & Travel'),
            ('ls063841856', 'Serial Killers'),
            ('ls051708902', 'Shocking Movie Scenes'),
            ('ls027822154', 'Sleeper Hit Movies'),
            ('ls020576693', 'Smut and Trash'),
            ('ls066367722', 'Spy - CIA - MI5 - MI6 - KGB'),
            ('ls051289348', 'Stephen King Movies and Adaptations'),
            ('ls070949682', 'Tech Geeks'),
            ('ls066113037', 'Teenage'),
            ('ls066184124', 'Time Travel'),
            ('ls075582795', 'Top Kung Fu'),
            ('ls003062015', 'Top Private Eye Movies'),
            ('ls076464829', 'Top Satirical Movies'),
            ('ls070389024', 'Video Games'),
            ('ls057106830', 'Winter Is Here')
        ]

        for i in lists:
            self.list.append(
                {
                    'name': i[1],
                    'url': self.imdb_customlist_link % (i[0], 'LIST_ORDER,ASC'),
                    'image': 'imdb.png',
                    'action': 'movies'
                }
            )
        self.addDirectory(self.list)
        return self.list


    def genres(self):
        genres = [
            ('Action', 'action', True),
            ('Adventure', 'adventure', True),
            ('Animation', 'animation', True),
            ('Anime', 'anime', False),
            ('Biography', 'biography', True),
            ('Comedy', 'comedy', True),
            ('Crime', 'crime', True),
            ('Documentary', 'documentary', True),
            ('Drama', 'drama', True),
            ('Family', 'family', True),
            ('Fantasy', 'fantasy', True),
            ('Film Noir', 'film_noir', True),
            ('History', 'history', True),
            ('Horror', 'horror', True),
            ('Music ', 'music', True),
            ('Musical', 'musical', True),
            ('Mystery', 'mystery', True),
            ('Romance', 'romance', True),
            ('Science Fiction', 'sci_fi', True),
            ('Sport', 'sport', True),
            ('Thriller', 'thriller', True),
            ('War', 'war', True),
            ('Western', 'western', True)
        ]

        for i in genres:
            self.list.append(
                {
                    'name': cleangenre.lang(i[0], self.lang),
                    'url': self.imdb_genre_link % (i[1].replace('_', '-').title(), 'Documentary' if not i[1] == 'documentary' else '') if i[2] else self.imdb_keyword_link % i[1],
                    'image': 'genres/{}.png'.format(i[1]),
                    'action': 'movies'
                }
            )
        self.addDirectory(self.list)
        return self.list


    def interests(self):
        interests = [
            ('action', 'Action Epic', 'in0000002'),
            ('action', 'B-Action', 'in0000003'),
            ('action', 'Car Action', 'in0000004'),
            ('action', 'Disaster', 'in0000005'),
            ('action', 'Gun Fu', 'in0000197'),
            ('action', 'Kung Fu', 'in0000198'),
            ('action', 'Martial Arts', 'in0000006'),
            ('action', 'One-Person-Army', 'in0000007'),
            ('action', 'Samurai', 'in0000199'),
            ('action', 'Superhero', 'in0000008'),
            ('action', 'Sword & Sandal', 'in0000009'),
            ('action', 'Wuxia', 'in0000200'),
            ('adventure', 'Adventure Epic', 'in0000015'),
            ('adventure', 'Desert Adventure', 'in0000013'),
            ('adventure', 'Dinosaur Adventure', 'in0000014'),
            ('adventure', 'Globetrotting Adventure', 'in0000016'),
            ('adventure', 'Jungle Adventure', 'in0000017'),
            ('adventure', 'Mountain Adventure', 'in0000018'),
            ('adventure', 'Quest', 'in0000019'),
            ('adventure', 'Road Trip', 'in0000020'),
            ('adventure', 'Sea Adventure', 'in0000021'),
            ('adventure', 'Swashbuckler', 'in0000022'),
            ('adventure', 'Teen Adventure', 'in0000023'),
            ('adventure', 'Urban Adventure', 'in0000024'),
            ('animation', 'Adult Animation', 'in0000025'),
            ('animation', 'Computer Animation', 'in0000028'),
            ('animation', 'Hand-Drawn Animation', 'in0000029'),
            ('animation', 'Holiday Animation', 'in0000193'),
            ('animation', 'Stop Motion Animation', 'in0000030'),
            ('anime', 'Isekai', 'in0000201'),
            ('anime', 'Iyashikei', 'in0000202'),
            ('anime', 'Josei', 'in0000203'),
            ('anime', 'Mecha', 'in0000204'),
            ('anime', 'Seinen', 'in0000205'),
            ('anime', 'Shōjo', 'in0000206'),
            ('anime', 'Shōnen', 'in0000207'),
            ('anime', 'Slice of Life', 'in0000208'),
            ('comedy', 'Body Swap Comedy', 'in0000031'),
            ('comedy', 'Buddy Comedy', 'in0000032'),
            ('comedy', 'Buddy Cop', 'in0000033'),
            ('comedy', 'Dark Comedy', 'in0000035'),
            ('comedy', 'Farce', 'in0000036'),
            ('comedy', 'High-Concept Comedy', 'in0000037'),
            ('comedy', 'Holiday Comedy', 'in0000194'),
            ('comedy', 'Mockumentary', 'in0000038'),
            ('comedy', 'Parody', 'in0000039'),
            ('comedy', 'Quirky Comedy', 'in0000040'),
            ('comedy', 'Raunchy Comedy', 'in0000041'),
            ('comedy', 'Satire', 'in0000042'),
            ('comedy', 'Screwball Comedy', 'in0000043'),
            ('comedy', 'Sketch Comedy', 'in0000045'),
            ('comedy', 'Slapstick', 'in0000046'),
            ('comedy', 'Stand-Up', 'in0000047'),
            ('comedy', 'Stoner Comedy', 'in0000048'),
            ('comedy', 'Teen Comedy', 'in0000049'),
            ('crime', 'Caper', 'in0000050'),
            ('crime', 'Cop Drama', 'in0000051'),
            ('crime', 'Drug Crime', 'in0000053'),
            ('crime', 'Gangster', 'in0000055'),
            ('crime', 'Heist', 'in0000056'),
            ('crime', 'Police Procedural', 'in0000057'),
            ('crime', 'True Crime', 'in0000058'),
            ('documentary', 'Crime Documentary', 'in0000059'),
            ('documentary', 'Faith & Spirit Documentary', 'in0000062'),
            ('documentary', 'Food Documentary', 'in0000063'),
            ('documentary', 'History Documentary', 'in0000064'),
            ('documentary', 'Military Documentary', 'in0000065'),
            ('documentary', 'Music Documentary', 'in0000066'),
            ('documentary', 'Nature Documentary', 'in0000067'),
            ('documentary', 'Political Documentary', 'in0000068'),
            ('documentary', 'Science & Technology Documentary', 'in0000069'),
            ('documentary', 'Sports Documentary', 'in0000070'),
            ('documentary', 'Travel Documentary', 'in0000071'),
            ('drama', 'Biography', 'in0000072'),
            ('drama', 'Coming-of-Age', 'in0000073'),
            ('drama', 'Costume Drama', 'in0000074'),
            ('drama', 'Docudrama', 'in0000075'),
            ('drama', 'Epic', 'in0000077'),
            ('drama', 'Financial Drama', 'in0000078'),
            ('drama', 'Legal Drama', 'in0000081'),
            ('drama', 'Medical Drama', 'in0000082'),
            ('drama', 'Period Drama', 'in0000083'),
            ('drama', 'Political Drama', 'in0000084'),
            ('drama', 'Prison Drama', 'in0000085'),
            ('drama', 'Psychological Drama', 'in0000086'),
            ('drama', 'Short', 'in0000212'),
            ('drama', 'Showbiz Drama', 'in0000087'),
            ('drama', 'Teen Drama', 'in0000089'),
            ('drama', 'Tragedy', 'in0000090'),
            ('drama', 'Workplace Drama', 'in0000091'),
            ('family', 'Animal Adventure', 'in0000092'),
            ('family', 'Holiday', 'in0000192'),
            ('family', 'Holiday Family', 'in0000195'),
            ('fantasy', 'Dark Fantasy', 'in0000095'),
            ('fantasy', 'Fairy Tale', 'in0000097'),
            ('fantasy', 'Fantasy Epic', 'in0000096'),
            ('fantasy', 'Supernatural Fantasy', 'in0000099'),
            ('fantasy', 'Sword & Sorcery', 'in0000100'),
            ('fantasy', 'Teen Fantasy', 'in0000101'),
            ('history', 'Historical Epic', 'in0000079'),
            ('horror', 'B-Horror', 'in0000108'),
            ('horror', 'Body Horror', 'in0000109'),
            ('horror', 'Folk Horror', 'in0000110'),
            ('horror', 'Found Footage Horror', 'in0000111'),
            ('horror', 'Monster Horror', 'in0000113'),
            ('horror', 'Pyschological Horror', 'in0000114'),
            ('horror', 'Slasher Horror', 'in0000115'),
            ('horror', 'Splatter Horror', 'in0000116'),
            ('horror', 'Supernatural Horror', 'in0000117'),
            ('horror', 'Teen Horror', 'in0000118'),
            ('horror', 'Vampire Horror', 'in0000119'),
            ('horror', 'Werewolf Horror', 'in0000120'),
            ('horror', 'Witch Horror', 'in0000121'),
            ('horror', 'Zombie Horror', 'in0000122'),
            ('music', 'Concert', 'in0000129'),
            ('musical', 'Classic Musical', 'in0000131'),
            ('musical', 'Jukebox Musical', 'in0000132'),
            ('musical', 'Pop Musical', 'in0000134'),
            ('musical', 'Rock Musical', 'in0000135'),
            ('mystery', 'Bumbling Detective', 'in0000136'),
            ('mystery', 'Cozy Mystery', 'in0000137'),
            ('mystery', 'Hard-boiled Detective', 'in0000138'),
            ('mystery', 'Suspense Mystery', 'in0000140'),
            ('mystery', 'Whodunit', 'in0000141'),
            ('romance', 'Dark Romance', 'in0000149'),
            ('romance', 'Feel-Good Romance', 'in0000151'),
            ('romance', 'Holiday Romance', 'in0000196'),
            ('romance', 'Romantic Comedy', 'in0000153'),
            ('romance', 'Romantic Epic', 'in0000150'),
            ('romance', 'Steamy Romance', 'in0000154'),
            ('romance', 'Teen Romance', 'in0000155'),
            ('romance', 'Tragic Romance', 'in0000156'),
            ('sci_fi', 'Alien Invasion', 'in0000157'),
            ('sci_fi', 'Artificial Intelligence', 'in0000158'),
            ('sci_fi', 'Cyberpunk', 'in0000159'),
            ('sci_fi', 'Dystopian Sci-Fi', 'in0000160'),
            ('sci_fi', 'Kaiju', 'in0000161'),
            ('sci_fi', 'Sci-Fi Epic', 'in0000163'),
            ('sci_fi', 'Space Sci-Fi', 'in0000164'),
            ('sci_fi', 'Steampunk', 'in0000165'),
            ('sci_fi', 'Time Travel', 'in0000166'),
            ('sport', 'Baseball', 'in0000167'),
            ('sport', 'Basketball', 'in0000168'),
            ('sport', 'Boxing', 'in0000169'),
            ('sport', 'Extreme Sport', 'in0000170'),
            ('sport', 'Football', 'in0000171'),
            ('sport', 'Motorsport', 'in0000172'),
            ('sport', 'Soccer', 'in0000173'),
            ('sport', 'Water Sport', 'in0000175'),
            ('thriller', 'Conspiracy Thriller', 'in0000176'),
            ('thriller', 'Cyber Thriller', 'in0000177'),
            ('thriller', 'Erotic Thriller', 'in0000178'),
            ('thriller', 'Giallo', 'in0000179'),
            ('thriller', 'Legal Thriller', 'in0000180'),
            ('thriller', 'Political Thriller', 'in0000181'),
            ('thriller', 'Psychological Thriller', 'in0000182'),
            ('thriller', 'Serial Killer', 'in0000183'),
            ('thriller', 'Spy', 'in0000184'),
            ('thriller', 'Survival', 'in0000185'),
            ('war', 'War Epic', 'in0000011'),
            ('western', 'Classical Western', 'in0000187'),
            ('western', 'Contemporary Western', 'in0000188'),
            ('western', 'Spaghetti Western', 'in0000190'),
            ('western', 'Western Epic', 'in0000189')
        ]

        for i in interests:
            self.list.append(
                {
                    'name': '%s  |  [B]%s[/B]' % (i[0].title().replace('_', '-'), i[1]),
                    'url': self.imdb_interests_link % i[2],
                    'image': 'genres/{}.png'.format(i[0]),
                    'action': 'movies'
                }
            )
        self.addDirectory(self.list)
        return self.list


    def tmdb_genres(self, code=''):
        genres = [
            ('Action', '28', 'action'),
            ('Adventure', '12', 'adventure'),
            ('Animation', '16', 'animation'),
            ('Comedy', '35', 'comedy'),
            ('Crime', '80', 'crime'),
            ('Documentary', '99', 'documentary'),
            ('Drama', '18', 'drama'),
            ('Family', '10751', 'family'),
            ('Fantasy', '14', 'fantasy'),
            ('History', '36', 'history'),
            ('Horror', '27', 'horror'),
            ('Music', '10402', 'music'),
            ('Mystery', '9648', 'mystery'),
            ('Romance', '10749', 'romance'),
            ('Science Fiction', '878', 'sci_fi'),
            ('TV Movie', '10770', 'reality_tv'),
            ('Thriller', '53', 'thriller'),
            ('War', '10752', 'war'),
            ('Western', '37', 'western')
        ]

        region = self.country if code else ''

        for i in genres:
            self.list.append(
                {
                    'name': cleangenre.lang(i[0], self.lang),
                    'url': self.tmdb_genre_link % (i[1], code, region),
                    'image': 'genres/{}.png'.format(i[2]),
                    'action': 'movies'
                }
            )
        self.addDirectory(self.list)
        return self.list


    def languages(self, code='', tmdb=False):
        languages = [
            ('Arabic', 'ar'),
            ('Bosnian', 'bs'),
            ('Bulgarian', 'bg'),
            ('Chinese', 'zh'),
            ('Croatian', 'hr'),
            ('Dutch', 'nl'),
            ('English', 'en'),
            ('Finnish', 'fi'),
            ('French', 'fr'),
            ('German', 'de'),
            ('Greek', 'el'),
            ('Hebrew', 'he'),
            ('Hindi ', 'hi'),
            ('Hungarian', 'hu'),
            ('Icelandic', 'is'),
            ('Italian', 'it'),
            ('Japanese', 'ja'),
            ('Korean', 'ko'),
            ('Macedonian', 'mk'),
            ('Norwegian', 'no'),
            ('Persian', 'fa'),
            ('Polish', 'pl'),
            ('Portuguese', 'pt'),
            ('Punjabi', 'pa'),
            ('Romanian', 'ro'),
            ('Russian', 'ru'),
            ('Serbian', 'sr'),
            ('Slovenian', 'sl'),
            ('Spanish', 'es'),
            ('Swedish', 'sv'),
            ('Turkish', 'tr'),
            ('Ukrainian', 'uk')
        ]

        region = self.country if code else ''

        for i in languages:
            self.list.append(
                {
                    'name': i[0],
                    'url': self.imdb_language_link % i[1] if not tmdb else self.tmdb_language_link % (i[1], code, region),
                    'image': 'languages.png',
                    'action': 'movies'
                }
            )
        self.addDirectory(self.list)
        return self.list


    def certifications(self, code='', tmdb=False):
        certificates = ['G', 'PG', 'PG-13', 'R', 'NC-17']

        region = self.country if code else ''

        for i in certificates:
            excCert = ','.join([c for c in certificates if c!=i])

            self.list.append(
                {
                    'name': i,
                    'url': self.imdb_certification_link % (i, excCert) if not tmdb else self.tmdb_certification_link % (i, code, region),
                    'image': 'mpaa/{}.png'.format(i),
                    'action': 'movies'
                }
            )
        self.addDirectory(self.list)
        return self.list


    def awards(self):
        navigator.navigator().addDirectoryItem('Academy Awards (Oscars)', 'movieOscars', 'awards/Oscars.png', 'DefaultMovies.png')

        events = [
            (control.lang(32151).format(control.lang(32153)), 'ev0000292,,WINNER_ONLY', 'Golden Globes'),
            (control.lang(32152).format(control.lang(32153)), 'ev0000292,,', 'Golden Globes'),
            (control.lang(32151).format(control.lang(32154)), 'ev0000147,,WINNER_ONLY', 'Cannes'),
            (control.lang(32152).format(control.lang(32154)), 'ev0000147,,', 'Cannes'),
            (control.lang(32151).format('BAFTA Awards'), 'ev0000123,,WINNER_ONLY', 'Bafta'),
            (control.lang(32152).format('BAFTA Awards'), 'ev0000123,,', 'Bafta'),
            (control.lang(32151).format('Critics Choice Awards'), 'ev0000133,,WINNER_ONLY', 'Critics Choice'),
            (control.lang(32152).format('Critics Choice Awards'), 'ev0000133,,', 'Critics Choice'),
            (control.lang(32151).format('Film Independent Spirit Awards'), 'ev0000349,,WINNER_ONLY', 'Film Independent'),
            (control.lang(32152).format('Film Independent Spirit Awards'), 'ev0000349,,', 'Film Independent'),
            (control.lang(32151).format(control.lang(32155)), 'ev0000558,,WINNER_ONLY', 'Razzies'),
            (control.lang(32152).format(control.lang(32155)), 'ev0000558,,', 'Razzies'),
            ('Sundance Film Festival', 'ev0000631,,WINNER_ONLY', 'Sundance'),
            ('Toronto International Film Festival', 'ev0000659,,WINNER_ONLY', 'TIFF'),
            ('Berlin International Film Festival', 'ev0000091,,WINNER_ONLY', 'Berlin'),
            ('Venice Film Festival', 'ev0000681,,WINNER_ONLY', 'Venice'),
            ('BFI London Film Festival', 'ev0000404,,WINNER_ONLY', 'BFI'),
            ('Fantasia Film Festival', 'ev0000235,,', 'awards'),
            ('Fantastic Fest', 'ev0001695,,', 'awards'),
            ('FrightFest', 'ev0004049,,', 'awards'),
            ('Panic Fest', 'ev0005439,,', 'awards'),
            ('Popcorn Frights', 'ev0004167,,', 'awards'),
            ('The Overlook Film Festival', 'ev0005624,,', 'awards'),
            ('Buried Alive Film Festival', 'ev0004822,,', 'awards'),
            ('Days of the Dead Film Festival', 'ev0039802,,', 'awards')
        ]

        for i in events:
            self.list.append(
                {
                    'name': i[0],
                    'url': self.imdb_awards_link % i[1],
                    'image': 'awards/{}.png'.format(i[2]),
                    'action': 'movies'
                }
            )
        self.addDirectory(self.list)
        return self.list


    def oscars(self):
        awards = [
            (control.lang(32151).format('Best Picture'), 'ev0000003,bestPicture,WINNER_ONLY'),
            (control.lang(32152).format('Best Picture'), 'ev0000003,bestPicture,'),
            (control.lang(32151).format('Best in Directing'), 'ev0000003,bestDirector,WINNER_ONLY'),
            (control.lang(32152).format('Best in Directing'), 'ev0000003,bestDirector,'),
            (control.lang(32151).format('Best Actor'), 'ev0000003,bestActor,WINNER_ONLY'),
            (control.lang(32152).format('Best Actor'), 'ev0000003,bestActor,'),
            (control.lang(32151).format('Best Actress'), 'ev0000003,bestActress,WINNER_ONLY'),
            (control.lang(32152).format('Best Actress'), 'ev0000003,bestActress,'),
            (control.lang(32156), 'ev0000003,,WINNER_ONLY')
        ]

        for i in awards:
            self.list.append(
                {
                    'name': i[0],
                    'url': self.imdb_awards_link % i[1],
                    'image': 'awards/Oscars.png',
                    'action': 'movies'
                }
            )
        self.addDirectory(self.list)
        return self.list


    def years(self, code='', tmdb=False):
        region = self.country if code else ''
        year = (self.datetime.strftime('%Y'))

        for i in range(int(year), 1900, -1):
            self.list.append(
                {
                    'name': str(i),
                    'url': self.imdb_year_link % (str(i), str(i)) if not tmdb else self.tmdb_year_link % (str(i), code, region),
                    'image': 'years.png',
                    'action': 'movies'
                }
            )
        self.addDirectory(self.list)
        return self.list


    def decades(self, code='', tmdb=False):
        region = self.country if code else ''
        year = (self.datetime.strftime('%Y'))
        dec = int(year[:3]) * 10

        for i in range(dec, 1890, -10):
            self.list.append(
                {
                    'name': str(i) + 's',
                    'url': self.imdb_year_link % (str(i), str(i+9)) if not tmdb else self.tmdb_decade_link % (str(i) + '-01-01', str(i+9) + '-12-31', code, region),
                    'image': 'years.png',
                    'action': 'movies'
                }
            )
        self.addDirectory(self.list)
        return self.list


    def services(self, code):
        _code = urllib_parse.quote(code)

        navigator.navigator().addDirectoryItem(32011, 'movieTmdbGenres&code=%s' % _code, 'genres.png', 'DefaultMovies.png')
        navigator.navigator().addDirectoryItem(32012, 'movieYears&code=%s&tmdb=True' % _code, 'years.png', 'DefaultMovies.png')
        navigator.navigator().addDirectoryItem(32123, 'movieDecades&code=%s&tmdb=True' % _code, 'years.png', 'DefaultMovies.png')
        navigator.navigator().addDirectoryItem(32015, 'movieCertificates&code=%s&tmdb=True' % _code, 'certificates.png', 'DefaultMovies.png')
        navigator.navigator().addDirectoryItem(32014, 'movieLanguages&code=%s&tmdb=True' % _code, 'languages.png', 'DefaultMovies.png')

        self.list.append(
            {
                'name': control.lang(32018),
                'url': self.tmdb_providers_pop_link % code,
                'image': 'people-watching.png',
                'action': 'movies'
            })
        self.list.append(
            {
                'name': control.lang(32023),
                'url': self.tmdb_providers_rated_link % code,
                'image': 'highly-rated.png',
                'action': 'movies'
            })
        self.list.append(
            {
                'name': control.lang(32019),
                'url': self.tmdb_providers_voted_link % code,
                'image': 'most-voted.png',
                'action': 'movies'
            })
        self.list.append(
            {
                'name': control.lang(32568),
                'url': self.tmdb_providers_added_link % code,
                'image': 'latest-movies.png',
                'action': 'movies'
            })
        self.addDirectory(self.list)
        return self.list


    def services_availability(self, tmdb, code):
        url = self.tmdb_providers_avail_link % tmdb
        r = self.session.get(url, timeout=10).json()
        r = r['results'].get(self.country)
        if r:
            offers = [r.get('free'), r.get('ads'), r.get('flatrate')]
            offers = [o for o in offers if o]
            if offers:
                providers = []
                for o in offers:
                    for c in o:
                        providers.append(str(c['provider_id']))
                if providers:
                    if any(p in code.split('|') for p in providers):
                        return True
        return False


    def userlists(self):
        navigator.navigator().addDirectoryItem(32158, 'addIMDbList', 'userlists.png', 'DefaultMovies.png', isFolder=False)

        userlists = []

        try:
            control.makeFile(control.dataPath)
            dbcon = database.connect(control.mylistsFile)
            dbcur = dbcon.cursor()
            dbcur.execute("CREATE TABLE IF NOT EXISTS imdbLists (""id TEXT, ""name TEXT, ""author TEXT, ""UNIQUE(id)"");")
            dbcur.execute("SELECT * FROM imdbLists")
            lists = dbcur.fetchall()
            dbcon.commit()
            dbcon.close()
            if lists:
                for lst in lists:
                    try:
                        url = self.imdb_customlist_link % (lst[0], self.imdb_sort())
                        name = "  ".join((lst[1], '[I](%s)[/I]' % lst[2]))
                        userlists += [{'name': name, 'url': url, 'context': url, 'image': 'imdb.png', 'context2': 'delIMDbList&url=%s' % lst[0]}]
                    except:
                        pass
        except:
            pass

        try:
            if self.imdb_user == '': raise Exception()
            userlists += cache.get(self.imdb_user_list, 24, self.imdb_userlists_link)
        except:
            pass

        try:
            if trakt.getTraktCredentialsInfo() == False: raise Exception()
            try:
                activity = trakt.getActivity()
            except:
                pass

            try:
                userlists += [{'name': 'Favorites', 'url': self.trakfavorites_link, 'context': self.trakfavorites_link, 'image': 'trakt.png'}]
            except:
                pass

            try:
                self.list = []
                try:
                    if activity > cache.timeout(self.trakt_user_list, self.traktlists_link): raise Exception()
                    userlists += cache.get(self.trakt_user_list, 720, self.traktlists_link)
                except:
                    userlists += cache.get(self.trakt_user_list, 0, self.traktlists_link)
            except:
                pass

            try:
                self.list = []
                try:
                    if activity > cache.timeout(self.trakt_user_list, self.traktlikedlists_link): raise Exception()
                    userlists += cache.get(self.trakt_user_list, 720, self.traktlikedlists_link)
                except:
                    userlists += cache.get(self.trakt_user_list, 0, self.traktlikedlists_link)
            except:
                pass
        except:
            pass

        self.list = userlists
        for i in range(0, len(self.list)):
            self.list[i].update({'action': 'movies'})
        self.addDirectory(self.list, queue=True, catch=False)
        return self.list


    def trakt_list(self, url):
        try:
            q = dict(urllib_parse.parse_qsl(urllib_parse.urlsplit(url).query))
            q.update({'extended': 'full'})
            q = (urllib_parse.urlencode(q)).replace('%2C', ',')
            u = url.replace('?' + urllib_parse.urlparse(url).query, '') + '?' + q

            result = trakt.getTrakt(u)

            items = []
            for i in result:
                try: items.append(i['movie'])
                except: pass
            if len(items) == 0:
                items = result
        except:
            log_utils.log('movies_trakt_list0', 1)
            return self.list

        try:
            q = dict(urllib_parse.parse_qsl(urllib_parse.urlsplit(url).query))
            if not int(q['limit']) == len(items): raise Exception()
            page = q['page']
            q.update({'page': str(int(page) + 1)})
            q = (urllib_parse.urlencode(q)).replace('%2C', ',')
            nxt = url.replace('?' + urllib_parse.urlparse(url).query, '') + '?' + q
        except:
            nxt = page = ''

        for item in items:
            try:
                title = item['title']

                year = item.get('year')
                if year: year = re.sub(r'[^0-9]', '', str(year))
                else: year = '0'
                #if int(year) > int((self.datetime).strftime('%Y')): raise Exception()

                imdb = item.get('ids', {}).get('imdb')
                if not imdb: imdb = '0'
                else: imdb = 'tt' + re.sub(r'[^0-9]', '', str(imdb))

                tmdb = item.get('ids', {}).get('tmdb')
                if not tmdb: tmdb == '0'
                else: tmdb = str(tmdb)

                premiered = item.get('released')
                if premiered: premiered = re.compile(r'(\d{4}-\d{2}-\d{2})').findall(premiered)[0]
                else: premiered = '0'

                genre = item.get('genres')
                if genre:
                    genre = [i.title() for i in genre]
                    genre = ' / '.join(genre)
                else: genre = '0'

                duration = item.get('runtime')
                if duration: duration = str(duration)
                else: duration = '0'

                rating = item.get('rating')
                if rating and not rating == '0.0': rating = str(rating)
                else: rating = '0'

                try: votes = str(item['votes'])
                except: votes = '0'
                try: votes = str(format(int(votes),',d'))
                except: pass
                if votes == None: votes = '0'

                mpaa = item.get('certification', '0') or '0'

                country = item.get('country')
                if not country: country = '0'
                else: country = country.upper()

                tagline = item.get('tagline', '0') or '0'

                plot = item.get('overview', '0') or '0'

                paused_at = item.get('paused_at', '0') or '0'
                paused_at = re.sub('[^0-9]+', '', paused_at)

                self.list.append({'title': title, 'originaltitle': title, 'year': year, 'premiered': premiered, 'genre': genre, 'duration': duration, 'rating': rating, 'votes': votes,
                                  'mpaa': mpaa, 'plot': plot, 'tagline': tagline, 'imdb': imdb, 'imdbnumber': imdb, 'tmdb': tmdb, 'country': country, 'tvdb': '0', 'poster': '0',
                                  'paused_at': paused_at, 'mediatype': 'movie', 'list_prov': 'trakt', 'page': page, 'next': nxt})
            except:
                log_utils.log('movies_trakt_list1', 1)
                pass

        return self.list


    def trakt_user_list(self, url):
        try:
            items = trakt.getTrakt(url)
        except:
            pass

        for item in items:
            try:
                try:
                    name_list = (trakt.slug(item['list']['user']['username']), item['list']['ids']['slug'])
                    name = "  ".join((item['list']['name'], '[I](%s)[/I]' % name_list[0]))
                    desc = item['list'].get('description', '') or ''
                except:
                    name_list = ('me', item['ids']['slug'])
                    name = item['name']
                    desc = item.get('description', '') or ''

                url = self.traktlist_link % name_list

                self.list.append({'name': name, 'url': url, 'context': url, 'image': 'trakt.png', 'plot': desc})
            except:
                pass

        self.list = sorted(self.list, key=lambda k: k['name'].lower())
        return self.list


    def imdb_graphql(self, url):
        try:
            if url == self.imdb_watchlist_link:
                wl_id = cache.get(imdb_api.get_watchlist_id, 7200, 'ur%s' % self.imdb_user)
                url = self.imdb_customlist_link % (wl_id, self.imdb_sort())

            first = int(self.items_per_page)
            after = url.split('&after=')[1]
            query = re.findall(r'query=([^&]+)', url)[0]
            pars = re.findall(r'params=([^&]*)', url)[0]
            pars = dict(p.split(':') for p in pars.split('|'))
            func = getattr(imdb_api, query)

            items = func(first, after, pars)
            #log_utils.log(items)
            if items['pageInfo']['hasNextPage']:
                page = re.findall(r'&page=(\d+)&', url)[0]
                page = int(page)
                nxt = re.sub(r'&after=%s' % after, '&after=%s' % items['pageInfo']['endCursor'], url)
                nxt = re.sub(r'&page=(\d+)&', '&page=%s&' % str(page+1), nxt)
            else:
                nxt = page = ''
            items = items['edges']
            #log_utils.log(items)


            for item in items:
                try:
                    try: item = item['node']['title']
                    except:
                        try: item = item['title']
                        except: item = item['node']
                    title = item['titleText']['text']
                    try: plot = item['plot']['plotText']['plainText'] or '0'
                    except: plot = '0'
                    try: poster = item['primaryImage']['url']
                    except: poster = ''
                    if not poster or '/sash/' in poster or '/nopicture/' in poster: poster = '0'
                    else: poster = re.sub(r'(?:_SX|_SY|_UX|_UY|_CR|_AL|_V)(?:\d+|_).+?\.', '_SX500.', poster)
                    rating = str(item['ratingsSummary']['aggregateRating']) or '0'
                    votes = str(item['ratingsSummary']['voteCount']) or '0'
                    year = str(item['releaseYear']['year']) or '0'
                    try: premiered = '%d-%02d-%02d' % (item['releaseDate']['year'], item['releaseDate']['month'], item['releaseDate']['day'])
                    except: premiered = '0'
                    try: mpaa = item['certificate']['rating'] or '0'
                    except: mpaa = '0'
                    try: duration = item['runtime']['seconds']
                    except: duration = '0'
                    if duration and not duration == '0': duration = str(int(duration // 60))
                    else: duration = '0'
                    imdb = item['id']

                    self.list.append({'title': title, 'originaltitle': title, 'year': year, 'genre': '0', 'duration': duration, 'rating': rating, 'votes': votes, 'mpaa': mpaa,
                                      'director': '0', 'plot': plot, 'tagline': '0', 'imdb': imdb, 'imdbnumber': imdb, 'tmdb': '0', 'tvdb': '0', 'poster': poster, 'cast': '0',
                                      'premiered': premiered, 'mediatype': 'movie', 'list_prov': 'imdb', 'page': page, 'next': nxt})
                except:
                    log_utils.log('imdb_graphql_item fail', 1)
                    pass
        except:
            log_utils.log('imdb_graphql_list fail', 1)
            pass

        return self.list


    def imdb_user_list(self, url):
        result = imdb_api.get_userlists('ur%s' % self.imdb_user)
        #log_utils.log(result)

        items = result['edges']
        for item in items:
            try:
                name = cleantitle.normalize(item['node']['name']['originalText'])
                url = self.imdb_customlist_link % (item['node']['id'], self.imdb_sort())
                self.list.append({'name': name, 'url': url, 'context': url, 'image': 'imdb.png'})
            except:
                pass

        self.list = sorted(self.list, key=lambda k: k['name'].lower())
        return self.list


    def tmdb_list(self, url, code):
        try:
            #log_utils.log(url)
            result = self.session.get(url, timeout=16)
            result.raise_for_status()
            result.encoding = 'utf-8'
            result = result.json() if six.PY3 else utils.json_loads_as_str(result.text)
            if not '/person/' in url:
                items = result['results']
            else:
                items = result['cast'] + result['crew']
                items = sorted(items, key=lambda k: k['popularity'], reverse=True)
                items = list({item['id']: item for item in items}.values())
            if not items:
                if 'with_watch_providers' in url:
                    control.infoDialog('Service not available in %s' % self.country)
                raise Exception()
        except:
            log_utils.log('tmdb_list0', 1)
            return self.list

        try:
            page = int(result['page'])
            total = int(result['total_pages'])
            if page >= total: raise Exception()
            if 'page=' not in url: raise Exception()
            nxt = '%s&page=%s' % (url.split('&page=', 1)[0], page+1)
        except:
            nxt = page = ''

        for item in items:

            try:
                tmdb = str(item['id'])

                if code:
                    if not self.services_availability(tmdb, code):
                        continue

                title = item['title']

                originaltitle = item.get('original_title', '') or title

                try: rating = str(item['vote_average'])
                except: rating = ''
                if not rating: rating = '0'

                try: votes = str(item['vote_count'])
                except: votes = ''
                if not votes: votes = '0'

                try: premiered = item['release_date']
                except: premiered = ''
                if not premiered : premiered = '0'

                try: year = re.findall(r'(\d{4})', premiered)[0]
                except: year = ''
                if not year : year = '0'

                try: plot = item['overview']
                except: plot = ''
                if not plot: plot = '0'

                try: poster_path = item['poster_path']
                except: poster_path = ''
                if poster_path: poster = self.tmdb_img_link % ('500', poster_path)
                else: poster = '0'

                self.list.append({'title': title, 'originaltitle': originaltitle, 'premiered': premiered, 'year': year, 'rating': rating, 'votes': votes, 'plot': plot, 'imdb': '0',
                                  'tmdb': tmdb, 'tvdb': '0', 'mpaa': '0', 'poster': poster, 'mediatype': 'movie', 'list_prov': 'tmdb', 'page': page, 'next': nxt})
            except:
                log_utils.log('tmdb_list1', 1)
                pass

        return self.list


    def local_list(self, url):
        try:
            query = re.findall(r'query=([^&]+)', url)[0]
            control.makeFile(control.dataPath)

            db = control.mylistsFile if query == 'locallist' else control.bookmarksFile
            dbcon = database.connect(db)
            dbcur = dbcon.cursor()
            if query == 'history':
                dbcur.execute("SELECT * FROM bookmarks WHERE (type = 'movie' AND overlay = 7)")
            elif query == 'ondeck':
                dbcur.execute("SELECT * FROM bookmarks WHERE (type = 'movie' AND played_seconds > 120 AND progress < 92)")
            elif query == 'locallist':
                dbcur.execute("SELECT * FROM mylists WHERE type = 'movie'")
            all_items = dbcur.fetchall()
            dbcon.commit()
        except:
            log_utils.log('local_list_fail', 1)
            return self.list

        if all_items:
            try:
                all_items = sorted(all_items, key=lambda x: x[-1], reverse=True)
                all_items = [json.loads(m[3]) for m in all_items]
                for i in all_items:
                    i.pop('page', None) ; i.pop('next', None)

                size = int(self.items_per_page)
                after = url.split('&after=')[1]
                if after:
                    start = [i+1 for i, v in enumerate(all_items) if v['imdb'] == after][0]
                else:
                    start = 0
                end = start + size

                items = all_items[start:end]

                if len(all_items) - (size + start) > 0:
                    _after = [i['imdb'] for i in items][-1]
                    page = re.findall(r'&page=(\d+)&', url)[0]
                    page = int(page)
                    nxt = re.sub(r'&after=%s' % after, '&after=%s' % _after, url)
                    nxt = re.sub(r'&page=(\d+)&', '&page=%s&' % str(page+1), nxt)
                else:
                    nxt = page = ''

                for i in items:
                    i.update({'next': nxt, 'page': page, 'duration': str(int(i['duration']) // 60)})
                    self.list.append(i)
            except:
                log_utils.log('local_list_fail', 1)
                return

        return self.list


    def worker(self):
        self.meta = []
        total = len(self.list)

        for i in range(0, total): self.list[i].update({'metacache': False})

        self.list = metacache.fetch(self.list, self.lang, self.user)

        for r in range(0, total, 40):
            threads = []
            for i in range(r, r+40):
                if i < total: threads.append(workers.Thread(self.super_info, i))
            [i.start() for i in threads]
            [i.join() for i in threads]

        if self.meta: metacache.insert(self.meta)

        self.list = [i for i in self.list if not i['imdb'] == '0']

        #self.list = metacache.local(self.list, self.tmdb_img_link, 'poster', 'fanart')


    def super_info(self, i):
        try:
            if self.list[i]['metacache'] == True: return

            imdb = self.list[i]['imdb'] if 'imdb' in self.list[i] else '0'
            tmdb = self.list[i]['tmdb'] if 'tmdb' in self.list[i] else '0'
            list_title = self.list[i]['title']

            if (not tmdb or tmdb in ['0', 'None']) and (imdb and not imdb in ['0', 'None']):
                try:
                    url = self.tmdb_by_imdb % imdb
                    result = self.session.get(url, timeout=16).json()
                    id = result['movie_results'][0]
                    tmdb = id['id']
                    if not tmdb: tmdb = '0'
                    else: tmdb = str(tmdb)
                except:
                    tmdb = '0'

            # if tmdb == '0':
                # try:
                    # url = self.tmdb_search_link % (urllib_parse.quote(list_title)) + '&year=' + self.list[i]['year']
                    # result = self.session.get(url, timeout=16).json()
                    # results = result['results']
                    # movie = [r for r in results if cleantitle.get(r.get('name')) == cleantitle.get(list_title)][0]# and re.findall(r'(\d{4})', r.get('first_air_date'))[0] == self.list[i]['year']][0]
                    # tmdb = movie.get('id')
                    # if not tmdb: tmdb = '0'
                    # else: tmdb = str(tmdb)
                # except:
                    # pass

            id = tmdb if not tmdb == '0' else imdb
            if id == '0': raise Exception()

            en_url = self.tmdb_api_link % (id)
            f_url = en_url + ',translations'
            url = en_url if self.lang == 'en' else f_url
            #log_utils.log('tmdb_url: ' + url)

            r = self.session.get(url, timeout=10)
            r.raise_for_status()
            r.encoding = 'utf-8'
            item = r.json() if six.PY3 else utils.json_loads_as_str(r.text)
            #log_utils.log('tmdb_item: ' + repr(item))

            if imdb == '0':
                try:
                    imdb = item['external_ids']['imdb_id']
                    if not imdb: imdb = '0'
                except:
                    imdb = '0'

            original_language = item.get('original_language', '')

            if self.lang == 'en':
                en_trans_item = None
            else:
                try:
                    translations = item['translations']['translations']
                    en_trans_item = [x['data'] for x in translations if x['iso_639_1'] == 'en'][0]
                except:
                    en_trans_item = {}

            name = item.get('title', '')
            original_name = item.get('original_title', '')
            en_trans_name = en_trans_item.get('title', '') if not self.lang == 'en' else None
            #log_utils.log('self_lang: %s | original_language: %s | list_title: %s | name: %s | original_name: %s | en_trans_name: %s' % (self.lang, original_language, list_title, name, original_name, en_trans_name))

            if self.lang == 'en':
                title = label = name
            else:
                title = en_trans_name or original_name
                if original_language == self.lang:
                    label = name
                else:
                    label = en_trans_name or name
            if not title: title = list_title
            if not label: label = list_title

            plot = item.get('overview') or self.list[i]['plot']

            tagline = item.get('tagline') or '0'

            if not self.lang == 'en':
                if plot == '0':
                    en_plot = en_trans_item.get('overview', '')
                    if en_plot: plot = en_plot

                if tagline == '0':
                    en_tagline = en_trans_item.get('tagline', '')
                    if en_tagline: tagline = en_tagline

            status = item.get('status') or '0'

            premiered = self.list[i]['premiered']
            if not premiered or premiered == '0':
                premiered = item.get('release_date') or '0'

            if premiered == '0' or (int(re.sub('[^0-9]', '', str(premiered))) > int(re.sub('[^0-9]', '', str(self.today_date)))):
                cache_upd = 48
            else:
                cache_upd = 360

            try: _year = re.findall(r'(\d{4})', premiered)[0]
            except: _year = ''
            if not _year : _year = '0'
            year = self.list[i]['year'] if not self.list[i]['year'] == '0' else _year

            try: studio = item['production_companies'][0]['name']
            except: studio = ''
            if not studio: studio = '0'

            try:
                genre = item['genres']
                genre = [d['name'] for d in genre]
                genre = ' / '.join(genre)
            except:
                genre = ''
            if not genre: genre = '0'

            try:
                country = item['production_countries']
                country = [c['name'] for c in country]
                country = ' / '.join(country)
            except:
                country = ''
            if not country: country = '0'
            else: country = country.replace('United States of America', 'USA').replace('United Kingdom', 'UK')

            try:
                duration = str(item['runtime'])
            except:
                duration = ''
            if not duration: duration = '0'

            mpaa = self.list[i]['mpaa']
            if not mpaa or mpaa == '0':
                try:
                    m = item['release_dates']['results']
                    m = [i['release_dates'] for i in m if i['iso_3166_1'] == 'US'][0]
                    for c in m:
                        if c['certification']:
                            if c['type'] not in [3, 4, 5, 6]:
                                continue
                            mpaa = c['certification']
                            break
                except:
                    pass

            # rating = self.list[i]['rating']
            # votes = self.list[i]['votes']
            # if rating == votes == '0':
                # try: rating = str(item['vote_average'])
                # except: rating = ''
                # if not rating: rating = '0'
                # try: votes = str(item['vote_count'])
                # except: votes = ''
                # if not votes: votes = '0'

            castwiththumb = []
            try:
                c = item['credits']['cast'][:30]
                for person in c:
                    _icon = person['profile_path']
                    icon = self.tmdb_img_link % ('185', _icon) if _icon else ''
                    castwiththumb.append({'name': person['name'], 'role': person['character'], 'thumbnail': icon})
            except:
                pass
            if not castwiththumb: castwiththumb = '0'

            try:
                crew = item['credits']['crew']
                director = ', '.join([d['name'] for d in [x for x in crew if x['job'] == 'Director']])
                writer = ', '.join([w['name'] for w in [y for y in crew if y['job'] in ['Writer', 'Screenplay', 'Author', 'Novel']]])
            except:
                director = writer = '0'

            poster1 = self.list[i].get('poster')

            poster_path = item.get('poster_path')
            if poster_path:
                poster2 = self.tmdb_img_link % ('500', poster_path)
            else:
                poster2 = None

            fanart_path = item.get('backdrop_path')
            if fanart_path:
                fanart1 = self.tmdb_img_link % ('1280', fanart_path)
            else:
                fanart1 = '0'

            poster3 = fanart2 = None
            banner = clearlogo = clearart = landscape = discart = '0'
            if self.hq_artwork == 'true' and not imdb == '0':# and not self.fanart_tv_user == '':

                try:
                    r2 = self.session.get(self.fanart_tv_art_link % imdb, headers=self.fanart_tv_headers, timeout=10)
                    r2.raise_for_status()
                    r2.encoding = 'utf-8'
                    art = r2.json() if six.PY3 else utils.json_loads_as_str(r2.text)

                    try:
                        _poster3 = art['movieposter']
                        _poster3 = [x for x in _poster3 if x.get('lang') == self.lang][::-1] + [x for x in _poster3 if x.get('lang') == 'en'][::-1] + [x for x in _poster3 if x.get('lang') in ['00', '']][::-1]
                        _poster3 = _poster3[0]['url']
                        if _poster3: poster3 = _poster3
                    except:
                        pass

                    try:
                        if 'moviebackground' in art: _fanart2 = art['moviebackground']
                        else: _fanart2 = art['moviethumb']
                        _fanart2 = [x for x in _fanart2 if x.get('lang') == self.lang][::-1] + [x for x in _fanart2 if x.get('lang') == 'en'][::-1] + [x for x in _fanart2 if x.get('lang') in ['00', '']][::-1]
                        _fanart2 = _fanart2[0]['url']
                        if _fanart2: fanart2 = _fanart2
                    except:
                        pass

                    try:
                        _banner = art['moviebanner']
                        _banner = [x for x in _banner if x.get('lang') == self.lang][::-1] + [x for x in _banner if x.get('lang') == 'en'][::-1] + [x for x in _banner if x.get('lang') in ['00', '']][::-1]
                        _banner = _banner[0]['url']
                        if _banner: banner = _banner
                    except:
                        pass

                    try:
                        if 'hdmovielogo' in art: _clearlogo = art['hdmovielogo']
                        else: _clearlogo = art['clearlogo']
                        _clearlogo = [x for x in _clearlogo if x.get('lang') == self.lang][::-1] + [x for x in _clearlogo if x.get('lang') == 'en'][::-1] + [x for x in _clearlogo if x.get('lang') in ['00', '']][::-1]
                        _clearlogo = _clearlogo[0]['url']
                        if _clearlogo: clearlogo = _clearlogo
                    except:
                        pass

                    try:
                        if 'hdmovieclearart' in art: _clearart = art['hdmovieclearart']
                        else: _clearart = art['clearart']
                        _clearart = [x for x in _clearart if x.get('lang') == self.lang][::-1] + [x for x in _clearart if x.get('lang') == 'en'][::-1] + [x for x in _clearart if x.get('lang') in ['00', '']][::-1]
                        _clearart = _clearart[0]['url']
                        if _clearart: clearart = _clearart
                    except:
                        pass

                    try:
                        if 'moviethumb' in art: _landscape = art['moviethumb']
                        else: _landscape = art['moviebackground']
                        _landscape = [x for x in _landscape if x.get('lang') == self.lang][::-1] + [x for x in _landscape if x.get('lang') == 'en'][::-1] + [x for x in _landscape if x.get('lang') in ['00', '']][::-1]
                        _landscape = _landscape[0]['url']
                        if _landscape: landscape = _landscape
                    except:
                        pass

                    try:
                        if 'moviedisc' in art: _discart = art['moviedisc']
                        _discart = [x for x in _discart if x.get('lang') == self.lang][::-1] + [x for x in _discart if x.get('lang') == 'en'][::-1] + [x for x in _discart if x.get('lang') in ['00', '']][::-1]
                        _discart = _discart[0]['url']
                        if _discart: discart = _discart
                    except:
                        pass
                except:
                    #log_utils.log('fanart.tv art fail', 1)
                    pass

            poster = poster3 or poster2 or poster1
            fanart = fanart2 or fanart1

            item = {'title': title, 'originaltitle': title, 'label': label, 'year': year, 'imdb': imdb, 'tmdb': tmdb, 'poster': poster, 'banner': banner, 'fanart': fanart, 'clearlogo': clearlogo,
                    'clearart': clearart, 'landscape': landscape, 'discart': discart, 'premiered': premiered, 'genre': genre, 'duration': duration, 'mpaa': mpaa, 'director': director, 'writer': writer,
                    'castwiththumb': castwiththumb, 'plot': plot, 'tagline': tagline, 'status': status, 'studio': studio, 'country': country, 'mediatype': 'movie', 'cache_upd': cache_upd}
            #item = dict((k,v) for k, v in six.iteritems(item) if not v == '0')
            self.list[i].update(item)

            meta = {'imdb': imdb, 'tmdb': tmdb, 'tvdb': '0', 'lang': self.lang, 'user': self.user, 'item': item}
            self.meta.append(meta)
        except:
            log_utils.log('superinfo_fail', 1)
            pass


    def movieDirectory(self, items):
        from sys import argv
        if not items:
            control.idle()
            control.infoDialog('No content')

        sysaddon = argv[0]

        syshandle = int(argv[1])

        addonPoster, addonFanart, addonBanner = control.addonPoster(), control.addonFanart(), control.addonBanner()

        traktCredentials = trakt.getTraktCredentialsInfo()

        kodiVersion = control.getKodiVersion()

        isPlayable = True if not 'plugin' in control.infoLabel('Container.PluginName') else False

        indicators = playcount.getMovieIndicators(refresh=True) if action == 'movies' else playcount.getMovieIndicators()

        myList = mylists.check_list('movie') if traktCredentials == False else []

        if self.trailer_source == '0': trailerAction = 'tmdb_trailer'
        elif self.trailer_source == '1': trailerAction = 'yt_trailer'
        else: trailerAction = 'imdb_trailer'

        playbackMenu = control.lang(32063) if control.setting('hosts.mode') == '2' else control.lang(32064)

        watchedMenu = control.lang(32068) if trakt.getTraktIndicatorsInfo() == True else control.lang(32066)

        unwatchedMenu = control.lang(32069) if trakt.getTraktIndicatorsInfo() == True else control.lang(32067)

        queueMenu = control.lang(32065)

        traktManagerMenu = control.lang(32070)

        addMyListMenu = control.lang(32525)

        delMyListMenu = control.lang(32526)

        nextMenu = control.lang(32053)

        addToLibrary = control.lang(32551)

        clearProviders = control.lang(32081)

        findSimilar = control.lang(32100)

        infoMenu = control.lang(32101)

        list_items = []
        for i in items:
            try:
                i = dict((k, ('0' if v == 'None' else v)) for k, v in six.iteritems(i))
                imdb, tmdb, title, year = i['imdb'], i['tmdb'], i['originaltitle'], i['year']
                label = i['label'] if 'label' in i and not i['label'] == '0' else title
                label = '%s (%s)' % (label, year)
                status = i['status'] if 'status' in i else '0'
                try:
                    premiered = i['premiered']
                    if (premiered == '0' and status in ['Rumored', 'Planned', 'In Production', 'Post Production', 'Upcoming']) or (int(re.sub('[^0-9]', '', premiered)) > int(re.sub('[^0-9]', '', str(self.today_date)))):
                        label = '[COLOR crimson]%s [I][Upcoming][/I][/COLOR]' % label
                except:
                    pass

                sysname = urllib_parse.quote_plus('%s (%s)' % (title, year))
                systitle = urllib_parse.quote_plus(title)

                meta = dict((k,v) for k, v in six.iteritems(i) if not v == '0')
                meta.update({'trailer': '%s?action=%s&mode=play&name=%s&tmdb=%s&imdb=%s' % (sysaddon, trailerAction, systitle, tmdb, imdb)})
                if not 'duration' in meta or meta['duration'] in ['0', 'None']: meta.update({'duration': '120'})
                try: meta.update({'duration': str(int(meta['duration']) * 60)})
                except: pass
                try: meta.update({'genre': cleangenre.lang(meta['genre'], self.lang)})
                except: pass
                if 'castwiththumb' in meta: meta.pop('cast', '0')

                poster = i['poster'] if 'poster' in i and not i['poster'] == '0' else addonPoster
                fanart = i['fanart'] if 'fanart' in i and not i['fanart'] == '0' else addonFanart
                banner = i['banner'] if 'banner' in i and not i['banner'] == '0' else addonBanner
                landscape = i['landscape'] if 'landscape' in i and not i['landscape'] == '0' else fanart
                offset = bookmarks.get('movie', imdb, '', '', True)

                meta.update({'mediatype': 'movie', 'imdbnumber': imdb, 'code': tmdb, 'label': label, 'offset': offset,
                             'poster': poster, 'fanart': fanart, 'banner': banner, 'landscape': landscape})

                sysmeta = urllib_parse.quote_plus(json.dumps(meta))

                related_link = urllib_parse.quote_plus(self.imdb_related_link % imdb) if self.lists_provider == '0' else urllib_parse.quote_plus(self.tmdb_related_link % tmdb)

                url = '%s?action=play&title=%s&year=%s&imdb=%s&tmdb=%s&meta=%s&t=%s' % (sysaddon, systitle, year, imdb, tmdb, sysmeta, self.systime)
                sysurl = urllib_parse.quote_plus(url)

                #path = '%s?action=play&title=%s&year=%s&imdb=%s' % (sysaddon, systitle, year, imdb)

                cm = []

                cm.append((findSimilar, 'Container.Update(%s?action=movies&url=%s)' % (sysaddon, related_link)))

                cm.append(('[I]Cast[/I]', 'RunPlugin(%s?action=moviecredits&tmdb=%s&status=%s)' % (sysaddon, tmdb, status)))

                cm.append(('[I]Videos[/I]', 'RunPlugin(%s?action=%s&mode=select&name=%s&tmdb=%s&imdb=%s)' % (sysaddon, trailerAction, systitle, tmdb, imdb)))

                cm.append((queueMenu, 'RunPlugin(%s?action=queueItem)' % sysaddon))

                try:
                    overlay = int(playcount.getMovieOverlay(indicators, imdb))
                    if overlay == 7:
                        cm.append((unwatchedMenu, 'RunPlugin(%s?action=moviePlaycount&imdb=%s&query=6&meta=%s)' % (sysaddon, imdb, sysmeta)))
                        meta.update({'playcount': 1, 'overlay': 7})
                    else:
                        cm.append((watchedMenu, 'RunPlugin(%s?action=moviePlaycount&imdb=%s&query=7&meta=%s)' % (sysaddon, imdb, sysmeta)))
                        meta.update({'playcount': 0, 'overlay': 6})
                except:
                    meta.update({'playcount': 0, 'overlay': 6})

                if traktCredentials == True:
                    cm.append((traktManagerMenu, 'RunPlugin(%s?action=traktManager&name=%s&imdb=%s&content=movie)' % (sysaddon, sysname, imdb)))
                else:
                    if imdb not in myList:
                        cm.append((addMyListMenu, 'RunPlugin(%s?action=addMyList&name=%s&imdb=%s&content=movie&meta=%s)' % (sysaddon, sysname, imdb, sysmeta)))
                    else:
                        cm.append((delMyListMenu, 'RunPlugin(%s?action=delMyList&name=%s&imdb=%s)' % (sysaddon, sysname, imdb)))

                cm.append((addToLibrary, 'RunPlugin(%s?action=movieToLibrary&name=%s&title=%s&year=%s&imdb=%s&tmdb=%s)' % (sysaddon, sysname, systitle, year, imdb, tmdb)))

                cm.append((playbackMenu, 'RunPlugin(%s?action=alterSources&url=%s&meta=%s)' % (sysaddon, sysurl, sysmeta)))

                cm.append(('[I]Custom Scrape[/I]', 'RunPlugin(%s?action=playCustom&title=%s&year=%s&imdb=%s&meta=%s&t=%s)' % (sysaddon, systitle, year, imdb, sysmeta, self.systime)))

                cm.append((clearProviders, 'RunPlugin(%s?action=clearCacheProviders)' % sysaddon))

                if kodiVersion < 17:
                    cm.append((infoMenu, 'Action(Info)'))

                #cm.append(('[I]Clear All Cache[/I]', 'RunPlugin(%s?action=clearAllCache)' % sysaddon))

                art = {'icon': poster, 'thumb': poster, 'poster': poster, 'fanart': fanart, 'banner': banner, 'landscape': landscape}

                if 'clearlogo' in i and not i['clearlogo'] == '0':
                    art.update({'clearlogo': i['clearlogo']})

                if 'clearart' in i and not i['clearart'] == '0':
                    art.update({'clearart': i['clearart']})

                if 'discart' in i and not i['discart'] == '0':
                    art.update({'discart': i['discart']})

                try: item = control.item(label=label, offscreen=True)
                except: item = control.item(label=label)

                item.setArt(art)
                item.addContextMenuItems(cm)

                if isPlayable:
                    item.setProperty('IsPlayable', 'true')

                control.processListItem(item, meta)

                #control.addItem(handle=syshandle, url=url, listitem=item, isFolder=False)
                list_items.append((url, item, False))
            except:
                log_utils.log('movies_dir', 1)
                pass

        try:
            url = items[0]['next']
            if url == '': raise Exception()

            icon = control.addonNext()
            url = '%s?action=moviePage&url=%s' % (sysaddon, urllib_parse.quote_plus(url))
            if self.code: url += '&code=%s' % urllib_parse.quote(self.code)

            if 'page' in items[0] and items[0]['page']: nextMenu += '[I] (%s)[/I]' % str(int(items[0]['page']) + 1)

            try: item = control.item(label=nextMenu, offscreen=True)
            except: item = control.item(label=nextMenu)

            item.setArt({'icon': icon, 'thumb': icon, 'poster': icon, 'banner': icon, 'fanart': addonFanart})
            item.setProperty('SpecialSort', 'bottom')

            #control.addItem(handle=syshandle, url=url, listitem=item, isFolder=True)
            list_items.append((url, item, True))
        except:
            pass

        control.addItems(handle=syshandle, items=list_items, totalItems=len(list_items))
        control.content(syshandle, 'movies')
        control.directory(syshandle, cacheToDisc=True)
        control.sleep(1000)
        views.setView('movies', {'skin.estuary': 55, 'skin.confluence': 500})


    def addDirectory(self, items, queue=False, catch=True):
        from sys import argv
        if not items:
            control.idle()
            control.infoDialog('No content')

        sysaddon = argv[0]

        syshandle = int(argv[1])

        addonFanart, addonThumb, artPath = control.addonFanart(), control.addonThumb(), control.artPath()

        queueMenu = control.lang(32065)

        playRandom = control.lang(32535)

        addToLibrary = control.lang(32551)

        removeList = control.lang(32159)

        kodiVersion = control.getKodiVersion()

        list_items = []
        for i in items:
            try:
                name = i['name']

                plot = i.get('plot') or '[CR]'

                if i['image'].startswith('http'): thumb = i['image']
                elif not artPath == None: thumb = os.path.join(artPath, i['image'])
                else: thumb = addonThumb

                url = '%s?action=%s' % (sysaddon, i['action'])
                try: url += '&url=%s' % urllib_parse.quote_plus(i['url'])
                except: pass

                cm = []

                cm.append((playRandom, 'RunPlugin(%s?action=random&rtype=movie&url=%s)' % (sysaddon, urllib_parse.quote_plus(i['url']))))

                if queue == True:
                    cm.append((queueMenu, 'RunPlugin(%s?action=queueItem)' % sysaddon))

                if 'context' in i: cm.append((addToLibrary, 'RunPlugin(%s?action=moviesToLibrary&url=%s)' % (sysaddon, urllib_parse.quote_plus(i['context']))))
                if 'context2' in i: cm.append((removeList, 'RunPlugin(%s?action=%s)' % (sysaddon, i['context2'])))

                try: item = control.item(label=name, offscreen=True)
                except: item = control.item(label=name)

                item.addContextMenuItems(cm)
                item.setArt({'icon': thumb, 'thumb': thumb, 'poster': thumb, 'fanart': addonFanart})

                if kodiVersion > 19:
                    vtag = item.getVideoInfoTag()
                    vtag.setMediaType('video')
                    vtag.setPlot(plot)
                else:
                    item.setInfo(type='video', infoLabels={'plot': plot})

                #control.addItem(handle=syshandle, url=url, listitem=item, isFolder=True)
                list_items.append((url, item, True))
            except:
                log_utils.log('mov_addDir', 1)
                pass

        control.addItems(handle=syshandle, items=list_items, totalItems=len(list_items))
        control.content(syshandle, '')
        control.directory(syshandle, cacheToDisc=catch)
