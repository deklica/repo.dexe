# -*- coding: utf-8 -*-
# HTML-Remote 
# Copyright (c) 2026 zusatzmetall | Team IT('s) Possible. All rights reserved.
# Version 2026.10.22
# LEGAL NOTICE:
# Any liability and warranty for damages of any kind is excluded. 
# This code is the intellectual property of the authors.
# Modifying, altering, rewriting or the unauthorized 
# redistribution of this code is strictly prohibited.
import os
import http.server
import socketserver
import urllib.parse
import threading
import socket
import json
import time
import zipfile
import shutil
import re
import xbmc
import xbmcaddon
import xbmcvfs
import xbmcgui 

DEFAULT_PORT = 50808
ADDON = xbmcaddon.Addon()


def get_port():
    try:
        value = int(ADDON.getSetting('port').strip())
        if 1024 <= value <= 65535:
            return value
    except Exception:
        pass
    return DEFAULT_PORT


PORT = get_port()
ADDON_PATH = ADDON.getAddonInfo('path')
HTML_DIR = os.path.join(ADDON_PATH)
TEMP_DIR = xbmcvfs.translatePath('special://temp/')

PROFILE_DIR = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
FALLBACK_UPLOADS_DIR = os.path.join(PROFILE_DIR, 'uploads')
FLAG_FILE = os.path.join(PROFILE_DIR, 'initialized.flag')

# Old hardcoded default from earlier versions - treated as "not set"
LEGACY_DEFAULT_PATH = "/storage/emulated/0/Download/Telegram/Kodi/Downloads"

def get_active_uploads_dir():
    custom_path = ADDON.getSetting('download_path').strip()

    # Not set (or still the old default) -> use the add-on's own profile folder
    if not custom_path or custom_path.rstrip('/') == LEGACY_DEFAULT_PATH:
        os.makedirs(FALLBACK_UPLOADS_DIR, exist_ok=True)
        return FALLBACK_UPLOADS_DIR

    # Resolve special:// paths; network paths (smb://, nfs://...) can't be written with os.*
    custom_path = xbmcvfs.translatePath(custom_path)
    if '://' in custom_path:
        xbmc.log(f"Kodi Web Remote warning: Network path '{custom_path}' is not supported, using fallback profile folder.", xbmc.LOGWARNING)
        os.makedirs(FALLBACK_UPLOADS_DIR, exist_ok=True)
        return FALLBACK_UPLOADS_DIR

    try:
        os.makedirs(custom_path, exist_ok=True)
        test_file = os.path.join(custom_path, ".write_test")
        with open(test_file, 'w') as f:
            f.write("test")
        os.remove(test_file)
        return custom_path
    except Exception as e:
        xbmc.log(f"Kodi Web Remote warning: Could not use download path '{custom_path}' ({e}), using fallback profile folder.", xbmc.LOGWARNING)
        os.makedirs(FALLBACK_UPLOADS_DIR, exist_ok=True)
        return FALLBACK_UPLOADS_DIR

def get_local_ip():
    candidates = []

    for target in (("8.8.8.8", 80), ("10.255.255.255", 1), ("192.168.255.255", 1)):
        s = None
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.settimeout(0.5)
            s.connect(target)
            candidates.append(s.getsockname()[0])
        except Exception:
            pass
        finally:
            if s:
                try:
                    s.close()
                except Exception:
                    pass

    try:
        candidates.extend(socket.gethostbyname_ex(socket.gethostname())[2])
    except Exception:
        pass

    try:
        kodi_ip = xbmc.getInfoLabel('Network.IPAddress')
        if kodi_ip:
            candidates.append(kodi_ip.strip())
    except Exception:
        pass

    for ip in candidates:
        if ip and not ip.startswith('127.') and not ip.startswith('169.254.') and ip != '0.0.0.0':
            return ip
    return "127.0.0.1"

class ThreadingHTTPServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True
    allow_reuse_address = True

class RemoteHandler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=HTML_DIR, **kwargs)

    def log_message(self, format, *args):
        xbmc.log(f"Kodi Web Remote HTTP: {format % args}", xbmc.LOGINFO)

    def do_GET(self):
        parsed_path = urllib.parse.urlparse(self.path)
        path = parsed_path.path
        query = urllib.parse.parse_qs(parsed_path.query)

        if 'get_ip' in path:
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            ip_data = json.dumps({"ip": get_local_ip(), "port": PORT})
            self.wfile.write(ip_data.encode('utf-8'))
            return

        if 'list_uploads' in path:
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            files = []
            target_dir = get_active_uploads_dir()
            if os.path.exists(target_dir):
                for f in os.listdir(target_dir):
                    if f.startswith('.'): 
                        continue
                    f_path = os.path.join(target_dir, f)
                    if os.path.isfile(f_path):
                        files.append({"name": f, "size": os.path.getsize(f_path)})
            self.wfile.write(json.dumps(files).encode('utf-8'))
            return

        if 'delete_upload' in path:
            file_name = query.get('file', [''])[0]
            self.send_response(200)
            self.send_header('Content-type', 'text/plain')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            if file_name:
                safe_name = os.path.basename(file_name)
                target_dir = get_active_uploads_dir()
                target_path = os.path.join(target_dir, safe_name)

                if os.path.exists(target_path):
                    try:
                        os.remove(target_path)
                        xbmc.log(f"Kodi Web Remote: File deleted successfully: {safe_name}", xbmc.LOGINFO)
                        self.wfile.write(b"DELETED")
                        return
                    except Exception as e:
                        xbmc.log(f"Kodi Web Remote delete error: {e}", xbmc.LOGERROR)

            self.wfile.write(b"NOT_FOUND")
            return

        if 'action' in path:
            cmd = query.get('cmd', [''])[0]
            extra_query = query.get('query', [''])[0]

            if cmd:
                if cmd == 'playfile' and extra_query:
                    target_dir = get_active_uploads_dir()
                    if os.path.isabs(extra_query) and os.path.exists(extra_query):
                        media_path = extra_query
                    else:
                        media_path = os.path.join(target_dir, os.path.basename(extra_query))
                    
                    if os.path.exists(media_path):
                        xbmc.executebuiltin(f'PlayMedia("{media_path}")')
                        xbmc.log(f"Kodi Web Remote: Playing file: {media_path}", xbmc.LOGINFO)
                    else:
                        xbmc.executebuiltin(f'PlayMedia("{extra_query}")')
                        xbmc.log(f"Kodi Web Remote: Playing file (fallback): {extra_query}", xbmc.LOGWARNING)
                else:
                    self.handle_command(cmd, extra_query)

            self.send_response(200)
            self.send_header('Content-type', 'text/plain')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            self.wfile.write(b"OK")
            return

        elif path.startswith('/text') or 'txt' in query:
            text_val = ""
            if 'txt' in query:
                text_val = query.get('txt', [''])[0]
            
            text_val = urllib.parse.unquote(text_val).strip()
            
            current_time = time.time()
            if hasattr(self, '_last_text_time') and hasattr(self, '_last_text_val'):
                if text_val == self._last_text_val and (current_time - self._last_text_time) < 0.6:
                    xbmc.log(f"Kodi Web Remote: Duplicate request '{text_val}' ignored.", xbmc.LOGINFO)
                    self.send_response(200)
                    self.send_header('Content-type', 'text/plain')
                    self.send_header('Access-Control-Allow-Origin', '*')
                    self.end_headers()
                    self.wfile.write(b"Duplicate ignored")
                    return

            self._last_text_time = current_time
            self._last_text_val = text_val

            xbmc.log(f"Kodi Web Remote voice command received: '{text_val}'", xbmc.LOGINFO)
            
            if text_val:
                self.handle_text(text_val)

            self.send_response(200)
            self.send_header('Content-type', 'text/plain')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            self.wfile.write(b"Text processed")
            return

        return super().do_GET()

    def do_POST(self):
        if '/upload_addon' in self.path:
            try:
                content_type = self.headers.get('content-type', '')
                if 'boundary=' in content_type:
                    boundary = content_type.split('boundary=')[1].encode('utf-8')
                    content_length = int(self.headers.get('content-length', 0))
                    
                    body = self.rfile.read(content_length)
                    parts = body.split(b'--' + boundary)
                    
                    file_data = None
                    for part in parts:
                        if b'filename="' in part:
                            header_end = part.find(b'\r\n\r\n')
                            if header_end != -1:
                                file_data = part[header_end + 4:-2]
                                break
                    
                    if file_data:
                        os.makedirs(TEMP_DIR, exist_ok=True)
                        zip_path = os.path.join(TEMP_DIR, "uploaded_addon.zip")
                        
                        with open(zip_path, 'wb') as f:
                            f.write(file_data)
                        
                        addons_dir = xbmcvfs.translatePath('special://home/addons/')
                        os.makedirs(addons_dir, exist_ok=True)
                        
                        addon_id = None
                        root_dir_in_zip = None
                        
                        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                            namelist = zip_ref.namelist()
                            
                            addon_xml_path = None
                            for name in namelist:
                                norm_name = name.replace('\\', '/')
                                if norm_name.endswith('addon.xml'):
                                    addon_xml_path = name
                                    name_parts = norm_name.split('/')
                                    if len(name_parts) > 1:
                                        root_dir_in_zip = name_parts[0]
                                    break
                            
                            if addon_xml_path:
                                with zip_ref.open(addon_xml_path) as xml_file:
                                    xml_content = xml_file.read().decode('utf-8', errors='ignore')
                                    match = re.search(r'<addon[^>]+id=["\']([^"\']+)["\']', xml_content, re.IGNORECASE)
                                    if match:
                                        addon_id = match.group(1)
                            
                            if not addon_id and root_dir_in_zip:
                                addon_id = root_dir_in_zip.replace('-master', '').replace('-main', '')
                            
                            if not addon_id:
                                top_dirs = set()
                                for name in namelist:
                                    name_parts = name.replace('\\', '/').split('/')
                                    if name_parts and name_parts[0]:
                                        top_dirs.add(name_parts[0])
                                if top_dirs:
                                    addon_id = list(top_dirs)[0].replace('-master', '').replace('-main', '')
                            
                            if not addon_id:
                                raise ValueError("Could not determine add-on ID")
                            
                            target_addon_path = os.path.join(addons_dir, addon_id)
                            if os.path.exists(target_addon_path):
                                try:
                                    shutil.rmtree(target_addon_path)
                                    xbmc.log(f"Kodi Web Remote: Previous add-on folder deleted: {target_addon_path}", xbmc.LOGINFO)
                                except Exception as ex:
                                    xbmc.log(f"Kodi Web Remote: Could not delete folder {target_addon_path}: {ex}", xbmc.LOGWARNING)
                            
                            temp_extract_dir = os.path.join(TEMP_DIR, "extracted_addon_temp")
                            if os.path.exists(temp_extract_dir):
                                shutil.rmtree(temp_extract_dir)
                            os.makedirs(temp_extract_dir, exist_ok=True)
                            
                            zip_ref.extractall(temp_extract_dir)
                        
                        extracted_addon_root = temp_extract_dir
                        if root_dir_in_zip and os.path.exists(os.path.join(temp_extract_dir, root_dir_in_zip)):
                            extracted_addon_root = os.path.join(temp_extract_dir, root_dir_in_zip)
                        else:
                            for root, dirs, files in os.walk(temp_extract_dir):
                                if 'addon.xml' in files:
                                    extracted_addon_root = root
                                    break
                        
                        if os.path.exists(target_addon_path):
                            shutil.rmtree(target_addon_path)
                        shutil.copytree(extracted_addon_root, target_addon_path)
                        
                        try:
                            shutil.rmtree(temp_extract_dir)
                        except:
                            pass
                        
                        xbmc.executebuiltin('UpdateLocalAddons')
                        time.sleep(1.0)
                        
                        if addon_id:
                            try:
                                rpc_query = {
                                    "jsonrpc": "2.0",
                                    "method": "Addons.SetAddonEnabled",
                                    "params": { "addonid": addon_id, "enabled": True },
                                    "id": 1
                                }
                                xbmc.executeJSONRPC(json.dumps(rpc_query))
                                xbmc.log(f"Kodi Web Remote: Add-on enabled: {addon_id}", xbmc.LOGINFO)
                            except Exception as rpc_err:
                                xbmc.log(f"Kodi Web Remote activation error for {addon_id}: {rpc_err}", xbmc.LOGWARNING)
                        
                        xbmcgui.Dialog().notification("Kodi Web Remote", "Add-on installed & enabled successfully!", xbmcgui.NOTIFICATION_INFO, 3000)
                        xbmc.log(f"Kodi Web Remote: Add-on ZIP installed and enabled successfully ({addon_id})", xbmc.LOGINFO)
                        
                        self.send_response(200)
                        self.send_header('Content-type', 'text/plain')
                        self.send_header('Access-Control-Allow-Origin', '*')
                        self.end_headers()
                        self.wfile.write(b"SUCCESS")
                        return

            except Exception as e:
                xbmc.log(f"Kodi Web Remote upload error: {e}", xbmc.LOGERROR)

            self.send_response(500)
            self.end_headers()
            self.wfile.write(b"ERROR")
            return

        elif '/upload_media' in self.path:
            try:
                content_type = self.headers.get('content-type', '')
                if 'boundary=' in content_type:
                    boundary = content_type.split('boundary=')[1].encode('utf-8')
                    content_length = int(self.headers.get('content-length', 0))
                    body = self.rfile.read(content_length)
                    parts = body.split(b'--' + boundary)
                    
                    file_data = None
                    file_name = "media_file"
                    media_type = "video"
                    
                    for part in parts:
                        if b'name="type"' in part and b'filename="' not in part:
                            header_end = part.find(b'\r\n\r\n')
                            if header_end != -1:
                                media_type = part[header_end + 4:-2].decode('utf-8', errors='ignore').strip()

                        if b'filename="' in part and file_data is None:
                            try:
                                fn_start = part.find(b'filename="') + 10
                                fn_end = part.find(b'"', fn_start)
                                if fn_end != -1:
                                    file_name = part[fn_start:fn_end].decode('utf-8', errors='ignore')
                            except:
                                pass
                            
                            header_end = part.find(b'\r\n\r\n')
                            if header_end != -1:
                                file_data = part[header_end + 4:-2]
                    
                    if file_data:
                        target_dir = get_active_uploads_dir()
                        safe_name = os.path.basename(file_name) or "media_file"
                        media_path = os.path.join(target_dir, safe_name)
                        
                        with open(media_path, 'wb' ) as f:
                            f.write(file_data)
                        
                        xbmc.log(f"Kodi Web Remote: Media saved ({media_type}): {media_path}", xbmc.LOGINFO)
                        xbmc.executebuiltin(f'PlayMedia("{media_path}")')
                        
                        self.send_response(200)
                        self.send_header('Content-type', 'text/plain')
                        self.send_header('Access-Control-Allow-Origin', '*')
                        self.end_headers()
                        self.wfile.write(b"SUCCESS")
                        return
            except Exception as e:
                xbmc.log(f"Kodi Web Remote media upload error: {e}", xbmc.LOGERROR)

            self.send_response(500)
            self.end_headers()
            self.wfile.write(b"ERROR")
            return

        self.send_response(404)
        self.end_headers()

    def handle_command(self, cmd, query=""):
        command_map = {
            'up': 'Action(up)',
            'down': 'Action(down)',
            'left': 'Action(left)',
            'right': 'Action(right)',
            'select': 'Action(select)',
            'back': 'Action(back)',
            'home': 'ActivateWindow(Home)',
            'contextmenu': 'Action(contextmenu)',
            'playpause': 'Action(playpause)',
            'stop': 'Action(stop)',
            'backspace': 'Action(backspace)',
            'volumeup': 'Action(volumeup)',
            'volumedown': 'Action(volumedown)',
            'mute': 'Action(mute)',
            'settings': 'ActivateWindow(settings)',
            'fullscreen': 'Action(fullscreen)',
            'osd': 'Action(osd)',
            'info': 'Action(info)',
            'subtitles': 'Action(nextsubtitle)',
            'audio': 'Action(audionextlanguage)',
            'filemanager': 'ActivateWindow(10040,"addons://user/all",return)'
        }

        if cmd in command_map:
            xbmc.executebuiltin(command_map[cmd])
        elif cmd == 'open_addon' and query:
            self.open_addon_by_name(query)
        elif cmd == 'close_addon':
            xbmc.executebuiltin('Dialog.Close(all, true)')
            xbmc.executebuiltin('Action(back)')
        elif cmd == 'builtin' and query:
            xbmc.executebuiltin(query)
            xbmc.log(f"Kodi Web Remote: Executed builtin command: {query}", xbmc.LOGINFO)
        elif cmd == 'search' and query:
            rpc_query = {
                "jsonrpc": "2.0",
                "method": "Input.SendText",
                "params": { "text": query, "done": True },
                "id": 1
            }
            xbmc.executeJSONRPC(json.dumps(rpc_query))

    def open_addon_by_name(self, name):
        try:
            clean_search = name.replace(" ", "").replace("-", "").lower()
            xbmc.log(f"Kodi Web Remote: Dynamic add-on search for '{name}' (cleaned: '{clean_search}')", xbmc.LOGINFO)
            
            target_id = None
            rpc_query = {
                "jsonrpc": "2.0",
                "method": "Addons.GetAddons",
                "params": { "properties": ["name", "addonid"] },
                "id": 1
            }
            result = xbmc.executeJSONRPC(json.dumps(rpc_query))
            data = json.loads(result)
            
            if "result" in data and "addons" in data["result"]:
                for addon in data["result"]["addons"]:
                    addon_id = addon["addonid"]
                    addon_name = addon.get("name", "")
                    
                    clean_id = addon_id.lower().replace(".", "").replace("_", "").replace("-", "")
                    clean_name = addon_name.lower().replace(" ", "").replace("-", "")
                    
                    if clean_search in clean_name or clean_search in clean_id or clean_id in clean_search:
                        target_id = addon_id
                        xbmc.log(f"Kodi Web Remote: Match found! ID: {target_id} ({addon_name})", xbmc.LOGINFO)
                        break
            
            if target_id:
                xbmc.executebuiltin(f'RunAddon({target_id})')
            else:
                launched = False
                for prefix in ["plugin.video.", "plugin.audio.", "plugin.image.", "script.", "service."]:
                    test_id = prefix + clean_search
                    try:
                        xbmc.executebuiltin(f'RunAddon({test_id})')
                        xbmc.log(f"Kodi Web Remote: Launched via prefix fallback: {test_id}", xbmc.LOGINFO)
                        launched = True
                        break
                    except:
                        pass
                
                if not launched:
                    xbmc.executebuiltin(f'RunAddon({name})')
                
        except Exception as e:
            xbmc.log(f"Kodi Web Remote open_addon error: {e}", xbmc.LOGERROR)

    def handle_text(self, text):
        text_lower = text.lower().strip()
        xbmc.log(f"Kodi Web Remote processing command (lower): '{text_lower}'", xbmc.LOGINFO)
        
        if any(k in text_lower for k in ["open favorites", "show favorites", "favorites", "favourites"]):
            xbmc.executebuiltin('ActivateWindow(Favourites)')
        elif any(k in text_lower for k in ["open weather", "show weather", "weather"]):
            xbmc.executebuiltin('ActivateWindow(weather)')
        elif any(k in text_lower for k in ["open settings", "settings"]):
            xbmc.executebuiltin('ActivateWindow(settings)')
        elif any(k in text_lower for k in ["go home", "main menu", "home", "home screen"]):
            xbmc.executebuiltin('ActivateWindow(Home)')
            
        elif text_lower in ["pause", "resume", "play", "continue"]:
            xbmc.executebuiltin('Action(playpause)')
        elif text_lower in ["stop", "stop playback"]:
            xbmc.executebuiltin('Action(stop)')
        elif text_lower in ["mute", "sound off", "unmute"]:
            xbmc.executebuiltin('Action(mute)')
        elif text_lower in ["louder", "volume up"]:
            xbmc.executebuiltin('Action(volumeup)')
        elif text_lower in ["quieter", "volume down"]:
            xbmc.executebuiltin('Action(volumedown)')

        elif text_lower.startswith("search movie"):
            for prefix in ["search movies ", "search movie "]:
                if text_lower.startswith(prefix):
                    query = text[len(prefix):].strip()
                    break
            else:
                query = ""
            
            if query:
                xbmc.executebuiltin(f'ActivateWindow(10025,"plugin://plugin.video.moviescout/?action=searchMovies&query={urllib.parse.quote(query)}",return)')
            else:
                xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.moviescout/?action=searchMovies",return)')
                
        elif text_lower.startswith("search series") or text_lower.startswith("search show"):
            for prefix in ["search series ", "search shows ", "search show "]:
                if text_lower.startswith(prefix):
                    query = text[len(prefix):].strip()
                    break
            else:
                query = ""
            
            if query:
                xbmc.executebuiltin(f'ActivateWindow(10025,"plugin://plugin.video.moviescout/?action=searchTV&query={urllib.parse.quote(query)}",return)')
            else:
                xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.moviescout/?action=searchTV",return)')

        elif text_lower.startswith("search person") or text_lower.startswith("search people"):
            for prefix in ["search persons ", "search person ", "search people "]:
                if text_lower.startswith(prefix):
                    query = text[len(prefix):].strip()
                    break
            else:
                query = ""
            
            if query:
                xbmc.executebuiltin(f'ActivateWindow(10025,"plugin://plugin.video.moviescout/?action=searchPerson&query={urllib.parse.quote(query)}",return)')
            else:
                xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.moviescout/?action=searchPerson",return)')

        elif text_lower.startswith("open "):
            query = text[5:].strip()
            self.open_addon_by_name(query)
            
        elif text_lower.startswith("close ") or text_lower in ["close", "exit"]:
            xbmc.executebuiltin('Dialog.Close(all, true)')
            xbmc.executebuiltin('Action(back)')

        elif text_lower == "party mode":
            xbmc.executebuiltin('RunAddon(plugin.audio.spotify)')
            xbmc.log("Kodi Web Remote Macro: Party mode activated", xbmc.LOGINFO)

        elif text == '\b' or text == 'BACKSPACE':
            xbmc.executebuiltin('Action(backspace)')
        else:
            rpc_query = {
                "jsonrpc": "2.0",
                "method": "Input.SendText",
                "params": { "text": text, "done": True },
                "id": 1
            }
            xbmc.executeJSONRPC(json.dumps(rpc_query))


def run_server():
    try:
        if ADDON.getSetting('enabled') == 'false':
            xbmc.log("Kodi Web Remote is disabled in the add-on settings.", xbmc.LOGINFO)
            return

        httpd = None
        last_error = None
        for attempt in range(6):
            try:
                httpd = ThreadingHTTPServer(("0.0.0.0", PORT), RemoteHandler)
                break
            except Exception as bind_err:
                last_error = bind_err
                xbmc.log(f"Kodi Web Remote: Port {PORT} not available (attempt {attempt + 1}/6): {bind_err}", xbmc.LOGWARNING)
                time.sleep(2)

        if httpd is None:
            xbmc.log(f"Kodi Web Remote server error: Could not open port {PORT}: {last_error}", xbmc.LOGERROR)
            xbmcgui.Dialog().notification("Kodi Web Remote", f"Port {PORT} is in use - server not started", xbmcgui.NOTIFICATION_ERROR, 6000)
            return

        local_ip = get_local_ip()
        full_address = f"http://{local_ip}:{PORT}"
        localhost_address = f"http://localhost:{PORT}"
        
        ADDON.setSetting('local_ip', full_address)
        ADDON.setSetting('localhost_ip', localhost_address)

        os.makedirs(PROFILE_DIR, exist_ok=True)
        get_active_uploads_dir() 
        
        if not os.path.exists(FLAG_FILE):
            try:
                with open(FLAG_FILE, 'w' ) as f:
                    f.write('initialized')
            except Exception as e:
                xbmc.log(f"Kodi Web Remote Error writing flag file: {e}", xbmc.LOGERROR)

            dialog_text = (
                f"Welcome to Kodi Web Remote!\n\n"
                f"This add-on provides a local web server "
                f"that lets you control Kodi from your phone or PC.\n\n"
                f"Open this in the browser on your phone/PC (on the same Wi-Fi as Kodi):\n"
                f"{full_address}\n\n"
                f"Note: 'localhost' ({localhost_address}) only works directly on the "
                f"device Kodi is running on - not from other devices.\n\n"
                f"This message is only shown on first start."
            )
            xbmcgui.Dialog().ok("Kodi Web Remote - Getting Started", dialog_text)
        else:
            xbmcgui.Dialog().notification("Kodi Web Remote", f"Available at {full_address}", xbmcgui.NOTIFICATION_INFO, 6000)

        xbmc.log(f"===================================================", xbmc.LOGINFO)
        xbmc.log(f" Kodi Web Remote started! Browser URL: {full_address}", xbmc.LOGINFO)
        xbmc.log(f"===================================================", xbmc.LOGINFO)
        httpd.serve_forever()
    except Exception as e:
        xbmc.log(f"Kodi Web Remote server error: {e}", xbmc.LOGERROR)

if __name__ == 'main' or __name__ == '__main__':
    server_thread = threading.Thread(target=run_server)
    server_thread.daemon = True
    server_thread.start()
    
    monitor = xbmc.Monitor()
    while not monitor.abortRequested():
        if monitor.waitForAbort(10):
            break
# LEGAL NOTICE:
# Any liability and warranty for damages of any kind is excluded. 
# This code is the intellectual property of the authors.
# Modifying, altering, rewriting or the unauthorized 
# redistribution of this code is strictly prohibited.
