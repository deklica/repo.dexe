import xbmc, xbmcgui, xbmcaddon

window = xbmcgui.Window(10000)
__addon__ = xbmcaddon.Addon(id='skin.fenstruary')
logger = xbmc.log
default_settings = ('DefaultBackgroundBrightness,Medium', 'DefaultFanartBrightness,Low', 'first_time_run,true')

class FenstruaryService(xbmc.Monitor):
    def __init__(self):
        xbmc.Monitor.__init__(self)
        self.startUp()

    def startUp(self):
        self.firstRun()
        self.kodiStart()
        self.updateMonitor()

    def firstRun(self):
        if xbmc.getInfoLabel('Skin.String(first_time_run)') == 'true': return
        for item in default_settings: xbmc.executebuiltin('Skin.SetString(%s)' % item)
        self.waitForAbort(1)
        xbmcgui.Dialog().ok('Fenstruary First Run', 'Go to Skin Settings to set Movie and TV Show menu items and widgets.')


    def kodiStart(self):
        from modules.cpath_maker import starting_widgets
        starting_widgets()

    def updateMonitor(self):
        while not self.abortRequested():
            if window.getProperty('fenstruary.pause_services') == "true":
                self.waitForAbort(10)
                continue
            property_version = window.getProperty('fenstruary.installed_version')
            installed_version = __addon__.getAddonInfo('version')
            if not property_version:
                window.setProperty('fenstruary.installed_version', installed_version)
                self.waitForAbort(5)
                continue
            if property_version != installed_version:
                from modules.cpath_maker import remake_all_cpaths, starting_widgets
                window.setProperty('fenstruary.installed_version', installed_version)
                self.waitForAbort(1)
                remake_all_cpaths(silent=True)
                starting_widgets()
            self.waitForAbort(5)

    def onNotification(self, sender, method, data):
        if sender == 'xbmc':
            if method in ('GUI.OnScreensaverActivated', 'System.OnSleep'):
                window.setProperty('fenstruary.pause_services', 'true')
                logger('###PAUSING Fenstruary Services Due to Device Sleep###', 1)
            elif method in ('GUI.OnScreensaverDeactivated', 'System.OnWake'):
                window.setProperty('fenstruary.pause_services', 'false')
                logger('###UNPAUSING Fenstruary Services Due to Device Awake###', 1)

logger('###Fenstruary: Service Started###', 1)
FenstruaryService().waitForAbort()
logger('###Fenstruary: Service Finished###', 1)
