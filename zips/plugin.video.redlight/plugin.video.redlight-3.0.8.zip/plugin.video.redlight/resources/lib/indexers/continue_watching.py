# -*- coding: utf-8 -*-
import sys
from indexers.movies import Movies
from indexers.episodes import build_single_episode, _widget_item_limit, _pin_recently_aired
from modules import kodi_utils, settings, watched_status as ws
from modules.utils import get_datetime
from datetime import datetime

def build_continue_watching(params):
	"""Paused movies, then one card per show (its newest paused episode, or its next episode if that was played more recently), most recently played first (#284, #286).

	Widget path: plugin://plugin.video.redlight/?mode=build_continue_watching (also TV Shows menu).
	Sort Recently Aired to Top (Continue Watching settings, #285) pins recently aired next-ups above everything else.
	Next-ups sort by when the show was last watched but carry no ListItem.LastPlayed, since they were never played.
	Unaired next-ups and never-started shows (Next Episodes' include-unwatched options) are left out: nothing to continue.
	"""
	handle, is_external = int(sys.argv[1]), kodi_utils.external()
	never = datetime.min
	movie_rows = ws.get_in_progress_movies('movie', 1)
	movies = Movies({'action': 'in_progress_movies', 'list': [(c, i['media_id']) for c, i in enumerate(movie_rows)], 'custom_order': 'true'})
	movies.last_played_by_id = {str(i['media_id']): i['last_played'] for i in movie_rows}
	rows = [(ws.local_last_played(movie_rows[c]['last_played']) or never, item) for item, c in movies.worker()]
	show = lambda i: str(i['row_packet']['tmdb_id']) if i.get('row_packet') else None
	played = lambda i: ws.local_last_played(i.get('last_played')) or never
	paused = build_single_episode('episode.progress', {'collect': 'true'}) or []
	next_up = build_single_episode('episode.next', {'collect': 'true', 'nextep_sort': 'last_played'}) or []
	# A next-up's last_played is the show's last full play; a pause older than that, or than the show's newest pause, is stale (#286).
	show_watched = {show(i): played(i) for i in next_up if show(i)}
	paused = [i for i in paused if not (show(i) in show_watched and never < played(i) < show_watched[show(i)])]
	newest_pause = {}
	for i in sorted(paused, key=played): newest_pause[show(i) or id(i)] = i
	paused = list(newest_pause.values())
	next_up = [i for i in next_up if not (i.get('unaired') or i.get('unwatched'))]
	paused_shows = {show(i) for i in paused if show(i)}
	next_up = [i for i in next_up if show(i) not in paused_shows]
	if settings.continue_watching_airing_today():
		pinned, next_up = _pin_recently_aired(next_up, get_datetime(), settings.continue_watching_airing_today_days())
	else: pinned = []
	rows += [(played(i), i['list_items']) for i in paused + next_up]
	rows.sort(key=lambda k: k[0], reverse=True)
	rows = [(None, i['list_items']) for i in pinned] + rows
	limit = _widget_item_limit(is_external)
	if limit: rows = rows[:limit]
	kodi_utils.add_items(handle, [i[1] for i in rows])
	kodi_utils.set_content(handle, 'episodes')
	kodi_utils.set_category(handle, 'Continue Watching')
	kodi_utils.end_directory(handle, cacheToDisc=False)
	kodi_utils.set_view_mode('view.episodes_single', 'episodes', is_external, fallback_view_types=('view.episodes',))
