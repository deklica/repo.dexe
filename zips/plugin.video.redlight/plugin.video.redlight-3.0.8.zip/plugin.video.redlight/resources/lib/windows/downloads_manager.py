# -*- coding: utf-8 -*-
import json
from windows.base_window import BaseDialog
from modules.kodi_utils import select_dialog, confirm_dialog, ok_dialog, notification
# from modules.kodi_utils import logger

class DownloadsManager(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, *args)
		self.window_id = 2500
		self.closed = False
		self.position = 0

	def onInit(self):
		self.make_active_downloads(first_run=True)
		self.monitor()

	def run(self):
		self.doModal()
		self.clearProperties()

	def onAction(self, action):
		if action in self.closing_actions:
			self.closed = True
			return self.close()
		else:
			if action in self.selection_actions: return self.set_status(self.get_listitem(self.window_id))

	def make_active_downloads(self, first_run=False):
		def queued_builder():
			for item in self.active_queued_downloads:
				try:
					listitem = self.make_listitem()
					listitem.setProperty('name', item.replace('.', ' ').replace('_', ' '))
					listitem.setProperty('item_id', item)
					listitem.setProperty('percent', '0')
					listitem.setProperty('status', 'queued')
					yield listitem
				except: pass
		def builder():
			for item in self.active_downloads:
				try:
					listitem = self.make_listitem()
					listitem.setProperty('name', item.replace('.', ' ').replace('_', ' '))
					listitem.setProperty('item_id', item)
					listitem.setProperty('percent', self.get_home_property(item))
					listitem.setProperty('status', self.get_status(item))
					yield listitem
				except: pass
		try:
			self.active_downloads = json.loads(self.get_home_property('active_downloads') or '[]')
			self.active_item_list = list(builder())
			_queue_epoch, self.active_queued_downloads = self._queued_state()
			self.queued_item_list = list(queued_builder())
			self.item_list = self.active_item_list + self.queued_item_list
			self.item_list.sort(key=lambda li: (li.getProperty('item_id') or '').lower())
			self.setProperty('active', str(len(self.active_item_list)))
			self.setProperty('queued', str(len(self.queued_item_list)))
			self.reset_window(self.window_id)
			self.add_items(self.window_id, self.item_list)
			if first_run: self.setFocusId(self.window_id)
			else: self.select_item(self.window_id, self.position)
		except: pass

	def get_status(self, item_id):
		return self.get_home_property('download_status.%s' % item_id)

	def _queued_state(self):
		raw = self.get_home_property('active_queued_downloads') or ''
		if not raw:
			return None, []
		try:
			data = json.loads(raw)
		except Exception:
			return None, []
		if isinstance(data, dict):
			return data.get('epoch'), list(data.get('names') or [])
		if isinstance(data, list):
			return None, data
		return None, []

	def _write_queued_state(self, epoch, names):
		if not names:
			self.clear_home_property('active_queued_downloads')
			return
		if epoch is None:
			self.set_home_property('active_queued_downloads', json.dumps(names))
		else:
			self.set_home_property('active_queued_downloads', json.dumps({'epoch': epoch, 'names': names}))

	def _mark_cancelled(self, name):
		epoch_now = self.get_home_property('download_queue_epoch') or '0'
		self.set_home_property('download_cancel_epoch.%s' % name, epoch_now)
		self.set_home_property('download_status.%s' % name, 'cancelled')

	def set_status(self, list_item):
		pause_choices, cancel_choices = [], []
		item_id = list_item.getProperty('item_id')
		list_status = list_item.getProperty('status')
		status = self.get_status(item_id)
		if list_status == 'queued':
			cancel_choices.append(('Cancel Download', 'cancelled'))
		elif status == 'paused':
			pause_choices.append(('Resume Download', 'unpaused'))
			cancel_choices.append(('Cancel Download', 'cancelled'))
		else:
			pause_choices.append(('Pause Download', 'paused'))
			cancel_choices.append(('Cancel Download', 'cancelled'))
		multiple = (len(self.active_downloads or []) + len(self.active_queued_downloads or [])) > 1
		active_states = [self.get_status(name) for name in (self.active_downloads or [])]
		queued_states = [self.get_status(name) for name in (self.active_queued_downloads or [])]
		queue_held = self.get_home_property('download_pause_all') == 'true'
		paused_count = sum(1 for state in active_states + queued_states if state == 'paused')
		running_active = sum(1 for state in active_states if state != 'paused')
		pause_all = ('Pause All Downloads', 'paused_all') if running_active > 1 else None
		resume_all = ('Resume All Downloads', 'resumed_all') if multiple and (queue_held or paused_count > 1) else None
		if status == 'paused':
			bulk = (resume_all, pause_all)
		else:
			bulk = (pause_all, resume_all)
		pause_choices.extend(choice for choice in bulk if choice)
		if multiple:
			cancel_choices.append(('Cancel All Downloads', 'cancelled_all'))
		choices = pause_choices + cancel_choices + [('Full Filename', 'filename')]
		list_items = [{'line1': i[0]} for i in choices]
		kwargs = {'items': json.dumps(list_items), 'narrow_window': 'true'}
		status_choice = select_dialog([i[1] for i in choices], **kwargs)
		if status_choice == None: return
		if status_choice == 'filename': return ok_dialog(text=list_item.getProperty('name'))
		if status_choice == 'paused_all':
			self.set_home_property('download_pause_all', 'true')
			for name in list(self.active_downloads or []) + list(self.active_queued_downloads or []):
				if self.get_status(name) != 'paused':
					self.set_home_property('download_status.%s' % name, 'paused')
			self.make_active_downloads()
			return
		if status_choice == 'resumed_all':
			self.clear_home_property('download_pause_all')
			for name in self.active_downloads or []:
				if self.get_status(name) == 'paused':
					self.set_home_property('download_status.%s' % name, 'unpaused')
			for name in self.active_queued_downloads or []:
				if self.get_status(name) == 'paused':
					self.clear_home_property('download_status.%s' % name)
			self.make_active_downloads()
			return
		if status_choice == 'cancelled_all':
			if not confirm_dialog(text='Cancel all downloads?'): return
			names = list(self.active_downloads or []) + list(self.active_queued_downloads or [])
			self.clear_home_property('download_cancel_all_toasted')
			self.set_home_property('download_cancel_all', 'true')
			self.set_home_property('download_pack_aborted', 'true')
			for name in names:
				self._mark_cancelled(name)
			try:
				retired = str(int(self.get_home_property('download_queue_epoch') or '0') + 1)
			except Exception:
				retired = '1'
			self.set_home_property('download_queue_epoch', retired)
			self.set_home_property('download_cancel_all_epoch', retired)
			self.clear_home_property('active_queued_downloads')
			self.clear_home_property('active_downloads')
			self.make_active_downloads()
			self.set_home_property('download_cancel_all_toasted', 'true')
			notification('[B]CANCELLED[/B] All downloads', 2500, settle_ms=300)
			return
		if status_choice == 'cancelled' and not confirm_dialog(): return
		if status_choice == 'cancelled':
			self.set_home_property('download_pack_aborted', 'true')
			self._mark_cancelled(item_id)
			if list_status == 'queued':
				epoch, names = self._queued_state()
				self._write_queued_state(epoch, [i for i in names if i != item_id])
			else:
				try:
					active = [i for i in json.loads(self.get_home_property('active_downloads') or '[]') if i != item_id]
					if active: self.set_home_property('active_downloads', json.dumps(active))
					else: self.clear_home_property('active_downloads')
				except Exception:
					pass
			self.make_active_downloads()
			return
		if status_choice == 'unpaused':
			self.clear_home_property('download_pause_all')
		self.set_home_property('download_status.%s' % item_id, status_choice)

	def _downloads_listed(self):
		active = self.get_home_property('active_downloads') or ''
		queued = self.get_home_property('active_queued_downloads') or ''
		return active not in ('', '[]') or bool(queued)

	def monitor(self):
		while not self.closed:
			if not self._downloads_listed(): break
			self.sleep(2500)
			if self.closed or not self._downloads_listed(): break
			self.position = self.get_position(self.window_id)
			self.reset_window(self.window_id)
			self.make_active_downloads()
