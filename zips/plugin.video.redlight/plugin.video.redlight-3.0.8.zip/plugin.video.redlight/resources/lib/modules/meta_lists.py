# -*- coding: utf-8 -*-

def get_years(start_year):
	from datetime import datetime
	current_year = datetime.now().year
	return [{'name': str(year), 'id': year} for year in range(current_year, start_year - 1, -1)]

def get_decades(start_decade):
	from datetime import datetime
	current_year = datetime.now().year
	current_decade = (current_year // 10) * 10
	return [{'name': '%ss' % decade, 'id': decade} for decade in range(current_decade, start_decade - 1, -10)]

def years_movies():
	return get_years(1900)

def years_tvshows():
	return get_years(1944)

def years_anime():
	return get_years(1961)

def decades_movies():
	return get_decades(1900)

def decades_tvshows():
	return get_decades(1940)

def decades_anime():
	return get_decades(1960)

def oscar_winners():
	return (
{'results': [{'id': 1054867}, {'id': 1064213}, {'id': 872585}, {'id': 545611}, {'id': 776503}, {'id': 581734}, {'id': 496243}, {'id': 490132}, {'id': 399055}, {'id': 376867},
{'id': 314365}, {'id': 194662}, {'id': 76203}, {'id': 68734}, {'id': 74643}, {'id': 45269}, {'id': 12162}, {'id': 12405}, {'id': 6977}, {'id': 1422}],
'total_pages': 5, 'page': 1},
{'results': [{'id': 1640}, {'id': 70}, {'id': 122}, {'id': 1574}, {'id': 453}, {'id': 98}, {'id': 14}, {'id': 1934}, {'id': 597}, {'id': 409}, {'id': 197}, {'id': 13}, {'id': 424},
{'id': 33}, {'id': 274}, {'id': 581}, {'id': 403}, {'id': 380}, {'id': 746}, {'id': 792}],
'total_pages': 5, 'page': 2},
{'results': [{'id': 606}, {'id': 279}, {'id': 11050}, {'id': 783}, {'id': 9443}, {'id': 16619}, {'id': 12102}, {'id': 11778}, {'id': 703}, {'id': 1366}, {'id': 510}, {'id': 240},
{'id': 9277}, {'id': 238}, {'id': 1051}, {'id': 11202}, {'id': 3116}, {'id': 17917}, {'id': 10633}, {'id': 874}],
'total_pages': 5, 'page': 3},
{'results': [{'id': 15121}, {'id': 11113}, {'id': 5769}, {'id': 947}, {'id': 1725}, {'id': 284}, {'id': 665}, {'id': 17281}, {'id': 826}, {'id': 2897}, {'id': 15919}, {'id': 654},
{'id': 11426}, {'id': 27191}, {'id': 2769}, {'id': 705}, {'id': 25430}, {'id': 23383}, {'id': 33667}, {'id': 887}],
'total_pages': 5, 'page': 4},
{'results': [{'id': 28580}, {'id': 17661}, {'id': 27367}, {'id': 289}, {'id': 43266}, {'id': 223}, {'id': 770}, {'id': 34106}, {'id': 43278}, {'id': 43277}, {'id': 12311},
{'id': 3078}, {'id': 56164}, {'id': 33680}, {'id': 42861}, {'id': 143}, {'id': 65203}, {'id': 28966}, {'id': 631}],
'total_pages': 5, 'page': 5}
	)

def movie_certifications():
	return [
{'name': 'G', 'id': 'G'}, {'name': 'PG', 'id': 'PG'}, {'name': 'PG-13', 'id': 'PG-13'},
{'name': 'R', 'id': 'R'}, {'name': 'NC-17', 'id': 'NC-17'}, {'name': 'NR', 'id': 'NR'}
	]

def tvshow_certifications():
	return [
{'name': 'TV-Y', 'id': 'tv-y'}, {'name': 'TV-Y7', 'id': 'tv-y7'}, {'name': 'TV-G', 'id': 'tv-g'},
{'name': 'TV-PG', 'id': 'tv-pg'}, {'name': 'TV-14', 'id': 'tv-14'}, {'name': 'TV-MA', 'id': 'tv-ma'}
	]

def languages():
	return [
{'name': 'Arabic', 'id': 'ar'}, {'name': 'Bosnian', 'id': 'bs'}, {'name': 'Bulgarian', 'id': 'bg'}, {'name': 'Chinese', 'id': 'zh'}, {'name': 'Croatian', 'id': 'hr'},
{'name': 'Dutch', 'id': 'nl'}, {'name': 'English', 'id': 'en'}, {'name': 'Finnish', 'id': 'fi'}, {'name': 'French', 'id': 'fr'}, {'name': 'German', 'id': 'de'},
{'name': 'Greek', 'id': 'el'}, {'name': 'Hebrew', 'id': 'he'}, {'name': 'Hindi', 'id': 'hi'}, {'name': 'Hungarian', 'id': 'hu'}, {'name': 'Icelandic', 'id': 'is'},
{'name': 'Italian', 'id': 'it'}, {'name': 'Japanese', 'id': 'ja'}, {'name': 'Korean', 'id': 'ko'}, {'name': 'Macedonian', 'id': 'mk'}, {'name': 'Norwegian', 'id': 'no'},
{'name': 'Persian', 'id': 'fa'}, {'name': 'Polish', 'id': 'pl'}, {'name': 'Portuguese', 'id': 'pt'}, {'name': 'Punjabi', 'id': 'pa'}, {'name': 'Romanian', 'id': 'ro'},
{'name': 'Russian', 'id': 'ru'}, {'name': 'Serbian', 'id': 'sr'}, {'name': 'Slovenian', 'id': 'sl'}, {'name': 'Spanish', 'id': 'es'}, {'name': 'Swedish', 'id': 'sv'},
{'name': 'Turkish', 'id': 'tr'}, {'name': 'Ukrainian', 'id': 'uk'}, {'name': 'Vietnamese', 'id': 'vi'}
	]

def iso639_1_to_display_code(code):
	"""Convert a TMDb ISO 639-1 2-letter language code to a 3-letter uppercase display label.
	Falls back to the uppercased 2-letter code when the code is unknown."""
	_map = {
		'af': 'AFR', 'sq': 'ALB', 'am': 'AMH', 'ar': 'ARA', 'hy': 'ARM', 'az': 'AZE',
		'eu': 'BAQ', 'be': 'BEL', 'bn': 'BEN', 'bs': 'BOS', 'br': 'BRE', 'bg': 'BUL',
		'my': 'BUR', 'ca': 'CAT', 'zh': 'CHI', 'hr': 'HRV', 'cs': 'CZE', 'da': 'DAN',
		'nl': 'DUT', 'en': 'ENG', 'eo': 'EPO', 'et': 'EST', 'fi': 'FIN', 'fr': 'FRE',
		'gl': 'GLG', 'ka': 'GEO', 'de': 'GER', 'el': 'GRE', 'he': 'HEB', 'hi': 'HIN',
		'hu': 'HUN', 'is': 'ICE', 'id': 'IND', 'it': 'ITA', 'ja': 'JPN', 'kk': 'KAZ',
		'km': 'KHM', 'ko': 'KOR', 'lv': 'LAV', 'lt': 'LIT', 'lb': 'LTZ', 'mk': 'MAC',
		'ms': 'MAY', 'ml': 'MAL', 'mn': 'MON', 'no': 'NOR', 'nb': 'NOR', 'nn': 'NOR',
		'oc': 'OCI', 'fa': 'PER', 'pl': 'POL', 'pt': 'POR', 'pa': 'PAN', 'ro': 'RUM',
		'ru': 'RUS', 'sr': 'SRP', 'si': 'SIN', 'sk': 'SLO', 'sl': 'SLV', 'es': 'SPA',
		'sw': 'SWA', 'sv': 'SWE', 'tl': 'TGL', 'ta': 'TAM', 'te': 'TEL', 'th': 'THA',
		'tr': 'TUR', 'uk': 'UKR', 'ur': 'URD', 'vi': 'VIE', 'cy': 'WEL',
	}
	if not code: return ''
	return _map.get(code.lower(), code.upper())

def language_choices():
	return {
'None': 'None',              'Afrikaans': 'afr',            'Albanian': 'alb',             'Arabic': 'ara',
'Armenian': 'arm',           'Basque': 'baq',               'Bengali': 'ben',              'Bosnian': 'bos',
'Breton': 'bre',             'Bulgarian': 'bul',            'Burmese': 'bur',              'Catalan': 'cat',
'Chinese': 'chi',            'Croatian': 'hrv',             'Czech': 'cze',                'Danish': 'dan',
'Dutch': 'dut',              'English': 'eng',              'Esperanto': 'epo',            'Estonian': 'est',
'Finnish': 'fin',            'French': 'fre',               'Galician': 'glg',             'Georgian': 'geo',
'German': 'ger',             'Greek': 'ell',                'Hebrew': 'heb',               'Hindi': 'hin',
'Hungarian': 'hun',          'Icelandic': 'ice',            'Indonesian': 'ind',           'Italian': 'ita',
'Japanese': 'jpn',           'Kazakh': 'kaz',               'Khmer': 'khm',                'Korean': 'kor',
'Latvian': 'lav',            'Lithuanian': 'lit',           'Luxembourgish': 'ltz',        'Macedonian': 'mac',
'Malay': 'may',              'Malayalam': 'mal',            'Manipuri': 'mni',             'Mongolian': 'mon',
'Montenegrin': 'mne',        'Norwegian': 'nor',            'Occitan': 'oci',              'Persian': 'per',
'Polish': 'pol',             'Portuguese': 'por',           'Portuguese(Brazil)': 'pob',   'Romanian': 'rum',
'Russian': 'rus',            'Serbian': 'scc',              'Sinhalese': 'sin',            'Slovak': 'slo',
'Slovenian': 'slv',          'Spanish': 'spa',              'Swahili': 'swa',              'Swedish': 'swe',
'Syriac': 'syr',             'Tagalog': 'tgl',              'Tamil': 'tam',                'Telugu': 'tel',
'Thai': 'tha',               'Turkish': 'tur',              'Ukrainian': 'ukr',            'Urdu': 'urd',
'Vietnamese': 'vie'
	}

def regions():
	return [
{'id': 'AF', 'name': 'Afghanistan'},        {'id': 'AL', 'name': 'Albania'},          {'id': 'DZ', 'name': 'Algeria'},
{'id': 'AQ', 'name': 'Antarctica'},         {'id': 'AR', 'name': 'Argentina'},        {'id': 'AM', 'name': 'Armenia'},
{'id': 'AU', 'name': 'Australia'},          {'id': 'AT', 'name': 'Austria'},          {'id': 'BD', 'name': 'Bangladesh'},
{'id': 'BY', 'name': 'Belarus'},            {'id': 'BE', 'name': 'Belgium'},          {'id': 'BR', 'name': 'Brazil'},
{'id': 'BG', 'name': 'Bulgaria'},           {'id': 'KH', 'name': 'Cambodia'},         {'id': 'CA', 'name': 'Canada'},
{'id': 'CL', 'name': 'Chile'},              {'id': 'CN', 'name': 'China'},            {'id': 'HR', 'name': 'Croatia'},
{'id': 'CZ', 'name': 'Czech Republic'},     {'id': 'DK', 'name': 'Denmark'},          {'id': 'DE', 'name': 'Egypt'},
{'id': 'FR', 'name': 'Finland'},            {'id': 'FI', 'name': 'France'},           {'id': 'EG', 'name': 'Germany'},
{'id': 'GR', 'name': 'Greece'},             {'id': 'HK', 'name': 'Hong Kong'},        {'id': 'HU', 'name': 'Hungary'},
{'id': 'IS', 'name': 'Iceland'},            {'id': 'IN', 'name': 'India'},            {'id': 'ID', 'name': 'Indonesia'},
{'id': 'IR', 'name': 'Iran'},               {'id': 'IQ', 'name': 'Iraq'},             {'id': 'IE', 'name': 'Ireland'},
{'id': 'IL', 'name': 'Israel'},             {'id': 'IT', 'name': 'Italy'},            {'id': 'JP', 'name': 'Japan'},
{'id': 'MY', 'name': 'Malaysia'},           {'id': 'NP', 'name': 'Nepal'},            {'id': 'NL', 'name': 'Netherlands'},
{'id': 'NZ', 'name': 'New Zealand'},        {'id': 'NO', 'name': 'Norway'},           {'id': 'PK', 'name': 'Pakistan'},
{'id': 'PY', 'name': 'Paraguay'},           {'id': 'PE', 'name': 'Peru'},             {'id': 'PH', 'name': 'Philippines'},
{'id': 'PL', 'name': 'Poland'},             {'id': 'PT', 'name': 'Portugal'},         {'id': 'PR', 'name': 'Puerto Rico'},
{'id': 'RO', 'name': 'Romania'},            {'id': 'RU', 'name': 'Russia'},           {'id': 'SA', 'name': 'Saudi Arabia'},
{'id': 'RS', 'name': 'Serbia'},             {'id': 'SG', 'name': 'Singapore'},        {'id': 'SK', 'name': 'Slovakia'},
{'id': 'SI', 'name': 'Slovenia'},           {'id': 'ZA', 'name': 'South Africa'},     {'id': 'ES', 'name': 'Spain'},
{'id': 'LK', 'name': 'Sri Lanka'},          {'id': 'SE', 'name': 'Sweden'},           {'id': 'CH', 'name': 'Switzerland'},
{'id': 'TH', 'name': 'Thailand'},           {'id': 'TR', 'name': 'Turkey'},           {'id': 'UA', 'name': 'Ukraine'},
{'id': 'AE', 'name': 'UAE'},                {'id': 'GB', 'name': 'UK'},               {'id': 'US', 'name': 'USA'},
{'id': 'UY', 'name': 'Uruguay'},            {'id': 'VE', 'name': 'Venezuela'},        {'id': 'VN', 'name': 'Viet Nam'},
{'id': 'YE', 'name': 'Yemen'},              {'id': 'ZW', 'name': 'Zimbabwe'}
	]

def movie_genres():
	return [
{'name': 'Action', 'id': '28', 'icon': 'genre_action'}, {'name': 'Adventure', 'id': '12', 'icon': 'genre_adventure'}, {'name': 'Animation', 'id': '16', 'icon': 'genre_animation'},
{'name': 'Comedy', 'id': '35', 'icon': 'genre_comedy'}, {'name': 'Crime', 'id': '80', 'icon': 'genre_crime'}, {'name': 'Documentary', 'id': '99', 'icon': 'genre_documentary'},
{'name': 'Drama', 'id': '18', 'icon': 'genre_drama'}, {'name': 'Family', 'id': '10751', 'icon': 'genre_family'}, {'name': 'Fantasy', 'id': '14', 'icon': 'genre_fantasy'},
{'name': 'History', 'id': '36', 'icon': 'genre_history'}, {'name': 'Horror', 'id': '27', 'icon': 'genre_horror'}, {'name': 'Music', 'id': '10402', 'icon': 'genre_music'},
{'name': 'Mystery', 'id': '9648', 'icon': 'genre_mystery'}, {'name': 'Romance', 'id': '10749', 'icon': 'genre_romance'},
{'name': 'Science Fiction', 'id': '878', 'icon': 'genre_scifi'}, {'name': 'TV Movie', 'id': '10770', 'icon': 'genre_soap'}, {'name': 'Thriller', 'id': '53', 'icon': 'genre_thriller'},
{'name': 'War', 'id': '10752', 'icon': 'genre_war'}, {'name': 'Western', 'id': '37', 'icon': 'genre_western'}
	]

def tvshow_genres():
	return [
{'name': 'Action & Adventure', 'id': '10759', 'icon': 'genre_action'}, {'name': 'Animation', 'id': '16', 'icon': 'genre_animation'},
{'name': 'Comedy', 'id': '35', 'icon': 'genre_comedy'}, {'name': 'Crime', 'id': '80', 'icon': 'genre_crime'}, {'name': 'Documentary', 'id': '99', 'icon': 'genre_documentary'},
{'name': 'Drama', 'id': '18', 'icon': 'genre_drama'}, {'name': 'Family', 'id': '10751', 'icon': 'genre_family'}, {'name': 'Kids', 'id': '10762', 'icon': 'genre_kids'},
{'name': 'Mystery', 'id': '9648', 'icon': 'genre_mystery'}, {'name': 'News', 'id': '10763', 'icon': 'genre_news'}, {'name': 'Reality', 'id': '10764', 'icon': 'genre_reality'},
{'name': 'Sci-Fi & Fantasy', 'id': '10765', 'icon': 'genre_scifi'}, {'name': 'Soap', 'id': '10766', 'icon': 'genre_soap'}, {'name': 'Talk', 'id': '10767', 'icon': 'genre_talk'},
{'name': 'War & Politics', 'id': '10768', 'icon': 'genre_war'}, {'name': 'Western', 'id': '37', 'icon': 'genre_western'}
	]

def anime_genres():
	return [
{'name': 'Action & Adventure', 'id': '10759', 'icon': 'genre_action'}, {'name': 'Comedy', 'id': '35', 'icon': 'genre_comedy'}, {'name': 'Crime', 'id': '80', 'icon': 'genre_crime'},
{'name': 'Drama', 'id': '18', 'icon': 'genre_drama'}, {'name': 'Family', 'id': '10751', 'icon': 'genre_family'}, {'name': 'Kids', 'id': '10762', 'icon': 'genre_kids'},
{'name': 'Mystery', 'id': '9648', 'icon': 'genre_mystery'}, {'name': 'Sci-Fi & Fantasy', 'id': '10765', 'icon': 'genre_scifi'},
{'name': 'War & Politics', 'id': '10768', 'icon': 'genre_war'}, {'name': 'Western', 'id': '37', 'icon': 'genre_western'}
	]

def networks():
	return sorted([
{'id': 54, 'name': 'Disney Channel', 'logo': 'ZCgEkp6'}, {'id': 44, 'name': 'Disney XD', 'logo': 'PAJJoqQ'}, {'id': 2, 'name': 'ABC', 'logo': 'qePLxos'},
{'id': 493, 'name': 'BBC America', 'logo': 'TUHDjfl'}, {'id': 6, 'name': 'NBC', 'logo': 'yPRirQZ'}, {'id': 13, 'name': 'Nickelodeon', 'logo': 'OUVoqYc'},
{'id': 14, 'name': 'PBS', 'logo': 'r9qeDJY'}, {'id': 16, 'name': 'CBS', 'logo': '8OT8igR'}, {'id': 19, 'name': 'FOX', 'logo': '6vc0Iov'},
{'id': 21, 'name': 'The WB', 'logo': 'rzfVME6'}, {'id': 24, 'name': 'BET', 'logo': 'ZpGJ5UQ'}, {'id': 30, 'name': 'USA Network', 'logo': 'Doccw9E'},
{'id': 23, 'name': 'CBC Television', 'logo': 'unQ7WCZ'}, {'id': 88, 'name': 'FX', 'logo': 'aQc1AIZ'}, {'id': 33, 'name': 'MTV', 'logo': 'QM6DpNW'},
{'id': 34, 'name': 'Lifetime', 'logo': 'tvYbhen'}, {'id': 35, 'name': 'Nick Jr.', 'logo': 'leuCWYt'}, {'id': 41, 'name': 'TNT', 'logo': 'WnzpAGj'},
{'id': 43, 'name': 'National Geographic', 'logo': 'XCGNKVQ'}, {'id': 47, 'name': 'Comedy Central', 'logo': 'ko6XN77'}, {'id': 49, 'name': 'HBO', 'logo': 'Hyu8ZGq'},
{'id': 55, 'name': 'Spike', 'logo': 'BhXYytR'}, {'id': 67, 'name': 'Showtime', 'logo': 'SawAYkO'}, {'id': 56, 'name': 'Cartoon Network', 'logo': 'zmOLbbI'},
{'id': 65, 'name': 'History', 'logo': 'LEMgy6n'}, {'id': 84, 'name': 'TLC', 'logo': 'c24MxaB'}, {'id': 68, 'name': 'TBS', 'logo': 'RVCtt4Z'},
{'id': 71, 'name': 'The CW', 'logo': 'Q8tooeM'}, {'id': 74, 'name': 'Bravo', 'logo': 'TmEO3Tn'}, {'id': 76, 'name': 'E!', 'logo': '3Delf9f'},
{'id': 77, 'name': 'Syfy', 'logo': '9yCq37i'}, {'id': 80, 'name': 'Adult Swim', 'logo': 'jCqbRcS'}, {'id': 91, 'name': 'Animal Planet', 'logo': 'olKc4RP'},
{'id': 110, 'name': 'CTV', 'logo': 'qUlyVHz'}, {'id': 129, 'name': 'A&E', 'logo': 'xLDfHjH'}, {'id': 158, 'name': 'VH1', 'logo': 'IUtHYzA'},
{'id': 174, 'name': 'AMC', 'logo': 'ndorJxi'}, {'id': 928, 'name': 'Crackle', 'logo': '53kqZSY'}, {'id': 202, 'name': 'WGN America', 'logo': 'TL6MzgO'},
{'id': 209, 'name': 'Travel Channel', 'logo': 'mWXv7SF'}, {'id': 213, 'name': 'Netflix', 'logo': 'jI5c3bw'}, {'id': 251, 'name': 'Audience', 'logo': '5Q3mo5A'},
{'id': 270, 'name': 'SundanceTV', 'logo': 'qldG5p2'}, {'id': 318, 'name': 'Starz', 'logo': 'Z0ep2Ru'}, {'id': 359, 'name': 'Cinemax', 'logo': 'zWypFNI'},
{'id': 364, 'name': 'truTV', 'logo': 'HnB3zfc'}, {'id': 384, 'name': 'Hallmark Channel', 'logo': 'zXS64I8'}, {'id': 397, 'name': 'TV Land', 'logo': '1nIeDA5'},
{'id': 1024, 'name': 'Prime Video', 'logo': 'ru9DDlL'}, {'id': 1267, 'name': 'Freeform', 'logo': 'f9AqoHE'}, {'id': 4, 'name': 'BBC One', 'logo': 'u8x26te'},
{'id': 332, 'name': 'BBC Two', 'logo': 'SKeGH1a'}, {'id': 3, 'name': 'BBC Three', 'logo': 'SDLeLcn'}, {'id': 100, 'name': 'BBC Four', 'logo': 'PNDalgw'},
{'id': 214, 'name': 'Sky One', 'logo': 'xbgzhPU'}, {'id': 9, 'name': 'ITV1', 'logo': '5Hxp5eA'}, {'id': 26, 'name': 'Channel 4', 'logo': '6ZA9UHR'},
{'id': 99, 'name': '5', 'logo': '5ubnvOh'}, {'id': 136, 'name': 'E4', 'logo': 'frpunK8'}, {'id': 210, 'name': 'HGTV', 'logo': 'INnmgLT'},
{'id': 453, 'name': 'Hulu', 'logo': 'uSD2Cdw'}, {'id': 1436, 'name': 'YouTube Premium', 'logo': 'ZfewP1Y'}, {'id': 64, 'name': 'Discovery', 'logo': '8UrXnAB'},
{'id': 2739, 'name': 'Disney+', 'logo': 'DVrPgbM'}, {'id': 2552, 'name': 'Apple TV', 'logo': 'fAQMVNp'}, {'id': 2697, 'name': 'Acorn TV', 'logo': 'fSWB5gB'},
{'id': 1709, 'name': 'CBS All Access', 'logo': 'ZvaWMuU'}, {'id': 3186, 'name': 'HBO Max', 'logo': 'mmRMG75'}, {'id': 2243, 'name': 'DC Universe', 'logo': 'bhWIubn'},
{'id': 2076, 'name': 'Paramount Network', 'logo': 'ez3U6NV'}, {'id': 4330, 'name': 'Paramount+', 'logo': 'dmUjWmU'}, {'id': 3353, 'name': 'Peacock', 'logo': '1JXFkSM'},
{'id': 4353, 'name': 'Discovery+', 'logo': 'ukz1nOG'}, {'id': 132, 'name': 'Oxygen', 'logo': 'uFCQvbR'}, {'id': 244, 'name': 'Investigation Discovery', 'logo': '07w7BER'}
	], key=lambda k: k['name'], reverse=True)

def watch_providers_movies():
	return [
{'id': 337, 'name': 'Disney Plus', 'logo': '/5eZ872CghnHFLB1j8grszbrx0dx.png'}, {'id': 3, 'name': 'Google Play Movies', 'logo': '/aZRENwYILujqs0RVOZutTh0BVGV.png'},
{'id': 2, 'name': 'Apple TV Store', 'logo': '/qdEGArH3lKfFnAtYXMkSYk5wxuG.png'}, {'id': 309, 'name': 'Sun Nxt', 'logo': '/1T9VcLknesOZZen9ZgLfcDdm5Ys.png'},
{'id': 8, 'name': 'Netflix', 'logo': '/rK1KljqmbvO9HQa1PBFLILWah72.png'}, {'id': 9, 'name': 'Amazon Prime Video', 'logo': '/gMZdpavHmxFNnLpMHwVxfqeux2g.png'},
{'id': 10, 'name': 'Amazon Video', 'logo': '/jn6TLbtaTZntTRX9UYucHJvpQx1.png'}, {'id': 100, 'name': 'GuideDoc', 'logo': '/zlgqOma3er9QTv5r8g4nhkZCqeN.png'},
{'id': 175, 'name': 'Netflix Kids', 'logo': '/rjPaInWHH1nPgtRFF17BbHN2gu.png'}, {'id': 350, 'name': 'Apple TV', 'logo': '/9icYBfYFcwgCbky5VdGUIKJ4C5i.png'},
{'id': 15, 'name': 'Hulu', 'logo': '/44uAnmSqvA4yBOdbPWN8YgQHjWm.png'}, {'id': 257, 'name': 'fuboTV', 'logo': '/3wF8xISfVlcrc8X3jaa3uMUFGAr.png'},
{'id': 190, 'name': 'Curiosity Stream', 'logo': '/oPrhlrmvdq8QDWVXgHLAZz8B2Of.png'}, {'id': 583, 'name': 'MGM+ Amazon Channel', 'logo': '/gk7O3l9qHttE9F3hgDNnhbhlOs7.png'},
{'id': 1968, 'name': 'Crunchyroll Amazon Channel', 'logo': '/qHLLmKo7udRgiSnIASVTwP2IxfJ.png'}, {'id': 386, 'name': 'Peacock Premium', 'logo': '/a1UIdq5BrkcAxnxcUhFsNbXnxeu.png'},
{'id': 1899, 'name': 'HBO Max', 'logo': '/skypuy7SXuugIQeYg0IglmzoKaS.png'}, {'id': 2303, 'name': 'Paramount Plus Premium', 'logo': '/4N4BMd0Mm0kHAmF7RZgL5lW3cwc.png'},
{'id': 2616, 'name': 'Paramount Plus Essential', 'logo': '/uPWQPyF4nqwtfPNmGcFcenU57HG.png'}, {'id': 1825, 'name': 'HBO Max Amazon Channel', 'logo': '/64fLWeSyZ1KQZhIdvTdy4QHeWty.png'},
{'id': 538, 'name': 'Plex', 'logo': '/blAEhvx3XX8sV0fFVFk88FFjubs.png'}, {'id': 192, 'name': 'YouTube', 'logo': '/5Maob4o5w8oZnNeYpCDyVFD3M7X.png'},
{'id': 1855, 'name': 'Starz Apple TV Channel', 'logo': '/lgxDo2a3iGr617vm1rf0k5Hc8jz.png'},
{'id': 1854, 'name': 'AMC Plus Apple TV Channel ', 'logo': '/wLl5LRLVC6UOSaUlsmuzY0H9LS1.png'}, {'id': 430, 'name': 'HiDive', 'logo': '/1743zXk6Hn0afaarNtp6bXVMlsT.png'},
{'id': 1852, 'name': 'Britbox Apple TV Channel ', 'logo': '/r5LXOt96llVEmgwAQeheJuxUaMR.png'}, {'id': 444, 'name': 'Dekkoo', 'logo': '/pqiY6w53xNELS5Y16pYQYvCxgE.png'},
{'id': 582, 'name': 'Paramount+ Amazon Channel', 'logo': '/bxX0YVOCY7bI85BKRlJAAQ2EjUR.png'}, {'id': 457, 'name': 'VIX ', 'logo': '/ieJ55scAVrvboTpeJcZa3JlLIrS.png'},
{'id': 584, 'name': 'Discovery+ Amazon Channel', 'logo': '/52htht83nlt2aAobIug88TeiWvO.png'}, {'id': 528, 'name': 'AMC+ Amazon Channel', 'logo': '/tg5ufQ1GkYDCMxSSxemfeKWcvRe.png'},
{'id': 283, 'name': 'Crunchyroll', 'logo': '/uFL3c4Cq8M6WoLymlC5Y8bmGytV.png'}, {'id': 207, 'name': 'The Roku Channel', 'logo': '/b7uhrYJtAe7b1ieJGg705vTbwrX.png'},
{'id': 251, 'name': 'ALLBLK', 'logo': '/1mQtLR21JpfBgJEtBGa3Brlpu6t.png'},
{'id': 633, 'name': 'Paramount+ Roku Premium Channel', 'logo': '/tnZCMxbcKdxuVmjxefyXCaip7q3.png'}, {'id': 300, 'name': 'Pluto TV', 'logo': '/fN4czqaMQNLeF6sSSIjGbAWzvwK.png'},
{'id': 634, 'name': 'Starz Roku Premium Channel', 'logo': '/tKembbxL7cYdDvFK70xBecbN0G8.png'}, {'id': 446, 'name': 'Retrocrush', 'logo': '/pqXjcTVXpOVHF3IfWo9siRZkLXo.png'},
{'id': 635, 'name': 'AMC+ Roku Premium Channel', 'logo': '/xMyod7PSWlER7Q8FLDqVckKeyyB.png'}, {'id': 2285, 'name': 'JustWatch TV Free', 'logo': '/dMMp97ZdEkokwbdjqeM12Xk0acu.png'},
{'id': 526, 'name': 'AMC+', 'logo': '/wsCUflcmL4dCkzBUaGP8cj1cTkh.png'}, {'id': 636, 'name': 'MGM Plus Roku Premium Channel', 'logo': '/surh9i8VYeeq9186fKHnUg5Q5dg.png'},
{'id': 188, 'name': 'YouTube Premium', 'logo': '/eWHpKZihdiY617s5LipWJWvN28U.png'}, {'id': 11, 'name': 'MUBI', 'logo': '/k7iSlvgWzZuO4zU5PcBjhABMuia.png'},
{'id': 83, 'name': 'The CW', 'logo': '/6fcYLKQIjGnrswtH7WxjjoSiyy3.png'}, {'id': 191, 'name': 'Kanopy', 'logo': '/cltb8XKan9ierp23ItPmCOcVLRa.png'},
{'id': 212, 'name': 'Hoopla', 'logo': '/gtjNBzAoGgUtYzt0UKXmwG34WWL.png'}, {'id': 7, 'name': 'Fandango At Home', 'logo': '/wpOt6x0dRxTrIzuBosto4LGd7E9.png'},
{'id': 2528, 'name': 'YouTube TV', 'logo': '/48bVXEIyCLSL9pZUQ7gB9ToyWto.png'}, {'id': 43, 'name': 'Starz', 'logo': '/h25xjouKmiSmFiiqw0aDXbxGZo7.png'},
{'id': 332, 'name': 'Fandango at Home Free', 'logo': '/wpOt6x0dRxTrIzuBosto4LGd7E9.png'}, {'id': 258, 'name': 'Criterion Channel', 'logo': '/32XVilXkVbrwV96O3N5i0rtuyd6.png'},
{'id': 209, 'name': 'PBS', 'logo': '/kwKCUFjKjq1GlZeIjImBV62IypB.png'}, {'id': 123, 'name': 'FXNow', 'logo': '/a7ZF6Ng3d6KDMylLUMH1OjAeTqW.png'},
{'id': 2239, 'name': 'FlixHouse', 'logo': '/ezTsuy3T7Byi7XRbAozgJrsnbQC.png'}, {'id': 80, 'name': 'AMC', 'logo': '/4lMb5R5cpg7o2GZOxI7CgxoU9Jr.png'},
{'id': 25, 'name': 'Fandor', 'logo': '/vR0RxwoqbM0ZP10LR3uT6rpuamc.png'}, {'id': 79, 'name': 'NBC', 'logo': '/geRNAmvuPF6hOLExMHLKpt7bGBD.png'},
{'id': 34, 'name': 'MGM Plus', 'logo': '/q63Uzpu7JAs566vA2G23Lk7LcID.png'}, {'id': 211, 'name': 'Freeform', 'logo': '/n0IYtqCRKBhqnioKooWDLOS3l3r.png'},
{'id': 2383, 'name': 'Philo', 'logo': '/mfbhzQwmQKjm7bLZPF5CTeu3Ilc.png'}, {'id': 156, 'name': 'A&E', 'logo': '/uZCkdQoyMucDbIylu2jVZp7N0B.png'},
{'id': 157, 'name': 'Lifetime', 'logo': '/qZrPlzjZWFHSmvE3bQdRlFGy8iW.png'}, {'id': 99, 'name': 'Shudder', 'logo': '/58O6yqUFM6qoOiBNAddJs7xNKc.png'},
{'id': 87, 'name': 'Acorn TV', 'logo': '/3aWmgZsNAqdOt8ClxIFT4pnmHrM.png'}, {'id': 143, 'name': 'Sundance Now', 'logo': '/uSoP5JLrUjHWDFikg9EJKcm7IvQ.png'},
{'id': 151, 'name': 'BritBox', 'logo': '/eZeWGG6DDIi4Kmu1z9RfTeZtqZX.png'},
{'id': 268, 'name': 'History Vault', 'logo': '/5VGoQun874KipwsAgtc8eagtIkc.png'}, {'id': 260, 'name': 'WWE Network', 'logo': '/bbOe5U4MhSaVcKtsaqRMasUt4lw.png'},
{'id': 278, 'name': 'Pure Flix', 'logo': '/qAccuffS0YOegynkbRchQeBrw7W.png'}, {'id': 284, 'name': 'Lifetime Movie Club', 'logo': '/uIEpwbQFkFlcadP7p6DUOKRpmHp.png'}
	]

def watch_providers_tvshows():
	return [
{'id': 337, 'name': 'Disney Plus', 'logo': '/5eZ872CghnHFLB1j8grszbrx0dx.png'}, {'id': 3, 'name': 'Google Play Movies', 'logo': '/aZRENwYILujqs0RVOZutTh0BVGV.png'},
{'id': 2, 'name': 'Apple TV Store', 'logo': '/qdEGArH3lKfFnAtYXMkSYk5wxuG.png'}, {'id': 309, 'name': 'Sun Nxt', 'logo': '/1T9VcLknesOZZen9ZgLfcDdm5Ys.png'},
{'id': 8, 'name': 'Netflix', 'logo': '/rK1KljqmbvO9HQa1PBFLILWah72.png'}, {'id': 9, 'name': 'Amazon Prime Video', 'logo': '/gMZdpavHmxFNnLpMHwVxfqeux2g.png'},
{'id': 10, 'name': 'Amazon Video', 'logo': '/jn6TLbtaTZntTRX9UYucHJvpQx1.png'}, {'id': 175, 'name': 'Netflix Kids', 'logo': '/rjPaInWHH1nPgtRFF17BbHN2gu.png'},
{'id': 350, 'name': 'Apple TV', 'logo': '/9icYBfYFcwgCbky5VdGUIKJ4C5i.png'}, {'id': 15, 'name': 'Hulu', 'logo': '/44uAnmSqvA4yBOdbPWN8YgQHjWm.png'},
{'id': 257, 'name': 'fuboTV', 'logo': '/3wF8xISfVlcrc8X3jaa3uMUFGAr.png'}, {'id': 190, 'name': 'Curiosity Stream', 'logo': '/oPrhlrmvdq8QDWVXgHLAZz8B2Of.png'},
{'id': 583, 'name': 'MGM+ Amazon Channel', 'logo': '/gk7O3l9qHttE9F3hgDNnhbhlOs7.png'}, {'id': 1968, 'name': 'Crunchyroll Amazon Channel', 'logo': '/qHLLmKo7udRgiSnIASVTwP2IxfJ.png'},
{'id': 386, 'name': 'Peacock Premium', 'logo': '/a1UIdq5BrkcAxnxcUhFsNbXnxeu.png'}, {'id': 1899, 'name': 'HBO Max', 'logo': '/skypuy7SXuugIQeYg0IglmzoKaS.png'}, {'id': 2303, 'name': 'Paramount Plus Premium', 'logo': '/4N4BMd0Mm0kHAmF7RZgL5lW3cwc.png'}, {'id': 2616, 'name': 'Paramount Plus Essential', 'logo': '/uPWQPyF4nqwtfPNmGcFcenU57HG.png'}, {'id': 1825, 'name': 'HBO Max Amazon Channel', 'logo': '/64fLWeSyZ1KQZhIdvTdy4QHeWty.png'}, {'id': 192, 'name': 'YouTube', 'logo': '/5Maob4o5w8oZnNeYpCDyVFD3M7X.png'},
{'id': 1855, 'name': 'Starz Apple TV Channel', 'logo': '/lgxDo2a3iGr617vm1rf0k5Hc8jz.png'}, {'id': 191, 'name': 'Kanopy', 'logo': '/cltb8XKan9ierp23ItPmCOcVLRa.png'},
{'id': 1854, 'name': 'AMC Plus Apple TV Channel ', 'logo': '/wLl5LRLVC6UOSaUlsmuzY0H9LS1.png'}, {'id': 528, 'name': 'AMC+ Amazon Channel', 'logo': '/tg5ufQ1GkYDCMxSSxemfeKWcvRe.png'},
{'id': 1852, 'name': 'Britbox Apple TV Channel ', 'logo': '/r5LXOt96llVEmgwAQeheJuxUaMR.png'},{'id': 283, 'name': 'Crunchyroll', 'logo': '/uFL3c4Cq8M6WoLymlC5Y8bmGytV.png'},
{'id': 582, 'name': 'Paramount+ Amazon Channel', 'logo': '/bxX0YVOCY7bI85BKRlJAAQ2EjUR.png'},{'id': 207, 'name': 'The Roku Channel', 'logo': '/b7uhrYJtAe7b1ieJGg705vTbwrX.png'},
{'id': 584, 'name': 'Discovery+ Amazon Channel', 'logo': '/52htht83nlt2aAobIug88TeiWvO.png'}, {'id': 2285, 'name': 'JustWatch TV Free', 'logo': '/dMMp97ZdEkokwbdjqeM12Xk0acu.png'},
{'id': 1853, 'name': 'Paramount Plus Apple TV channel', 'logo': '/xu4LyKTwasTbta1Z0qWtZG48yZ3.png'}, {'id': 526, 'name': 'AMC+', 'logo': '/wsCUflcmL4dCkzBUaGP8cj1cTkh.png'},
{'id': 633, 'name': 'Paramount+ Roku Premium Channel', 'logo': '/tnZCMxbcKdxuVmjxefyXCaip7q3.png'}, {'id': 188, 'name': 'YouTube Premium', 'logo': '/eWHpKZihdiY617s5LipWJWvN28U.png'},
{'id': 634, 'name': 'Starz Roku Premium Channel', 'logo': '/tKembbxL7cYdDvFK70xBecbN0G8.png'}, {'id': 11, 'name': 'MUBI', 'logo': '/k7iSlvgWzZuO4zU5PcBjhABMuia.png'},
{'id': 635, 'name': 'AMC+ Roku Premium Channel', 'logo': '/xMyod7PSWlER7Q8FLDqVckKeyyB.png'}, {'id': 83, 'name': 'The CW', 'logo': '/6fcYLKQIjGnrswtH7WxjjoSiyy3.png'},
{'id': 636, 'name': 'MGM Plus Roku Premium Channel', 'logo': '/surh9i8VYeeq9186fKHnUg5Q5dg.png'},{'id': 212, 'name': 'Hoopla', 'logo': '/gtjNBzAoGgUtYzt0UKXmwG34WWL.png'},
{'id': 7, 'name': 'Fandango At Home', 'logo': '/wpOt6x0dRxTrIzuBosto4LGd7E9.png'}, {'id': 2528, 'name': 'YouTube TV', 'logo': '/48bVXEIyCLSL9pZUQ7gB9ToyWto.png'},
{'id': 43, 'name': 'Starz', 'logo': '/h25xjouKmiSmFiiqw0aDXbxGZo7.png'}, {'id': 332, 'name': 'Fandango at Home Free', 'logo': '/wpOt6x0dRxTrIzuBosto4LGd7E9.png'},
{'id': 258, 'name': 'Criterion Channel', 'logo': '/32XVilXkVbrwV96O3N5i0rtuyd6.png'}, {'id': 209, 'name': 'PBS', 'logo': '/kwKCUFjKjq1GlZeIjImBV62IypB.png'},
{'id': 123, 'name': 'FXNow', 'logo': '/a7ZF6Ng3d6KDMylLUMH1OjAeTqW.png'}, {'id': 80, 'name': 'AMC', 'logo': '/4lMb5R5cpg7o2GZOxI7CgxoU9Jr.png'},
{'id': 79, 'name': 'NBC', 'logo': '/geRNAmvuPF6hOLExMHLKpt7bGBD.png'}, {'id': 34, 'name': 'MGM Plus', 'logo': '/q63Uzpu7JAs566vA2G23Lk7LcID.png'},
{'id': 211, 'name': 'Freeform', 'logo': '/n0IYtqCRKBhqnioKooWDLOS3l3r.png'}, {'id': 2383, 'name': 'Philo', 'logo': '/mfbhzQwmQKjm7bLZPF5CTeu3Ilc.png'},
{'id': 156, 'name': 'A&E', 'logo': '/uZCkdQoyMucDbIylu2jVZp7N0B.png'}, {'id': 157, 'name': 'Lifetime', 'logo': '/qZrPlzjZWFHSmvE3bQdRlFGy8iW.png'},
{'id': 99, 'name': 'Shudder', 'logo': '/58O6yqUFM6qoOiBNAddJs7xNKc.png'}, {'id': 87, 'name': 'Acorn TV', 'logo': '/3aWmgZsNAqdOt8ClxIFT4pnmHrM.png'},
{'id': 143, 'name': 'Sundance Now', 'logo': '/uSoP5JLrUjHWDFikg9EJKcm7IvQ.png'}, {'id': 151, 'name': 'BritBox', 'logo': '/eZeWGG6DDIi4Kmu1z9RfTeZtqZX.png'},
{'id': 251, 'name': 'ALLBLK', 'logo': '/1mQtLR21JpfBgJEtBGa3Brlpu6t.png'}, {'id': 264, 'name': 'MyOutdoorTV', 'logo': '/hqO0JM1FS7SmKObKZrPOQoLWH62.png'},
{'id': 260, 'name': 'WWE Network', 'logo': '/bbOe5U4MhSaVcKtsaqRMasUt4lw.png'}, {'id': 278, 'name': 'Pure Flix', 'logo': '/qAccuffS0YOegynkbRchQeBrw7W.png'},
{'id': 293, 'name': 'PBS Kids Amazon Channel', 'logo': '/wCW3oITUn8OBRWhivavESRrYp7b.png'}, {'id': 289, 'name': 'Cinemax Amazon Channel', 'logo': '/vJBXVX2REOqNrWlwgnBuQX4pQK6.png'},
{'id': 290, 'name': 'Hallmark+ Amazon Channel', 'logo': '/yG1Q3YBp5xF2Xj6Meux51Dkg4jP.png'}, {'id': 2129, 'name': 'BYUtv', 'logo': '/nIlP6X2QcJbnXA5Tm4hrsKsniAP.png'},
{'id': 294, 'name': 'PBS Masterpiece Amazon Channel', 'logo': '/aZASQOdPFvGnXiJ015OVGVJ9vt7.png'}, {'id': 300, 'name': 'Pluto TV', 'logo': '/fN4czqaMQNLeF6sSSIjGbAWzvwK.png'},
{'id': 291, 'name': 'MZ Choice Amazon Channel', 'logo': '/6kINh90KLGRqWa9HS2oj4JI1ipO.png'}, {'id': 430, 'name': 'HiDive', 'logo': '/1743zXk6Hn0afaarNtp6bXVMlsT.png'},
{'id': 457, 'name': 'VIX ', 'logo': '/ieJ55scAVrvboTpeJcZa3JlLIrS.png'}, {'id': 446, 'name': 'Retrocrush', 'logo': '/pqXjcTVXpOVHF3IfWo9siRZkLXo.png'},
{'id': 444, 'name': 'Dekkoo', 'logo': '/pqiY6w53xNELS5Y16pYQYvCxgE.png'}, {'id': 439, 'name': 'Shout! Factory TV', 'logo': '/ezTLm8lPMse9QRKTYInPOBD2jUM.png'},
{'id': 438, 'name': 'Chai Flicks', 'logo': '/b1cu4YuZF6xRagXjCjVeZBbnSD2.png'}, {'id': 427, 'name': 'Mhz Choice', 'logo': '/lLCtT8BA42vuYn23UxuPPQDrLap.png'},
{'id': 204, 'name': 'Shudder Amazon Channel', 'logo': '/yb4PbHPVpvJ2JizOuZoJSLXsjcG.png'}, {'id': 458, 'name': 'Vice TV ', 'logo': '/sWhnA082jyBoc1tHvnTWKdTERJE.png'},
{'id': 201, 'name': 'MUBI Amazon Channel', 'logo': '/w1hl8HszsPf5aAGT0mVY0O6LYP4.png'}, {'id': 196, 'name': 'AcornTV Amazon Channel', 'logo': '/7BBOk6Av1TFqWqEhxBYyTJucGuL.png'},
{'id': 197, 'name': 'BritBox Amazon Channel', 'logo': '/dneArfNvYnCY0LQwDs6n0wVLpPh.png'}, {'id': 199, 'name': 'Fandor Amazon Channel', 'logo': '/pqV8nzIxmOKVDsDrQ5wCPYuSM5P.png'},
{'id': 202, 'name': 'Screambox Amazon Channel', 'logo': '/zRn4rBGPYDeZvTeZEBySDdqHzS8.png'}, {'id': 318, 'name': 'Adult Swim', 'logo': '/lEboSJfLzmtWaoLsms0jYBxYqka.png'},
{'id': 205, 'name': 'Sundance Now Amazon Channel', 'logo': '/2Xa0WHfPZRm4YD21CcN5hkP2kuj.png'},
{'id': 331, 'name': 'FlixFling', 'logo': '/hkw2s2Su8EyifB9EbbQP64Fj1xA.png'}, {'id': 235, 'name': 'YouTube Free', 'logo': '/gqaJWT5oFiJyVDojVLYRSFPbhQ1.png'},
{'id': 344, 'name': 'Rakuten Viki', 'logo': '/AoNsevRecTdVv4xQEf1oLRGO2yh.png'},
{'id': 365, 'name': 'Bravo TV', 'logo': '/8VIyhPVvdnmfpi4XCchb2qbbwwb.png'}, {'id': 363, 'name': 'TNT', 'logo': '/6cgMswJ1yXtJLP1uJhM476h2WTH.png'},
{'id': 366, 'name': 'Food Network', 'logo': '/f7gabf56gh4RpycLQxbzJTbwA8T.png'}, {'id': 397, 'name': 'BBC America', 'logo': '/kB58rlVFpLTxMl1L9F0OKc82ulG.png'},
{'id': 412, 'name': 'TLC', 'logo': '/sOgYdTTcfosx2QdaqGafoDg3WEV.png'}, {'id': 406, 'name': 'HGTV', 'logo': '/2KGw5gPyzRPSahcDJORMKpPPLYL.png'},
{'id': 408, 'name': 'Investigation Discovery', 'logo': '/A0AozqqtTnp2xDRxJFbtETyCgDC.png'}, {'id': 411, 'name': 'Science Channel', 'logo': '/ei7TvvGf0rTjRFtZHUZnQ5VICLZ.png'},
{'id': 399, 'name': 'Animal Planet', 'logo': '/6HyW7w4Dn1SIEl68DTfDWpKjnc1.png'}, {'id': 403, 'name': 'Discovery', 'logo': '/ais9zJI5vS3yhVQn0BvxqccFHC1.png'},
{'id': 413, 'name': 'Travel Channel', 'logo': '/69WrGxjeCzLqdEgFLJWht6zBlB5.png'}, {'id': 417, 'name': 'Here TV', 'logo': '/aFXgq7JAVVs2zdAlfqB1LlCfIUD.png'},
{'id': 422, 'name': 'VH1', 'logo': '/9Jp2fVhHCm88ZDZrabzQlVwYTK0.png'}, {'id': 263, 'name': 'DreamWorksTV Amazon Channel', 'logo': '/smBe3mXwA14goQ7g6GFxs8GWKEU.png'},
{'id': 506, 'name': 'TBS', 'logo': '/8MX4rbkjJUf2NMb2ZVwHq0IATJf.png'}, {'id': 514, 'name': 'AsianCrush', 'logo': '/oPEgKhJZjWEjCjySvwozKQyrNKi.png'},
{'id': 473, 'name': 'Revry', 'logo': '/emSd1j9jOjNzUA2iTKk8qRSvcjs.png'}, {'id': 475, 'name': 'DOCSVILLE', 'logo': '/enoyK3NBsSCTpaJJJIR5x28mWHN.png'},
{'id': 486, 'name': 'Spectrum On Demand', 'logo': '/6qPtM96UZkt3Bu4ZFPsDeHFWUZ2.png'}, {'id': 507, 'name': 'tru TV', 'logo': '/sksAwn7y5P55CNGZ2znVuwLNM8S.png'},
{'id': 508, 'name': 'DisneyNOW', 'logo': '/3Zp05yizjTStDH4AhEBPzEsf9jv.png'}, {'id': 509, 'name': 'WeTV', 'logo': '/uxRZQTVgO1ieK4Z2ipY25LwjA63.png'},
{'id': 538, 'name': 'Plex', 'logo': '/blAEhvx3XX8sV0fFVFk88FFjubs.png'}, 
{'id': 546, 'name': 'WOW Presents Plus', 'logo': '/8pME6TzkiDzMnKZioeoqqvfaNya.png'}, {'id': 551, 'name': 'Magellan TV', 'logo': '/hyo2pwkoGKt5Erpz9TfgNQbN8uq.png'},
{'id': 555, 'name': 'The Oprah Winfrey Network', 'logo': '/vreZdMXATJ69OtWp1uEn5jVDeo6.png'}, {'id': 575, 'name': 'OnDemandKorea', 'logo': '/t4tushezwJkXCposaC73oZTwF5a.png'},
{'id': 2308, 'name': 'Darkroom', 'logo': '/naf5wQA91UCj0OetKOEYZgWZLqe.png'}, {'id': 315, 'name': 'Hoichoi', 'logo': '/8dgAD4EzQWMsyudVwWCFg19998L.png'},
{'id': 581, 'name': 'iQIYI', 'logo': '/qcq4iKj21lUGZEYBZbI8jjegqZM.png'}, {'id': 613, 'name': 'Amazon Prime Video Free with Ads', 'logo': '/fuVBtr57kxnYzOILZ38xqSmBeyR.png'},
{'id': 2411, 'name': 'Eternal Family', 'logo': '/2IHcGZUPqxy4HhWWN57AGEIKcCW.png'}, {'id': 2409, 'name': 'Fawesome', 'logo': '/dNF4vWhF3TduWvOyfVxEyTqSNRl.png'},
{'id': 692, 'name': 'Cultpix', 'logo': '/hBR1NB5z52BHMqowq0TgZqMcDBv.png'},
{'id': 532, 'name': 'aha', 'logo': '/i8cMQ9Hw8oDcOO4rV6GYlO7VBDH.png'}, {'id': 1794, 'name': 'Starz Amazon Channel', 'logo': '/adymMNlhhLlJl5xccRCrsh3OehD.png'}
	]

def movie_sorts():
	return [
{'name': 'Popularity (asc)', 'id': '&sort_by=popularity.asc'}, {'name': 'Popularity (desc)', 'id': '&sort_by=popularity.desc'},
{'name': 'Release Date (asc)', 'id': '&sort_by=primary_release_date.asc'}, {'name': 'Release Date (desc)', 'id': '&sort_by=primary_release_date.desc'},
{'name': 'Total Revenue (asc)', 'id': '&sort_by=revenue.asc'}, {'name': 'Total Revenue (desc)', 'id': '&sort_by=revenue.desc'},
{'name': 'Title (asc)', 'id': '&sort_by=original_title.asc'}, {'name': 'Title (desc)', 'id': '&sort_by=original_title.desc'},
{'name': 'Rating (asc)', 'id': '&sort_by=vote_average.asc'}, {'name': 'Rating (desc)', 'id': '&sort_by=vote_average.desc'},
{'name': 'Random', 'id': '[random]'}
	]

def tvshow_sorts():
	return [
{'name': 'Popularity (asc)', 'id': '&sort_by=popularity.asc'}, {'name': 'Popularity (desc)', 'id': '&sort_by=popularity.desc'},
{'name': 'First Aired (asc)', 'id': '&sort_by=first_air_date.asc'}, {'name': 'First Aired (desc)', 'id': '&sort_by=first_air_date.desc'},
{'name': 'Rating (asc)', 'id': '&sort_by=vote_average.asc'}, {'name': 'Rating (desc)', 'id': '&sort_by=vote_average.desc'},
{'name': 'Random', 'id': '[random]'}
	]

def discover_items():
	return {
'with_year_start': {'label': 'Year Start', 'key': 'with_year_start', 'display_key': 'with_year_start_display', 'action': 'years',
'url_insert_movie': '&primary_release_date.gte=%s-01-01', 'url_insert_tvshow': '&first_air_date.gte=%s-01-01', 'name_value': ' | %s onwards', 'icon': 'calender'},
'with_year_end': {'label': 'Year End', 'key': 'with_year_end', 'display_key': 'with_year_end_display', 'action': 'years',
'url_insert_movie': '&primary_release_date.lte=%s-12-31', 'url_insert_tvshow': '&first_air_date.lte=%s-12-31', 'name_value': ' | up to %s', 'icon': 'calender'},
'with_genres': {'label': 'With Genres', 'key': 'with_genres', 'display_key': 'with_genres_display', 'action': 'genres',
'url_insert': '&with_genres=%s', 'name_value': ' | %s', 'icon': 'genres'},
'without_genres': {'label': 'Without Genres', 'key': 'without_genres', 'display_key': 'without_genres_display', 'action': 'genres',
'url_insert': '&without_genres=%s', 'name_value': ' | exclude %s', 'icon': 'genres'},
'with_network': {'label': 'Network', 'key': 'with_network', 'display_key': 'with_network_display', 'action': 'network',
'url_insert': '&with_networks=%s', 'name_value': ' | %s', 'limited': 'tvshow', 'icon': 'networks'},
'with_provider': {'label': 'Provider', 'key': 'with_provider', 'display_key': 'with_provider_display', 'action': 'provider',
'url_insert': '&with_watch_providers=%s', 'name_value': ' | %s', 'icon': 'providers'},
'with_certification': {'label': 'Certification', 'key': 'with_certification', 'display_key': 'with_certification_display', 'action': 'certifications',
'url_insert': '&certification_country=US&certification=%s', 'name_value': ' | %s', 'limited': 'movie', 'icon': 'certifications'},
'with_certification_and_lower': {'label': 'Certification (& lower)', 'key': 'with_certification_and_lower', 'display_key': 'with_certification_and_lower_display',
'action': 'certification_and_lowers', 'url_insert': '&certification_country=US&certification.lte=%s', 'name_value': ' | %s', 'limited': 'movie', 'icon': 'certifications'},
'with_language': {'label': 'Language', 'key': 'with_language', 'display_key': 'with_language_display', 'action': 'languages',
'url_insert': '&with_original_language=%s', 'name_value': ' | %s', 'icon': 'languages'},	
'with_keywords': {'label': 'With Keywords', 'key': 'with_keywords', 'display_key': 'with_keywords_display', 'action': 'keywords',
'url_insert': '&with_keywords=%s', 'name_value': ' | Keywords: %s', 'icon': 'fantasy'},
'with_rating': {'label': 'Minimum Rating', 'key': 'with_rating', 'display_key': 'with_rating_display', 'action': 'ratings',
'url_insert': '&vote_average.gte=%s', 'name_value': ' | %s+', 'icon': 'most_watched'},
'with_rating_votes': {'label': 'Minimum Number of Votes', 'key': 'with_rating_votes', 'display_key': 'with_rating_votes_display', 'action': 'votes',
'url_insert': '&vote_count.gte=%s', 'name_value': ' | %s votes', 'icon': 'most_voted'},
'with_cast': {'label': 'Include Cast', 'key': 'with_cast', 'display_key': 'with_cast_display', 'action': 'casts',
'url_insert': '&with_cast=%s', 'name_value': ' | with %s', 'limited': 'movie', 'icon': 'people'},
'with_sort': {'label': 'Sort By', 'key': 'with_sort', 'display_key': 'with_sort_display', 'action': 'sort',
'url_insert': '%s', 'name_value': ' | %s', 'icon': 'lists'},
'with_released': {'label': 'Released Only', 'key': 'with_released', 'display_key': 'with_released_display', 'action': 'released',
'url_insert_movie': '&primary_release_date.lte=%s', 'url_insert_tvshow': '&include_null_first_air_dates=false&first_air_date.lte=%s', 'name_value': ' | Released Only', 'icon': 'dvd'},
'with_adult': {'label': 'Include Adult', 'key': 'with_adult', 'display_key': 'with_adult_display', 'action': 'adult',
'url_insert': '&include_adult=%s', 'name_value': ' | Include Adult', 'limited': 'movie', 'icon': 'romance'},
	}

def color_palette():
	return [
'FFFFFFE3', 'FFFFFAE6', 'FFFEF5E6', 'FFFEF0E5', 'FFFEEBE5', 'FFFFEFEF', 'FFFFE6EA', 'FFFFE6F1', 'FFFEE6F4', 'FFFFE6FB', 'FFFEE6FE', 'FFFAE6FF', 'FFF4E6FF', 'FFF0E6FF', 'FFEAE7FC',
'FFE6E7FC', 'FFE6EBFF', 'FFE7F0FF', 'FFE7F5FF', 'FFE7FAFF', 'FFE6FFFF', 'FFE6FFFB', 'FFE7FEF4', 'FFE7FFF1', 'FFE6FFEA', 'FFE7FFE7', 'FFEBFFF3', 'FFF1FFE6', 'FFF5FFE6', 'FFFBFFE6',
'FFFFFFFF', 'FFFFFFCB', 'FFFEFACA', 'FFFFEACB', 'FFFFE0CC', 'FFFED6CC', 'FFFFCACD', 'FFFFCCD5', 'FFFFCDE0', 'FFFFCCEB', 'FFFFCBF5', 'FFFECCFD', 'FFF6CBFF', 'FFECCCFE', 'FFE0CCFF',
'FFD6CCFE', 'FFCCCCFE', 'FFCDD6FF', 'FFCAE1FF', 'FFCCEBFF', 'FFCEF4FD', 'FFCAFFFF', 'FFCCFFF6', 'FFCBFEEB', 'FFCCFFE0', 'FFCCFFD6', 'FFCDFFCC', 'FFD7FFCB', 'FFE1FFCD', 'FFEBFFCC',
'FFF5FFCB', 'FFEFEFEF', 'FFFEFFB3', 'FFFFF1B2', 'FFFFE0B2', 'FFFDD2B2', 'FFFFC2B3', 'FFFFB3B3', 'FFFFB2C2', 'FFFFB3D1', 'FFFFB3E1', 'FFFFB2F4', 'FFFFB3FE', 'FFF0B3FF', 'FFE1B2FF',
'FFD2B3FF', 'FFC1B3FE', 'FFB4B3FF', 'FFB3C1FE', 'FFB2D1FF', 'FFB3E0FF', 'FFB2F0FF', 'FFB3FFFF', 'FFB3FFF0', 'FFB4FFE0', 'FFB3FFD1', 'FFB4FEC3', 'FFB3FFB4', 'FFC2FFB2', 'FFD1FFB4',
'FFE0FFB3', 'FFF1FFB4', 'FFE0E0E0', 'FFFEFF99', 'FFFFEB9A', 'FFFED699', 'FFFFC299', 'FFFFAD98', 'FFFF9899', 'FFFF99AE', 'FFFF99C1', 'FFFE99D5', 'FFFF99EC', 'FFFF99FF', 'FFEB99FF',
'FFD699FF', 'FFC299FF', 'FFAE99FF', 'FF9A99FF', 'FF98ADFE', 'FF9AC2FF', 'FF98D6FF', 'FF99EBFF', 'FF99FFFF', 'FF99FFEA', 'FF99FFD7', 'FF9AFFC3', 'FF99FFAC', 'FF99FF99', 'FFADFF99',
'FFC2FF98', 'FFD6FF99', 'FFEAFF98', 'FFD0D0D0', 'FFFFFF80', 'FFFFE681', 'FFFFCC80', 'FFFFB381', 'FFFF9980', 'FFFE8081', 'FFFF8199', 'FFFF80B3', 'FFFF80CD', 'FFFF80E7', 'FFFC81FE',
'FFE680FF', 'FFCC7FFF', 'FFB380FF', 'FF9980FF', 'FF807FFE', 'FF8099FE', 'FF7FB3FF', 'FF80CCFE', 'FF80E6FF', 'FF7FFFFE', 'FF7FFEE0', 'FF80FFCC', 'FF80FFB2', 'FF80FF98', 'FF81FF81',
'FF99FF80', 'FFB3FF80', 'FFCCFF80', 'FFE6FF80', 'FFC0C0C0', 'FFFFFF6B', 'FFFEE066', 'FFFFC267', 'FFFFA366', 'FFFF8566', 'FFFF6766', 'FFFF6685', 'FFFF66A4', 'FFFF66C1', 'FFFF66E0',
'FFFF66FF', 'FFE166FF', 'FFC366FF', 'FFA366FF', 'FF8566FF', 'FF6665FE', 'FF6785FF', 'FF66A3FE', 'FF65C2FF', 'FF65E0FF', 'FF65FFFF', 'FF66FFE0', 'FF65FFC1', 'FF66FFA4', 'FF65FF85',
'FF66FF66', 'FF84FF66', 'FFA2FF66', 'FFC2FF66', 'FFE0FF66', 'FFAFAFAF', 'FFFFFF4D', 'FFFFDB4E', 'FFFFB84E', 'FFFF944C', 'FFFF714D', 'FFFF4D4D', 'FFFF4D6F', 'FFFE4D93', 'FFFE4DB7',
'FFFE4DDB', 'FFFF4DFF', 'FFDC4DFF', 'FFB84DFF', 'FF944EFF', 'FF704DFF', 'FF4D4CFF', 'FF4D70FE', 'FF4D94FE', 'FF4DB8FF', 'FF4DDBFF', 'FF4DFFFF', 'FF4DFFDB', 'FF4EFFB9', 'FF4EFF95',
'FF4DFE70', 'FF4CFF4C', 'FF70FF4D', 'FF94FF4D', 'FFB8FE4D', 'FFDAFF4D', 'FF8C8C8C', 'FFFFFF33', 'FFFFD634', 'FFFFAD33', 'FFFF8532', 'FFFF5C33', 'FFFF3334', 'FFFF335C', 'FFFF3287',
'FFFF33AE', 'FFFF33D6', 'FFFE33FF', 'FFD633FE', 'FFAD34FF', 'FF8534FF', 'FF5D33FF', 'FF3233FF', 'FF325CFE', 'FF3285FF', 'FF33ADFF', 'FF33D6FF', 'FF33FFFE', 'FF32FFD6', 'FF34FFAD',
'FF33FF84', 'FF32FF5C', 'FF34FF33', 'FF5CFF34', 'FF85FE33', 'FFADFE33', 'FFD5FF33', 'FF7C7C7C', 'FFFFFF19', 'FFFFD119', 'FFFFA418', 'FFFF751A', 'FFFF4719', 'FFFF1919', 'FFFF1947',
'FFFF1874', 'FFFF19A3', 'FFFF19D1', 'FFFF19FF', 'FFD019FF', 'FFA219FF', 'FF751AFE', 'FF4719FF', 'FF1819FF', 'FF1947FF', 'FF1974FF', 'FF19A3FE', 'FF18D1FF', 'FF19FFFF', 'FF19FFD1',
'FF19FFA4', 'FF18FF75', 'FF19FF47', 'FF19FF19', 'FF48FF19', 'FF76FF19', 'FFA3FE1A', 'FFD1FF19', 'FF6B6B6B', 'FFFFFF00', 'FFFFCC00', 'FFFE9900', 'FFFF6600', 'FFFF3300', 'FFFE0000',
'FFFE0032', 'FFFF0066', 'FFFF0198', 'FFFF00CC', 'FFFF00FE', 'FFCC00FF', 'FF9A00FF', 'FF6601FF', 'FF3300FF', 'FF0000FE', 'FF0033FF', 'FF0166FF', 'FF0097FE', 'FF00CCFF', 'FF00FFFF',
'FF01FFCD', 'FF00FF99', 'FF00FE67', 'FF00FF33', 'FF00FF01', 'FF33FF00', 'FF65FF00', 'FF99FE00', 'FFCCFF00', 'FF5D5D5D', 'FFE8E500', 'FFE6B800', 'FFE68B00', 'FFE65C01', 'FFE72E00',
'FFE60000', 'FFE6002E', 'FFE6005B', 'FFE80183', 'FFE600B8', 'FFE600E6', 'FFB700E6', 'FF8900E6', 'FF5C01E5', 'FF2E00E6', 'FF0000E6', 'FF012EE1', 'FF005BE7', 'FF008AE5', 'FF00B8E6',
'FF00E6E6', 'FF00E6B7', 'FF00E78B', 'FF00E65F', 'FF00E532', 'FF00E600', 'FF2FE600', 'FF5DE600', 'FF8AE501', 'FFB8E600', 'FF4F4F4F', 'FFCDCC00', 'FFCDA301', 'FFCA7B02', 'FFCC5200',
'FFCC2900', 'FFCC0001', 'FFCD0029', 'FFCE0052', 'FFCC007B', 'FFCD00A3', 'FFCB00CC', 'FFA300CB', 'FF7A01CC', 'FF5201CC', 'FF2A00D0', 'FF0000CC', 'FF0029CB', 'FF0052CC', 'FF007ACD',
'FF00A3CC', 'FF00CCCB', 'FF00CCA3', 'FF01CC7A', 'FF03CB51', 'FF00CC29', 'FF01CC00', 'FF29CC01', 'FF52CB00', 'FF7ACB00', 'FFA2CC00', 'FF434343', 'FFB4B300', 'FFB38E00', 'FFB36B00',
'FFB34700', 'FFB32501', 'FFB30101', 'FFB40025', 'FFB40047', 'FFB4006B', 'FFB5008B', 'FFB300B3', 'FF8F00B2', 'FF6B00B2', 'FF4700B4', 'FF2300B2', 'FF0000B2', 'FF0025B4', 'FF0047B3',
'FF006BB3', 'FF008EB2', 'FF00B3B2', 'FF00B38E', 'FF00B36C', 'FF00B346', 'FF00B324', 'FF00B300', 'FF24B301', 'FF47B200', 'FF6CB201', 'FF90B301', 'FF373737', 'FF999A00', 'FF987A00',
'FF995C01', 'FF9A3D00', 'FF9A1F00', 'FF990100', 'FF99001F', 'FF9A003E', 'FF99005B', 'FF9A007A', 'FF990099', 'FF7B0099', 'FF5D0099', 'FF3D0099', 'FF1F0099', 'FF000098', 'FF011F99',
'FF003D98', 'FF005C99', 'FF007A99', 'FF009999', 'FF00997A', 'FF00995B', 'FF00993E', 'FF00991F', 'FF009900', 'FF1E9900', 'FF3C9900', 'FF5C9900', 'FF7A9900', 'FF2E2E2E', 'FF7F8000',
'FF7F6601', 'FF804C00', 'FF803201', 'FF801A01', 'FF800000', 'FF800019', 'FF800033', 'FF80004B', 'FF810065', 'FF81007F', 'FF660080', 'FF4C007F', 'FF33007F', 'FF1A0080', 'FF010080',
'FF011A7F', 'FF003480', 'FF004C80', 'FF00667F', 'FF008081', 'FF008067', 'FF037F4B', 'FF008033', 'FF00801B', 'FF008001', 'FF1A8000', 'FF338000', 'FF4C8001', 'FF668100', 'FF242424',
'FF656600', 'FF675201', 'FF653D00', 'FF672900', 'FF661400', 'FF660000', 'FF660015', 'FF660028', 'FF65003C', 'FF660053', 'FF660066', 'FF550069', 'FF3D0067', 'FF290066', 'FF150067',
'FF010066', 'FF001465', 'FF012966', 'FF003D66', 'FF005267', 'FF006766', 'FF006651', 'FF00663E', 'FF01662A', 'FF006613', 'FF006600', 'FF146600', 'FF296600', 'FF3D6600', 'FF516600',
'FF181818', 'FF4B4C00', 'FF4C3E01', 'FF4D2E00', 'FF4C1F00', 'FF4D0F00', 'FF4C0000', 'FF4C000F', 'FF4B001F', 'FF4C002E', 'FF4C003E', 'FF4C004B', 'FF3D004D', 'FF2E004B', 'FF1F004C',
'FF0E004B', 'FF01004C', 'FF000E4B', 'FF001F4D', 'FF012E4D', 'FF003D4C', 'FF004C4C', 'FF004D3D', 'FF004C2E', 'FF004C1E', 'FF004C0E', 'FF004C01', 'FF0F4C00', 'FF204C01', 'FF2D4C00',
'FF3E4C01', 'FF000000'
	]

def list_display_choices(list_type):
	return {
'tmdb': {'choices': [('Title', '0'), ('Date Created (asc)', '1'), ('Date Created (desc)', '2'), ('Recently Updated (asc)', '3'), ('Recently Updated (desc)', '4'),
('Item Count (asc)', '5'), ('Item Count (desc)', '6'), ('Average Rating (asc)', '7'), ('Average Rating (desc)', '8'), ('Total Runtime (asc)', '9'),
('Total Runtime (desc)', '10'), ('Total Revenue (asc)', '11'), ('Total Revenue (desc)', '12')],
'setting': 'tmdblist'},
'personal': {'choices': [('Title', '0'), ('Author', '1'), ('Date Created (asc)', '2'), ('Date Created (desc)', '3'),
('Recently Updated (asc)', '4'), ('Recently Updated (desc)', '5'), ('Item Count (asc)', '6'), ('Item Count (desc)', '7')],
'setting': 'personal_list'}
	}[list_type]