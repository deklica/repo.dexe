# -*- coding: utf-8 -*-
"""Local air time for Next Episodes, and an earlier release date for other lists.

TMDb only stores a date. The show slot (clock + zone) comes from TVMaze and is
cached per show, with that show's episode dates. A real timestamp already on the
row (WeTrakr) is used instead of the slot. Next Episodes is not held open for
the lookup: a miss keeps today's date rule and the slot is filled in the
background for the next open.

Episode dates are only used to clear an unaired row when they are earlier than
TMDb and that day has already passed. A later date does not turn a row red.
"""
from datetime import datetime, timedelta, timezone, date
from threading import Lock, Thread
from time import sleep

_CACHE_PREFIX = 'tvmaze_air_v2_'
_SLOT_HOURS = 168
_MISS_HOURS = 24
_LOCK = Lock()
_QUEUED = set()
_WORKER = False

# Hours east of UTC: (standard, daylight, rule). rule is us, eu, au, nz, or ''.
# Used when the device has no IANA timezone data (some Android/Fire TV builds).
_ZONES = {
	'America/New_York': (-5, -4, 'us'), 'America/Detroit': (-5, -4, 'us'),
	'America/Indiana/Indianapolis': (-5, -4, 'us'), 'America/Toronto': (-5, -4, 'us'),
	'America/Chicago': (-6, -5, 'us'), 'America/Winnipeg': (-6, -5, 'us'),
	'America/Denver': (-7, -6, 'us'), 'America/Edmonton': (-7, -6, 'us'),
	'America/Phoenix': (-7, -7, ''), 'America/Los_Angeles': (-8, -7, 'us'),
	'America/Vancouver': (-8, -7, 'us'), 'America/Anchorage': (-9, -8, 'us'),
	'America/Halifax': (-4, -3, 'us'), 'America/St_Johns': (-3.5, -2.5, 'us'),
	'America/Mexico_City': (-6, -6, ''), 'America/Sao_Paulo': (-3, -3, ''),
	'America/Argentina/Buenos_Aires': (-3, -3, ''), 'America/Bogota': (-5, -5, ''),
	'Pacific/Honolulu': (-10, -10, ''),
	'Europe/London': (0, 1, 'eu'), 'Europe/Dublin': (0, 1, 'eu'),
	'Europe/Lisbon': (0, 1, 'eu'), 'Europe/Paris': (1, 2, 'eu'),
	'Europe/Berlin': (1, 2, 'eu'), 'Europe/Madrid': (1, 2, 'eu'),
	'Europe/Rome': (1, 2, 'eu'), 'Europe/Amsterdam': (1, 2, 'eu'),
	'Europe/Brussels': (1, 2, 'eu'), 'Europe/Stockholm': (1, 2, 'eu'),
	'Europe/Oslo': (1, 2, 'eu'), 'Europe/Copenhagen': (1, 2, 'eu'),
	'Europe/Warsaw': (1, 2, 'eu'), 'Europe/Prague': (1, 2, 'eu'),
	'Europe/Vienna': (1, 2, 'eu'), 'Europe/Zurich': (1, 2, 'eu'),
	'Europe/Athens': (2, 3, 'eu'), 'Europe/Helsinki': (2, 3, 'eu'),
	'Europe/Bucharest': (2, 3, 'eu'), 'Europe/Kyiv': (2, 3, 'eu'),
	'Europe/Moscow': (3, 3, ''),
	'Asia/Jerusalem': (2, 3, ''), 'Asia/Dubai': (4, 4, ''),
	'Asia/Kolkata': (5.5, 5.5, ''), 'Asia/Bangkok': (7, 7, ''),
	'Asia/Singapore': (8, 8, ''), 'Asia/Hong_Kong': (8, 8, ''),
	'Asia/Shanghai': (8, 8, ''), 'Asia/Taipei': (8, 8, ''),
	'Asia/Seoul': (9, 9, ''), 'Asia/Tokyo': (9, 9, ''),
	'Australia/Perth': (8, 8, ''), 'Australia/Adelaide': (9.5, 10.5, 'au'),
	'Australia/Brisbane': (10, 10, ''), 'Australia/Sydney': (10, 11, 'au'),
	'Australia/Melbourne': (10, 11, 'au'), 'Australia/Hobart': (10, 11, 'au'),
	'Pacific/Auckland': (12, 13, 'nz'),
	'UTC': (0, 0, ''), 'Etc/UTC': (0, 0, ''), 'GMT': (0, 0, ''),
}


def _nth_sunday(year, month, n):
	if n == -1:
		if month == 12: day = date(year + 1, 1, 1) - timedelta(days=1)
		else: day = date(year, month + 1, 1) - timedelta(days=1)
		return day - timedelta(days=(day.weekday() - 6) % 7)
	first = date(year, month, 1)
	return first + timedelta(days=((6 - first.weekday()) % 7) + 7 * (n - 1))


def _dst(rule, day):
	if rule == 'us':
		return _nth_sunday(day.year, 3, 2) <= day < _nth_sunday(day.year, 11, 1)
	if rule == 'eu':
		return _nth_sunday(day.year, 3, -1) <= day < _nth_sunday(day.year, 10, -1)
	if rule == 'au':
		return day >= _nth_sunday(day.year, 10, 1) or day < _nth_sunday(day.year, 4, 1)
	if rule == 'nz':
		return day >= _nth_sunday(day.year, 9, -1) or day < _nth_sunday(day.year, 4, 1)
	return False


def _zone_hours(zone_name, when):
	row = _ZONES.get(zone_name or '')
	if not row: return None
	standard, daylight, rule = row
	if rule and _dst(rule, when.date()): return daylight
	return standard


def _user_offset():
	try:
		from modules.settings import datetime_utc_offset
		return int(datetime_utc_offset() or 0)
	except Exception:
		return 0


def _buffer_hours():
	try:
		from modules.settings import nextep_airtime_buffer
		return nextep_airtime_buffer()
	except Exception:
		return 0


def _to_local_naive(aware):
	"""Device local wall time. UTC offset setting applies when the device clock is UTC."""
	offset = _user_offset()
	try:
		local = aware.astimezone()
		device = local.utcoffset()
		device_seconds = int(device.total_seconds()) if device is not None else 0
	except Exception:
		local = None
		device_seconds = 0
	if local is not None and not (device_seconds == 0 and offset):
		return local.replace(tzinfo=None)
	utc = aware.astimezone(timezone.utc).replace(tzinfo=None)
	return utc + timedelta(hours=offset)


def _naive_slot(air_date, hhmm):
	day = str(air_date or '')[:10]
	clock = str(hhmm or '').strip()
	if len(day) < 10 or len(clock) < 4: return None
	try:
		parts = clock.replace('.', ':').split(':')
		hour, minute = int(parts[0]), int(parts[1]) if len(parts) > 1 else 0
		if hour > 23 or minute > 59 or hour < 0 or minute < 0: return None
		return datetime(int(day[0:4]), int(day[5:7]), int(day[8:10]), hour, minute)
	except Exception:
		return None


def _slot_utc(naive, zone_name):
	"""UTC naive time for a wall clock in zone_name. None if the zone is unknown."""
	if naive is None: return None
	zone_name = str(zone_name or '').strip()
	if zone_name:
		try:
			from zoneinfo import ZoneInfo
			aware = naive.replace(tzinfo=ZoneInfo(zone_name))
			return aware.astimezone(timezone.utc).replace(tzinfo=None)
		except Exception:
			pass
	hours = _zone_hours(zone_name, naive)
	if hours is None: return None
	return naive - timedelta(hours=hours)


def _parse_iso(text):
	text = str(text or '').strip()
	if not text or 'T' not in text: return None
	if text.endswith('Z'): text = text[:-1] + '+00:00'
	if '.' in text:
		left, right = text.split('.', 1)
		sign = max(right.rfind('+'), right.rfind('-'))
		text = left + (right[sign:] if sign >= 0 else '')
	try:
		if len(text) >= 22 and text[-6] in ('+', '-') and text[-3] == ':':
			base, sign_s, hh, mm = text[:-6], text[-6], int(text[-5:-3]), int(text[-2:])
			sign = 1 if sign_s == '+' else -1
			for fmt in ('%Y-%m-%dT%H:%M:%S', '%Y-%m-%dT%H:%M'):
				try: dt = datetime.strptime(base, fmt)
				except ValueError: continue
				return dt.replace(tzinfo=timezone(timedelta(hours=sign * hh, minutes=sign * mm)))
			return None
		for fmt in ('%Y-%m-%dT%H:%M:%S', '%Y-%m-%dT%H:%M'):
			try: return datetime.strptime(text, fmt).replace(tzinfo=timezone.utc)
			except ValueError: continue
	except Exception:
		return None
	return None


def _service_local(service_air):
	aware = _parse_iso(service_air)
	if aware is None: return None
	if aware.tzinfo is None: aware = aware.replace(tzinfo=timezone.utc)
	return _to_local_naive(aware)


def _recent_air_date(air_date, now):
	naive = _naive_slot(air_date, '00:00')
	if naive is None: return False
	return -1 <= (now.date() - naive.date()).days <= 1


def _usable_imdb(value):
	value = str(value or '').strip()
	if not value.startswith('tt') or value in ('tt0000000', 'tt0'): return ''
	return value


def _usable_tvdb(value):
	value = str(value or '').strip()
	if value in ('', 'None', '0', '0000000') or not value.isdigit() or int(value) <= 0: return ''
	return value


def _cache_id(imdb, tvdb):
	imdb, tvdb = _usable_imdb(imdb), _usable_tvdb(tvdb)
	if imdb: return _CACHE_PREFIX + imdb
	if tvdb: return _CACHE_PREFIX + 'tvdb' + tvdb
	return ''


def _iso_day(value):
	value = str(value or '')[:10]
	if len(value) != 10 or value[4] != '-' or value[7] != '-': return ''
	try:
		int(value[0:4]); int(value[5:7]); int(value[8:10])
	except Exception:
		return ''
	return value


def _earlier_day(day, tmdb_day):
	"""True when day is a real date and strictly before the TMDb day (or TMDb has none)."""
	day = _iso_day(day)
	if not day: return False
	tmdb_day = _iso_day(tmdb_day)
	if not tmdb_day: return True
	return day < tmdb_day


def _episode_dates(episodes):
	if not isinstance(episodes, list): return {}
	out = {}
	for ep in episodes:
		if not isinstance(ep, dict): continue
		day = _iso_day(ep.get('airdate'))
		if not day: continue
		try: season, number = int(ep.get('season')), int(ep.get('number'))
		except Exception: continue
		out['%s:%s' % (season, number)] = day
	return out


def _store_show(imdb, tvdb, clock, zone, episodes, hours):
	key = _cache_id(imdb, tvdb)
	if not key: return
	try:
		from caches.main_cache import main_cache
		main_cache.set(key, {'time': clock or '', 'zone': zone or '', 'episodes': episodes or {}}, expiration=hours)
	except Exception:
		pass


def _show_zone(show):
	for key in ('network', 'webChannel'):
		block = show.get(key) or {}
		if not isinstance(block, dict): continue
		country = block.get('country') or {}
		if isinstance(country, dict) and country.get('timezone'):
			return str(country.get('timezone'))
	return ''


def _fetch_show(imdb, tvdb):
	import requests
	imdb, tvdb = _usable_imdb(imdb), _usable_tvdb(tvdb)
	if imdb: url = 'https://api.tvmaze.com/lookup/shows?imdb=%s' % imdb
	elif tvdb: url = 'https://api.tvmaze.com/lookup/shows?thetvdb=%s' % tvdb
	else: return
	headers = {'User-Agent': 'RedLight (Kodi; next episodes air time)'}
	try:
		resp = requests.get(url, headers=headers, timeout=8)
	except Exception:
		return
	if resp.status_code == 404:
		_store_show(imdb, tvdb, '', '', {}, _MISS_HOURS)
		return
	if resp.status_code != 200: return
	try: show = resp.json()
	except Exception: return
	if not isinstance(show, dict): return
	clock = str((show.get('schedule') or {}).get('time') or '').strip()
	if len(clock) >= 5: clock = clock[:5]
	show_id = show.get('id')
	episodes = {}
	if show_id:
		try:
			ep_resp = requests.get('https://api.tvmaze.com/shows/%s/episodes' % show_id, headers=headers, timeout=8)
		except Exception:
			return
		if ep_resp.status_code == 404:
			episodes = {}
		elif ep_resp.status_code != 200:
			return
		else:
			try: episodes = _episode_dates(ep_resp.json())
			except Exception: return
	_store_show(imdb, tvdb, clock, _show_zone(show), episodes, _SLOT_HOURS if (clock or episodes) else _MISS_HOURS)


def _worker():
	global _WORKER
	while True:
		with _LOCK:
			if not _QUEUED:
				_WORKER = False
				return
			imdb, tvdb = _QUEUED.pop()
		try: _fetch_show(imdb, tvdb)
		except Exception: pass
		sleep(0.55)


def _queue_slot(imdb, tvdb):
	global _WORKER
	key = (_usable_imdb(imdb), _usable_tvdb(tvdb))
	if not key[0] and not key[1]: return
	with _LOCK:
		_QUEUED.add(key)
		if _WORKER: return
		_WORKER = True
		Thread(target=_worker, daemon=True).start()


def _read_show(imdb, tvdb):
	"""Cached show dict, 'skip' when it cannot be looked up, None if not cached yet."""
	key = _cache_id(imdb, tvdb)
	if not key: return 'skip'
	try:
		from caches.main_cache import main_cache
		data = main_cache.get(key)
	except Exception:
		data = None
	if isinstance(data, dict) and isinstance(data.get('episodes'), dict): return data
	return None


def _cached_slot(imdb, tvdb):
	"""Dict with time/zone, 'skip' when this show cannot be looked up, None if not cached yet."""
	show = _read_show(imdb, tvdb)
	if show == 'skip' or isinstance(show, dict): return show
	_queue_slot(imdb, tvdb)
	return None


def ensure_show(imdb_id, tvdb_id):
	"""Fetch this show's slot and episode dates when a season is opened. One show."""
	show = _read_show(imdb_id, tvdb_id)
	if show == 'skip' or isinstance(show, dict): return
	try: _fetch_show(imdb_id, tvdb_id)
	except Exception: pass


def _date_passed(day, today):
	from modules.utils import adjust_premiered_date, get_datetime
	from modules.settings import date_offset
	try: ep_date = adjust_premiered_date(day, date_offset())[0]
	except Exception: return False
	if today is None: today = get_datetime()
	return bool(ep_date and ep_date <= today)


def _wetrakr_release_day(service_air):
	"""Local calendar day of a WeTrakr episode time, when WeTrakr is the watched provider."""
	if not str(service_air or '').strip(): return ''
	try:
		from modules.settings import watched_indicators
		if int(watched_indicators() or 0) != 5: return ''
	except Exception:
		return ''
	local = _service_local(service_air)
	if local is None: return ''
	return local.strftime('%Y-%m-%d')


def episode_already_out(season, episode, tmdb_date, imdb_id, tvdb_id, service_air=None, today=None, wait=False):
	"""True when an earlier TVMaze date, or WeTrakr time, has already passed.

	Does not mark an episode unaired. wait fetches this show before deciding.
	Otherwise a cache miss queues a background lookup and the TMDb date stands.
	"""
	tmdb_day = _iso_day(tmdb_date)
	candidates = []
	wetrakr_day = _wetrakr_release_day(service_air)
	if _earlier_day(wetrakr_day, tmdb_day): candidates.append(wetrakr_day)
	if wait: ensure_show(imdb_id, tvdb_id)
	show = _read_show(imdb_id, tvdb_id)
	if show is None:
		if not wait: _queue_slot(imdb_id, tvdb_id)
	elif show != 'skip':
		try: key = '%s:%s' % (int(season), int(episode))
		except Exception: key = ''
		day = _iso_day((show.get('episodes') or {}).get(key))
		if _earlier_day(day, tmdb_day): candidates.append(day)
	for day in candidates:
		if _date_passed(day, today): return True
	return False


def _slot_local(air_date, clock, zone_name):
	naive = _naive_slot(air_date, clock)
	if naive is None: return None
	utc = _slot_utc(naive, zone_name)
	if utc is None:
		return naive + timedelta(hours=_user_offset())
	return _to_local_naive(utc.replace(tzinfo=timezone.utc))


def clock_status(air_date, service_air, imdb_id, tvdb_id, now=None):
	"""'pending' before local air time, 'clear' when known to be out, 'unknown' if the slot is not cached yet."""
	now = now or datetime.now()
	release = _service_local(service_air)
	if release is None and _recent_air_date(air_date, now):
		slot = _cached_slot(imdb_id, tvdb_id)
		if slot is None: return 'unknown'
		if slot == 'skip' or not slot.get('time'): return 'clear'
		release = _slot_local(air_date, slot.get('time'), slot.get('zone') or '')
		if release is None: return 'clear'
	elif release is None:
		return 'clear'
	buffer_hours = _buffer_hours()
	if buffer_hours: release = release + timedelta(hours=buffer_hours)
	if now < release: return 'pending'
	return 'clear'


def _self_test():
	cases = (
		('2026-11-11', '21:30', 'America/New_York', datetime(2026, 11, 12, 2, 30)),
		('2026-11-01', '21:30', 'America/New_York', datetime(2026, 11, 2, 2, 30)),
		('2026-07-11', '21:30', 'America/New_York', datetime(2026, 7, 12, 1, 30)),
		('2026-03-08', '21:30', 'America/New_York', datetime(2026, 3, 9, 1, 30)),
		('2026-03-07', '21:30', 'America/New_York', datetime(2026, 3, 8, 2, 30)),
		('2026-11-11', '21:00', 'Europe/London', datetime(2026, 11, 11, 21, 0)),
		('2026-07-11', '21:00', 'Europe/London', datetime(2026, 7, 11, 20, 0)),
		('2026-03-29', '21:00', 'Europe/London', datetime(2026, 3, 29, 20, 0)),
		('2026-03-28', '21:00', 'Europe/London', datetime(2026, 3, 28, 21, 0)),
		('2026-11-11', '21:30', 'Australia/Sydney', datetime(2026, 11, 11, 10, 30)),
		('2026-06-11', '21:30', 'Australia/Sydney', datetime(2026, 6, 11, 11, 30)),
		('2026-11-11', '21:00', 'Asia/Tokyo', datetime(2026, 11, 11, 12, 0)),
	)
	for day, clock, zone, expect in cases:
		naive = _naive_slot(day, clock)
		got = _slot_utc(naive, zone)
		hours = _zone_hours(zone, naive)
		table = naive - timedelta(hours=hours)
		if got != expect: raise AssertionError('%s %s zoneinfo/table %s != %s' % (day, zone, got, expect))
		if table != expect: raise AssertionError('%s %s offset table %s != %s' % (day, zone, table, expect))
	parsed = _parse_iso('2026-11-12T02:30:00Z')
	if parsed != datetime(2026, 11, 12, 2, 30, tzinfo=timezone.utc):
		raise AssertionError('Z parse %s' % (parsed,))
	parsed = _parse_iso('2026-11-11T21:30:00.000-05:00')
	if parsed.utcoffset() != timedelta(hours=-5): raise AssertionError('offset parse %s' % (parsed,))
	if not _recent_air_date('2026-11-11', datetime(2026, 11, 11, 10, 0)): raise AssertionError('today')
	if _recent_air_date('2026-11-01', datetime(2026, 11, 11, 10, 0)): raise AssertionError('old date queued')
	if not _earlier_day('2026-10-25', '2026-11-15'): raise AssertionError('earlier release')
	if _earlier_day('2026-11-15', '2026-10-25'): raise AssertionError('later date must not release')
	if _earlier_day('2026-11-15', '2026-11-15'): raise AssertionError('same day is not earlier')
	if not _earlier_day('2026-10-25', ''): raise AssertionError('missing tmdb date')
	episodes = _episode_dates([
		{'season': 2, 'number': 7, 'airdate': '2026-10-25'},
		{'season': 2, 'number': 8, 'airdate': ''},
	])
	if episodes != {'2:7': '2026-10-25'}: raise AssertionError('episode dates %s' % (episodes,))


if __name__ == '__main__':
	_self_test()
	print('airtime ok')
