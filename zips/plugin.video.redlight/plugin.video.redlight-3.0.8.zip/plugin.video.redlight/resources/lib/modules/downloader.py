# -*- coding: utf-8 -*-
import os
import sys
import ssl
import json
import socket
from threading import Lock, Thread
from urllib.request import Request, urlopen
from urllib.parse import parse_qsl, urlparse, unquote
from modules import kodi_utils
from modules.sources import Sources, PROP_RESOLVE_CANCEL
from modules.settings import download_directory, max_concurrent_downloads, store_resolved_to_cloud
from modules.debrid import normalize_debrid_provider
from modules.source_utils import clean_title, iter_season_episode_tokens
from modules.utils import clean_file_name, safe_string, remove_accents, normalize
# logger = kodi_utils.logger

NO_DOWNLOAD_URL_MSG = 'No URL found for Download. Pick another Source'

def runner(params):
	kodi_utils.hide_busy_dialog()
	kodi_utils.clear_property('redlight.download_busy_token')
	kodi_utils.clear_property('redlight.download_cancel_all')
	kodi_utils.clear_property('redlight.download_pack_aborted')
	action = params.get('action')
	if action == 'image':
		for item in ('thumb_url', 'image_url'):
			image_params = params
			image_params['url'] = params.pop(item)
			image_params['media_type'] = item
			Downloader(image_params).run()
	elif action == 'meta.pack':
		from modules.source_utils import find_season_in_release_title
		from modules.debrid import ExternalPackSource, downloader_provider_slug
		source, meta = json.loads(params['source']), json.loads(params['meta'])
		pack_source = ExternalPackSource(source, meta)
		pack_result = pack_source.browse_packs(download=True)
		if not pack_result:
			return
		pack_choices, pack_api = pack_result
		provider = downloader_provider_slug(getattr(pack_source, 'debrid', '') or source.get('cache_provider', ''))
		pack_items = [dict(params, **{'pack_files': item, 'provider': provider}) for item in pack_choices]
		icon = {'real-debrid': 'realdebrid', 'premiumize.me': 'premiumize', 'alldebrid': 'alldebrid', 'offcloud': 'offcloud', 'torbox': 'torbox'}.get(provider, 'box_office')
		chosen_list = select_pack_item(pack_items, kodi_utils.get_icon(icon))
		if not chosen_list: return
		show_package = source.get('package') == 'show'
		image = meta.get('poster') or kodi_utils.get_icon('box_office')
		default_name = '%s (%s)' % (clean_file_name(get_title(meta)), get_year(meta))
		default_foldername = kodi_utils.kodi_dialog().input('Title', defaultt=default_name)
		single_choice = len(chosen_list) == 1
		multi_downloads = []
		for item in chosen_list:
			if show_package:
				season = find_season_in_release_title(item['pack_files']['filename'])
				if season:
					meta['season'] = season
					item['meta'] = json.dumps(meta)
			item['default_foldername'] = default_foldername
			if not single_choice:
				item['pack_batch'] = True
			item['queued_name'] = _pack_file_display_name(item['pack_files']['filename'])
			multi_downloads.append((Thread(target=Downloader(item).run), item['queued_name'], item))
		pack_cleanup = None
		if provider == 'torbox' and pack_choices and not store_resolved_to_cloud('TorBox', True):
			torrent_id = pack_choices[0].get('torrent_id')
			if torrent_id:
				def pack_cleanup():
					try: pack_api.delete_torrent(torrent_id)
					except: pass
		if single_choice:
			item['pack_batch'] = True
			kodi_utils.notification('Pack download started: %s' % toast_title(clean_file_name(get_title(meta)), get_year(meta), pack=True), 3500, image)
			thread = multi_downloads[0][0]
			thread.start()
			if pack_cleanup:
				def _cleanup():
					thread.join()
					if not _keep_pack_transfer():
						pack_cleanup()
				Thread(target=_cleanup, daemon=True).start()
		else:
			kodi_utils.notification('Pack download started: %s' % toast_title(clean_file_name(get_title(meta)), get_year(meta), pack=True), 3500, image)
			Thread(target=download_threads_manager, args=(multi_downloads, pack_cleanup), daemon=True).start()
	else: Downloader(params).run()

def _download_cancelled(name):
	return kodi_utils.get_property('redlight.download_status.%s' % name) == 'cancelled'

def _cancel_epoch(name):
	return kodi_utils.get_property('redlight.download_cancel_epoch.%s' % name) or ''

def _queue_epoch():
	try: return int(kodi_utils.get_property('redlight.download_queue_epoch') or '0')
	except: return 0

def _bump_queue_epoch():
	epoch = _queue_epoch() + 1
	kodi_utils.set_property('redlight.download_queue_epoch', str(epoch))
	return epoch

def _cancel_all_requested():
	return kodi_utils.get_property('redlight.download_cancel_all') == 'true'

def _batch_cancelled_by_cancel_all(queue_epoch):
	'''True when this pack batch was already covered by Cancel All.'''
	if queue_epoch is None:
		return False
	try:
		mark = int(kodi_utils.get_property('redlight.download_cancel_all_epoch') or '0')
		return bool(mark) and int(queue_epoch) < mark
	except (TypeError, ValueError):
		return False

def _notify_cancel_all_once():
	if kodi_utils.get_property('redlight.download_cancel_all_toasted') == 'true':
		return
	kodi_utils.set_property('redlight.download_cancel_all_toasted', 'true')
	kodi_utils.notification('[B]CANCELLED[/B] All downloads', 2500)

def _notify_cancelled(label):
	kodi_utils.notification('[B]CANCELLED[/B] %s' % (label or 'Download'), 2500)

def toast_title(title, year=None, media_type=None, season=None, episode=None, pack=False):
	'''Short media title for toasts. Release filenames are too long and keep the toast scrolling.'''
	title = (title or '').strip()
	if not pack and media_type == 'episode' and season not in (None, '') and episode not in (None, ''):
		try:
			return '%s S%02dE%02d' % (title, int(season), int(episode))
		except (TypeError, ValueError):
			pass
	if title and year not in (None, ''):
		return '%s (%s)' % (title, year)
	return title or 'Download'

def _season_episode_from_filename(filename):
	for season, episode in iter_season_episode_tokens(filename or ''):
		return season, episode
	return None, None

def _pack_filename(item):
	pack_files = item.get('pack_files') if isinstance(item, dict) else None
	if isinstance(pack_files, dict):
		filename = pack_files.get('filename') or ''
		if filename:
			return filename
	return (item.get('queued_name') if isinstance(item, dict) else '') or ''

def _toast_title_from_item(item):
	try:
		meta = json.loads(item.get('meta') or '{}')
	except Exception:
		meta = {}
	title = clean_file_name(get_title(meta)) if meta and get_title(meta) else ''
	year = get_year(meta) if meta else None
	if item.get('action') == 'meta.pack':
		season, episode = _season_episode_from_filename(_pack_filename(item))
		if season is not None and episode is not None:
			return toast_title(title, year, 'episode', season, episode)
	return toast_title(title, year, meta.get('media_type') if meta else None,
		get_season(meta) if meta else None, get_episode(meta) if meta else None,
		pack=item.get('action') == 'meta.pack')

def _pause_all_requested():
	return kodi_utils.get_property('redlight.download_pause_all') == 'true'

def _download_paused(name):
	return kodi_utils.get_property('redlight.download_status.%s' % name) == 'paused'

def _keep_pack_transfer():
	return _cancel_all_requested() or kodi_utils.get_property('redlight.download_pack_aborted') == 'true'

def _write_queued_downloads(names, epoch):
	'''Only the queue that owns this epoch may publish or clear the pending list.'''
	if _queue_epoch() != epoch:
		return
	current = kodi_utils.get_property('redlight.active_queued_downloads') or ''
	if names:
		kodi_utils.set_property('redlight.active_queued_downloads', json.dumps({'epoch': epoch, 'names': names}))
		return
	if current:
		try:
			data = json.loads(current)
			if isinstance(data, dict) and data.get('epoch') != epoch:
				return
		except Exception:
			pass
	kodi_utils.clear_property('redlight.active_queued_downloads')

def _cancelled_for_epoch(name, epoch):
	return _download_cancelled(name) and _cancel_epoch(name) == str(epoch)

def download_threads_manager(multi_downloads, pack_cleanup=None):
	limit = max_concurrent_downloads()
	epoch = _bump_queue_epoch()
	pending = list(multi_downloads)
	started_threads = []
	for thread, name, item in pending:
		item['queue_epoch'] = epoch
	_write_queued_downloads([name for _thread, name, _item in pending], epoch)
	while pending:
		if _queue_epoch() != epoch:
			if _cancel_all_requested():
				_notify_cancel_all_once()
			pending = []
			break
		if _cancel_all_requested():
			pending = []
			_write_queued_downloads([], epoch)
			_notify_cancel_all_once()
			break
		kept = []
		for thread, name, item in pending:
			if _cancelled_for_epoch(name, epoch):
				if not _cancel_all_requested() and not _batch_cancelled_by_cancel_all(epoch):
					_notify_cancelled(_toast_title_from_item(item))
				continue
			kept.append((thread, name, item))
		pending = kept
		_write_queued_downloads([name for _thread, name, _item in pending], epoch)
		if not pending:
			break
		if _pause_all_requested() or _download_paused(pending[0][1]):
			kodi_utils.sleep(2000)
			continue
		if len([thread for thread, _name, _item in started_threads if thread.is_alive()]) >= limit:
			kodi_utils.sleep(2000)
			continue
		thread, name, item = pending[0]
		if _queue_epoch() != epoch or _cancel_all_requested():
			if _cancel_all_requested():
				_notify_cancel_all_once()
			pending = []
			break
		if _cancelled_for_epoch(name, epoch):
			pending.pop(0)
			if not _cancel_all_requested() and not _batch_cancelled_by_cancel_all(epoch):
				_notify_cancelled(_toast_title_from_item(item))
			continue
		pending.pop(0)
		item['queue_epoch'] = epoch
		thread.start()
		started_threads.append((thread, name, item))
		_write_queued_downloads([name for _thread, name, _item in pending], epoch)
	_write_queued_downloads([], epoch)
	started_threads = [thread for thread, _name, _item in started_threads]
	if pack_cleanup and not _keep_pack_transfer():
		for thread in started_threads:
			try: thread.join()
			except: pass
		try: pack_cleanup()
		except: pass

def select_pack_item(pack_choices, icon):
	list_items = [{'line1': '%.2f GB | %s' % (float(item['pack_files']['size'])/1073741824, clean_file_name(item['pack_files']['filename']).upper()), 'icon': icon} \
				for item in pack_choices]
	heading = 'Choose Files to Download - %s' % clean_file_name(json.loads(pack_choices[0].get('source')).get('name'))
	kwargs = {'items': json.dumps(list_items), 'heading': heading, 'enumerate': 'true', 'multi_choice': 'true'}
	return kodi_utils.select_dialog(pack_choices, **kwargs)

def get_title(meta):
	title = meta.get('custom_title', None) or meta.get('english_title') or meta.get('original_title') or meta.get('title')	
	return title

def get_year(meta):
	return meta.get('custom_year', None) or meta.get('year')

def get_season(meta):
		season = meta.get('custom_season', None) or meta.get('season')
		return int(season) if season else None

def get_episode(meta):
		episode = meta.get('custom_episode', None) or meta.get('episode')
		return int(episode) if episode else None

def _pack_file_display_name(filename):
	if not filename:
		return ''
	base = os.path.splitext(urlparse(filename).path)[0].split('/')[-1]
	return safe_string(remove_accents(base))

def _sanitize_path_name(name):
	if not name:
		return ''
	for char in r'\/:*?"<>|':
		name = name.replace(char, '')
	return name.strip('. ')

def _video_extension(name):
	if not name:
		return ''
	ext = os.path.splitext(name)[1].lstrip('.').lower()
	if ext in kodi_utils.video_extensions():
		return ext
	return ''

def _is_read_timeout(exc):
	if isinstance(exc, socket.timeout):
		return True
	text = str(exc).lower()
	return 'timed out' in text or 'timeout' in text

def _set_read_timeout(resp, seconds):
	'''Reads should wake often enough for Cancel to stop the file and show the toast.'''
	fp = getattr(resp, 'fp', None)
	raw = getattr(fp, 'raw', None)
	for obj in (getattr(raw, '_sock', None), getattr(raw, 'sock', None), raw, fp):
		if obj is None or not hasattr(obj, 'settimeout'):
			continue
		try:
			obj.settimeout(seconds)
			return
		except Exception:
			continue

def _release_name_from_source(source_json):
	try:
		source = json.loads(source_json) if isinstance(source_json, str) else (source_json or {})
		for key in ('name', 'display_name'):
			val = (source.get(key) or '').strip()
			if val: return val
	except: pass
	return ''

_active_downloads_lock = Lock()

class Downloader:
	def __init__(self, params):
		self.params = params
		self.params_get = self.params.get

	def run(self):
		self._busy_token = None
		if self.params_get('action') != 'meta.pack':
			self._busy_token = kodi_utils.push_busy_dialog()
		self.download_prep()
		self._note_stale_cancel()
		if self._abort_requested(): return self._abort_download()
		self.get_url_and_headers()
		if self._abort_requested(): return self._abort_download()
		if self.url in (None, 'None', ''):
			if getattr(self, '_download_url_notified', False):
				return self.return_notification()
			return self.return_notification(_notification=NO_DOWNLOAD_URL_MSG)
		self.get_filename()
		self.get_extension()
		self._drop_previous_cancel()
		if self._abort_requested(): return self._abort_download()
		if not self.download_check():
			if self._abort_requested(): return self._abort_download()
			if self.media_type == 'thumb_url': return
			return self.return_notification(_ok_dialog='Failed')
		if self._abort_requested(): return self._abort_download()
		if not self.confirm_download(): return self.return_notification(_notification='Cancelled')
		self.get_download_folder()
		if not self.get_destination_folder(): return self.return_notification(_notification='Cancelled')
		if self._abort_requested(): return self._abort_download()
		self.download_runner()

	def _note_stale_cancel(self):
		'''A previous cancel of this filename must not abort a new batch.'''
		self._ignore_cancel_epochs = set()
		name = self.params_get('queued_name')
		if not name or self.queue_epoch is None:
			return
		marked = _cancel_epoch(name)
		if _download_cancelled(name) and marked and marked != str(self.queue_epoch):
			self._ignore_cancel_epochs.add(marked)

	def _cancel_targets_me(self, name):
		if not name or not _download_cancelled(name):
			return False
		marked = _cancel_epoch(name)
		if marked and marked in getattr(self, '_ignore_cancel_epochs', set()):
			return False
		if self.queue_epoch is not None and marked and marked != str(self.queue_epoch):
			return False
		# Download File has no queue epoch. A cancel left by Cancel All belongs to the old batch.
		if self.queue_epoch is None and marked and marked != str(_queue_epoch()):
			return False
		return True

	def _drop_previous_cancel(self):
		'''A new single-file download must not inherit Cancel All from the same filename.'''
		if self.queue_epoch is not None or not self.final_name:
			return
		if not _download_cancelled(self.final_name):
			return
		marked = _cancel_epoch(self.final_name)
		if marked and marked != str(_queue_epoch()):
			kodi_utils.clear_property('redlight.download_status.%s' % self.final_name)
			kodi_utils.clear_property('redlight.download_cancel_epoch.%s' % self.final_name)

	def _finish_was_cancel_all(self):
		return bool(getattr(self, 'cancelled_via_all', False) or _cancel_all_requested() or _batch_cancelled_by_cancel_all(getattr(self, 'queue_epoch', None)))

	def _abort_requested(self):
		if _cancel_all_requested():
			self.cancelled_via_all = True
			return True
		name = getattr(self, 'final_name', None) or self.params_get('queued_name')
		return bool(name) and self._cancel_targets_me(name)

	def _release_busy(self):
		token = getattr(self, '_busy_token', None)
		self._busy_token = None
		if token:
			kodi_utils.pop_busy_dialog(token)

	def _abort_download(self):
		kodi_utils.set_property('redlight.download_pack_aborted', 'true')
		self._release_busy()
		try:
			if getattr(self, 'resp', None):
				self.resp.close()
		except: pass
		self.remove_active_download()
		name = getattr(self, 'final_name', None) or self.params_get('queued_name')
		if name:
			kodi_utils.clear_property('redlight.download_status.%s' % name)
			kodi_utils.clear_property('redlight.download_cancel_epoch.%s' % name)
			kodi_utils.clear_property('redlight.%s' % name)
		if self._finish_was_cancel_all():
			_notify_cancel_all_once()
		elif name and not kodi_utils.get_visibility('Window.IsActive(fullscreenvideo)'):
			_notify_cancelled(self._cancel_toast_title())

	def _is_torbox_download(self, url=None):
		if 'torbox' in (self.action or ''):
			return True
		if self.provider in ('torbox', 'TorBox', 'Torbox', 'tb_cloud'):
			return True
		try:
			source = json.loads(self.source) if self.source else {}
			if normalize_debrid_provider(source.get('debrid') or source.get('cache_provider', '')) == 'TorBox':
				return True
		except:
			pass
		check_url = (url or self.url or '').lower()
		return 'tb-cdn' in check_url or 'torbox.app' in check_url

	def download_prep(self):
		if 'meta' in self.params:
			self.meta = json.loads(self.params_get('meta'))
			self.meta_get = self.meta.get
			self.media_type = self.meta_get('media_type')
			self.title = clean_file_name(get_title(self.meta))
			self.year = get_year(self.meta)
			self.season = get_season(self.meta)
			self.episode = get_episode(self.meta)
			self.image = self.meta_get('poster') or kodi_utils.get_icon('box_office')
			self.name = self.params_get('name')
		else:
			self.meta, self.year, self.season, self.episode = None, None, None, None
			self.media_type = self.params_get('media_type')
			self.name = self.params_get('name')
			self.title = clean_file_name(self.name or '')
			self.image = self.params_get('image')
		self.provider = self.params_get('provider')
		self.action = self.params_get('action')
		self.source = self.params_get('source')
		self._download_url_notified = False
		if self.action == 'meta.single' and self.source:
			release = _release_name_from_source(self.source)
			if release: self.name = release
		self.queue_epoch = self.params_get('queue_epoch')
		self._ignore_cancel_epochs = set()
		self.final_name = None

	def download_runner(self):
		self.final_destination = os.path.join(self.final_destination, self.final_name + self.extension)
		if self._abort_requested(): return self._abort_download()
		self.add_active_download()
		if self._abort_requested(): return self._abort_download()
		self.start_download()

	def _toast_title(self):
		return toast_title(getattr(self, 'title', None), getattr(self, 'year', None), getattr(self, 'media_type', None),
			getattr(self, 'season', None), getattr(self, 'episode', None), pack=self.action == 'meta.pack')

	def _cancel_toast_title(self):
		if self.action == 'meta.pack':
			filename = _pack_filename(self.params) or getattr(self, 'final_name', None) or ''
			season, episode = _season_episode_from_filename(filename)
			if season is not None and episode is not None:
				return toast_title(getattr(self, 'title', None), getattr(self, 'year', None), 'episode', season, episode)
		return self._toast_title()

	def get_active_downloads(self):
		return json.loads(kodi_utils.get_property('redlight.active_downloads') or '[]')

	def add_active_download(self):
		if self.action == 'image' or not self.final_name or self._abort_requested():
			return
		with _active_downloads_lock:
			active_downloads = self.get_active_downloads()
			if self.final_name not in active_downloads:
				active_downloads.append(self.final_name)
			kodi_utils.set_property('redlight.active_downloads', json.dumps(active_downloads))

	def remove_active_download(self):
		if self.action == 'image' or not getattr(self, 'final_name', None):
			return
		with _active_downloads_lock:
			active_downloads = self.get_active_downloads()
			try: active_downloads.remove(self.final_name)
			except ValueError: pass
			if active_downloads: kodi_utils.set_property('redlight.active_downloads', json.dumps(active_downloads))
			else: self.clear_active_downloads()

	def clear_active_downloads(self):
		kodi_utils.clear_property('redlight.active_downloads')

	def set_percent_property(self, percent):
		kodi_utils.set_property('redlight.%s' % self.final_name, str(percent))

	def check_status(self):
		if _cancel_all_requested():
			self.cancelled_via_all = True
			return 'cancelled'
		name = getattr(self, 'final_name', None)
		if name and self._cancel_targets_me(name):
			kodi_utils.clear_property('redlight.download_status.%s' % name)
			kodi_utils.clear_property('redlight.download_cancel_epoch.%s' % name)
			return 'cancelled'
		status = kodi_utils.get_property('redlight.download_status.%s' % self.final_name)
		if status == 'unpaused':
			kodi_utils.clear_property('redlight.download_status.%s' % self.final_name)
		elif status == 'cancelled':
			return None
		return status

	def _unrestrict_pack_file_link(self, link, provider):
		'''Turn a pack file link into a downloadable CDN URL for the given debrid.'''
		from modules.debrid import downloader_provider_slug
		provider = downloader_provider_slug(provider)
		if not link:
			return None
		if provider == 'real-debrid':
			from apis.real_debrid_api import RealDebridAPI
			return RealDebridAPI().unrestrict_link(link)
		if provider == 'premiumize.me':
			from apis.premiumize_api import PremiumizeAPI
			return PremiumizeAPI().add_headers_to_url(link)
		if provider == 'alldebrid':
			from apis.alldebrid_api import AllDebridAPI
			return AllDebridAPI().unrestrict_link(link)
		if provider == 'torbox':
			from apis.torbox_api import TorBoxAPI
			api = TorBoxAPI()
			url = api.unrestrict_link(link)
			if not url:
				self._download_url_notified = True
				self._release_busy()
				kodi_utils.notification('TorBox: Download link not ready. Wait until the torrent is finished in TorBox, then try again.', 4500)
				return None
			return api.add_headers_to_url(url)
		if provider == 'offcloud':
			return link
		return None

	def _resolve_pack_episode_url(self, source):
		'''Match current episode inside a season/show pack — no extra file picker (Download File).'''
		from modules.debrid import ExternalPackSource, normalize_debrid_provider
		from modules.source_utils import seas_ep_filter, supported_video_extensions
		if self.media_type != 'episode' or not self.season or not getattr(self, 'episode', None):
			return None
		pack_result = ExternalPackSource(source, meta=self.meta).browse_packs(download=True)
		if not pack_result:
			self._download_url_notified = True
			return None
		pack_choices, _pack_api = pack_result
		extensions = supported_video_extensions()
		season, episode = int(self.season), int(self.episode)
		for item in sorted(pack_choices, key=lambda k: (k.get('filename') or '').lower()):
			filename = (item.get('filename') or '').split('/')[-1]
			if not filename or not item.get('link'):
				continue
			if not any(filename.lower().endswith(ext) for ext in extensions):
				continue
			if seas_ep_filter(season, episode, filename):
				self.name = filename
				provider = normalize_debrid_provider(source.get('debrid') or source.get('cache_provider', ''))
				return self._unrestrict_pack_file_link(item.get('link'), provider)
		return None

	def get_url_and_headers(self):
		url = self.params_get('url')
		if url in (None, 'None', ''):
			if self.action == 'meta.single':
				try:
					source = json.loads(self.source)
					if source.get('scrape_provider', '') == 'easynews': source['url_dl'] = source['down_url']
					kodi_utils.clear_property(PROP_RESOLVE_CANCEL)
					cancelled = kodi_utils.get_property(PROP_RESOLVE_CANCEL) == 'true'
					url = Sources().resolve_sources(source, meta=self.meta)
					if url and source.get('scrape_provider') == 'aiostreams':
						from apis.aiostreams_api import resolve_download_url
						url = resolve_download_url(source, url)
					if not url and 'package' in source:
						# Magnet resolve can miss pack filenames — match episode silently, then normal confirm/title flow.
						url = self._resolve_pack_episode_url(source)
					elif not url:
						try:
							kodi_utils.logger('Red Light', 'Download resolve returned no URL (cancel_prop=%s provider=%s hash=%s)' % (
								cancelled, source.get('cache_provider') or source.get('debrid'), (source.get('hash') or '')[:12]))
						except Exception:
							pass
					if url and self._is_torbox_download(url):
						from apis.torbox_api import TorBoxAPI
						url = TorBoxAPI().add_headers_to_url(url)
				except Exception as exc:
					try: kodi_utils.logger('Red Light', 'Download resolve failed: %s' % exc)
					except Exception: pass
					url = None
			elif self.action == 'meta.pack':
				link = self.params_get('pack_files', {}).get('link')
				url = self._unrestrict_pack_file_link(link, self.provider)
		else:
			if self.action.startswith('cloud'):
				if '_direct' in self.action:
					url = self.params_get('url')
				elif 'realdebrid' in self.action:
					from indexers.real_debrid import resolve_rd
					url = resolve_rd(self.params)
				elif 'alldebrid' in self.action:
					from indexers.alldebrid import resolve_ad
					url = resolve_ad(self.params)
				elif 'premiumize' in self.action:
					from apis.premiumize_api import PremiumizeAPI
					url = PremiumizeAPI().add_headers_to_url(url)
				elif 'torbox' in self.action:
					from apis.torbox_api import TorBoxAPI
					api = TorBoxAPI()
					file_id = self.params_get('url')
					media_type = self.params_get('media_type') or 'torrent'
					if media_type == 'torrent':
						url = api.unrestrict_link(file_id)
					elif media_type == 'webdl':
						url = api.unrestrict_webdl(file_id)
					else:
						url = api.unrestrict_usenet(file_id)
					if not url:
						return self.return_notification(_notification='TorBox: Unable to resolve download link')
					url = api.add_headers_to_url(url)
				elif 'easynews' in self.action:
					from indexers.easynews import resolve_easynews
					url = resolve_easynews(self.params)
		try: headers = dict(parse_qsl(url.rsplit('|', 1)[1]))
		except: headers = dict('')
		try: url = url.split('|')[0]
		except: pass
		self.url = url
		self.headers = headers

	def get_download_folder(self):
		self.down_folder = download_directory(self.media_type)
		if self.media_type == 'thumb_url': self.down_folder = os.path.join(self.down_folder, '.thumbs')
		for level in ['../../../..', '../../..', '../..', '..']:
			try: kodi_utils.make_directory(os.path.abspath(os.path.join(self.down_folder, level)))
			except: pass

	def get_destination_folder(self):
		if self.action == 'image':
			self.final_destination = self.down_folder
		elif self.action in ('meta.single', 'meta.pack'):
			default_name = '%s (%s)' % (self.title, self.year)
			if self.action == 'meta.single': folder_rootname = kodi_utils.kodi_dialog().input('Title', defaultt=default_name)
			else: folder_rootname = self.params_get('default_foldername', default_name)
			if not folder_rootname: return False
			if self.media_type == 'episode':
				inter = os.path.join(self.down_folder, folder_rootname)
				kodi_utils.make_directory(inter)
				self.final_destination = os.path.join(inter, 'Season %02d' %  int(self.season))
			else: self.final_destination = os.path.join(self.down_folder, folder_rootname)
		else: self.final_destination = self.down_folder
		kodi_utils.make_directory(self.final_destination)
		return True

	def get_filename(self):
		if self.final_name: final_name = self.final_name
		elif self.action == 'meta.pack':
			final_name = self.params_get('queued_name') or _pack_file_display_name(self.params_get('pack_files')['filename'])
		elif self.action == 'image':
			final_name = self.title
		else:
			name_url = unquote(self.url)
			file_name = clean_title(name_url.split('/')[-1])
			if self.action == 'meta.single':
				release = _release_name_from_source(self.source)
				if release:
					base = os.path.splitext(release)[0] or release
					final_name = _sanitize_path_name(base) or _sanitize_path_name(release)
				elif clean_title(self.title).lower() in file_name.lower():
					final_name = os.path.splitext(urlparse(name_url).path)[0].split('/')[-1]
				else:
					name_ref = (self.name or self.title or '').strip()
					if name_ref:
						base = os.path.splitext(name_ref)[0] or name_ref
						final_name = _sanitize_path_name(base) or _sanitize_path_name(name_ref)
					else:
						final_name = os.path.splitext(urlparse(name_url).path)[0].split('/')[-1]
			elif clean_title(self.title).lower() in file_name.lower():
				final_name = os.path.splitext(urlparse(name_url).path)[0].split('/')[-1]
			else:
				name_ref = (self.name or self.title or '').strip()
				if name_ref:
					base = os.path.splitext(name_ref)[0] or name_ref
					final_name = _sanitize_path_name(base) or _sanitize_path_name(name_ref)
				else:
					final_name = os.path.splitext(urlparse(name_url).path)[0].split('/')[-1]
			if not final_name:
				final_name = os.path.splitext(urlparse(name_url).path)[0].split('/')[-1] or 'download'
		self.final_name = safe_string(remove_accents(final_name))

	def get_extension(self):
		if self.action == 'archive':
			ext = 'zip'
		elif self.action == 'image':
			ext = os.path.splitext(urlparse(self.url).path)[1][1:]
			if not ext in kodi_utils.image_extensions(): ext = 'jpg'
		else:
			ext = _video_extension(self.name or self.title or '')
			if not ext:
				ext = os.path.splitext(urlparse(self.url).path)[1][1:]
			if not ext in kodi_utils.video_extensions(): ext = 'mp4'
		ext = '.%s' % ext
		self.extension = ext

	def download_check(self):
		self.content_unknown = False
		self.resp = self.get_response()
		if not self.resp:
			self._release_busy()
			return False
		try: self.content = int(self.resp.headers.get('Content-Length') or 0)
		except: self.content = 0
		try: self.resumable = 'bytes' in self.resp.headers.get('Accept-Ranges', '').lower()
		except: self.resumable = False
		self.size = 1024 * 1024
		if self.content < 1:
			self.content_unknown = True
			self.mb = 0
			self._release_busy()
			return True
		self.mb = self.content / (1024 * 1024)
		if self.content < self.size: self.size = self.content
		self._release_busy()
		return True

	def start_download(self):
		if self.action == 'meta.single':
			kodi_utils.notification('Download started: %s' % self._toast_title(), 3000, self.image)
		if self._abort_requested(): return self.finish_download('cancelled')
		monitor_progress = self.action != 'image'
		total, errors, count, resume, sleep_time  = 0, 0, 0, 0, 0
		f = kodi_utils.open_file(self.final_destination, 'w')
		chunk  = None
		chunks = []
		while True:
			downloaded = total
			for c in chunks: downloaded += len(c)
			if self.content_unknown:
				percent = min(99, downloaded // (50 * 1024 * 1024)) if downloaded else 0
			else:
				percent = min(round(float(downloaded) * 100 / self.content), 100)
			if monitor_progress:
				status = self.check_status()
				if status == 'paused':
					while status == 'paused':
						status = self.check_status()
						kodi_utils.sleep(1000)
				if status == 'cancelled': return self.finish_download(status)
				if percent % 5 == 0: self.set_percent_property(percent)
			chunk = None
			error = False
			try:        
				chunk  = self.resp.read(self.size)
				if not chunk:
					if not self.content_unknown and percent < 99:
						error = True
					else:
						while len(chunks) > 0:
							c = chunks.pop(0)
							f.write(c)
							del c
						f.close()
						return self.finish_download('success')
			except Exception as e:
				if self._abort_requested():
					return self.finish_download('cancelled')
				if _is_read_timeout(e):
					self._read_timeouts = getattr(self, '_read_timeouts', 0) + 1
					if self._read_timeouts < 6:
						continue
					self._read_timeouts = 0
				error = True
				sleep_time = 10
				errno = 0
				if hasattr(e, 'errno'):
					errno = e.errno
				if errno == 10035: # 'A non-blocking socket operation could not be completed immediately'
					pass
				if errno == 10054: #'An existing connection was forcibly closed by the remote host'
					errors = 10 #force resume
					sleep_time = 30
				if errno == 11001: # 'getaddrinfo failed'
					errors = 10 #force resume
					sleep_time = 30
			if chunk:
				errors = 0
				self._read_timeouts = 0
				chunks.append(chunk)
				if len(chunks) > 5:
					c = chunks.pop(0)
					f.write(c)
					total += len(c)
					del c
			if error:
				errors += 1
				count  += 1
				waited = 0
				while waited < sleep_time:
					if self._abort_requested():
						return self.finish_download('cancelled')
					kodi_utils.sleep(1000)
					waited += 1
			if (self.resumable and errors > 0) or errors >= 10:
				if (not self.resumable and resume >= 50) or resume >= 500:
					return self.finish_download('failed')
				resume += 1
				errors  = 0
				if self.resumable:
					chunks  = []
					self.resp = self.get_response(total)
				else: pass

	def get_response(self, size=0):
		try:
			headers = dict(self.headers or {})
			headers.setdefault('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36')
			if self._is_torbox_download():
				headers.setdefault('Referer', 'https://torbox.app/')
			if size > 0:
				size = int(size)
				headers['Range'] = 'bytes=%d-' % size
			req = Request(self.url, headers=headers)
			timeout = 20 if self._is_torbox_download() else 15
			resp = urlopen(req, context=ssl.create_default_context(), timeout=timeout)
			_set_read_timeout(resp, 5)
			return resp
		except: return None

	def finish_download(self, status):
		self._release_busy()
		if self.action == 'image':
			if self.media_type == 'image_url': return kodi_utils.notification(status.upper(), 2500, self.final_destination)
			else: return
		if status == 'cancelled':
			name = getattr(self, 'final_name', None)
			if name:
				kodi_utils.clear_property('redlight.download_status.%s' % name)
				kodi_utils.clear_property('redlight.download_cancel_epoch.%s' % name)
		if status == 'cancelled' and self._finish_was_cancel_all():
			_notify_cancel_all_once()
		elif status == 'cancelled':
			if not kodi_utils.get_visibility('Window.IsActive(fullscreenvideo)'):
				_notify_cancelled(self._cancel_toast_title())
		elif not kodi_utils.get_visibility('Window.IsActive(fullscreenvideo)'):
			kodi_utils.notification('[B]%s[/B] %s' % (status.upper(), self._toast_title()), 2500, self.image)
		try:
			if getattr(self, 'resp', None):
				self.resp.close()
		except: pass
		self.remove_active_download()

	def confirm_download(self):
		if self.action in ('image', 'meta.pack'):
			return True
		if getattr(self, 'content_unknown', False):
			text = 'File size could not be determined from the server.[CR]Continue with download?'
		else:
			text = 'Complete file is [B]%dMB[/B][CR]Continue with download?' % self.mb
		return kodi_utils.confirm_dialog(heading=self.final_name, text=text)

	def return_notification(self, _notification=None, _ok_dialog=None):
		self._release_busy()
		if _notification: kodi_utils.notification(_notification, 2500, settle_ms=400)
		elif _ok_dialog: kodi_utils.ok_dialog(text=_ok_dialog)
		else: return

def viewer(params):
	def _process():
		for info in results:
			try:
				path = info[0]
				url = os.path.join(folder_path, path)
				listitem = kodi_utils.make_listitem()
				listitem.setLabel(clean_file_name(normalize(path)))
				listitem.setArt({'fanart': fanart})
				info_tag = listitem.getVideoInfoTag()
				info_tag.setPlot(' ')
				yield (url, listitem, info[1])
			except: pass
	handle = int(sys.argv[1])
	fanart = kodi_utils.get_addon_fanart()
	folder_path = download_directory(params['folder_type'])
	try: kodi_utils.make_directories(folder_path)
	except: pass
	try: dirs, files = kodi_utils.list_dirs(folder_path)
	except: dirs, files = [], []
	results = [(i, True) for i in dirs] + [(i, False) for i in files]
	item_list = list(_process())
	kodi_utils.add_items(handle, item_list)
	kodi_utils.set_sort_method(handle, 'files')
	kodi_utils.set_content(handle, kodi_utils.MENU_FOLDER_CONTENT)
	kodi_utils.set_category(handle, params.get('name'))
	kodi_utils.end_directory(handle)
	kodi_utils.set_view_mode('view.main', kodi_utils.MENU_FOLDER_CONTENT, False)

def manager(foo=None):
	from windows.base_window import open_window
	kwargs = {}
	return open_window(('windows.downloads_manager', 'DownloadsManager'), 'downloads_manager.xml', **kwargs)
