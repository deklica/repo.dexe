# -*- coding: utf-8 -*-
"""Anime season lists for shows whose TMDb seasons do not match the cours.

ani.zip supplies the episode order. AniList walks later parts that share one
TMDb show (Ascendance of a Bookworm). Watched and scrobble stay on the TMDb
episode the row points back to. No ani.zip entry falls back to a TMDb episode
group named Seasons, then the caller keeps today's list.
"""
import requests
from caches.main_cache import main_cache
from modules import metadata
from modules.kodi_utils import logger

_ANILIST = 'https://graphql.anilist.co'
_ANIZIP = 'https://api.ani.zip/mappings'
_HEADERS = {'User-Agent': 'RedLight', 'Accept': 'application/json'}
_TV_FORMATS = ('TV', 'TV_SHORT', 'ONA', 'OVA')
_SEARCH = '''
query ($search: String) {
  Page(page: 1, perPage: 8) {
    media(search: $search, type: ANIME, format_in: [TV, TV_SHORT, ONA, OVA]) {
      id
      idMal
      title { romaji english }
    }
  }
}
'''
_MEDIA = '''
query ($id: Int) {
  Media(id: $id) {
    id
    idMal
    format
    title { romaji english }
    relations { edges { relationType node { id format } } }
  }
}
'''


def for_show(meta):
	"""Cached map for an anime show, or None when this show stays on TMDb seasons."""
	if not meta or not metadata.is_anime_check(meta):
		return None
	tmdb_id = str(meta.get('tmdb_id') or '')
	if not tmdb_id:
		return None
	key = 'anime_map_%s' % tmdb_id
	cached = main_cache.get(key)
	if cached is not None:
		return cached or None
	try:
		built = _build(meta)
	except Exception as exc:
		logger('Red Light', 'Anime map %s failed: %s' % (tmdb_id, exc))
		return None
	if not built:
		main_cache.set(key, {}, expiration=12)
		return None
	if built.get('source') == 'anizip' and meta.get('status') in ('Ended', 'Canceled'):
		hours = 168
	elif built.get('source') == 'anizip':
		hours = 24
	else:
		hours = 12
	main_cache.set(key, built, expiration=hours)
	logger('Red Light', 'Anime map %s: %s season(s) via %s' % (tmdb_id, len(built.get('parts') or []), built.get('source')))
	return built


def for_id(tmdb_id):
	if not tmdb_id:
		return None
	from modules.settings import tmdb_api_key, mpaa_region
	from modules.utils import get_datetime
	meta = metadata.tvshow_meta('tmdb_id', tmdb_id, tmdb_api_key(), mpaa_region(), get_datetime())
	return for_show(meta)


def row_for_meta(meta, season, episode):
	show = for_show(meta)
	if not show:
		return {}
	return _row_by_tmdb(show, season, episode) or {}


def row_for_playback(tmdb_id, season, episode):
	"""Map row for the TMDb episode a play URL names. Empty when this play stays on TMDb numbers."""
	try:
		show = for_id(tmdb_id)
	except Exception:
		return {}
	if not show:
		return {}
	return _row_by_tmdb(show, season, episode) or {}


def season_items(show, season_data=None):
	"""Season rows for build_season_list, or None when the show has no map."""
	if not show or not show.get('parts'):
		return None
	tmdb_posters = {}
	for item in season_data or []:
		try:
			num = int(item.get('season_number'))
		except (TypeError, ValueError):
			continue
		if num > 0 and item.get('poster_path'):
			tmdb_posters[num] = item['poster_path']
	items = []
	for part in show['parts']:
		episodes = part.get('episodes') or []
		dates = sorted(ep.get('premiered') for ep in episodes if ep.get('premiered'))
		tmdb_season = None
		for ep in episodes:
			try:
				tmdb_season = int(ep.get('tmdb_season'))
			except (TypeError, ValueError):
				continue
			if tmdb_season:
				break
		items.append({
			'name': part.get('name') or 'Season %s' % part.get('display_season'),
			'overview': part.get('overview') or '',
			'poster_path': tmdb_posters.get(tmdb_season),
			'air_date': dates[0] if dates else '',
			'season_number': part.get('display_season'),
			'episode_count': len(episodes),
			'anime_episodes': episodes,
			'anime_poster': part.get('poster') or '',
		})
	return items


def episode_items(show, season):
	"""Episode rows for one display season, or every season when season is None.

	None means this display season is not on the map (caller keeps the TMDb list).
	"""
	if not show or not show.get('parts'):
		return None
	if season is not None:
		try:
			season = int(season)
		except (TypeError, ValueError):
			return None
		if not any(int(part.get('display_season') or 0) == season for part in show['parts']):
			return None
	rows = []
	for part in show['parts']:
		if season is not None and int(part.get('display_season') or 0) != season:
			continue
		for ep in part.get('episodes') or []:
			rows.append(_list_episode(ep))
	rows.sort(key=lambda item: (item.get('season') or 0, item.get('episode') or 0))
	return rows


def next_tmdb(meta, season, episode, watched_info, nextep_content):
	"""(tmdb_season, tmdb_episode) of the next anime episode, or None to keep TMDb order.

	(None, None) means the map handled this show and there is no next episode.
	"""
	show = for_show(meta)
	if not show:
		return None
	flat = _flat(show)
	index = _tmdb_index(flat, season, episode)
	if index is None:
		return None
	from modules.watched_status import get_watched_status_episode
	for row in flat[index + 1:]:
		pair = _tmdb_pair(row)
		if not pair:
			continue
		if nextep_content == 0 or not get_watched_status_episode(watched_info, pair):
			return pair
	return (None, None)


def previous_tmdb_for_id(tmdb_id, season, episode):
	"""Previous episode's TMDb pair, () when this is the first, or None when no map applies."""
	try:
		if not metadata.is_anime_check(tmdb_id=tmdb_id):
			return None
		show = for_id(tmdb_id)
	except Exception:
		return None
	if not show:
		return None
	flat = _flat(show)
	index = _tmdb_index(flat, season, episode)
	if index is None:
		return None
	if index <= 0:
		return ()
	return _tmdb_pair(flat[index - 1]) or ()


def watched_tally(episodes, watched_rows, current_date, adjust_hours):
	"""(aired count, watched count) for one anime season, using TMDb pairs."""
	from modules.utils import adjust_premiered_date
	watched_set = set()
	for row in watched_rows or []:
		try:
			watched_set.add((int(row[0]), int(row[1])))
		except (TypeError, ValueError, IndexError):
			continue
	aired, watched = 0, 0
	for ep in episodes or []:
		premiered = ep.get('premiered') or ''
		if premiered:
			try:
				episode_date, _premiered = adjust_premiered_date(premiered, adjust_hours)
			except Exception:
				episode_date = None
			if episode_date and current_date < episode_date:
				continue
		aired += 1
		pair = _tmdb_pair(ep)
		if pair and pair in watched_set:
			watched += 1
	return aired, watched


def _build(meta):
	tmdb_id = str(meta.get('tmdb_id') or '')
	parts, source = [], ''
	try:
		parts = _anizip_parts(meta, tmdb_id)
		source = 'anizip'
	except Exception as exc:
		logger('Red Light', 'Anime map ani.zip %s: %s' % (tmdb_id, exc))
		parts = []
	if not parts:
		try:
			parts = _group_parts(tmdb_id)
			source = 'episode_group'
		except Exception as exc:
			logger('Red Light', 'Anime map episode group %s: %s' % (tmdb_id, exc))
			parts = []
	if not parts:
		return {}
	_bind_tmdb(parts, meta)
	_stamp(parts)
	return {'tmdb_id': tmdb_id, 'source': source, 'parts': parts}


def _anizip_parts(meta, tmdb_id):
	anchor = _find_anchor(meta, tmdb_id)
	if not anchor:
		return []
	chain = _walk(anchor[0], tmdb_id)
	if not chain:
		return []
	if len(chain) == 1:
		return _parts_from_one(chain[0])
	parts = []
	for index, (media, mapping) in enumerate(chain, 1):
		episodes = _rows_from_mapping(mapping, index, cour_episode=True)
		if not episodes:
			continue
		parts.append(_part(index, _media_title(media), mapping, episodes))
	return parts


def _parts_from_one(item):
	media, mapping = item
	grouped = {}
	for ep in _raw_episodes(mapping):
		season_number = _int(ep.get('seasonNumber'), 1) or 1
		grouped.setdefault(season_number, []).append(ep)
	kitsu_id = (mapping.get('mappings') or {}).get('kitsu_id')
	parts = []
	for season_number in sorted(grouped):
		episodes = [_row_from_anizip(ep, season_number, kitsu_id, cour_episode=False) for ep in grouped[season_number]]
		episodes = [ep for ep in episodes if ep]
		if not episodes:
			continue
		name = 'Season %s' % season_number if len(grouped) > 1 else _media_title(media)
		parts.append(_part(season_number, name, mapping, episodes))
	return parts


def _part(display_season, name, mapping, episodes):
	episodes.sort(key=lambda ep: ep.get('display_episode') or 0)
	overview = ''
	for ep in episodes:
		if ep.get('plot'):
			overview = ep['plot']
			break
	return {
		'display_season': display_season,
		'name': name or 'Season %s' % display_season,
		'overview': overview,
		'poster': _poster(mapping),
		'episodes': episodes,
	}


def _find_anchor(meta, tmdb_id):
	seen = set()
	for title in _search_titles(meta):
		for media in _anilist_search(title):
			mal_id = media.get('idMal')
			if not mal_id or mal_id in seen:
				continue
			seen.add(mal_id)
			mapping = _anizip(mal_id)
			if mapping and str((mapping.get('mappings') or {}).get('themoviedb_id') or '') == tmdb_id:
				return media.get('id'), mal_id, mapping
	return None


def _walk(anilist_id, tmdb_id):
	chain = []
	current = anilist_id
	seen = set()
	for _step in range(8):
		if not current or current in seen:
			break
		seen.add(current)
		media = _anilist_media(current)
		if not media:
			break
		mal_id = media.get('idMal')
		mapping = _anizip(mal_id) if mal_id else None
		if not mapping or str((mapping.get('mappings') or {}).get('themoviedb_id') or '') != tmdb_id:
			break
		chain.append((media, mapping))
		prequel = _relation(media, 'PREQUEL')
		if not prequel or prequel in seen:
			break
		current = prequel
	chain.reverse()
	if not chain:
		return []
	current_media = chain[-1][0]
	seen = {item[0].get('id') for item in chain}
	for _step in range(8):
		nxt = _relation(current_media, 'SEQUEL')
		if not nxt or nxt in seen:
			break
		seen.add(nxt)
		media = _anilist_media(nxt)
		if not media:
			break
		mal_id = media.get('idMal')
		mapping = _anizip(mal_id) if mal_id else None
		if not mapping or str((mapping.get('mappings') or {}).get('themoviedb_id') or '') != tmdb_id:
			break
		chain.append((media, mapping))
		current_media = media
	return chain


def _group_parts(tmdb_id):
	group = _seasons_group(metadata.episode_groups(tmdb_id))
	if not group:
		return []
	details = metadata.group_details(group.get('id')) or {}
	groups = [item for item in (details.get('groups') or []) if _int(item.get('order'), 0)]
	groups.sort(key=lambda item: _int(item.get('order'), 0))
	parts = []
	absolute = 0
	for group_item in groups:
		display_season = _int(group_item.get('order'), 0)
		episodes = []
		ordered = sorted(group_item.get('episodes') or [], key=lambda ep: _int(ep.get('order'), 0))
		for ep in ordered:
			absolute += 1
			row = _row_from_group(ep, display_season, absolute)
			if row:
				episodes.append(row)
		if not episodes:
			continue
		parts.append({
			'display_season': display_season,
			'name': group_item.get('name') or 'Season %s' % display_season,
			'overview': '',
			'poster': '',
			'episodes': episodes,
		})
	return parts


def _seasons_group(groups):
	if not groups:
		return None
	exact = [group for group in groups if (group.get('name') or '').strip().lower() == 'seasons']
	if exact:
		return exact[0]
	prefix = [group for group in groups if (group.get('name') or '').strip().lower().startswith('seasons')]
	return prefix[0] if prefix else None


def _bind_tmdb(parts, meta):
	pending = [ep for part in parts for ep in (part.get('episodes') or []) if not ep.get('tmdb_season')]
	if not pending:
		return
	try:
		tmdb_eps = metadata.all_episodes_meta(meta) or []
	except Exception:
		tmdb_eps = []
	by_date = {}
	for ep in tmdb_eps:
		if _int(ep.get('season'), 0) == 0:
			continue
		day = str(ep.get('premiered') or '')[:10]
		if day:
			by_date.setdefault(day, []).append(ep)
	for day in by_date:
		by_date[day].sort(key=lambda ep: (_int(ep.get('season'), 0), _int(ep.get('episode'), 0)))
	used = set()
	for ep in pending:
		day = str(ep.get('premiered') or '')[:10]
		chosen = None
		for candidate in by_date.get(day, []):
			pair = (_int(candidate.get('season'), 0), _int(candidate.get('episode'), 0))
			if pair in used or not pair[0] or not pair[1]:
				continue
			chosen = candidate
			used.add(pair)
			break
		if not chosen:
			continue
		ep['tmdb_season'] = _int(chosen.get('season'))
		ep['tmdb_episode'] = _int(chosen.get('episode'))
		ep['tmdb_episode_id'] = chosen.get('episode_id')
		if not ep.get('plot'):
			ep['plot'] = chosen.get('plot') or ''
		if not ep.get('thumb'):
			ep['thumb'] = chosen.get('thumb')
		if not ep.get('title'):
			ep['title'] = chosen.get('title') or ''


def _stamp(parts):
	for part in parts:
		count = len(part.get('episodes') or [])
		for ep in part.get('episodes') or []:
			ep['season_count'] = count
			ep['anime_episode'] = True


def _rows_from_mapping(mapping, display_season, cour_episode=False):
	kitsu_id = (mapping.get('mappings') or {}).get('kitsu_id')
	rows = []
	for ep in _raw_episodes(mapping):
		row = _row_from_anizip(ep, display_season, kitsu_id, cour_episode=cour_episode)
		if row:
			rows.append(row)
	return rows


def _raw_episodes(mapping):
	episodes = (mapping or {}).get('episodes') or {}
	rows = []
	for key, ep in episodes.items():
		if not str(key).isdigit() or not isinstance(ep, dict):
			continue
		rows.append(ep)
	rows.sort(key=lambda ep: _int(ep.get('absoluteEpisodeNumber'), _int(ep.get('episode'), 0)))
	return rows


def _row_from_anizip(ep, display_season, kitsu_id, cour_episode=False):
	# Split cours: `episode` is 1..n inside that part. One entry with real seasons:
	# episodeNumber is the number inside seasonNumber (Naruto S02E01, not episode 36).
	if cour_episode:
		display_episode = _int(ep.get('episode'), None)
	else:
		display_episode = _int(ep.get('episodeNumber'), None) or _int(ep.get('episode'), None)
	if not display_episode:
		return None
	absolute = _int(ep.get('absoluteEpisodeNumber'), _int(ep.get('episode'), display_episode))
	title = _episode_title(ep.get('title'))
	plot = ep.get('overview') or ep.get('summary') or ''
	premiered = str(ep.get('airDate') or ep.get('airdate') or '')[:10]
	runtime = _int(ep.get('runtime'), None) or _int(ep.get('length'), None) or 24
	return {
		'display_season': display_season,
		'display_episode': display_episode,
		'absolute': absolute,
		'kitsu_id': kitsu_id or '',
		'kitsu_episode': _int(ep.get('episode'), display_episode),
		'title': title,
		'plot': plot,
		'premiered': premiered,
		'thumb': ep.get('image') or '',
		'runtime': runtime,
		'tmdb_season': None,
		'tmdb_episode': None,
		'tmdb_episode_id': None,
	}


def _row_from_group(ep, display_season, absolute):
	tmdb_season = _int(ep.get('season_number'), None)
	tmdb_episode = _int(ep.get('episode_number'), None)
	display_episode = _int(ep.get('order'), None)
	if display_episode is None:
		return None
	display_episode += 1
	if not display_episode:
		return None
	still = ep.get('still_path')
	thumb = 'https://image.tmdb.org/t/p/w1280%s' % still if still else ''
	runtime = _int(ep.get('runtime'), None) or 24
	return {
		'display_season': display_season,
		'display_episode': display_episode,
		'absolute': absolute,
		'kitsu_id': '',
		'kitsu_episode': '',
		'title': ep.get('name') or '',
		'plot': ep.get('overview') or '',
		'premiered': str(ep.get('air_date') or '')[:10],
		'thumb': thumb,
		'runtime': runtime,
		'tmdb_season': tmdb_season,
		'tmdb_episode': tmdb_episode,
		'tmdb_episode_id': ep.get('id'),
	}


def _list_episode(ep):
	runtime = _int(ep.get('runtime'), 24) or 24
	return {
		'season': ep.get('display_season'),
		'episode': ep.get('display_episode'),
		'title': ep.get('title') or 'Episode %s' % ep.get('display_episode'),
		'plot': ep.get('plot') or '',
		'premiered': ep.get('premiered') or '',
		'thumb': ep.get('thumb') or None,
		'duration': runtime * 60,
		'episode_id': ep.get('tmdb_episode_id'),
		'episode_type': '',
		'rating': 0,
		'votes': 0,
		'director': [],
		'writer': [],
		'guest_stars': [],
		'tmdb_season': ep.get('tmdb_season'),
		'tmdb_episode': ep.get('tmdb_episode'),
		'absolute': ep.get('absolute'),
		'kitsu_id': ep.get('kitsu_id') or '',
		'kitsu_episode': ep.get('kitsu_episode') or '',
		'season_count': ep.get('season_count') or 0,
		'anime_episode': True,
	}


def _flat(show):
	rows = []
	for part in show.get('parts') or []:
		rows.extend(part.get('episodes') or [])
	rows.sort(key=lambda ep: (_int(ep.get('display_season'), 0), _int(ep.get('display_episode'), 0)))
	return rows


def _tmdb_index(flat, season, episode):
	try:
		season, episode = int(season), int(episode)
	except (TypeError, ValueError):
		return None
	for index, row in enumerate(flat):
		pair = _tmdb_pair(row)
		if pair == (season, episode):
			return index
	return None


def _row_by_tmdb(show, season, episode):
	flat = _flat(show)
	index = _tmdb_index(flat, season, episode)
	if index is None:
		return None
	return flat[index]


def _tmdb_pair(ep):
	season, episode = _int(ep.get('tmdb_season'), None), _int(ep.get('tmdb_episode'), None)
	if season and episode:
		return season, episode
	return None


def _search_titles(meta):
	titles = []
	for key in ('title', 'english_title', 'original_title'):
		value = (meta.get(key) or '').strip()
		if value and value not in titles:
			titles.append(value)
	return titles


def _media_title(media):
	title = (media or {}).get('title') or {}
	if isinstance(title, dict):
		return title.get('romaji') or title.get('english') or ''
	return str(title or '')


def _episode_title(title):
	if isinstance(title, dict):
		for key in ('en', 'x-jat', 'ja'):
			if title.get(key):
				return title[key]
		for value in title.values():
			if value:
				return value
		return ''
	return title or ''


def _poster(mapping):
	for image in (mapping or {}).get('images') or []:
		if not isinstance(image, dict):
			continue
		if str(image.get('coverType') or '').lower() == 'poster' and image.get('url'):
			return image['url']
	return ''


def _relation(media, kind):
	hits = []
	for edge in ((media or {}).get('relations') or {}).get('edges') or []:
		if edge.get('relationType') != kind:
			continue
		node = edge.get('node') or {}
		if node.get('format') not in _TV_FORMATS:
			continue
		hits.append(node)
	if not hits:
		return None
	tv = [node for node in hits if node.get('format') == 'TV']
	return (tv or hits)[0].get('id')


def _anilist_search(title):
	data = _anilist(_SEARCH, {'search': title})
	return ((data.get('Page') or {}).get('media') or []) if data else []


def _anilist_media(anilist_id):
	data = _anilist(_MEDIA, {'id': int(anilist_id)})
	return (data or {}).get('Media')


def _anilist(query, variables):
	response = requests.post(_ANILIST, json={'query': query, 'variables': variables}, headers=dict(_HEADERS, **{'Content-Type': 'application/json'}), timeout=15)
	response.raise_for_status()
	payload = response.json() or {}
	if payload.get('errors'):
		raise RuntimeError(payload['errors'][0].get('message') or 'AniList error')
	return payload.get('data') or {}


def _anizip(mal_id):
	response = requests.get(_ANIZIP, params={'mal_id': int(mal_id)}, headers=_HEADERS, timeout=15)
	if response.status_code == 404:
		return None
	response.raise_for_status()
	return response.json()


def _int(value, default=None):
	try:
		return int(value)
	except (TypeError, ValueError):
		return default
