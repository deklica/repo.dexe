# -*- coding: utf-8 -*-
import re
import json
import base64
import time
import requests
from threading import Thread
from urllib.parse import unquote, unquote_plus
from caches.settings_cache import get_setting
from modules.metadata import episodes_meta
from modules.settings import date_offset
from modules.kodi_utils import supported_media, get_property, set_property, notification
from modules.utils import adjust_premiered_date, get_datetime, jsondate_to_datetime, subtract_dates, chunks, normalize as _utils_normalize
# from modules.kodi_utils import logger

def extras():
	return ('sample', 'extra', 'extras', 'deleted', 'unused', 'footage', 'inside', 'blooper', 'bloopers',
			'making.of', 'feature', 'featurette', 'behind.the.scenes', 'trailer')

def extras_tokens(title=None, ep_name=None):
	"""Bonus-file tokens, minus any that already appear in the show or episode title.

	Stops Eyes on the Inside matching extras() 'inside'.
	"""
	hay = ' '.join(part for part in (title, ep_name) if part).lower()
	return tuple(token for token in extras() if token not in hay)

def is_extra_release(file_name, title=None, ep_name=None):
	"""True when the release looks like a bonus extra rather than the main file."""
	tokens = extras_tokens(title, ep_name)
	if not tokens or not file_name:
		return False
	return any(token in file_name.lower() for token in tokens)

def junk_name_tokens():
	# Fenom/Gears dump-and-group names, minus quality tags that eat ordinary WEB/HDTV rips.
	# extras() already drops sample/trailer. Match on release_info_format (dotted).
	return (
		'400p.octopus', '720p.octopus', '1080p.octopus', 'alexfilm', 'amedia', 'audiobook',
		'baibako', 'bigsinema', 'bonus.disc', 'casstudio.tv', 'courage.bambey',
		'.cbr', '.cbz', 'coldfilm', 'dilnix', 'dutchreleaseteam', 'e.book.collection',
		'empire.minutemen', 'eniahd', '.exe', 'exkinoray', 'extras.only',
		'gears.media', 'gearsmedia', 'good.people', 'gostfilm', 'hamsterstudio', 'hdrezka',
		'hurtom', 'idea.film', 'ideafilm', 'jaskier', 'kapatejl6',
		'kerob', 'kinokopilka', 'kravec', 'kuraj.bambey', 'lakefilm', 'lostfilm',
		'megapeer', 'minutemen.empire', 'newstudio', 'omskbird', '.ost.',
		'paravozik', 'profix.media', 'rifftrax', 'soundtrack', 'subtitle.only',
		'sunshinestudio', 'teaser', 'tumbler.studio', 'ultradox', 'viruseproject',
		'vostfr', 'vo.stfr', 'wish666',
	)

def has_junk_release_name(file_name):
	name_info = release_info_format(file_name or '')
	if not name_info:
		return False
	return any(token in name_info for token in junk_name_tokens())

def unwanted_tags():
	return (
'tamilrockers.com', 'www.tamilrockers.com', 'www.tamilrockers.ws', 'www.tamilrockers.pl', 'www-tamilrockers-cl', 'www.tamilrockers.cl', 'www.tamilrockers.li',
'www.tamilrockerrs.pl', 'www.tamilmv.bid', 'www.tamilmv.biz', 'www.1tamilmv.org', 'gktorrent-bz', 'gktorrent-com', 'www.torrenting.com', 'www.torrenting.org',
'www-torrenting-com', 'www-torrenting-org', 'katmoviehd.pw', 'katmoviehd-pw', 'www.torrent9.nz', 'www-torrent9-uno', 'torrent9-cz', 'torrent9.cz',
'agusiq-torrents-pl', 'oxtorrent-bz', 'oxtorrent-com', 'oxtorrent.com', 'oxtorrent-sh', 'oxtorrent-vc', 'www.movcr.tv', 'movcr-com', 'www.movcr.to', '(imax)',
'imax', 'xtorrenty.org', 'nastoletni.wilkoak', 'www.scenetime.com', 'kst-vn', 'www.movierulz.vc', 'www-movierulz-ht', 'www.2movierulz.ac', 'www.2movierulz.ms',
'www.3movierulz.com', 'www.3movierulz.tv', 'www.3movierulz.ws', 'www.3movierulz.ms', 'www.7movierulz.pw', 'www.8movierulz.ws', 'mkvcinemas.live', 'www.bludv.tv',
'ramin.djawadi', 'extramovies.casa', 'extramovies.wiki', '13+', '18+', 'taht.oyunlar', 'crazy4tv.com', 'karibu', '989pa.com', 'best-torrents-net', '1-3-3-8.com',
'ssrmovies.club', 'va:', 'zgxybbs-fdns-uk', 'www.tamilblasters.mx', 'www.1tamilmv.work', 'www.xbay.me', 'crazy4tv-com', '(es)')

def audio_filter_choices():
	return (
('DOLBY DIGITAL', 'DD'), ('DOLBY DIGITAL PLUS', 'DD+'), ('DOLBY DIGITAL EX', 'DD-EX'), ('DOLBY ATMOS', 'ATMOS'), ('DOLBY TRUEHD', 'TRUEHD'), 
('DTS', 'DTS'), ('DTS-HD MASTER AUDIO', 'DTS-HD MA'), ('DTS-X', 'DTS-X'), ('DTS-HD', 'DTS-HD'), ('AAC', 'AAC'), ('OPUS', 'OPUS'), ('MP3', 'MP3'),
('8CH AUDIO', '8CH'), ('7CH AUDIO', '7CH'), ('6CH AUDIO', '6CH'), ('2CH AUDIO', '2CH'))

def audio_lang_choices():
	# Alphabetical by display name (Sort To Top / filter menu order).
	return (
('ENGLISH AUDIO', 'ENG', ('.eng.', '.english.')),
('FRENCH AUDIO', 'FRE', ('.fre.', '.french.', '.fra.', '.vff.', '.vfq.', '.truefrench.')),
('GERMAN AUDIO', 'GER', ('.ger.', '.german.', '.deu.')),
('HINDI AUDIO', 'HIN', ('.hin.', '.hindi.')),
('ITALIAN AUDIO', 'ITA', ('.ita.', '.italian.')),
('JAPANESE AUDIO', 'JPN', ('.jpn.', '.japanese.', '.jap.')),
('KOREAN AUDIO', 'KOR', ('.kor.', '.korean.')),
('PORTUGUESE AUDIO', 'POR', ('.por.', '.portuguese.', '.dublado.')),
('RUSSIAN AUDIO', 'RUS', ('.rus.', '.russian.')),
('SPANISH AUDIO', 'SPA', ('.spa.', '.spanish.', '.esp.', '.castellano.', '.latino.')))

ENG_OR_UNTAGGED_FILTER = ('ENGLISH OR UNTAGGED', 'ENG-OR-UNTAGGED')

def foreign_audio_lang_tags():
	return frozenset(tag for _, tag, _ in audio_lang_choices() if tag != 'ENG')

# Words and 3-letter codes match anywhere in the dotted name.
# 2-letter codes are dotted so ".en." is not found inside "french". ".uk." is left out (UK in a title).
# A 2-letter code between the quality and the source is a release group (1080p.iT.WEB-DL), not audio.
# The same code only marking subtitles (364.nl.sub) is not audio. ".it." at the end of H.265-iT is the group.
# A 2-letter code between ordinary title words (de in "final de", it in a sentence) is not audio.
_FOREIGN_AUDIO_WORDS = (
	'arabic', 'bengali', 'bgaudio', 'castellano', 'chinese', 'dublado', 'dutch', 'finnish', 'french', 'german', 'greek',
	'hebrew', 'hindi', 'indonesian', 'italian', 'japanese', 'korean', 'latino', 'pldub', 'polish', 'portuguese', 'russian',
	'spanish', 'swedish', 'tamil', 'telugu', 'truefrench', 'truespanish', 'turkish', 'vostfr',
)
_FOREIGN_AUDIO_CODES = (
	'.ara.', '.ces.', '.chi.', '.chs.', '.cze.', '.dan.', '.deu.', '.dut.', '.ell.', '.esl.',
	'.esp.', '.fin.', '.fra.', '.fre.', '.frn.', '.ger.', '.gre.', '.heb.', '.hin.',
	'.hun.', '.ita.', '.jap.', '.jpn.', '.kor.', '.lat.', '.nld.',
	'.nor.', '.pol.', '.por.', '.rus.', '.spa.', '.swe.', '.tur.',
	'.ukr.', '.vff.', '.vfq.', '.vie.', '.zho.',
)
_FOREIGN_AUDIO_SHORT_CODES = (
	'de', 'es', 'fi', 'fr', 'he', 'hi', 'it', 'ja', 'ko', 'nl', 'pl', 'pt', 'ru', 'sv', 'tr', 'vi', 'zh',
)
_SHORT_CODE_RES = re.compile(r'^\d{3,4}p$')
_SHORT_CODE_GAP = frozenset((
	'hdr', 'hdr10', 'dv', 'dovi', 'sdr', '10bit', '8bit', '12bit', 'hybrid', 'repack', 'proper', 'rerip', 'extended',
))
_SHORT_CODE_SOURCE = frozenset((
	'web', 'webrip', 'webdl', 'bluray', 'blu', 'bdrip', 'brrip', 'hdtv', 'hdrip',
	'dvdrip', 'dvd', 'hdcam', 'cam', 'camrip', 'hdts', 'telesync', 'webhd', 'remux',
))
_SHORT_CODE_SUB = frozenset(('sub', 'subs', 'subtitle', 'subbed', 'subtitles'))
_SHORT_CODE_CODEC = frozenset(('x264', 'x265', 'h264', 'h265', '264', '265', 'xvid', 'hevc', 'av1', 'divx'))
_SHORT_CODE_EXT = frozenset(('mkv', 'mp4', 'avi', 'm4v', 'ts', 'wmv', 'mpg', 'mpeg', 'iso', 'mov'))
_SHORT_CODE_DUB = frozenset(('dub', 'dubbed', 'dubbing', 'audio', 'dual'))
_SHORT_CODE_YEAR = re.compile(r'^(?:19|20)\d{2}$')
_ENGLISH_OR_MULTI = ('.eng.', '.en.', '.english.', '.ingles.', '.multi.')
# "Ing" in Lat-Cast-Ing is English. "1TamilMV.ing" is a site, so Ing only counts beside another language.
_ENGLISH_ING_NEIGHBORS = frozenset((
	'lat', 'latino', 'cast', 'castellano', 'esp', 'spa', 'spanish', 'es',
	'fr', 'fra', 'fre', 'french', 'ita', 'italian', 'por', 'pt', 'portuguese',
	'pl', 'polish', 'de', 'ger', 'german', 'rus', 'ru', 'russian', 'ukr',
	'hin', 'hindi', 'tam', 'tamil', 'hun', 'kor', 'jpn', 'jap',
))

def _dotted_release_name(name):
	text = re.sub(r'[^a-z0-9]+', '.', (name or '').lower()).strip('.')
	if not text: return ''
	return '.%s.' % text

def _resolution_before(text, index):
	before = text[:index].strip('.')
	while before:
		piece = before.rsplit('.', 1)[-1]
		if _SHORT_CODE_RES.match(piece): return True
		if piece not in _SHORT_CODE_GAP: return False
		cut = before.rfind('.')
		if cut < 0: return False
		before = before[:cut]
	return False

def _short_code_tag(token):
	if not token: return False
	if token in _SHORT_CODE_GAP or token in _SHORT_CODE_SOURCE or token in _SHORT_CODE_CODEC: return True
	if token in _SHORT_CODE_EXT or token in _SHORT_CODE_DUB: return True
	if _SHORT_CODE_RES.match(token) or _SHORT_CODE_YEAR.match(token): return True
	return False

def _short_code_is_audio(text, code):
	"""True when this 2-letter code marks audio, not a release group, a subtitle tag, or a title word."""
	token = '.%s.' % code
	start = 0
	while True:
		index = text.find(token, start)
		if index < 0: return False
		nxt = text[index + len(token):].split('.', 1)[0]
		prev = text[:index].strip('.').rsplit('.', 1)[-1]
		if nxt in _SHORT_CODE_SUB:
			start = index + len(token)
			continue
		if _resolution_before(text, index) and nxt in _SHORT_CODE_SOURCE:
			start = index + len(token)
			continue
		rest = [part for part in text[index + len(token):].split('.') if part]
		if len(rest) <= 1 and (not rest or rest[0] in _SHORT_CODE_EXT):
			if prev in _SHORT_CODE_CODEC:
				start = index + len(token)
				continue
		if not (_short_code_tag(prev) or _short_code_tag(nxt)):
			start = index + len(token)
			continue
		return True

def _ing_means_english(text):
	token = '.ing.'
	start = 0
	while True:
		index = text.find(token, start)
		if index < 0: return False
		prev = text[:index].strip('.').rsplit('.', 1)[-1]
		nxt = text[index + len(token):].split('.', 1)[0]
		if prev in _ENGLISH_ING_NEIGHBORS or nxt in _ENGLISH_ING_NEIGHBORS: return True
		start = index + len(token)

def foreign_single_audio(name):
	"""True when the filename is one non-English language and not English or multi."""
	text = _dotted_release_name(name)
	if not text: return False
	if any(token in text for token in _ENGLISH_OR_MULTI) or _ing_means_english(text): return False
	if any(word in text for word in _FOREIGN_AUDIO_WORDS): return True
	if any(code in text for code in _FOREIGN_AUDIO_CODES): return True
	return any(('.%s.' % code) in text and _short_code_is_audio(text, code) for code in _FOREIGN_AUDIO_SHORT_CODES)

def matches_english_or_untagged(tags):
	# ENG tag, or no other audio-language tag (plain English rips are usually untagged).
	tag_set = set()
	for tag in tags or ():
		cleaned = str(tag).replace('[B]', '').replace('[/B]', '').strip()
		if cleaned: tag_set.add(cleaned)
	if 'ENG' in tag_set: return True
	return not tag_set.intersection(foreign_audio_lang_tags())

def audio_lang_filter_entries():
	entries = []
	for name, tag, _ in audio_lang_choices():
		entries.append((name, tag))
		if tag == 'ENG': entries.append(ENG_OR_UNTAGGED_FILTER)
	return tuple(entries)

def source_filters():
	return (
('PACK', 'PACK'), ('DOLBY VISION', '[B]D/VISION[/B]'), ('HIGH DYNAMIC RANGE (HDR)', '[B]HDR[/B]'), ('IMAX', 'IMAX'), ('HYBRID', '[B]HYBRID[/B]'), ('AV1', '[B]AV1[/B]'),
('HEVC (X265)', '[B]HEVC[/B]'), ('MP4', 'MP4'), ('MKV', 'MKV'), ('REMUX', 'REMUX'), ('BLURAY', 'BLURAY'), ('AI ENHANCED/UPSCALED', '[B]AI ENHANCED/UPSCALED[/B]'), ('SDR', 'SDR'), ('3D', '[B]3D[/B]'),
('DOLBY ATMOS', 'ATMOS'), ('DOLBY TRUEHD', 'TRUEHD'), ('DOLBY DIGITAL EX', 'DD-EX'), ('DOLBY DIGITAL PLUS', 'DD+'), ('DOLBY DIGITAL', 'DD'),
('DTS-HD MASTER AUDIO', 'DTS-HD MA'), ('DTS-X', 'DTS-X'), ('DTS-HD', 'DTS-HD'), ('DTS', 'DTS'), ('AAC', 'AAC'), ('OPUS', 'OPUS'), ('MP3', 'MP3'), ('8CH AUDIO', '8CH'),
('7CH AUDIO', '7CH'), ('6CH AUDIO', '6CH'), ('2CH AUDIO', '2CH'), ('DVD SOURCE', 'DVD'), ('WEB SOURCE', 'WEB'),
('SUBTITLES', 'SUBS'), ('MULTIPLE LANGUAGES', 'MULTI-LANG')) + audio_lang_filter_entries()

def include_exclude_filters():
	return {'hevc': 'HEVC', '3d': '3D', 'hdr': 'HDR', 'dv': 'D/VISION', 'av1': 'AV1', 'enhanced_upscaled': 'AI ENHANCED/UPSCALED', 'hybrid': 'HYBRID', 'mp4': 'MP4'}

def get_aliases_titles(aliases):
	try: result = [i['title'] for i in aliases]
	except: result = []
	return result

_ALT_TITLE_COUNTRIES = ('US', 'GB', 'UK', 'JP', '')

def _alt_title_usable(title, iso_3166_1=''):
	"""Keep US/GB/UK/JP/blank alts, plus mostly-Latin names from other regions (romaji-style releases)."""
	if not title: return False
	iso = (iso_3166_1 or '').upper()
	if iso in _ALT_TITLE_COUNTRIES: return True
	try:
		normalized = normalize(title)
		letters = [c for c in normalized if c.isalpha()]
		if len(letters) < 3: return False
		# Basic Latin + Latin-1 Supplement + Latin Extended-A/B — skip CJK/Hangul/Thai/etc.
		latin = sum(1 for c in letters if ord(c) < 0x0250)
		return latin >= int(len(letters) * 0.85)
	except: return False

def filter_alternative_titles(entries, titles_key='results'):
	"""Normalize TMDb movie (titles) / TV (results) alternative_titles into a usable string list."""
	if not entries: return []
	if isinstance(entries, dict):
		alternatives = entries.get(titles_key) or entries.get('titles') or entries.get('results') or []
	else:
		alternatives = entries
	out, seen = [], set()
	for item in alternatives:
		if not isinstance(item, dict): continue
		title = item.get('title') or ''
		if not _alt_title_usable(title, item.get('iso_3166_1', '')): continue
		key = title.casefold()
		if key in seen: continue
		seen.add(key)
		out.append(title)
	return out

def folder_title_queries(title, aliases=None):
	"""Cleaned primary title + aliases for cloud folder substring gates."""
	queries, seen = [], set()
	for candidate in [title] + list(aliases or []):
		if not candidate: continue
		query = clean_title(normalize(candidate))
		if not query or query in seen: continue
		seen.add(query)
		queries.append(query)
	return queries

def folder_name_matches(folder_name, title, aliases=None):
	cleaned = clean_title(normalize(folder_name or ''))
	if not cleaned: return True
	queries = folder_title_queries(title, aliases)
	return any(q in cleaned for q in queries)

def _usable_host_alias(name):
	tokens = [t for t in re.split(r'\s+', (name or '').strip(' .:-')) if t]
	if len(tokens) < 2 or len(tokens) > 5:
		return False
	if tokens[0].lower() in ('the', 'a', 'an'):
		return False
	return True

def daily_short_aliases(title):
	"""Talk-show host short name only: 'Starring X' or 'Show/Night with X'.

	Bare 'with X' is skipped (Dancing with the Stars). Host must be 2–5 tokens
	and not start with the/a/an.
	"""
	text = (title or '').strip()
	if not text:
		return []
	aliases, seen = [], set()
	def _add(name):
		name = (name or '').strip(' .:-')
		key = name.casefold()
		if not name or key in seen or not _usable_host_alias(name):
			return
		seen.add(key)
		aliases.append(name)
	starring = re.search(r'\bStarring\s+(.+)$', text, re.I)
	if starring:
		_add(starring.group(1))
	# The Late Show with Stephen Colbert / Late Night with Seth Meyers
	show_with = re.search(r'\b(?:Show|Night)\s+with\s+(.+)$', text, re.I)
	if show_with:
		_add(show_with.group(1))
	return aliases

_SCRAPE_ALIAS_ARTICLES = frozenset(('the', 'a', 'an'))

def _strip_leading_article(tokens):
	if tokens and tokens[0] in _SCRAPE_ALIAS_ARTICLES:
		return list(tokens[1:])
	return list(tokens or [])

def _tokens_are_prefix(short, long_tokens):
	if not short or not long_tokens or len(short) > len(long_tokens):
		return False
	return list(long_tokens[:len(short)]) == list(short)

def _scrape_alias_usable(title, original_title, alias):
	"""True when a TMDb alternative title is safe to treat as this show in scrapes.

	Drops one-word working titles that are a different show (Nocturne / Lazarus).
	Keeps cleaned matches (9-1-1 / 911), title-without-The (The Mandalorian /
	Mandalorian), first-token abbreviations (CSI), and two-or-more-word names.
	"""
	alias = (alias or '').strip()
	if not alias:
		return False
	alias_tokens = _filename_tokens(alias)
	if not alias_tokens:
		# Non-Latin (JP original script): not an English filename collision.
		return True
	if all(t in _SCRAPE_ALIAS_ARTICLES for t in alias_tokens):
		return False
	alias_clean = clean_title(alias) or ''
	title_clean = clean_title(title) or ''
	if alias_clean and title_clean and alias_clean == title_clean:
		return True
	original_clean = clean_title(original_title) or ''
	if alias_clean and original_clean and alias_clean == original_clean:
		return True
	alias_core = _strip_leading_article(alias_tokens)
	if not alias_core:
		return False
	for host in (_filename_tokens(title), _filename_tokens(original_title)):
		host_core = _strip_leading_article(host)
		if host_core and alias_core == host_core:
			return True
		if host and _tokens_are_prefix(alias_tokens, host):
			return True
		if host_core and _tokens_are_prefix(alias_core, host_core):
			return True
	return len(alias_tokens) >= 2

def make_alias_dict(meta, title, scrape=True):
	"""Aliases for scrapes (scrape=True) or the full TMDb list (Scrape with an Alias)."""
	aliases = []
	alternative_titles = meta.get('alternative_titles', []) or []
	original_title = meta.get('original_title') or title or ''
	cunt_codes = meta.get('country_codes', [])
	country_codes = set([i.replace('GB', 'UK') for i in cunt_codes])
	seen = set()
	def _add(name):
		name = (name or '').strip()
		if not name:
			return
		key = name.casefold()
		if key in seen:
			return
		seen.add(key)
		aliases.append({'title': name, 'country': ''})
	for alt in alternative_titles:
		if scrape and not _scrape_alias_usable(title, original_title, alt):
			continue
		_add(alt)
	_add(original_title)
	if country_codes:
		for code in country_codes:
			_add('%s %s' % (title, code))
	for short in daily_short_aliases(title) + daily_short_aliases(original_title):
		_add(short)
	return aliases

def internal_results(provider, sources):
	set_property('redlight.internal_results.%s' % provider, json.dumps(sources))

def normalize(title):
	"""Same accent-fold as modules.utils.normalize (single implementation)."""
	return _utils_normalize(title)

def _season_fully_aired(meta, season):
	adjust_hours, current_date = date_offset(), get_datetime()
	episodes_data = episodes_meta(season, meta)
	if not episodes_data: return False
	aired = [adjust_premiered_date(i['premiered'], adjust_hours)[0] for i in episodes_data]
	if None in aired: return False
	return all(i <= current_date for i in aired)

def show_has_ended(meta):
	try: return (meta.get('extra_info') or {}).get('status') in ('Ended', 'Canceled')
	except Exception: return False

def release_covers_season(release_title, season):
	"""True when the name has this season, or a range that includes it (S04, S01-S04)."""
	if not release_title: return False
	try: season_i = int(season)
	except (TypeError, ValueError): return False
	dotted = _utils_normalize(release_title).lower().replace(' ', '.')
	covered = set()
	for match in re.finditer(r'(?:seasons?)[.\s_-]*(\d{1,2})[.\s_-]*(?:to|through|-)[.\s_-]*(\d{1,2})(?!\d)', dotted):
		start, end = int(match.group(1)), int(match.group(2))
		if start > end: start, end = end, start
		covered.update(range(start, end + 1))
	for match in re.finditer(r's(\d{1,2})[._-]+s(\d{1,2})(?!\d)', dotted):
		start, end = int(match.group(1)), int(match.group(2))
		if start > end: start, end = end, start
		covered.update(range(start, end + 1))
	for match in re.finditer(r'(?:^|[.\s_-])(?:s|season)[.\s_-]*(\d{1,2})(?!\d)', dotted):
		rest = dotted[match.end():match.end() + 3]
		if re.match(r'[.\s_-]*e\d', rest): continue
		covered.add(int(match.group(1)))
	return season_i in covered

def pack_enable_check(meta, season, episode):
	"""(season_packs, show_packs).

	Ended or canceled: both on. This season fully aired: both on (Slow Horses S4
	while S6 is still airing). This season still has unaired episodes: both off.
	A show pack on a running show still has to name this season.
	"""
	try:
		if show_has_ended(meta): return True, True
		if not _season_fully_aired(meta, season): return False, False
		return True, True
	except: pass
	return False, False

def clear_scrapers_cache(silent=False):
	from caches.base_cache import clear_cache
	for item in ('internal_scrapers', 'external_scrapers'): clear_cache(item, silent=True)
	if not silent: notification('Success')

def supported_video_extensions():
	supported_video_extensions = supported_media().split('|')
	return [i for i in supported_video_extensions if not i in ('','.zip','.rar','.iso')]

def seas_ep_filter(season, episode, release_title, split=False, return_match=False):
	str_season, str_episode = str(season), str(episode)
	season_fill, episode_fill = str_season.zfill(2), str_episode.zfill(2)
	str_ep_plus_1, str_ep_minus_1 = str(episode+1), str(episode-1)
	release_title = re.sub(r'[^A-Za-z0-9-]+', '.', unquote(release_title).replace('\'', '')).lower()
	# If the name has an explicit Sxx / NxN season, it must match. Stops S12E01-E02
	# matching S01E02 via episode-only patterns like -e02 (complete show packs).
	season_tags = re.findall(r'(?:^|[.-])s(\d{1,2})[.-]?e', release_title)
	season_tags += re.findall(r'(?:^|[.-])(\d{1,2})x\d', release_title)
	if season_tags:
		requested = {str(int(season)), str_season, season_fill}
		if not any(str(int(tag)) in requested or tag in requested for tag in season_tags):
			if return_match: raise AttributeError('seas_ep season mismatch')
			return False
	string1 = r'(s<<S>>[.-]?e[p]?[.-]?<<E>>[.-])'
	string2 = r'(season[.-]?<<S>>[.-]?episode[.-]?<<E>>[.-])'#|([s]?<<S>>[x.]<<E>>[.-])'
	string3 = r'(s<<S>>e<<E1>>[.-]?e?<<E2>>[.-])'
	string4 = r'([.-]<<S>>[.-]?<<E>>[.-])'
	string5 = r'(episode[.-]?<<E>>[.-])'
	string6 = r'([.-]e[p]?[.-]?<<E>>[.-])'
	string7 = r'(^(?=.*\.e?0*<<E>>\.)(?:(?!((?:s|season)[.-]?\d+[.-x]?(?:ep?|episode)[.-]?\d+)|\d+x\d+).)*$)'
	string8 = r'([s]?<<S>>x<<E>>[.-])'
	string_list = []
	string_list_append = string_list.append
	string_list_append(string1.replace('<<S>>', season_fill).replace('<<E>>', episode_fill))
	string_list_append(string1.replace('<<S>>', str_season).replace('<<E>>', episode_fill))
	string_list_append(string1.replace('<<S>>', season_fill).replace('<<E>>', str_episode))
	string_list_append(string1.replace('<<S>>', str_season).replace('<<E>>', str_episode))
	string_list_append(string2.replace('<<S>>', season_fill).replace('<<E>>', episode_fill))
	string_list_append(string2.replace('<<S>>', str_season).replace('<<E>>', episode_fill))
	string_list_append(string2.replace('<<S>>', season_fill).replace('<<E>>', str_episode))
	string_list_append(string2.replace('<<S>>', str_season).replace('<<E>>', str_episode))
	string_list_append(string3.replace('<<S>>', season_fill).replace('<<E1>>', str_ep_minus_1.zfill(2)).replace('<<E2>>', episode_fill))
	string_list_append(string3.replace('<<S>>', season_fill).replace('<<E1>>', episode_fill).replace('<<E2>>', str_ep_plus_1.zfill(2)))
	string_list_append(string4.replace('<<S>>', season_fill).replace('<<E>>', episode_fill))
	string_list_append(string4.replace('<<S>>', str_season).replace('<<E>>', episode_fill))
	string_list_append(string5.replace('<<E>>', episode_fill))
	string_list_append(string5.replace('<<E>>', str_episode))
	string_list_append(string6.replace('<<E>>', episode_fill))
	string_list_append(string7.replace('<<E>>', episode_fill))
	string_list_append(string8.replace('<<S>>', season_fill).replace('<<E>>', episode_fill))
	string_list_append(string8.replace('<<S>>', str_season).replace('<<E>>', episode_fill))
	string_list_append(string8.replace('<<S>>', season_fill).replace('<<E>>', str_episode))
	string_list_append(string8.replace('<<S>>', str_season).replace('<<E>>', str_episode))
	final_string = '|'.join(string_list)
	match = re.search(final_string, release_title)
	if split:
		if not match: return release_title
		return release_title.split(match.group(), 1)[1]
	if return_match: return match.group()
	return bool(match)

def seas_ep_filter_exact(season, episode, release_title):
	"""Exact S/E only — for debrid cloud files (no multi-episode pack ranges)."""
	str_season, str_episode = str(season), str(episode)
	season_fill, episode_fill = str_season.zfill(2), str_episode.zfill(2)
	release_title = re.sub(r'[^A-Za-z0-9-]+', '.', unquote(release_title).replace('\'', '')).lower()
	patterns = (
		r'(s<<S>>[.-]?e[p]?[.-]?<<E>>[.-])',
		r'(season[.-]?<<S>>[.-]?episode[.-]?<<E>>[.-])',
		r'([.-]<<S>>[.-]?<<E>>[.-])',
		r'(episode[.-]?<<E>>[.-])',
		r'([.-]e[p]?[.-]?<<E>>[.-])',
		r'([s]?<<S>>x<<E>>[.-])',
	)
	string_list = []
	for pattern in patterns:
		for s, e in ((season_fill, episode_fill), (str_season, episode_fill), (season_fill, str_episode), (str_season, str_episode)):
			string_list.append(pattern.replace('<<S>>', s).replace('<<E>>', e))
	return bool(re.search('|'.join(string_list), release_title))

def scrape_premiered(value):
	"""Episode air date for scrapers/resolve: YYYY-MM-DD, or '' if missing/invalid."""
	text = str(value or '').strip()
	if not text:
		return ''
	match = re.match(r'^(\d{4})[-./](\d{1,2})[-./](\d{1,2})', text)
	if not match:
		return ''
	year, month, day = match.group(1), match.group(2).zfill(2), match.group(3).zfill(2)
	try:
		month_i, day_i = int(month), int(day)
	except Exception:
		return ''
	if month_i < 1 or month_i > 12 or day_i < 1 or day_i > 31:
		return ''
	return '%s-%s-%s' % (year, month, day)

def premiered_release_tokens(premiered):
	value = scrape_premiered(premiered)
	if not value:
		return ()
	year, month, day = value.split('-')
	return (
		'%s.%s.%s' % (year, month, day),
		'%s-%s-%s' % (year, month, day),
		'%s%s%s' % (year, month, day),
	)

def premiered_in_release(release_title, premiered, split=False, return_match=False):
	"""True when the file is a date-named episode (Show.Name.2026.10.20.1080p)."""
	tokens = premiered_release_tokens(premiered)
	if not tokens:
		if return_match:
			return ''
		return release_title if split else False
	text = re.sub(r'[^A-Za-z0-9-]+', '.', unquote(release_title or '').replace('\'', '')).lower()
	for token in tokens:
		found = re.search(r'(?:^|[.-])%s(?=[.-]|$)' % re.escape(token), text)
		if not found:
			continue
		if return_match:
			return found.group(0).strip('.-')
		if split:
			return text[found.end():]
		return True
	if return_match:
		return ''
	return text if split else False

def episode_release_matches(season, episode, release_title, premiered=None, split=False, return_match=False, alt_season=None, alt_episode=None):
	"""SxxExx match, or the episode air date when Coco (or similar) used premiered."""
	for s, e in scrape_episode_pairs(season, episode, alt_season, alt_episode) or [(season, episode)]:
		if seas_ep_filter(s, e, release_title):
			return seas_ep_filter(s, e, release_title, split=split, return_match=return_match)
	if scrape_premiered(premiered) and premiered_in_release(release_title, premiered):
		return premiered_in_release(release_title, premiered, split=split, return_match=return_match)
	if return_match:
		raise AttributeError('episode release mismatch')
	if split:
		return release_title
	return False

# Cloud filename S/E tokens (left-to-right). Prefer explicit season markers.
# Covers S04E17, S4.E17, S4-E17, S4 -17, S4-17, S4.17, S4 - E17, S6x29, S6xE29, 4x17.
# Episode 1–4 digits (One Piece S23E1170). (?!\d) avoids hash tags like S1E123456…
_CLOUD_SE_TOKEN_RE = re.compile(
	r'(?:'
	r's(\d{1,2})[.-]?e[p]?[.-]?(\d{1,4})(?!\d)'
	r'|'
	r's(\d{1,2})x(?:e)?(\d{1,4})(?!\d)'
	r'|'
	r's(\d{1,2})[.-]+(?:e[p]?[.-]*)?(\d{1,4})(?!\d)'
	r'|'
	r'(\d{1,2})x(\d{1,4})(?!\d)'
	r')'
)
# Anime-style bare episode only when no Sxx/NxN token exists: "Show - 001 - Title", "Show - 1080.mkv".
# 4 digits so 1080/1170 can match; a year token only keeps if that number is the requested episode.
_CLOUD_BARE_EP_RE = re.compile(r'(?:^|[.-])(\d{1,4})(?=[.-]|$)')
# e164 / ep15 / episode.15. Prefix required; 4 digits so e1170 can match.
_CLOUD_BARE_EP_PREFIX_RE = re.compile(r'(?:^|[.-])(?:e(?:p(?:isode)?)?)[.-]?(\d{1,4})(?=[.-]|$)')
# Quality-like numbers: skip unless that number is the requested episode/absolute.
# 1080p is already not a bare token (p attached). Show.720.BluRay stays out when not ep 720.
_BARE_EP_BLOCKLIST = frozenset((480, 720, 1080, 2160))

def _normalize_release_title(release_title):
	return re.sub(r'[^A-Za-z0-9-]+', '.', unquote(release_title).replace('\'', '')).lower()

def iter_season_episode_tokens(release_title):
	"""Yield (season, episode) pairs from a release/file name, left to right."""
	release_title = _normalize_release_title(release_title)
	for match in _CLOUD_SE_TOKEN_RE.finditer(release_title):
		try:
			if match.group(1) is not None:
				yield int(match.group(1)), int(match.group(2))
			elif match.group(3) is not None:
				yield int(match.group(3)), int(match.group(4))
			elif match.group(5) is not None:
				yield int(match.group(5)), int(match.group(6))
			else:
				yield int(match.group(7)), int(match.group(8))
		except Exception:
			continue

def absolute_episode_from_season_data(season_data, season, episode):
	"""Aired-order absolute episode for season-relative numbering (e.g. DBZ S09E02 → 255).
	When TMDb already uses absolute episode numbers inside a season (One Piece S23E1170), return that episode."""
	try:
		season_i, episode_i = int(season), int(episode)
	except Exception:
		return None
	if not season_data or season_i < 1 or episode_i < 1:
		return None
	try:
		cur = next((i for i in season_data if int(i.get('season_number') or -1) == season_i), None)
		ep_count = int((cur or {}).get('episode_count') or 0)
		# Absolute-style numbers inside the season (episode exceeds that season's count).
		if ep_count and episode_i > ep_count:
			return episode_i
		prior = sum(int(i.get('episode_count') or 0) for i in season_data if 0 < int(i.get('season_number') or -1) < season_i)
		return prior + episode_i
	except Exception:
		return None

def iter_bare_episode_numbers(release_title, requested=None):
	"""Yield bare episode candidates when the name has no explicit season token.

	480/720/1080/2160 are skipped unless they are the requested episode or absolute.
	"""
	normalized = _normalize_release_title(release_title)
	if _CLOUD_SE_TOKEN_RE.search(normalized):
		return
	requested = set(requested or ())
	seen = set()
	for rx in (_CLOUD_BARE_EP_PREFIX_RE, _CLOUD_BARE_EP_RE):
		for match in rx.finditer(normalized):
			try:
				num = int(match.group(1))
			except Exception:
				continue
			if num < 1 or num in seen:
				continue
			if num in _BARE_EP_BLOCKLIST and num not in requested:
				continue
			seen.add(num)
			yield num

def parse_episode_from_filename(release_title, season=None):
	"""Parse SxxExx / Sxx - ## / 1x## from a filename; prefer requested season; ignore later hash junk."""
	for s_num, e_num in iter_season_episode_tokens(release_title):
		if season is not None and int(s_num) != int(season):
			continue
		return e_num
	return None

def scrape_episode_pairs(season, episode, alt_season=None, alt_episode=None):
	"""(season, episode) pairs to query or match. Alt is the anime list S/E when it differs from TMDb."""
	pairs = []
	try:
		pairs.append((int(season), int(episode)))
	except Exception:
		return []
	try:
		alt_s, alt_e = int(alt_season), int(alt_episode)
	except Exception:
		return pairs
	if alt_s > 0 and alt_e > 0 and (alt_s, alt_e) not in pairs:
		pairs.append((alt_s, alt_e))
	return pairs


def scrape_alt_episode(info):
	"""List S/E from an anime map when it is not the TMDb pair used to scrape."""
	info = info or {}
	try:
		alt_s, alt_e = int(info.get('display_season')), int(info.get('display_episode'))
		season, episode = int(info.get('season')), int(info.get('episode'))
	except Exception:
		return None, None
	if alt_s < 1 or alt_e < 1 or (alt_s, alt_e) == (season, episode):
		return None, None
	return alt_s, alt_e


def cloud_or_date_matches(season, episode, filename, absolute_episode=None, premiered=None, accept_s01_absolute=False, alt_season=None, alt_episode=None):
	"""SxxExx / absolute (cloud_episode_matches), or the episode air date."""
	if cloud_episode_matches(season, episode, filename, absolute_episode, accept_s01_absolute=accept_s01_absolute, alt_season=alt_season, alt_episode=alt_episode):
		return True
	return bool(scrape_premiered(premiered) and episode_release_matches(season, episode, filename, premiered, alt_season=alt_season, alt_episode=alt_episode))

def cloud_episode_matches(season, episode, filename, absolute_episode=None, accept_s01_absolute=False, alt_season=None, alt_episode=None):
	"""Match requested episode using the file name only — not parent folder names like Episode 1/.

	1) Explicit SxxExx / S# -## / NxN tokens (prefer these; never guess against them).
	2) Anime maps also accept the list S/E, TMDb S/E, and S01E{absolute} when the pack filed the cour as season 1.
	3) Else bare aired-order number: match absolute_episode when known, else S01 + episode only.
	"""
	if not filename:
		return False
	pairs = scrape_episode_pairs(season, episode, alt_season, alt_episode)
	if not pairs:
		return False
	season_i, episode_i = pairs[0]
	tokens = list(iter_season_episode_tokens(filename))
	if tokens:
		if any(s_num == s and e_num == e for s, e in pairs for s_num, e_num in tokens):
			return True
		if accept_s01_absolute and absolute_episode is not None:
			try:
				abs_i = int(absolute_episode)
			except Exception:
				abs_i = 0
			if abs_i > 0 and any(s_num == 1 and e_num == abs_i for s_num, e_num in tokens):
				return True
		return False
	targets = set()
	if absolute_episode is not None:
		try:
			abs_i = int(absolute_episode)
			if abs_i > 0:
				targets.add(abs_i)
		except Exception:
			pass
	# Season 1 files often omit S01 ("Show - 001 - Title"); only when no absolute target or same value.
	for s, e in pairs:
		if s == 1:
			targets.add(e)
	if not targets:
		return False
	return any(num in targets for num in iter_bare_episode_numbers(filename, targets))

def find_season_in_release_title(release_title):
	release_title = re.sub(r'[^A-Za-z0-9-]+', '.', unquote(release_title).replace('\'', '')).lower()
	match = None
	regex_list = [r's(\d+)', r's\.(\d+)', r'(\d+)x', r'(\d+)\.x', r'season(\d+)', r'season\.(\d+)']
	for item in regex_list:
		try:
			match = re.search(item, release_title)
			if match:
				match = int(str(match.group(1)).lstrip('0'))
				break
		except: pass
	return match

_FALSE_YEAR_TOKENS = frozenset((1920,))
_YEAR_TOKEN_RE = re.compile(r'(?:^|[^0-9])((?:19|20)\d{2})(?![0-9])')

def _exact_show_title_key(name):
	text = (name or '').lower().replace('&', 'and')
	return re.sub(r'[^a-z0-9]+', '', text)

def filename_years(release_title):
	"""19xx/20xx tokens in a release name. Skips 1920 (1080p width)."""
	years = set()
	for match in _YEAR_TOKEN_RE.finditer(release_title or ''):
		try:
			value = int(match.group(1))
		except Exception:
			continue
		if value in _FALSE_YEAR_TOKENS:
			continue
		years.add(value)
	return years

def release_contains_show_year(release_title, year):
	try:
		year = int(year)
	except Exception:
		return False
	return bool(filename_years(release_title) & {year - 1, year, year + 1})

def movie_release_year_ok(release_title, title, year):
	"""True when the name has no release year, or it is search year ±1.

	Years that are the movie title itself (1917, 2012) are not treated as a release year.
	Used by Local Media Folders so a (2000) file is not returned for a 2018 search.
	"""
	try:
		year = int(year or 0)
	except Exception:
		return True
	if not year:
		return True
	release_years = filename_years(release_title or '') - filename_years(title or '')
	if not release_years:
		return True
	return bool(release_years & {year - 1, year, year + 1})

def _folders_movie_dotted_key(text, strip_years=None):
	text = strip_non_ascii_and_unprintable(text or '').lstrip('/ ').replace(' ', '.').replace(':', '.').lower()
	text = text.replace("'", '').replace('!', '').replace('?', '').replace('(', '').replace(')', '').replace('&', 'and')
	text = re.sub(r'\.+', '.', text).strip('.')
	unwanted = unwanted_tags()
	releasetitle_startswith = text.startswith
	for i in unwanted:
		if releasetitle_startswith(i):
			i_startswith = i.startswith
			pattern = r'\%s' % i if i_startswith('[') or i_startswith('+') else r'%s' % i
			text = re.sub(r'^%s' % pattern, '', text, 1, re.I)
	text = text.lstrip('.-:/')
	text = re.sub(r'^\[.*?]', '', text, 1, re.I)
	text = text.lstrip('.-[](){}:/')
	text = re.sub(r'\.+', '.', text).strip('.')
	if '.' in text:
		head, tail = text.rsplit('.', 1)
		if 2 <= len(tail) <= 4 and tail.isalpha():
			text = head
	if strip_years:
		for y in sorted(strip_years, reverse=True):
			text = re.sub(r'(?:^|\.)%s(?:\.|$)' % y, '.', text)
		text = re.sub(r'\.+', '.', text).strip('.')
	return text

def folders_movie_title_ok(title, release_title, aliases, year):
	"""Local movie title match: exact, or search title at the start of the filename.

	Stops The Grinch keeping How the Grinch Stole Christmas when years already match.
	Quality tags after the title still pass (The Grinch.1080p).
	"""
	try:
		all_titles = [title]
		if aliases: all_titles += aliases
		year = str(year or '')
		cleaned_titles = []
		for i in all_titles:
			if not i: continue
			cleaned_titles.append(
				i.lower().replace('\'', '').replace(':', '').replace('!', '').replace('?', '').replace('(', '').replace(')', '').replace('&', 'and').replace(' ', '.').replace(year, ''))
		cleaned_titles = [re.sub(r'\.+', '.', t).strip('.') for t in cleaned_titles if t]
		if not cleaned_titles:
			return True
		strip_years = filename_years(release_title or '') - filename_years(title or '')
		release_key = _folders_movie_dotted_key(release_title, strip_years)
		if not release_key:
			return False
		for item in cleaned_titles:
			if not item:
				continue
			if release_key == item or release_key.startswith(item + '.'):
				return True
		return False
	except Exception:
		return True

def _shared_title_default_peer(peers):
	if len(peers) < 2:
		return None
	ranked = sorted(peers, key=lambda p: (int(p.get('vote_count') or 0), float(p.get('popularity') or 0)), reverse=True)
	top, second = ranked[0], ranked[1]
	v1, v2 = int(top.get('vote_count') or 0), int(second.get('vote_count') or 0)
	p1, p2 = float(top.get('popularity') or 0), float(second.get('popularity') or 0)
	if v1 >= 50 and v1 >= v2 * 2 and (v1 - v2) >= 25:
		return top
	if v1 >= 20 and v1 >= v2 * 3:
		return top
	if p1 >= 20 and p1 >= p2 * 3 and v1 >= v2:
		return top
	return None

def resolve_shared_title_require_year(meta):
	"""True when this TV id is a secondary exact-title series (needs year in name queries/files)."""
	if not meta:
		return False
	media = meta.get('mediatype') or meta.get('media_type')
	if media == 'movie':
		return False
	title = meta.get('english_title') or meta.get('original_title') or meta.get('tvshowtitle') or meta.get('title') or ''
	try:
		tmdb_id = int(meta.get('tmdb_id') or 0)
	except Exception:
		tmdb_id = 0
	try:
		year = int(meta.get('year') or 0)
	except Exception:
		year = 0
	if not title or not tmdb_id:
		return False
	from modules.settings import tmdb_api_key
	if tmdb_api_key() in (None, 'empty_setting', ''):
		return False
	try:
		from apis.tmdb_api import tmdb_tv_search
		data = tmdb_tv_search(title, 1)
	except Exception:
		return False
	results = data.get('results') if isinstance(data, dict) else data
	if not isinstance(results, list):
		return False
	key = _exact_show_title_key(title)
	peers, seen = [], set()
	for row in results:
		name = row.get('name') or ''
		original = row.get('original_name') or ''
		if _exact_show_title_key(name) != key and _exact_show_title_key(original) != key:
			continue
		try:
			peer_id = int(row.get('id') or 0)
			peer_year = int(str(row.get('first_air_date') or '')[:4])
		except Exception:
			continue
		if not peer_id or not peer_year or peer_id in seen:
			continue
		seen.add(peer_id)
		peers.append({
			'id': peer_id, 'year': peer_year,
			'vote_count': row.get('vote_count') or 0,
			'popularity': row.get('popularity') or 0,
			'name': name or original,
		})
	if tmdb_id not in seen and year:
		peers.append({
			'id': tmdb_id, 'year': year,
			'vote_count': meta.get('votes') or 0,
			'popularity': 0,
			'name': title,
		})
	years = set(p['year'] for p in peers)
	default = _shared_title_default_peer(peers)
	return bool(default and tmdb_id != default['id'] and len(years) >= 2)

def _is_longer_title_sibling(title, other):
	a = (title or '').strip().lower()
	b = (other or '').strip().lower()
	if not a or not b or a == b:
		return False
	return b.startswith(a + ' ') or b.startswith(a + ':') or b.startswith(a + '-')

def has_prefix_title_siblings(meta):
	"""True when TMDb has other TV shows whose name is this title plus extra words.

	Same Title Series only covers exact-title twins (year in the name). This is Batman vs
	Batman: Caped Crusader / Batman: The Animated Series, where the year is not required
	on the default series but extra title words still name a different show.
	"""
	if not meta:
		return False
	media = meta.get('mediatype') or meta.get('media_type')
	if media == 'movie':
		return False
	title = meta.get('english_title') or meta.get('original_title') or meta.get('tvshowtitle') or meta.get('title') or ''
	try:
		tmdb_id = int(meta.get('tmdb_id') or 0)
	except Exception:
		tmdb_id = 0
	if not title or not tmdb_id:
		return False
	from modules.settings import tmdb_api_key
	if tmdb_api_key() in (None, 'empty_setting', ''):
		return False
	try:
		from apis.tmdb_api import tmdb_tv_search
		data = tmdb_tv_search(title, 1)
	except Exception:
		return False
	results = data.get('results') if isinstance(data, dict) else data
	if not isinstance(results, list):
		return False
	for row in results:
		try:
			peer_id = int(row.get('id') or 0)
		except Exception:
			continue
		if not peer_id or peer_id == tmdb_id:
			continue
		for name in (row.get('name'), row.get('original_name')):
			if _is_longer_title_sibling(title, name):
				return True
	return False

def tv_scrape_query(title, year, season, episode, require_year, season_only=False):
	if season_only:
		tail = 'S%02d' % int(season)
	else:
		tail = 'S%02dE%02d' % (int(season), int(episode))
	if require_year and year not in (None, '', 0, '0'):
		return '%s %s %s' % (title, year, tail)
	return '%s %s' % (title, tail)

def tv_date_scrape_query(title, premiered):
	"""Name-search query using the episode air date (Show 2026.10.21)."""
	name = (title or '').strip()
	tokens = premiered_release_tokens(premiered)
	if not name or not tokens:
		return ''
	return '%s %s' % (name, tokens[0])

def date_search_titles(title, aliases=None):
	"""Primary title plus short aliases (host names) for a dated second search."""
	names, seen = [], set()
	def _add(name):
		name = (name or '').strip()
		key = name.casefold()
		if not name or key in seen:
			return
		seen.add(key)
		names.append(name)
	_add(title)
	for alias in aliases or []:
		tokens = [t for t in str(alias).split() if t]
		if 2 <= len(tokens) <= 4:
			_add(alias)
	return names

def check_title(title, release_title, aliases, year, season, episode, require_year=False, premiered=None):
	if require_year and season and not release_contains_show_year(release_title, year):
		return False
	try:
		all_titles = [title]
		if aliases: all_titles += aliases
		cleaned_titles = []
		cleaned_titles_append = cleaned_titles.append
		year = str(year)
		for i in all_titles:
			cleaned_titles_append(
				i.lower().replace('\'', '').replace(':', '').replace('!', '').replace('?', '').replace('(', '').replace(')', '').replace('&', 'and').replace(' ', '.').replace(year, ''))
		release_title = strip_non_ascii_and_unprintable(release_title).lstrip('/ ').replace(' ', '.').replace(':', '.').lower()
		releasetitle_startswith = release_title.startswith
		unwanted = unwanted_tags()
		for i in unwanted:
			if releasetitle_startswith(i):
				i_startswith = i.startswith
				pattern = r'\%s' % i if i_startswith('[') or i_startswith('+') else r'%s' % i
				release_title = re.sub(r'^%s' % pattern, '', release_title, 1, re.I)
		release_title = release_title.lstrip('.-:/')
		release_title = re.sub(r'^\[.*?]', '', release_title, 1, re.I)
		release_title = release_title.lstrip('.-[](){}:/')
		if season:
			if season == 'pack': hdlr = ''
			else:
				hdlr = ''
				try: hdlr = seas_ep_filter(season, episode, release_title, return_match=True) or ''
				except: hdlr = ''
				if not hdlr:
					hdlr = premiered_in_release(release_title, premiered, return_match=True) or ''
				if not hdlr:
					return False
		else: hdlr = year
		if hdlr:
			release_title = release_title.split(hdlr.lower())[0]
			release_title = release_title.replace(year, '').replace('(', '').replace(')', '').replace('&', 'and').replace('?', '').rstrip('.-').rstrip('.').rstrip('-').replace(':', '')
			# Episodes: exact show title before SxxExx (Wings must not match Behind The Wings / Super Wings).
			if season and season != 'pack':
				if not any(release_title == i for i in cleaned_titles): return False
			elif not any(item in release_title for item in cleaned_titles): return False
		else:
			release_title = release_title.replace(year, '').replace('(', '').replace(')', '').replace('&', 'and').replace('?', '').rstrip('.-').rstrip('.').rstrip('-').replace(':', '')
			if not any(i in release_title for i in cleaned_titles): return False
		return True
	except: return True

_EP_TITLE_STOPWORDS = frozenset((
	'a', 'an', 'the', 'of', 'and', 'or', 'to', 'in', 'on', 'at', 'for', 'from', 'with', 'vs',
))

def _filename_tokens(text):
	text = _utils_normalize(text or '').lower().replace('&', ' and ').replace("'", '')
	return [t for t in re.split(r'[^a-z0-9]+', text) if t]

def episode_title_keep_tokens(ep_name):
	"""Distinctive TMDb episode-title words, or None when the name is too generic to keep a file."""
	tokens = [t for t in _filename_tokens(ep_name)
		if t not in _EP_TITLE_STOPWORDS and not t.isdigit() and len(t) >= 3]
	if len(tokens) >= 2:
		return tokens
	if len(tokens) == 1 and len(tokens[0]) >= 8:
		return tokens
	return None

def episode_title_in_release(ep_name, release_title):
	needed = episode_title_keep_tokens(ep_name)
	if not needed:
		return False
	hay = set(_filename_tokens(release_title))
	return all(w in hay for w in needed)

def check_title_or_absolute(title, release_title, aliases, year, season, episode, absolute_episode=None, ep_name=None, allow_episode_title=False, require_year=False, premiered=None, accept_s01_absolute=False, alt_season=None, alt_episode=None):
	"""Keep SxxExx hits via check_title, plus Sxx-less files whose bare/absolute episode matches.

	Same title/alias rules as cloud scrapers (pack-style substring) on the absolute path.
	The episode title can help searches find more candidates, but it must not bypass the
	show/alias check unless allow_episode_title is True (EasyNews/NZB Filter by Name option).
	Date-named dailies (Show.Name.2026.10.20) keep when premiered matches, same title rules.
	"""
	pairs = scrape_episode_pairs(season, episode, alt_season, alt_episode)
	for s, e in pairs or [(season, episode)]:
		if check_title(title, release_title, aliases, year, s, e, require_year, premiered=premiered):
			return True
	if not season or season == 'pack':
		return False
	if not pairs:
		return False
	if not cloud_episode_matches(season, episode, release_title, absolute_episode, accept_s01_absolute=accept_s01_absolute, alt_season=alt_season, alt_episode=alt_episode):
		return False
	# SxxExx already names this episode: extra words before it failed check_title.
	# Pack substring would re-admit Batman.Caped.Crusader.S01E01 for title Batman.
	try:
		if any(seas_ep_filter(s, e, release_title) for s, e in pairs):
			if allow_episode_title:
				return episode_title_in_release(ep_name, release_title)
			return False
	except Exception:
		pass
	if check_title(title, release_title, aliases, year, 'pack', episode, require_year):
		return True
	if allow_episode_title:
		return episode_title_in_release(ep_name, release_title)
	return False

def strip_non_ascii_and_unprintable(text):
	"""Accent-fold first so Filter-by-Name keeps Pokémon→Pokemon / Léon→Leon."""
	try:
		text = _utils_normalize(text)
		result = ''.join(char for char in text if char in printable)
		return result.encode('ascii', errors='ignore').decode('ascii', errors='ignore')
	except: pass
	return text

def release_info_format(release_title):
	try:
		release_title = url_strip(release_title)
		release_title = release_title.lower().replace("'", "").lstrip('.').rstrip('.')
		title = '.%s.' % re.sub(r'[^a-z0-9-~]+', '.', release_title).replace('.-.', '.').replace('-.', '.').replace('.-', '.').replace('--', '.')
		return title
	except:
		return release_title.lower()

def clean_title(title):
	try:
		if not title: return
		title = title.lower()
		title = re.sub(r'&#(\d+);', '', title)
		title = re.sub(r'(&#[0-9]+)([^;^0-9]+)', '\\1;\\2', title)
		title = title.replace('&quot;', '\"').replace('&amp;', '&')
		title = re.sub(r'\n|([\[({].+?[})\]])|([:;–\-"\',!_.?~$@])|\s', '', title)
	except: pass
	return title

def url_strip(url):
	try:
		url = unquote_plus(url)
		if 'magnet:' in url: url = url.split('&dn=')[1]
		url = url.lower().replace("'", "").lstrip('.').rstrip('.')
		title = re.sub(r'[^a-z0-9]+', ' ', url)
		if 'http' in title: return None
		if title == '': return None
		return title
	except: return None

def get_file_info(name_info=None, url=None, default_quality='SD'):
	title = None
	if name_info: title = name_info
	elif url: title = url_strip(url)
	if not title: return 'SD', ''
	quality = get_release_quality(title) or default_quality
	info = get_info(title)
	return quality, info

def get_release_quality(release_info):
	if any(i in release_info for i in ('.scr.', 'screener', 'dvdscr', 'dvd.scr', '.r5', '.r6')):
		return 'SCR'
	if any(i in release_info for i in ('.cam.', 'camrip', 'hdcam', '.hd.cam', 'hqcam', '.hq.cam', 'cam.rip', 'dvdcam')):
		return 'CAM'
	if any(i in release_info for i in ('.tc.', '.ts.', 'tsrip', 'hdts', 'hdtc', '.hd.tc', 'dvdts', 'telesync', 'tele.sync', 'telecine', 'tele.cine')):
		return 'TELE'
	if any(i in release_info for i in ('720', '720p', '720i', 'hd720', '720hd', 'hd720p', '72o', '72op')):
		return '720p'
	if any(i in release_info for i in ('1080', '1080p', '1080i', 'hd1080', '1080hd', 'hd1080p', 'm1080p', 'fullhd', 'full.hd', '1o8o', '1o8op',
		'108o', '108op', '1o80', '1o80p')): return '1080p'
	if any(i in release_info for i in ('.4k', 'hd4k', '4khd', '.uhd', 'ultrahd', 'ultra.hd', 'hd2160', '2160hd', '2160', '2160p', '216o', '216op')):
		return '4K'
	return None

def get_info(title):
	# thanks 123Venom and gaiaaaiaai, whom I knicked most of this code from. :)
	info = []
	info_append = info.append
	if any(i in title for i in ('.3d.', '.sbs.', '.hsbs', 'sidebyside', 'side.by.side', 'stereoscopic', '.tab.', '.htab.', 'topandbottom', 'top.and.bottom')):
		info_append('[B]3D[/B]')
	if '.sdr' in title:
		info_append('SDR')
	elif any(i in title for i in ('dolby.vision', 'dolbyvision', '.dovi.', '.dv.')):
		info_append('[B]D/VISION[/B]')
	elif any(i in title for i in ('2160p.bluray.hevc.truehd', '2160p.bluray.hevc.dts', '2160p.bluray.hevc.lpcm', '2160p.blu.ray.hevc.truehd', '2160p.blu.ray.hevc.dts',
		'2160p.uhd.bluray', '2160p.uhd.blu.ray', '2160p.us.bluray.hevc.truehd', '2160p.us.bluray.hevc.dts', '.hdr.', 'hdr10', 'hdr.10', 'uhd.bluray.2160p',
		'uhd.blu.ray.2160p')):
		info_append('[B]HDR[/B]')
	elif all(i in title for i in ('2160p', 'remux')):
		info_append('[B]HDR[/B]')
	if '[B]D/VISION[/B]' in info:
		if any(i in title for i in ('.hdr.', '.hdr10.', 'hdr.10')) or 'hybrid' in title:
			info_append('[B]HDR[/B]')
		if '[B]HDR[/B]' in info:
			info_append('[B]HYBRID[/B]')
	if any(i in title for i in ('avc', 'h264', 'h.264', 'x264', 'x.264')):
		info_append('AVC')
	elif '.av1.' in title:
		info_append('[B]AV1[/B]')
	elif any(i in title for i in ('h265', 'h.265', 'hevc', 'x265', 'x.265')):
		info_append('[B]HEVC[/B]')
	elif any(i in info for i in ('[B]HDR[/B]', '[B]D/VISION[/B]')):
		info_append('[B]HEVC[/B]')
	if any(i in title for i in ('.imax.', '.(imax).', '.(.imax.).')):
		info_append('IMAX')
	elif any(i in title for i in ('.enhanced.', '.upscaled.', '.enhance.', '.upscale.', '.ai.')):
		info_append('[B]AI ENHANCED/UPSCALED[/B]')
	if '.atvp' in title:
		info_append('APPLETV+')
	elif any(i in title for i in ('xvid', '.x.vid')):
		info_append('XVID')
	elif any(i in title for i in ('divx', 'div2', 'div3', 'div4')):
		info_append('DIVX')
	if any(i in title for i in ('remux', 'bdremux')):
		info_append('REMUX')
	if any(i in title for i in ('bluray', 'blu.ray', 'bdrip', 'bd.rip')):
		info_append('BLURAY')
	elif any(i in title for i in ('dvdrip', 'dvd.rip')):
		info_append('DVD')
	elif any(i in title for i in ('.web.', 'webdl', 'web.dl', 'web-dl', 'webrip', 'web.rip')):
		info_append('WEB')
	elif 'hdtv' in title:
		info_append('HDTV')
	elif 'pdtv' in title:
		info_append('PDTV')
	elif any(i in title for i in ('.hdrip', '.hd.rip')):
		info_append('HDRIP')
	if 'atmos' in title:
		info_append('ATMOS')
	if any(i in title for i in ('true.hd', 'truehd')):
		info_append('TRUEHD')
	if any(i in title for i in ('dolby.digital.plus', 'dolbydigital.plus', 'dolbydigitalplus', 'dd.plus.', 'ddplus', '.ddp.', 'ddp2', 'ddp5', 'ddp7', 'eac3', '.e.ac3')):
		info_append('DD+')
	elif any(i in title for i in ('.dd.ex.', 'ddex', 'dolby.ex.', 'dolby.digital.ex.', 'dolbydigital.ex.')):
		info_append('DD-EX')
	elif any(i in title for i in ('dd2.', 'dd5', 'dd7', 'dolby.digital', 'dolbydigital', '.ac3', '.ac.3.', '.dd.')):
		info_append('DD')
	if 'aac' in title:
		info_append('AAC')
	elif 'mp3' in title:
		info_append('MP3')
	elif '.flac.' in title:
		info_append('FLAC')
	elif 'opus' in title and not title.endswith('opus.'):
		info_append('OPUS')
	if any(i in title for i in ('.dts.x.', 'dtsx')):
		info_append('DTS-X')
	elif any(i in title for i in ('hd.ma', 'hdma')):
		info_append('DTS-HD MA')
	elif any(i in title for i in ('dts.hd.', 'dtshd')):
		info_append('DTS-HD')
	elif '.dts' in title:
		info_append('DTS')
	if any(i in title for i in ('ch8.', '8ch.', '7.1ch', '7.1.')):
		info_append('8CH')
	elif any(i in title for i in ('ch7.', '7ch.', '6.1ch', '6.1.')):
		info_append('7CH')
	elif any(i in title for i in ('ch6.', '6ch.', '5.1ch', '5.1.')):
		info_append('6CH')
	elif any(i in title for i in ('ch2', '2ch', '2.0ch', '2.0.', 'audio.2.0.', 'stereo')):
		info_append('2CH')
	if '.wmv' in title:
		info_append('WMV')
	elif any(i in title for i in ('.mp4', '.m4p', '.m4v')):
		info_append('MP4')
	elif any(i in title for i in ('.mpg', '.mp2', '.mpeg', '.mpe', '.mpv', 'msmpeg', 'mpegurl')):
		info_append('MPEG')
	elif '.avi' in title:
		info_append('AVI')
	elif any(i in title for i in ('.mkv', 'matroska')):
		info_append('MKV')
	# audio language tags: subtitle-adjacent codes (eng.subs, subs.eng) are subtitles, not audio
	lang_title = re.sub(r'\.(subs?|subbed)\.([a-z]{2,12})\.', '.', title)
	lang_title = re.sub(r'\.([a-z]{2,12})\.(subs?|subbed)\.', '.', lang_title)
	for _, lang_tag, lang_patterns in audio_lang_choices():
		if any(i in lang_title for i in lang_patterns):
			info_append(lang_tag)
	if any(i in title for i in ('hindi.eng', 'ara.eng', 'ces.eng', 'chi.eng', 'cze.eng', 'dan.eng', 'dut.eng', 'ell.eng', 'esl.eng', 'esp.eng', 'fin.eng', 'fra.eng',
		'fre.eng', 'frn.eng', 'gai.eng', 'ger.eng', 'gle.eng', 'gre.eng', 'gtm.eng', 'heb.eng', 'hin.eng', 'hun.eng', 'ind.eng', 'iri.eng', 'ita.eng', 'jap.eng',
		'jpn.eng', 'kor.eng', 'lat.eng', 'lebb.eng', 'lit.eng', 'nor.eng', 'pol.eng', 'por.eng', 'rus.eng', 'som.eng', 'spa.eng', 'sve.eng', 'swe.eng', 'tha.eng',
		'tur.eng', 'uae.eng', 'ukr.eng', 'vie.eng', 'zho.eng', 'dual.audio', 'multi')):
		info_append('MULTI-LANG')
	if any(i in title for i in ('1xbet', 'betwin')):
		info_append('ADS')
	if any(i in title for i in ('subita', 'subfrench', 'subspanish', 'subtitula', 'swesub', 'nl.subs', 'subbed')):
		info_append('SUBS')
	return ' | '.join(filter(None, info))

def get_cache_expiry(media_type, meta, season):
	try:
		current_date = get_datetime()
		if media_type == 'movie':
			premiered = jsondate_to_datetime(meta['premiered'], '%Y-%m-%d', remove_time=True)
			difference = subtract_dates(current_date, premiered)
			if difference == 0: single_expiry = 3
			elif difference <= 7: single_expiry = 24
			elif difference <= 14: single_expiry = 48
			elif difference <= 21: single_expiry = 72
			elif difference <= 30: single_expiry = 96
			elif difference <= 60: single_expiry = 168
			else: single_expiry = 336
			season_expiry, show_expiry = 0, 0
		else:
			recently_ended = False
			extra_info = meta['extra_info']
			ended = extra_info['status'] in ('Ended', 'Canceled')
			premiered = adjust_premiered_date(meta['premiered'], date_offset())[0]
			difference = subtract_dates(current_date, premiered)
			last_episode_to_air = jsondate_to_datetime(extra_info['last_episode_to_air']['air_date'], '%Y-%m-%d', remove_time=True)
			last_ep_difference = subtract_dates(current_date, last_episode_to_air)
			if ended and last_ep_difference <= 14: recently_ended = True
			if not ended or recently_ended:
				if difference == 0: single_expiry = 3
				elif difference <= 3: single_expiry = 24
				elif difference <= 7: single_expiry = 72
				else: single_expiry = 168
				if meta['total_seasons'] == season:
					if last_ep_difference <= 7: season_expiry = 72
					else: season_expiry = 240
				else: season_expiry = 720
				show_expiry = 240
			else: single_expiry, season_expiry, show_expiry = 240, 720, 720
	except: single_expiry, season_expiry, show_expiry = 72, 72, 240
	return single_expiry, season_expiry, show_expiry

def get_external_cache_status(debrid, unchecked_hashes, data, active_debrid):
	def _process(service, hashes):
		result = []
		if service in ('mediafusion', 'torrentio'):
			if service == 'mediafusion':
				base_link, name_test = 'https://mediafusion.elfhosted.com/%s=%s' % (debrid_name, token), '⚡'
				params = json.dumps({'enable_catalogs': False, 'max_streams_per_resolution': 99, 'torrent_sorting_priority':[], 'certification_filter': ['Disable'],
											'nudity_filter': ['Disable'], 'streaming_provider': {'token': token, 'service': debrid_name,
											'only_show_cached_streams': True}}).encode('utf-8')
				headers = {'encoded_user_data': base64.b64encode(params).decode('utf-8')}
			elif service == 'torrentio':
				base_link, name_test = 'https://torrentio.strem.fun/%s=%s' % (debrid_name, token), '[RD+]'
				headers = {'User-Agent': 'Mozilla/5.0'}
			try:
				if 'tvshowtitle' in data: url = '%s%s' % (base_link, '/stream/series/%s:%s:%s.json' % (imdb_id, data['season'], data['episode']))
				else: url = '%s%s' % (base_link, '/stream/movie/%s.json' % imdb_id)
				result = requests.get(url, headers=headers, timeout=9)
				result = result.json()['streams']
				if result:
					result = [re.search(r'\b\w{40}\b', i.get('url')) for i in result if name_test in i['name']]
					result = [i.group() for i in result if i]
			except: pass
		elif service == 'dmm':
			import ctypes, random
			def get_secret():
				def calc_value_alg(t, n, const):
					temp = t ^ n
					t = ctypes.c_long((temp * const)).value
					t4 = ctypes.c_long(t << 5).value
					t5 = ctypes.c_long((t & 0xFFFFFFFF) >> 27).value
					return t4 | t5
				def slice_hash(s, n):
					half = int(len(s) // 2)
					left_s, right_s = s[:half], s[half:]
					left_n, right_n = n[:half], n[half:]
					l = ''.join(ls + ln for ls, ln in zip(left_s, left_n))
					return l + right_n[::-1] + right_s[::-1]
				def generate_hash(e):
					t = ctypes.c_long(0xDEADBEEF ^ len(e)).value
					a = 1103547991 ^ len(e)
					for ch in e:
						n = ord(ch)
						t = calc_value_alg(t, n, 2654435761)
						a = calc_value_alg(a, n, 1597334677)
					t = ctypes.c_long(t + ctypes.c_long(a * 1566083941).value).value
					a = ctypes.c_long(a + ctypes.c_long(t * 2024237689).value).value
					return (ctypes.c_long(t ^ a).value & 0xFFFFFFFF)
				ran = random.randrange(10 ** 80)
				hex_str = f"{ran:064x}"[:8]
				timestamp = int(time.time())
				dmmProblemKey = f"{hex_str}-{timestamp}"
				s = generate_hash(dmmProblemKey)
				s = f"{s:x}"
				n = generate_hash("debridmediamanager.com%%fe7#td00rA3vHz%VmI-" + hex_str)
				n = f"{n:x}"
				solution = slice_hash(s, n)
				return dmmProblemKey, solution
			def fetch(hash_chunk):
				try:
					json_data = {'dmmProblemKey': dmmProblemKey, 'solution': solution, 'imdbId': imdb_id, 'hashes': hash_chunk}
					r = requests.post('https://debridmediamanager.com/api/availability/check', json=json_data, timeout=9).json()
					r = [i['hash'] for i in r['available'] if 'hash' in i]
					result_extend(r)
				except: pass
			result = []
			result_extend = result.extend
			dmmProblemKey, solution = get_secret()
			unchecked_hashes_chunks = list(chunks(unchecked_hashes, 100))
			threads = [Thread(target=fetch, args=(item,)) for item in unchecked_hashes_chunks]
			[i.start() for i in threads]
			[i.join() for i in threads]
		results.extend(result)
	try:
		results = []
		imdb_id = data['imdb']
		debrid_name, services, token = {'Real-Debrid': ('realdebrid', ['torrentio'], get_setting('redlight.rd.token')),
										'AllDebrid': ('alldebrid', ['mediafusion'], get_setting('redlight.ad.token'))}[debrid]
		threads = [Thread(target=_process, args=(item, unchecked_hashes)) for item in services]
		[i.start() for i in threads]
		[i.join() for i in threads]
		results = list(set(results))
	except: pass
	if debrid == 'Real-Debrid':
		try: _process('dmm', [i for i in unchecked_hashes if not i in results])
		except: pass
	return results