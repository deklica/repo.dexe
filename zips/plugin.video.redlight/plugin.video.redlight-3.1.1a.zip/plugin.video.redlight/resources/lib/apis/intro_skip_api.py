# -*- coding: utf-8 -*-
import requests
from caches.main_cache import main_cache

THEINTRODB_URL = 'https://api.theintrodb.org/v3/media'
INTRODB_URL = 'https://api.introdb.app/segments'
_CACHE_HOURS = 168
_API_TIMEOUT = 6
_MIN_SEGMENT_SEC = 10
_MIN_END_SEC = 15
_MAX_SEGMENT_SEC = 600
_MAX_INTRO_START_FRAC = 0.5
_MIN_CREDITS_START_FRAC = 0.5
_CREDITS_DURATION_SLACK_SEC = 15
_CREDITS_INTRO_OVERLAP_MS = 5000


def _intro_cache_key(tmdb_id, imdb_id, season, episode):
	return 'intro_skip_v2_%s_%s_%s_%s' % (tmdb_id, imdb_id or '', season, episode)


def _outro_cache_key(tmdb_id, imdb_id, season, episode):
	return 'outro_credits_%s_%s_%s_%s' % (tmdb_id, imdb_id or '', season, episode)


def peek_intro_segment_cache(tmdb_id, imdb_id, season, episode, duration_sec=None):
	try:
		season, episode = int(season), int(episode)
	except:
		return '__miss__'
	cached = main_cache.get(_intro_cache_key(tmdb_id, imdb_id, season, episode))
	if cached is None:
		return '__miss__'
	if not cached:
		return None
	segment = _valid_segment(cached.get('start_sec'), cached.get('end_sec'), duration_sec)
	if segment:
		segment['source'] = cached.get('source', 'introdb')
		return segment
	return '__miss__'


def prefetch_intro_segment(tmdb_id, imdb_id, season, episode, duration_sec=None):
	try:
		resolve_intro_segment(tmdb_id, imdb_id, season, episode, duration_sec)
	except:
		pass


def prefetch_credits_start(tmdb_id, imdb_id, season, episode, duration_sec=None):
	try:
		resolve_credits_start_sec(tmdb_id, imdb_id, season, episode, duration_sec)
	except:
		pass


def _recap_cache_key(tmdb_id, imdb_id, season, episode):
	return 'recap_skip_%s_%s_%s_%s' % (tmdb_id, imdb_id or '', season, episode)


def peek_recap_segments_cache(tmdb_id, imdb_id, season, episode, duration_sec=None):
	try:
		season, episode = int(season), int(episode)
	except:
		return '__miss__'
	cached = main_cache.get(_recap_cache_key(tmdb_id, imdb_id, season, episode))
	if cached is None:
		return '__miss__'
	if not cached:
		return None
	segments = _revalidate_recap_segments(cached, duration_sec)
	if segments:
		return segments
	return '__miss__'


def prefetch_recap_segments(tmdb_id, imdb_id, season, episode, duration_sec=None):
	try:
		resolve_recap_segments(tmdb_id, imdb_id, season, episode, duration_sec)
	except:
		pass


def resolve_recap_segments(tmdb_id, imdb_id, season, episode, duration_sec=None):
	try:
		season, episode = int(season), int(episode)
	except:
		return None
	cache_key = _recap_cache_key(tmdb_id, imdb_id, season, episode)
	cached = main_cache.get(cache_key)
	if cached is not None:
		if not cached:
			return None
		segments = _revalidate_recap_segments(cached, duration_sec)
		if segments:
			return segments
		main_cache.set(cache_key, '', expiration=_CACHE_HOURS)
	segments = None
	if tmdb_id not in (None, '', 'None', '0000000'):
		segments = _fetch_theintrodb_recaps(tmdb_id, season, episode, duration_sec)
	if not segments and imdb_id not in (None, '', 'None', 'tt0000000'):
		segments = _fetch_introdb_recaps(imdb_id, season, episode, duration_sec)
	main_cache.set(cache_key, segments or '', expiration=_CACHE_HOURS)
	return segments


def resolve_intro_segment(tmdb_id, imdb_id, season, episode, duration_sec=None):
	try:
		season, episode = int(season), int(episode)
	except:
		return None
	cache_key = _intro_cache_key(tmdb_id, imdb_id, season, episode)
	recaps = _recaps_for_intro_filter(tmdb_id, imdb_id, season, episode, duration_sec)
	cached = main_cache.get(cache_key)
	if cached is not None:
		if not cached:
			return None
		segment = _valid_segment(cached.get('start_sec'), cached.get('end_sec'), duration_sec)
		if segment and not _intro_inside_any_recap(segment, recaps):
			segment['source'] = cached.get('source', 'introdb')
			return segment
	segment = None
	if tmdb_id not in (None, '', 'None', '0000000'):
		for candidate in _fetch_theintrodb_intros(tmdb_id, season, episode, duration_sec):
			if not _intro_inside_any_recap(candidate, recaps):
				segment = candidate
				break
	if not segment and imdb_id not in (None, '', 'None', 'tt0000000'):
		candidate = _fetch_introdb_intro(imdb_id, season, episode)
		if candidate and not _intro_inside_any_recap(candidate, recaps):
			segment = candidate
	main_cache.set(cache_key, segment or '', expiration=_CACHE_HOURS)
	return segment


def _unpack_credits_cache(cached):
	if cached == '':
		return {'start_sec': None, 'duration_sec': None}
	if isinstance(cached, dict):
		start_sec, duration_sec = cached.get('start_sec'), cached.get('duration_sec')
		if start_sec in ('', None):
			start_sec = None
		return {'start_sec': start_sec, 'duration_sec': duration_sec}
	try:
		return {'start_sec': float(cached), 'duration_sec': None}
	except:
		return {'start_sec': None, 'duration_sec': None}


def _credits_duration_close(cached_duration, duration_sec):
	if cached_duration is None or duration_sec is None:
		return False
	try:
		return abs(float(cached_duration) - float(duration_sec)) <= _CREDITS_DURATION_SLACK_SEC
	except:
		return False


def _pack_credits_cache(start_sec, duration_sec):
	return {'start_sec': start_sec, 'duration_sec': duration_sec}


def usable_credits_start(start_sec, duration_sec=None):
	start_sec = _valid_start_sec(start_sec, duration_sec)
	if start_sec is None:
		return None
	if duration_sec:
		try:
			total = float(duration_sec)
			if total > 60 and start_sec < total * _MIN_CREDITS_START_FRAC:
				return None
		except:
			pass
	return start_sec


def resolve_credits_start_sec(tmdb_id, imdb_id, season, episode, duration_sec=None):
	try:
		season, episode = int(season), int(episode)
	except:
		return None
	try:
		duration_sec = float(duration_sec) if duration_sec not in (None, '', 0, 0.0) else None
	except:
		duration_sec = None
	if duration_sec is not None and duration_sec < 60:
		duration_sec = None
	cache_key = _outro_cache_key(tmdb_id, imdb_id, season, episode)
	cached = main_cache.get(cache_key)
	packed = _unpack_credits_cache(cached) if cached is not None else None
	if duration_sec:
		if packed and _credits_duration_close(packed.get('duration_sec'), duration_sec):
			if packed.get('start_sec') is None:
				return None
			start_sec = usable_credits_start(packed.get('start_sec'), duration_sec)
			if start_sec is not None:
				return start_sec
			main_cache.set(cache_key, _pack_credits_cache(None, duration_sec), expiration=_CACHE_HOURS)
			return None
		start_sec = _fetch_credits_start_sec(tmdb_id, imdb_id, season, episode, duration_sec)
		start_sec = usable_credits_start(start_sec, duration_sec)
		main_cache.set(cache_key, _pack_credits_cache(start_sec, duration_sec), expiration=_CACHE_HOURS)
		return start_sec
	if packed and packed.get('duration_sec') is not None:
		if packed.get('start_sec') is None:
			return None
		return usable_credits_start(packed.get('start_sec'), packed.get('duration_sec'))
	if packed:
		return packed.get('start_sec')
	start_sec = _fetch_credits_start_sec(tmdb_id, imdb_id, season, episode, None)
	main_cache.set(cache_key, _pack_credits_cache(start_sec, None), expiration=_CACHE_HOURS)
	return start_sec


def _fetch_credits_start_sec(tmdb_id, imdb_id, season, episode, duration_sec):
	start_sec = None
	if tmdb_id not in (None, '', 'None', '0000000'):
		start_sec = _fetch_theintrodb_credits(tmdb_id, season, episode, duration_sec)
	if start_sec is None and imdb_id not in (None, '', 'None', 'tt0000000'):
		start_sec = _fetch_introdb_outro(imdb_id, season, episode, duration_sec)
	return start_sec


def _valid_start_sec(start_sec, duration_sec=None):
	try:
		start_sec = float(start_sec)
	except:
		return None
	if start_sec < 0:
		return None
	if duration_sec:
		try:
			total = float(duration_sec)
			if total > 60 and start_sec > total:
				return None
		except:
			pass
	return start_sec


def _valid_segment(start_sec, end_sec, duration_sec=None):
	try:
		start_sec, end_sec = float(start_sec), float(end_sec)
	except:
		return None
	if end_sec <= start_sec:
		return None
	length = end_sec - start_sec
	if length < _MIN_SEGMENT_SEC or length > _MAX_SEGMENT_SEC:
		return None
	if end_sec < _MIN_END_SEC:
		return None
	if duration_sec:
		try:
			total = float(duration_sec)
			if total > 60:
				if end_sec > total:
					return None
				if start_sec > total * _MAX_INTRO_START_FRAC:
					return None
		except:
			pass
	return {'start_sec': start_sec, 'end_sec': end_sec}


def _ms_segment(start_ms, end_ms, duration_sec=None):
	if start_ms is None:
		start_ms = 0
	try:
		start_ms, end_ms = int(start_ms), int(end_ms)
	except:
		return None
	if end_ms <= start_ms:
		return None
	return _valid_segment(start_ms / 1000.0, end_ms / 1000.0, duration_sec)


def _credits_start_ms_list(credits_list):
	starts = []
	for entry in credits_list or []:
		ms = entry.get('start_ms') if isinstance(entry, dict) else None
		if ms is None:
			continue
		try:
			starts.append(int(ms))
		except:
			pass
	return starts


def _intro_is_credits_duplicate(start_ms, credits_starts):
	if not credits_starts:
		return False
	try:
		start_ms = 0 if start_ms is None else int(start_ms)
	except:
		return False
	for credit_ms in credits_starts:
		if abs(start_ms - credit_ms) <= _CREDITS_INTRO_OVERLAP_MS:
			return True
		if start_ms >= credit_ms:
			return True
	return False


def _parse_start_value(start_val, end_val=None):
	if start_val is None:
		return None
	try:
		start_sec = float(start_val)
		if start_sec > 10000:
			start_sec = start_sec / 1000.0
		return start_sec
	except:
		return None


def _intro_inside_recap(segment, recap):
	# 11.5-66.9 inside recap 0-66 is the recap mistagged as an intro.
	# 403-461 is not. Same start and end stays a same-zone skip, not "inside".
	try:
		i_start, i_end = float(segment['start_sec']), float(segment['end_sec'])
		r_start, r_end = float(recap['start_sec']), float(recap['end_sec'])
	except:
		return False
	if abs(i_start - r_start) <= 5 and abs(i_end - r_end) <= 5:
		return False
	return i_start >= r_start and i_end <= r_end + 5


def _intro_inside_any_recap(segment, recaps):
	for recap in recaps or []:
		if _intro_inside_recap(segment, recap):
			return True
	return False


def _recaps_for_intro_filter(tmdb_id, imdb_id, season, episode, duration_sec=None):
	try:
		return resolve_recap_segments(tmdb_id, imdb_id, season, episode, duration_sec) or []
	except:
		return []


def _fetch_theintrodb_intros(tmdb_id, season, episode, duration_sec=None):
	try:
		params = {'tmdb_id': str(tmdb_id), 'season': season, 'episode': episode}
		if duration_sec:
			try:
				params['durationMs'] = int(float(duration_sec) * 1000)
			except:
				pass
		response = requests.get(THEINTRODB_URL, params=params, timeout=_API_TIMEOUT)
		if response.status_code != 200:
			return []
		data = response.json()
		credits_starts = _credits_start_ms_list(data.get('credits') or [])
		segments = []
		for entry in _as_entries(data.get('intro')):
			start_ms = entry.get('start_ms')
			if _intro_is_credits_duplicate(start_ms, credits_starts):
				continue
			segment = _ms_segment(start_ms, entry.get('end_ms'), duration_sec)
			if not segment:
				continue
			segment['source'] = 'theintrodb'
			segments.append(segment)
		segments.sort(key=lambda seg: seg['start_sec'])
		return segments
	except:
		return []


def _fetch_theintrodb_intro(tmdb_id, season, episode, duration_sec=None):
	segments = _fetch_theintrodb_intros(tmdb_id, season, episode, duration_sec)
	return segments[0] if segments else None


def _fetch_introdb_intro(imdb_id, season, episode):
	try:
		params = {'imdb_id': str(imdb_id), 'season': season, 'episode': episode, 'segment_type': 'intro'}
		response = requests.get(INTRODB_URL, params=params, timeout=_API_TIMEOUT)
		if response.status_code != 200:
			return None
		data = response.json()
		intro = data.get('intro')
		if not intro or not isinstance(intro, dict):
			return None
		start_sec = _parse_start_value(intro.get('start_sec', intro.get('start_ms')))
		end_sec = _parse_start_value(intro.get('end_sec', intro.get('end_ms')))
		if start_sec is None:
			start_sec = 0.0
		segment = _valid_segment(start_sec, end_sec)
		if segment:
			segment['source'] = 'introdb'
		return segment
	except:
		return None


def _fetch_introdb_outro(imdb_id, season, episode, duration_sec=None):
	try:
		params = {'imdb_id': str(imdb_id), 'season': season, 'episode': episode}
		response = requests.get(INTRODB_URL, params=params, timeout=_API_TIMEOUT)
		if response.status_code != 200:
			return None
		outro = response.json().get('outro') or {}
		start_sec = _parse_start_value(outro.get('start_sec', outro.get('start_ms')))
		return _valid_start_sec(start_sec, duration_sec)
	except:
		return None


def _fetch_theintrodb_credits(tmdb_id, season, episode, duration_sec=None):
	try:
		params = {'tmdb_id': str(tmdb_id), 'season': season, 'episode': episode}
		if duration_sec:
			try:
				params['durationMs'] = int(float(duration_sec) * 1000)
			except:
				pass
		response = requests.get(THEINTRODB_URL, params=params, timeout=_API_TIMEOUT)
		if response.status_code != 200:
			return None
		credits_list = response.json().get('credits') or []
		if not credits_list:
			return None
		entry = credits_list[0]
		if entry.get('start_ms') is None:
			return None
		return _valid_start_sec(int(entry['start_ms']) / 1000.0, duration_sec)
	except:
		return None


def _as_entries(value):
	if isinstance(value, dict):
		return [value]
	if isinstance(value, list):
		return [entry for entry in value if isinstance(entry, dict)]
	return []


def _same_segment_window(left, right):
	try:
		return (abs(float(left['start_sec']) - float(right['start_sec'])) <= 5
			and abs(float(left['end_sec']) - float(right['end_sec'])) <= 5)
	except:
		return False


def _entry_segment(entry, duration_sec, milliseconds=False):
	if not isinstance(entry, dict):
		return None
	if milliseconds:
		return _ms_segment(entry.get('start_ms'), entry.get('end_ms'), duration_sec)
	start_sec = _parse_start_value(entry.get('start_sec', entry.get('start_ms')))
	end_sec = _parse_start_value(entry.get('end_sec', entry.get('end_ms')))
	if start_sec is None:
		start_sec = 0.0
	return _valid_segment(start_sec, end_sec, duration_sec)


def _revalidate_recap_segments(cached, duration_sec):
	if not isinstance(cached, list):
		return None
	segments = []
	for item in cached:
		segment = _entry_segment(item, duration_sec, milliseconds=False)
		if not segment:
			continue
		segment['source'] = item.get('source', 'introdb') if isinstance(item, dict) else 'introdb'
		segments.append(segment)
	segments.sort(key=lambda seg: seg['start_sec'])
	return segments or None


def _collect_recap_segments(entries, intro_entries, credits_starts, duration_sec, source, milliseconds=False):
	intro_segments = []
	for entry in intro_entries:
		segment = _entry_segment(entry, duration_sec, milliseconds)
		if segment:
			intro_segments.append(segment)
	segments = []
	for entry in entries:
		if milliseconds:
			if _intro_is_credits_duplicate(entry.get('start_ms'), credits_starts):
				continue
		else:
			start_sec = _parse_start_value(entry.get('start_sec', entry.get('start_ms')))
			start_ms = None if start_sec is None else int(float(start_sec) * 1000)
			if _intro_is_credits_duplicate(start_ms, credits_starts):
				continue
		segment = _entry_segment(entry, duration_sec, milliseconds)
		if not segment:
			continue
		if any(_same_segment_window(segment, intro) for intro in intro_segments):
			continue
		segment['source'] = source
		if any(_same_segment_window(segment, existing) for existing in segments):
			continue
		segments.append(segment)
	segments.sort(key=lambda seg: seg['start_sec'])
	return segments or None


def _fetch_theintrodb_recaps(tmdb_id, season, episode, duration_sec=None):
	try:
		params = {'tmdb_id': str(tmdb_id), 'season': season, 'episode': episode}
		if duration_sec:
			try:
				params['durationMs'] = int(float(duration_sec) * 1000)
			except:
				pass
		response = requests.get(THEINTRODB_URL, params=params, timeout=_API_TIMEOUT)
		if response.status_code != 200:
			return None
		data = response.json()
		credits_starts = _credits_start_ms_list(data.get('credits') or [])
		return _collect_recap_segments(
			_as_entries(data.get('recap')), _as_entries(data.get('intro')),
			credits_starts, duration_sec, 'theintrodb', milliseconds=True)
	except:
		return None


def _fetch_introdb_recaps(imdb_id, season, episode, duration_sec=None):
	try:
		params = {'imdb_id': str(imdb_id), 'season': season, 'episode': episode}
		response = requests.get(INTRODB_URL, params=params, timeout=_API_TIMEOUT)
		if response.status_code != 200:
			return None
		data = response.json()
		outro = data.get('outro') or {}
		start_sec = _parse_start_value(outro.get('start_sec', outro.get('start_ms')))
		credits_starts = [int(float(start_sec) * 1000)] if start_sec is not None else []
		return _collect_recap_segments(
			_as_entries(data.get('recap')), _as_entries(data.get('intro')),
			credits_starts, duration_sec, 'introdb', milliseconds=False)
	except:
		return None
