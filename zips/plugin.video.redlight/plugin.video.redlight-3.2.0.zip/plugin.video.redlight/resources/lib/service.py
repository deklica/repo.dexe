# -*- coding: utf-8 -*-
from modules.ipv6_fallback import install as ipv6_fallback
ipv6_fallback()
from xbmc import Monitor
import os
import json
from time import time
from threading import Thread
from caches.settings_cache import get_setting, set_setting, sync_settings
from modules import kodi_utils

pause_services_prop = 'redlight.pause_services'
# In-session updates from before 2.0 keep the old service's settings in memory.
# A Kodi restart is what applies the current settings cache.
_SETTINGS_RESTART_BEFORE = (2, 0, 0)
current_skin_prop = 'redlight.current_skin'
trakt_service_string = 'TraktMonitor Service Update %s - %s'
trakt_success_line_dict = {'success': 'Trakt Update Performed', 'no account': '(Unauthorised) Trakt Update Performed'}
update_string = 'Next Update in %s minutes...'

def _refresh_widgets_after_sync(provider_index, label):
	from modules.settings import provider_sync_refresh_widgets
	if not provider_sync_refresh_widgets(provider_index): return
	try:
		kodi_utils.refresh_widgets_after_provider_sync()
	except Exception as exc:
		kodi_utils.logger('Red Light', '%s widget refresh skipped: %s' % (label, exc))

def _start_daemon(target):
	Thread(target=target, daemon=True).start()

def _run_safe(cls, label):
	try: cls().run()
	except Exception as e: kodi_utils.logger(label, str(e))

def _version_tuple(version):
	parts = []
	for token in str(version or '').replace('-', '.').replace('+', '.').split('.'):
		digits = ''.join(c for c in token if c.isdigit())
		if not digits: continue
		parts.append(int(digits))
		if len(parts) == 3: break
	while len(parts) < 3: parts.append(0)
	return tuple(parts[:3])

def _stored_addon_version():
	try:
		from caches.settings_cache import settings_cache
		value = settings_cache.read_db_value('addon.last_version')
		if value in (None, '', 'empty_setting'): return ''
		return str(value)
	except: return ''

def _remember_addon_version(version):
	try: set_setting('addon.last_version', version, provider_sync=False)
	except: pass

def _toast_restart_after_old_update():
	try:
		monitor = Monitor()
		if monitor.waitForAbort(8): return
		if kodi_utils.service_shutting_down(monitor): return
		kodi_utils.notification('Restart Kodi to finish updating Red Light settings', 8000)
	except Exception as e:
		kodi_utils.logger('SetAddonConstants', str(e))

class SetAddonConstants:
	def run(self):
		kodi_utils.logger('Red Light', 'SetAddonConstants Service Starting')
		import random
		import xbmc
		# Guard against the ~200ms window where the addon ID is temporarily
		# unregistered when a new invoker starts immediately after a force-kill
		# during an update.  Uses waitForAbort so the wait exits immediately if
		# Kodi sends an abort signal (e.g. the build is shutting down).
		_mon = xbmc.Monitor()
		for _attempt in range(20):
			try:
				kodi_utils.addon_info('version')
				break
			except Exception:
				if _mon.waitForAbort(0.25):
					return kodi_utils.logger('SetAddonConstants', 'Aborted during addon ID wait')
		else:
			return kodi_utils.logger('SetAddonConstants', 'Addon ID still unknown after retries — aborting')
		new_version = kodi_utils.addon_info('version')
		prev_version = kodi_utils.get_property('redlight.addon_version') or _stored_addon_version()
		if prev_version and prev_version != new_version:
			try:
				from caches.settings_cache import clear_settings_boot_state
				clear_settings_boot_state(clear_deferred=True)
			except: pass
			kodi_utils.clear_addon_xml_sync_version()
			kodi_utils.logger('Red Light', 'SetAddonConstants - version %s -> %s' % (prev_version, new_version))
			if _version_tuple(prev_version) < _SETTINGS_RESTART_BEFORE:
				_start_daemon(_toast_restart_after_old_update)
		icon_choice = get_setting('addon_icon_choice', 'resources/media/addon_icons/icon.png')
		addon_path = kodi_utils.addon_info('path')
		icon_path = kodi_utils.translate_path(os.path.join(addon_path, icon_choice))
		icon_mini = os.path.join(addon_path, 'resources', 'media', 'addon_icons', 'minis', os.path.basename(icon_path))
		addon_items = [
			('redlight.playback_key', str(random.randint(1000, 10000))),
			('redlight.addon_version', new_version),
			('redlight.addon_path', addon_path),
			('redlight.addon_profile', kodi_utils.translate_path(kodi_utils.addon_info('profile'))),
			('redlight.addon_icon', icon_path),
			('redlight.addon_icon_mini', icon_mini),
			('redlight.addon_fanart', kodi_utils.addon_fanart())
					]
		for item in addon_items: kodi_utils.set_property(*item)
		kodi_utils.clear_property('redlight.widgets_refresh_scheduled')
		kodi_utils.clear_property('redlight.language_invoker_ready')
		kodi_utils.clear_property('redlight.addon_xml_applied')
		kodi_utils.clear_property(kodi_utils.SHUTTING_DOWN_PROP)
		kodi_utils.reset_boot_sync_gate()
		try:
			from modules.utils import _prune_qr_cache
			_prune_qr_cache(kodi_utils.translate_path(kodi_utils.addon_info('profile')))
		except: pass
		_remember_addon_version(new_version)
		return kodi_utils.logger('Red Light', 'SetAddonConstants Service Finished')

class DatabaseMaintenance:
	def run(self):
		kodi_utils.logger('Red Light', 'DatabaseMaintenance Service Starting')
		from caches.base_cache import check_databases_integrity
		check_databases_integrity(silent=True)
		return kodi_utils.logger('Red Light', 'DatabaseMaintenance Service Finished')

class SyncSettings:
	def run(self):
		kodi_utils.logger('Red Light', 'SyncSettings Service Starting')
		from caches.settings_cache import sync_settings, settings_sync_needed
		if not settings_sync_needed():
			return kodi_utils.logger('Red Light', 'SyncSettings Service Skipped')
		sync_settings({'load_properties': False})
		return kodi_utils.logger('Red Light', 'SyncSettings Service Finished')

class BootstrapSettings:
	def run(self, monitor):
		from caches.settings_cache import (
			bootstrap_settings_needed, bootstrap_settings_properties,
			refresh_widgets_after_db_migration, run_deferred_setup_background_if_needed,
			service_bootstrap_needed, widgets_refresh_after_migration_needed, _properties_loaded,
		)
		if not service_bootstrap_needed():
			return
		kodi_utils.logger('Red Light', 'BootstrapSettings Service Starting')
		try:
			from modules.sources import clear_orphan_nextep_play_stash
			clear_orphan_nextep_play_stash()
		except:
			pass
		if bootstrap_settings_needed() and not _properties_loaded():
			monitor.waitForAbort(2)
		if kodi_utils.service_shutting_down(monitor): return
		try:
			if bootstrap_settings_needed():
				bootstrap_settings_properties()
			if not kodi_utils.service_shutting_down(monitor) and widgets_refresh_after_migration_needed():
				refresh_widgets_after_db_migration()
			run_deferred_setup_background_if_needed()
		except Exception as e:
			kodi_utils.logger('BootstrapSettings', str(e))
		return kodi_utils.logger('Red Light', 'BootstrapSettings Service Finished')

_custom_windows_thread_started = False

def start_custom_windows_prepare(monitor):
	global _custom_windows_thread_started
	if _custom_windows_thread_started: return
	_custom_windows_thread_started = True
	_start_daemon(lambda: CustomWindowsPrepare().run(monitor))

def run_deferred_service_setup():
	global _custom_windows_thread_started
	kodi_utils.logger('Red Light', 'Deferred Service Setup Starting')
	try:
		from windows.base_window import ExtrasUtils
		ExtrasUtils().run()
	except Exception as e: kodi_utils.logger('DeferredServiceSetup', 'ExtrasUtils: %s' % e)
	return kodi_utils.logger('Red Light', 'Deferred Service Setup Finished')

class CustomWindowsPrepare:
	def run(self, monitor):
		kodi_utils.logger('Red Light', 'CustomWindowsPrepare Service Starting')
		from windows.base_window import FontUtils
		player = kodi_utils.kodi_player()
		wait_for_abort, is_playing = monitor.waitForAbort, player.isPlayingVideo
		kodi_utils.clear_property(current_skin_prop)
		font_utils = FontUtils()
		while not monitor.abortRequested():
			font_utils.execute_custom_fonts()
			wait_for_abort(20)
		try: del player
		except: pass
		return kodi_utils.logger('Red Light', 'CustomWindowsPrepare Service Finished')

class TraktMonitor:
	def run(self, monitor):
		kodi_utils.logger('Red Light', 'TraktMonitor Service Starting')
		from apis.trakt_api import trakt_sync_activities
		from modules.settings import trakt_user_active, trakt_sync_interval
		player = kodi_utils.kodi_player()
		wait_for_abort, is_playing = monitor.waitForAbort, player.isPlayingVideo
		wait_for_abort(45)
		while not monitor.abortRequested():
			while is_playing() or kodi_utils.get_property(pause_services_prop) == 'true': wait_for_abort(10)
			wait_time = 1800
			try:
				from caches.settings_cache import sync_kodi_profile_context
				sync_kodi_profile_context()
				sync_interval, wait_time = trakt_sync_interval()
				next_update_string = update_string % sync_interval
				if trakt_user_active(): status = trakt_sync_activities()
				else: status = 'no_auth'
				if status == 'failed': kodi_utils.logger('Red Light', trakt_service_string % ('Failed. Error from Trakt', next_update_string))
				elif status == 'no_auth': kodi_utils.logger('Red Light', trakt_service_string % ('Not Run. No Current Trakt Account', next_update_string))
				else:
					if status in ('success', 'no account'):
						kodi_utils.logger('Red Light', trakt_service_string % ('Success. %s' % trakt_success_line_dict[status], next_update_string))
					else:
						kodi_utils.logger('Red Light', trakt_service_string % ('Success. No Changes Needed', next_update_string))# 'not needed'
					if status in ('success', 'not needed'):
						kodi_utils.mark_boot_trakt_sync_ready()
					if status == 'success' and not kodi_utils.service_shutting_down(monitor):
						try:
							from apis.trakt_api import trakt_prefetch_personal_sync_lists
							trakt_prefetch_personal_sync_lists()
						except Exception as exc:
							kodi_utils.logger('Red Light', 'Trakt list prefetch skipped: %s' % exc)
						_refresh_widgets_after_sync(1, 'Trakt')
			except Exception as e: kodi_utils.logger('Red Light', trakt_service_string % ('Failed', 'The following Error Occured: %s' % str(e)))
			wait_for_abort(wait_time)
		try: del player
		except: pass
		return kodi_utils.logger('Red Light', 'TraktMonitor Service Finished')

class SimklMonitor:
	def run(self, monitor):
		kodi_utils.logger('Red Light', 'SimklMonitor Service Starting')
		from apis.simkl_api import simkl_sync_activities
		from modules.settings import simkl_user_active, simkl_sync_interval
		player = kodi_utils.kodi_player()
		wait_for_abort, is_playing = monitor.waitForAbort, player.isPlayingVideo
		wait_for_abort(45)
		while not monitor.abortRequested():
			while is_playing() or kodi_utils.get_property(pause_services_prop) == 'true': wait_for_abort(10)
			wait_time = 1800
			try:
				from caches.settings_cache import sync_kodi_profile_context
				sync_kodi_profile_context()
				sync_interval, wait_time = simkl_sync_interval()
				next_update_string = 'Simkl Sync finished - Next Sync in %s minutes' % sync_interval
				if simkl_user_active(): status = simkl_sync_activities()
				else: status = 'no_auth'
				if status == 'failed': kodi_utils.logger('Red Light', 'Simkl Sync Failed')
				elif status == 'no_auth': kodi_utils.logger('Red Light', 'Simkl Sync Not Run - No Account')
				else: kodi_utils.logger('Red Light', 'Simkl Sync %s - %s' % ('OK' if status == 'success' else 'No Changes', next_update_string))
				if status == 'success' and not kodi_utils.service_shutting_down(monitor):
					_refresh_widgets_after_sync(2, 'Simkl')
			except Exception as e: kodi_utils.logger('Red Light', 'Simkl Sync Failed: %s' % str(e))
			wait_for_abort(wait_time)
		try: del player
		except: pass
		return kodi_utils.logger('Red Light', 'SimklMonitor Service Finished')

class MdblistMonitor:
	def run(self, monitor):
		kodi_utils.logger('Red Light', 'MDBListMonitor Service Starting')
		from apis.mdblist_api import mdblist_sync_activities
		from modules.settings import mdblist_user_active, mdblist_sync_interval
		player = kodi_utils.kodi_player()
		wait_for_abort, is_playing = monitor.waitForAbort, player.isPlayingVideo
		wait_for_abort(60)
		while not monitor.abortRequested():
			while is_playing() or kodi_utils.get_property(pause_services_prop) == 'true': wait_for_abort(10)
			wait_time = 1800
			try:
				from caches.settings_cache import sync_kodi_profile_context
				sync_kodi_profile_context()
				sync_interval, wait_time = mdblist_sync_interval()
				next_update_string = 'MDBList Sync finished - Next Sync in %s minutes' % sync_interval
				if mdblist_user_active(): status = mdblist_sync_activities()
				else: status = 'no_auth'
				if status == 'failed': kodi_utils.logger('Red Light', 'MDBList Sync Failed')
				elif status == 'no_auth': kodi_utils.logger('Red Light', 'MDBList Sync Not Run - No Account')
				else: kodi_utils.logger('Red Light', 'MDBList Sync %s - %s' % ('OK' if status == 'success' else 'No Changes', next_update_string))
				if status == 'success' and not kodi_utils.service_shutting_down(monitor):
					_refresh_widgets_after_sync(3, 'MDBList')
			except Exception as e: kodi_utils.logger('Red Light', 'MDBList Sync Failed: %s' % str(e))
			wait_for_abort(wait_time)
		try: del player
		except: pass
		return kodi_utils.logger('Red Light', 'MDBListMonitor Service Finished')

class PunchPlayMonitor:
	def run(self, monitor):
		kodi_utils.logger('Red Light', 'PunchPlayMonitor Service Starting')
		from apis.punchplay_api import punchplay_sync_activities
		from modules.settings import punchplay_user_active, punchplay_sync_interval
		player = kodi_utils.kodi_player()
		wait_for_abort, is_playing = monitor.waitForAbort, player.isPlayingVideo
		wait_for_abort(55)
		while not monitor.abortRequested():
			while is_playing() or kodi_utils.get_property(pause_services_prop) == 'true': wait_for_abort(10)
			wait_time = 1800
			try:
				from caches.settings_cache import sync_kodi_profile_context
				sync_kodi_profile_context()
				sync_interval, wait_time = punchplay_sync_interval()
				next_update_string = 'PunchPlay Sync finished - Next Sync in %s minutes' % sync_interval
				if punchplay_user_active(): status = punchplay_sync_activities(allow_history_repair=True)
				else: status = 'no_auth'
				if status == 'failed': kodi_utils.logger('Red Light', 'PunchPlay Sync Failed')
				elif status == 'no_auth': kodi_utils.logger('Red Light', 'PunchPlay Sync Not Run - No Account')
				else: kodi_utils.logger('Red Light', 'PunchPlay Sync %s - %s' % ('OK' if status == 'success' else 'No Changes', next_update_string))
				if status == 'success' and not kodi_utils.service_shutting_down(monitor):
					_refresh_widgets_after_sync(4, 'PunchPlay')
			except Exception as e: kodi_utils.logger('Red Light', 'PunchPlay Sync Failed: %s' % str(e))
			wait_for_abort(wait_time)
		try: del player
		except: pass
		return kodi_utils.logger('Red Light', 'PunchPlayMonitor Service Finished')

class WeTrakrMonitor:
	def run(self, monitor):
		kodi_utils.logger('Red Light', 'WeTrakrMonitor Service Starting')
		from apis.wetrakr_api import wetrakr_sync_activities
		from modules.settings import wetrakr_user_active, wetrakr_sync_interval
		player = kodi_utils.kodi_player()
		wait_for_abort, is_playing = monitor.waitForAbort, player.isPlayingVideo
		wait_for_abort(55)
		while not monitor.abortRequested():
			while is_playing() or kodi_utils.get_property(pause_services_prop) == 'true': wait_for_abort(10)
			wait_time = 1800
			try:
				from caches.settings_cache import sync_kodi_profile_context
				sync_kodi_profile_context()
				sync_interval, wait_time = wetrakr_sync_interval()
				next_update_string = 'WeTrakr Sync finished - Next Sync in %s minutes' % sync_interval
				if wetrakr_user_active(): status = wetrakr_sync_activities(allow_history_repair=True)
				else: status = 'no_auth'
				if status == 'failed': kodi_utils.logger('Red Light', 'WeTrakr Sync Failed')
				elif status == 'no_auth': kodi_utils.logger('Red Light', 'WeTrakr Sync Not Run - No Account')
				else: kodi_utils.logger('Red Light', 'WeTrakr Sync %s - %s' % ('OK' if status == 'success' else 'No Changes', next_update_string))
				if status == 'success' and not kodi_utils.service_shutting_down(monitor):
					_refresh_widgets_after_sync(5, 'WeTrakr')
			except Exception as e: kodi_utils.logger('Red Light', 'WeTrakr Sync Failed: %s' % str(e))
			wait_for_abort(wait_time)
		try: del player
		except: pass
		return kodi_utils.logger('Red Light', 'WeTrakrMonitor Service Finished')

class WidgetRefresher:
	def run(self, monitor):
		kodi_utils.logger('Red Light', 'WidgetRefresher Service Starting')
		from time import time
		player = kodi_utils.kodi_player()
		wait_for_abort, self.is_playing = monitor.waitForAbort, player.isPlayingVideo
		wait_for_abort(10)
		self.set_next_refresh(time())
		self._was_playing = False
		while not monitor.abortRequested():
			try:
				# Two 5s waits: a pending Home update is seen as quickly as the old alarm.
				# The timed widget refresh below still runs on the same 10s check.
				for _ in (0, 1):
					if wait_for_abort(5): break
					if kodi_utils.service_shutting_down(monitor): break
					self._flush_deferred_widget_refresh()
				if monitor.abortRequested() or kodi_utils.service_shutting_down(monitor): continue
				offset = int(get_setting('redlight.widget_refresh_timer', '60'))
				if offset != self.offset:
					self.set_next_refresh(time())
					continue
				playing = False
				try: playing = self.is_playing()
				except: playing = False
				if self._was_playing and not playing:
					self._defer_overdue_refresh()
				self._was_playing = playing
				if self.condition_check(): continue
				if self.next_refresh < time():
					kodi_utils.logger('Red Light', 'WidgetRefresher Service - Widgets Refreshed')
					kodi_utils.refresh_widgets()
					self.set_next_refresh(time())
			except: pass
		try: del player
		except: pass
		return kodi_utils.logger('Red Light', 'WidgetRefresher Service Finished')

	def _defer_overdue_refresh(self):
		# Timer ran out during playback. Home already rebuilds on Stop; wait 2
		# minutes so Trakt/etc still get a pass without stacking on that rebuild.
		if not getattr(self, 'offset', 0) or self.next_refresh is None:
			return
		now = time()
		if self.next_refresh <= now:
			self.next_refresh = now + kodi_utils.PLAYBACK_WIDGET_REFRESH_COOLDOWN_SEC
			kodi_utils.logger('Red Light', 'WidgetRefresher: timer due during play, waiting 2 minutes after Stop')

	def _flush_deferred_widget_refresh(self):
		"""One Home widget update after Mark Watched, once the user has left Red Light."""
		pending = kodi_utils.widget_refresh_pending()
		if not pending: return
		if self.is_playing() or kodi_utils.get_property(pause_services_prop) == 'true': return
		if kodi_utils.browsing_redlight(): return
		kodi_utils.clear_widget_refresh_pending()
		kodi_utils.logger('Red Light', 'Widget refresh after leaving Red Light')
		kodi_utils.refresh_widgets(silent=True, reload_skin=(pending == 'reload'))

	def condition_check(self):
		if not self.external(): return True

		if self.next_refresh == None or self.is_playing() or kodi_utils.get_property(pause_services_prop) == 'true': return True
		# Same 120s post-Stop/mark window as Meta Accounts Refresh Widgets After Sync.
		# Kodi already rebuilds Home; do not stack another UpdateLibrary immediately.
		try:
			if kodi_utils.playback_widget_refresh_recent(): return True
		except: pass
		if kodi_utils.get_property('redlight.window_loaded') == 'true': return True 
		try:
			window_stack = json.loads(kodi_utils.get_property('redlight.window_stack'))
			if window_stack or window_stack == []: return True
		except: pass
		return False

	def set_next_refresh(self, _time):
		self.offset = int(get_setting('redlight.widget_refresh_timer', '60'))
		if self.offset: self.next_refresh = _time + (self.offset*60)
		else: self.next_refresh = None

	def external(self):
		return 'plugin' not in kodi_utils.get_infolabel('Container.PluginName')

class PlaybackRemoteMonitor:
	def run(self, monitor):
		kodi_utils.logger('Red Light', 'PlaybackRemoteMonitor Service Starting')
		from modules.playback_remotes import process_pending_jobs
		wait_for_abort = monitor.waitForAbort
		while not monitor.abortRequested():
			try: process_pending_jobs(monitor)
			except Exception as e: kodi_utils.logger('PlaybackRemoteMonitor', str(e))
			wait_for_abort(1)
		try: process_pending_jobs(monitor, force=True)
		except: pass
		return kodi_utils.logger('Red Light', 'PlaybackRemoteMonitor Service Finished')

class InvokerCooldown:
	"""Retire the interpreter left by browsing, once the user has left Red Light.

	A home widget call does not do this. That call is what keeps the next widget warm.
	"""
	def run(self, monitor):
		kodi_utils.logger('Red Light', 'InvokerCooldown Service Starting')
		wait_for_abort = monitor.waitForAbort
		while not monitor.abortRequested():
			if wait_for_abort(1): break
			try:
				if kodi_utils.service_shutting_down(monitor) or kodi_utils.get_property(pause_services_prop) == 'true': continue
				if not kodi_utils.invoker_cooldown_due(): continue
				kodi_utils.clear_invoker_idle()
				kodi_utils.run_plugin({'mode': 'invoker_cooldown'})
			except Exception as e: kodi_utils.logger('InvokerCooldown', str(e))
		return kodi_utils.logger('Red Light', 'InvokerCooldown Service Finished')

class AutoStart:
	def run(self, monitor):
		kodi_utils.logger('Red Light', 'AutoStart Service Starting')
		from modules.settings import auto_start_redlight
		if auto_start_redlight() and not kodi_utils.service_shutting_down(monitor):
			try:
				from caches.settings_cache import ensure_settings_properties_loaded
				ensure_settings_properties_loaded()
			except Exception as e:
				kodi_utils.logger('AutoStart', 'bootstrap: %s' % e)
			kodi_utils.run_addon()
		return kodi_utils.logger('Red Light', 'AutoStart Service Finished')

class ServiceExpiryAlerts:
	def run(self, monitor):
		kodi_utils.logger('Red Light', 'ServiceExpiryAlerts Service Starting')
		from modules.service_expiry import run_expiry_alerts
		monitor.waitForAbort(60)
		if not monitor.abortRequested() and not kodi_utils.service_shutting_down(monitor):
			try: run_expiry_alerts()
			except Exception as e: kodi_utils.logger('ServiceExpiryAlerts', str(e))
		return kodi_utils.logger('Red Light', 'ServiceExpiryAlerts Service Finished')

class AddonXMLCheck:
	def run(self):
		kodi_utils.logger('Red Light', 'AddonXMLCheck Service Starting')
		try: kodi_utils.reuse_language_invoker_check()
		except Exception as e: kodi_utils.logger('AddonXMLCheck', str(e))
		return kodi_utils.logger('Red Light', 'AddonXMLCheck Service Finished')

class RedLightMonitor(Monitor):
	def __init__ (self):
		Monitor.__init__(self)
		# Background ALL startup work so the main thread reaches waitForAbort()
		# in milliseconds.  Kodi only restarts a service's new version after a
		# CLEAN exit (waitForAbort returned).  If startServices() ran on the
		# main thread and took > 5 seconds, Kodi force-killed the process and
		# then did NOT restart the updated version — leaving Red Light dead
		# until the next full Kodi restart.
		_start_daemon(lambda: self.startServices())

	def startServices(self):
		try: SetAddonConstants().run()
		except Exception as e: kodi_utils.logger('SetAddonConstants', str(e))
		if self.abortRequested(): return
		_start_daemon(lambda: _run_safe(DatabaseMaintenance, 'DatabaseMaintenance'))
		_start_daemon(lambda: _run_safe(SyncSettings, 'SyncSettings'))
		if self.abortRequested(): return
		try: AddonXMLCheck().run()
		except Exception as e: kodi_utils.logger('AddonXMLCheck', str(e))
		if self.abortRequested(): return
		try:
			from caches.settings_cache import service_bootstrap_needed
			if service_bootstrap_needed():
				_start_daemon(lambda: BootstrapSettings().run(self))
		except Exception as e: kodi_utils.logger('BootstrapSettings', str(e))
		if self.abortRequested(): return
		start_custom_windows_prepare(self)
		_start_daemon(lambda: PlaybackRemoteMonitor().run(self))
		_start_daemon(lambda: InvokerCooldown().run(self))
		_start_daemon(lambda: TraktMonitor().run(self))
		_start_daemon(lambda: SimklMonitor().run(self))
		_start_daemon(lambda: MdblistMonitor().run(self))
		_start_daemon(lambda: PunchPlayMonitor().run(self))
		_start_daemon(lambda: WeTrakrMonitor().run(self))
		_start_daemon(lambda: WidgetRefresher().run(self))
		if self.abortRequested(): return
		try: AutoStart().run(self)
		except Exception as e: kodi_utils.logger('AutoStart', str(e))
		_start_daemon(lambda: ServiceExpiryAlerts().run(self))

	def onNotification(self, sender, method, data):
		if method in ('GUI.OnScreensaverActivated', 'System.OnSleep'):
			kodi_utils.set_property(pause_services_prop, 'true')
			kodi_utils.logger('OnNotificationActions', 'PAUSING Red Light Services Due to Device Sleep')
		elif method in ('GUI.OnScreensaverDeactivated', 'System.OnWake'):
			kodi_utils.clear_property(pause_services_prop)
			kodi_utils.logger('OnNotificationActions', 'UNPAUSING Red Light Services Due to Device Awake')
		elif method in ('Addon.OnDisabled', 'Addon.OnUninstalled'):
			try:
				info = json.loads(data)
				if info.get('id') == 'plugin.video.redlight':
					kodi_utils.prepare_service_shutdown()
					kodi_utils.logger('Red Light', 'Service shutdown - addon disabled for update or uninstall')
			except: pass

if __name__ == '__main__':
	# ----- AM Lite Trakt startup sync patch BEGIN -----
	def wait_for_am_trakt(timeout=120, max_age=180):
		import time
		import xbmc
		import xbmcaddon

		if not xbmc.getCondVisibility('System.HasAddon(script.module.acctmgr)'):
			return False

		waited = 0
		while waited < timeout:
			try:
				am = xbmcaddon.Addon('script.module.acctmgr')
				ready = am.getSetting('am_trakt_ready')
				last_prepare = am.getSetting('am_last_prepare')
				if ready == 'true' and last_prepare:
					age = int(time.time()) - int(last_prepare)
					if 0 <= age <= max_age:
						return True
			except Exception:
				pass
			xbmc.sleep(1000)
			waited += 1
		return False

	def _am_trakt_startup():
		try:
			wait_for_am_trakt()
		except Exception:
			pass

	Thread(target=_am_trakt_startup, daemon=True).start()
	# ----- AM Lite Trakt startup sync patch END -----
	kodi_utils.logger('Red Light', 'Main Monitor Service Starting')
	RedLightMonitor().waitForAbort()
	kodi_utils.logger('Red Light', 'Main Monitor Service Finished')