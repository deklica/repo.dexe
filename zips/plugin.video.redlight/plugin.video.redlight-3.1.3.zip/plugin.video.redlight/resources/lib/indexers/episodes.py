# -*- coding: utf-8 -*-
import sys
from modules import kodi_utils, settings, watched_status as ws
from modules.metadata import tvshow_meta, episodes_meta, all_episodes_meta
from modules.utils import jsondate_to_datetime, adjust_premiered_date, calendar_service_local_date, make_day, get_datetime, get_current_timestamp, title_key, date_difference, TaskPool
from datetime import datetime, timedelta
# logger = kodi_utils.logger

def _calendar_episode_date(service_first_aired, tmdb_premiered, adjust_hours):
	"""Use Trakt/MDBList/Simkl/PunchPlay air date for calendar label + sort (not TMDb premiered).

	Do not invent TMDb 20:00 / apply date_offset() here — that can push service calendar
	days one day ahead. Date-only events keep their calendar day; ISO timestamps
	use the user UTC (+/-) setting only.
	"""
	if service_first_aired:
		d, day = calendar_service_local_date(service_first_aired)
		if d is not None:
			return d, day
	return adjust_premiered_date(tmdb_premiered, adjust_hours)

def _nextep_activity_datetime(item, resformat, current_date):
	"""Newer of last watched and this next-up's air date. Unaired air dates are ignored.

	Air dates are date-only (start of that local day), so a watch later the same day
	outranks that day's premiere. All Watched Status Providers use the same row fields.
	"""
	played, aired = None, None
	raw_played = item.get('last_played')
	if raw_played:
		try: played = jsondate_to_datetime(raw_played, resformat)
		except: played = None
	if not item.get('unaired'):
		raw_air = item.get('first_aired') or ''
		try:
			aired_dt = jsondate_to_datetime(raw_air, '%Y-%m-%d')
			if aired_dt:
				aired_date = aired_dt.date() if hasattr(aired_dt, 'date') else aired_dt
				if aired_date <= current_date:
					aired = datetime(aired_date.year, aired_date.month, aired_date.day)
		except: aired = None
	candidates = [t for t in (played, aired) if t]
	if not candidates: return datetime(2000, 1, 1)
	return max(candidates)

def _pin_recently_aired(item_list, current_date, pin_days):
	"""Sort Recently Aired to Top: returns (next-ups aired within pin_days, newest first; the rest in their order).

	0 days = aired today only. Unaired (red) episodes are never pinned.
	"""
	def _recent(item):
		if item.get('unaired'): return False
		try:
			aired = jsondate_to_datetime(item.get('first_aired', '2100-12-31'), '%Y-%m-%d').date()
			return 0 <= (current_date - aired).days <= pin_days
		except: return False
	pinned = sorted([i for i in item_list if _recent(i)], key=lambda i: i.get('first_aired', ''), reverse=True)
	return pinned, [i for i in item_list if not i in pinned]

def _nextep_indicator_watchlist(indicators=None):
	"""Never-started shows from a Watched Status Provider service watchlist (empty for Red Light)."""
	if indicators is None: indicators = settings.watched_indicators()
	try:
		if indicators == 1:
			from apis.trakt_api import trakt_watchlist
			data = trakt_watchlist('tvshow', '') or []
			return [{'media_ids': i['media_ids'], 'title': i.get('title', '')} for i in data if i.get('media_ids')]
		if indicators == 2:
			from apis.simkl_api import simkl_plantowatch
			data = (simkl_plantowatch('shows') or []) + (simkl_plantowatch('anime') or [])
			return [{'media_ids': i['media_ids'], 'title': i.get('title', '')} for i in data if i.get('media_ids')]
		if indicators == 3:
			from apis.mdblist_api import mdblist_watchlist_media_ids
			return mdblist_watchlist_media_ids('shows')
		if indicators == 4:
			from apis.punchplay_api import punchplay_watchlist
			data = (punchplay_watchlist('shows') or []) + (punchplay_watchlist('anime') or [])
			return [{'media_ids': i['media_ids'], 'title': i.get('title', '')} for i in data if i.get('media_ids')]
		if indicators == 5:
			from apis.wetrakr_api import wetrakr_plantowatch
			data = wetrakr_plantowatch('shows') or []
			return [{'media_ids': i['media_ids'], 'title': i.get('title', '')} for i in data if i.get('media_ids')]
	except: pass
	return []

def _apply_wetrakr_up_next(data, hidden_list, up_rows, played=None):
	"""Use WeTrakr's lined-up episode when it names one. Other shows stay on local next-up."""
	up_by = {}
	for row in up_rows or []:
		try: tid = int(row['media_ids']['tmdb'])
		except Exception: continue
		if hidden_list and tid in hidden_list: continue
		up_by[tid] = row
	if not up_by: return data
	played = played or {}
	seen, merged = set(), []
	for row in data or []:
		try: tid = int(row['media_ids']['tmdb'])
		except Exception:
			merged.append(row)
			continue
		if tid not in up_by:
			merged.append(row)
			continue
		if tid in seen: continue
		nxt = dict(up_by[tid])
		last_played = row.get('last_played') or played.get(tid)
		if last_played: nxt['last_played'] = last_played
		if not nxt.get('title'): nxt['title'] = row.get('title') or ''
		merged.append(nxt)
		seen.add(tid)
	for tid, row in up_by.items():
		if tid in seen: continue
		nxt = dict(row)
		if played.get(tid): nxt['last_played'] = played.get(tid)
		merged.append(nxt)
	return merged

_CLEAR_PROGRESS_LABEL = '[B]Clear Progress[/B]'
_MARK_WATCHED_LABELS = ('[B]Mark Watched[/B]', '[B]Mark Unwatched[/B]')
_UNMARK_PREV_LABEL = '[B]Unmark Previous Watched[/B]'

def _cm_sync_mark_watched(cm, packet, playcount):
	"""Keep Mark Watched/Unwatched on unaired rows (playback can tick them; menu used to hide)."""
	cm = [i for i in (cm or []) if not (isinstance(i, (list, tuple)) and i and i[0] in _MARK_WATCHED_LABELS)]
	try:
		if int(packet.get('season')) == 0: return cm
	except Exception:
		return cm
	action = 'mark_as_unwatched' if playcount else 'mark_as_watched'
	label = '[B]Mark Unwatched[/B]' if playcount else '[B]Mark Watched[/B]'
	url = kodi_utils.build_url({
		'mode': 'watched_status.mark_episode', 'action': action,
		'tmdb_id': packet['tmdb_id'], 'tvdb_id': packet.get('tvdb_id') or '0',
		'season': packet['season'], 'episode': packet['episode'],
		'title': packet.get('tvshowtitle') or ''
	})
	item = (label, 'RunPlugin(%s)' % url)
	insert_at = len(cm)
	for idx, entry in enumerate(cm):
		if isinstance(entry, (list, tuple)) and entry and entry[0] in (
			_CLEAR_PROGRESS_LABEL, _UNMARK_PREV_LABEL, '[B]Refresh Widgets[/B]', '[B]Reload Widgets[/B]'):
			insert_at = idx
			break
	cm.insert(insert_at, item)
	return cm

def _cm_sync_unmark_previous(cm, packet, watched_info=None):
	"""Keep Unmark Previous on Next Episodes only when the previous episode is watched."""
	cm = [i for i in (cm or []) if not (isinstance(i, (list, tuple)) and i and i[0] == _UNMARK_PREV_LABEL)]
	if not packet.get('nextep_unmark_previous'):
		return cm
	if not ws.previous_episode_watched(packet.get('season'), packet.get('episode'), watched_info):
		return cm
	url = kodi_utils.build_url({
		'mode': 'watched_status.unmark_previous_episode', 'action': 'mark_as_unwatched',
		'tmdb_id': packet['tmdb_id'], 'tvdb_id': packet.get('tvdb_id') or '0',
		'season': packet.get('season'), 'episode': packet.get('episode'),
		'title': packet.get('tvshowtitle') or '', 'refresh': 'true'
	})
	item = (_UNMARK_PREV_LABEL, 'RunPlugin(%s)' % url)
	insert_at = len(cm)
	for idx, entry in enumerate(cm):
		if isinstance(entry, (list, tuple)) and entry and entry[0] in ('[B]Refresh Widgets[/B]', '[B]Reload Widgets[/B]'):
			insert_at = idx
			break
	cm.insert(insert_at, item)
	return cm

def _cm_sync_clear_progress(cm, packet, has_progress):
	"""Keep Clear Progress in line with live resume (cached Next Episodes CM can be stale)."""
	cm = [i for i in (cm or []) if not (isinstance(i, (list, tuple)) and i and i[0] == _CLEAR_PROGRESS_LABEL)]
	if not has_progress:
		return cm
	url = kodi_utils.build_url({
		'mode': 'watched_status.erase_bookmark', 'media_type': 'episode',
		'tmdb_id': packet['tmdb_id'], 'season': packet['season'], 'episode': packet['episode'],
		'refresh': 'true'
	})
	item = (_CLEAR_PROGRESS_LABEL, 'RunPlugin(%s)' % url)
	insert_at = len(cm)
	for idx, entry in enumerate(cm):
		if isinstance(entry, (list, tuple)) and entry and entry[0] in _MARK_WATCHED_LABELS:
			insert_at = idx + 1
	cm.insert(insert_at, item)
	return cm

def _nextep_colored_label(packet, unaired):
	prefix = packet.get('label_prefix') or ''
	body = packet.get('label_body') or ''
	suffix = packet.get('label_suffix') or ''
	if packet.get('unwatched'):
		return '%s[COLOR darkgoldenrod]%s[/COLOR]%s' % (prefix, body, suffix)
	if unaired:
		return '%s[COLOR red]%s[/COLOR]%s' % (prefix, body, suffix)
	return '%s%s%s' % (prefix, body, suffix)


def _nextep_airtime_view(packet):
	"""Re-check local air time when a saved Next Episodes row is drawn.

	Returns (packet, hide). hide is true when the episode is not out yet and
	Include Unaired is off. The saved row stays in the cache either way.
	"""
	from modules.airtime import clock_status
	try:
		status = clock_status(packet.get('air_date'), packet.get('service_air'), packet.get('imdb_id'), packet.get('tvdb_id'))
	except Exception:
		status = 'unknown'
	date_unaired = bool(packet.get('date_unaired'))
	released = False
	if date_unaired:
		try:
			from modules.airtime import episode_already_out
			released = episode_already_out(packet.get('season'), packet.get('episode'), packet.get('air_date'),
				packet.get('imdb_id'), packet.get('tvdb_id'), packet.get('service_air'))
		except Exception:
			released = False
	if released: effective = False
	elif status == 'pending': effective = True
	else: effective = date_unaired
	hide = effective and not settings.nextep_include_unaired()
	packet = dict(packet)
	packet['unaired'] = effective
	if packet.get('label_body') is not None or packet.get('label_prefix') is not None:
		packet['display'] = _nextep_colored_label(packet, effective)
	return packet, hide


def _paint_episode_list_packet(packet, item_list_append, make_listitem, kodi_actor, watched_db, is_external,
								live_progress=True, log_label='episode list cache', set_last_played=True,
								apply_airtime=False, keep_hidden=False):
	"""Paint a cached row packet into item_list. Re-reads live WatchedProgress when requested."""
	try:
		if apply_airtime:
			prepared, hide = _nextep_airtime_view(packet)
			if hide:
				if keep_hidden:
					item_list_append({
						'list_items': None, 'row_packet': packet, 'unaired': True,
						'first_aired': packet.get('first_aired'), 'name': packet.get('name') or '',
						'last_played': packet.get('last_played'), 'sort_order': packet.get('sort_order'),
						'unwatched': packet.get('unwatched') or False,
					})
				return
			packet = prepared
		listitem = make_listitem()
		set_properties = listitem.setProperties
		info_tag = listitem.getVideoInfoTag()
		props = dict(packet.get('properties') or {})
		# Estuary's poster count is drawn only for a TV show row.
		media_type = 'episode'
		if not is_external and props.get('totalepisodes') and settings.single_episode_tvshow_view():
			media_type = 'tvshow'
			listitem.setLabel2('%s / %s' % (props.get('watchedepisodes') or '0', props.get('totalepisodes')))
		info_tag.setMediaType(media_type), info_tag.setOriginalTitle(packet['orig_title']), info_tag.setTitle(packet['display_title'])
		info_tag.setGenres(packet['genre'] or [])
		if not packet.get('omit_tvshowtitle'): info_tag.setTvShowTitle(packet['tvshowtitle'])
		info_tag.setPlaycount(packet['playcount']), info_tag.setPlot(packet['plot']), info_tag.setFirstAired(packet['premiered'])
		if not (packet.get('omit_season_episode') or packet.get('display_format') == 2):
			info_tag.setSeason(packet['season']), info_tag.setEpisode(packet['episode'])
		info_tag.setDuration(packet['duration']), info_tag.setIMDBNumber(packet['imdb_id'])
		info_tag.setUniqueIDs({'imdb': packet['imdb_id'], 'tmdb': str(packet['tmdb_id']), 'tvdb': str(packet['tvdb_id'])})
		info_tag.setCountries(packet.get('country') or []), info_tag.setTrailer(packet['trailer']), info_tag.setTvShowStatus(packet['show_status'])
		studio = packet.get('studio')
		if isinstance(studio, tuple): studio = list(studio)
		elif not studio: studio = []
		info_tag.setStudios(studio), info_tag.setWriters(packet.get('writer')), info_tag.setDirectors(packet.get('director'))
		info_tag.setYear(int(packet['year'])), info_tag.setRating(packet.get('rating')), info_tag.setVotes(packet.get('votes')), info_tag.setMpaa(packet.get('mpaa'))
		info_tag.setCast([kodi_actor(name=i['name'], role=i['role'], thumbnail=i['thumbnail']) for i in (packet.get('cast') or [])])
		ws.clear_listitem_kodi_resume(info_tag)
		try: listitem.setContentLookup(False)
		except: pass
		listitem.setLabel(packet['display'])
		listitem.setArt(packet.get('art') or {})
		props.pop('WatchedProgress', None)
		if props: set_properties(props)
		_prog = None
		playcount = packet.get('playcount') or 0
		_watched_info = None
		if live_progress:
			try:
				_bm = ws.get_bookmarks_episode(packet['tmdb_id'], packet['season'], watched_db)
				_prog = ws.get_progress_status_episode(_bm, packet['episode'])
				if _prog:
					ws.apply_listitem_progress(info_tag, set_properties, _prog, packet.get('duration') or 0, is_external)
			except: pass
			try:
				_watched_info = ws.watched_info_episode(packet['tmdb_id'], watched_db)
				playcount = ws.get_watched_status_episode(_watched_info, (packet['season'], packet['episode']))
			except: pass
		if set_last_played: ws.apply_listitem_last_played(info_tag, packet.get('last_played'))
		cm = packet.get('cm') or []
		cm = _cm_sync_mark_watched(cm, packet, playcount)
		cm = _cm_sync_unmark_previous(cm, packet, _watched_info)
		cm = _cm_sync_clear_progress(cm, packet, bool(_prog))
		packet['cm'] = cm
		listitem.addContextMenuItems(cm)
		item_list_append({'list_items': (packet['play_params'], listitem, False), 'first_aired': packet.get('first_aired'),
						'name': packet.get('name'), 'unaired': packet.get('unaired'), 'last_played': packet.get('last_played'),
						'sort_order': packet.get('sort_order'), 'unwatched': packet.get('unwatched'),
						'row_packet': packet})
	except Exception as e:
		try: kodi_utils.logger('Red Light', '%s paint failed: %s' % (log_label, e))
		except: pass

def build_episode_list(params):
	def _process():
		for item in episodes_data:
			try:
				cm = []
				cm_append = cm.append
				listitem = make_listitem()
				set_properties = listitem.setProperties
				item_get = item.get
				season, episode, ep_name = item_get('season'), item_get('episode'), item_get('title')
				matched = item_get('tmdb_season') not in (None, '')
				anime_episode = bool(item_get('anime_episode'))
				if matched:
					lookup_season, lookup_episode = int(item_get('tmdb_season')), int(item_get('tmdb_episode'))
				else:
					lookup_season, lookup_episode = season, episode
				has_progress_id = matched or not anime_episode
				season_special = season == 0
				episode_date, premiered = adjust_premiered_date(item_get('premiered'), adjust_hours)
				episode_type = item_get('episode_type') or ''
				episode_id = item_get('episode_id') or None
				if not has_progress_id:
					playcount, progress = 0, None
				elif season_special: playcount, progress = 0, None
				else:
					playcount = ws.get_watched_status_episode(watched_info, (lookup_season, lookup_episode))
					if playcount and hide_watched: continue
					if map_list or total_seasons: progress = ws.get_progress_status_all_episode(bookmarks, lookup_season, lookup_episode)
					else: progress = ws.get_progress_status_episode(bookmarks, lookup_episode)
				if no_spoilers and not playcount: thumb, plot = show_landscape or show_fanart, tvshow_plot or '* Hidden to Prevent Spoilers *'
				else: thumb, plot = item_get('thumb', None) or show_landscape or show_fanart, item_get('plot') or tvshow_plot
				try: year = premiered.split('-')[0]
				except: year = show_year or '2050'
				duration = item_get('duration')
				if not duration:
					duration = show_duration
					item['duration'] = duration
				str_episode_zfill2 = str(episode).zfill(2)
				seas_ep = '%sx%s. ' % (season, str_episode_zfill2)
				if not episode_date or current_date < episode_date:
					display, unaired = '[COLOR red][I]%s%s[/I][/COLOR]' % (seas_ep, ep_name), True
					item['title'] = display
					if not (anime_episode and not matched):
						try:
							from modules.airtime import episode_already_out
							if episode_already_out(lookup_season, lookup_episode, item_get('premiered'), imdb_id, tvdb_id, today=current_date):
								display, unaired = '%s%s' % (seas_ep, ep_name), False
								item['title'] = ep_name
						except Exception:
							pass
				else: display, unaired = '%s%s' % (seas_ep, ep_name), False
				extras_params = build_url({'mode': 'extras_menu_choice', 'tmdb_id': tmdb_id, 'media_type': 'episode', 'is_external': is_external})
				options_params = build_url({'mode': 'options_menu_choice', 'content': 'episode', 'tmdb_id': tmdb_id, 'poster': show_poster, 'is_external': is_external,
											'season': lookup_season, 'episode': lookup_episode, 'episode_id': episode_id})
				playback_options_params = build_url({'mode': 'playback_choice', 'media_type': 'episode', 'meta': tmdb_id, 'season': lookup_season, 'playcount': playcount,
												'episode': lookup_episode, 'episode_id': episode_id})
				play_params = {'mode': play_mode, 'media_type': 'episode', 'tmdb_id': tmdb_id, 'season': lookup_season, 'episode': lookup_episode,
							'playcount': playcount, 'episode_id': episode_id, playback_key: playback_key}
				if anime_episode and not matched:
					play_params.update({'skip_scrobble': 'true', 'anime_display': 'true', 'absolute_episode': item_get('absolute') or '',
									'kitsu_id': item_get('kitsu_id') or '', 'kitsu_episode': item_get('kitsu_episode') or '',
									'ep_name': ep_name, 'plot': item_get('plot') or '', 'premiered': item_get('premiered') or ''})
				play_params = build_url(play_params)
				cm_append(['extras', ('[B]Extras[/B]', 'RunPlugin(%s)' % extras_params)])
				cm_append(['options', ('[B]Options[/B]', 'RunPlugin(%s)' % options_params)])
				cm_append(['playback_options', ('[B]Play Options[/B]', 'RunPlugin(%s)' % playback_options_params)])
				settings.append_source_shortcut_context_menus(cm_append, build_url, cm_sort_order, 'episode', tmdb_id, lookup_season, lookup_episode, playcount)
				settings.append_external_scraper_settings_cm(cm_append, build_url)
				cm_append(['browse_seasons', ('[B]Browse Seasons[/B]', window_command % build_url({'mode': 'build_season_list', 'tmdb_id': tmdb_id}))])
				cm_append(['browse_episodes', ('[B]Browse Episodes[/B]', window_command % build_url({'mode': 'build_episode_list', 'tmdb_id': tmdb_id, 'season': season}))])
				if not season_special and has_progress_id:
					if playcount:
						cm_append(['mark_watched', ('[B]Mark Unwatched[/B]', 'RunPlugin(%s)' % build_url({'mode': 'watched_status.mark_episode', 'action': 'mark_as_unwatched',
													'tmdb_id': tmdb_id, 'tvdb_id': tvdb_id, 'season': lookup_season, 'episode': lookup_episode,  'title': title}))])
					else: cm_append(['mark_watched', ('[B]Mark Watched[/B]', 'RunPlugin(%s)' % build_url({'mode': 'watched_status.mark_episode', 'action': 'mark_as_watched',
													'tmdb_id': tmdb_id, 'tvdb_id': tvdb_id, 'season': lookup_season, 'episode': lookup_episode,  'title': title}))])
					if progress: cm_append(['mark_watched', ('[B]Clear Progress[/B]', 'RunPlugin(%s)' % \
								build_url({'mode': 'watched_status.erase_bookmark', 'media_type': 'episode', 'tmdb_id': tmdb_id,
								'season': lookup_season, 'episode': lookup_episode, 'refresh': 'true'}))])
					if ws.previous_episode_watched(lookup_season, lookup_episode, watched_info, meta):
						cm_append(['unmark_previous_episode', ('[B]Unmark Previous Watched[/B]', 'RunPlugin(%s)' % \
									build_url({'mode': 'watched_status.unmark_previous_episode', 'action': 'mark_as_unwatched',
												'tmdb_id': tmdb_id, 'tvdb_id': tvdb_id, 'season': lookup_season, 'episode': lookup_episode,
												'title': title, 'refresh': 'true'}))])
				if is_external:
					cm.extend([['refresh', ('[B]Refresh Widgets[/B]', 'RunPlugin(%s)' % build_url({'mode': 'refresh_widgets'}))],
							['reload', ('[B]Reload Widgets[/B]', 'RunPlugin(%s)' % build_url({'mode': 'kodi_refresh'}))]])
				if custom_cm_menu:
					try: cm = sorted([i for i in cm if i[0] in cm_sort_order], key=lambda k: cm_sort_order[k[0]])
					except: pass
				cm = [i[1] for i in cm]
				studios = list(studio) if isinstance(studio, tuple) else (studio or [])
				info_tag = listitem.getVideoInfoTag()
				info_tag.setMediaType('episode'), info_tag.setTitle(ep_name), info_tag.setOriginalTitle(orig_title), info_tag.setTvShowTitle(title), info_tag.setGenres(genre)
				info_tag.setPlaycount(playcount), info_tag.setSeason(season), info_tag.setEpisode(episode), info_tag.setPlot(plot)
				info_tag.setDuration(duration), info_tag.setIMDBNumber(imdb_id), info_tag.setUniqueIDs({'imdb': imdb_id, 'tmdb': str(tmdb_id), 'tvdb': str(tvdb_id)})
				info_tag.setFirstAired(premiered), info_tag.setTvShowStatus(show_status)
				info_tag.setCountries(country), info_tag.setTrailer(trailer), info_tag.setDirectors(item_get('director'))
				info_tag.setYear(int(year)), info_tag.setRating(item_get('rating')), info_tag.setVotes(item_get('votes')), info_tag.setMpaa(mpaa)
				info_tag.setStudios(studios), info_tag.setWriters(item_get('writer'))
				full_cast = cast + (item_get('guest_stars') or [])
				info_tag.setCast([kodi_actor(name=item['name'], role=item['role'], thumbnail=item['thumbnail']) for item in full_cast])
				ws.clear_listitem_kodi_resume(info_tag)
				try: listitem.setContentLookup(False)
				except: pass
				if progress:
					ws.apply_listitem_progress(info_tag, set_properties, progress, duration, is_external)
				listitem.setLabel(display)
				listitem.addContextMenuItems(cm)
				listitem.setArt({'poster': show_poster, 'fanart': show_fanart, 'thumb': thumb, 'icon':thumb, 'clearlogo': show_clearlogo, 'landscape': thumb,
								'season.poster': season_poster, 'tvshow.poster': show_poster, 'tvshow.clearlogo': show_clearlogo,
								'tvshow.landscape': show_landscape})
				set_properties({
					'episode_type': episode_type, 'redlight.extras_params': extras_params, 'redlight.options_params': options_params,
					'redlight.playback_options_params': playback_options_params
					})
				yield (play_params, listitem, False)
			except: pass
	kodi_actor, make_listitem, build_url = kodi_utils.kodi_actor(), kodi_utils.make_listitem, kodi_utils.build_url
	poster_empty, fanart_empty = kodi_utils.get_icon('box_office'), kodi_utils.addon_fanart()
	handle, is_external = int(sys.argv[1]), kodi_utils.external()
	window_command = 'ActivateWindow(Videos,%s,return)' if is_external else 'Container.Update(%s)'
	no_spoilers = settings.avoid_episode_spoilers()
	item_list = []
	append = item_list.append
	watched_indicators, adjust_hours = settings.watched_indicators(), settings.date_offset()
	current_date, hide_watched = get_datetime(), is_external and settings.widget_hide_watched() and params.get('search_results') != 'true'
	cm_sort_order = settings.cm_sort_order()
	custom_cm_menu = cm_sort_order != settings.cm_default_order()
	rpdb_info = settings.rpdb_info('tvshow')
	rpdb_api_key, rpdb_format = rpdb_info['rpdb_api_key'], rpdb_info['rpdb_format']
	playback_key = settings.playback_key()
	play_mode = 'playback.%s' % playback_key
	meta = tvshow_meta('tmdb_id', params.get('tmdb_id'), settings.tmdb_api_key(), settings.mpaa_region(), current_date)
	meta_get = meta.get
	tmdb_id, tvdb_id, imdb_id, tvshow_plot, orig_title = meta_get('tmdb_id'), meta_get('tvdb_id'), meta_get('imdb_id'), meta_get('plot'), meta_get('original_title')
	title, show_year, rootname, show_duration, show_status = meta_get('title'), meta_get('year') or '2050', meta_get('rootname'), meta_get('duration'), meta_get('status')
	mpaa, trailer, genre, studio, country = meta_get('mpaa'), str(meta_get('trailer')), meta_get('genre'), meta_get('studio'), meta_get('country')
	cast = meta_get('short_cast', []) or meta_get('cast', []) or []
	season = params['season']
	show_poster = settings.rpdb_poster(rpdb_api_key, rpdb_format, meta_get('rpdb_poster'), meta_get('poster') or poster_empty)
	show_fanart = meta_get('fanart') or fanart_empty
	show_clearlogo = meta_get('clearlogo') or ''
	show_landscape = meta_get('landscape') or meta_get('fanart') or ''
	watched_db = ws.get_database(watched_indicators)
	watched_info = ws.watched_info_episode(tmdb_id, watched_db)
	from modules import anime_map
	show_map = anime_map.for_show(meta)
	mapped = anime_map.episode_items(show_map, None if season == 'all' else season) if show_map else None
	map_list = mapped is not None
	if map_list:
		episodes_data = mapped
		total_seasons = meta_get('total_seasons') or 1
		bookmarks = ws.get_bookmarks_all_episode(tmdb_id, total_seasons, watched_db)
		if season == 'all':
			part_count = len(show_map.get('parts') or []) or 1
			category_name = 'Season %s' % season if part_count == 1 else 'Seasons 1-%s' % part_count
		else:
			category_name = 'Season %s' % season
		try:
			season_data = meta_get('season_data')
			tmdb_season = None
			for ep in episodes_data or []:
				if ep.get('tmdb_season') not in (None, ''):
					tmdb_season = int(ep['tmdb_season'])
					break
			lookup = tmdb_season if tmdb_season else int(season)
			poster_path = next((i['poster_path'] for i in season_data if i['season_number'] == lookup), None)
			season_poster = 'https://image.tmdb.org/t/p/w780%s' % poster_path if poster_path is not None else show_poster
		except: season_poster = show_poster
	elif season == 'all':
		total_seasons = meta_get('total_seasons')
		episodes_data = sorted(all_episodes_meta(meta, settings.show_specials()), key=lambda x: (x['season'], x['episode']))
		bookmarks = ws.get_bookmarks_all_episode(tmdb_id, total_seasons, watched_db)
		season_poster = show_poster
		category_name = 'Season %s' % season if total_seasons == 1 else 'Seasons 1-%s' % total_seasons
	else:
		total_seasons = None
		episodes_data = episodes_meta(season, meta)
		bookmarks = ws.get_bookmarks_episode(tmdb_id, season, watched_db)
		try:
			season_data = meta_get('season_data')
			poster_path = next((i['poster_path'] for i in season_data if i['season_number'] == int(season)), None)
			season_poster = 'https://image.tmdb.org/t/p/w780%s' % poster_path if poster_path is not None else show_poster
		except: season_poster = show_poster
		category_name = 'Season %s' % season
	try:
		from modules.airtime import ensure_show
		ensure_show(imdb_id, tvdb_id)
	except Exception:
		pass
	kodi_utils.add_items(handle, list(_process()))
	kodi_utils.set_sort_method(handle, 'episodes', labelMask='%L')
	kodi_utils.set_content(handle, 'episodes')
	kodi_utils.set_category(handle, category_name)
	kodi_utils.end_directory(handle, cacheToDisc=False if is_external else True)
	kodi_utils.set_view_mode('view.episodes', 'episodes', is_external)

def _show_progress_properties(enabled, aired, watched, unwatched, progress, total_seasons):
	"""Same poster counts TV Shows set, so a skin can draw 4/10 on a show poster."""
	if not enabled or aired is None: return None
	visible = '0' if progress == 100 else progress
	return {
		'watchedepisodes': str(watched or 0),
		'unwatchedepisodes': str(unwatched if unwatched is not None else 0),
		'totalepisodes': str(aired),
		'watchedprogress': str(visible),
		'totalseasons': str(total_seasons or 0),
	}

def _finish_single_episode_list(handle, item_list, category_name, is_external, calendar_sort=False):
	if not is_external and settings.single_episode_tvshow_view():
		content, view_type, fallback = 'tvshows', 'view.tvshows', ()
	else:
		content, view_type, fallback = 'episodes', 'view.episodes_single', ('view.episodes',)
	kodi_utils.add_items(handle, [i['list_items'] for i in item_list])
	kodi_utils.set_content(handle, content)
	kodi_utils.set_category(handle, category_name)
	if calendar_sort:
		kodi_utils.set_sort_method(handle, 'none', labelMask='%L')
	kodi_utils.end_directory(handle, cacheToDisc=False)
	kodi_utils.set_view_mode(view_type, content, is_external, fallback_view_types=fallback)

def _widget_item_limit(is_external):
	# Same Widgets Item Limit as movies/TV/lists. 0 = off (in-addon, or widget pagination off).
	try:
		if is_external and settings.paginate(True): return max(1, int(settings.page_limit(True)))
	except Exception:
		pass
	return 0

def build_single_episode(list_type, params={}):
	category_override = None
	def _get_category_name():
		if category_override: return category_override
		try:
			cat_name = {'episode.progress': 'In Progress Episodes',
						'episode.recently_watched': 'Recently Watched Episodes',
						'episode.next_trakt': 'Next Episodes', 'episode.next_redlight': 'Next Episodes',
						'episode.next_simkl': 'Next Episodes', 'episode.next_mdblist': 'Next Episodes', 'episode.next_punchplay': 'Next Episodes',
						'episode.next_wetrakr': 'Next Episodes',
						'episode.trakt': {'true': 'Recently Aired Episodes', None: 'Trakt Calendar'},
						'episode.mdblist': 'MDBList Calendar', 'episode.mdblist_calendar': 'MDBList Calendar',
						'episode.mdblist_next': 'MDBList Next Up',
						'episode.punchplay': 'PunchPlay Calendar', 'episode.punchplay_calendar': 'PunchPlay Calendar',
						'episode.simkl': 'Simkl Calendar', 'episode.simkl_calendar': 'Simkl Calendar',
						'episode.simkl_public': 'Simkl Calendar', 'episode.simkl_public_calendar': 'Simkl Calendar',
						'episode.wetrakr_public': 'WeTrakr Calendar', 'episode.wetrakr_public_calendar': 'WeTrakr Calendar',
						'episode.wetrakr_personal': 'WeTrakr Calendar', 'episode.wetrakr_personal_calendar': 'WeTrakr Calendar',
						'episode.trakt_public': 'Trakt Calendar', 'episode.trakt_public_calendar': 'Trakt Calendar'}[list_type]
			if isinstance(cat_name, dict): cat_name = cat_name[params.get('recently_aired')]
		except: cat_name = 'Episodes'
		return cat_name
	def _process(_position, ep_data):
		try:
			ep_data_get = ep_data.get
			meta = tvshow_meta('trakt_dict', ep_data_get('media_ids'), api_key, mpaa_region_value, current_date, current_time, is_anime_list=is_anime_list)
			if not meta: return
			meta_get = meta.get
			cm = []
			cm_append = cm.append
			listitem = make_listitem()
			set_properties = listitem.setProperties
			orig_season, orig_episode = ep_data_get('season'), ep_data_get('episode')
			unwatched = ep_data_get('unwatched', False)
			_position = ep_data_get('custom_order', _position)
			tmdb_id, tvdb_id, imdb_id, title, show_year = meta_get('tmdb_id'), meta_get('tvdb_id'), meta_get('imdb_id'), meta_get('title'), meta_get('year') or '2050'
			season_data = meta_get('season_data')
			watched_info = ws.watched_info_episode(meta_get('tmdb_id'), watched_db)
			# WeTrakr already named this episode, including a rewatch of one watched locally.
			if list_type_starts_with('next') and not ep_data_get('wetrakr_next'):
				last_watched_season, last_watched_episode = orig_season, orig_episode
				orig_season, orig_episode = ws.get_next(orig_season, orig_episode, watched_info, season_data, nextep_content, meta)
				# Weekly anime: stale season/show cache often stops at the last watched ep until expiry.
				if (not orig_season or not orig_episode) and meta_get('status') not in ('Ended', 'Canceled'):
					try:
						from modules.metadata import refresh_airing_show_meta
						refresh_airing_show_meta(meta_get('tmdb_id'), last_watched_season)
						meta = tvshow_meta('tmdb_id', meta_get('tmdb_id'), api_key, mpaa_region_value, current_date, current_time, is_anime_list=is_anime_list)
						if not meta: return
						meta_get = meta.get
						season_data = meta_get('season_data')
						watched_info = ws.watched_info_episode(meta_get('tmdb_id'), watched_db)
						orig_season, orig_episode = ws.get_next(last_watched_season, last_watched_episode, watched_info, season_data, nextep_content, meta)
					except: pass
				if not orig_season or not orig_episode: return
				if ws.get_watched_status_episode(watched_info, (orig_season, orig_episode)): return
			episodes_data = episodes_meta(orig_season, meta)
			if not episodes_data: return
			item = next((i for i in episodes_data if i['episode'] == orig_episode), None)
			if not item: return
			item_get = item.get
			season, episode, ep_name = item_get('season'), item_get('episode'), item_get('title')
			is_calendar = list_type_compare in ('trakt_calendar', 'mdblist_calendar', 'punchplay_calendar', 'simkl_calendar', 'simkl_public_calendar', 'wetrakr_public_calendar', 'wetrakr_personal_calendar', 'trakt_public_calendar', 'trakt_recently_aired')
			if is_calendar:
				episode_date, premiered = _calendar_episode_date(ep_data_get('first_aired'), item_get('premiered'), adjust_hours)
			else:
				episode_date, premiered = adjust_premiered_date(item_get('premiered'), adjust_hours)
			episode_type = item_get('episode_type') or ''
			episode_id = item_get('episode_id') or None
			finale_label = ''
			if list_type_compare in ('simkl_calendar', 'simkl_public_calendar'):
				mapped = {1: 'mid_season_finale', 2: 'season_finale', 3: 'series_finale'}.get(ep_data_get('finale_type'))
				if mapped:
					episode_type = mapped
					finale_label = {'mid_season_finale': 'Mid-Season Finale', 'season_finale': 'Season Finale', 'series_finale': 'Series Finale'}[mapped]
			released_earlier = False
			if not is_calendar and (not episode_date or current_date < episode_date):
				try:
					from modules.airtime import episode_already_out
					released_earlier = episode_already_out(season, episode, item_get('premiered'), imdb_id, tvdb_id,
						service_air=ep_data_get('air_datetime') or '', today=current_date, wait=list_type_starts_with('next_'))
				except Exception:
					released_earlier = False
			if released_earlier:
				unaired = False
			elif not episode_date or current_date < episode_date:
				if list_type_starts_with('next_'):
					if not episode_date: return
					if not include_unaired: return
					if not date_difference(current_date, episode_date, 7): return
				unaired = True
			else: unaired = False
			date_unaired = unaired
			air_date_raw = (item_get('premiered') or '')[:10]
			service_air = ''
			if list_type_starts_with('next_') and not released_earlier:
				service_air = str(ep_data_get('air_datetime') or '')
				try:
					from modules.airtime import clock_status
					if clock_status(air_date_raw, service_air, imdb_id, tvdb_id) == 'pending':
						unaired = True
				except Exception:
					pass
			elif list_type_starts_with('next_'):
				service_air = str(ep_data_get('air_datetime') or '')
			orig_title, rootname, trailer, genre = meta_get('original_title'), meta_get('rootname'), str(meta_get('trailer')), meta_get('genre')
			mpaa, tvshow_plot, studio, show_status = meta_get('mpaa'), meta_get('plot'), meta_get('studio'), meta_get('status')
			cast = meta_get('short_cast', []) or meta_get('cast', []) or []
			show_poster = settings.rpdb_poster(rpdb_api_key, rpdb_format, meta_get('rpdb_poster'), meta_get('poster') or poster_empty)
			show_fanart = meta_get('fanart') or fanart_empty
			show_clearlogo = meta_get('clearlogo') or ''
			show_landscape = meta_get('landscape') or meta_get('fanart') or ''
			try: year = premiered.split('-')[0]
			except: year = show_year or '2050'
			try:
				poster_path = next((i['poster_path'] for i in season_data if i['season_number'] == int(season)), None)
				season_poster = 'https://image.tmdb.org/t/p/w780%s' % poster_path if poster_path is not None else show_poster
			except: season_poster = show_poster
			label_season, label_episode = season, episode
			try:
				from modules.anime_map import row_for_meta
				row = row_for_meta(meta, season, episode)
				if row:
					label_season, label_episode = int(row['display_season']), int(row['display_episode'])
			except Exception:
				pass
			str_episode_zfill2 = str(label_episode).zfill(2)
			label_prefix, label_body, label_suffix = '', '', ''
			if display_format == 0: title_str = '%s - ' % title
			else: title_str = ''
			if display_format in (0, 1): seas_ep = '%sx%s. ' % (str(label_season), str_episode_zfill2)
			else: seas_ep = ''
			if not list_type_starts_with('next_'):
				playcount = ws.get_watched_status_episode(watched_info, (season, episode))
				if playcount and hide_watched: return
			if list_type_starts_with('next_'):
				playcount = 0
				if include_airdate:
					if episode_date: display_premiered = '[%s] ' % make_day(current_date, episode_date)
					else: display_premiered = '[UNKNOWN] '
				else: display_premiered = ''
				if unwatched: highlight_start, highlight_end = '[COLOR darkgoldenrod]', '[/COLOR]'
				elif unaired: highlight_start, highlight_end = '[COLOR red]', '[/COLOR]'
				else: highlight_start, highlight_end = '', ''
				# Title mirrors settings format without BBCode (widgets/skins that bind Title).
				label_prefix = '%s%s' % (display_premiered, title_str)
				label_body = '%s%s' % (seas_ep, ep_name)
				display_title = '%s%s%s%s' % (display_premiered, title_str, seas_ep, ep_name)
				display = '%s%s%s%s%s%s' % (display_premiered, title_str, highlight_start, seas_ep, ep_name, highlight_end)
			elif list_type_compare in ('trakt_calendar', 'mdblist_calendar', 'punchplay_calendar', 'simkl_calendar', 'simkl_public_calendar', 'wetrakr_public_calendar', 'wetrakr_personal_calendar', 'trakt_public_calendar'):
				if not episode_date:
					display_premiered = 'UNKNOWN'
				else:
					display_premiered = make_day(
						current_date, episode_date, calendar_date_strftime,
						use_words=calendar_use_words, include_date=calendar_include_date)
				display = display_title = '[%s] %s%s%s' % (display_premiered, title_str, seas_ep, ep_name)
			else: display = display_title = '%s%s%s' % (title_str, seas_ep, ep_name)
			if finale_label:
				suffix = ' [I][%s][/I]' % finale_label
				display, display_title = display + suffix, display_title + suffix
				if list_type_starts_with('next_'): label_suffix += suffix
			progress_aired_eps, total_watched, total_unwatched, show_progress = None, None, None, None
			if unwatched_info or show_progress_tag:
				try:
					progress_aired_eps = ws.progress_aired_eps(meta)
					_show_play, total_watched, total_unwatched = ws.get_watched_status_tvshow(show_watched_map.get(str(tmdb_id)), progress_aired_eps)
					if total_watched: show_progress = ws.get_progress_status_tvshow(total_watched, progress_aired_eps)
					else: show_progress = 0
				except: progress_aired_eps, total_watched, total_unwatched, show_progress = None, None, None, None
				if unwatched_in_title and total_unwatched:
					suffix = ' (%s)' % total_unwatched
					display, display_title = display + suffix, display_title + suffix
					if list_type_starts_with('next_'): label_suffix += suffix
			if no_spoilers and not playcount: thumb, plot = show_landscape or show_fanart, tvshow_plot or '* Hidden to Prevent Spoilers *'
			else: thumb, plot = item_get('thumb', None) or show_landscape or show_fanart, item_get('plot') or tvshow_plot
			duration = item_get('duration')
			if not duration:
				duration = meta_get('duration')
				item['duration'] = duration
			bookmarks = ws.get_bookmarks_episode(tmdb_id, season, watched_db)
			progress = ws.get_progress_status_episode(bookmarks, episode)
			play_params = build_url({'mode': play_mode, 'media_type': 'episode', 'tmdb_id': tmdb_id, 'season': season, 'episode': episode, 'playcount': playcount,
									'episode_id': episode_id, playback_key: playback_key})
			extras_params = build_url({'mode': 'extras_menu_choice', 'tmdb_id': tmdb_id, 'media_type': 'episode', 'is_external': is_external})
			options_params = build_url({'mode': 'options_menu_choice', 'content': list_type, 'tmdb_id': tmdb_id, 'poster': show_poster, 'is_external': is_external,
										'season': season, 'episode': episode, 'episode_id': episode_id})
			playback_options_params = build_url({'mode': 'playback_choice', 'media_type': 'episode', 'meta': tmdb_id, 'season': season, 'playcount': playcount,
											'episode': episode, 'episode_id': episode_id})
			cm_append(['extras', ('[B]Extras[/B]', 'RunPlugin(%s)' % extras_params)])
			cm_append(['options', ('[B]Options[/B]', 'RunPlugin(%s)' % options_params)])
			cm_append(['playback_options', ('[B]Play Options[/B]', 'RunPlugin(%s)' % \
						build_url({'mode': 'playback_choice', 'media_type': 'episode', 'meta': tmdb_id, 'season': season, 'episode': episode, 'episode_id': episode_id}))])
			settings.append_source_shortcut_context_menus(cm_append, build_url, cm_sort_order, 'episode', tmdb_id, season, episode, playcount)
			settings.append_external_scraper_settings_cm(cm_append, build_url)
			cm_append(['browse_seasons', ('[B]Browse Seasons[/B]', window_command % build_url({'mode': 'build_season_list', 'tmdb_id': tmdb_id}))])
			cm_append(['browse_episodes', ('[B]Browse Episodes[/B]', window_command % build_url({'mode': 'build_episode_list', 'tmdb_id': tmdb_id, 'season': label_season}))])
			# List managers stay show-scoped (watchlist/library/etc). MDBList static add/remove uses season/episode when present.
			trakt_manager_params, simkl_manager_params, punchplay_manager_params, mdblist_manager_params, tmdb_manager_params, wetrakr_manager_params = '', '', '', '', '', ''
			if settings.trakt_user_active():
				trakt_manager_params = build_url({'mode': 'trakt_manager_choice', 'tmdb_id': tmdb_id, 'imdb_id': imdb_id, 'tvdb_id': tvdb_id, 'media_type': 'tvshow',
												'title': title, 'icon': show_poster, 'season': season, 'episode': episode, 'episode_id': episode_id})
			if settings.simkl_user_active():
				simkl_params = {'mode': 'simkl_manager_choice', 'tmdb_id': tmdb_id, 'imdb_id': imdb_id, 'tvdb_id': tvdb_id, 'media_type': 'tvshow',
								'title': title, 'icon': show_poster, 'season': season, 'episode': episode}
				if is_anime_list is True: simkl_params['simkl_media_kind'] = 'anime'
				simkl_manager_params = build_url(simkl_params)
			if settings.punchplay_user_active():
				punchplay_manager_params = build_url({'mode': 'punchplay_manager_choice', 'tmdb_id': tmdb_id, 'imdb_id': imdb_id, 'tvdb_id': tvdb_id, 'media_type': 'tvshow',
													'title': title, 'icon': show_poster, 'season': season, 'episode': episode})
			if settings.mdblist_user_active():
				mdblist_manager_params = build_url({'mode': 'mdblist_manager_choice', 'tmdb_id': tmdb_id, 'imdb_id': imdb_id, 'tvdb_id': tvdb_id, 'media_type': 'tvshow',
													'title': title, 'icon': show_poster, 'season': season, 'episode': episode, 'episode_id': episode_id})
			if settings.tmdblist_user_active():
				tmdb_manager_params = build_url({'mode': 'tmdblists_manager_choice', 'media_type': 'tv', 'tmdb_id': tmdb_id, 'icon': show_poster})
			personal_manager_params = build_url({'mode': 'personallists_manager_choice', 'list_type': 'tvshow', 'tmdb_id': tmdb_id, 'title': title,
												'premiered': meta_get('premiered'), 'current_time': current_time, 'icon': show_poster})
			favorites_manager_params = build_url({'mode': 'favorites_manager_choice', 'media_type': 'tvshow', 'tmdb_id': tmdb_id, 'title': title})
			if mdblist_manager_params: cm_append(['mdblist_manager', ('[B]MDBList Manager[/B]', 'RunPlugin(%s)' % mdblist_manager_params)])
			if punchplay_manager_params: cm_append(['punchplay_manager', ('[B]PunchPlay Manager[/B]', 'RunPlugin(%s)' % punchplay_manager_params)])
			if simkl_manager_params: cm_append(['simkl_manager', ('[B]Simkl Lists Manager[/B]', 'RunPlugin(%s)' % simkl_manager_params)])
			if tmdb_manager_params: cm_append(['tmdb_manager', ('[B]TMDb Lists Manager[/B]', 'RunPlugin(%s)' % tmdb_manager_params)])
			if trakt_manager_params: cm_append(['trakt_manager', ('[B]Trakt Lists Manager[/B]', 'RunPlugin(%s)' % trakt_manager_params)])
			if settings.wetrakr_lists_active():
				wetrakr_manager_params = build_url({'mode': 'wetrakr_manager_choice', 'tmdb_id': tmdb_id, 'imdb_id': imdb_id, 'tvdb_id': tvdb_id, 'media_type': 'tvshow',
													'title': title, 'icon': show_poster, 'season': season, 'episode': episode})
			if wetrakr_manager_params: cm_append(['wetrakr_manager', ('[B]WeTrakr Lists Manager[/B]', 'RunPlugin(%s)' % wetrakr_manager_params)])
			settings.append_list_shortcut_context_menus(cm_append, build_url, cm_sort_order, 'tvshow', tmdb_id, imdb_id, tvdb_id, title, show_poster)
			cm_append(['personal_manager', ('[B]Personal Lists Manager[/B]', 'RunPlugin(%s)' % personal_manager_params)])
			cm_append(['favorites_manager', ('[B]Favorites Manager[/B]', 'RunPlugin(%s)' % favorites_manager_params)])
			if season:
				if playcount:
					cm_append(['mark_watched', ('[B]Mark Unwatched[/B]', 'RunPlugin(%s)' % build_url({'mode': 'watched_status.mark_episode', 'action': 'mark_as_unwatched',
												'tmdb_id': tmdb_id, 'tvdb_id': tvdb_id, 'season': season, 'episode': episode,  'title': title}))])
				else: cm_append(['mark_watched', ('[B]Mark Watched[/B]', 'RunPlugin(%s)' % build_url({'mode': 'watched_status.mark_episode', 'action': 'mark_as_watched',
											'tmdb_id': tmdb_id, 'tvdb_id': tvdb_id, 'season': season, 'episode': episode,  'title': title}))])
				if progress:
					cm_append(['mark_watched', ('[B]Clear Progress[/B]', 'RunPlugin(%s)' % \
								build_url({'mode': 'watched_status.erase_bookmark', 'media_type': 'episode', 'tmdb_id': tmdb_id,
											'season': season, 'episode': episode, 'refresh': 'true'}))])
			if not unaired:
				if not show_progress_tag and unwatched_info and total_unwatched is not None and progress_aired_eps != total_unwatched:
					set_properties({'watchedepisodes': '1', 'unwatchedepisodes': str(total_unwatched)})
			_counts = _show_progress_properties(show_progress_tag, progress_aired_eps, total_watched, total_unwatched, show_progress, meta_get('total_seasons'))
			if _counts:
				set_properties(_counts)
				listitem.setLabel2('%s / %s' % (_counts['watchedepisodes'], _counts['totalepisodes']))
			show_unmark_previous = (
				list_type_starts_with('next_') and not unwatched
				and ws.previous_episode_watched(season, episode, watched_info, meta)
			)
			if show_unmark_previous:
				cm_append(['unmark_previous_episode', ('[B]Unmark Previous Watched[/B]', 'RunPlugin(%s)' % \
								build_url({'mode': 'watched_status.unmark_previous_episode', 'action': 'mark_as_unwatched', 'tmdb_id': tmdb_id, 'tvdb_id': tvdb_id,
											'season': season, 'episode': episode, 'title': title, 'refresh': 'true'}))])
			if is_external:
				cm.extend([['refresh', ('[B]Refresh Widgets[/B]', 'RunPlugin(%s)' % build_url({'mode': 'refresh_widgets'}))],
						['reload', ('[B]Reload Widgets[/B]', 'RunPlugin(%s)' % build_url({'mode': 'kodi_refresh'}))]])
			if custom_cm_menu:
				try: cm = sorted([i for i in cm if i[0] in cm_sort_order], key=lambda k: cm_sort_order[k[0]])
				except: pass
			cm = [i[1] for i in cm]
			# Legacy metacache used 1-tuples for studio; setStudios requires a list.
			if isinstance(studio, tuple): studio = list(studio)
			elif not studio: studio = []
			info_tag = listitem.getVideoInfoTag()
			# Estuary draws 4/10 on poster, banner, shift, and info wall only when the row is a TV show.
			info_tag.setMediaType('tvshow' if _counts else 'episode'), info_tag.setOriginalTitle(orig_title), info_tag.setTitle(display_title), info_tag.setGenres(genre)
			# Optional: widgets that bind TVShowTitle as a second line under Label.
			if not (is_external and omit_tvshowtitle_widgets):
				info_tag.setTvShowTitle(title)
			info_tag.setPlaycount(playcount), info_tag.setPlot(plot), info_tag.setFirstAired(premiered)
			# EPISODE format always omits Season/Episode tags. Optional Omit Season/Episode
			# Tags on Widgets does the same for TITLE/SxE widget formats so Label can hold
			# the full string without skins that bind Season/Episode duplicating SxE (#201).
			if display_format != 2 and not omit_season_episode_tags:
				info_tag.setSeason(label_season), info_tag.setEpisode(label_episode)
			info_tag.setDuration(duration), info_tag.setIMDBNumber(imdb_id), info_tag.setUniqueIDs({'imdb': imdb_id, 'tmdb': str(tmdb_id), 'tvdb': str(tvdb_id)})
			info_tag.setCountries(meta_get('country', [])), info_tag.setTrailer(trailer), info_tag.setTvShowStatus(show_status)
			info_tag.setStudios(studio), info_tag.setWriters(item_get('writer')), info_tag.setDirectors(item_get('director'))
			info_tag.setYear(int(year)), info_tag.setRating(item_get('rating')), info_tag.setVotes(item_get('votes')), info_tag.setMpaa(mpaa)
			full_cast = cast + (item_get('guest_stars') or [])
			info_tag.setCast([kodi_actor(name=item['name'], role=item['role'], thumbnail=item['thumbnail']) for item in full_cast])
			ws.clear_listitem_kodi_resume(info_tag)
			try: listitem.setContentLookup(False)
			except: pass
			if progress:
				ws.apply_listitem_progress(info_tag, set_properties, progress, duration, is_external)
			# A next-up was never played; its last_played is the show's, kept for sorting only (#284).
			if not is_next_up: ws.apply_listitem_last_played(info_tag, ep_data_get('last_played'))
			listitem.setLabel(display)
			listitem.addContextMenuItems(cm)
			listitem.setArt({'poster': show_poster, 'fanart': show_fanart, 'thumb': thumb, 'icon':thumb, 'clearlogo': show_clearlogo, 'landscape': thumb,
							'season.poster': season_poster, 'tvshow.poster': show_poster, 'tvshow.clearlogo': show_clearlogo,
							'tvshow.landscape': show_landscape})
			set_properties({
				'episode_type': episode_type, 'redlight.extras_params': extras_params, 'redlight.options_params': options_params,
				'redlight.playback_options_params': playback_options_params,
				'redlight.trakt_manager_params': trakt_manager_params,
				'redlight.wetrakr_manager_params': wetrakr_manager_params,
				'redlight.simkl_manager_params': simkl_manager_params,
				'redlight.punchplay_manager_params': punchplay_manager_params,
				'redlight.mdblist_manager_params': mdblist_manager_params,
				'redlight.personal_manager_params': personal_manager_params,
				'redlight.tmdb_manager_params': tmdb_manager_params,
				'redlight.favorites_manager_params': favorites_manager_params
				})
			_row_packet = None
			_cacheable_row = (
				list_type_starts_with('next_')
				or list_type_compare in (
					'simkl_public_calendar', 'wetrakr_public_calendar', 'wetrakr_personal_calendar', 'trakt_public_calendar', 'progress', 'recently_watched',
					'trakt_calendar', 'trakt_recently_aired', 'mdblist_calendar',
					'punchplay_calendar', 'simkl_calendar'
				)
			)
			if _cacheable_row:
				props = {
					'episode_type': episode_type, 'redlight.extras_params': extras_params, 'redlight.options_params': options_params,
					'redlight.playback_options_params': playback_options_params,
					'redlight.trakt_manager_params': trakt_manager_params,
				'redlight.wetrakr_manager_params': wetrakr_manager_params,
					'redlight.simkl_manager_params': simkl_manager_params,
					'redlight.punchplay_manager_params': punchplay_manager_params,
					'redlight.mdblist_manager_params': mdblist_manager_params,
					'redlight.personal_manager_params': personal_manager_params,
					'redlight.tmdb_manager_params': tmdb_manager_params,
					'redlight.favorites_manager_params': favorites_manager_params
				}
				if progress: props['WatchedProgress'] = progress
				_counts = _show_progress_properties(show_progress_tag, progress_aired_eps, total_watched, total_unwatched, show_progress, meta_get('total_seasons'))
				if _counts: props.update(_counts)
				elif unwatched_info and total_unwatched is not None and progress_aired_eps != total_unwatched:
					props['watchedepisodes'] = '1'
					props['unwatchedepisodes'] = str(total_unwatched)
				_row_packet = {
					'play_params': play_params, 'display': display, 'display_title': display_title, 'cm': list(cm),
					'art': {'poster': show_poster, 'fanart': show_fanart, 'thumb': thumb, 'icon': thumb, 'clearlogo': show_clearlogo,
							'landscape': thumb, 'season.poster': season_poster, 'tvshow.poster': show_poster, 'tvshow.clearlogo': show_clearlogo,
							'tvshow.landscape': show_landscape},
					'properties': props,
					'omit_tvshowtitle': bool(is_external and omit_tvshowtitle_widgets),
					'omit_season_episode': bool(display_format == 2 or omit_season_episode_tags),
					'display_format': display_format,
					'orig_title': orig_title, 'genre': genre, 'tvshowtitle': title, 'playcount': playcount, 'plot': plot,
					'premiered': premiered, 'season': season, 'episode': episode, 'duration': duration,
					'imdb_id': imdb_id, 'tmdb_id': tmdb_id, 'tvdb_id': tvdb_id, 'country': meta_get('country', []),
					'trailer': trailer, 'show_status': show_status, 'studio': studio,
					'writer': item_get('writer'), 'director': item_get('director'), 'year': int(year),
					'rating': item_get('rating'), 'votes': item_get('votes'), 'mpaa': mpaa,
					'cast': [{'name': i['name'], 'role': i['role'], 'thumbnail': i['thumbnail']} for i in full_cast],
					'resume_secs': None,
					'unaired': unaired, 'first_aired': premiered,
					'nextep_unmark_previous': bool(show_unmark_previous),
					'name': '%s - %sx%s' % (title, str(season), str_episode_zfill2),
					'last_played': ep_data_get('last_played', resinsert), 'sort_order': _position,
					'unwatched': ep_data_get('unwatched')
				}
				if list_type_starts_with('next_'):
					_row_packet['air_date'] = air_date_raw
					_row_packet['service_air'] = service_air
					_row_packet['date_unaired'] = date_unaired
					_row_packet['label_prefix'] = label_prefix
					_row_packet['label_body'] = label_body
					_row_packet['label_suffix'] = label_suffix
			item_list_append({'list_items': (play_params, listitem, False), 'first_aired': premiered, 'name': '%s - %sx%s' % (title, str(season), str_episode_zfill2),
							'unaired': unaired, 'last_played': ep_data_get('last_played', resinsert), 'sort_order': _position, 'unwatched': ep_data_get('unwatched'),
							'row_packet': _row_packet})
		except Exception as e:
			# Silent drops blank calendars/next-ep lists; log so meta/InfoTag failures are visible.
			try: kodi_utils.logger('Red Light', 'build_single_episode item failed (%s): %s' % (list_type, e))
			except: pass
	kodi_actor, make_listitem, build_url = kodi_utils.kodi_actor(), kodi_utils.make_listitem, kodi_utils.build_url
	poster_empty, fanart_empty = kodi_utils.get_icon('box_office'), kodi_utils.addon_fanart()
	handle, is_external = int(sys.argv[1]), kodi_utils.external()
	is_anime_list = 'is_anime_list' in params
	# Calendars / Next Up are not anime-filtered shelves — never pass False into meta_valid_check.
	if list_type in ('episode.trakt', 'episode.mdblist', 'episode.mdblist_next', 'episode.punchplay', 'episode.simkl', 'episode.simkl_public', 'episode.wetrakr_public', 'episode.wetrakr_personal', 'episode.trakt_public'):
		is_anime_list = None
	elif not is_anime_list and settings.include_anime_tvshow():
		is_anime_list = None
	item_list, airing_today, unwatched, return_results = [], [], [], False
	# Continue Watching merges the rows into its own directory instead of ending this one.
	collect = isinstance(params, dict) and params.get('collect') == 'true'
	# Next Episodes widgets: cut after sort. Cache still stores the full list.
	# Worked out before list_type is rewritten to episode.next_trakt / _simkl / etc.
	nextep_limit = _widget_item_limit(is_external) if list_type in ('episode.next', 'episode.mdblist_next') and not collect else 0
	resinsert = ''
	item_list_append = item_list.append
	def _finish(calendar_sort=False):
		if collect: return item_list
		_finish_single_episode_list(handle, item_list, _get_category_name(), is_external, calendar_sort=calendar_sort)
	window_command = 'ActivateWindow(Videos,%s,return)' if is_external else 'Container.Update(%s)'
	_nextep_ck, _nextep_token, _nextep_busy = None, None, False
	no_spoilers = settings.avoid_episode_spoilers()
	watched_indicators = settings.watched_indicators()
	# MDBList Lists → Next Up always uses MDBList watched history (not global Watched Status Provider).
	if list_type == 'episode.mdblist_next': watched_indicators = 3
	if list_type in ('episode.trakt', 'episode.mdblist', 'episode.punchplay', 'episode.simkl', 'episode.simkl_public', 'episode.wetrakr_public', 'episode.wetrakr_personal', 'episode.trakt_public'):
		display_format = settings.calendar_display_format(is_external)
		calendar_date_strftime, calendar_use_words, calendar_include_date = settings.calendar_date_label_options()
		calendar_date_format = None if calendar_use_words else calendar_date_strftime
	else:
		display_format = settings.single_ep_display_format(is_external)
		calendar_date_strftime, calendar_use_words, calendar_include_date = '%Y-%m-%d', True, False
		calendar_date_format = None
	current_date, current_time, adjust_hours = get_datetime(), get_current_timestamp(), settings.date_offset()
	unwatched_info = settings.single_ep_unwatched_episodes()
	show_progress_tag = (not is_external) and settings.single_episode_tvshow_view()
	show_watched_map = {}
	unwatched_in_title = settings.single_ep_unwatched_in_title()
	omit_tvshowtitle_widgets = settings.single_ep_widget_omit_tvshowtitle()
	omit_season_episode_tags = is_external and settings.single_ep_widget_omit_season_episode()
	hide_watched = is_external and settings.widget_hide_watched() and list_type not in ('episode.recently_watched', 'episode.progress')
	api_key, mpaa_region_value = settings.tmdb_api_key(), settings.mpaa_region()
	cm_sort_order, ignore_articles = settings.cm_sort_order(), settings.ignore_articles()
	custom_cm_menu = cm_sort_order != settings.cm_default_order()
	rpdb_info = settings.rpdb_info('tvshow')
	rpdb_api_key, rpdb_format = rpdb_info['rpdb_api_key'], rpdb_info['rpdb_format']
	playback_key = settings.playback_key()
	play_mode = 'playback.%s' % playback_key
	watched_db = ws.get_database(watched_indicators)
	if list_type in ('episode.next', 'episode.mdblist_next'):
		ws.clear_local_bookmarks()
		try: ws._purge_negligible_progress(ws.get_database(watched_indicators))
		except: pass
		mdblist_menu_next = list_type == 'episode.mdblist_next'
		include_unwatched, include_unaired, nextep_content = settings.nextep_include_unwatched(), settings.nextep_include_unaired(), settings.nextep_method()
		sort_override = settings.parse_nextep_sort_key(params.get('nextep_sort'))
		sort_key, sort_direction = settings.nextep_sort_key(sort_override), settings.nextep_sort_direction()
		include_airdate = settings.nextep_include_airdate()
		if watched_indicators in (1, 2, 3, 4, 5):
			resformat, resinsert = '%Y-%m-%dT%H:%M:%S.%fZ', '2000-01-01T00:00:00.000Z'
			list_type = {1: 'episode.next_trakt', 2: 'episode.next_simkl', 3: 'episode.next_mdblist', 4: 'episode.next_punchplay', 5: 'episode.next_wetrakr'}[watched_indicators]
		else: resformat, resinsert, list_type = '%Y-%m-%d %H:%M:%S', '2000-01-01 00:00:00', 'episode.next_redlight'
		if mdblist_menu_next: category_override = 'MDBList Next Up'
		elif sort_override == 'last_played': category_override = 'Next Episodes (Recently Watched)'
		elif sort_override == 'first_aired': category_override = 'Next Episodes (Airdate)'
		elif sort_override == 'name': category_override = 'Next Episodes (Title)'
		list_type_compare = list_type.split('episode.')[1]
		list_type_starts_with = list_type_compare.startswith
		# A PunchPlay drop does not touch the local watched DB, so it cannot bust this
		# cache by itself. Sync first so the hide token sees the drop (#289).
		if watched_indicators == 4 and settings.punchplay_user_active():
			try:
				if not kodi_utils.playback_list_sync_skip_recent():
					ws._refresh_punchplay_tvshow_watched()
			except: pass
		# Umbrella-style: reuse built rows when watched/progress/hide (+ include-unwatched) unchanged.
		try:
			from caches import nextep_cache
			_nextep_ck = nextep_cache.cache_id(watched_indicators, mdblist_menu_next, is_anime_list, is_external, sort_key)
			_nextep_token = nextep_cache.activity_token(watched_indicators)
			if include_unwatched != 0:
				_uw_extra = []
				if include_unwatched in (1, 3):
					try: _uw_extra.extend(str(i['media_ids'].get('tmdb')) for i in (_nextep_indicator_watchlist(watched_indicators) or []) if i.get('media_ids'))
					except: pass
				if include_unwatched in (2, 3):
					try:
						from caches.favorites_cache import favorites_cache
						_uw_extra.extend(str(i['tmdb_id']) for i in (favorites_cache.get_favorites('tvshow') or []))
					except: pass
				_nextep_token = '%s|uw:%s|%s' % (_nextep_token, include_unwatched, ','.join(sorted(set(_uw_extra))))
			_cached_packets = nextep_cache.get_packets(_nextep_ck, _nextep_token)
		except:
			_nextep_ck, _nextep_token, _cached_packets = None, None, None
		if _cached_packets:
			_shown = 0
			for _packet in _cached_packets:
				_before = len(item_list)
				_paint_episode_list_packet(
					_packet, item_list_append, make_listitem, kodi_actor, watched_db, is_external,
					live_progress=True, log_label='nextep cache', set_last_played=False, apply_airtime=True)
				if len(item_list) == _before: continue
				_shown += 1
				if nextep_limit and _shown >= nextep_limit: break
			return _finish()
		# Cold rebuild (#203): Kodi's GetDirectory busy often dies when fullscreen closes after
		# Stop; keep an explicit spinner until rows are ready (warm cache hits skip this).
		# Widgets load in the background — a no-cancel spinner there locks Home until it ends.
		_nextep_busy = not is_external
		if _nextep_busy:
			try: kodi_utils.show_busy_dialog()
			except: pass
		_wetrakr_up_failed = False
		try:
			# Right after Stop, local watched/progress is already written — blocking Simkl/Trakt/etc.
			# sync is the main wait even with one row. Skip ~30s; monitors / later opens still sync.
			_skip_provider_refresh = False
			try: _skip_provider_refresh = kodi_utils.playback_list_sync_skip_recent()
			except: pass
			if _skip_provider_refresh:
				try: kodi_utils.logger('Red Light', 'Next Episodes: skip provider sync (recent playback)')
				except: pass
			elif watched_indicators == 3 and settings.mdblist_user_active():
				try: ws._refresh_mdblist_tvshow_watched()
				except: pass
			elif watched_indicators == 1 and settings.trakt_user_active():
				try: ws._refresh_trakt_tvshow_watched()
				except: pass
			elif watched_indicators == 2 and settings.simkl_user_active():
				try: ws._refresh_simkl_tvshow_watched()
				except: pass
			elif watched_indicators == 4 and settings.punchplay_user_active():
				try: ws._refresh_punchplay_tvshow_watched()
				except: pass
			elif watched_indicators == 5 and settings.wetrakr_user_active():
				try: ws._refresh_wetrakr_tvshow_watched()
				except: pass
			data = ws.get_next_episodes(nextep_content, watched_indicators)
			_played = {}
			for _row in data:
				try: _played[int(_row['media_ids']['tmdb'])] = _row.get('last_played')
				except Exception: pass
			if settings.nextep_limit_history(): data = data[:settings.nextep_limit()]
			hidden_list = set()
			for _hid in ws.get_hidden_progress_items(watched_indicators) or []:
				try: hidden_list.add(int(_hid))
				except (TypeError, ValueError): pass
			if hidden_list:
				data = [i for i in data if int(i['media_ids']['tmdb']) not in hidden_list]
			if watched_indicators == 5 and settings.wetrakr_user_active():
				try:
					from apis.wetrakr_api import wetrakr_up_next_episodes
					_up_rows = wetrakr_up_next_episodes()
				except Exception:
					_up_rows = None
				if _up_rows is None:
					_wetrakr_up_failed = True
					if _nextep_ck:
						try:
							from caches import nextep_cache
							_stale_packets = (nextep_cache.get_stale_payload(_nextep_ck) or {}).get('packets') or []
							if _stale_packets:
								_shown = 0
								for _packet in _stale_packets:
									_before = len(item_list)
									_paint_episode_list_packet(
										_packet, item_list_append, make_listitem, kodi_actor, watched_db, is_external,
										live_progress=True, log_label='nextep wetrakr fallback', set_last_played=False,
										apply_airtime=True)
									if len(item_list) == _before: continue
									_shown += 1
									if nextep_limit and _shown >= nextep_limit: break
								if _nextep_busy:
									try: kodi_utils.hide_busy_dialog()
									except: pass
								return _finish()
						except Exception: pass
				else:
					data = _apply_wetrakr_up_next(data, hidden_list, _up_rows, _played)
			if include_unwatched != 0:
				if include_unwatched in (1, 3):
					try:
						watchlist = _nextep_indicator_watchlist(watched_indicators)
						unwatched.extend([{'media_ids': i['media_ids'], 'season': 1, 'episode': 0, 'unwatched': True, 'title': i['title']} for i in watchlist])
					except: pass
				if include_unwatched in (2, 3):
					from caches.favorites_cache import favorites_cache
					try:
						favorites = favorites_cache.get_favorites('tvshow')
						unwatched.extend([{'media_ids': {'tmdb': int(i['tmdb_id'])}, 'season': 1, 'episode': 0, 'unwatched': True, 'title': i['title']} \
										for i in favorites if not int(i['tmdb_id']) in [x['media_ids']['tmdb'] for x in data]])
					except: pass
				data += unwatched
		except Exception:
			try: kodi_utils.hide_busy_dialog()
			except: pass
			_nextep_busy = False
			data = []
	elif list_type == 'episode.progress':
		ws.clear_local_bookmarks()
		data = ws.get_in_progress_episodes()
	elif list_type == 'episode.recently_watched': data = ws.get_recently_watched('episode', short_list=True)
	elif list_type == 'episode.trakt':
		from apis.trakt_api import trakt_get_my_calendar
		recently_aired = params.get('recently_aired', None)
		data = trakt_get_my_calendar(recently_aired, get_datetime())
		hidden_list = ws.get_hidden_progress_items(watched_indicators)
		if hidden_list: data = [i for i in data if not i['media_ids']['tmdb'] in hidden_list]
		list_type = 'episode.trakt_recently_aired' if recently_aired else 'episode.trakt_calendar'
		if settings.flatten_episodes():
			try:
				duplicates = set()
				data.sort(key=lambda i: i['sort_title'])
				data = [i for i in data if not ((i['media_ids']['tmdb'], i['first_aired'].split('T')[0]) in duplicates
						or duplicates.add((i['media_ids']['tmdb'], i['first_aired'].split('T')[0])))]
			except: pass
		else:
			try: data = sorted(data, key=lambda i: (i['sort_title'], i.get('first_aired', '2100-12-31')), reverse=True)
			except: data = sorted(data, key=lambda i: i['sort_title'], reverse=True)
	elif list_type == 'episode.mdblist':
		from apis.mdblist_api import mdblist_get_my_calendar
		data = mdblist_get_my_calendar()
		hidden_list = ws.get_hidden_progress_items(watched_indicators)
		if hidden_list: data = [i for i in data if not i['media_ids']['tmdb'] in hidden_list]
		list_type = 'episode.mdblist_calendar'
		if settings.flatten_episodes():
			try:
				duplicates = set()
				data.sort(key=lambda i: i['sort_title'])
				data = [i for i in data if not ((i['media_ids']['tmdb'], i['first_aired'].split('T')[0]) in duplicates
						or duplicates.add((i['media_ids']['tmdb'], i['first_aired'].split('T')[0])))]
			except: pass
		else:
			try: data = sorted(data, key=lambda i: (i['sort_title'], i.get('first_aired', '2100-12-31')), reverse=True)
			except: data = sorted(data, key=lambda i: i['sort_title'], reverse=True)
	elif list_type == 'episode.punchplay':
		from apis.punchplay_api import punchplay_get_my_calendar
		data = punchplay_get_my_calendar()
		hidden_list = set()
		for _hid in ws.get_hidden_progress_items(watched_indicators) or []:
			try: hidden_list.add(int(_hid))
			except (TypeError, ValueError): pass
		if hidden_list:
			data = [i for i in data if int(i['media_ids']['tmdb']) not in hidden_list]
		list_type = 'episode.punchplay_calendar'
		if settings.flatten_episodes():
			try:
				duplicates = set()
				data.sort(key=lambda i: i['sort_title'])
				data = [i for i in data if not ((i['media_ids']['tmdb'], i['first_aired'].split('T')[0]) in duplicates
						or duplicates.add((i['media_ids']['tmdb'], i['first_aired'].split('T')[0])))]
			except: pass
		else:
			try: data = sorted(data, key=lambda i: (i['sort_title'], i.get('first_aired', '2100-12-31')), reverse=True)
			except: data = sorted(data, key=lambda i: i['sort_title'], reverse=True)
	elif list_type == 'episode.simkl':
		from apis.simkl_api import simkl_get_my_calendar
		data = simkl_get_my_calendar()
		hidden_list = ws.get_hidden_progress_items(watched_indicators)
		if hidden_list: data = [i for i in data if not i['media_ids']['tmdb'] in hidden_list]
		list_type = 'episode.simkl_calendar'
		if settings.flatten_episodes():
			try:
				duplicates = set()
				data.sort(key=lambda i: i['sort_title'])
				data = [i for i in data if not ((i['media_ids']['tmdb'], i['first_aired'].split('T')[0]) in duplicates
						or duplicates.add((i['media_ids']['tmdb'], i['first_aired'].split('T')[0])))]
			except: pass
		else:
			try: data = sorted(data, key=lambda i: (i['sort_title'], i.get('first_aired', '2100-12-31')), reverse=True)
			except: data = sorted(data, key=lambda i: i['sort_title'], reverse=True)
	elif list_type == 'episode.simkl_public':
		from apis.simkl_api import simkl_get_public_calendar
		feeds = params.get('feeds')
		if not feeds:
			feeds = 'all' if settings.public_calendar_include_anime() else 'tv'
		data = simkl_get_public_calendar(feeds)
		list_type = 'episode.simkl_public_calendar'
		if feeds == 'anime': category_override = 'Public Anime Calendar'
		elif feeds == 'tv': category_override = 'Public TV Calendar'
		else: category_override = 'Public Calendar'
		if settings.flatten_episodes():
			try:
				duplicates = set()
				data.sort(key=lambda i: i['sort_title'])
				data = [i for i in data if not ((i['media_ids']['tmdb'], i['first_aired'].split('T')[0]) in duplicates
						or duplicates.add((i['media_ids']['tmdb'], i['first_aired'].split('T')[0])))]
			except: pass
		else:
			try: data = sorted(data, key=lambda i: (i['sort_title'], i.get('first_aired', '2100-12-31')), reverse=True)
			except: data = sorted(data, key=lambda i: i['sort_title'], reverse=True)
	elif list_type == 'episode.wetrakr_public':
		from apis.wetrakr_api import wetrakr_get_public_calendar
		data = wetrakr_get_public_calendar()
		list_type = 'episode.wetrakr_public_calendar'
		category_override = 'WeTrakr Calendar'
		if settings.flatten_episodes():
			try:
				duplicates = set()
				data.sort(key=lambda i: i['sort_title'])
				data = [i for i in data if not ((i['media_ids']['tmdb'], i['first_aired'].split('T')[0]) in duplicates
						or duplicates.add((i['media_ids']['tmdb'], i['first_aired'].split('T')[0])))]
			except: pass
		else:
			try: data = sorted(data, key=lambda i: (i['sort_title'], i.get('first_aired', '2100-12-31')), reverse=True)
			except: data = sorted(data, key=lambda i: i['sort_title'], reverse=True)
	elif list_type == 'episode.wetrakr_personal':
		from apis.wetrakr_api import wetrakr_get_public_calendar
		data = wetrakr_get_public_calendar('following')
		list_type = 'episode.wetrakr_personal_calendar'
		category_override = 'WeTrakr Calendar'
		if settings.flatten_episodes():
			try:
				duplicates = set()
				data.sort(key=lambda i: i['sort_title'])
				data = [i for i in data if not ((i['media_ids']['tmdb'], i['first_aired'].split('T')[0]) in duplicates
						or duplicates.add((i['media_ids']['tmdb'], i['first_aired'].split('T')[0])))]
			except: pass
		else:
			try: data = sorted(data, key=lambda i: (i['sort_title'], i.get('first_aired', '2100-12-31')), reverse=True)
			except: data = sorted(data, key=lambda i: i['sort_title'], reverse=True)
	elif list_type == 'episode.trakt_public':
		from apis.trakt_api import trakt_get_public_calendar
		data = trakt_get_public_calendar()
		list_type = 'episode.trakt_public_calendar'
		category_override = 'Trakt Calendar'
		if settings.flatten_episodes():
			try:
				duplicates = set()
				data.sort(key=lambda i: i['sort_title'])
				data = [i for i in data if not ((i['media_ids']['tmdb'], i['first_aired'].split('T')[0]) in duplicates
						or duplicates.add((i['media_ids']['tmdb'], i['first_aired'].split('T')[0])))]
			except: pass
		else:
			try: data = sorted(data, key=lambda i: (i['sort_title'], i.get('first_aired', '2100-12-31')), reverse=True)
			except: data = sorted(data, key=lambda i: i['sort_title'], reverse=True)
	else: data, return_results = sorted(params, key=lambda i: i['custom_order']), True
	list_type_compare = list_type.split('episode.')[1]
	list_type_starts_with = list_type_compare.startswith
	is_next_up = list_type_starts_with('next_') or list_type_compare == 'mdblist_next'
	_pubcal_ck, _pubcal_token = None, None
	_progress_ck, _progress_token = None, None
	_recent_ck, _recent_token = None, None
	_pcal_ck, _pcal_token = None, None

	# In Progress: refresh already ran in get_in_progress_episodes — then token-check.
	if list_type_compare == 'progress':
		try:
			from caches import progress_episodes_cache
			_progress_ck = progress_episodes_cache.cache_id(watched_indicators, is_external)
			_progress_token = progress_episodes_cache.activity_token(watched_indicators, data)
			_cached_packets = progress_episodes_cache.get_packets(_progress_ck, _progress_token)
		except:
			_progress_ck, _progress_token, _cached_packets = None, None, None
		if _cached_packets:
			for _packet in _cached_packets:
				_paint_episode_list_packet(
					_packet, item_list_append, make_listitem, kodi_actor, watched_db, is_external,
					live_progress=True, log_label='progress episodes cache')
			return _finish()

	# Recently Watched: data already fetched (MDBList/PunchPlay refresh inside get_recently_watched).
	if list_type_compare == 'recently_watched':
		try:
			from caches import recent_watched_cache
			_recent_ck = recent_watched_cache.cache_id(watched_indicators, is_external, short_list=True)
			_recent_token = recent_watched_cache.activity_token(watched_indicators, data)
			_cached_packets = recent_watched_cache.get_packets(_recent_ck, _recent_token)
		except:
			_recent_ck, _recent_token, _cached_packets = None, None, None
		if _cached_packets:
			for _packet in _cached_packets:
				_paint_episode_list_packet(
					_packet, item_list_append, make_listitem, kodi_actor, watched_db, is_external,
					live_progress=True, log_label='recent watched cache')
			return _finish()

	# Personal calendars: feed already fetched — then token-check (day in fingerprint).
	if list_type_compare in ('trakt_calendar', 'trakt_recently_aired', 'mdblist_calendar', 'punchplay_calendar', 'simkl_calendar'):
		try:
			from caches import personal_calendar_cache
			_pcal_ck = personal_calendar_cache.cache_id(list_type_compare, is_external)
			_pcal_token = personal_calendar_cache.activity_token(data, watched_indicators)
			_cached_packets = personal_calendar_cache.get_packets(_pcal_ck, _pcal_token)
		except:
			_pcal_ck, _pcal_token, _cached_packets = None, None, None
		if _cached_packets:
			for _packet in _cached_packets:
				_paint_episode_list_packet(
					_packet, item_list_append, make_listitem, kodi_actor, watched_db, is_external,
					live_progress=True, log_label='personal calendar cache')
			return _finish(calendar_sort=True)

	if list_type_compare in ('simkl_public_calendar', 'wetrakr_public_calendar', 'wetrakr_personal_calendar', 'trakt_public_calendar') and settings.public_calendar_cache_list():
		try:
			from caches import public_calendar_cache
			if list_type_compare == 'wetrakr_personal_calendar': _pubcal_feeds = 'wetrakr_personal'
			elif list_type_compare == 'wetrakr_public_calendar': _pubcal_feeds = 'wetrakr'
			elif list_type_compare == 'trakt_public_calendar': _pubcal_feeds = 'trakt'
			else: _pubcal_feeds = params.get('feeds') or 'all'
			_pubcal_ck = public_calendar_cache.cache_id(_pubcal_feeds, is_external)
			_pubcal_token = public_calendar_cache.activity_token(data, watched_indicators)
			_cached_packets = public_calendar_cache.get_packets(_pubcal_ck, _pubcal_token)
		except:
			_pubcal_ck, _pubcal_token, _cached_packets = None, None, None
		if _cached_packets:
			for _packet in _cached_packets:
				_paint_episode_list_packet(
					_packet, item_list_append, make_listitem, kodi_actor, watched_db, is_external,
					live_progress=True, log_label='public calendar cache')
			return _finish(calendar_sort=True)
	try:
		process_data = data
		# Next Episodes incremental: token miss but stale packets exist — rebuild dirty shows only.
		if list_type_starts_with('next_') and _nextep_ck:
			try:
				from caches import nextep_cache
				_stale = nextep_cache.get_stale_payload(_nextep_ck)
				if _stale:
					_stale_packets = _stale.get('packets') or []
					_stale_activity = _stale.get('show_activity') or {}
					_cur_activity = nextep_cache.show_activity(watched_indicators)
					_stale_by_tmdb = {}
					for _p in _stale_packets:
						try: _stale_by_tmdb[str(_p['tmdb_id'])] = _p
						except: pass
					dirty_data, clean_ok = [], True
					for _item in data:
						try: _tmdb = str(_item['media_ids']['tmdb'])
						except:
							dirty_data.append(_item)
							continue
						_stale_p = _stale_by_tmdb.get(_tmdb)
						if not _stale_p or _stale_activity.get(_tmdb) != _cur_activity.get(_tmdb):
							dirty_data.append(_item)
						else:
							try:
								_paint_episode_list_packet(
									_stale_p, item_list_append, make_listitem, kodi_actor, watched_db, is_external,
									live_progress=True, log_label='nextep incremental', set_last_played=False,
									apply_airtime=True, keep_hidden=True)
							except:
								clean_ok = False
								break
					if clean_ok:
						process_data = dirty_data
					else:
						del item_list[:]
						process_data = data
			except:
				del item_list[:]
				process_data = data
		if process_data:
			if unwatched_info or show_progress_tag:
				try: show_watched_map = ws.watched_info_tvshow(watched_db) or {}
				except: show_watched_map = {}
			threads = TaskPool().tasks_enumerate(_process, process_data, min(len(process_data), settings.max_threads()))
			[i.join() for i in threads]
		if return_results: return [(i['list_items'], i['sort_order']) for i in item_list]
		if list_type_starts_with('next_'):
			use_latest_activity = sort_key == 'last_played' and settings.nextep_sort_latest_activity()
			def func(function):
				if sort_key == 'name': return title_key(function, ignore_articles)
				elif sort_key == 'last_played': return jsondate_to_datetime(function, resformat)
				else: return function
			if (not use_latest_activity) and settings.nextep_airing_today():
				airing_today, item_list = _pin_recently_aired(item_list, current_date, settings.nextep_airing_today_days())
			else: airing_today = []
			if use_latest_activity:
				item_list = sorted(item_list, key=lambda i: _nextep_activity_datetime(i, resformat, current_date), reverse=sort_direction)
			elif sort_key == 'last_played':
				unwatched = sorted([i for i in item_list if i['unwatched']], key=lambda i: title_key(i['name'], ignore_articles))
				item_list = sorted([i for i in item_list if not i['unwatched']], key=lambda i: func(i[sort_key]), reverse=sort_direction) + unwatched
			else: item_list = sorted(item_list, key=lambda i: func(i[sort_key]), reverse=sort_direction)
			item_list = airing_today + item_list
		else:
			item_list.sort(key=lambda i: i['sort_order'])
			if list_type_compare in ('trakt_calendar', 'trakt_recently_aired', 'mdblist_calendar', 'punchplay_calendar', 'simkl_calendar', 'simkl_public_calendar', 'wetrakr_public_calendar', 'wetrakr_personal_calendar', 'trakt_public_calendar'):
				if list_type_compare in ('trakt_calendar', 'mdblist_calendar', 'punchplay_calendar', 'simkl_calendar', 'simkl_public_calendar', 'wetrakr_public_calendar', 'wetrakr_personal_calendar', 'trakt_public_calendar'): reverse = settings.calendar_sort_order() == 0
				else: reverse = True
				try: item_list = sorted(item_list, key=lambda i: i.get('first_aired', '2100-12-31'), reverse=reverse)
				except:
					item_list = [i for i in item_list if i.get('first_aired') not in (None, 'None', '')]
					item_list = sorted(item_list, key=lambda i: i.get('first_aired'), reverse=reverse)
				if list_type_compare in ('trakt_calendar', 'mdblist_calendar', 'punchplay_calendar', 'simkl_calendar', 'simkl_public_calendar', 'wetrakr_public_calendar', 'wetrakr_personal_calendar', 'trakt_public_calendar') and not calendar_date_format:
					airing_today = sorted([i for i in item_list if date_difference(current_date, jsondate_to_datetime(i.get('first_aired', '2100-12-31'), '%Y-%m-%d').date(), 0)],
											key=lambda i: i['first_aired'])
					item_list = [i for i in item_list if not i in airing_today]
					item_list = airing_today + item_list
		_row_packets = [i['row_packet'] for i in item_list if i.get('row_packet')]
		if list_type_starts_with('next_'):
			# Held rows stay in the cache so they can appear later the same day.
			# Include Unaired still shows them, in red, inside the 7-day window.
			if include_unaired: item_list = [i for i in item_list if i.get('list_items')]
			else: item_list = [i for i in item_list if i.get('list_items') and not i.get('unaired')]
		if list_type_starts_with('next_') and _nextep_ck:
			try:
				from caches import nextep_cache
				_nextep_token = nextep_cache.activity_token(watched_indicators)
				if include_unwatched != 0:
					_uw_extra = []
					if include_unwatched in (1, 3):
						try: _uw_extra.extend(str(i['media_ids'].get('tmdb')) for i in (_nextep_indicator_watchlist(watched_indicators) or []) if i.get('media_ids'))
						except: pass
					if include_unwatched in (2, 3):
						try:
							from caches.favorites_cache import favorites_cache
							_uw_extra.extend(str(i['tmdb_id']) for i in (favorites_cache.get_favorites('tvshow') or []))
						except: pass
					_nextep_token = '%s|uw:%s|%s' % (_nextep_token, include_unwatched, ','.join(sorted(set(_uw_extra))))
				if _row_packets and not _wetrakr_up_failed:
					nextep_cache.set_packets(
						_nextep_ck, _nextep_token, _row_packets,
						show_activity_map=nextep_cache.show_activity(watched_indicators))
			except: pass
		if list_type_compare in ('simkl_public_calendar', 'wetrakr_public_calendar', 'wetrakr_personal_calendar', 'trakt_public_calendar') and _pubcal_ck:
			try:
				from caches import public_calendar_cache
				if _row_packets: public_calendar_cache.set_packets(_pubcal_ck, _pubcal_token, _row_packets)
			except: pass
		if list_type_compare == 'progress' and _progress_ck:
			try:
				from caches import progress_episodes_cache
				if _row_packets: progress_episodes_cache.set_packets(_progress_ck, _progress_token, _row_packets)
			except: pass
		if list_type_compare == 'recently_watched' and _recent_ck:
			try:
				from caches import recent_watched_cache
				if _row_packets: recent_watched_cache.set_packets(_recent_ck, _recent_token, _row_packets)
			except: pass
		if list_type_compare in ('trakt_calendar', 'trakt_recently_aired', 'mdblist_calendar', 'punchplay_calendar', 'simkl_calendar') and _pcal_ck:
			try:
				from caches import personal_calendar_cache
				if _row_packets: personal_calendar_cache.set_packets(_pcal_ck, _pcal_token, _row_packets)
			except: pass
		# Widget cut after the full list is cached (sorted, airing-today pins first).
		if nextep_limit and list_type_starts_with('next_'): item_list = item_list[:nextep_limit]
		# Keep plugin order for calendars — Kodi "Sort by Date" was reordering vs day labels.
		_calendar_sort = list_type_compare in ('trakt_calendar', 'mdblist_calendar', 'punchplay_calendar', 'simkl_calendar', 'simkl_public_calendar', 'wetrakr_public_calendar', 'wetrakr_personal_calendar', 'trakt_public_calendar', 'trakt_recently_aired')
		return _finish(calendar_sort=_calendar_sort)
	finally:
		if _nextep_busy:
			try: kodi_utils.hide_busy_dialog()
			except: pass
