# -*- coding: utf-8 -*-
"""Anime season lists for shows whose TMDb seasons do not match the cours.

ani.zip supplies the episode order. AniList search and prequel/sequel links
collect every part that shares this TMDb show. A TMDb episode group named
Seasons adds cours ani.zip has not split yet. Episodes that are still only on
TMDb are added after that, so a new cour can be opened before ani.zip lists it.
Watched and scrobble stay on the TMDb episode the row points back to.
"""
from datetime import date
import requests
from caches.main_cache import main_cache
from modules import metadata
from modules.kodi_utils import logger

_ANILIST = 'https://graphql.anilist.co'
_ANIZIP = 'https://api.ani.zip/mappings'
_HEADERS = {'User-Agent': 'RedLight', 'Accept': 'application/json'}
_TV_FORMATS = ('TV', 'TV_SHORT', 'ONA', 'OVA')
_SEARCH = '''
query ($search: String) {
  Page(page: 1, perPage: 8) {
    media(search: $search, type: ANIME, format_in: [TV, TV_SHORT, ONA, OVA]) {
      id
      idMal
      title { romaji english }
    }
  }
}
'''
_MEDIA = '''
query ($id: Int) {
  Media(id: $id) {
    id
    idMal
    format
    title { romaji english }
    relations { edges { relationType node { id format } } }
  }
}
'''


def for_show(meta):
	"""Cached map for an anime show, or None when this show stays on TMDb seasons."""
	if not meta or not metadata.is_anime_check(meta):
		return None
	tmdb_id = str(meta.get('tmdb_id') or '')
	if not tmdb_id:
		return None
	key = 'anime_map_v3_%s' % tmdb_id
	cached = main_cache.get(key)
	if cached is not None:
		return cached or None
	try:
		built = _build(meta)
	except Exception as exc:
		logger('Red Light', 'Anime map %s failed: %s' % (tmdb_id, exc))
		return None
	if not built:
		main_cache.set(key, {}, expiration=12)
		return None
	if built.get('source') == 'anizip' and meta.get('status') in ('Ended', 'Canceled'):
		hours = 168
	elif built.get('source') == 'anizip':
		hours = 24
	else:
		hours = 12
	main_cache.set(key, built, expiration=hours)
	episode_count = sum(len(part.get('episodes') or []) for part in built.get('parts') or [])
	logger('Red Light', 'Anime map %s: %s season(s), %s episode(s) via %s' % (tmdb_id, len(built.get('parts') or []), episode_count, built.get('source')))
	return built


def for_id(tmdb_id):
	if not tmdb_id:
		return None
	from modules.settings import tmdb_api_key, mpaa_region
	from modules.utils import get_datetime
	meta = metadata.tvshow_meta('tmdb_id', tmdb_id, tmdb_api_key(), mpaa_region(), get_datetime())
	return for_show(meta)


def row_for_meta(meta, season, episode):
	show = for_show(meta)
	if not show:
		return {}
	return _row_by_tmdb(show, season, episode) or {}


def row_for_playback(tmdb_id, season, episode):
	"""Map row for the TMDb episode a play URL names. Empty when this play stays on TMDb numbers."""
	try:
		show = for_id(tmdb_id)
	except Exception:
		return {}
	if not show:
		return {}
	return _row_by_tmdb(show, season, episode) or {}


def season_items(show, season_data=None):
	"""Season rows for build_season_list, or None when the show has no map."""
	if not show or not show.get('parts'):
		return None
	tmdb_posters = {}
	for item in season_data or []:
		try:
			num = int(item.get('season_number'))
		except (TypeError, ValueError):
			continue
		if num > 0 and item.get('poster_path'):
			tmdb_posters[num] = item['poster_path']
	items = []
	for part in show['parts']:
		episodes = part.get('episodes') or []
		dates = sorted(ep.get('premiered') for ep in episodes if ep.get('premiered'))
		tmdb_season = None
		for ep in episodes:
			try:
				tmdb_season = int(ep.get('tmdb_season'))
			except (TypeError, ValueError):
				continue
			if tmdb_season:
				break
		items.append({
			'name': part.get('name') or 'Season %s' % part.get('display_season'),
			'overview': part.get('overview') or '',
			'poster_path': tmdb_posters.get(tmdb_season),
			'air_date': dates[0] if dates else '',
			'season_number': part.get('display_season'),
			'episode_count': len(episodes),
			'anime_episodes': episodes,
			'anime_poster': part.get('poster') or '',
		})
	return items


def episode_items(show, season):
	"""Episode rows for one display season, or every season when season is None.

	None means this display season is not on the map (caller keeps the TMDb list).
	"""
	if not show or not show.get('parts'):
		return None
	if season is not None:
		try:
			season = int(season)
		except (TypeError, ValueError):
			return None
		if not any(int(part.get('display_season') or 0) == season for part in show['parts']):
			return None
	rows = []
	for part in show['parts']:
		if season is not None and int(part.get('display_season') or 0) != season:
			continue
		for ep in part.get('episodes') or []:
			rows.append(_list_episode(ep))
	rows.sort(key=lambda item: (item.get('season') or 0, item.get('episode') or 0))
	return rows


def next_tmdb(meta, season, episode, watched_info, nextep_content):
	"""(tmdb_season, tmdb_episode) of the next anime episode, or None to keep TMDb order.

	(None, None) means the map handled this show and there is no next episode.
	"""
	show = for_show(meta)
	if not show:
		return None
	flat = _flat(show)
	index = _tmdb_index(flat, season, episode)
	if index is None:
		return None
	from modules.watched_status import get_watched_status_episode
	for row in flat[index + 1:]:
		pair = _tmdb_pair(row)
		if not pair:
			continue
		if nextep_content == 0 or not get_watched_status_episode(watched_info, pair):
			return pair
	return (None, None)


def previous_tmdb_for_id(tmdb_id, season, episode):
	"""Previous episode's TMDb pair, () when this is the first, or None when no map applies."""
	try:
		if not metadata.is_anime_check(tmdb_id=tmdb_id):
			return None
		show = for_id(tmdb_id)
	except Exception:
		return None
	if not show:
		return None
	flat = _flat(show)
	index = _tmdb_index(flat, season, episode)
	if index is None:
		return None
	if index <= 0:
		return ()
	return _tmdb_pair(flat[index - 1]) or ()


def watched_tally(episodes, watched_rows, current_date, adjust_hours):
	"""(aired count, watched count) for one anime season, using TMDb pairs."""
	from modules.utils import adjust_premiered_date
	watched_set = set()
	for row in watched_rows or []:
		try:
			watched_set.add((int(row[0]), int(row[1])))
		except (TypeError, ValueError, IndexError):
			continue
	aired, watched = 0, 0
	for ep in episodes or []:
		premiered = ep.get('broadcast') or ep.get('premiered') or ''
		if premiered:
			try:
				episode_date, _premiered = adjust_premiered_date(premiered, adjust_hours)
			except Exception:
				episode_date = None
			if episode_date and current_date < episode_date:
				continue
		aired += 1
		pair = _tmdb_pair(ep)
		if pair and pair in watched_set:
			watched += 1
	return aired, watched


def _build(meta):
	tmdb_id = str(meta.get('tmdb_id') or '')
	parts, source = [], ''
	loose = []
	try:
		parts, loose = _anizip_parts(meta, tmdb_id)
		source = 'anizip'
	except Exception as exc:
		logger('Red Light', 'Anime map ani.zip %s: %s' % (tmdb_id, exc))
		parts, loose = [], []
	try:
		group_parts = _group_parts(tmdb_id)
	except Exception as exc:
		logger('Red Light', 'Anime map episode group %s: %s' % (tmdb_id, exc))
		group_parts = []
	if not parts:
		parts = group_parts
		group_parts = []
		source = 'episode_group' if parts else ''
	if not parts:
		return {}
	try:
		tmdb_eps = metadata.all_episodes_meta(meta) or []
	except Exception:
		tmdb_eps = []
	_bind_tmdb(parts, tmdb_eps)
	parts = _dedupe_bound(parts)
	if group_parts:
		_merge_uncovered(parts, group_parts)
	_fill_tmdb_gaps(parts, tmdb_eps, meta)
	_overlay_kitsu(parts, loose, tmdb_eps)
	parts = [part for part in parts if part.get('episodes')]
	if not parts:
		return {}
	parts.sort(key=lambda part: _int(part.get('display_season'), 0))
	_stamp(parts)
	return {'tmdb_id': tmdb_id, 'source': source or 'tmdb', 'parts': parts}


def _anizip_parts(meta, tmdb_id):
	chain, loose = _matching_entries(meta, tmdb_id)
	if not chain:
		return [], loose
	if len(chain) == 1:
		return _parts_from_one(chain[0]), loose
	parts = []
	for index, (media, mapping) in enumerate(chain, 1):
		episodes = _rows_from_mapping(mapping, index, cour_episode=True)
		if not episodes:
			continue
		parts.append(_part(index, _media_title(media), mapping, episodes))
	return parts, loose


def _matching_entries(meta, tmdb_id):
	"""Ani.zip entries for this TMDb show, earliest cour first.

	Search hits cover a sequel that shares the id but has no AniList relation
	(Cyberpunk: Edgerunners 2). Relations cover a cour the title search missed.
	"""
	found, loose, known = {}, [], set()

	def add(media):
		if not media or not media.get('id') or media.get('id') in known:
			return ''
		if media.get('format') and media.get('format') not in _TV_FORMATS:
			return ''
		mal_id = media.get('idMal')
		if not mal_id:
			media = _anilist_media(media.get('id'))
			if not media:
				return ''
			mal_id = media.get('idMal')
		known.add(media.get('id'))
		mapping = _anizip(mal_id) if mal_id else None
		if not mapping or not _raw_episodes(mapping):
			return ''
		linked = str((mapping.get('mappings') or {}).get('themoviedb_id') or '')
		if linked and linked != str(tmdb_id):
			return ''
		if not linked:
			# Same franchise, ani.zip has not filled themoviedb_id yet (Last Boss season 1).
			loose.append((media, mapping))
			return 'loose'
		found[media.get('id')] = (media, mapping)
		return 'linked'

	for title in _search_titles(meta):
		for media in _anilist_search(title):
			add(media)
	seen = set()
	queue = list(found) + [item[0].get('id') for item in loose]
	while queue and len(found) < 12:
		current = queue.pop(0)
		if current in seen:
			continue
		seen.add(current)
		media = found.get(current, (None, None))[0]
		if not ((media or {}).get('relations') or {}).get('edges'):
			media = _anilist_media(current) or media
			if current in found and media:
				found[current] = (media, found[current][1])
		for anilist_id in _relation_ids(media, ('PREQUEL', 'SEQUEL')):
			if anilist_id in seen:
				continue
			full = _anilist_media(anilist_id)
			if add(full):
				queue.append(anilist_id)
	items = list(found.values())
	items.sort(key=lambda item: (_first_air(item[1]) or '9999', _min_absolute(item[1]), _int(item[0].get('id'), 0)))
	return items, loose


def _overlay_kitsu(parts, loose, tmdb_eps):
	"""Copy Kitsu ids from an ani.zip entry that has no TMDb id onto rows that share air dates."""
	if not loose or not tmdb_eps:
		return
	index = {}
	for part in parts:
		for ep in part.get('episodes') or []:
			pair = _tmdb_pair(ep)
			if pair and not ep.get('kitsu_id'):
				index[pair] = ep
	if not index:
		return
	for media, mapping in loose:
		rows = _rows_from_mapping(mapping, 1, cour_episode=True)
		if not rows:
			continue
		_bind_tmdb([{'episodes': rows}], tmdb_eps)
		bound = [ep for ep in rows if _tmdb_pair(ep)]
		if len(bound) * 2 < len(rows):
			continue
		for ep in bound:
			dest = index.get(_tmdb_pair(ep))
			if not dest:
				continue
			dest['kitsu_id'] = ep.get('kitsu_id') or ''
			dest['kitsu_episode'] = ep.get('kitsu_episode') or ''


def _parts_from_one(item):
	media, mapping = item
	grouped = {}
	for ep in _raw_episodes(mapping):
		season_number = _int(ep.get('seasonNumber'), 1) or 1
		grouped.setdefault(season_number, []).append(ep)
	kitsu_id = (mapping.get('mappings') or {}).get('kitsu_id')
	parts = []
	for season_number in sorted(grouped):
		episodes = [_row_from_anizip(ep, season_number, kitsu_id, cour_episode=False) for ep in grouped[season_number]]
		episodes = [ep for ep in episodes if ep]
		if not episodes:
			continue
		name = 'Season %s' % season_number if len(grouped) > 1 else _media_title(media)
		parts.append(_part(season_number, name, mapping, episodes))
	return parts


def _part(display_season, name, mapping, episodes):
	episodes.sort(key=lambda ep: ep.get('display_episode') or 0)
	overview = ''
	for ep in episodes:
		if ep.get('plot'):
			overview = ep['plot']
			break
	return {
		'display_season': display_season,
		'name': name or 'Season %s' % display_season,
		'overview': overview,
		'poster': _poster(mapping),
		'episodes': episodes,
	}


def _first_air(mapping):
	days = []
	for ep in _raw_episodes(mapping):
		day = str(ep.get('airDate') or ep.get('airdate') or '')[:10]
		if len(day) == 10:
			days.append(day)
	return min(days) if days else ''


def _min_absolute(mapping):
	values = [_int(ep.get('absoluteEpisodeNumber'), None) for ep in _raw_episodes(mapping)]
	values = [value for value in values if value]
	return min(values) if values else 0


def _group_parts(tmdb_id):
	group = _seasons_group(metadata.episode_groups(tmdb_id))
	if not group:
		return []
	details = metadata.group_details(group.get('id')) or {}
	groups = [item for item in (details.get('groups') or []) if _int(item.get('order'), 0)]
	groups.sort(key=lambda item: _int(item.get('order'), 0))
	parts = []
	absolute = 0
	for group_item in groups:
		display_season = _int(group_item.get('order'), 0)
		episodes = []
		ordered = sorted(group_item.get('episodes') or [], key=lambda ep: _int(ep.get('order'), 0))
		for ep in ordered:
			absolute += 1
			row = _row_from_group(ep, display_season, absolute)
			if row:
				episodes.append(row)
		if not episodes:
			continue
		parts.append({
			'display_season': display_season,
			'name': group_item.get('name') or 'Season %s' % display_season,
			'overview': '',
			'poster': '',
			'episodes': episodes,
		})
	return parts


def _seasons_group(groups):
	if not groups:
		return None
	exact = [group for group in groups if (group.get('name') or '').strip().lower() == 'seasons']
	if exact:
		return exact[0]
	prefix = [group for group in groups if (group.get('name') or '').strip().lower().startswith('seasons')]
	return prefix[0] if prefix else None


def _bind_tmdb(parts, tmdb_eps):
	pending = [ep for part in parts for ep in (part.get('episodes') or []) if not ep.get('tmdb_season')]
	if not pending or not tmdb_eps:
		return
	pool = []
	for ep in tmdb_eps:
		if _int(ep.get('season'), 0) <= 0 or not _int(ep.get('episode'), 0):
			continue
		pool.append(ep)
	by_date = {}
	for ep in pool:
		day = str(ep.get('premiered') or '')[:10]
		if day:
			by_date.setdefault(day, []).append(ep)
	for day in by_date:
		by_date[day].sort(key=lambda ep: (_int(ep.get('season'), 0), _int(ep.get('episode'), 0)))
	used = set()
	for part in parts:
		for ep in part.get('episodes') or []:
			pair = _tmdb_pair(ep)
			if pair:
				used.add(pair)

	def take(ep, chosen):
		pair = (_int(chosen.get('season'), 0), _int(chosen.get('episode'), 0))
		if not pair[0] or not pair[1] or pair in used:
			return False
		used.add(pair)
		ep['tmdb_season'] = pair[0]
		ep['tmdb_episode'] = pair[1]
		ep['tmdb_episode_id'] = chosen.get('episode_id')
		if not ep.get('plot'):
			ep['plot'] = chosen.get('plot') or ''
		if not ep.get('thumb'):
			ep['thumb'] = chosen.get('thumb')
		if not ep.get('title'):
			ep['title'] = chosen.get('title') or ''
		return True

	still = []
	for ep in pending:
		day = str(ep.get('premiered') or '')[:10]
		chosen = None
		for candidate in by_date.get(day, []):
			pair = (_int(candidate.get('season'), 0), _int(candidate.get('episode'), 0))
			if pair in used or not pair[0] or not pair[1]:
				continue
			chosen = candidate
			break
		if not chosen or not take(ep, chosen):
			still.append(ep)
	# A Japan/US air date is often one day apart. Exact days were claimed above.
	ranked = []
	for ep in still:
		src = _ordinal(ep.get('premiered'))
		if src is None:
			continue
		for candidate in pool:
			pair = (_int(candidate.get('season'), 0), _int(candidate.get('episode'), 0))
			if pair in used or not pair[0] or not pair[1]:
				continue
			dst = _ordinal(candidate.get('premiered'))
			if dst is None or abs(src - dst) != 1:
				continue
			ranked.append((pair, ep, candidate))
	ranked.sort(key=lambda item: item[0])
	claimed = set()
	for pair, ep, candidate in ranked:
		if id(ep) in claimed or pair in used:
			continue
		if take(ep, candidate):
			claimed.add(id(ep))


def _dedupe_bound(parts):
	seen = set()
	kept = []
	for part in parts:
		rows = []
		for ep in part.get('episodes') or []:
			pair = _tmdb_pair(ep)
			if pair and pair in seen:
				continue
			if pair:
				seen.add(pair)
			rows.append(ep)
		if rows:
			part['episodes'] = rows
			kept.append(part)
	return kept


def _merge_uncovered(parts, incoming):
	"""Add episode-group rows whose TMDb pair is not already on the map."""
	covered = _pair_set(parts)
	displays = {_int(part.get('display_season'), 0) for part in parts}
	for part in incoming or []:
		fresh = []
		for ep in part.get('episodes') or []:
			pair = _tmdb_pair(ep)
			if not pair or pair in covered:
				continue
			fresh.append(dict(ep))
			covered.add(pair)
		if not fresh:
			continue
		display = _int(part.get('display_season'), 0)
		if len(fresh) == len(part.get('episodes') or []) and display and display not in displays:
			parts.append({
				'display_season': display,
				'name': part.get('name') or 'Season %s' % display,
				'overview': part.get('overview') or '',
				'poster': part.get('poster') or '',
				'episodes': fresh,
			})
			displays.add(display)
			continue
		_place_rows(parts, fresh, part.get('name') or '', display)


def _fill_tmdb_gaps(parts, tmdb_eps, meta):
	"""Add aired and upcoming TMDb episodes the anime sources do not list yet."""
	covered = _pair_set(parts)
	missing = []
	for ep in tmdb_eps or []:
		season, episode = _int(ep.get('season'), 0), _int(ep.get('episode'), 0)
		if season <= 0 or not episode or (season, episode) in covered:
			continue
		missing.append(ep)
	if not missing:
		return
	missing.sort(key=lambda ep: (_int(ep.get('season'), 0), _int(ep.get('episode'), 0)))
	run = []

	def flush():
		if not run:
			return
		season = _int(run[0].get('season'), 0)
		rows = [_row_from_meta(ep, _absolute_index(tmdb_eps, season, _int(ep.get('episode'), 0))) for ep in run]
		_place_rows(parts, rows, _season_label(meta, season), season)
		run[:] = []

	prev = None
	for ep in missing:
		pair = (_int(ep.get('season'), 0), _int(ep.get('episode'), 0))
		if prev and (pair[0] != prev[0] or pair[1] != prev[1] + 1):
			flush()
		run.append(ep)
		prev = pair
	flush()


def _place_rows(parts, rows, name, preferred_display):
	if not rows:
		return
	pair = _episode_pair(rows[0])
	season = pair[0] if pair else 0
	host = _continuation_part(parts, season, rows)
	if host is None:
		display = _free_display(parts, _display_before(parts, season, rows) or preferred_display or season)
		host = {
			'display_season': display,
			'name': name or 'Season %s' % display,
			'overview': '',
			'poster': '',
			'episodes': [],
		}
		parts.append(host)
	for ep in rows:
		chosen = _episode_pair(ep)
		number = _take_display(host, chosen[1] if chosen else None)
		ep['display_season'] = host['display_season']
		ep['display_episode'] = number
		host['episodes'].append(ep)
	host['episodes'].sort(key=lambda ep: _int(ep.get('display_episode'), 0))


def _continuation_part(parts, season, rows):
	"""Part this run should extend. A run that sits before that part is a new cour."""
	if not season:
		return None
	gap_nums = [pair[1] for pair in (_episode_pair(ep) for ep in rows) if pair]
	if not gap_nums:
		return None
	gap_min = min(gap_nums)
	best, best_max = None, -1
	for part in parts:
		nums = [pair[1] for pair in (_episode_pair(ep) for ep in part.get('episodes') or []) if pair and pair[0] == season]
		if not nums:
			continue
		top = max(nums)
		if top < gap_min and top >= best_max:
			best, best_max = part, top
	return best


def _display_before(parts, season, rows):
	pairs = [pair for pair in (_episode_pair(ep) for ep in rows) if pair]
	if not pairs:
		return None
	gap_max = max(pair[1] for pair in pairs)
	for part in parts:
		nums = [pair[1] for pair in (_episode_pair(ep) for ep in part.get('episodes') or []) if pair and pair[0] == season]
		if nums and min(nums) > gap_max:
			return _int(part.get('display_season'), 0) - 1
	return None


def _free_display(parts, preferred):
	used = {_int(part.get('display_season'), 0) for part in parts}
	preferred = _int(preferred, 0)
	if preferred and preferred not in used:
		return preferred
	return max(used or [0]) + 1


def _take_display(host, preferred):
	used = {_int(ep.get('display_episode'), 0) for ep in host.get('episodes') or []}
	nxt = max(used or [0]) + 1
	preferred = _int(preferred, 0)
	if not host.get('episodes') and preferred and preferred not in used:
		return preferred
	if preferred and preferred == nxt:
		return preferred
	return nxt


def _season_label(meta, tmdb_season):
	for item in (meta or {}).get('season_data') or []:
		if _int(item.get('season_number'), None) == tmdb_season and item.get('name'):
			return item['name']
	return 'Season %s' % tmdb_season


def _row_from_meta(ep, absolute):
	duration = _int(ep.get('duration'), 0) or 0
	runtime = duration // 60 if duration >= 60 else 24
	return {
		'display_season': None,
		'display_episode': None,
		'absolute': absolute,
		'kitsu_id': '',
		'kitsu_episode': '',
		'title': ep.get('title') or '',
		'plot': ep.get('plot') or '',
		'premiered': str(ep.get('premiered') or '')[:10],
		'thumb': ep.get('thumb') or '',
		'runtime': runtime or 24,
		'tmdb_season': _int(ep.get('season'), None),
		'tmdb_episode': _int(ep.get('episode'), None),
		'tmdb_episode_id': ep.get('episode_id'),
	}


def _absolute_index(tmdb_eps, season, episode):
	ordered = [ep for ep in tmdb_eps or [] if _int(ep.get('season'), 0) > 0 and _int(ep.get('episode'), 0)]
	ordered.sort(key=lambda ep: (_int(ep.get('season'), 0), _int(ep.get('episode'), 0)))
	for index, ep in enumerate(ordered, 1):
		if _int(ep.get('season'), 0) == season and _int(ep.get('episode'), 0) == episode:
			return index
	return episode


def _pair_set(parts):
	found = set()
	for part in parts:
		for ep in part.get('episodes') or []:
			pair = _episode_pair(ep)
			if pair:
				found.add(pair)
	return found


def _episode_pair(ep):
	pair = _tmdb_pair(ep)
	if pair:
		return pair
	season, episode = _int(ep.get('season'), 0), _int(ep.get('episode'), 0)
	if season > 0 and episode:
		return season, episode
	return None


def _ordinal(day):
	try:
		return date.fromisoformat(str(day)[:10]).toordinal()
	except Exception:
		return None


def _stamp(parts):
	for part in parts:
		part['episodes'] = sorted(part.get('episodes') or [], key=lambda ep: _int(ep.get('display_episode'), 0))
		count = len(part['episodes'])
		for ep in part['episodes']:
			ep['season_count'] = count
			ep['anime_episode'] = True


def _rows_from_mapping(mapping, display_season, cour_episode=False):
	kitsu_id = (mapping.get('mappings') or {}).get('kitsu_id')
	rows = []
	for ep in _raw_episodes(mapping):
		row = _row_from_anizip(ep, display_season, kitsu_id, cour_episode=cour_episode)
		if row:
			rows.append(row)
	return rows


def _raw_episodes(mapping):
	episodes = (mapping or {}).get('episodes') or {}
	rows = []
	for key, ep in episodes.items():
		if not str(key).isdigit() or not isinstance(ep, dict):
			continue
		rows.append(ep)
	rows.sort(key=lambda ep: _int(ep.get('absoluteEpisodeNumber'), _int(ep.get('episode'), 0)))
	return rows


def _air_dates(ep):
	"""(tmdb date, broadcast date). ani.zip often lists the broadcast a week earlier than TMDb."""
	days = []
	for key in ('airDate', 'airdate'):
		day = str((ep or {}).get(key) or '')[:10]
		if len(day) == 10 and day not in days:
			days.append(day)
	if not days:
		return '', ''
	days.sort()
	later, earlier = days[-1], days[0]
	if later != earlier:
		start, end = _ordinal(earlier), _ordinal(later)
		if start is None or end is None or end - start > 14:
			earlier = later
	return later, earlier


def _row_from_anizip(ep, display_season, kitsu_id, cour_episode=False):
	# Split cours: `episode` is 1..n inside that part. One entry with real seasons:
	# episodeNumber is the number inside seasonNumber (Naruto S02E01, not episode 36).
	if cour_episode:
		display_episode = _int(ep.get('episode'), None)
	else:
		display_episode = _int(ep.get('episodeNumber'), None) or _int(ep.get('episode'), None)
	if not display_episode:
		return None
	absolute = _int(ep.get('absoluteEpisodeNumber'), _int(ep.get('episode'), display_episode))
	title = _episode_title(ep.get('title'))
	plot = ep.get('overview') or ep.get('summary') or ''
	premiered, broadcast = _air_dates(ep)
	runtime = _int(ep.get('runtime'), None) or _int(ep.get('length'), None) or 24
	return {
		'display_season': display_season,
		'display_episode': display_episode,
		'absolute': absolute,
		'kitsu_id': kitsu_id or '',
		'kitsu_episode': _int(ep.get('episode'), display_episode),
		'title': title,
		'plot': plot,
		'premiered': premiered,
		'broadcast': broadcast,
		'thumb': ep.get('image') or '',
		'runtime': runtime,
		'tmdb_season': None,
		'tmdb_episode': None,
		'tmdb_episode_id': None,
	}


def _row_from_group(ep, display_season, absolute):
	tmdb_season = _int(ep.get('season_number'), None)
	tmdb_episode = _int(ep.get('episode_number'), None)
	display_episode = _int(ep.get('order'), None)
	if display_episode is None:
		return None
	display_episode += 1
	if not display_episode:
		return None
	still = ep.get('still_path')
	thumb = 'https://image.tmdb.org/t/p/w1280%s' % still if still else ''
	runtime = _int(ep.get('runtime'), None) or 24
	return {
		'display_season': display_season,
		'display_episode': display_episode,
		'absolute': absolute,
		'kitsu_id': '',
		'kitsu_episode': '',
		'title': ep.get('name') or '',
		'plot': ep.get('overview') or '',
		'premiered': str(ep.get('air_date') or '')[:10],
		'thumb': thumb,
		'runtime': runtime,
		'tmdb_season': tmdb_season,
		'tmdb_episode': tmdb_episode,
		'tmdb_episode_id': ep.get('id'),
	}


def _list_episode(ep):
	runtime = _int(ep.get('runtime'), 24) or 24
	return {
		'season': ep.get('display_season'),
		'episode': ep.get('display_episode'),
		'title': ep.get('title') or 'Episode %s' % ep.get('display_episode'),
		'plot': ep.get('plot') or '',
		'premiered': ep.get('broadcast') or ep.get('premiered') or '',
		'thumb': ep.get('thumb') or None,
		'duration': runtime * 60,
		'episode_id': ep.get('tmdb_episode_id'),
		'episode_type': '',
		'rating': 0,
		'votes': 0,
		'director': [],
		'writer': [],
		'guest_stars': [],
		'tmdb_season': ep.get('tmdb_season'),
		'tmdb_episode': ep.get('tmdb_episode'),
		'absolute': ep.get('absolute'),
		'kitsu_id': ep.get('kitsu_id') or '',
		'kitsu_episode': ep.get('kitsu_episode') or '',
		'season_count': ep.get('season_count') or 0,
		'anime_episode': True,
	}


def _flat(show):
	rows = []
	for part in show.get('parts') or []:
		rows.extend(part.get('episodes') or [])
	rows.sort(key=lambda ep: (_int(ep.get('display_season'), 0), _int(ep.get('display_episode'), 0)))
	return rows


def _tmdb_index(flat, season, episode):
	try:
		season, episode = int(season), int(episode)
	except (TypeError, ValueError):
		return None
	for index, row in enumerate(flat):
		pair = _tmdb_pair(row)
		if pair == (season, episode):
			return index
	return None


def _row_by_tmdb(show, season, episode):
	flat = _flat(show)
	index = _tmdb_index(flat, season, episode)
	if index is None:
		return None
	return flat[index]


def _tmdb_pair(ep):
	season, episode = _int(ep.get('tmdb_season'), None), _int(ep.get('tmdb_episode'), None)
	if season and episode:
		return season, episode
	return None


def _search_titles(meta):
	titles = []
	for key in ('title', 'english_title', 'original_title'):
		value = (meta.get(key) or '').strip()
		if value and value not in titles:
			titles.append(value)
	return titles


def _media_title(media):
	title = (media or {}).get('title') or {}
	if isinstance(title, dict):
		return title.get('romaji') or title.get('english') or ''
	return str(title or '')


def _episode_title(title):
	if isinstance(title, dict):
		for key in ('en', 'x-jat', 'ja'):
			if title.get(key):
				return title[key]
		for value in title.values():
			if value:
				return value
		return ''
	return title or ''


def _poster(mapping):
	for image in (mapping or {}).get('images') or []:
		if not isinstance(image, dict):
			continue
		if str(image.get('coverType') or '').lower() == 'poster' and image.get('url'):
			return image['url']
	return ''


def _relation_ids(media, kinds):
	ids = []
	for edge in ((media or {}).get('relations') or {}).get('edges') or []:
		if edge.get('relationType') not in kinds:
			continue
		node = edge.get('node') or {}
		if node.get('format') not in _TV_FORMATS:
			continue
		anilist_id = node.get('id')
		if anilist_id and anilist_id not in ids:
			ids.append(anilist_id)
	return ids


def _anilist_search(title):
	data = _anilist(_SEARCH, {'search': title})
	return ((data.get('Page') or {}).get('media') or []) if data else []


def _anilist_media(anilist_id):
	data = _anilist(_MEDIA, {'id': int(anilist_id)})
	return (data or {}).get('Media')


def _anilist(query, variables):
	response = requests.post(_ANILIST, json={'query': query, 'variables': variables}, headers=dict(_HEADERS, **{'Content-Type': 'application/json'}), timeout=15)
	response.raise_for_status()
	payload = response.json() or {}
	if payload.get('errors'):
		raise RuntimeError(payload['errors'][0].get('message') or 'AniList error')
	return payload.get('data') or {}


def _anizip(mal_id):
	response = requests.get(_ANIZIP, params={'mal_id': int(mal_id)}, headers=_HEADERS, timeout=15)
	if response.status_code == 404:
		return None
	response.raise_for_status()
	return response.json()


def _int(value, default=None):
	try:
		return int(value)
	except (TypeError, ValueError):
		return default
