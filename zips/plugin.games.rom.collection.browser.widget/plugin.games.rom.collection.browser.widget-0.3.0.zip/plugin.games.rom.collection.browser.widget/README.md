# rcb-widget
Provides widget data for Rom Collection Browser
