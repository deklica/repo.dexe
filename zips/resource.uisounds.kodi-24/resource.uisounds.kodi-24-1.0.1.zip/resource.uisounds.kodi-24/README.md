# resource.uisounds.kodi-24
 Kodi UI sounds reduced by 24 dB
