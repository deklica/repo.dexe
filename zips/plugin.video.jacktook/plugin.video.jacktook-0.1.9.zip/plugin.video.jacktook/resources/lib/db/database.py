#!/usr/bin/env python3
import os
import pickle
from resources.lib.utils.kodi import ADDON_ID
import xbmcvfs


# Source with some modifications
# https://github.com/pikdum/plugin.video.haru/blob/master/resources/lib/database.py
class Database:
    def __init__(self):
        BASE_DATABASE = {
            "jt:watch": {},
            "jt:fanarttv": {},
            "jt:tmdb": {},
            "jt:lth":{},
            "jt:lfh": {}
        }

        data_dir = xbmcvfs.translatePath(
            os.path.join("special://profile/addon_data/", ADDON_ID)
        )
        database_path = os.path.join(data_dir, "database.pickle")
        xbmcvfs.mkdirs(data_dir)

        if os.path.exists(database_path):
            with open(database_path, "rb") as f:
                database = pickle.load(f)
        else:
            database = {}

        database = {**BASE_DATABASE, **database}

        self.database = database
        self.database_path = database_path
        self.addon_xml_path = xbmcvfs.translatePath(
            os.path.join("special://home/addons/", ADDON_ID, "addon.xml")
        )

    def get_fanarttv(self, key, id):
        if id in self.database[key]:
            return self.database[key][id]
        return None

    def set_fanarttv(self, key, id, poster, fanart, clear):
        self.database[key][id] = {
            "poster2": poster,
            "fanart2": fanart,
            "clearlogo2": clear,
        }
        self.commit()
    
    def get_tmdb(self, key, identifier):
        if identifier in self.database[key]:
            return self.database[key][identifier]
        return None

    def set_tmdb(self, key, identifier, tmdb_data):
        self.database[key][identifier] = tmdb_data
        self.commit()

    def commit(self):
        with open(self.database_path, "wb") as f:
            pickle.dump(self.database, f)

db_instance = Database()

def get_db():
    return db_instance