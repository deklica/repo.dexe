#!/usr/bin/env python3

from resources.lib.navigation import run

run()
