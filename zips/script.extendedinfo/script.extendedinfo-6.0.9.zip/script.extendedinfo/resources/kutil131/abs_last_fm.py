"""
Created on 8/24/21

@author: Frank Feuerbacher
"""


class AbstractLastFM:

    @classmethod
    def get_similar_artists(cls, artist_mbid):
        pass