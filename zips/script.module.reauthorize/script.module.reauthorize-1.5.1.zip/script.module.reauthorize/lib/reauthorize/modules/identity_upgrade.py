# -*- coding: utf-8 -*-
"""
    ReAuthorize - a device id that is leftover memory gets a fresh one, once (1.5.0)

    Part 2 of the Microsoft Store fix (part 1 is entropy.py: new ids are made properly). Boxes that made their id
    before 1.5.0 on Kodi from the Store app hold ids such as e400000000000000..., which are guessable (the id is
    also the key that encrypts the backup) and can be the same on two boxes. 431 cloud backups sat on such ids
    when this was found (2026-11-10). An id that is NOT plainly leftover memory is never touched: a real id is
    what keeps a backup readable, so the test (entropy.id_looks_weak) is strict.

    What moves, in this order, and why:
      1. read what the old id holds: the local store (vault.json) and the server copy, both under the old id.
         A server that cannot be reached right now means wait for the next start: moving the id without the
         server copy would orphan it.
      2. put the merged set on the server under the NEW id and key. A failure stops everything here, nothing has
         changed yet.
      3. write the new id and key beside the vault, and the store re-encrypted under the new id.
      4. only then clear the old server row (and its uptake row), speaking as the old id.
    A crash between 2 and 3 leaves an unused row under a new id and the old id still in use: the next start does
    it again. A crash after 3 leaves the old server row, harmless: nothing uses that id any more.

    The reset number (reset_epoch), the stamp on the sign-ins and the settings are not tied to the id's value,
    apart from the stamp, which is made again (owner.claim).
"""

import xbmc
from reauthorize.modules import device, entropy, own_settings, server, storage, vault

LOG_TAG = '[ReAuthorize Identity]'


def _fresh_pair():
    """A new id and key, each checked against the same test (a made-up value never fails it in practice)."""
    for _ in range(5):
        new_id, new_key = device._new_value(), device._new_value()
        if not entropy.id_looks_weak(new_id):
            return new_id, new_key
    return None, None


def upgrade_weak_identity():
    """
    Returns True when this call moved the device to a new id. False: nothing to do, or it could not be done
    now (the reason is logged) and the next start tries again.
    """
    try:
        return _upgrade()
    except Exception as e:
        xbmc.log('%s check failed: %s' % (LOG_TAG, e), xbmc.LOGWARNING)
        return False


def _upgrade():
    with device._lock:
        id_path = storage.device_id_path()
        old_id = device._read_file_id(id_path)      # only an id kept beside the vault; never one found in settings
        if not old_id or not entropy.id_looks_weak(old_id):
            return False
        key_path = storage.device_key_path()
        old_key = device._read_file_id(key_path)

        # 1. what the old id holds
        try:
            store, meta = vault.read_store()
        except Exception as e:
            xbmc.log('%s could not read the local backup (%s) - leaving the device ID alone.' % (LOG_TAG, e),
                     xbmc.LOGWARNING)
            return False
        online = server._server_enabled()
        server_copy, row_readable = {}, True
        if online:
            result = server._post('fetch')
            if device.get_device_id() != old_id:
                return False                        # the server called the id shared; it already has a new one
            if result is None and server.last_error() != 'no_backup':
                xbmc.log('%s the server could not be asked - will move the device ID at a later start.' % LOG_TAG,
                         xbmc.LOGINFO)
                return False
            if result and result.get('vault_data') and not result.get('builder_mode'):
                try:
                    server_copy = server._decode(result['vault_data'], old_id)
                except Exception as e:
                    row_readable = False            # not ours to delete if we cannot read it
                    xbmc.log('%s the server copy could not be read (%s).' % (LOG_TAG, e), xbmc.LOGWARNING)
        carried = vault._merge(store, server_copy if isinstance(server_copy, dict) else {}, meta)[0]

        new_id, new_key = _fresh_pair()
        if not new_id:
            return False

        # 2. the server first: nothing local has changed if this fails
        if online and vault.count_credentials(carried):
            sent = server._post('store', {'vault_data': server._encode(carried, new_id)},
                                identity=(new_id, new_key))
            if not (sent and sent.get('status') == 200):
                xbmc.log('%s could not store the backup under the new ID (%s) - leaving the device ID alone.'
                         % (LOG_TAG, server.last_error()), xbmc.LOGWARNING)
                return False

        # 3. the new id and key beside the vault, then the store under the new id
        if not device._write_file_id(key_path, new_key):
            return False
        if not device._write_file_id(id_path, new_id):
            if old_key:
                device._write_file_id(key_path, old_key)
            return False
        device._session_id = new_id
        vault_file = storage.vault_path()
        for path in (vault_file, (vault_file + '.bak') if vault_file else None, storage.keep_path()):
            device._remove(path)                    # encrypted under the old id; carried is re-written below
        if vault.count_credentials(carried):
            try:
                vault._write_store(carried, meta)
            except Exception as e:
                xbmc.log('%s could not write the local backup under the new ID: %s' % (LOG_TAG, e), xbmc.LOGWARNING)
        addon = own_settings.addon()
        addon.setSetting(device.SETTING, '')
        addon.setSetting('vault.last_backup', '')
        xbmc.log('%s Device ID %s... was not random (a Store-app Kodi gave leftover memory). This device now has '
                 'a new one: %s... Its backup moved with it.' % (LOG_TAG, old_id[:8], new_id[:8]), xbmc.LOGWARNING)
        from reauthorize.modules import owner
        owner.claim(force=True)                     # the stamp was made from the old id

        # 4. the old rows, speaking as the old id
        if online and row_readable:
            identity = (old_id, old_key)
            server._post('clear', identity=identity)
            server._post('reset_done', timeout=5, identity=identity)    # its uptake row: counted once
        return True
