# -*- coding: utf-8 -*-
"""
    ReAuthorize - random bytes that a broken system random source cannot weaken (1.5.0)

    Kodi from the Microsoft Store (the Xbox app, and the same app on Windows PCs) returns leftover memory from
    os.urandom, not random bytes. Found 2026-11-10 in auth_seen / auth_vault: device ids such as e400000000000000...,
    e47365722d416765 ('ser-Age', from 'User-Agent'), e4726d6174732066 ('rmats f'), ...7f0000 (memory addresses);
    431 backups on such ids, 62 of them retired because two boxes held the same id; Send My Log 1006 (fingerprint
    e4010000) reports 'WINDOWS 10.0.26100' with its store in addon data. The device id is also the key that encrypts
    the backup, so it must be both unique and hard to guess.

    random_bytes() hashes os.urandom TOGETHER with sources that do not depend on it (the clocks to the nanosecond,
    timing jitter, the process and thread, Kodi's MAC address and up-time, a counter) through SHA-256. Where
    os.urandom works the result is as good as it; where it does not, the rest still makes every value different
    and hard to predict. No xbmc import at the top: crypto.py uses this outside Kodi too.
"""

import hashlib
import os
import threading
import time

_lock = threading.Lock()
_counter = [0]


def _jitter(rounds=96):
    """How long tiny pieces of work take, to the nanosecond: different on every call and every box."""
    samples = []
    for _ in range(rounds):
        start = time.perf_counter_ns()
        x = start
        for i in range(40):
            x = (x * 6364136223846793005 + i) & 0xFFFFFFFFFFFFFFFF
        samples.append(time.perf_counter_ns() - start)
    return samples


def _kodi_parts():
    try:
        import xbmc
        return '|'.join(xbmc.getInfoLabel(label) for label in
                        ('Network.MacAddress', 'System.FriendlyName', 'System.Uptime', 'System.Time(hh:mm:ss)'))
    except Exception:
        return ''


def _system():
    try:
        return os.urandom(64)
    except Exception:
        return b''


def random_bytes(n):
    """n bytes for an id, a key or a nonce."""
    with _lock:
        _counter[0] += 1
        count = _counter[0]
    seed = b''.join((
        _system(),
        repr((time.time_ns(), time.perf_counter_ns(), time.monotonic_ns(), os.getpid(), threading.get_ident(),
              id(object()), count, _jitter(), _kodi_parts())).encode('utf-8', 'replace'),
        _system(),
    ))
    out, block = b'', 0
    while len(out) < n:
        out += hashlib.sha256(seed + block.to_bytes(4, 'big')).digest()
        block += 1
    return out[:n]


def _printable_run(data):
    best = run = 0
    for b in data:
        run = run + 1 if 32 <= b < 127 else 0
        best = max(best, run)
    return best


def looks_broken(sample=None, second=None):
    """
    True when the system source plainly is not random: two draws alike, eight or more zero bytes in 32, or sixteen
    readable characters in a row (leftover text). Each happens to real random bytes far less than once in a million
    draws. For a log line only; random_bytes() never depends on it.
    """
    if sample is None:
        sample, second = _system()[:32], _system()[:32]
    if not sample or (second is not None and sample == second):
        return True
    return sample.count(0) >= 8 or _printable_run(sample) >= 16


_TEXT = frozenset(b'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 -_.')


def _text_run(data):
    best = run = 0
    for b in data:
        run = run + 1 if b in _TEXT else 0
        best = max(best, run)
    return best


def id_looks_weak(device_id):
    """
    True for a device id that is plainly leftover memory, not random (1.5.0, part 2 of the Store-app fix).
    Seen in auth_vault: e400000000000000..., e47365722d416765 ('ser-Age'), ...7f0000 (a pointer). Each test is
    one a random 32-byte value meets about once in 5 million (a few in 200,000 boxes, who then only get a new id
    with their backup carried over, so a false hit costs nothing):
      - five or more zero bytes, or four zero bytes in a row
      - '7f0000' at a byte boundary (the top of a 64-bit pointer)
      - twelve readable characters in a row (letters, digits, space, - _ .)
      - a leading e4 byte followed by six readable characters (e47365722d416765, 'ser-Age')
    A value that is not 64 hex characters is not judged here.
    """
    try:
        data = bytes.fromhex(device_id)
    except (TypeError, ValueError):
        return False
    if len(data) != 32:
        return False
    return (data.count(0) >= 5 or b'\x00\x00\x00\x00' in data or b'\x7f\x00\x00' in data
            or _text_run(data) >= 12 or (data[0] == 0xe4 and _text_run(data[1:7]) >= 6))
