# -*- coding: utf-8 -*-
"""
    ReAuthorize - back up by itself when a sign-in changes (1.3.9)

    Until 1.3.9 only Trakt, the MDBList account, YouTube and the importer backed up after a
    sign-in. Authorizing Real-Debrid, Premiumize, AllDebrid, TorBox, OffCloud, EasyDebrid,
    Simkl, Last.fm or entering a metadata key wrote NO backup: the sign-in worked on that box
    and was gone at the next build install unless the user pressed "Save & Backup Now". The
    only guard was a reminder shown after nearly every action, which people stopped reading
    (a user asked why it keeps saying it; "can't closing just do that?" - it could not).

    default.py takes snapshot() when an action starts and calls save_if_changed() when it ends.
    Nothing changed -> nothing happens and nothing is said.
"""

import xbmc

from reauthorize.modules import control

LOG_TAG = '[ReAuthorize Autosave]'
SAVED = 'Saved and backed up.'


def snapshot():
    """Every setting that goes into a backup, as it is now."""
    from reauthorize.modules import vault
    return {key: control.setting(key) or '' for key in vault.CREDENTIAL_KEYS}


def is_revoke(action):
    """A Revoke / sign-out button: what it removes leaves the shared backup and every Kodi (1.4.6)."""
    return bool(action) and 'Revoke' in action


def record_signout(before, after=None, push=True):
    """
    Mark what a sign-out removed (`before` -> `after`, default: the settings now) as revoked in the shared
    backup (vault.note_signed_out), so it leaves the backup and every Kodi on the device signs out too. With
    `push`, the server copy follows; when nothing is left there it is cleared instead, since a backup with
    no sign-in is never sent and would leave the revoked one on the server. Returns the services marked.
    """
    from reauthorize.modules import vault, server
    names = []
    try:
        names = vault.note_signed_out(before, after)
        if names and not vault.count_credentials(vault.stored()):
            server.clear()
        elif names and push:
            server.backup()
    except Exception as e:
        xbmc.log('%s recording the sign-out failed: %s' % (LOG_TAG, e), xbmc.LOGINFO)
    return names


def save_if_changed(before, action=None):
    """
    Back up to the vault and the server if anything in the backup set changed since 'before'.
    After a Revoke (`action`), the services it removed are first marked revoked in the shared backup
    (vault.note_signed_out); a backup no longer drops a service just because this Kodi lacks it.
    Returns the line to show the user, or None when there is nothing to say:
      - nothing changed, or a sign-in was only removed and there was nothing new to save
      - the backup was written                      -> 'Saved and backed up.'
      - a sign-in was ADDED and no backup was made  -> why not (vault.failure_message())
    """
    if before is None:
        return None
    from reauthorize.modules import vault, server
    now = snapshot()
    if now == before:
        return None
    vault_ok = server_ok = False
    if is_revoke(action):
        record_signout(before, now, push=False)        # the backups below carry it
    else:
        try:                                           # a value signed in again is no longer 'revoked' (1.4.9)
            vault.note_signed_in(before, now)
        except Exception as e:
            xbmc.log('%s recording the sign-in failed: %s' % (LOG_TAG, e), xbmc.LOGINFO)
    try:
        vault_ok = bool(vault.backup())
    except Exception as e:
        xbmc.log('%s vault backup failed: %s' % (LOG_TAG, e), xbmc.LOGINFO)
    try:
        server_ok = bool(server.backup())
    except Exception as e:
        xbmc.log('%s server backup failed: %s' % (LOG_TAG, e), xbmc.LOGINFO)
    xbmc.log('%s a sign-in changed: vault %s, server %s' % (LOG_TAG, 'saved' if vault_ok else 'not saved',
                                                          'saved' if server_ok else 'not saved'), xbmc.LOGINFO)
    if vault_ok or server_ok:
        return SAVED
    added = vault.count_credentials(now) > vault.count_credentials(before)
    if added:
        try:
            return 'Not backed up: %s' % vault.failure_message()
        except Exception:
            return 'Not backed up. Open Backup & Device and press "Save & Backup Now".'
    return None
