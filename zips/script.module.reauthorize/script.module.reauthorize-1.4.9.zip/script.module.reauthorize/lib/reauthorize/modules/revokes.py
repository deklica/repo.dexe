# -*- coding: utf-8 -*-
"""
    ReAuthorize - a Revoke reaches every Kodi on the device (1.4.6)

    Every Kodi on a device shares one store (vault.py). Until 1.4.6 a Revoke reached only the Kodi it was made
    in: OffCloud was revoked on the main bench 2026-10-18, and the MQ9 build on the same PC kept it, used it two
    days later and most likely put it back into the shared backup.

    Now a Revoke leaves a marker in the store (vault.note_signed_out). At start and at every five-minute look,
    each Kodi asks vault.revoked_here() whether it holds a sign-in the marker ended, and signs that service out
    of itself and its add-ons: the same helpers a pause uses (pause.py), and the key removal of the metadata
    Revokes (sync/key_removal.py). Nothing is revoked at the service again; the Kodi that revoked did that.
"""

import xbmc

from reauthorize.modules.control import accountmgr

LOG_TAG = '[ReAuthorize Revoke]'

# The vault's metadata tags and the one setting each holds (sync/key_removal.py takes it out of the add-ons)
_KEY_TAGS = {'fanart': 'fanart.tv.api.key', 'omdb': 'omdb.api.key', 'mdbkey': 'mdb.api.key',
             'imdb': 'imdb.user', 'audiodb': 'audiodb.api.key', 'tmdbkey': 'tmdb.api.key',
             'tmdb': 'tmdb.session_id'}
# Kept by the service itself, not the vault: cleared with the sign-in
_ALSO_CLEAR = {'trakt': ('trakt.lifetime', 'sync.tk.service')}


def _log(message):
    xbmc.log('%s %s' % (LOG_TAG, message), xbmc.LOGINFO)


def _take_out(tag, current):
    """Take this service out of every add-on, while ReAuthorize still holds it."""
    from reauthorize.modules import pause
    if tag == 'trakt':
        # Not pause's way: that first checks the pair with Trakt, and a revoked pair only earns a refusal
        from reauthorize.modules.sync import trakt_wipe
        trakt_wipe.wipe_addons()
    elif tag == 'mdbo':
        from reauthorize.modules.sync import mdblist_oauth_sync
        mdblist_oauth_sync.wipe(token=current.get('mdblist.oauth.token'))
    elif tag in _KEY_TAGS:
        from reauthorize.modules.sync import key_removal
        key = _KEY_TAGS[tag]
        key_removal.remove(key, current.get(key))
    elif tag in dict((s[0], s) for s in pause.SERVICES):
        pause._take_out(tag)
    # Debrid-Link and the YouTube keys: no add-on is sent them on their own


def apply():
    """Sign out here what a Revoke on another Kodi of this device ended. Returns the names signed out."""
    from reauthorize.modules import vault, pause
    try:
        current = dict((k, accountmgr.getSetting(k)) for k in vault.CREDENTIAL_KEYS)
        hits = vault.revoked_here(current)
    except Exception as e:
        _log('could not read the shared backup: %s' % e)
        return []
    names = []
    for tag, name, keys in hits:
        try:
            _take_out(tag, current)
        except Exception as e:
            _log('could not take %s out of every add-on: %s' % (name, e))
        for key in tuple(keys) + _ALSO_CLEAR.get(tag, ()):
            accountmgr.setSetting(key, '')
        try:
            if pause.paused(tag):
                pause._store(pause.paused_tags() - {tag})
        except Exception:
            pass
        names.append(name)
        _log('%s was signed out on another Kodi on this device - signed out here too' % name)
    if names:
        try:
            from reauthorize.modules import settings_display
            settings_display.sync_authorized_display_values()
        except Exception as e:
            _log('could not update the status lines: %s' % e)
    return names
