import xbmc
import sqlite3
import xbmcgui
import xbmcvfs
from libs.common import var
from sqlite3 import Error

#Account Manager Trakt
# Shared accessor: a cached Addon handle can revert settings written
# through another instance. See control._Settings.
from reauthorize.modules.control import accountmgr
your_clientid = var.client_am
your_secret = var.secret_am
your_token = accountmgr.getSetting("trakt.token")
your_username = accountmgr.getSetting("trakt.username")
your_expires = accountmgr.getSetting("trakt.expires")

# Gears renews Trakt by itself once under 7 days remain (apis/trakt_api.py), and Trakt's tokens last 7 days, so
# it renewed at its first call after every send, under ReAuthorize's key, and the next send wrote the spent token
# back over its new pair. '0' is Gears' own "no refresh token": it returns without asking Trakt and keeps working.
NO_RENEW = '0'
# Gears reads these from the home window before its database, so a write alone reaches it at its next start
_GEARS_CACHED = ('gears.trakt.client', 'gears.trakt.secret', 'gears.trakt.token', 'gears.trakt.user',
                 'gears.trakt.refresh', 'gears.trakt.expires')

###################### Connect to Database ######################
def create_conn(db_file):
    try:
        conn = None
        try:
            conn = sqlite3.connect(db_file)
        except Error as e:
            xbmc.log(str(e), xbmc.LOGINFO)

        return conn
    except:
        xbmc.log('%s: Trakt_db Connect Failed!' % var.amgr, xbmc.LOGINFO)


######################### Trakt #########################
def connect_trakt(conn, setting):
    try:
        # Update settings database
        trakt_client = ''' UPDATE settings
                  SET setting_value = ?
                  WHERE setting_id = ?'''
        trakt_secret = ''' UPDATE settings
                  SET setting_value = ?
                  WHERE setting_id = ?'''
        trakt_token = ''' UPDATE settings
                  SET setting_value = ?
                  WHERE setting_id = ?'''
        trakt_user = ''' UPDATE settings
                  SET setting_value = ?
                  WHERE setting_id = ?'''
        trakt_refresh = ''' UPDATE settings
                  SET setting_value = ?
                  WHERE setting_id = ?'''
        trakt_expires = ''' UPDATE settings
                  SET setting_value = ?
                  WHERE setting_id = ?'''
        trakt_watched_indicators = ''' UPDATE settings
                  SET setting_value = ?
                  WHERE setting_id = ?'''
        trakt_watched_indicators_name = ''' UPDATE settings
                  SET setting_value = ?
                  WHERE setting_id = ?'''

        cur = conn.cursor()
        cur.execute(trakt_client, setting)
        cur.execute(trakt_secret, setting)
        cur.execute(trakt_token, setting)
        cur.execute(trakt_user, setting)
        cur.execute(trakt_refresh, setting)
        cur.execute(trakt_expires, setting)
        cur.execute(trakt_watched_indicators, setting)
        cur.execute(trakt_watched_indicators_name, setting)
        conn.commit()
        cur.close()
    except:
        xbmc.log('%s: Trakt_db Failed!' % var.amgr, xbmc.LOGINFO)


_GEARS_DB = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.gears/databases/settings.db')

def auth_gears_trakt():
    try:
        conn = create_conn(_GEARS_DB)
        with conn:
            connect_trakt(conn, (your_clientid, 'trakt.client'))
            connect_trakt(conn, (your_secret, 'trakt.secret'))
            connect_trakt(conn, (your_token, 'trakt.token'))
            connect_trakt(conn, (your_username, 'trakt.user'))
            connect_trakt(conn, (NO_RENEW, 'trakt.refresh'))
            connect_trakt(conn, (your_expires, 'trakt.expires'))
            # watched_indicators: sync/pickers.py, only while still on Gears' own tracking (1.4.5)
        forget_gears_cache()
    except:
        xbmc.log('%s: Trakt_db Gears Failed!' % var.amgr, xbmc.LOGINFO)


def forget_gears_cache():
    """A running Gears reads its Trakt rows from the database again at its next call."""
    window = xbmcgui.Window(10000)
    for name in _GEARS_CACHED:
        window.clearProperty(name)


def gears_pair():
    """The pair Gears renewed for itself under ReAuthorize's key, (token, refresh, expires), or None."""
    if not xbmcvfs.exists(var.chkset_gears):
        return None
    conn = create_conn(var.gears_settings_db)
    try:
        rows = dict(conn.execute("SELECT setting_id, setting_value FROM settings WHERE setting_id IN "
                                 "('trakt.client', 'trakt.token', 'trakt.refresh', 'trakt.expires')"))
    finally:
        conn.close()
    refresh = rows.get('trakt.refresh')
    if rows.get('trakt.client') != your_clientid or refresh in (None, '', NO_RENEW, 'empty_setting'):
        return None
    return rows.get('trakt.token'), refresh, rows.get('trakt.expires')
