import xbmc
import xbmcaddon
import xbmcvfs
import os

from libs.common import var

char_remov = ["'", ",", ")","("]

#Account Manager OffCloud
# Shared accessor: a cached Addon handle can revert settings written
# through another instance. See control._Settings.
from reauthorize.modules.control import accountmgr
your_token = accountmgr.getSetting("offcloud.token")

class Auth:
    def offcloud_auth(self):
    #Umbrella
        try:
            if xbmcvfs.exists(var.chk_umb) and xbmcvfs.exists(var.chkset_umb):
                chk_auth_umb = xbmcaddon.Addon('plugin.video.umbrella').getSetting("offcloudtoken")
                if not str(your_token) == str(chk_auth_umb) or str(chk_auth_umb) == '':

                    addon = xbmcaddon.Addon("plugin.video.umbrella")
                    addon.setSetting("offcloudtoken", your_token)
                    addon.setSetting("offcloud.enable", "true")
        except:
            xbmc.log('%s: Umbrella OffCloud Failed!' % var.amgr, xbmc.LOGINFO)

    #POV
        try:
            if xbmcvfs.exists(var.chk_pov) and xbmcvfs.exists(var.chkset_pov):
                chk_auth_pov = xbmcaddon.Addon('plugin.video.pov').getSetting("oc.token")
                if not str(your_token) == str(chk_auth_pov) or str(chk_auth_pov) == '':

                    addon = xbmcaddon.Addon("plugin.video.pov")
                    addon.setSetting("oc.token", your_token)
                    addon.setSetting("oc.enabled", "true")
        except:
            xbmc.log('%s: POV OffCloud Failed!' % var.amgr, xbmc.LOGINFO)

    #Infinity
        try:
            if xbmcvfs.exists(var.chk_infinity) and xbmcvfs.exists(var.chkset_infinity):
                chk_auth_infinity = xbmcaddon.Addon('plugin.video.infinity').getSetting("offcloudtoken")
                if not str(your_token) == str(chk_auth_infinity) or str(chk_auth_infinity) == '':

                    addon = xbmcaddon.Addon("plugin.video.infinity")
                    addon.setSetting("offcloudtoken", your_token)
                    addon.setSetting("offcloud.enable", "true")
        except:
            xbmc.log('%s: Infinity OffCloud Failed!' % var.amgr, xbmc.LOGINFO)

    #Cosmos
        try:
            if xbmcvfs.exists(var.chk_cosmos) and xbmcvfs.exists(var.chkset_cosmos):
                chk_auth_cosmos = xbmcaddon.Addon('plugin.video.cosmos').getSetting("oc_api_key")
                if not str(your_token) == str(chk_auth_cosmos) or str(chk_auth_cosmos) == '':

                    addon = xbmcaddon.Addon("plugin.video.cosmos")
                    addon.setSetting("oc_api_key", your_token)
                    addon.setSetting("oc_enabled", "true")
                    # A sign-out used to blank the key but write "authorized" again, and left the
                    # account e-mail: Cosmos still looked signed in (the user, 2026-10-21).
                    addon.setSetting("oc_auth_done", "true" if your_token else "false")
                    if not your_token:
                        addon.setSetting("oc_account", '')
        except:
            xbmc.log('%s: Cosmos OffCloud Failed!' % var.amgr, xbmc.LOGINFO)

    #ResolveURL
    #ResolveURL's OffCloud plugin is usable when it is enabled and has an apikey;
    #OffCloudResolver_user is only a display label. OffCloud gives one account
    #the same key wherever it signs in, so this is the value Umbrella holds too.
        try:
            if xbmcvfs.exists(var.chk_rurl) and not xbmcvfs.exists(var.rurl_ud):
                os.mkdir(var.rurl_ud)
                xbmcvfs.copy(os.path.join(var.rurl), os.path.join(var.chkset_rurl))

            if xbmcvfs.exists(var.chk_rurl) and not xbmcvfs.exists(var.chkset_rurl):
                xbmcvfs.copy(os.path.join(var.rurl), os.path.join(var.chkset_rurl))

            if xbmcvfs.exists(var.chk_rurl) and xbmcvfs.exists(var.chkset_rurl):
                chk_auth_rurl = xbmcaddon.Addon('script.module.resolveurl').getSetting("OffCloudResolver_apikey")
                if not str(your_token) == str(chk_auth_rurl) or str(chk_auth_rurl) == '':

                    addon = xbmcaddon.Addon("script.module.resolveurl")
                    addon.setSetting("OffCloudResolver_apikey", your_token)
                    if your_token:
                        addon.setSetting("OffCloudResolver_enabled", "true")
        except:
            xbmc.log('%s: ResolveURL OffCloud Failed!' % var.amgr, xbmc.LOGINFO)

    #Red Light
        try:
            from reauthorize.modules.db import redlight_db
            redlight_db.push([('oc.token', your_token),
                              ('oc.enabled', 'true')])
        except:
            xbmc.log('%s: Red Light OffCloud Failed!' % var.amgr, xbmc.LOGINFO)

    #Diamond Media Player OffCloud
        try:
            if xbmcvfs.exists(var.chk_rdtplayer) and xbmcvfs.exists(var.chkset_rdtplayer):
                chk_auth_rdtplayer = xbmcaddon.Addon('plugin.program.rdtplayer').getSetting("offcloud_api_key")
                if not str(your_token) == str(chk_auth_rdtplayer) or str(chk_auth_rdtplayer) == '':
                    addon = xbmcaddon.Addon("plugin.program.rdtplayer")
                    addon.setSetting("offcloud_api_key", your_token)
        except:
            xbmc.log('%s: Diamond Media Player OffCloud Failed!' % var.amgr, xbmc.LOGINFO)

    #Prism OffCloud
    #oc.token isn't in settings.xml either; confirmed from Prism's own
    #resources/lib/debrid/offcloud.py: OC_TOKEN_KEY = "oc.token".
        try:
            if xbmcvfs.exists(var.chk_prism) and xbmcvfs.exists(var.chkset_prism):
                chk_auth_prism = xbmcaddon.Addon('plugin.video.prism').getSetting("oc.token")
                if not str(your_token) == str(chk_auth_prism) or str(chk_auth_prism) == '':
                    addon = xbmcaddon.Addon("plugin.video.prism")
                    addon.setSetting("oc.token", your_token)
                    addon.setSetting("offcloud.enabled", 'true')
        except:
            xbmc.log('%s: Prism OffCloud Failed!' % var.amgr, xbmc.LOGINFO)

    #TMDb Movies OffCloud
        try:
            if xbmcvfs.exists(var.chk_tmdbmovies) and xbmcvfs.exists(var.chkset_tmdbmovies):
                chk_auth_tmdbmovies = xbmcaddon.Addon('plugin.video.tmdbmovies').getSetting("oc_api_key")
                if not str(your_token) == str(chk_auth_tmdbmovies) or str(chk_auth_tmdbmovies) == '':
                    addon = xbmcaddon.Addon("plugin.video.tmdbmovies")
                    addon.setSetting("oc_api_key", your_token)
        except:
            xbmc.log('%s: TMDb Movies OffCloud Failed!' % var.amgr, xbmc.LOGINFO)
