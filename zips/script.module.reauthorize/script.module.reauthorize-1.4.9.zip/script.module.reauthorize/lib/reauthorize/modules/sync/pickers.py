# -*- coding: utf-8 -*-
"""
    ReAuthorize - the add-ons' "where do my watched marks go" choices (1.4.5)

    Several add-ons ask which service keeps your watched marks, resume points and scrobbles, and
    all of them start on their own local tracking. Signed in to Trakt through ReAuthorize, Umbrella
    still marked shows watched only on the box and never told Trakt, which most people take for
    "Trakt is not working". Account Manager used to switch these choices; ReAuthorize switched some,
    the wrong way: the POV, Coalition and Gears blocks wrote "Trakt" at EVERY Trakt re-send (every
    renewal, about every 3.5 days), so a POV set to MDBList was flipped back behind the user's back.

    The rule (the user, 2026-10-21, "the safe version"):
      - a sign-in moves a choice off the add-on's default ONLY while it is still on that default;
        a choice the user made is never overruled
      - once per add-on per sign-in: a user who puts it back to local afterwards is left alone at
        the next renewal (the add-on is remembered as "done" for that service)
      - Trakt wins over MDBList: a choice ReAuthorize itself set to MDBList moves to Trakt
      - a sign-out (or a pause, or a wipe) puts back the add-on's default only where ReAuthorize set
        it and it still holds that service, then lets another signed-in service take over
    The values come from each add-on's own code (read 2026-10-21): what its own sign-in sets, and
    what its own sign-out puts back. Add-on updates keep their settings, so the choices survive them.
"""

import json
import sqlite3

import xbmc
import xbmcaddon
import xbmcvfs

from reauthorize.modules.control import accountmgr

LOG_TAG = '[ReAuthorize Pickers]'
STATE_SETTING = 'pickers.state'          # hidden, per profile, never backed up
PRIORITY = ('trakt', 'mdblist')          # earlier wins
SIGNED_IN = {'trakt': 'trakt.token', 'mdblist': 'mdblist.oauth.token'}

REDLIGHT = 'plugin.video.redlight'
GEARS = 'plugin.video.gears'
GRATISRED = 'plugin.video.gratisred'
TMDBH = 'plugin.video.themoviedb.helper'

# A choice that names a provider add-on is only made while that add-on is installed: TMDb Helper takes a
# selection it cannot load as 'chosen' and then never offers its own set-up (sync/providers/selection.py).
REQUIRES = {TMDBH: 'script.module.tmdbhelper.sync.trakt'}

# addon id: (where it keeps settings, [(choice setting, label setting or None)], default value,
#            default label, {service: (value, label)})
# Labels are the text some add-ons show beside a choice they keep as a number.
PICKERS = {
    # POV 3.0: watched_indicators POV|Trakt|MDBList; its own sign-ins set 1 / 2
    'plugin.video.pov': ('settings', (('watched_indicators', None),), '0', None,
                         {'trakt': ('1', None), 'mdblist': ('2', None)}),
    # Coalition (a POV relative; no copy on this PC to read its MDBList value): Trakt only
    'plugin.video.coalition': ('settings', (('watched_indicators', None),), '0', None,
                               {'trakt': ('1', None)}),
    # Umbrella 6.7.92: indicators.alt / scrobble.source 0 Local, 1 Trakt, 2 Simkl, 3 MDBList, 7 PunchPlay;
    # its own Trakt sign-in sets both to 1 with the labels 'Trakt' (modules/trakt.py)
    'plugin.video.umbrella': ('settings', (('indicators.alt', 'indicators'), ('scrobble.source', 'scrobble')),
                              '0', 'Local', {'trakt': ('1', 'Trakt'), 'mdblist': ('3', 'MDBList')}),
    # Red Light 2.8.8 (settings.db): 0 Red Light, 1 Trakt, 2 Simkl, 3 MDBList, 4 PunchPlay, 5 WeTrakr;
    # it falls back to its own tracking when the chosen account is not signed in
    REDLIGHT: ('redlight', (('watched_indicators', 'watched_indicators_name'),), '0', 'Red Light',
               {'trakt': ('1', 'Trakt'), 'mdblist': ('3', 'MDBList')}),
    # Gears 2.4 (settings.db): 0 built-in, 1 Trakt, 2 Simkl, 3 MDBList; ReAuthorize sends it Trakt only
    GEARS: ('gears', (('watched_indicators', 'watched_indicators_name'),), '0', 'gears',
            {'trakt': ('1', 'Trakt')}),
    # GratisRed 2.0.8: 0 Gratis Red, 1 Trakt, 2 Simkl, 3 MDBList. Its own Trakt sign-in asks and sets both, so a
    # sign-in from ReAuthorize left lists showing with no watched marks (log 1007, solved by RJ 2026-11-01).
    # 2.0.9 also takes the MDBList account (mdblist_oauth_sync.py, 1.4.9): Trakt still wins.
    GRATISRED: ('settings', (('indicators.alt', 'indicators.alt.name'), ('bookmarks.source', None)), '0', 'Gratis Red',
                {'trakt': ('1', 'Trakt'), 'mdblist': ('3', 'MDBList')}),     # 2.0.9 takes the account (1.4.9)
    # TMDb Helper 6.21: which provider add-on keeps each kind of mark; empty = not chosen yet, 'never' = the
    # user said no. Its own Trakt sign-in offers to set all four to 'trakt' (provider_default.py); scrobbling
    # also takes a JSON list, and a plain 'trakt' reads the same. Only the Trakt provider gets a sign-in.
    TMDBH: ('settings', (('sync_provider_watched', None), ('sync_provider_watchlist', None),
                         ('sync_provider_collection', None), ('sync_provider_scrobbling', None)), '', None,
            {'trakt': ('trakt', None)}),
}


def _log(message):
    xbmc.log('%s %s' % (LOG_TAG, message), xbmc.LOGINFO)


# -- state ----------------------------------------------------------------------------------------

def _state():
    try:
        state = json.loads(accountmgr.getSetting(STATE_SETTING) or '{}')
    except Exception:
        state = {}
    state.setdefault('done', {})         # service -> add-ons already offered for this sign-in
    state.setdefault('set', {})          # 'addon|choice' -> the service ReAuthorize set it to
    _adopt_old_trakt_choices(state)
    return state


# Up to 1.4.4 ReAuthorize itself switched these to Trakt at every Trakt send, and kept no note of it.
_OLD_TRAKT_FORCED = ('plugin.video.pov', 'plugin.video.coalition', GEARS)


def _adopt_old_trakt_choices(state):
    """
    Once, the first time this runs while Trakt is signed in (1.4.5, the user's decision 2026-10-23): a POV,
    Coalition or Gears choice still on Trakt is counted as set by ReAuthorize, since older versions put it
    there without a note. Without this, a Trakt pause or sign-out left POV on a Trakt it no longer had
    (the bench, 2026-10-22). The cost: a Trakt choice someone made by hand there is also put back on a
    Trakt pause or sign-out, when Trakt cannot take watched marks anyway.
    """
    if state.get('migrated') or not accountmgr.getSetting(SIGNED_IN['trakt']):
        return
    for addon_id in _OLD_TRAKT_FORCED:
        try:
            if not _ready(addon_id):
                continue
            choices, values = PICKERS[addon_id][1], PICKERS[addon_id][4]
            for choice, _label in choices:
                key = '%s|%s' % (addon_id, choice)
                if key not in state['set'] and _read(addon_id, choice) == values['trakt'][0]:
                    state['set'][key] = 'trakt'
                    done = state['done'].setdefault('trakt', [])
                    if addon_id not in done:
                        done.append(addon_id)
                    _log('%s: %s on Trakt counted as set by ReAuthorize (older versions set it)' % (addon_id, choice))
        except Exception as e:
            _log('could not read the choice in %s: %s' % (addon_id, e))
    state['migrated'] = True


def _save(state):
    state['done'] = {k: v for k, v in state['done'].items() if v}
    text = json.dumps(state, sort_keys=True) if (state['done'] or state['set'] or state.get('migrated')) else ''
    if accountmgr.getSetting(STATE_SETTING) != text:
        accountmgr.setSetting(STATE_SETTING, text)


def clear_state():
    """A wipe or a reset: nothing of the old set-up is carried over (a build must not ship it)."""
    if accountmgr.getSetting(STATE_SETTING):
        accountmgr.setSetting(STATE_SETTING, '')


# -- reading and writing the add-ons --------------------------------------------------------------

def _db_path(addon_id):
    return xbmcvfs.translatePath('special://profile/addon_data/%s/databases/settings.db' % addon_id)


def _ready(addon_id):
    if not xbmcvfs.exists('special://home/addons/%s/' % addon_id):
        return False
    if PICKERS[addon_id][0] == 'settings':
        return xbmcvfs.exists('special://profile/addon_data/%s/settings.xml' % addon_id)
    return xbmcvfs.exists(_db_path(addon_id))


def _read(addon_id, setting):
    if PICKERS[addon_id][0] == 'settings':
        return xbmcaddon.Addon(addon_id).getSetting(setting)
    conn = sqlite3.connect(_db_path(addon_id), timeout=10)
    try:
        row = conn.execute('SELECT setting_value FROM settings WHERE setting_id = ?', (setting,)).fetchone()
    finally:
        conn.close()
    return '' if not row or row[0] is None else str(row[0])


def _write(addon_id, pairs):
    """pairs: [(setting, value)]; a None setting (no label) is skipped."""
    pairs = [(s, v) for s, v in pairs if s]
    store = PICKERS[addon_id][0]
    if store == 'settings':
        addon = xbmcaddon.Addon(addon_id)
        for s, v in pairs:
            if addon.getSetting(s) != v:
                addon.setSetting(s, v)
        return
    if store == 'redlight':
        from reauthorize.modules.db import redlight_db
        redlight_db.push(pairs, require_first=False)       # it reloads Red Light (batched in a full sync)
        return
    conn = sqlite3.connect(_db_path(addon_id), timeout=10)
    try:
        with conn:
            for s, v in pairs:
                conn.execute('UPDATE settings SET setting_value = ? WHERE setting_id = ?', (v, s))
    finally:
        conn.close()


def _on_default(value, default):
    return value in ('', default)


# -- the two moves --------------------------------------------------------------------------------

def apply(service):
    """
    A sign-in of `service` reached the add-ons: switch each add-on's choice to it, by the rule above.
    Safe to call at every send (renewals included). How many choices were switched.
    """
    from reauthorize.modules import control
    if control.wiping() or service not in SIGNED_IN or not accountmgr.getSetting(SIGNED_IN[service]):
        return 0
    from reauthorize.modules import pause
    if pause.paused(pause.PICKER_TAG[service]):
        return 0                                    # paused: its add-ons do not have it
    state = _state()
    done = state['done'].setdefault(service, [])
    switched = 0
    for addon_id, (store, choices, default, default_label, values) in sorted(PICKERS.items()):
        if service not in values or addon_id in done:
            continue
        try:
            if not _ready(addon_id):
                continue
            if addon_id in REQUIRES and not xbmcvfs.exists('special://home/addons/%s/' % REQUIRES[addon_id]):
                continue                    # not 'done': it is set once the provider is installed
            value, label = values[service]
            for choice, label_setting in choices:
                key = '%s|%s' % (addon_id, choice)
                current = _read(addon_id, choice)
                owner = state['set'].get(key)
                ours_lower = (owner and owner != service and owner in values and
                              current == values[owner][0] and
                              PRIORITY.index(service) < PRIORITY.index(owner))
                if _on_default(current, default) or ours_lower:
                    _write(addon_id, [(choice, value), (label_setting, label)])
                    state['set'][key] = service
                    switched += 1
                    _log('%s: %s set to %s (%s)' % (addon_id, choice, service,
                         'it was on its default' if _on_default(current, default)
                         else 'ReAuthorize had set it to %s' % owner))
            done.append(addon_id)
        except Exception as e:
            _log('could not set the choice in %s: %s' % (addon_id, e))
    _save(state)
    return switched


def release(service):
    """
    `service` was signed out, paused or wiped: put back the add-on's default wherever ReAuthorize
    set the choice to it and it still holds it, then let another signed-in service take over.
    How many choices were put back.
    """
    from reauthorize.modules import control
    state = _state()
    state['done'].pop(service, None)
    put_back = 0
    touched = set()
    for key, owner in sorted(state['set'].items()):
        if owner != service:
            continue
        addon_id, choice = key.split('|', 1)
        del state['set'][key]
        spec = PICKERS.get(addon_id)
        if not spec:
            continue
        store, choices, default, default_label, values = spec
        try:
            if not _ready(addon_id):
                continue
            if _read(addon_id, choice) != values[service][0]:
                continue                   # the user has changed it since: theirs now
            label_setting = dict(choices).get(choice)
            _write(addon_id, [(choice, default), (label_setting, default_label)])
            put_back += 1
            touched.add(addon_id)
            _log('%s: %s put back to its default (%s signed out)' % (addon_id, choice, service))
        except Exception as e:
            _log('could not put back the choice in %s: %s' % (addon_id, e))
    for other in state['done']:
        state['done'][other] = [a for a in state['done'][other] if a not in touched]
    _save(state)
    if touched and not control.wiping():
        for other in PRIORITY:
            if other != service:
                apply(other)
    return put_back
