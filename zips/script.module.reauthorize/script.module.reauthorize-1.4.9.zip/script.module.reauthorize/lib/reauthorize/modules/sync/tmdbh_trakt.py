# -*- coding: utf-8 -*-
"""
    ReAuthorize - TMDb Helper's Trakt provider add-on (1.4.9)

    TMDb Helper 6.21 moved Trakt out of itself into a separate provider add-on,
    script.module.tmdbhelper.sync.trakt (also MDBList, Simkl, Kodi, TVDb, ... each its own add-on, none
    installed with TMDb Helper). From then on TMDb Helper reads no Trakt sign-in of its own, and the file
    ReAuthorize used to patch for its key (var.path_tmdbh) is gone. Read from the provider 1.2.9 on the
    bench, 2026-11-10:

      - the sign-in is its setting `token`: one JSON value, the same layout as TMDb Helper's old
        `trakt_token` (access_token, refresh_token, created_at, expires_in). It is read from the home-window
        property TMDbHelper.TraktUserToken FIRST, so after a change that property is cleared; a 401 also
        makes it read the settings again.
      - its app key is one line, CLIENT_ID = '...' in api/keys.py (TMDb Helper's old key, no secret: it renews
        without one).
      - it renews when created_at + expires_in has passed, or after a 401 with nothing newer in its settings.
        It gets NO_RENEW as its refresh token and created_at = the real expiry (as TMDb Helper did, 1.3.8 /
        1.4.5): renewal is ReAuthorize's job. A refused renewal (400 invalid_grant) only pauses it for 300 s;
        a call in the background never asks to sign in and nothing is deleted.
      - on its first use it copies TMDb Helper's old trakt_token once, when its own is empty
        (credentials_migrated). ReAuthorize marks that done, so an old copy is never taken after a sign-out.
      - which tracker TMDb Helper uses for watched / watchlist / collection / scrobbling is TMDb Helper's own
        choice (sync_provider_*), set in pickers.py.
"""

import json
import os

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from libs.common import var
from reauthorize.modules.sync.simkl_appkey import swap_key, restore_key

PROVIDER = 'script.module.tmdbhelper.sync.trakt'
KEY_FILE = 'resources/lib/tmdbhelper_sync_trakt/api/keys.py'
KEY_NAME = 'CLIENT_ID'
TOKEN_SETTING = 'token'
LOG_TAG = '[ReAuthorize Trakt]'
LABEL = 'TMDb Helper Trakt'

# What the provider keeps in the home window (settings.py clear_authorization_session, api/token.py).
_PROPERTIES = ('TraktUserToken', 'TraktIsAuth', 'TraktRefreshAttempts', 'TraktRefreshTimeStamp',
               'TraktAttemptedLogin')


def installed():
    return xbmcvfs.exists('special://home/addons/%s/' % PROVIDER)


def key_path():
    return os.path.join(var.addons, PROVIDER, *KEY_FILE.split('/'))


def token_value(token, expires, no_renew):
    """The provider's `token` setting for this sign-in (the same text TMDb Helper's old block wrote)."""
    return json.dumps({'access_token': token, 'token_type': 'bearer', 'expires_in': 7776000,
                       'refresh_token': no_renew, 'scope': 'public', 'created_at': int(float(expires))},
                      separators=(',', ':'))


def forget_cache():
    window = xbmcgui.Window(10000)
    for name in _PROPERTIES:
        window.clearProperty('TMDbHelper.%s' % name)


def _rewrite_key(change, done):
    path = key_path()
    try:
        with open(path, encoding='utf-8') as f:
            text = f.read()
    except Exception:
        return False
    changed = change(text)
    if changed == text:
        return False
    try:
        with open(path, 'w', encoding='utf-8') as f:
            f.write(changed)
        xbmc.log('%s %s %s' % (LOG_TAG, done, LABEL), xbmc.LOGINFO)
        return True
    except Exception as e:
        xbmc.log('%s could not change the Trakt app key in %s: %s' % (LOG_TAG, LABEL, e), xbmc.LOGINFO)
        return False


def ensure_key():
    """ReAuthorize's Trakt app key on the provider's key line (an update of it puts its own back)."""
    return _rewrite_key(lambda text: swap_key(text, KEY_NAME, var.client_am), 'Trakt app key set in')


def restore_own_key():
    return _rewrite_key(lambda text: restore_key(text, KEY_NAME), 'own Trakt app key put back in')


def link(token, expires, no_renew):
    """Give the provider this sign-in. True if anything was written."""
    if not (installed() and token and expires):
        return False
    ensure_key()
    addon = xbmcaddon.Addon(PROVIDER)
    value = token_value(token, expires, no_renew)
    if addon.getSetting(TOKEN_SETTING) == value and addon.getSetting('credentials_migrated') == 'true':
        return False
    addon.setSetting(TOKEN_SETTING, value)
    addon.setSetting('credentials_migrated', 'true')
    forget_cache()
    return True


def wipe():
    """A sign-out or a wipe: blank the sign-in, forget what it holds in memory, give it its own key back."""
    if not installed():
        return False
    changed = False
    try:
        addon = xbmcaddon.Addon(PROVIDER)
        if addon.getSetting(TOKEN_SETTING):
            addon.setSetting(TOKEN_SETTING, '')
            changed = True
        if addon.getSetting('credentials_migrated') != 'true':
            addon.setSetting('credentials_migrated', 'true')   # no later copy of TMDb Helper's old token
    except Exception as e:
        xbmc.log('%s could not clear %s: %s' % (LOG_TAG, LABEL, e), xbmc.LOGINFO)
    forget_cache()
    return restore_own_key() or changed
