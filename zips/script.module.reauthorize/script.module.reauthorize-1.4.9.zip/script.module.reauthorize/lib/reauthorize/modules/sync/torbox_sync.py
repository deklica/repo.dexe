import xbmc
import xbmcaddon
import xbmcvfs
import os

from libs.common import var

char_remov = ["'", ",", ")","("]

#Account Manager Torbox
# Shared accessor: a cached Addon handle can revert settings written
# through another instance. See control._Settings.
from reauthorize.modules.control import accountmgr
your_token = accountmgr.getSetting("torbox.token")
# What the add-ons show as the account. Up to 1.4.4 this was torbox.acct_id, which held the API KEY itself, so the
# key was shown as a user name and stayed in builds (Revoke and Prepare for Distribution never cleared it).
your_acct_id = 'TorBox' if your_token else ''

class Auth:
    def torbox_auth(self):
    #Umbrella
        try:
            if xbmcvfs.exists(var.chk_umb) and xbmcvfs.exists(var.chkset_umb):
                chk_auth_umb = xbmcaddon.Addon('plugin.video.umbrella').getSetting("torboxtoken")
                if not str(your_token) == str(chk_auth_umb) or str(chk_auth_umb) == '':

                    addon = xbmcaddon.Addon("plugin.video.umbrella")
                    addon.setSetting("torboxtoken", your_token)
                    addon.setSetting("torbox.username", your_acct_id)
                    addon.setSetting("torbox.enable", 'true')

        except:
            xbmc.log('%s: Umbrella TorBox Failed!' % var.amgr, xbmc.LOGINFO)

    #ResolveURL (1.4.5, outside audit): TorBoxResolver_apikey (plugins/torbox.py, ResolveURL 5.1.211); the
    #resolver is used only when enabled AND it holds the key. The Crew and every add-on that plays through
    #ResolveURL get TorBox from here; up to 1.4.4 nothing was sent.
        try:
            if xbmcvfs.exists(var.chk_rurl) and xbmcvfs.exists(var.chkset_rurl):
                chk_auth_rurl = xbmcaddon.Addon('script.module.resolveurl').getSetting("TorBoxResolver_apikey")
                if not str(your_token) == str(chk_auth_rurl) or str(chk_auth_rurl) == '':
                    addon = xbmcaddon.Addon("script.module.resolveurl")
                    addon.setSetting("TorBoxResolver_apikey", your_token)
                    if your_token:
                        addon.setSetting("TorBoxResolver_enabled", "true")
        except:
            xbmc.log('%s: ResolveURL TorBox Failed!' % var.amgr, xbmc.LOGINFO)

    #POV
        try:
            if xbmcvfs.exists(var.chk_pov) and xbmcvfs.exists(var.chkset_pov):
                chk_auth_pov = xbmcaddon.Addon('plugin.video.pov').getSetting("tb.token")
                if not str(your_token) == str(chk_auth_pov) or str(chk_auth_pov) == '':

                    addon = xbmcaddon.Addon("plugin.video.pov")
                    addon.setSetting("tb.token", your_token)
                    addon.setSetting("tb.account_id", your_acct_id)
                    addon.setSetting("tb.enabled", 'true')
                    addon.setSetting("tb.expires", '0')

        except:
            xbmc.log('%s: POV TorBox Failed!' % var.amgr, xbmc.LOGINFO)

    #Infinity
        try:
            if xbmcvfs.exists(var.chk_infinity) and xbmcvfs.exists(var.chkset_infinity):
                chk_auth_infinity = xbmcaddon.Addon('plugin.video.infinity').getSetting("torboxtoken")
                if not str(your_token) == str(chk_auth_infinity) or str(chk_auth_infinity) == '':

                    addon = xbmcaddon.Addon("plugin.video.infinity")
                    addon.setSetting("torboxtoken", your_token)
                    addon.setSetting("torbox.username", your_acct_id)
                    addon.setSetting("torbox.enable", 'true')
                    addon.setSetting("torbox.expirynotice", '0')

        except:
            xbmc.log('%s: Infinity TorBox Failed!' % var.amgr, xbmc.LOGINFO)

 #Otaku
        try:
            if xbmcvfs.exists(var.chk_otaku) and not xbmcvfs.exists(var.otaku_ud):
                os.mkdir(var.otaku_ud)
                xbmcvfs.copy(os.path.join(var.otaku), os.path.join(var.chkset_otaku))

            if xbmcvfs.exists(var.chk_otaku) and not xbmcvfs.exists(var.chkset_otaku):
                xbmcvfs.copy(os.path.join(var.otaku), os.path.join(var.chkset_otaku))

            if xbmcvfs.exists(var.chk_otaku) and xbmcvfs.exists(var.chkset_otaku):
                chk_auth_otaku = xbmcaddon.Addon('plugin.video.otaku').getSetting("tb.apikey")
                if not str(your_token) == str(chk_auth_otaku) or str(chk_auth_otaku) == '':

                    addon = xbmcaddon.Addon("plugin.video.otaku")
                    addon.setSetting("tb.apikey", your_token)
                    addon.setSetting("tb.enabled", 'true')
        except:
            xbmc.log('%s: Otaku TorBox Failed!' % var.amgr, xbmc.LOGINFO)

    #Gears TorBox
        try:
            if xbmcvfs.exists(var.chk_gears_video) and xbmcvfs.exists(var.chkset_gears):

                from reauthorize.modules.db import torbox_db
                conn = torbox_db.create_conn(var.gears_settings_db)

                with conn:
                    cursor = conn.cursor()
                    cursor.execute('''SELECT setting_value FROM settings WHERE setting_id = ?''', ('tb.token',))
                    auth_tb = cursor.fetchone()
                    chk_auth_gears = str(auth_tb)
                    cursor.close()

                    for char in char_remov:
                        chk_auth_gears = chk_auth_gears.replace(char, "")

                    if not str(your_token) == chk_auth_gears:
                        from reauthorize.modules.db import torbox_db
                        torbox_db.auth_gears_tb()
                        var.remake_settings()
        except:
            xbmc.log('%s: Gears TorBox Failed!' % var.amgr, xbmc.LOGINFO)

    #Genocide (plugin.video.genocide) TorBox
        try:
            if xbmcvfs.exists(var.chk_newgenocide) and xbmcvfs.exists(var.chkset_newgenocide):
                chk_auth_newgenocide = xbmcaddon.Addon('plugin.video.genocide').getSetting("torbox.token")
                if not str(your_token) == str(chk_auth_newgenocide) or str(chk_auth_newgenocide) == '':
                    addon = xbmcaddon.Addon("plugin.video.genocide")
                    addon.setSetting("torbox.token", your_token)
                    addon.setSetting("torbox.username", your_acct_id)
        except:
            xbmc.log('%s: Genocide TorBox Failed!' % var.amgr, xbmc.LOGINFO)

    #Orion TorBox
        try:
            if xbmcvfs.exists(var.chk_orion) and xbmcvfs.exists(var.chkset_orion):
                chk_auth_orion = xbmcaddon.Addon('plugin.video.orion').getSetting("tb_token")
                if not str(your_token) == str(chk_auth_orion) or str(chk_auth_orion) == '':
                    addon = xbmcaddon.Addon("plugin.video.orion")
                    addon.setSetting("tb_token", your_token)
                    addon.setSetting("tb_enabled", 'true')
        except:
            xbmc.log('%s: Orion TorBox Failed!' % var.amgr, xbmc.LOGINFO)

    #Red Light TorBox
        try:
            from reauthorize.modules.db import redlight_db
            redlight_db.push([('tb.token', your_token),
                              ('tb.enabled', 'true')])
        except:
            xbmc.log('%s: Red Light TorBox Failed!' % var.amgr, xbmc.LOGINFO)

    #The Archives TorBox
        try:
            if xbmcvfs.exists(var.chk_thearchives) and xbmcvfs.exists(var.chkset_thearchives):
                chk_auth_thearchives = xbmcaddon.Addon('plugin.video.thearchives').getSetting("tb.token")
                if not str(your_token) == str(chk_auth_thearchives) or str(chk_auth_thearchives) == '':

                    addon = xbmcaddon.Addon("plugin.video.thearchives")
                    addon.setSetting("tb.token", your_token)
                    addon.setSetting("tb.enabled", 'true')
        except:
            xbmc.log('%s: The Archives TorBox Failed!' % var.amgr, xbmc.LOGINFO)

    #Cosmos TorBox
        try:
            if xbmcvfs.exists(var.chk_cosmos) and xbmcvfs.exists(var.chkset_cosmos):
                chk_auth_cosmos = xbmcaddon.Addon('plugin.video.cosmos').getSetting("tb_api_key")
                if not str(your_token) == str(chk_auth_cosmos) or str(chk_auth_cosmos) == '':
                    addon = xbmcaddon.Addon("plugin.video.cosmos")
                    addon.setSetting("tb_api_key", your_token)
                    addon.setSetting("tb_auth_done", 'true' if your_token else 'false')
                    if not your_token:
                        addon.setSetting("tb_account", '')
        except:
            xbmc.log('%s: Cosmos TorBox Failed!' % var.amgr, xbmc.LOGINFO)

    #Diamond Media Player TorBox
        try:
            if xbmcvfs.exists(var.chk_rdtplayer) and xbmcvfs.exists(var.chkset_rdtplayer):
                chk_auth_rdtplayer = xbmcaddon.Addon('plugin.program.rdtplayer').getSetting("torbox_token")
                if not str(your_token) == str(chk_auth_rdtplayer) or str(chk_auth_rdtplayer) == '':
                    addon = xbmcaddon.Addon("plugin.program.rdtplayer")
                    addon.setSetting("torbox_token", your_token)
        except:
            xbmc.log('%s: Diamond Media Player TorBox Failed!' % var.amgr, xbmc.LOGINFO)

    #Prism TorBox
    #tb.token isn't in settings.xml (visible="false" with no id= match in that file);
    #confirmed from Prism's own resources/lib/debrid/torbox.py: TB_TOKEN_KEY = "tb.token".
        try:
            if xbmcvfs.exists(var.chk_prism) and xbmcvfs.exists(var.chkset_prism):
                chk_auth_prism = xbmcaddon.Addon('plugin.video.prism').getSetting("tb.token")
                if not str(your_token) == str(chk_auth_prism) or str(chk_auth_prism) == '':
                    addon = xbmcaddon.Addon("plugin.video.prism")
                    addon.setSetting("tb.token", your_token)
                    addon.setSetting("torbox.enabled", 'true')
        except:
            xbmc.log('%s: Prism TorBox Failed!' % var.amgr, xbmc.LOGINFO)

    #TMDb Movies TorBox
        try:
            if xbmcvfs.exists(var.chk_tmdbmovies) and xbmcvfs.exists(var.chkset_tmdbmovies):
                chk_auth_tmdbmovies = xbmcaddon.Addon('plugin.video.tmdbmovies').getSetting("torbox_api_key")
                if not str(your_token) == str(chk_auth_tmdbmovies) or str(chk_auth_tmdbmovies) == '':
                    addon = xbmcaddon.Addon("plugin.video.tmdbmovies")
                    addon.setSetting("torbox_api_key", your_token)
        except:
            xbmc.log('%s: TMDb Movies TorBox Failed!' % var.amgr, xbmc.LOGINFO)

    #Youtube Theater TorBox
        try:
            if xbmcvfs.exists(var.chk_youtubetheater) and xbmcvfs.exists(var.chkset_youtubetheater):
                chk_auth_ytheater = xbmcaddon.Addon('plugin.video.youtubetheater').getSetting("tb.token")
                if not str(your_token) == str(chk_auth_ytheater) or str(chk_auth_ytheater) == '':
                    addon = xbmcaddon.Addon("plugin.video.youtubetheater")
                    addon.setSetting("tb.token", your_token)
                    addon.setSetting("debrid_use_tr", 'true')
        except:
            xbmc.log('%s: Youtube Theater TorBox Failed!' % var.amgr, xbmc.LOGINFO)
