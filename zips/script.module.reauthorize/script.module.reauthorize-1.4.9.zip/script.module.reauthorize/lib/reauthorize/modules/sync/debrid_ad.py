import xbmc, xbmcaddon
import xbmcvfs
import os

from libs.common import var

char_remov = ["'", ",", ")","("]

#Account Manager All-Debrid
# Shared accessor: a cached Addon handle can revert settings written
# through another instance. See control._Settings.
from reauthorize.modules.control import accountmgr
your_ad_username = accountmgr.getSetting("alldebrid.username")
your_ad_token = accountmgr.getSetting("alldebrid.token")

class Auth:
    def alldebrid_auth(self):
#Seren AD
        try:
            if xbmcvfs.exists(var.chk_seren) and xbmcvfs.exists(var.chkset_seren): #Check that the addon is installed and settings.xml exists

                #Get add-on setting to compare
                chk_auth_seren = xbmcaddon.Addon('plugin.video.seren').getSetting("alldebrid.apikey")
                chk_auth_seren_rd = xbmcaddon.Addon('plugin.video.seren').getSetting("rd.auth")
                chk_auth_seren_pm = xbmcaddon.Addon('plugin.video.seren').getSetting("premiumize.token")
                if not str(your_ad_token) == str(chk_auth_seren) or str(chk_auth_seren) == '': #Compare Account Mananger token to Add-on token. If they match authorization is skipped

                    #Write data to settings.xml
                    addon = xbmcaddon.Addon("plugin.video.seren")
                    addon.setSetting("alldebrid.username", your_ad_username)
                    addon.setSetting("alldebrid.apikey", your_ad_token)

                    premium_stat = ("Premium")
                    addon.setSetting("alldebrid.premiumstatus", premium_stat)

                    #Enable authorized debrid services
                    enabled_ad = ("true")
                    addon.setSetting("alldebrid.enabled", enabled_ad)

                    if str(chk_auth_seren_rd) != '': #Check if Real-Debrid is authorized
                        enabled_rd = ("true")
                        addon.setSetting("realdebrid.enabled", enabled_rd)
                    else:
                        enabled_rd = ("false")
                        addon.setSetting("realdebrid.enabled", enabled_rd)

                    if str(chk_auth_seren_pm) != '': #Check if Premiumize is authorized
                        enabled_pm = ("true")
                        addon.setSetting("premiumize.enabled", enabled_pm)
                    else:
                        enabled_pm = ("false")
                        addon.setSetting("premiumize.enabled", enabled_pm)
        except:
            xbmc.log('%s: Seren All-Debrid Failed!' % var.amgr, xbmc.LOGINFO)

    #Coalition AD
        try:
            if xbmcvfs.exists(var.chk_coal) and xbmcvfs.exists(var.chkset_coal):
                chk_auth_coal = xbmcaddon.Addon('plugin.video.coalition').getSetting("ad.token")
                chk_auth_coal_rd = xbmcaddon.Addon('plugin.video.coalition').getSetting("rd.token")
                chk_auth_coal_pm = xbmcaddon.Addon('plugin.video.coalition').getSetting("pm.token")
                if not str(your_ad_token) == str(chk_auth_coal) or str(chk_auth_coal) == '':

                    addon = xbmcaddon.Addon("plugin.video.coalition")
                    addon.setSetting("ad.account_id", your_ad_username)
                    addon.setSetting("ad.token", your_ad_token)

                    enabled_ad = ("true")
                    addon.setSetting("ad.enabled", enabled_ad)

                    if str(chk_auth_coal_rd) != '':
                        enabled_rd = ("true")
                        addon.setSetting("rd.enabled", enabled_rd)
                    else:
                        enabled_rd = ("false")
                        addon.setSetting("rd.enabled", enabled_rd)

                    if str(chk_auth_coal_pm) != '':
                        enabled_pm = ("true")
                        addon.setSetting("pm.enabled", enabled_pm)
                    else:
                        enabled_pm = ("false")
                        addon.setSetting("pm.enabled", enabled_pm)
        except:
            xbmc.log('%s: Coalition All-Debrid Failed!' % var.amgr, xbmc.LOGINFO)

    #POV AD
        try:
            if xbmcvfs.exists(var.chk_pov) and xbmcvfs.exists(var.chkset_pov):
                chk_auth_pov = xbmcaddon.Addon('plugin.video.pov').getSetting("ad.token")
                chk_auth_pov_rd = xbmcaddon.Addon('plugin.video.pov').getSetting("rd.token")
                chk_auth_pov_pm = xbmcaddon.Addon('plugin.video.pov').getSetting("pm.token")
                if not str(your_ad_token) == str(chk_auth_pov) or str(chk_auth_pov) == '':

                    addon = xbmcaddon.Addon("plugin.video.pov")
                    addon.setSetting("ad.account_id", your_ad_username)
                    addon.setSetting("ad.token", your_ad_token)

                    enabled_ad = ("true")
                    addon.setSetting("ad.enabled", enabled_ad)

                    if str(chk_auth_pov_rd) != '':
                        enabled_rd = ("true")
                        addon.setSetting("rd.enabled", enabled_rd)
                    else:
                        enabled_rd = ("false")
                        addon.setSetting("rd.enabled", enabled_rd)

                    if str(chk_auth_pov_pm) != '':
                        enabled_pm = ("true")
                        addon.setSetting("pm.enabled", enabled_pm)
                    else:
                        enabled_pm = ("false")
                        addon.setSetting("pm.enabled", enabled_pm)
        except:
            xbmc.log('%s: POV All-Debrid Failed!' % var.amgr, xbmc.LOGINFO)

    #Umbrella AD
        try:
            if xbmcvfs.exists(var.chk_umb) and xbmcvfs.exists(var.chkset_umb):
                chk_auth_umb = xbmcaddon.Addon('plugin.video.umbrella').getSetting("alldebridtoken")
                chk_auth_umb_rd = xbmcaddon.Addon('plugin.video.umbrella').getSetting("realdebridtoken")
                chk_auth_umb_pm = xbmcaddon.Addon('plugin.video.umbrella').getSetting("premiumizetoken")
                if not str(your_ad_token) == str(chk_auth_umb) or str(chk_auth_umb) == '':

                    addon = xbmcaddon.Addon("plugin.video.umbrella")
                    addon.setSetting("alldebridusername", your_ad_username)
                    addon.setSetting("alldebridtoken", your_ad_token)

                    enabled_ad = ("true")
                    addon.setSetting("alldebrid.enable", enabled_ad)

                    if str(chk_auth_umb_rd) != '':
                        enabled_rd = ("true")
                        addon.setSetting("realdebrid.enable", enabled_rd)
                    else:
                        enabled_rd = ("false")
                        addon.setSetting("realdebrid.enable", enabled_rd)

                    if str(chk_auth_umb_pm) != '':
                        enabled_pm = ("true")
                        addon.setSetting("premiumize.enable", enabled_pm)
                    else:
                        enabled_pm = ("false")
                        addon.setSetting("premiumize.enable", enabled_pm)
        except:
            xbmc.log('%s: Umbrella All-Debrid Failed!' % var.amgr, xbmc.LOGINFO)

    #Infinity AD
        try:
            if xbmcvfs.exists(var.chk_infinity) and xbmcvfs.exists(var.chkset_infinity):
                chk_auth_infinity = xbmcaddon.Addon('plugin.video.infinity').getSetting("alldebridtoken")
                chk_auth_infinity_rd = xbmcaddon.Addon('plugin.video.infinity').getSetting("realdebridtoken")
                chk_auth_infinity_pm = xbmcaddon.Addon('plugin.video.infinity').getSetting("premiumizetoken")
                if not str(your_ad_token) == str(chk_auth_infinity) or str(chk_auth_infinity) == '':

                    addon = xbmcaddon.Addon("plugin.video.infinity")
                    addon.setSetting("alldebridusername", your_ad_username)
                    addon.setSetting("alldebridtoken", your_ad_token)

                    enabled_ad = ("true")
                    addon.setSetting("alldebrid.enable", enabled_ad)

                    if str(chk_auth_infinity_rd) != '':
                        enabled_rd = ("true")
                        addon.setSetting("realdebrid.enable", enabled_rd)
                    else:
                        enabled_rd = ("false")
                        addon.setSetting("realdebrid.enable", enabled_rd)

                    if str(chk_auth_infinity_pm) != '':
                        enabled_pm = ("true")
                        addon.setSetting("premiumize.enable", enabled_pm)
                    else:
                        enabled_pm = ("false")
                        addon.setSetting("premiumize.enable", enabled_pm)
        except:
            xbmc.log('%s: Infinity All-Debrid Failed!' % var.amgr, xbmc.LOGINFO)

    #Shadow AD
        try:
            if xbmcvfs.exists(var.chk_shadow) and not xbmcvfs.exists(var.shadow_ud):
                os.mkdir(var.shadow_ud)
                xbmcvfs.copy(os.path.join(var.shadow), os.path.join(var.chkset_shadow))

            if xbmcvfs.exists(var.chk_shadow) and not xbmcvfs.exists(var.chkset_shadow):
                xbmcvfs.copy(os.path.join(var.shadow), os.path.join(var.chkset_shadow))

            if xbmcvfs.exists(var.chk_shadow) and xbmcvfs.exists(var.chkset_shadow):
                chk_auth_shadow = xbmcaddon.Addon('plugin.video.shadow').getSetting("alldebrid.token")
                chk_auth_shadow_rd = xbmcaddon.Addon('plugin.video.shadow').getSetting("rd.auth")
                chk_auth_shadow_pm = xbmcaddon.Addon('plugin.video.shadow').getSetting("premiumize.token")
                if not str(your_ad_token) == str(chk_auth_shadow) or str(chk_auth_shadow) == '':

                    addon = xbmcaddon.Addon("plugin.video.shadow")
                    addon.setSetting("alldebrid.username", your_ad_username)
                    addon.setSetting("alldebrid.token", your_ad_token)

                    enabled_ad = ("true")
                    addon.setSetting("debrid_use_ad", enabled_ad)

                    if str(chk_auth_shadow_rd) != '':
                        rd_use = ("true")
                        addon.setSetting("debrid_use_rd", rd_use)
                    else:
                        rd_use = ("false")
                        addon.setSetting("debrid_use_rd", rd_use)

                    if str(chk_auth_shadow_pm) != '':
                        pm_use = ("true")
                        addon.setSetting("debrid_use_pm", pm_use)
                    else:
                        pm_use = ("false")
                        addon.setSetting("debrid_use_pm", pm_use)
        except:
            xbmc.log('%s: Shadow All-Debrid Failed!' % var.amgr, xbmc.LOGINFO)

    #Blue Balls AD
        try:
            if xbmcvfs.exists(var.chk_blueballs) and not xbmcvfs.exists(var.blueballs_ud):
                os.mkdir(var.blueballs_ud)
                xbmcvfs.copy(os.path.join(var.blueballs), os.path.join(var.chkset_blueballs))

            if xbmcvfs.exists(var.chk_blueballs) and not xbmcvfs.exists(var.chkset_blueballs):
                xbmcvfs.copy(os.path.join(var.blueballs), os.path.join(var.chkset_blueballs))

            if xbmcvfs.exists(var.chk_blueballs) and xbmcvfs.exists(var.chkset_blueballs):
                chk_auth_blueballs = xbmcaddon.Addon('plugin.video.blueballs').getSetting("alldebrid.token")
                if not str(your_ad_token) == str(chk_auth_blueballs) or str(chk_auth_blueballs) == '':

                    addon = xbmcaddon.Addon("plugin.video.blueballs")
                    addon.setSetting("alldebrid.username", your_ad_username)
                    addon.setSetting("alldebrid.token", your_ad_token)

                    d_use = ("true")
                    addon.setSetting("debrid_use", d_use)

                    d_select = ("2")
                    addon.setSetting("debrid_select", d_select)
        except:
            xbmc.log('%s: Blue Balls All-Debrid Failed!' % var.amgr, xbmc.LOGINFO)

    #Twisted AD
        try:
            if xbmcvfs.exists(var.chk_twisted) and not xbmcvfs.exists(var.twisted_ud):
                os.mkdir(var.twisted_ud)
                xbmcvfs.copy(os.path.join(var.twisted), os.path.join(var.chkset_twisted))

            if xbmcvfs.exists(var.chk_twisted) and not xbmcvfs.exists(var.chkset_twisted):
                xbmcvfs.copy(os.path.join(var.twisted), os.path.join(var.chkset_twisted))

            if xbmcvfs.exists(var.chk_twisted) and xbmcvfs.exists(var.chkset_twisted):
                chk_auth_twisted = xbmcaddon.Addon('plugin.video.twisted').getSetting("alldebrid.token")
                chk_auth_twisted_rd = xbmcaddon.Addon('plugin.video.twisted').getSetting("rd.auth")
                chk_auth_twisted_pm = xbmcaddon.Addon('plugin.video.twisted').getSetting("premiumize.token")
                if not str(your_ad_token) == str(chk_auth_twisted) or str(chk_auth_twisted) == '':

                    addon = xbmcaddon.Addon("plugin.video.twisted")
                    addon.setSetting("alldebrid.username", your_ad_username)
                    addon.setSetting("alldebrid.token", your_ad_token)

                    enabled_ad = ("true")
                    addon.setSetting("debrid_use_ad", enabled_ad)

                    if str(chk_auth_twisted_rd) != '':
                        rd_use = ("true")
                        addon.setSetting("debrid_use_rd", rd_use)
                    else:
                        rd_use = ("false")
                        addon.setSetting("debrid_use_rd", rd_use)

                    if str(chk_auth_twisted_pm) != '':
                        pm_use = ("true")
                        addon.setSetting("debrid_use_pm", pm_use)
                    else:
                        pm_use = ("false")
                        addon.setSetting("debrid_use_pm", pm_use)
        except:
            xbmc.log('%s: Twisted All-Debrid Failed!' % var.amgr, xbmc.LOGINFO)

    #Aliunde K19 AD
        try:
            if xbmcvfs.exists(var.chk_aliunde) and xbmcvfs.exists(var.chkset_aliunde):
                chk_auth_aliunde = xbmcaddon.Addon('plugin.video.aliundek19').getSetting("alldebrid.token")
                chk_auth_aliunde_rd = xbmcaddon.Addon('plugin.video.aliundek19').getSetting("rd.auth")
                chk_auth_aliunde_pm = xbmcaddon.Addon('plugin.video.aliundek19').getSetting("premiumize.token")
                if not str(your_ad_token) == str(chk_auth_aliunde) or str(chk_auth_aliunde) == '':

                    addon = xbmcaddon.Addon("plugin.video.aliundek19")
                    addon.setSetting("alldebrid.username", your_ad_username)
                    addon.setSetting("alldebrid.token", your_ad_token)

                    enabled_ad = ("true")
                    addon.setSetting("debrid_use_ad", enabled_ad)

                    if str(chk_auth_aliunde_rd) != '':
                        rd_use = ("true")
                        addon.setSetting("debrid_use_rd", rd_use)
                    else:
                        rd_use = ("false")
                        addon.setSetting("debrid_use_rd", rd_use)

                    if str(chk_auth_aliunde_pm) != '':
                        pm_use = ("true")
                        addon.setSetting("debrid_use_pm", pm_use)
                    else:
                        pm_use = ("false")
                        addon.setSetting("debrid_use_pm", pm_use)
        except:
            xbmc.log('%s: Aliunde K19 All-Debrid Failed!' % var.amgr, xbmc.LOGINFO)

    #Ghost AD
        try:
            if xbmcvfs.exists(var.chk_ghost) and not xbmcvfs.exists(var.ghost_ud):
                os.mkdir(var.ghost_ud)
                xbmcvfs.copy(os.path.join(var.ghost), os.path.join(var.chkset_ghost))

            if xbmcvfs.exists(var.chk_ghost) and not xbmcvfs.exists(var.chkset_ghost):
                xbmcvfs.copy(os.path.join(var.ghost), os.path.join(var.chkset_ghost))

            if xbmcvfs.exists(var.chk_ghost) and xbmcvfs.exists(var.chkset_ghost):
                chk_auth_ghost = xbmcaddon.Addon('plugin.video.ghost').getSetting("alldebrid.token")
                if not str(your_ad_token) == str(chk_auth_ghost) or str(chk_auth_ghost) == '':

                    addon = xbmcaddon.Addon("plugin.video.ghost")
                    addon.setSetting("alldebrid.username", your_ad_username)
                    addon.setSetting("alldebrid.token", your_ad_token)

                    d_use = ("true")
                    addon.setSetting("debrid_use", d_use)

                    d_select = ("2")
                    addon.setSetting("debrid_select", d_select)
        except:
            xbmc.log('%s: Ghost All-Debrid Failed!' % var.amgr, xbmc.LOGINFO)

    #Base AD
        try:
            if xbmcvfs.exists(var.chk_base) and not xbmcvfs.exists(var.base_ud):
                os.mkdir(var.base_ud)
                xbmcvfs.copy(os.path.join(var.base), os.path.join(var.chkset_base))

            if xbmcvfs.exists(var.chk_base) and not xbmcvfs.exists(var.chkset_base):
                xbmcvfs.copy(os.path.join(var.base), os.path.join(var.chkset_base))

            if xbmcvfs.exists(var.chk_base) and xbmcvfs.exists(var.chkset_base):
                chk_auth_base = xbmcaddon.Addon('plugin.video.base').getSetting("alldebrid.token")
                if not str(your_ad_token) == str(chk_auth_base) or str(chk_auth_base) == '':

                    addon = xbmcaddon.Addon("plugin.video.base")
                    addon.setSetting("alldebrid.username", your_ad_username)
                    addon.setSetting("alldebrid.token", your_ad_token)

                    d_select = ("2")
                    addon.setSetting("debrid_select", d_select)
        except:
            xbmc.log('%s: Base All-Debrid Failed!' % var.amgr, xbmc.LOGINFO)

    #Chains AD
        try:
            if xbmcvfs.exists(var.chk_chains) and not xbmcvfs.exists(var.chains_ud):
                os.mkdir(var.chains_ud)
                xbmcvfs.copy(os.path.join(var.chains), os.path.join(var.chkset_chains))

            if xbmcvfs.exists(var.chk_chains) and not xbmcvfs.exists(var.chkset_chains):
                xbmcvfs.copy(os.path.join(var.chains), os.path.join(var.chkset_chains))

            if xbmcvfs.exists(var.chk_chains) and xbmcvfs.exists(var.chkset_chains):
                chk_auth_chains = xbmcaddon.Addon('plugin.video.thechains').getSetting("alldebrid.token")
                if not str(your_ad_token) == str(chk_auth_chains) or str(chk_auth_chains) == '':

                    addon = xbmcaddon.Addon("plugin.video.thechains")
                    addon.setSetting("alldebrid.username", your_ad_username)
                    addon.setSetting("alldebrid.token", your_ad_token)

                    d_use = ("true")
                    addon.setSetting("debrid_use", d_use)

                    d_select = ("2")
                    addon.setSetting("debrid_select", d_select)
        except:
            xbmc.log('%s: Chains All-Debrid Failed!' % var.amgr, xbmc.LOGINFO)

    #Patriot AD
        try:
            if xbmcvfs.exists(var.chk_patriot) and not xbmcvfs.exists(var.patriot_ud):
                os.mkdir(var.patriot_ud)
                xbmcvfs.copy(os.path.join(var.patriot), os.path.join(var.chkset_patriot))

            if xbmcvfs.exists(var.chk_patriot) and not xbmcvfs.exists(var.chkset_patriot):
                xbmcvfs.copy(os.path.join(var.patriot), os.path.join(var.chkset_patriot))

            if xbmcvfs.exists(var.chk_patriot) and xbmcvfs.exists(var.chkset_patriot):
                chk_auth_patriot = xbmcaddon.Addon('plugin.video.patriot').getSetting("alldebrid.token")
                if not str(your_ad_token) == str(chk_auth_patriot) or str(chk_auth_patriot) == '':

                    addon = xbmcaddon.Addon("plugin.video.patriot")
                    addon.setSetting("alldebrid.username", your_ad_username)
                    addon.setSetting("alldebrid.token", your_ad_token)

                    d_use = ("true")
                    addon.setSetting("debrid_use", d_use)

                    d_select = ("2")
                    addon.setSetting("debrid_select", d_select)
        except:
            xbmc.log('%s: Patriot All-Debrid Failed!' % var.amgr, xbmc.LOGINFO)

    #Black Lightning AD
        try:
            if xbmcvfs.exists(var.chk_blackl) and not xbmcvfs.exists(var.blackl_ud):
                os.mkdir(var.blackl_ud)
                xbmcvfs.copy(os.path.join(var.blackl), os.path.join(var.chkset_blackl))

            if xbmcvfs.exists(var.chk_blackl) and not xbmcvfs.exists(var.chkset_blackl):
                xbmcvfs.copy(os.path.join(var.blackl), os.path.join(var.chkset_blackl))

            if xbmcvfs.exists(var.chk_blackl) and xbmcvfs.exists(var.chkset_blackl):
                chk_auth_blackl = xbmcaddon.Addon('plugin.video.blacklightning').getSetting("alldebrid.token")
                chk_auth_blackl_rd = xbmcaddon.Addon('plugin.video.blacklightning').getSetting("rd.auth")
                chk_auth_blackl_pm = xbmcaddon.Addon('plugin.video.blacklightning').getSetting("premiumize.token")
                if not str(your_ad_token) == str(chk_auth_blackl) or str(chk_auth_blackl) == '':

                    addon = xbmcaddon.Addon("plugin.video.blacklightning")
                    addon.setSetting("alldebrid.username", your_ad_username)
                    addon.setSetting("alldebrid.token", your_ad_token)

                    enabled_ad = ("true")
                    addon.setSetting("debrid_use_ad", enabled_ad)

                    if str(chk_auth_blackl_rd) != '':
                        rd_use = ("true")
                        addon.setSetting("debrid_use_rd", rd_use)
                    else:
                        rd_use = ("false")
                        addon.setSetting("debrid_use_rd", rd_use)

                    if str(chk_auth_blackl_pm) != '':
                        pm_use = ("true")
                        addon.setSetting("debrid_use_pm", pm_use)
                    else:
                        pm_use = ("false")
                        addon.setSetting("debrid_use_pm", pm_use)
        except:
            xbmc.log('%s: Black Lightning All-Debrid Failed!' % var.amgr, xbmc.LOGINFO)

    #Chains Genocide AD
        try:
            if xbmcvfs.exists(var.chk_genocide) and not xbmcvfs.exists(var.genocide_ud):
                os.mkdir(var.genocide_ud)
                xbmcvfs.copy(os.path.join(var.genocide), os.path.join(var.chkset_genocide))

            if xbmcvfs.exists(var.chk_genocide) and not xbmcvfs.exists(var.chkset_genocide):
                xbmcvfs.copy(os.path.join(var.genocide), os.path.join(var.chkset_genocide))

            if xbmcvfs.exists(var.chk_genocide) and xbmcvfs.exists(var.chkset_genocide):
                chk_auth_genocide = xbmcaddon.Addon('plugin.video.chainsgenocide').getSetting("alldebrid.token")
                if not str(your_ad_token) == str(chk_auth_genocide) or str(chk_auth_genocide) == '':

                    addon = xbmcaddon.Addon("plugin.video.chainsgenocide")
                    addon.setSetting("alldebrid.username", your_ad_username)
                    addon.setSetting("alldebrid.token", your_ad_token)
        except:
            xbmc.log('%s: Chains Genocide All-Debrid Failed!' % var.amgr, xbmc.LOGINFO)

 #Otaku AD
        try:
            if xbmcvfs.exists(var.chk_otaku) and not xbmcvfs.exists(var.otaku_ud):
                os.mkdir(var.otaku_ud)
                xbmcvfs.copy(os.path.join(var.otaku), os.path.join(var.chkset_otaku))

            if xbmcvfs.exists(var.chk_otaku) and not xbmcvfs.exists(var.chkset_otaku):
                xbmcvfs.copy(os.path.join(var.otaku), os.path.join(var.chkset_otaku))

            if xbmcvfs.exists(var.chk_otaku) and xbmcvfs.exists(var.chkset_otaku):
                chk_auth_otaku = xbmcaddon.Addon('plugin.video.otaku').getSetting("alldebrid.apikey")
                if not str(your_ad_token) == str(chk_auth_otaku) or str(chk_auth_otaku) == '':

                    addon = xbmcaddon.Addon("plugin.video.otaku")
                    addon.setSetting("alldebrid.username", your_ad_username)
                    addon.setSetting("alldebrid.apikey", your_ad_token)

                    enabled_ad = ("true")
                    addon.setSetting("alldebrid.enabled", enabled_ad)
        except:
            xbmc.log('%s: Otaku All-Debrid Failed!' % var.amgr, xbmc.LOGINFO)

    #All Accounts AD
        try:
            if xbmcvfs.exists(var.chk_allaccounts) and not xbmcvfs.exists(var.allaccounts_ud):
                os.mkdir(var.allaccounts_ud)
                xbmcvfs.copy(os.path.join(var.allaccounts), os.path.join(var.chkset_allaccounts))

            if xbmcvfs.exists(var.chk_allaccounts) and not xbmcvfs.exists(var.chkset_allaccounts):
                xbmcvfs.copy(os.path.join(var.allaccounts), os.path.join(var.chkset_allaccounts))

            if xbmcvfs.exists(var.chk_allaccounts) and xbmcvfs.exists(var.chkset_allaccounts):
                chk_auth_allaccounts = xbmcaddon.Addon('script.module.allaccounts').getSetting("alldebrid.token")
                if not str(your_ad_token) == str(chk_auth_allaccounts) or str(chk_auth_allaccounts) == '':

                    addon = xbmcaddon.Addon("script.module.allaccounts")
                    addon.setSetting("alldebrid.username", your_ad_username)
                    addon.setSetting("alldebrid.token", your_ad_token)
        except:
            xbmc.log('%s: All Accounts All-Debrid Failed!' % var.amgr, xbmc.LOGINFO)

    #My Accounts AD
        try:
            if xbmcvfs.exists(var.chk_myaccounts) and not xbmcvfs.exists(var.myaccounts_ud):
                os.mkdir(var.myaccounts_ud)
                xbmcvfs.copy(os.path.join(var.myaccounts), os.path.join(var.chkset_myaccounts))

            if xbmcvfs.exists(var.chk_myaccounts) and not xbmcvfs.exists(var.chkset_myaccounts):
                xbmcvfs.copy(os.path.join(var.myaccounts), os.path.join(var.chkset_myaccounts))

            if xbmcvfs.exists(var.chk_myaccounts) and xbmcvfs.exists(var.chkset_myaccounts):
                chk_auth_myaccounts = xbmcaddon.Addon('script.module.myaccounts').getSetting("alldebrid.token")
                if not str(your_ad_token) == str(chk_auth_myaccounts) or str(chk_auth_myaccounts) == '':

                    addon = xbmcaddon.Addon("script.module.myaccounts")
                    addon.setSetting("alldebrid.username", your_ad_username)
                    addon.setSetting("alldebrid.token", your_ad_token)
        except:
            xbmc.log('%s: My Accounts All-Debrid Failed!' % var.amgr, xbmc.LOGINFO)

    #ResolveURL AD
        try:
            if xbmcvfs.exists(var.chk_rurl) and not xbmcvfs.exists(var.rurl_ud):
                os.mkdir(var.rurl_ud)
                xbmcvfs.copy(os.path.join(var.rurl), os.path.join(var.chkset_rurl))

            if xbmcvfs.exists(var.chk_rurl) and not xbmcvfs.exists(var.chkset_rurl):
                xbmcvfs.copy(os.path.join(var.rurl), os.path.join(var.chkset_rurl))

            if xbmcvfs.exists(var.chk_rurl) and xbmcvfs.exists(var.chkset_rurl):
                chk_auth_rurl = xbmcaddon.Addon('script.module.resolveurl').getSetting("AllDebridResolver_token")
                if not str(your_ad_token) == str(chk_auth_rurl) or str(chk_auth_rurl) == '':

                    addon = xbmcaddon.Addon("script.module.resolveurl")
                    # 1.4.5: ResolveURL has no AllDebridResolver_client_id (the user name went there up
                    # to 1.4.4); a resolver is used only when enabled AND signed in.
                    if your_ad_token:
                        addon.setSetting("AllDebridResolver_enabled", "true")
                    addon.setSetting("AllDebridResolver_token", your_ad_token)

                    cache_only = ("true")
                    addon.setSetting("AllDebridResolver_cached_only", cache_only)
        except:
            xbmc.log('%s: ResolveURL All-Debrid Failed!' % var.amgr, xbmc.LOGINFO)

    #Gears AD
        try:
            if xbmcvfs.exists(var.chk_gears_video) and xbmcvfs.exists(var.chkset_gears):

                from reauthorize.modules.db import debrid_db
                conn = debrid_db.create_conn(var.gears_settings_db)

                with conn:
                    cursor = conn.cursor()
                    cursor.execute('''SELECT setting_value FROM settings WHERE setting_id = ?''', ('ad.token',))
                    auth_ad = cursor.fetchone()
                    chk_auth_gears = str(auth_ad)
                    cursor.close()

                    for char in char_remov:
                        chk_auth_gears = chk_auth_gears.replace(char, "")

                    if not str(your_ad_token) == chk_auth_gears:
                        from reauthorize.modules.db import debrid_db
                        debrid_db.auth_gears_ad()
                        var.remake_settings()
        except:
            xbmc.log('%s: Gears All-Debrid Failed!' % var.amgr, xbmc.LOGINFO)

    #Genocide (plugin.video.genocide) AD
        try:
            if xbmcvfs.exists(var.chk_newgenocide) and xbmcvfs.exists(var.chkset_newgenocide):
                chk_auth_newgenocide = xbmcaddon.Addon('plugin.video.genocide').getSetting("alldebrid.token")
                if not str(your_ad_token) == str(chk_auth_newgenocide) or str(chk_auth_newgenocide) == '':
                    addon = xbmcaddon.Addon("plugin.video.genocide")
                    addon.setSetting("alldebrid.token", your_ad_token)
                    addon.setSetting("alldebrid.username", your_ad_username)
        except:
            xbmc.log('%s: Genocide All-Debrid Failed!' % var.amgr, xbmc.LOGINFO)

    #Orion AD
        try:
            if xbmcvfs.exists(var.chk_orion) and xbmcvfs.exists(var.chkset_orion):
                chk_auth_orion = xbmcaddon.Addon('plugin.video.orion').getSetting("ad_token")
                if not str(your_ad_token) == str(chk_auth_orion) or str(chk_auth_orion) == '':
                    addon = xbmcaddon.Addon("plugin.video.orion")
                    addon.setSetting("ad_token", your_ad_token)
                    addon.setSetting("ad_enabled", 'true')
        except:
            xbmc.log('%s: Orion All-Debrid Failed!' % var.amgr, xbmc.LOGINFO)

    #Red Light AD
        try:
            from reauthorize.modules.db import redlight_db
            redlight_db.push([('ad.token', your_ad_token),
                              ('ad.account_id', your_ad_username),
                              ('ad.enabled', 'true')])
        except:
            xbmc.log('%s: Red Light All-Debrid Failed!' % var.amgr, xbmc.LOGINFO)

    #Cosmos AD
        try:
            if xbmcvfs.exists(var.chk_cosmos) and xbmcvfs.exists(var.chkset_cosmos):
                chk_auth_cosmos = xbmcaddon.Addon('plugin.video.cosmos').getSetting("ad_api_key")
                if not str(your_ad_token) == str(chk_auth_cosmos) or str(chk_auth_cosmos) == '':
                    addon = xbmcaddon.Addon("plugin.video.cosmos")
                    addon.setSetting("ad_api_key", your_ad_token)
                    addon.setSetting("ad_auth_done", 'true' if your_ad_token else 'false')
                    if not your_ad_token:
                        addon.setSetting("ad_username", '')
        except:
            xbmc.log('%s: Cosmos All-Debrid Failed!' % var.amgr, xbmc.LOGINFO)

    #The Archives AD
        try:
            if xbmcvfs.exists(var.chk_thearchives) and xbmcvfs.exists(var.chkset_thearchives):
                chk_auth_thearchives = xbmcaddon.Addon('plugin.video.thearchives').getSetting("ad.token")
                if not str(your_ad_token) == str(chk_auth_thearchives) or str(chk_auth_thearchives) == '':
                    addon = xbmcaddon.Addon("plugin.video.thearchives")
                    addon.setSetting("ad.token", your_ad_token)
                    addon.setSetting("ad.enabled", 'true')
                    addon.setSetting("ad_api_key", your_ad_token)
                    addon.setSetting("ad_auth_done", 'true')
        except:
            xbmc.log('%s: The Archives All-Debrid Failed!' % var.amgr, xbmc.LOGINFO)

    #Prism AD
        try:
            if xbmcvfs.exists(var.chk_prism) and xbmcvfs.exists(var.chkset_prism):
                chk_auth_prism = xbmcaddon.Addon('plugin.video.prism').getSetting("alldebrid.apikey")
                if not str(your_ad_token) == str(chk_auth_prism) or str(chk_auth_prism) == '':
                    addon = xbmcaddon.Addon("plugin.video.prism")
                    addon.setSetting("alldebrid.apikey", your_ad_token)
                    addon.setSetting("alldebrid.username", your_ad_username)
                    addon.setSetting("alldebrid.enabled", 'true')
        except:
            xbmc.log('%s: Prism All-Debrid Failed!' % var.amgr, xbmc.LOGINFO)

    #Youtube Theater AD
        try:
            if xbmcvfs.exists(var.chk_youtubetheater) and xbmcvfs.exists(var.chkset_youtubetheater):
                chk_auth_ytheater = xbmcaddon.Addon('plugin.video.youtubetheater').getSetting("alldebrid.token")
                if not str(your_ad_token) == str(chk_auth_ytheater) or str(chk_auth_ytheater) == '':
                    addon = xbmcaddon.Addon("plugin.video.youtubetheater")
                    addon.setSetting("alldebrid.token", your_ad_token)
                    addon.setSetting("alldebrid.username", your_ad_username)
                    addon.setSetting("debrid_use_ad", 'true')
        except:
            xbmc.log('%s: Youtube Theater All-Debrid Failed!' % var.amgr, xbmc.LOGINFO)
