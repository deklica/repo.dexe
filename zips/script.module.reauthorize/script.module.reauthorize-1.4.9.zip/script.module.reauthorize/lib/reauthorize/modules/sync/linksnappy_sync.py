import xbmc, xbmcaddon
import xbmcvfs
from libs.common import var

# Shared accessor: a cached Addon handle can revert settings written
# through another instance. See control._Settings.
from reauthorize.modules.control import accountmgr
your_username = accountmgr.getSetting("linksnappy.username")
your_password = accountmgr.getSetting("linksnappy.password")

class Auth:
    def linksnappy_auth(self):

    #Cosmos
        try:
            if xbmcvfs.exists(var.chk_cosmos) and xbmcvfs.exists(var.chkset_cosmos):
                chk_auth_cosmos = xbmcaddon.Addon('plugin.video.cosmos').getSetting("ls_username")
                # 1.4.5 (outside audit F10): the password too, or a changed password alone never got there
                if (not str(your_username) == str(chk_auth_cosmos) or str(chk_auth_cosmos) == '' or
                        xbmcaddon.Addon('plugin.video.cosmos').getSetting("ls_password") != str(your_password)):
                    addon = xbmcaddon.Addon("plugin.video.cosmos")
                    addon.setSetting("ls_username", your_username)
                    addon.setSetting("ls_password", your_password)
        except:
            xbmc.log('%s: Cosmos Linksnappy Failed!' % var.amgr, xbmc.LOGINFO)
