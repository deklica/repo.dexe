# -*- coding: utf-8 -*-
"""
    ReAuthorize - WeTrakr sign-in to the add-ons (1.4.7)

    ReAuthorize is the only one that renews (auth/wetrakr.py says why), so an add-on gets the ACCESS
    token only. Read on the bench, 2026-10-30:

    Red Light 2.9.5    settings.db: wetrakr.token + wetrakr.user = signed in, wetrakr.refresh,
                       wetrakr.expires ('0' = no renewal by the clock). With refresh '0' it never renews,
                       and a refused call is logged and clears nothing. Its calls send its own sealed app
                       key with our token; WeTrakr accepting that has to be seen on a real box.
                       Lists work once signed in; scrobbling only while WeTrakr is its Watched Status
                       Provider (watched_indicators 5), which stays the user's choice. A sign-out puts
                       that back to Red Light, as Red Light's own Revoke does.

    A Red Light holding a refresh token signed in for itself: renewals and a sign-out leave it alone,
    the sign-in button and "Sync Add-ons" replace it, a wipe clears it. The Archives and the scrobbler
    use another kind of token and are not fed.
"""

import sqlite3

import xbmc

from reauthorize.modules import control
from reauthorize.modules.control import accountmgr
from reauthorize.modules.db import redlight_db
from reauthorize.modules.sync.punchplay_sync import _redlight_rows

LOG_TAG = '[ReAuthorize WeTrakr]'
REDLIGHT = 'plugin.video.redlight'
_PROVIDER_WETRAKR = '5'


def _log(message):
    xbmc.log('%s %s' % (LOG_TAG, message), xbmc.LOGINFO)


def _held():
    """(access token, refresh token) Red Light holds now; '' for none."""
    rows = _redlight_rows('wetrakr.token', 'wetrakr.refresh')
    return rows.get('wetrakr.token', ''), rows.get('wetrakr.refresh', '')


def push(force=False):
    """Give Red Light ReAuthorize's access token; its own sign-in is replaced only with force. How many written."""
    from reauthorize.modules import pause
    token = accountmgr.getSetting('wetrakr.token')
    if not token or pause.paused('wetrakr') or not redlight_db.available():
        return 0
    try:
        held, own_refresh = _held()
        if held == token or (own_refresh and not force):
            return 0
        user = accountmgr.getSetting('wetrakr.username') or 'WeTrakr User'
        if not redlight_db.push([('wetrakr.token', token), ('wetrakr.refresh', '0'), ('wetrakr.expires', '0'),
                                 ('wetrakr.user', user)]):
            return 0                # a Red Light too old to have these rows
        _log('sign-in sent to %s' % REDLIGHT)
        return 1
    except Exception as e:
        _log('could not send the sign-in to %s: %s' % (REDLIGHT, e))
        return 0


def ensure():
    """Between renewals: put the sign-in back where an update, a build or the add-on itself removed it."""
    return push()


def holding():
    """The add-ons that hold ReAuthorize's current token (for the Sync button and the tests)."""
    token = accountmgr.getSetting('wetrakr.token')
    try:
        return [REDLIGHT] if token and redlight_db.available() and _held()[0] == token else []
    except Exception:
        return []


def _provider_back():
    # What Red Light's own Revoke does when WeTrakr was its watched-status provider.
    from libs.common import var
    if _redlight_rows('watched_indicators').get('watched_indicators') != _PROVIDER_WETRAKR:
        return
    conn = sqlite3.connect(var.redlight_settings_db, timeout=10)
    try:
        with conn:
            conn.execute("UPDATE settings SET setting_value = '0' WHERE setting_id = 'watched_indicators'")
            conn.execute("UPDATE settings SET setting_value = 'Red Light' WHERE setting_id = 'watched_indicators_name'")
    finally:
        conn.close()


def wipe(token=None):
    """
    No token (a wipe): clear Red Light's WeTrakr sign-in. A token (a sign-out): only where that token is
    held, or a token with no refresh token (one ReAuthorize sent earlier). How many add-ons were cleared.
    """
    if not redlight_db.available():
        return 0
    try:
        held, own_refresh = _held()
        if (not held and not own_refresh) or (token is not None and held != token and own_refresh):
            return 0
        _provider_back()
        before = control.wiping()
        control.set_wiping(True)                  # redlight_db puts rows back to Red Light's defaults
        try:
            redlight_db.push([('wetrakr.token', ''), ('wetrakr.refresh', ''), ('wetrakr.expires', ''), ('wetrakr.user', '')])
        finally:
            control.set_wiping(before)
        _log('sign-in removed from %s' % REDLIGHT)
        return 1
    except Exception as e:
        _log('could not clear %s: %s' % (REDLIGHT, e))
        return 0
