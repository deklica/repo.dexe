import os
import xbmc, xbmcaddon
import xbmcvfs
from reauthorize.modules import control
from libs.common import var

#Account Manager FilePursuit
# Shared accessor: a cached Addon handle can revert settings written
# through another instance. See control._Settings.
from reauthorize.modules.control import accountmgr
your_file_api = accountmgr.getSetting("filepursuit.api.key")

class Auth:
    def file_auth(self):

    #Umbrella (1.4.5, outside audit F04): its scraper and source list read `filepursuittoken`
    #(internal_scrapers/filepursuit.py, modules/sources.py); `filepursuit.api`, which every version up to
    #1.4.4 wrote, is read by nothing, so FilePursuit never reached Umbrella. The old copy is cleared.
    #A blank is written only in a wipe (as meta_sync._go).
        try:
            if xbmcvfs.exists(var.chk_umb) and xbmcvfs.exists(var.chkset_umb): #Check that the addon is installed and settings.xml exists
                addon = xbmcaddon.Addon("plugin.video.umbrella")
                if your_file_api or control.wiping():
                    if addon.getSetting("filepursuittoken") != your_file_api:
                        addon.setSetting("filepursuittoken", your_file_api)
                        addon.setSetting("filepursuit.enable", 'true' if your_file_api else 'false')
                if addon.getSetting("filepursuit.api"):
                    addon.setSetting("filepursuit.api", '')
        except:
            xbmc.log('%s: Umbrella FilePursuit Failed!' % var.amgr, xbmc.LOGINFO)

    #Infinity
        try:
            if xbmcvfs.exists(var.chk_infinity) and xbmcvfs.exists(var.chkset_infinity):

                chk_file = xbmcaddon.Addon('plugin.video.infinity').getSetting("filepursuit.api")
                enable_file = ("true")

                if not str(your_file_api) == str(chk_file) or str(chk_file) == '':
                    addon = xbmcaddon.Addon("plugin.video.infinity")
                    addon.setSetting("filepursuit.enable", enable_file)
                    addon.setSetting("filepursuit.api", your_file_api)
        except:
            xbmc.log('%s: Infinity FilePursuit Failed!' % var.amgr, xbmc.LOGINFO)

    #All Accounts
        try:
            if xbmcvfs.exists(var.chk_allaccounts) and not xbmcvfs.exists(var.allaccounts_ud):
                os.mkdir(var.allaccounts_ud)
                xbmcvfs.copy(os.path.join(var.allaccounts), os.path.join(var.chkset_allaccounts))

            if xbmcvfs.exists(var.chk_allaccounts) and not xbmcvfs.exists(var.chkset_allaccounts):
                xbmcvfs.copy(os.path.join(var.allaccounts), os.path.join(var.chkset_allaccounts))

            if xbmcvfs.exists(var.chk_allaccounts) and xbmcvfs.exists(var.chkset_allaccounts):

                chk_file = xbmcaddon.Addon('script.module.allaccounts').getSetting("filepursuit.api.key")

                if not str(your_file_api) == str(chk_file) or str(chk_file) == '':
                    addon = xbmcaddon.Addon("script.module.allaccounts")
                    addon.setSetting("filepursuit.api.key", your_file_api)
        except:
            xbmc.log('%s: All Accounts FilePursuit Failed!' % var.amgr, xbmc.LOGINFO)

    #My Accounts
        try:
            if xbmcvfs.exists(var.chk_myaccounts) and not xbmcvfs.exists(var.myaccounts_ud):
                os.mkdir(var.myaccounts_ud)
                xbmcvfs.copy(os.path.join(var.myaccounts), os.path.join(var.chkset_myaccounts))

            if xbmcvfs.exists(var.chk_myaccounts) and not xbmcvfs.exists(var.chkset_myaccounts):
                xbmcvfs.copy(os.path.join(var.myaccounts), os.path.join(var.chkset_myaccounts))

            if xbmcvfs.exists(var.chk_myaccounts) and xbmcvfs.exists(var.chkset_myaccounts):

                chk_file = xbmcaddon.Addon('script.module.myaccounts').getSetting("filepursuit.api.key")

                if not str(your_file_api) == str(chk_file) or str(chk_file) == '':
                    addon = xbmcaddon.Addon("script.module.myaccounts")
                    addon.setSetting("filepursuit.api.key", your_file_api)
        except:
            xbmc.log('%s: My Accounts FilePursuit Failed!' % var.amgr, xbmc.LOGINFO)
