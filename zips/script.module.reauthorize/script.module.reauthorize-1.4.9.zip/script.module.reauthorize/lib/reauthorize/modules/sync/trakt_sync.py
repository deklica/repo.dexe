from reauthorize.modules import own_settings  # one read or write of our settings at a time
import xbmc
import xbmcaddon
import xbmcvfs
import os
from libs.common import var
from reauthorize.modules.sync import trakt_select

char_remov = ["'", ",", ")","("]

#Account Manager Trakt

translatePath = xbmcvfs.translatePath
addon_id = xbmcaddon.Addon().getAddonInfo('id')
addon = xbmcaddon.Addon(addon_id)
addoninfo = addon.getAddonInfo
addon_data = translatePath(addon.getAddonInfo('profile'))

# 1.4.5, the user's decision (2026-10-23): no add-on may renew the shared Trakt sign-in on its own, because
# a renewal by one add-on ends the pair for ReAuthorize and every other add-on (the bench, 2026-10-22). The
# add-ons that renew eagerly AND only log a refused renewal (TMDb Helper, GratisRed, TMDb Movies) are given
# this instead of the refresh token: they keep tracking on the real access token, their renewal is refused,
# and ReAuthorize renews for them. Add-ons that sign out on a refused renewal (Umbrella) keep the real one;
# ReAuthorize recovers their newer pair if they renew (auth/trakt.py ensure_alive).
NO_RENEW = 'ReAuthorize-renews-this'


class Auth:
    def trakt_auth(self):
        from reauthorize.modules import pause
        if pause.paused('trakt'):
            xbmc.log('[ReAuthorize Trakt] paused: not sent to the add-ons', xbmc.LOGINFO)
            return
        accountmgr = own_settings.addon()
        your_token = accountmgr.getSetting("trakt.token")
        your_username = accountmgr.getSetting("trakt.username")
        your_refresh = accountmgr.getSetting("trakt.refresh")
        your_expires = accountmgr.getSetting("trakt.expires")
        #Whole seconds. ReAuthorize used to store this as '1791750555.0', and an add-on that reads
        #it with int() (POV's TraktMonitor) raised on the '.0' and reported "Error from Trakt".
        try: your_expires = str(int(float(your_expires)))
        except: pass
        #Every installed add-on gets Trakt. This used to depend on the user picking
        #one primary add-on into trakt_sync_list.json, and a build wipe deleted that
        #file, leaving Trakt pushed nowhere. ReAuthorize now renews the token itself
        #(Trakt.refresh_if_due), so no add-on has to be the only one holding it.
        current = trakt_select.installed_addons()
        if current:
    #Seren
            try:
                if 'Seren' in current: # Check if addon is included in sync list
                    if xbmcvfs.exists(var.chk_seren) and xbmcvfs.exists(var.chkset_seren): #Check that the addon is installed and settings.xml exists.

                        #Get add-on setting to compare
                        chk_seren = xbmcaddon.Addon('plugin.video.seren')
                        chk_auth_seren = chk_seren.getSetting("trakt.auth")
                        # 1.4.5 (outside audit F02): Seren reads its Trakt app key from trakt.clientid /
                        # trakt.secret first (indexers/trakt.py _load_settings) and only then from its code;
                        # Seren 4.x no longer holds the literals the code patch below looks for, so it sent
                        # our token under its own key. The settings are written, and repaired when the token
                        # already matches. The code patch is kept for old Seren and may fail on its own.
                        seren_key_ok = chk_seren.getSetting("trakt.clientid") == var.client_am
                        if not str(your_token) == str(chk_auth_seren) or str(chk_auth_seren) == '' or not seren_key_ok: #Compare Account Mananger token to Add-on token. If they match, authorization is skipped

                            try:
                                with open(var.path_seren,'r') as f:
                                    data = f.read()
                                client = data.replace(var.seren_client,var.client_am).replace(var.seren_secret,var.secret_am)
                                if client != data:
                                    with open(var.path_seren,'w') as f:
                                        f.write(client)
                            except Exception as e:
                                xbmc.log('%s: Seren key file not patched (%s); its settings carry the key' % (var.amgr, e), xbmc.LOGINFO)

                            #Write data to settings.xml
                            addon = xbmcaddon.Addon("plugin.video.seren")
                            addon.setSetting("trakt.clientid", var.client_am)
                            addon.setSetting("trakt.secret", var.secret_am)
                            addon.setSetting("trakt.auth", your_token)
                            addon.setSetting("trakt.username", your_username)
                            addon.setSetting("trakt.refresh", your_refresh)

                            your_expires_float = float(your_expires)
                            your_expires_rnd = int(your_expires_float)
                            your_expires_str = str(your_expires_rnd)
                            addon.setSetting("trakt.expires", your_expires_str)
            except:
                xbmc.log('%s: Seren Trakt Failed!' % var.amgr, xbmc.LOGINFO)
    #Coalition
            try:
                if 'The Coalition' in current:
                    if xbmcvfs.exists(var.chk_coal) and xbmcvfs.exists(var.chkset_coal):
                        chk_auth_coal = xbmcaddon.Addon('plugin.video.coalition').getSetting("trakt.token")
                        if not str(your_token) == str(chk_auth_coal) or str(chk_auth_coal) == '':

                            with open(var.path_coal,'r') as f:
                                data = f.read()

                            client = data.replace(var.coal_client,var.client_am).replace(var.coal_secret,var.secret_am)

                            with open(var.path_coal,'w') as f:
                                f.write(client)

                            addon = xbmcaddon.Addon("plugin.video.coalition")
                            addon.setSetting("trakt.token", your_token)
                            addon.setSetting("trakt_user", your_username)
                            addon.setSetting("trakt.refresh", your_refresh)
                            addon.setSetting("trakt.expires", your_expires)
                            addon.setSetting("trakt.indicators_active", 'true')
            except:
                xbmc.log('%s: Coalition Trakt Failed!' % var.amgr, xbmc.LOGINFO)

    #POV
            try:
                if 'POV' in current:
                    if xbmcvfs.exists(var.chk_pov) and xbmcvfs.exists(var.chkset_pov):
                        chk_auth_pov = xbmcaddon.Addon('plugin.video.pov').getSetting("trakt.token")
                        #also when only the expiry differs: a POV still holding the old '...0' form is repaired
                        chk_expires_pov = xbmcaddon.Addon('plugin.video.pov').getSetting("trakt.expires")
                        if not str(your_token) == str(chk_auth_pov) or str(chk_auth_pov) == '' or str(chk_expires_pov) != str(your_expires):

                            addon = xbmcaddon.Addon("plugin.video.pov")
                            addon.setSetting("trakt.client_id", var.client_am)
                            addon.setSetting("trakt.client_secret", var.secret_am)
                            addon.setSetting("trakt.token", your_token)
                            addon.setSetting("trakt_user", your_username)
                            addon.setSetting("trakt.refresh", your_refresh)
                            addon.setSetting("trakt.expires", your_expires)
                            addon.setSetting("trakt_indicators_active", 'true')
            except:
                xbmc.log('%s: POV Trakt Failed!' % var.amgr, xbmc.LOGINFO)

    #Umbrella
            try:
                if 'Umbrella' in current:
                    if xbmcvfs.exists(var.chk_umb) and xbmcvfs.exists(var.chkset_umb):
                        chk_umb = xbmcaddon.Addon('plugin.video.umbrella')
                        chk_auth_umb = chk_umb.getSetting("trakt.user.token")
                        # 1.4.5 (outside audit F08): Umbrella's own sign-in also sets trakt.isauthed (it shows
                        # its Trakt sync options) and trakt.authed.clientid, the app that issued the token; its
                        # renewal signs out a token whose authed.clientid differs from its client id. Both are
                        # repaired on boxes that already hold our token.
                        umb_state_ok = (chk_umb.getSetting("trakt.isauthed") == 'true' and
                                        chk_umb.getSetting("trakt.authed.clientid") == var.client_am)
                        if not str(your_token) == str(chk_auth_umb) or str(chk_auth_umb) == '' or not umb_state_ok:

                            addon = xbmcaddon.Addon("plugin.video.umbrella")
                            addon.setSetting("trakt.isauthed", 'true')
                            addon.setSetting("trakt.authed.clientid", var.client_am)
                            addon.setSetting("trakt.user.name", your_username)
                            addon.setSetting("trakt.user.token", your_token)
                            addon.setSetting("trakt.refreshtoken", your_refresh)
                            addon.setSetting("trakt.token.expires", your_expires)
                            addon.setSetting("traktuserkey.customenabled", 'true')
                            addon.setSetting("trakt.clientid", var.client_am)
                            addon.setSetting("trakt.clientsecret", var.secret_am)
                            addon.setSetting("trakt.scrobble", 'true')
                            addon.setSetting("resume.source", '1')
            except:
                xbmc.log('%s: Umbrella Trakt Failed!' % var.amgr, xbmc.LOGINFO)

    #Infinity
            try:
                if 'Infinity' in current:
                    if xbmcvfs.exists(var.chk_infinity) and xbmcvfs.exists(var.chkset_infinity):
                        chk_auth_infinity = xbmcaddon.Addon('plugin.video.infinity').getSetting("trakt.user.token")
                        if not str(your_token) == str(chk_auth_infinity) or str(chk_auth_infinity) == '':

                            addon = xbmcaddon.Addon("plugin.video.infinity")
                            addon.setSetting("trakt.user.name", your_username)
                            addon.setSetting("trakt.user.token", your_token)
                            addon.setSetting("trakt.refreshtoken", your_refresh)
                            addon.setSetting("trakt.token.expires", your_expires)
                            addon.setSetting("traktuserkey.customenabled", 'true')
                            addon.setSetting("trakt.clientid", var.client_am)
                            addon.setSetting("trakt.clientsecret", var.secret_am)
                            addon.setSetting("trakt.scrobble", 'true')
                            addon.setSetting("resume.source", '1')
            except:
                xbmc.log('%s: Infinity Trakt Failed!' % var.amgr, xbmc.LOGINFO)

    #Shadow
            try:
                if 'Shadow' in current:
                    if xbmcvfs.exists(var.chk_shadow) and not xbmcvfs.exists(var.shadow_ud):
                        os.mkdir(var.shadow_ud)
                        xbmcvfs.copy(os.path.join(var.shadow), os.path.join(var.chkset_shadow))

                    if xbmcvfs.exists(var.chk_shadow) and not xbmcvfs.exists(var.chkset_shadow):
                        xbmcvfs.copy(os.path.join(var.shadow), os.path.join(var.chkset_shadow))

                    if xbmcvfs.exists(var.chk_shadow) and xbmcvfs.exists(var.chkset_shadow):
                        chk_auth_shadow = xbmcaddon.Addon('plugin.video.shadow').getSetting("trakt_access_token")
                        if not str(your_token) == str(chk_auth_shadow) or str(chk_auth_shadow) == '':

                            with open(var.path_shadow,'r') as f:
                                data = f.read()

                            client = data.replace(var.shadow_client,var.client_am).replace(var.shadow_secret,var.secret_am)

                            with open(var.path_shadow,'w') as f:
                                f.write(client)

                            addon = xbmcaddon.Addon("plugin.video.shadow")
                            addon.setSetting("trakt_access_token", your_token)
                            addon.setSetting("trakt_refresh_token", your_refresh)
                            addon.setSetting("trakt_expires_at", your_expires)
            except:
                xbmc.log('%s: Shadow Trakt Failed!' % var.amgr, xbmc.LOGINFO)

    #Ghost
            try:
                if 'Ghost' in current:
                    if xbmcvfs.exists(var.chk_ghost) and not xbmcvfs.exists(var.ghost_ud):
                        os.mkdir(var.ghost_ud)
                        xbmcvfs.copy(os.path.join(var.ghost), os.path.join(var.chkset_ghost))

                    if xbmcvfs.exists(var.chk_ghost) and not xbmcvfs.exists(var.chkset_ghost):
                        xbmcvfs.copy(os.path.join(var.ghost), os.path.join(var.chkset_ghost))

                    if xbmcvfs.exists(var.chk_ghost) and xbmcvfs.exists(var.chkset_ghost):
                        chk_auth_ghost = xbmcaddon.Addon('plugin.video.ghost').getSetting("trakt_access_token")
                        if not str(your_token) == str(chk_auth_ghost) or str(chk_auth_ghost) == '':

                            with open(var.path_ghost,'r') as f:
                                data = f.read()

                            client = data.replace(var.ghost_client,var.client_am).replace(var.ghost_secret,var.secret_am)

                            with open(var.path_ghost,'w') as f:
                                f.write(client)

                            addon = xbmcaddon.Addon("plugin.video.ghost")
                            addon.setSetting("trakt_access_token", your_token)
                            addon.setSetting("trakt_refresh_token", your_refresh)
                            addon.setSetting("trakt_expires_at", your_expires)
            except:
                xbmc.log('%s: Ghost Trakt Failed!' % var.amgr, xbmc.LOGINFO)

    #Blue Balls
            try:
                if 'Blue Balls' in current:
                    if xbmcvfs.exists(var.chk_blueballs) and not xbmcvfs.exists(var.blueballs_ud):
                        os.mkdir(var.blueballs_ud)
                        xbmcvfs.copy(os.path.join(var.blueballs), os.path.join(var.chkset_blueballs))

                    if xbmcvfs.exists(var.chk_blueballs) and not xbmcvfs.exists(var.chkset_blueballs):
                        xbmcvfs.copy(os.path.join(var.blueballs), os.path.join(var.chkset_blueballs))

                    if xbmcvfs.exists(var.chk_blueballs) and xbmcvfs.exists(var.chkset_blueballs):
                        chk_auth_blueballs = xbmcaddon.Addon('plugin.video.blueballs').getSetting("trakt_access_token")
                        if not str(your_token) == str(chk_auth_blueballs) or str(chk_auth_blueballs) == '':

                            with open(var.path_blueballs,'r') as f:
                                data = f.read()

                            client = data.replace(var.blueballs_client,var.client_am).replace(var.blueballs_secret,var.secret_am)

                            with open(var.path_blueballs,'w') as f:
                                f.write(client)

                            addon = xbmcaddon.Addon("plugin.video.blueballs")
                            addon.setSetting("trakt_access_token", your_token)
                            addon.setSetting("trakt_refresh_token", your_refresh)
                            addon.setSetting("trakt_expires_at", your_expires)
            except:
                xbmc.log('%s: Blue Balls Trakt Failed!' % var.amgr, xbmc.LOGINFO)

    #Twisted
            try:
                if 'Twisted' in current:
                    if xbmcvfs.exists(var.chk_twisted) and not xbmcvfs.exists(var.twisted_ud):
                        os.mkdir(var.twisted_ud)
                        xbmcvfs.copy(os.path.join(var.twisted), os.path.join(var.chkset_twisted))

                    if xbmcvfs.exists(var.chk_twisted) and not xbmcvfs.exists(var.chkset_twisted):
                        xbmcvfs.copy(os.path.join(var.twisted), os.path.join(var.chkset_twisted))

                    if xbmcvfs.exists(var.chk_twisted) and xbmcvfs.exists(var.chkset_twisted):
                        chk_auth_twisted = xbmcaddon.Addon('plugin.video.twisted').getSetting("trakt_access_token")
                        if not str(your_token) == str(chk_auth_twisted) or str(chk_auth_twisted) == '':

                            with open(var.path_twisted,'r') as f:
                                data = f.read()

                            client = data.replace(var.twisted_client,var.client_am).replace(var.twisted_secret,var.secret_am)

                            with open(var.path_twisted,'w') as f:
                                f.write(client)

                            addon = xbmcaddon.Addon("plugin.video.twisted")
                            addon.setSetting("trakt_access_token", your_token)
                            addon.setSetting("trakt_refresh_token", your_refresh)
                            addon.setSetting("trakt_expires_at", your_expires)
            except:
                xbmc.log('%s: Twisted Trakt Failed!' % var.amgr, xbmc.LOGINFO)

    #Base
            try:
                if 'Base' in current:
                    if xbmcvfs.exists(var.chk_base) and not xbmcvfs.exists(var.base_ud):
                        os.mkdir(var.base_ud)
                        xbmcvfs.copy(os.path.join(var.base), os.path.join(var.chkset_base))

                    if xbmcvfs.exists(var.chk_base) and not xbmcvfs.exists(var.chkset_base):
                        xbmcvfs.copy(os.path.join(var.base), os.path.join(var.chkset_base))

                    if xbmcvfs.exists(var.chk_base) and xbmcvfs.exists(var.chkset_base):
                        chk_auth_base = xbmcaddon.Addon('plugin.video.base').getSetting("trakt_access_token")
                        if not str(your_token) == str(chk_auth_base) or str(chk_auth_base) == '':

                            with open(var.path_base,'r') as f:
                                data = f.read()

                            client = data.replace(var.base_client,var.client_am).replace(var.base_secret,var.secret_am)

                            with open(var.path_base,'w') as f:
                                f.write(client)

                            addon = xbmcaddon.Addon("plugin.video.base")
                            addon.setSetting("trakt_access_token", your_token)
                            addon.setSetting("trakt_refresh_token", your_refresh)
                            addon.setSetting("trakt_expires_at", your_expires)
            except:
                xbmc.log('%s: Base Trakt Failed!' % var.amgr, xbmc.LOGINFO)

    #Chain Reaction
            try:
                if 'Chain Reaction' in current:
                    if xbmcvfs.exists(var.chk_chains) and not xbmcvfs.exists(var.chains_ud):
                        os.mkdir(var.chains_ud)
                        xbmcvfs.copy(os.path.join(var.chains), os.path.join(var.chkset_chains))

                    if xbmcvfs.exists(var.chk_chains) and not xbmcvfs.exists(var.chkset_chains):
                        xbmcvfs.copy(os.path.join(var.chains), os.path.join(var.chkset_chains))

                    if xbmcvfs.exists(var.chk_chains) and xbmcvfs.exists(var.chkset_chains):
                        chk_auth_chains = xbmcaddon.Addon('plugin.video.thechains').getSetting("trakt_access_token")
                        if not str(your_token) == str(chk_auth_chains) or str(chk_auth_chains) == '':

                            with open(var.path_chains,'r') as f:
                                data = f.read()

                            client = data.replace(var.chains_client,var.client_am).replace(var.chains_secret,var.secret_am)

                            with open(var.path_chains,'w') as f:
                                f.write(client)

                            addon = xbmcaddon.Addon("plugin.video.thechains")
                            addon.setSetting("trakt_access_token", your_token)
                            addon.setSetting("trakt_refresh_token", your_refresh)
                            addon.setSetting("trakt_expires_at", your_expires)
            except:
                xbmc.log('%s: Chain Reaction Trakt Failed!' % var.amgr, xbmc.LOGINFO)

    #Patriot
            try:
                if 'Patriot' in current:
                    if xbmcvfs.exists(var.chk_patriot) and not xbmcvfs.exists(var.patriot_ud):
                        os.mkdir(var.patriot_ud)
                        xbmcvfs.copy(os.path.join(var.patriot), os.path.join(var.chkset_patriot))

                    if xbmcvfs.exists(var.chk_patriot) and not xbmcvfs.exists(var.chkset_patriot):
                        xbmcvfs.copy(os.path.join(var.patriot), os.path.join(var.chkset_patriot))

                    if xbmcvfs.exists(var.chk_patriot) and xbmcvfs.exists(var.chkset_patriot):
                        chk_auth_patriot = xbmcaddon.Addon('plugin.video.patriot').getSetting("trakt_access_token")
                        if not str(your_token) == str(chk_auth_patriot) or str(chk_auth_patriot) == '':

                            with open(var.path_patriot,'r') as f:
                                data = f.read()

                            client = data.replace(var.patriot_client,var.client_am).replace(var.patriot_secret,var.secret_am)

                            with open(var.path_patriot,'w') as f:
                                f.write(client)

                            addon = xbmcaddon.Addon("plugin.video.patriot")
                            addon.setSetting("trakt_access_token", your_token)
                            addon.setSetting("trakt_refresh_token", your_refresh)
                            addon.setSetting("trakt_expires_at", your_expires)
            except:
                xbmc.log('%s: Patriot Trakt Failed!' % var.amgr, xbmc.LOGINFO)

    #Black Lightning
            try:
                if 'Black Lightning' in current:
                    if xbmcvfs.exists(var.chk_blackl) and not xbmcvfs.exists(var.blackl_ud):
                        os.mkdir(var.blackl_ud)
                        xbmcvfs.copy(os.path.join(var.blackl), os.path.join(var.chkset_blackl))

                    if xbmcvfs.exists(var.chk_blackl) and not xbmcvfs.exists(var.chkset_blackl):
                        xbmcvfs.copy(os.path.join(var.blackl), os.path.join(var.chkset_blackl))

                    if xbmcvfs.exists(var.chk_blackl) and xbmcvfs.exists(var.chkset_blackl):
                        chk_auth_blackl = xbmcaddon.Addon('plugin.video.blacklightning').getSetting("trakt_access_token")
                        if not str(your_token) == str(chk_auth_blackl) or str(chk_auth_blackl) == '':

                            with open(var.path_blackl,'r') as f:
                                data = f.read()

                            client = data.replace(var.blackl_client,var.client_am).replace(var.blackl_secret,var.secret_am)

                            with open(var.path_blackl,'w') as f:
                                f.write(client)

                            addon = xbmcaddon.Addon("plugin.video.blacklightning")
                            addon.setSetting("trakt_access_token", your_token)
                            addon.setSetting("trakt_refresh_token", your_refresh)
                            addon.setSetting("trakt_expires_at", your_expires)
            except:
                xbmc.log('%s: Black Lightning Trakt Failed!' % var.amgr, xbmc.LOGINFO)

    #Homelander
            try:
                if 'Homelander' in current:
                    if xbmcvfs.exists(var.chk_home) and not xbmcvfs.exists(var.home_ud):
                        os.mkdir(var.home_ud)
                        xbmcvfs.copy(os.path.join(var.home), os.path.join(var.chkset_home))

                    if xbmcvfs.exists(var.chk_home) and not xbmcvfs.exists(var.chkset_home):
                        xbmcvfs.copy(os.path.join(var.home), os.path.join(var.chkset_home))

                    if xbmcvfs.exists(var.chk_home) and xbmcvfs.exists(var.chkset_home):
                        chk_auth_home = xbmcaddon.Addon('plugin.video.homelander').getSetting("trakt.token")
                        if not str(your_token) == str(chk_auth_home) or str(chk_auth_home) == '':

                            addon = xbmcaddon.Addon("plugin.video.homelander")
                            addon.setSetting("trakt.user", your_username)
                            addon.setSetting("trakt.token", your_token)
                            addon.setSetting("trakt.refresh", your_refresh)
                            addon.setSetting("trakt.authed", 'yes')
                            addon.setSetting("trakt.client_id", var.client_am)
                            addon.setSetting("trakt.client_secret", var.secret_am)
            except:
                xbmc.log('%s: Homelander Trakt Failed!' % var.amgr, xbmc.LOGINFO)

    #Quicksilver
            try:
                if 'Quicksilver' in current:
                    if xbmcvfs.exists(var.chk_quick) and not xbmcvfs.exists(var.quick_ud):
                        os.mkdir(var.quick_ud)
                        xbmcvfs.copy(os.path.join(var.quick), os.path.join(var.chkset_quick))

                    if xbmcvfs.exists(var.chk_quick) and not xbmcvfs.exists(var.chkset_quick):
                        xbmcvfs.copy(os.path.join(var.quick), os.path.join(var.chkset_quick))

                    if xbmcvfs.exists(var.chk_quick) and xbmcvfs.exists(var.chkset_quick):
                        chk_auth_quick = xbmcaddon.Addon('plugin.video.quicksilver').getSetting("trakt.token")
                        if not str(your_token) == str(chk_auth_quick) or str(chk_auth_quick) == '':

                            addon = xbmcaddon.Addon("plugin.video.quicksilver")
                            addon.setSetting("trakt.user", your_username)
                            addon.setSetting("trakt.token", your_token)
                            addon.setSetting("trakt.refresh", your_refresh)
                            addon.setSetting("trakt.authed", 'yes')
                            addon.setSetting("trakt.client_id", var.client_am)
                            addon.setSetting("trakt.client_secret", var.secret_am)
            except:
                xbmc.log('%s: Quicksilver Trakt Failed!' % var.amgr, xbmc.LOGINFO)

    #Chains Genocide
            try:
                if 'Chains Genocide' in current:
                    if xbmcvfs.exists(var.chk_genocide) and not xbmcvfs.exists(var.genocide_ud):
                        os.mkdir(var.genocide_ud)
                        xbmcvfs.copy(os.path.join(var.genocide), os.path.join(var.chkset_genocide))

                    if xbmcvfs.exists(var.chk_genocide) and not xbmcvfs.exists(var.chkset_genocide):
                        xbmcvfs.copy(os.path.join(var.genocide), os.path.join(var.chkset_genocide))

                    if xbmcvfs.exists(var.chk_genocide) and xbmcvfs.exists(var.chkset_genocide):
                        chk_auth_genocide = xbmcaddon.Addon('plugin.video.chainsgenocide').getSetting("trakt.token")
                        if not str(your_token) == str(chk_auth_genocide) or str(chk_auth_genocide) == '':

                            with open(var.path_genocide,'r') as f:
                                data = f.read()

                            client = data.replace(var.genocide_client,var.client_am).replace(var.genocide_secret,var.secret_am)

                            with open(var.path_genocide,'w') as f:
                                f.write(client)

                            addon = xbmcaddon.Addon("plugin.video.chainsgenocide")
                            addon.setSetting("trakt.username", your_username)
                            addon.setSetting("trakt.token", your_token)
                            addon.setSetting("trakt.refresh", your_refresh)
                            addon.setSetting("trakt.isauthed", 'true')
            except:
                xbmc.log('%s: Chains Genocide Trakt Failed!' % var.amgr, xbmc.LOGINFO)

    #Absolution
            try:
                if 'Absolution' in current:
                    if xbmcvfs.exists(var.chk_absol) and not xbmcvfs.exists(var.absol_ud):
                        os.mkdir(var.absol_ud)
                        xbmcvfs.copy(os.path.join(var.absol), os.path.join(var.chkset_absol))

                    if xbmcvfs.exists(var.chk_absol) and not xbmcvfs.exists(var.chkset_absol):
                        xbmcvfs.copy(os.path.join(var.absol), os.path.join(var.chkset_absol))

                    if xbmcvfs.exists(var.chk_absol) and xbmcvfs.exists(var.chkset_absol):
                        chk_auth_absol = xbmcaddon.Addon('plugin.video.absolution').getSetting("trakt.token")
                        if not str(your_token) == str(chk_auth_absol) or str(chk_auth_absol) == '':

                            addon = xbmcaddon.Addon("plugin.video.absolution")
                            addon.setSetting("trakt.user", your_username)
                            addon.setSetting("trakt.token", your_token)
                            addon.setSetting("trakt.refresh", your_refresh)
                            addon.setSetting("trakt.authed", 'yes')
                            addon.setSetting("trakt.client_id", var.client_am)
                            addon.setSetting("trakt.client_secret", var.secret_am)
            except:
                xbmc.log('%s: Absolution Trakt Failed!' % var.amgr, xbmc.LOGINFO)

    #Shazam
            try:
                if 'Shazam' in current:
                    if xbmcvfs.exists(var.chk_shazam) and not xbmcvfs.exists(var.shazam_ud):
                        os.mkdir(var.shazam_ud)
                        xbmcvfs.copy(os.path.join(var.shazam), os.path.join(var.chkset_shazam))

                    if xbmcvfs.exists(var.chk_shazam) and not xbmcvfs.exists(var.chkset_shazam):
                        xbmcvfs.copy(os.path.join(var.shazam), os.path.join(var.chkset_shazam))

                    if xbmcvfs.exists(var.chk_shazam) and xbmcvfs.exists(var.chkset_shazam):
                        chk_auth_shazam = xbmcaddon.Addon('plugin.video.shazam').getSetting("trakt.token")
                        if not str(your_token) == str(chk_auth_shazam) or str(chk_auth_shazam) == '':

                            addon = xbmcaddon.Addon("plugin.video.shazam")
                            addon.setSetting("trakt.user", your_username)
                            addon.setSetting("trakt.token", your_token)
                            addon.setSetting("trakt.refresh", your_refresh)
                            addon.setSetting("trakt.authed", 'yes')
                            addon.setSetting("trakt.client_id", var.client_am)
                            addon.setSetting("trakt.client_secret", var.secret_am)
            except:
                xbmc.log('%s: Shazam Trakt Failed!' % var.amgr, xbmc.LOGINFO)

    #The Crew
            try:
                if 'The Crew' in current:
                    if xbmcvfs.exists(var.chk_crew) and not xbmcvfs.exists(var.crew_ud):
                        os.mkdir(var.crew_ud)
                        xbmcvfs.copy(os.path.join(var.crew), os.path.join(var.chkset_crew))

                    if xbmcvfs.exists(var.chk_crew) and not xbmcvfs.exists(var.chkset_crew):
                        xbmcvfs.copy(os.path.join(var.crew), os.path.join(var.chkset_crew))

                    if xbmcvfs.exists(var.chk_crew) and xbmcvfs.exists(var.chkset_crew):
                        # Crew 3.x keeps its key in keys.py, deletes a sign-in while trakt.revoked is
                        # true, and wants trakt.expires_at: see sync/crew_trakt.py (1.3.8).
                        from reauthorize.modules.sync import crew_trakt
                        crew_trakt.link(your_username, your_token, your_refresh, your_expires)
            except:
                xbmc.log('%s: The Crew Trakt Failed!' % var.amgr, xbmc.LOGINFO)

    #Nightwing (plugin.video.nightwing, 1.4.0): Moria's code base, same settings and signed-in rule
            try:
                if 'Nightwing' in current:

                    if xbmcvfs.exists(var.chk_nightwing) and xbmcvfs.exists(var.chkset_nightwing):
                        chk_auth_nightwing = xbmcaddon.Addon('plugin.video.nightwing').getSetting("trakt.token")
                        if not str(your_token) == str(chk_auth_nightwing) or str(chk_auth_nightwing) == '':

                            addon = xbmcaddon.Addon("plugin.video.nightwing")
                            addon.setSetting("trakt.user", your_username)
                            addon.setSetting("trakt.token", your_token)
                            addon.setSetting("trakt.refresh", your_refresh)
                            addon.setSetting("trakt.authed", 'yes')
                            addon.setSetting("trakt.client_id", var.client_am)
                            addon.setSetting("trakt.client_secret", var.secret_am)
            except:
                xbmc.log('%s: Nightwing Trakt Failed!' % var.amgr, xbmc.LOGINFO)

    #Scrubs V2
            try:
                if 'Scrubs V2' in current:
                    if xbmcvfs.exists(var.chk_scrubs) and not xbmcvfs.exists(var.scrubs_ud):
                        os.mkdir(var.scrubs_ud)
                        xbmcvfs.copy(os.path.join(var.scrubs), os.path.join(var.chkset_scrubs))

                    if xbmcvfs.exists(var.chk_scrubs) and not xbmcvfs.exists(var.chkset_scrubs):
                        xbmcvfs.copy(os.path.join(var.scrubs), os.path.join(var.chkset_scrubs))

                    if xbmcvfs.exists(var.chk_scrubs) and xbmcvfs.exists(var.chkset_scrubs):
                        chk_auth_scrubs = xbmcaddon.Addon('plugin.video.scrubsv2').getSetting("trakt.token")
                        if not str(your_token) == str(chk_auth_scrubs) or str(chk_auth_scrubs) == '':

                            with open(var.path_scrubs,'r') as f:
                                data = f.read()

                            client = data.replace(var.scrubs_client,var.client_am).replace(var.scrubs_secret,var.secret_am)

                            with open(var.path_scrubs,'w') as f:
                                f.write(client)

                            addon = xbmcaddon.Addon("plugin.video.scrubsv2")
                            addon.setSetting("trakt.user", your_username)
                            addon.setSetting("trakt.token", your_token)
                            addon.setSetting("trakt.refresh", your_refresh)
                            addon.setSetting("trakt.authed", 'yes')
            except:
                xbmc.log('%s: Scrubs V2 Trakt Failed!' % var.amgr, xbmc.LOGINFO)

    #TMDB Helper
            try:
                if 'TMDb Helper' in current:
                    if xbmcvfs.exists(var.chk_tmdbh) and not xbmcvfs.exists(var.tmdbh_ud):
                        os.mkdir(var.tmdbh_ud)
                        xbmcvfs.copy(os.path.join(var.tmdbh), os.path.join(var.chkset_tmdbh))

                    if xbmcvfs.exists(var.chk_tmdbh) and not xbmcvfs.exists(var.chkset_tmdbh):
                        xbmcvfs.copy(os.path.join(var.tmdbh), os.path.join(var.chkset_tmdbh))

                    if xbmcvfs.exists(var.chk_tmdbh) and xbmcvfs.exists(var.chkset_tmdbh):

                        chk_auth_tmdbh = xbmcaddon.Addon('plugin.video.themoviedb.helper').getSetting("trakt_token")

                        if str(your_token) in str(chk_auth_tmdbh) and NO_RENEW in str(chk_auth_tmdbh):
                            pass

                        else:
                            # 6.21 has no such file (its Trakt is a separate add-on, block below)
                            if os.path.isfile(var.path_tmdbh):
                                with open(var.path_tmdbh,'r') as f:
                                    data = f.read()

                                client = data.replace(var.tmdbh_client,var.client_am).replace(var.tmdbh_secret,var.secret_am)

                                with open(var.path_tmdbh,'w') as f:
                                    f.write(client)

                            addon = xbmcaddon.Addon("plugin.video.themoviedb.helper")
                            your_expires_float = float(your_expires)
                            your_expires_rnd = int(your_expires_float)
                            token = '{"access_token":"'
                            refresh = '","token_type":"bearer","expires_in":7776000,"refresh_token":"'
                            expires = '","scope":"public","created_at":'
                            # NO_RENEW, not the real refresh token: it renews on any failed start-up check
                            # (even a 429) and that renewal ends the pair for every other add-on (1.4.5)
                            tmdbh_data = '%s%s%s%s%s%s}' %(token, your_token, refresh, NO_RENEW, expires, your_expires_rnd)
                            addon.setSettingString("trakt_token", tmdbh_data)
                            addon.setSetting("startup_notifications", 'false')
            except:
                xbmc.log('%s: TMDBh Trakt Failed!' % var.amgr, xbmc.LOGINFO)

    #TMDb Helper 6.21+: Trakt is its own add-on, script.module.tmdbhelper.sync.trakt (sync/tmdbh_trakt.py)
            try:
                if 'TMDb Helper' in current:
                    from reauthorize.modules.sync import tmdbh_trakt
                    if tmdbh_trakt.installed() and tmdbh_trakt.link(your_token, your_expires, NO_RENEW):
                        xbmc.log('[ReAuthorize Trakt] sign-in sent to TMDb Helper Trakt', xbmc.LOGINFO)
            except Exception as e:
                xbmc.log('%s: TMDb Helper Trakt provider Failed! %s' % (var.amgr, e), xbmc.LOGINFO)

    #Trakt Addon
            try:
                if 'Trakt Addon' in current:
                    if xbmcvfs.exists(var.chk_trakt) and not xbmcvfs.exists(var.trakt_ud):
                        os.mkdir(var.trakt_ud)
                        xbmcvfs.copy(os.path.join(var.trakt), os.path.join(var.chkset_trakt))

                    if xbmcvfs.exists(var.chk_trakt) and not xbmcvfs.exists(var.chkset_trakt):
                        xbmcvfs.copy(os.path.join(var.trakt), os.path.join(var.chkset_trakt))

                    if xbmcvfs.exists(var.chk_trakt) and xbmcvfs.exists(var.chkset_trakt):

                        chk_auth_trakt = xbmcaddon.Addon('script.trakt').getSetting("trakt_token")

                        if str(your_token) in str(chk_auth_trakt):
                            pass

                        else:
                            # 3.9.0 keeps its key as a list of numbers: swap the lines (traktaddon_key.py)
                            from reauthorize.modules.sync import traktaddon_key
                            with open(var.path_trakt,'r') as f:
                                data = f.read()

                            client = traktaddon_key.swap_key(data, var.client_am, var.secret_am)

                            with open(var.path_trakt,'w') as f:
                                f.write(client)

                            addon = xbmcaddon.Addon("script.trakt")
                            addon.setSetting("user", your_username)
                            your_expires_float = float(your_expires)
                            your_expires_rnd = int(your_expires_float)
                            token = '{"access_token": "'
                            refresh = '","token_type": "bearer", "expires_in": 7776000, "refresh_token": "'
                            expires = '", "scope": "public", "created_at": '
                            trakt_data = '%s%s%s%s%s%s}' %(token, your_token, refresh, your_refresh, expires, your_expires_rnd)
                            addon.setSetting("authorization", trakt_data)
            except:
                xbmc.log('%s: Trakt Addon Trakt Failed!' % var.amgr, xbmc.LOGINFO)

    #All Accounts
            try:
                if 'All Accounts' in current:
                    if xbmcvfs.exists(var.chk_allaccounts) and not xbmcvfs.exists(var.allaccounts_ud):
                        os.mkdir(var.allaccounts_ud)
                        xbmcvfs.copy(os.path.join(var.allaccounts), os.path.join(var.chkset_allaccounts))

                    if xbmcvfs.exists(var.chk_allaccounts) and not xbmcvfs.exists(var.chkset_allaccounts):
                        xbmcvfs.copy(os.path.join(var.allaccounts), os.path.join(var.chkset_allaccounts))

                    if xbmcvfs.exists(var.chk_allaccounts) and xbmcvfs.exists(var.chkset_allaccounts):
                        chk_auth_allaccounts = xbmcaddon.Addon('script.module.allaccounts').getSetting("trakt.token")
                        if not str(your_token) == str(chk_auth_allaccounts) or str(chk_auth_allaccounts) == '':

                            with open(var.path_allaccounts,'r') as f:
                                data = f.read()

                            client = data.replace(var.allacts_client,var.client_am).replace(var.allacts_secret,var.secret_am)

                            with open(var.path_allaccounts,'w') as f:
                                f.write(client)

                            addon = xbmcaddon.Addon("script.module.allaccounts")
                            addon.setSetting("trakt.token", your_token)
                            addon.setSetting("trakt.username", your_username)
                            addon.setSetting("trakt.refresh", your_refresh)
                            addon.setSetting("trakt.expires", your_expires)
            except:
                xbmc.log('%s: All Accounts Trakt Failed!' % var.amgr, xbmc.LOGINFO)

    #My Accounts
            try:
                if 'My Accounts' in current:
                    if xbmcvfs.exists(var.chk_myaccounts) and not xbmcvfs.exists(var.myaccounts_ud):
                        os.mkdir(var.myaccounts_ud)
                        xbmcvfs.copy(os.path.join(var.myaccounts), os.path.join(var.chkset_myaccounts))

                    if xbmcvfs.exists(var.chk_myaccounts) and not xbmcvfs.exists(var.chkset_myaccounts):
                        xbmcvfs.copy(os.path.join(var.myaccounts), os.path.join(var.chkset_myaccounts))

                    if xbmcvfs.exists(var.chk_myaccounts) and xbmcvfs.exists(var.chkset_myaccounts):
                        chk_auth_myaccounts = xbmcaddon.Addon('script.module.myaccounts').getSetting("trakt.token")
                        if not str(your_token) == str(chk_auth_myaccounts) or str(chk_auth_myaccounts) == '':

                            with open(var.path_myaccounts,'r') as f:
                                data = f.read()

                            client = data.replace(var.myacts_client,var.client_am).replace(var.myacts_secret,var.secret_am)

                            with open(var.path_myaccounts,'w') as f:
                                f.write(client)

                            addon = xbmcaddon.Addon("script.module.myaccounts")
                            addon.setSetting("trakt.token", your_token)
                            addon.setSetting("trakt.username", your_username)
                            addon.setSetting("trakt.refresh", your_refresh)
                            addon.setSetting("trakt.expires", your_expires)
            except:
                xbmc.log('%s: My Accounts Trakt Failed!' % var.amgr, xbmc.LOGINFO)

    #Mad Titan Sports (plugin.video.madtitansports, 1.4.0). Takes the Trakt key from its settings (its own
    #code has none) and counts as signed in when trakt.user_id is set. It puts that id in its URLs
    #(/users/<id>/...), and ReAuthorize's username can hold spaces, so it gets 'me', Trakt's name for the
    #signed-in user (checked live 2026-10-09: watchlist, collection, lists, watched all 200). It never renews
    #by itself; ReAuthorize re-sends after every renewal. trakt_wipe blanks trakt.user_id with the token.
            try:
                if 'Mad Titan Sports' in current:
                    if xbmcvfs.exists(var.chk_madtitan) and xbmcvfs.exists(var.chkset_madtitan):
                        chk_auth_madtitan = xbmcaddon.Addon('plugin.video.madtitansports').getSetting("trakt.access_token")
                        if not str(your_token) == str(chk_auth_madtitan) or str(chk_auth_madtitan) == '':
                            addon = xbmcaddon.Addon("plugin.video.madtitansports")
                            addon.setSetting("trakt.client_id", var.client_am)
                            addon.setSetting("trakt.client_secret", var.secret_am)
                            addon.setSetting("trakt.access_token", your_token)
                            addon.setSetting("trakt.refresh_token", your_refresh)
                            addon.setSetting("trakt.user_id", 'me' if your_token else '')
            except:
                xbmc.log('%s: Mad Titan Sports Trakt Failed!' % var.amgr, xbmc.LOGINFO)

    #Gears
            try:
                if 'Gears' in current:
                    if xbmcvfs.exists(var.chk_gears_video) and xbmcvfs.exists(var.chkset_gears):

                        from reauthorize.modules.db import trakt_db
                        conn = trakt_db.create_conn(var.gears_settings_db)

                        with conn:
                            cursor = conn.cursor()
                            cursor.execute('''SELECT setting_value FROM settings WHERE setting_id = ?''', ('trakt.token',))
                            auth_trakt = cursor.fetchone()
                            chk_auth_gears = str(auth_trakt)
                            cursor.close()

                            for char in char_remov:
                                chk_auth_gears = chk_auth_gears.replace(char, "")

                            cursor = conn.cursor()
                            cursor.execute('''SELECT setting_value FROM settings WHERE setting_id = ?''', ('trakt.refresh',))
                            gears_refresh = cursor.fetchone()
                            cursor.close()

                            new_token = not str(your_token) == chk_auth_gears
                            #trakt_db.NO_RENEW (1.4.8): Gears must never hold the real refresh token
                            if new_token or not gears_refresh or gears_refresh[0] != trakt_db.NO_RENEW:

                                trakt_db.auth_gears_trakt()
                                if new_token:
                                    xbmcvfs.delete(var.gears_trakt_db)
                                var.remake_settings()
            except:
                xbmc.log('%s: Gears Trakt Failed!' % var.amgr, xbmc.LOGINFO)

    #Genocide (plugin.video.genocide)
            try:
                if 'Genocide' in current:
                    if xbmcvfs.exists(var.chk_newgenocide) and xbmcvfs.exists(var.chkset_newgenocide):
                            # Its Trakt key is hard-coded in resources/lib/indexers/trakt.py and the trakt.client_id
                            # settings below are never read, so without this swap it sent our token under its own
                            # key: 401 on every call, invalid_grant on every refresh, and a prompt to authorize.
                            # Optional, like TMDb Movies: a missing or moved file must not stop the settings write.
                        try:
                            with open(var.path_newgenocide, 'r') as f:
                                data = f.read()
                            if var.chk_api not in data:
                                with open(var.path_newgenocide, 'w') as f:
                                    f.write(data.replace(var.genocide_client, var.client_am).replace(var.genocide_secret, var.secret_am))
                        except Exception:
                            xbmc.log('%s: Genocide Trakt key file not patched' % var.amgr, xbmc.LOGINFO)
                        chk_auth_newgenocide = xbmcaddon.Addon('plugin.video.genocide').getSetting("trakt.token")
                        if not str(your_token) == str(chk_auth_newgenocide) or str(chk_auth_newgenocide) == '':
                            addon = xbmcaddon.Addon("plugin.video.genocide")
                            addon.setSetting("trakt.token", your_token)
                            addon.setSetting("trakt.username", your_username)
                            addon.setSetting("trakt.refresh", your_refresh)
                            addon.setSetting("trakt.expires", your_expires)
                            addon.setSetting("trakt.isauthed", 'true')
                            addon.setSetting("trakt.client_id", var.client_am)
                            addon.setSetting("trakt.client_secret", var.secret_am)
            except:
                xbmc.log('%s: Genocide Trakt Failed!' % var.amgr, xbmc.LOGINFO)

    #Aliunde K19
            try:
                if 'Aliunde K19' in current:
                    if xbmcvfs.exists(var.chk_aliunde) and not xbmcvfs.exists(var.aliunde_ud):
                        os.mkdir(var.aliunde_ud)
                        xbmcvfs.copy(os.path.join(var.aliunde), os.path.join(var.chkset_aliunde))

                    if xbmcvfs.exists(var.chk_aliunde) and not xbmcvfs.exists(var.chkset_aliunde):
                        xbmcvfs.copy(os.path.join(var.aliunde), os.path.join(var.chkset_aliunde))

                    if xbmcvfs.exists(var.chk_aliunde) and xbmcvfs.exists(var.chkset_aliunde):
                        chk_auth_aliunde = xbmcaddon.Addon('plugin.video.aliundek19').getSetting("trakt_access_token")
                        if not str(your_token) == str(chk_auth_aliunde) or str(chk_auth_aliunde) == '':

                            with open(var.path_aliunde,'r') as f:
                                data = f.read()

                            client = data.replace(var.aliunde_client,var.client_am).replace(var.aliunde_secret,var.secret_am)

                            with open(var.path_aliunde,'w') as f:
                                f.write(client)

                            addon = xbmcaddon.Addon("plugin.video.aliundek19")
                            addon.setSetting("trakt_access_token", your_token)
                            addon.setSetting("trakt_refresh_token", your_refresh)
                            addon.setSetting("trakt_expires_at", your_expires)
                            addon.setSetting("trakt_client_id", var.client_am)
                            addon.setSetting("trakt_client_secret", var.secret_am)
            except:
                xbmc.log('%s: Aliunde K19 Trakt Failed!' % var.amgr, xbmc.LOGINFO)

    #GratisRed
            try:
                if 'GratisRed' in current:
                    if xbmcvfs.exists(var.chk_gratisred) and xbmcvfs.exists(var.chkset_gratisred):
                        chk_auth_gratisred = xbmcaddon.Addon('plugin.video.gratisred').getSetting("trakt.token")
                        gratisred_renews = xbmcaddon.Addon('plugin.video.gratisred').getSetting("trakt.refresh") != NO_RENEW
                        if not str(your_token) == str(chk_auth_gratisred) or str(chk_auth_gratisred) == '' or gratisred_renews:

                            #Insert Account Manager API keys, so GratisRed presents to
                            #Trakt as the same Community App as every other addon
                            with open(var.path_gratisred,'r') as f:
                                data = f.read()

                            client = data.replace(var.gratisred_client,var.client_am).replace(var.gratisred_secret,var.secret_am)

                            with open(var.path_gratisred,'w') as f:
                                f.write(client)

                            addon = xbmcaddon.Addon("plugin.video.gratisred")
                            #GratisRed treats itself as signed out unless user, token
                            #and refresh are ALL set (getTraktCredentialsInfo), so
                            #without trakt.user the token was always ignored.
                            addon.setSetting("trakt.user", your_username)
                            addon.setSetting("trakt.token", your_token)
                            #NO_RENEW (1.4.5): it renews on ANY 401/403/405, which ends the pair for every
                            #other add-on; a refused renewal is only logged there. It still needs a value.
                            addon.setSetting("trakt.refresh", NO_RENEW)
                            #'yes' is what GratisRed's own sign-in writes.
                            addon.setSetting("trakt.authed", 'yes')
                            #GratisRed 2.0.4 reads its Trakt app key from these two
                            #settings BEFORE the lines in its file, at every call
                            #(_trakt_app_keys). An update of GratisRed puts its own
                            #lines back, and until they were swapped again (and Kodi
                            #restarted) it called Trakt under its own key with our
                            #sign-in, was refused, and showed an error (1.4.2).
                            if "trakt.client_id" in data:
                                addon.setSetting("trakt.client_id", var.client_am)
                                addon.setSetting("trakt.client_secret", var.secret_am)
                            #No trakt.expires on purpose: GratisRed only refreshes
                            #when it has one, and every addon that refreshes on its
                            #own spends the refresh token the others share.
            except:
                xbmc.log('%s: GratisRed Trakt Failed!' % var.amgr, xbmc.LOGINFO)

    #Orion
            try:
                if 'Orion' in current:
                    if xbmcvfs.exists(var.chk_orion) and xbmcvfs.exists(var.chkset_orion):
                        chk_auth_orion = xbmcaddon.Addon('plugin.video.orion').getSetting("trakt_token")
                        if not str(your_token) == str(chk_auth_orion) or str(chk_auth_orion) == '':
                            addon = xbmcaddon.Addon("plugin.video.orion")
                            addon.setSetting("trakt_token", your_token)
                            addon.setSetting("trakt_refresh", your_refresh)
                            addon.setSetting("trakt_enabled", 'true')
            except:
                xbmc.log('%s: Orion Trakt Failed!' % var.amgr, xbmc.LOGINFO)

    #Red Light
    #trakt.user is what Red Light checks to count itself signed in. trakt.expires
    #is required, unlike GratisRed: Red Light refreshes whenever now > expires, and
    #its default is '0', so leaving it out would spend the shared refresh token on
    #the very first call. trakt.client/secret are honoured from settings, so no
    #source patching.
            try:
                if 'Red Light' in current:
                    from reauthorize.modules.db import redlight_db
                    redlight_db.push([('trakt.token', your_token),
                                      ('trakt.refresh', your_refresh),
                                      ('trakt.expires', your_expires),
                                      ('trakt.user', your_username),
                                      ('trakt.client', var.client_am),
                                      ('trakt.secret', var.secret_am)])
            except:
                xbmc.log('%s: Red Light Trakt Failed!' % var.amgr, xbmc.LOGINFO)

    #Cosmos
            try:
                if 'Cosmos' in current:
                    if xbmcvfs.exists(var.chk_cosmos) and xbmcvfs.exists(var.chkset_cosmos):
                        chk_auth_cosmos = xbmcaddon.Addon('plugin.video.cosmos').getSetting("trakt_access_token")
                        if not str(your_token) == str(chk_auth_cosmos) or str(chk_auth_cosmos) == '':
                            addon = xbmcaddon.Addon("plugin.video.cosmos")
                            addon.setSetting("trakt_access_token", your_token)
                            addon.setSetting("trakt_refresh_token", your_refresh)
                            addon.setSetting("trakt_expires_in", '')
                            addon.setSetting("trakt_created_at", '')
                            addon.setSetting("trakt_username", your_username)
                            addon.setSetting("trakt_client_id", var.client_am)
                            addon.setSetting("trakt_client_secret", var.secret_am)
                            addon.setSetting("trakt_auth_done", 'true')
            except:
                xbmc.log('%s: Cosmos Trakt Failed!' % var.amgr, xbmc.LOGINFO)

    #The Archives
            try:
                if 'The Archives' in current:
                    if xbmcvfs.exists(var.chk_thearchives) and xbmcvfs.exists(var.chkset_thearchives):
                        chk_auth_thearchives = xbmcaddon.Addon('plugin.video.thearchives').getSetting("trakt.access_token")
                        if not str(your_token) == str(chk_auth_thearchives) or str(chk_auth_thearchives) == '':
                            addon = xbmcaddon.Addon("plugin.video.thearchives")
                            addon.setSetting("trakt.access_token", your_token)
                            addon.setSetting("trakt.token", your_token)
                            addon.setSetting("trakt.refresh_token", your_refresh)
                            addon.setSetting("trakt.refresh", your_refresh)
                            addon.setSetting("trakt.expires", your_expires)
                            addon.setSetting("trakt.user_id", your_username)
                            addon.setSetting("trakt.api_client_id", var.client_am)
                            addon.setSetting("trakt.api_client_secret", var.secret_am)
                            addon.setSetting("trakt.client_id", var.client_am)
                            addon.setSetting("trakt.client_secret", var.secret_am)
            except:
                xbmc.log('%s: The Archives Trakt Failed!' % var.amgr, xbmc.LOGINFO)

    #FidoK19
            try:
                if 'FidoK19' in current:
                    if xbmcvfs.exists(var.chk_fidok19) and xbmcvfs.exists(var.chkset_fidok19):
                        chk_auth_fidok19 = xbmcaddon.Addon('plugin.video.fidoK19').getSetting("trakt.access_token")
                        if not str(your_token) == str(chk_auth_fidok19) or str(chk_auth_fidok19) == '':
                            addon = xbmcaddon.Addon("plugin.video.fidoK19")
                            addon.setSetting("trakt.access_token", your_token)
                            addon.setSetting("trakt.refresh_token", your_refresh)
                            addon.setSetting("trakt.user_id", your_username)
                            addon.setSetting("trakt.client_id", var.client_am)
                            addon.setSetting("trakt.client_secret", var.secret_am)
            except:
                xbmc.log('%s: FidoK19 Trakt Failed!' % var.amgr, xbmc.LOGINFO)

    #TorqueLite
            try:
                if 'TorqueLite' in current:
                    if xbmcvfs.exists(var.chk_torquelite) and xbmcvfs.exists(var.chkset_torquelite):
                        chk_auth_torquelite = xbmcaddon.Addon('plugin.video.torquelite').getSetting("trakt.access_token")
                        if not str(your_token) == str(chk_auth_torquelite) or str(chk_auth_torquelite) == '':
                            addon = xbmcaddon.Addon("plugin.video.torquelite")
                            addon.setSetting("trakt.access_token", your_token)
                            addon.setSetting("trakt.refresh_token", your_refresh)
                            addon.setSetting("trakt.user_id", your_username)
                            addon.setSetting("trakt.client_id", var.client_am)
                            addon.setSetting("trakt.client_secret", var.secret_am)
            except:
                xbmc.log('%s: TorqueLite Trakt Failed!' % var.amgr, xbmc.LOGINFO)

    #TorqueLive
            try:
                if 'TorqueLive' in current:
                    if xbmcvfs.exists(var.chk_torquelive) and xbmcvfs.exists(var.chkset_torquelive):
                        chk_auth_torquelive = xbmcaddon.Addon('plugin.video.torquelive').getSetting("trakt.access_token")
                        if not str(your_token) == str(chk_auth_torquelive) or str(chk_auth_torquelive) == '':
                            addon = xbmcaddon.Addon("plugin.video.torquelive")
                            addon.setSetting("trakt.access_token", your_token)
                            addon.setSetting("trakt.refresh_token", your_refresh)
                            addon.setSetting("trakt.user_id", your_username)
                            addon.setSetting("trakt.client_id", var.client_am)
                            addon.setSetting("trakt.client_secret", var.secret_am)
            except:
                xbmc.log('%s: TorqueLive Trakt Failed!' % var.amgr, xbmc.LOGINFO)

    #Diamond Media Player
    #Trakt client id/secret are honoured from settings (no source patching needed),
    #same as POV/Umbrella/Infinity. No trakt_expires field exists in its settings.xml,
    #so there is nowhere to send one - matches FidoK19/TorqueLite/TorqueLive above.
            try:
                if 'Diamond Media Player' in current:
                    if xbmcvfs.exists(var.chk_rdtplayer) and xbmcvfs.exists(var.chkset_rdtplayer):
                        chk_auth_rdtplayer = xbmcaddon.Addon('plugin.program.rdtplayer').getSetting("trakt_access_token")
                        if not str(your_token) == str(chk_auth_rdtplayer) or str(chk_auth_rdtplayer) == '':
                            addon = xbmcaddon.Addon("plugin.program.rdtplayer")
                            addon.setSetting("trakt_client_id", var.client_am)
                            addon.setSetting("trakt_client_secret", var.secret_am)
                            addon.setSetting("trakt_access_token", your_token)
                            addon.setSetting("trakt_refresh_token", your_refresh)
            except:
                xbmc.log('%s: Diamond Media Player Trakt Failed!' % var.amgr, xbmc.LOGINFO)

    #TMDb Movies
    #TRAKT_CLIENT_ID/SECRET are hardcoded in resources/lib/config.py, read as
    #ADDON.getSetting('trakt_client_id') or <hardcoded value> - source patch needed,
    #same as Aliunde K19/Blue Balls/Twisted (also needs a router.py revoke block,
    #added alongside this). trakt_created_at + trakt_expires_in are tracked
    #separately (not a single expiry field): Trakt tokens are always a fixed
    #90-day (7776000s) lifetime, so created_at is back-computed from ReAuthorize's
    #own absolute expiry rather than left blank - a blank/zero created_at would
    #read as "already expired" and make the addon refresh (and spend) the shared
    #token on its very first use even though it is still fresh.
            try:
                if 'TMDb Movies' in current:
                    if xbmcvfs.exists(var.chk_tmdbmovies) and xbmcvfs.exists(var.chkset_tmdbmovies):
                        chk_auth_tmdbmovies = xbmcaddon.Addon('plugin.video.tmdbmovies').getSetting("trakt_access_token")
                        tmdbmovies_renews = xbmcaddon.Addon('plugin.video.tmdbmovies').getSetting("trakt_refresh_token") != NO_RENEW
                        if not str(your_token) == str(chk_auth_tmdbmovies) or str(chk_auth_tmdbmovies) == '' or tmdbmovies_renews:

                            # TMDb Movies 1.1.308 moved config.py to resources/lib/core/. Its settings override the
                            # hardcoded keys either way, so the patch is optional: a missing file must not stop the
                            # settings below being written (it did, and TMDb Movies got no Trakt at all).
                            try:
                                cfg = var.path_tmdbmovies
                                if not os.path.isfile(cfg):
                                    cfg = os.path.join(os.path.dirname(var.path_tmdbmovies), 'core', 'config.py')
                                with open(cfg, 'r') as f:
                                    data = f.read()
                                client = data.replace(var.tmdbmovies_client, var.client_am).replace(var.tmdbmovies_secret, var.secret_am)
                                with open(cfg, 'w') as f:
                                    f.write(client)
                            except Exception:
                                xbmc.log('%s: TMDb Movies source patch skipped (config.py not found)' % var.amgr, xbmc.LOGINFO)

                            addon = xbmcaddon.Addon("plugin.video.tmdbmovies")
                            addon.setSetting("trakt_client_id", var.client_am)
                            addon.setSetting("trakt_client_secret", var.secret_am)
                            addon.setSetting("trakt_access_token", your_token)
                            # NO_RENEW (1.4.5): it renews by itself near expiry; a refused renewal only
                            # sets its 'permanent fail' flag, which stops further renewals and nothing else
                            addon.setSetting("trakt_refresh_token", NO_RENEW)
                            expires_in = 7776000
                            your_expires_float = float(your_expires)
                            addon.setSetting("trakt_expires_in", str(expires_in))
                            addon.setSetting("trakt_created_at", str(int(your_expires_float) - expires_in))
            except:
                xbmc.log('%s: TMDb Movies Trakt Failed!' % var.amgr, xbmc.LOGINFO)

    #Youtube Theater
    #trakt_client_id/secret are honoured from settings (resources/modules/general.py's
    #_get_trakt_client_secret() checks Addon.getSetting first, hardcoded default
    #second) - no source patching or router.py block needed, unlike TMDb Movies.
    #trakt_expires_at exists as its own field (not created_at/expires_in like
    #TMDb Movies), so ReAuthorize's own absolute expiry maps straight across.
            try:
                if 'Youtube Theater' in current:
                    if xbmcvfs.exists(var.chk_youtubetheater) and xbmcvfs.exists(var.chkset_youtubetheater):
                        chk_auth_ytheater = xbmcaddon.Addon('plugin.video.youtubetheater').getSetting("trakt_access_token")
                        if not str(your_token) == str(chk_auth_ytheater) or str(chk_auth_ytheater) == '':
                            addon = xbmcaddon.Addon("plugin.video.youtubetheater")
                            addon.setSetting("trakt_client_id", var.client_am)
                            addon.setSetting("trakt_client_secret", var.secret_am)
                            addon.setSetting("trakt_access_token", your_token)
                            addon.setSetting("trakt_refresh_token", your_refresh)
                            addon.setSetting("trakt_expires_at", your_expires)
            except:
                xbmc.log('%s: Youtube Theater Trakt Failed!' % var.amgr, xbmc.LOGINFO)

    #The add-ons' "where do watched marks go" choices (POV, Coalition, Umbrella, Red Light, Gears): moved to
    #Trakt only while still on their default, once per sign-in (sync/pickers.py, 1.4.5). These blocks used to
    #write it at every re-send, so a POV set to MDBList went back to Trakt at every renewal.
            try:
                from reauthorize.modules.sync import pickers
                pickers.apply('trakt')
            except Exception as e:
                xbmc.log('%s: Trakt watched-status choices failed: %s' % (var.amgr, e), xbmc.LOGINFO)
