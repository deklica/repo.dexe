# -*- coding: utf-8 -*-
"""
    ReAuthorize - take one key out of the add-ons that hold OURS (1.4.5)

    The metadata Revokes (Fanart.TV, OMDb, IMDb, TheAudioDB, the TMDb session) used to clear only
    ReAuthorize's own copy; the key left the add-ons only because the next sync wrote a blank over
    whatever they held. That blank write also erased keys people had typed into an add-on themselves,
    so 1.4.5 stopped it (meta_sync._go), and a Revoke now removes its key here instead.

    Where a key lives comes from import_map (the sync code's own writes, run backwards), so a newly
    wired add-on is covered once its sync block is recorded. Only a value equal to the one ReAuthorize
    held is removed; a different key typed into an add-on by hand is left alone (as remove_api_key in
    mdblist_oauth_sync does for the MDBList key).
"""

import sqlite3

import xbmc
import xbmcaddon
import xbmcvfs

LOG_TAG = '[ReAuthorize Revoke]'


def _log(message):
    xbmc.log('%s %s' % (LOG_TAG, message), xbmc.LOGINFO)


def _settings_ready(addon_id):
    return (xbmcvfs.exists('special://home/addons/%s/' % addon_id) and
            xbmcvfs.exists('special://profile/addon_data/%s/settings.xml' % addon_id))


def remove(credential_key, old_value):
    """Blank `credential_key`'s value in every add-on still holding `old_value`. How many were cleared."""
    if not old_value:
        return 0
    from reauthorize.modules import import_map
    cleared = 0
    for addon_id, mapping in sorted(getattr(import_map, 'SETTINGS', {}).items()):
        ids = sorted(sid for sid, key in mapping.items() if key == credential_key)
        if not ids or not _settings_ready(addon_id):
            continue
        try:
            addon = xbmcaddon.Addon(addon_id)
            mine = [sid for sid in ids if addon.getSetting(sid) == old_value]
            for sid in mine:
                addon.setSetting(sid, '')
            if mine:
                cleared += len(mine)
                _log('%s removed from %s' % (credential_key, addon_id))
        except Exception as e:
            _log('could not remove %s from %s: %s' % (credential_key, addon_id, e))
    for addon_id, spec in sorted(getattr(import_map, 'DATABASES', {}).items()):
        ids = sorted(sid for sid, key in spec.get('keys', {}).items() if key == credential_key)
        if not ids or not xbmcvfs.exists('special://home/addons/%s/' % addon_id):
            continue
        path = xbmcvfs.translatePath('special://profile/addon_data/%s/%s' % (addon_id, spec.get('file', '')))
        if not xbmcvfs.exists(path):
            continue
        try:
            conn = sqlite3.connect(path, timeout=10)
            try:
                with conn:
                    n = 0
                    for sid in ids:
                        # back to the add-on's own default, as a wipe does (redlight_db._reset)
                        n += conn.execute('UPDATE settings SET setting_value = COALESCE(setting_default, \'\') '
                                          'WHERE setting_id = ? AND setting_value = ?', (sid, old_value)).rowcount
            finally:
                conn.close()
            if n:
                cleared += n
                _log('%s removed from %s' % (credential_key, addon_id))
                if addon_id == 'plugin.video.redlight':
                    from reauthorize.modules.db import redlight_db
                    redlight_db._request_reload()
        except Exception as e:
            _log('could not remove %s from %s: %s' % (credential_key, addon_id, e))
    return cleared
