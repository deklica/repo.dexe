import xbmc
import xbmcaddon
import xbmcvfs

from libs.common import var

char_remov = ["'", ",", ")","("]

#Account Manager Easy Debrid
# Shared accessor: a cached Addon handle can revert settings written
# through another instance. See control._Settings.
from reauthorize.modules.control import accountmgr
your_token = accountmgr.getSetting("easydebrid.token")
# What the add-ons show as the account (up to 1.4.4: easydebrid.acct_id, which held the API key itself)
your_acct_id = 'Easy Debrid' if accountmgr.getSetting("easydebrid.token") else ''

class Auth:
    def easydebrid_auth(self):
    #Umbrella
        try:
            if xbmcvfs.exists(var.chk_umb) and xbmcvfs.exists(var.chkset_umb):
                chk_auth_umb = xbmcaddon.Addon('plugin.video.umbrella').getSetting("easydebridtoken")
                if not str(your_token) == str(chk_auth_umb) or str(chk_auth_umb) == '':

                    addon = xbmcaddon.Addon("plugin.video.umbrella")
                    addon.setSetting("easydebridtoken", your_token)
                    addon.setSetting("easydebrid.enable", 'true')

        except:
            xbmc.log('%s: Umbrella Easy Debrid Failed!' % var.amgr, xbmc.LOGINFO)

    #POV
        try:
            if xbmcvfs.exists(var.chk_pov) and xbmcvfs.exists(var.chkset_pov):
                chk_auth_pov = xbmcaddon.Addon('plugin.video.pov').getSetting("ed.token")
                if not str(your_token) == str(chk_auth_pov) or str(chk_auth_pov) == '':

                    addon = xbmcaddon.Addon("plugin.video.pov")
                    addon.setSetting("ed.token", your_token)
                    addon.setSetting("ed.account_id", your_acct_id)
                    addon.setSetting("ed.enabled", 'true')

        except:
            xbmc.log('%s: POV Easy Debrid Failed!' % var.amgr, xbmc.LOGINFO)

    #Infinity
        try:
            if xbmcvfs.exists(var.chk_infinity) and xbmcvfs.exists(var.chkset_infinity):
                chk_auth_infinity = xbmcaddon.Addon('plugin.video.infinity').getSetting("easydebridtoken")
                if not str(your_token) == str(chk_auth_infinity) or str(chk_auth_infinity) == '':

                    addon = xbmcaddon.Addon("plugin.video.infinity")
                    addon.setSetting("easydebridtoken", your_token)
                    addon.setSetting("easydebrid.username", your_acct_id)
                    addon.setSetting("easydebrid.enable", 'true')
                    addon.setSetting("easydebrid.expirynotice", '0')

        except:
            xbmc.log('%s: Infinity Easy Debrid Failed!' % var.amgr, xbmc.LOGINFO)
