# -*- coding: utf-8 -*-
"""
    ReAuthorize - Ownership stamp (the leak failsafe)

    A build carries ReAuthorize's settings, so a builder's sign-ins used to arrive
    on every box the build went on (2026-09-27). Prepare for Distribution cleans
    them, but only if the builder remembers. This is the net under it.

    Whenever this device holds sign-ins, settings also holds a stamp made from this
    device's ID: '<first 8 chars of the ID>.<HMAC of the ID>'. The ID never leaves
    the device (device.py), so a stamp copied into a build cannot verify anywhere
    else. At every start, before anything is pushed or backed up:

        no sign-ins                       -> nothing to do
        stamp verifies                    -> the sign-ins are this device's own
        no stamp, device already had an   -> a version before the stamp existed:
          ID before this start               adopt them (stamp them now)
        no stamp and no ID yet, or a      -> they came with a build or a copy of
          stamp that does not verify         another device: FOREIGN

    Foreign sign-ins are cleared before they can reach an addon or a backup, the
    user is told in one plain sentence, and the server is told which device the
    stamp names, so the builder finds out from the leak itself (server.py, claim).

    Known limits: a build made by a version older than this carries no stamp and,
    on a box that already has an ID, is adopted as if it were the user's own;
    the kill switch (reset.py) is what covers those. Addons' own copies of tokens
    inside a build are only blanked for the services sync_all.run_all_syncs knows.
"""

import hashlib
import hmac
import os
import xbmc
from reauthorize.modules import own_settings  # one read or write of our settings at a time
from reauthorize.modules import storage, device, vault

ADDON_ID = 'script.module.reauthorize'
LOG_TAG  = '[ReAuthorize Owner]'

# How long a wipe waits before checking it again (see wipe_local). The tests set it to 0.
SETTLE_SECONDS = float(os.environ.get('REAUTHORIZE_SETTLE_SECONDS', '20'))

STAMP      = 'owner.stamp'
LEAKS_SEEN = 'owner.leaks.seen'

NONE, OWN, ADOPT, FOREIGN = 'none', 'own', 'adopt', 'foreign'

# Everything ReAuthorize clears when it removes every sign-in from a device,
# beyond vault.CREDENTIAL_KEYS: the markers that would make a fresh start behave
# like an old one.
_EXTRA_KEYS = ('trakt.all_push.done', 'trakt.auto_push.consent', 'import.declined', 'server.shared.notice', STAMP,
               'mdblist.oauth.username.display',
               'services.paused',    # pause.py: a build never ships its maker's paused services
               'torbox.acct_id', 'easydebrid.acct_id')   # up to 1.4.4 these held the API key itself

# Service tags for sync_all.run_all_syncs(wipe=...): push a blank to every
# addon that already holds the old value.
WIPE_TAGS = {'rd', 'pm', 'ad', 'torbox', 'easyd', 'offc', 'linksnappy',
             'easy', 'debridlink', 'simkl', 'filep', 'meta', 'mdbo', 'lastfm', 'punchplay',
             'wetrakr', 'torrentclaw'}


def _get(key):
    return own_settings.addon().getSetting(key)


def _set(key, value):
    own_settings.addon().setSetting(key, value)


def make_stamp():
    device_id = device.get_device_id()
    mac = hmac.new(device_id.encode('utf-8'), b'reauthorize-owner-stamp',
                   hashlib.sha256).hexdigest()[:32]
    return '%s.%s' % (device_id[:8], mac)


def source_of(stamp):
    """The 8-character device fingerprint a stamp names, or ''."""
    head = (stamp or '').split('.')[0]
    return head if len(head) == 8 else ''


def holds_credentials():
    addon = own_settings.addon()
    return vault.count_credentials({k: addon.getSetting(k) for k in vault.CREDENTIAL_KEYS}) > 0


def is_new_box():
    """
    True if this device has never had an ID. Call it before anything can make
    one: the ID file appears the first time device.get_device_id() runs.
    A device with nowhere to write outside Kodi cannot tell, so it is never new.
    """
    path = storage.device_id_path()
    return bool(path) and not os.path.isfile(path)


def assess(new_box):
    if not holds_credentials():
        return NONE
    stamp = _get(STAMP)
    if stamp:
        return OWN if hmac.compare_digest(stamp, make_stamp()) else FOREIGN
    return FOREIGN if new_box else ADOPT


def claim(force=False):
    """
    Stamp the sign-ins now in settings as this device's own. Leaves an existing
    stamp alone (never blesses what is already marked as someone else's) unless
    force. With no sign-ins it removes the stamp. Returns True if it wrote one.
    """
    try:
        if not holds_credentials():
            if _get(STAMP):
                _set(STAMP, '')
            return False
        if _get(STAMP) and not force:
            return False
        _set(STAMP, make_stamp())
        return True
    except Exception as e:
        xbmc.log('%s claim failed: %s' % (LOG_TAG, e), xbmc.LOGWARNING)
        return False


def wipe_local(revoke_trakt=False, progress=None):
    """
    Remove every sign-in and marker from ReAuthorize's settings, then push the
    blanks to the addons that already hold the old values.

    revoke_trakt kills the Trakt token itself, everywhere at once. Only for
    sign-ins that are this device's own to end: a build's Trakt belongs to its
    maker, who revokes it himself.

    progress(percent, text), when given, is told each step (Prepare for Distribution's
    progress window, 1.4.3: about 40 seconds passed with only a corner notice, and the
    user nearly took the wait for the end).
    """
    report = progress or (lambda percent, text: None)
    report(5, 'Removing the sign-ins from ReAuthorize...')
    if revoke_trakt and _get('trakt.token'):
        try:
            from reauthorize.modules.auth.trakt import Trakt
            Trakt().call('oauth/revoke', data={'token': _get('trakt.token')}, with_auth=False)
        except Exception as e:
            xbmc.log('%s Trakt revoke failed: %s' % (LOG_TAG, e), xbmc.LOGWARNING)

    for key in list(vault.CREDENTIAL_KEYS) + list(_EXTRA_KEYS):
        if _get(key):
            _set(key, '')

    try:
        from reauthorize.modules.sync_all import run_all_syncs
        from reauthorize.modules.sync import youtube_sync, trakt_wipe
        report(10, 'Removing them from your add-ons...')
        run_all_syncs(include_trakt=False, wipe=WIPE_TAGS)
        youtube_sync.wipe()
        # Trakt too, since 1.3.6: a build cleaned by Prepare for Distribution still carried
        # the builder's live Trakt inside every add-on (trakt_wipe.py).
        trakt_wipe.wipe_addons()
        # A running addon keeps its own copy of its settings and can write that copy back
        # over a blank. Seen live on the Shield (2026-09-30): Umbrella kept a TMDb password
        # and session through a wipe, while its other fields cleared. So wait a moment and
        # go round again: the second pass only writes where a value has come back.
        monitor = xbmc.Monitor()
        if progress is None:
            if SETTLE_SECONDS > 0 and monitor.waitForAbort(SETTLE_SECONDS):
                return      # Kodi is closing
        else:
            seconds = int(SETTLE_SECONDS)
            for waited in range(seconds):
                report(30 + 40 * waited // max(seconds, 1),
                       'Letting your add-ons settle before checking again: %d s' % (seconds - waited))
                if monitor.waitForAbort(1):
                    return  # Kodi is closing
        report(75, 'Checking your add-ons once more...')
        run_all_syncs(include_trakt=False, wipe=WIPE_TAGS)
        youtube_sync.wipe()
        trakt_wipe.wipe_addons()
        # The watched-status choices ReAuthorize set were put back by the wipes above (sync/pickers.py);
        # what it remembered about them goes too, so a build never ships it. Cleared last on purpose:
        # the put-back reads it.
        from reauthorize.modules.sync import pickers
        pickers.clear_state()
    except Exception as e:
        xbmc.log('%s Pushing blanks to addons failed: %s' % (LOG_TAG, e), xbmc.LOGWARNING)


def handle_foreign(source_fp):
    """Sign-ins that came with a build or copy: remove them and say so."""
    xbmc.log('%s Sign-ins came from another device (%s...) - removing them.'
             % (LOG_TAG, source_fp or '?'), xbmc.LOGWARNING)
    wipe_local(revoke_trakt=False)
    try:
        from reauthorize.modules import server
        server.report_leak(source_fp)
    except Exception as e:
        xbmc.log('%s Leak report failed: %s' % (LOG_TAG, e), xbmc.LOGWARNING)
    # No commas in the text: the builtin splits its arguments on them. Worded to be
    # true for a build's sign-ins and for an old box whose own sign-ins cannot be told apart.
    xbmc.executebuiltin('Notification(ReAuthorize, Sign-ins that could not be confirmed as '
                        'yours were removed. Please sign in to your services again., 8000)')


def startup_check(new_box):
    """First thing at every start. Returns the verdict."""
    verdict = assess(new_box)
    if verdict == ADOPT:
        claim()
    elif verdict == FOREIGN:
        handle_foreign(source_of(_get(STAMP)))
    return verdict


# The thread showing the leak message, kept so a test can wait for it.
_leak_popup = None
# The leak message waits for the start-up rush to pass (the user, 2026-10-23: 'it won't conflict
# with the Kodi bum rush'): at least this long after it is due, then until nothing has been on screen
# for LEAK_QUIET_SECONDS, never over a video; if dialogs keep coming it shows after LEAK_MAX_WAIT.
# The main bench's add-on updates landed 106 s after Kodi started (2026-10-23).
LEAK_DELAY_SECONDS = 120
LEAK_QUIET_SECONDS = 15
LEAK_MAX_WAIT = 600


def _screen_busy():
    for condition in ('System.HasActiveModalDialog', 'Window.IsVisible(extendedprogressdialog)',
                      'Window.IsVisible(busydialog)', 'Window.IsVisible(busydialognocancel)'):
        try:
            if xbmc.getCondVisibility(condition):
                return True
        except Exception:
            pass
    return False


def _playing():
    try:
        return bool(xbmc.getCondVisibility('Player.HasMedia'))
    except Exception:
        return False


def _wait_until_settled(monitor):
    """False when Kodi is closing first (the message then waits for the next start)."""
    if LEAK_DELAY_SECONDS <= 0:
        return True
    if monitor.waitForAbort(LEAK_DELAY_SECONDS):
        return False
    quiet = waited = 0
    while quiet < LEAK_QUIET_SECONDS:
        if _playing():
            quiet = 0
        elif _screen_busy() and waited < LEAK_MAX_WAIT:
            quiet = 0
            waited += 1
        else:
            quiet += 1
        if monitor.waitForAbort(1):
            return False
    return True


def leak_text(count):
    boxes = '%d box%s' % (count, '' if count == 1 else 'es')
    return ('Your sign-ins are in a shared build (%s)[CR][CR]'
            'They were found on %s and removed there. Before you share a build, run Prepare '
            'for Distribution (Reset & Clear tab). Then Revoke and sign in again on this device, '
            'so the copies in the old build stop working.' % (boxes, boxes))


def leak_notice(count):
    """
    The server counted `count` boxes that found this device's sign-ins in a build. Tell the
    builder, and keep telling him until OK itself is pressed (1.4.5): Back closes it only until
    it comes up again, and it counts as seen only after OK, so a message pressed away in the
    start-up rush, or left open when Kodi closed, is shown again at the next start. The leak
    table (2026-10-23) showed one builder's build reaching 21 boxes over two weeks while his
    one-time popup, marked seen before it even opened, had most likely gone unread.
    Shown in a thread of its own, so the start-up never waits on it, and only once the start-up rush
    has passed (_wait_until_settled).
    """
    global _leak_popup
    try:
        count = int(count)
        seen = int(_get(LEAKS_SEEN) or 0)
    except (TypeError, ValueError):
        return False
    if count <= seen:
        return False
    if _leak_popup is not None and _leak_popup.is_alive():
        return False
    import threading
    import xbmcgui
    text = leak_text(count)

    def show():
        monitor = xbmc.Monitor()
        if not _wait_until_settled(monitor):
            return
        while True:
            try:
                if xbmcgui.Dialog().ok('ReAuthorize', text):
                    _set(LEAKS_SEEN, str(count))
                    return
            except Exception as e:
                xbmc.log('%s leak message failed: %s' % (LOG_TAG, e), xbmc.LOGWARNING)
                return
            if monitor.waitForAbort(1):
                return

    _leak_popup = threading.Thread(target=show, name='ReAuthorizeLeakNotice')
    _leak_popup.daemon = True
    _leak_popup.start()
    return True
