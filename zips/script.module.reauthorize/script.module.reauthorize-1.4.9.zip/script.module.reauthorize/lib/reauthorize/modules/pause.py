# -*- coding: utf-8 -*-
"""
    ReAuthorize - turn a service off without signing out (1.4.5)

    Asked for by the user (2026-10-21): after a show, three redundant services each asked for a
    rating, and in a home where each person has favourite services, pausing one is handier than
    clearing it out. "Turns all of it off. When I need it I'll turn it on."

    Paused: the sign-in stays in ReAuthorize and in the backups, and keeps being renewed, but it is
    taken out of every add-on (the same helpers a Revoke uses, minus "forget it"), and nothing sends it
    back: Sync Add-ons, the send after a sign-in, Trakt / PunchPlay / MDBList renewals, the start-up
    checks, new add-ons and YouTube's restore all skip it. On: it is sent to every add-on at once.

    The list lives in ReAuthorize's own settings (services.paused), so each Kodi PROFILE decides for
    itself; it is not backed up, and Prepare for Distribution clears it (owner._EXTRA_KEYS). A pause is
    not a Revoke: nothing is revoked at the service and the sign-in is never forgotten.
"""

import xbmc

from reauthorize.modules.control import accountmgr

LOG_TAG = '[ReAuthorize Pause]'
PAUSED_SETTING = 'services.paused'

# tag (as in sync_all): label, the settings that hold its sign-in, the status line in the settings,
# and the Build Status tile. Metadata keys (Fanart.TV, TMDb, ...) and Debrid-Link (no add-on takes it)
# are not offered.
SERVICES = (
    ('trakt', 'Trakt', ('trakt.token', 'trakt.refresh', 'trakt.expires', 'trakt.username'),
     'trakt.username.display', 'trakt'),
    ('simkl', 'Simkl', ('simkl.token',), 'simkl.username.display', 'simkl'),
    ('mdbo', 'MDBList', ('mdblist.oauth.token', 'mdblist.oauth.refresh', 'mdb.api.key'),
     'mdblist.oauth.username.display', 'mdblist'),
    ('punchplay', 'PunchPlay', ('punchplay.token',), 'punchplay.username.display', 'punchplay'),
    ('wetrakr', 'WeTrakr', ('wetrakr.token',), 'wetrakr.username.display', 'wetrakr'),
    ('lastfm', 'Last.fm', ('lastfm.username', 'lastfm.password', 'lastfm.session.key'),
     'lastfm.username.display', 'lastfm'),
    ('rd', 'Real-Debrid', ('realdebrid.token', 'realdebrid.refresh', 'realdebrid.username'),
     'realdebrid.username.display', 'realdebrid'),
    ('pm', 'Premiumize', ('premiumize.token', 'premiumize.username'), 'premiumize.username.display', 'premiumize'),
    ('ad', 'AllDebrid', ('alldebrid.token', 'alldebrid.username'), 'alldebrid.username.display', 'alldebrid'),
    ('torbox', 'TorBox', ('torbox.token',), 'torbox.authorized.display', 'torbox'),
    ('easyd', 'Easy Debrid', ('easydebrid.token',), 'easydebrid.authorized.display', 'easydebrid'),
    ('offc', 'OffCloud', ('offcloud.token', 'offcloud.userid', 'offcloud.user', 'offcloud.pass'),
     'offcloud.authorized.display', 'offcloud'),
    ('easy', 'Easynews', ('easynews.username', 'easynews.password'), 'easynews.username.display', 'easynews'),
    ('filep', 'FilePursuit', ('filepursuit.api.key',), 'filepursuit.authorized.display', 'filepursuit'),
    ('linksnappy', 'Linksnappy', ('linksnappy.username', 'linksnappy.password'),
     'linksnappy.username.display', None),
    ('torrentclaw', 'TorrentClaw', ('torrentclaw.api.key',), 'torrentclaw.authorized.display', 'torrentclaw'),
    ('yt', 'YouTube', ('youtube.tokens',), 'youtube.signin.display', 'youtube'),
)
_BY_TAG = dict((s[0], s) for s in SERVICES)
# The tags pickers.py uses for the watched-status choices
PICKER_TAG = {'trakt': 'trakt', 'mdblist': 'mdbo'}


def _log(message):
    xbmc.log('%s %s' % (LOG_TAG, message), xbmc.LOGINFO)


def paused_tags():
    raw = accountmgr.getSetting(PAUSED_SETTING) or ''
    return set(t for t in raw.split(',') if t in _BY_TAG)


def paused(tag):
    try:
        return tag in paused_tags()
    except Exception:
        return False


def _store(tags):
    text = ','.join(t for t, *_ in SERVICES if t in tags)
    if accountmgr.getSetting(PAUSED_SETTING) != text:
        accountmgr.setSetting(PAUSED_SETTING, text)


def masked_keys():
    """The sign-in settings of every paused service (read as empty while a sync runs: sync_all)."""
    keys = set()
    for tag in paused_tags():
        keys.update(_BY_TAG[tag][2])
    return keys


def display_keys():
    """The status lines that get '(paused)' after them (settings_display)."""
    return set(_BY_TAG[t][3] for t in paused_tags())


def build_status_ids():
    """Build Status tiles shown as off while their service is paused (windows/status.py)."""
    return set(_BY_TAG[t][4] for t in paused_tags() if _BY_TAG[t][4])


def signed_in(tag):
    keys = _BY_TAG[tag][2]
    if tag == 'lastfm':
        keys = ('lastfm.password', 'lastfm.session.key')
    elif tag == 'mdbo':
        keys = ('mdblist.oauth.token', 'mdb.api.key')
    return any(accountmgr.getSetting(k) for k in keys)


def offered():
    """(tag, label) of every service that is signed in or paused, in display order."""
    now = paused_tags()
    return [(t, label) for t, label, *_ in SERVICES if t in now or signed_in(t)]


# -- taking a service out and sending it back -----------------------------------------------------

def _take_out(tag):
    from reauthorize.modules import own_settings
    if tag == 'trakt':
        # 1.4.5: an add-on may hold the only live pair (it renewed on its own); take it over before the
        # add-ons are cleared, or it is lost with them (the bench, 2026-10-22)
        try:
            from reauthorize.modules.auth import trakt
            trakt.Trakt().ensure_alive(quiet=True)
        except Exception as e:
            _log('could not check the Trakt sign-in before pausing: %s' % e)
        from reauthorize.modules.sync import trakt_wipe
        trakt_wipe.wipe_addons()                       # also puts back the watched-status choices
    elif tag == 'simkl':
        from reauthorize.modules.sync import simkl_sync
        simkl_sync.sign_out_addons()                   # blanks it and gives each add-on its own app key back
    elif tag == 'mdbo':
        from reauthorize.modules.sync import mdblist_oauth_sync
        token = accountmgr.getSetting('mdblist.oauth.token')
        if token:
            mdblist_oauth_sync.wipe(token=token)
        mdblist_oauth_sync.remove_api_key(accountmgr.getSetting('mdb.api.key'))
    elif tag == 'punchplay':
        from reauthorize.modules.sync import punchplay_sync
        punchplay_sync.wipe(token=accountmgr.getSetting('punchplay.token'))
    elif tag == 'wetrakr':
        from reauthorize.modules.sync import wetrakr_sync
        wetrakr_sync.wipe(token=accountmgr.getSetting('wetrakr.token'))
    elif tag == 'lastfm':
        from reauthorize.modules.sync import lastfm_sync
        lastfm_sync.clear_scrobbler(accountmgr.getSetting('lastfm.username'), accountmgr.getSetting('lastfm.password'))
    elif tag == 'torrentclaw':
        from reauthorize.modules.sync import torrentclaw_sync
        torrentclaw_sync.sign_out(accountmgr.getSetting('torrentclaw.api.key'))
    elif tag == 'yt':
        from reauthorize.modules.sync import youtube_sync
        youtube_sync.wipe()
    else:
        # The debrid services: the normal sync, run as a wipe of that one service, with its sign-in read
        # as empty for this thread only, so blanks are sent while ReAuthorize keeps its own copy.
        from reauthorize.modules.sync_all import run_all_syncs
        with own_settings.masking(_BY_TAG[tag][2]):
            run_all_syncs(include_trakt=False, wipe={tag}, only=(tag,))


def _send(tag):
    from reauthorize.modules.sync_all import run_all_syncs, refresh_sync_modules
    if tag == 'trakt':
        refresh_sync_modules()
        from reauthorize.modules.sync import trakt_sync
        trakt_sync.Auth().trakt_auth()
    elif tag == 'punchplay':
        from reauthorize.modules.sync import punchplay_sync
        punchplay_sync.push(force=True)
    elif tag == 'wetrakr':
        from reauthorize.modules.sync import wetrakr_sync
        wetrakr_sync.push(force=True)
    elif tag == 'mdbo':
        run_all_syncs(include_trakt=False, only=('mdbo', 'meta'))
    else:
        run_all_syncs(include_trakt=False, only=(tag,))   # YouTube's sync restores its sign-in file first


def pause(tag):
    if tag not in _BY_TAG:
        return False
    now = paused_tags()
    if tag in now:
        return False
    _store(now | {tag})
    try:
        _take_out(tag)
    except Exception as e:
        _log('could not take %s out of every add-on: %s' % (tag, e))
    _log('%s paused: taken out of the add-ons, still signed in to ReAuthorize' % _BY_TAG[tag][1])
    return True


def resume(tag):
    now = paused_tags()
    if tag not in now:
        return False
    _store(now - {tag})
    try:
        _send(tag)
    except Exception as e:
        _log('could not send %s to the add-ons: %s' % (tag, e))
    _log('%s on again: sent to the add-ons' % _BY_TAG[tag][1])
    return True


def choose(dialog=None, notify=None):
    """
    The 'Turn Services On or Off' button: a checklist of the signed-in services, ticked = on.
    Returns (paused, resumed) labels.
    """
    import xbmcgui
    dialog = dialog or xbmcgui.Dialog()
    rows = offered()
    if not rows:
        dialog.ok('ReAuthorize', 'Nothing to turn on or off yet.[CR][CR]Sign in to a service first.')
        return [], []
    now = paused_tags()
    on = [i for i, (t, _) in enumerate(rows) if t not in now]
    picked = dialog.multiselect('Ticked = on. Untick to pause, tick to turn back on.',
                                [label for _, label in rows], preselect=on)
    if picked is None:                                 # Back: nothing changes
        return [], []
    want_on = set(rows[i][0] for i in picked)
    paused_now, resumed_now = [], []
    for tag, label in rows:
        if tag in want_on and tag in now:
            if notify:
                notify('Turning %s back on...' % label)
            resume(tag)
            resumed_now.append(label)
        elif tag not in want_on and tag not in now:
            if notify:
                notify('Pausing %s...' % label)
            pause(tag)
            paused_now.append(label)
    return paused_now, resumed_now
