# -*- coding: utf-8 -*-
"""
        Account Manager
"""

import os.path
import xbmcaddon
import xbmcgui
from reauthorize.modules import control

addon_id = 'script.module.reauthorize'
addon = xbmcaddon.Addon(addon_id)
joinPath = os.path.join
file_icon = joinPath(os.path.join(addon.getAddonInfo('path'), 'resources', 'icons'), 'filepursuit.png')

class Filepursuit:

    def auth(self):
        api = (xbmcgui.Dialog().input('Enter FilePursuit API Key:') or '').strip()
        if not api:
            return          # Cancel or nothing typed: keep what was there (1.4.5; it saved a blank)
        control.setSetting('filepursuit.api.key', api)
        control.notification(title='FilePursuit', message='FilePursuit Successfully Authorized', icon=file_icon) #Authorization complete. Start sync process
