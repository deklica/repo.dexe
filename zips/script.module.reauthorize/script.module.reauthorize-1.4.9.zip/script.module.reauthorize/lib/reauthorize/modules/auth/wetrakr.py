# -*- coding: utf-8 -*-
"""
    ReAuthorize - WeTrakr sign-in (1.4.7)

    WeTrakr (wetrakr.com) tracks what is watched, like Trakt. ReAuthorize is registered as its own
    public app, so the sign-in is the usual "enter this code" screen, and the result goes to the
    add-ons on WeTrakr's public API (sync/wetrakr_sync.py). Tried by hand against the real service
    on 2026-10-13: the device sign-in works under our app id.

    WeTrakr's rules (api.wetrakr.com docs, read 2026-10-11): an access token lasts 7 days, a refresh
    token 180 days from its last use, and every renewal replaces the refresh token, with a short grace
    for the old one. A renewal needs no app id, so any holder can make one: as with PunchPlay, the
    add-ons get the access token and never the refresh token, and ReAuthorize is the only renewer.

    A renewal comes every few days, so it is backed up to the vault AND the server, like Trakt. The
    vault is read before each renewal and its pair taken over when it runs out later: every Kodi on a
    device shares it, and a used refresh token must not be shown to WeTrakr.

    A refused renewal keeps the sign-in (Trakt's rule, not PunchPlay's): what WeTrakr does after a
    refusal has not been seen, the access token may have days left, and the user can sign in again.
    It is tried again after RETRY_SECONDS and the user is told once per Kodi run.

    The WeTrakr scrobbler (script.wetrakr) and The Archives use another kind of token, with no app
    key, through a sign-in the terms do not let ReAuthorize copy. They keep their own.

    API: POST /oauth/device/code {client_id}, POST /oauth/device/token {code, client_id} (400 = not
    yet, 404 / 409 / 410 / 418 = over), POST /oauth/token/refresh {refresh_token}, POST /oauth/logout
    {refresh_token}, GET /account/settings. Calls with a token carry 'wetrakr-api-key', all carry
    'wetrakr-api-version: 1' and our own User-Agent (their Cloudflare answers Python's default 403).
"""

import json
import threading
import time

import xbmc
import xbmcgui

from reauthorize.modules import control

CLIENT_ID = '725bb80639e26073bbc9164923728e3d'
API = 'https://api.wetrakr.com'
ACTIVATE = 'https://wetrakr.com/activate'
LOG_TAG = '[ReAuthorize WeTrakr]'

TOKEN = 'wetrakr.token'
REFRESH = 'wetrakr.refresh'
EXPIRES = 'wetrakr.expires'
USERNAME = 'wetrakr.username'
DISPLAY = 'wetrakr.username.display'
KEYS = (TOKEN, REFRESH, EXPIRES, USERNAME)

LIFETIME = 7 * 86400                # what WeTrakr issues (expires_in 604800)
RENEW_WHEN_LEFT = LIFETIME // 2     # half the lifetime, as Trakt
RETRY_SECONDS = 3600                # the service looks every five minutes; a failing renewal waits

REFUSED_WORDS = ('TOKEN_REVOKED', 'INVALID_TOKEN', 'INVALID_GRANT')

_renew_lock = threading.Lock()
_BUSY = 'reauthorize.wetrakr.renewing'      # the service and the Sync button are separate processes
_retry = {'at': 0, 'told': False}
_last = {}                                  # the pair last stored: see punchplay._undo_revert


def _renewing_elsewhere():
    try:
        return time.time() - float(control.window.getProperty(_BUSY) or 0) < 45
    except (TypeError, ValueError):
        return False


def _log(message, level=xbmc.LOGINFO):
    xbmc.log('%s %s' % (LOG_TAG, message), level)


def _user_agent():
    try:
        version = control.addonVersion()
    except Exception:
        version = '1'
    return 'ReAuthorize/%s (+https://the-hermit.com)' % version


def _call(path, payload=None, token=None, timeout=20):
    """(status, json body) - (None, {}) when WeTrakr cannot be reached. Never raises."""
    try:
        from urllib.request import Request, urlopen
        from urllib.error import HTTPError
    except ImportError:
        return None, {}
    headers = {'Content-Type': 'application/json', 'Accept': 'application/json', 'User-Agent': _user_agent(),
               'wetrakr-api-version': '1'}
    if token:
        headers['Authorization'] = 'Bearer %s' % token
        headers['wetrakr-api-key'] = CLIENT_ID
    body = json.dumps(payload).encode('utf-8') if payload is not None else None
    try:
        response = urlopen(Request(API + path, data=body, headers=headers), timeout=timeout)
        raw = response.read().decode('utf-8', 'replace')
        status = response.getcode()
    except HTTPError as e:
        try:
            raw = e.read().decode('utf-8', 'replace')
        except Exception:
            raw = ''
        status = e.code
    except Exception as e:
        _log('could not reach WeTrakr (%s): %s' % (path, e))
        return None, {}
    try:
        data = json.loads(raw) if raw else {}
    except ValueError:
        data = {}
    return status, data if isinstance(data, dict) else {}


def signed_in():
    return bool(control.setting(TOKEN))


def seconds_left():
    try:
        return float(control.setting(EXPIRES)) - time.time()
    except (TypeError, ValueError):
        return 0


def _store(token):
    control.setSetting(TOKEN, token['access_token'])
    refresh = token.get('new_refresh_token') or token.get('refresh_token')
    if refresh:
        control.setSetting(REFRESH, refresh)
    try:
        lifetime = float(token.get('expires_in') or LIFETIME)
    except (TypeError, ValueError):
        lifetime = LIFETIME
    expires = str(int(time.time() + lifetime))
    control.setSetting(EXPIRES, expires)
    _last.update({TOKEN: token['access_token'], REFRESH: refresh or control.setting(REFRESH), EXPIRES: expires})


def _undo_revert():
    """A settings dialog left open across a renewal saves the old pair back: put the newer one back."""
    if not _last or not control.setting(TOKEN) or control.setting(TOKEN) == _last.get(TOKEN):
        return False
    try:
        if float(control.setting(EXPIRES) or 0) >= float(_last.get(EXPIRES) or 0):
            return False
    except (TypeError, ValueError):
        return False
    for key in (TOKEN, REFRESH, EXPIRES):
        control.setSetting(key, _last[key])
    _log('the settings held an older WeTrakr sign-in than the one last renewed - put the newer one back')
    return True


def _send(force=False):
    try:
        from reauthorize.modules.sync import wetrakr_sync
        return wetrakr_sync.push(force=force)
    except Exception as e:
        _log('could not send the sign-in to the add-ons: %s' % e)
        return 0


def _back_up():
    try:
        from reauthorize.modules import server, vault
        vault.backup(fresh=dict(_last))
        server.backup()
    except Exception as e:
        _log('could not back up the sign-in: %s' % e)


def _account_name(token):
    code, data = _call('/account/settings', token=token)
    info = data.get('info') if code == 200 else None
    if not isinstance(info, dict):
        return ''
    return str(info.get('username') or info.get('display_name') or '')


def sign_in():
    """The 'Authorize WeTrakr' button. True if signed in."""
    from reauthorize.modules import qr
    from reauthorize.windows import device_auth
    status, start = _call('/oauth/device/code', {'client_id': CLIENT_ID})
    if not (start.get('device_code') and start.get('user_code')):
        _log('device sign-in could not start (HTTP %s)' % status, xbmc.LOGWARNING)
        xbmcgui.Dialog().ok('ReAuthorize', 'WeTrakr sign-in did not start. Try again later.')
        return False

    result = {}

    def poll_once():
        code, token = _call('/oauth/device/token', {'code': start['device_code'], 'client_id': CLIENT_ID})
        if code == 200 and token.get('access_token'):
            result['token'] = token
            return True
        if code in (404, 409, 410, 418):
            return False
        return None

    verification = start.get('verification_url') or start.get('verification_uri') or ACTIVATE
    try:
        expires_in = int(start.get('expires_in') or 600)
        interval = max(int(start.get('interval') or 5), 1)
    except (TypeError, ValueError):
        expires_in, interval = 600, 5
    device_auth.run('WeTrakr', qr.qr_image_url('%s?code=%s' % (verification, start['user_code'])), verification,
                    start['user_code'], poll_once, interval=interval, expires_in=expires_in)
    if 'token' not in result:
        return False

    token = result['token']
    _store(token)
    name = _account_name(token['access_token'])
    control.setSetting(USERNAME, name)
    control.setSetting(DISPLAY, name or 'Signed in')
    _log('signed in%s' % (' as %s' % name if name else ''))
    # No backup here: the button's automatic backup (default.py, autosave) makes it and says so.
    sent = _send(force=True)
    control.notification(title='WeTrakr', message='Signed in. Sent to %d add-on%s.' % (sent, '' if sent == 1 else 's')
                         if sent else 'Signed in.')
    return True


def _renew_with(refresh):
    """'ok' (the new pair is stored), 'refused' (WeTrakr says the token is no good), or 'unreachable'."""
    status, token = _call('/oauth/token/refresh', {'refresh_token': refresh})
    if status == 200 and token.get('access_token'):
        _store(token)
        return 'ok'
    words = json.dumps(token).upper()
    if status in (400, 401, 403) and any(word in words for word in REFUSED_WORDS):
        return 'refused'
    _log('renewal got no usable answer (HTTP %s)' % status)
    return 'unreachable'


def _adopt_newer_from_vault():
    """Take over the vault's pair when it runs out later than the settings' one. Signed out stays signed out."""
    mine = control.setting(REFRESH)
    if not mine:
        return False
    try:
        from reauthorize.modules import vault
        stored = vault.stored()
    except Exception:
        return False
    theirs = {key: str(stored.get(key) or '') for key in KEYS}
    if not (theirs[TOKEN] and theirs[REFRESH]) or theirs[REFRESH] == mine:
        return False
    try:
        if float(theirs[EXPIRES] or 0) <= float(control.setting(EXPIRES) or 0):
            return False
    except (TypeError, ValueError):
        return False
    for key in (TOKEN, REFRESH, EXPIRES):
        control.setSetting(key, theirs[key])
    if theirs[USERNAME]:
        control.setSetting(USERNAME, theirs[USERNAME])
    _last.update({TOKEN: theirs[TOKEN], REFRESH: theirs[REFRESH], EXPIRES: theirs[EXPIRES]})
    _log('the local backup holds a newer WeTrakr sign-in than the settings - using that one')
    return True


def refresh_if_due(quiet=True, force=False):
    """
    Renew when under half the lifetime is left (or force) and re-send at once. Not due: just make sure
    the add-ons still hold the sign-in. True if renewed.
    """
    if not signed_in() and not control.setting(REFRESH):
        return False
    with _renew_lock:
        _undo_revert()
        if _adopt_newer_from_vault():
            _send()                 # the add-ons hold the pair that was just replaced
        if not force and seconds_left() > RENEW_WHEN_LEFT:
            try:
                from reauthorize.modules.sync import wetrakr_sync
                wetrakr_sync.ensure()
            except Exception as e:
                _log('could not check the add-ons: %s' % e)
            return False
        if _renewing_elsewhere() or (not force and time.time() < _retry['at']):
            return False
        control.window.setProperty(_BUSY, str(time.time()))
        try:
            outcome = _renew_with(control.setting(REFRESH))
        finally:
            control.window.clearProperty(_BUSY)
        if outcome == 'ok':
            _retry.update({'at': 0, 'told': False})
            _log('sign-in renewed - sending it to the add-ons')
            _send()
            _back_up()
            return True
        _retry['at'] = time.time() + RETRY_SECONDS
        if outcome == 'refused':
            _log('WeTrakr refused the renewal - the sign-in is kept', xbmc.LOGWARNING)
            if not _retry['told']:
                _retry['told'] = True
                control.notification(title='WeTrakr', message='Please sign in to WeTrakr again.', time=6000)
        elif not quiet:
            control.notification(title='WeTrakr', message='Renewal failed. Try again later.')
        return False


def _forget():
    _last.clear()
    token = control.setting(TOKEN)
    for key in KEYS + (DISPLAY,):
        control.setSetting(key, '')
    try:
        from reauthorize.modules.sync import wetrakr_sync
        wetrakr_sync.wipe(token=token)
    except Exception as e:
        _log('could not clear the add-ons: %s' % e)


def sign_out():
    """The 'Revoke' button: end the sign-in at WeTrakr (its terms ask for that) and take it out of the add-ons."""
    token, refresh = control.setting(TOKEN), control.setting(REFRESH)
    if token and refresh:
        _call('/oauth/logout', {'refresh_token': refresh}, token=token)
    _forget()
    control.notification(title='WeTrakr', message='Signed out of WeTrakr.')


def account_info_to_dialog():
    if not signed_in():
        control.notification(title='WeTrakr', message='Not signed in.')
        return
    days = max(0, int((seconds_left() - RENEW_WHEN_LEFT) // 86400))
    control.selectDialog(['Username: %s' % (control.setting(USERNAME) or 'Unknown'),
                          'Renewed automatically (next in about %d day%s)' % (days, '' if days == 1 else 's')],
                         'WeTrakr Account')
