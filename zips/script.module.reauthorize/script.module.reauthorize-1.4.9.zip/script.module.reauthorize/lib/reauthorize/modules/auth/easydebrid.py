# -*- coding: utf-8 -*-
"""
        Account Manager
"""

import os.path
import xbmcaddon
import xbmcgui
from reauthorize.modules import control

addon_id = 'script.module.reauthorize'
addon = xbmcaddon.Addon(addon_id)
joinPath = os.path.join
api_key = control.setting('easydebrid.token')
easyd_icon = joinPath(os.path.join(addon.getAddonInfo('path'), 'resources', 'icons'), 'easydebrid.png')

class Easydebrid:

    def auth(self):
        api = xbmcgui.Dialog().input('Enter Easy Debrid API Key:')
        if api == '':
            control.notification(message='Easy Debrid authorization failed!', icon=easyd_icon)
            return
        control.setSetting('easydebrid.token', api)
        control.notification(title='Easy Debrid', message='Easy Debrid Successfully Authorized', icon=easyd_icon)

    def revoke(self):
        if not control.confirm_remove('Easy Debrid'):
            return
        control.setSetting('easydebrid.token', '')
        control.setSetting('easydebrid.acct_id', '')  # older versions kept the key here too
        control.notification(message="Easy Debrid Authorization Revoked", icon=easyd_icon)
