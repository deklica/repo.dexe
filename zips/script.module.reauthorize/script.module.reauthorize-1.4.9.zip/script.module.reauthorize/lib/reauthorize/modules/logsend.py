# -*- coding: utf-8 -*-
"""
    ReAuthorize - Send My Log for Help (1.3.6)

    For people on an Android box who cannot copy a file off it. One button: ReAuthorize
    reads Kodi's log, keeps only what helps with a ReAuthorize problem, removes anything
    secret, and sends it to the server (server/api.php, action 'log'), which stores it and
    mails it to the log inbox. The user gets a reference number to quote in the group, and
    the line the developer can set on the server for everyone ("Known issue: ...").

    What is kept: every line about ReAuthorize, Kodi's own start-up lines (version,
    platform), every warning and error from anything (1.4.8: a report that kept only the
    add-ons ReAuthorize knows could not say why logs 1007 and 1008 went wrong), add-on
    installs and updates, the close of a session, and info lines from those add-ons when
    they are about sign-ins (Trakt, debrid, tokens, 401...). A line repeated over and over
    is kept three times and then counted. Above the log: the add-ons on the box and which
    are off, free storage, and whether each add-on holds ReAuthorize's sign-ins, as same /
    different / empty, never the values.

    What is removed, from what is kept: passwords, keys, sign-in tokens, email addresses,
    device IDs beyond their first 8 characters, the user name in folder paths, folders
    outside Kodi (people's own files), network addresses and IP numbers. The
    rules are the Hermit wizard's log cleaner (fixed 2026-09-30), plus user names and
    Python-style quoted keys. The user can read exactly what will be sent before sending.
"""

import json
import os
import re

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON_ID = 'script.module.reauthorize'
LOG_TAG = '[ReAuthorize Log]'

# The newest part of each log file is read. A debug log can run to tens of megabytes.
READ_BYTES = 8 * 1024 * 1024
# What is sent at most (the server refuses more than 400 KB). The newest part wins.
MAX_SEND = 300 * 1024
# How many times one repeated line is kept before it is only counted.
REPEATS_KEPT = 3

# Add-ons that are not in import_map (it lists where ReAuthorize writes sign-ins) but whose
# sign-in trouble is still ReAuthorize's business.
EXTRA_ADDONS = ('plugin.video.youtube', 'service.mdblist-scrobbler', 'service.scrobbler.lastfm',
                'script.module.resolveurl', 'script.module.reauthorize-core')

# An add-on's info line is kept only when it is about signing in.
KEYWORDS = ('trakt', 'debrid', 'premiumize', 'torbox', 'offcloud', 'easynews', 'simkl', 'mdblist',
            'tmdb', 'fanart', 'oauth', 'auth', 'token', 'login', 'sign', 'api key', 'apikey',
            ' 401', ' 403', 'invalid', 'expired', 'unauthorized')

HEADER_STARTS = ('Starting Kodi', 'Using Release', 'Kodi compiled', 'Running on', 'Host CPU')

# Kodi lines that name no add-on but say why one cannot load its settings. Kodi 21 refuses a
# settings file a Kodi 22 wrote ('version 4 (current version: 2)'): a Kodi 22 build backported to
# 21 left Umbrella, POV, ReAuthorize and others with empty settings windows (log 1004, Jay's
# build, 2026-10-15), and this line, the one that said why, was left out of the report.
ALWAYS_KEEP = ('unable to read setting values from version', 'failed to determine setting values',
               'stopping the application', 'exiting the application', 'caddoninstalljob', 'findaddon:')

# Warnings every box repeats that say nothing about a fault.
NOISE = ('uses plain http for add-on downloads', 'uses old schema definition',
         'does not have any directory matching', 'cguitexturemanager::cleanup', 'cimageloader::',
         'cmusicinfoscanner', 'refresh_container', 'jsonrpc: could not parse type')

# The settings that decide whether an add-on shows Trakt watched marks.
WATCHED_SETTINGS = (('plugin.video.umbrella', 'indicators.alt'), ('plugin.video.umbrella', 'scrobble.source'),
                    ('plugin.video.thecrew', 'tracker.service'), ('plugin.video.thecrew', 'indicators.alt'),
                    ('plugin.video.pov', 'watched_indicators'))

_ENTRY = re.compile(r'^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\.\d{3} T:\s*\d+\s+(\w+) <[^>]*>:\s?(.*)$')

# Applied in order to everything that is sent, header included.
REDACT = (
    # passwords written inside a web address:  http://name:password@host
    (r'//[^/\s:@]+:[^/\s@]+@', '//USER:PASSWORD@'),
    (r'<user>.+?</user>', '<user>USER</user>'),
    (r'<pass>.+?</pass>', '<pass>PASSWORD</pass>'),
    # secrets in a query string:  ?auth_token=...  &apikey=...  &password=...
    (r'(?i)([?&;](?:api_?key|auth_token|access_token|refresh_token|token|key|secret|client_secret|'
     r'password|pass|pin|code|authorization)=)[^&\s"\'<>]+', r'\1REDACTED'),
    # Authorization headers
    (r'(?i)(bearer\s+)[A-Za-z0-9._~+/=\-]{8,}', r'\1REDACTED'),
    # JSON:  "access_token": "..."
    (r'(?i)("(?:access_token|refresh_token|auth_token|token|api_?key|apikey|secret|client_secret|password|'
     r'authorization|device_code|code)"\s*:\s*")[^"]+(")', r'\1REDACTED\2'),
    # Python dicts printed into the log:  'access_token': '...'
    (r"(?i)('(?:access_token|refresh_token|auth_token|token|api_?key|apikey|secret|client_secret|password|"
     r"authorization|device_code|code)'\s*:\s*')[^']+(')", r'\1REDACTED\2'),
    # settings printed as  something.token = value
    (r'(?i)(\b[a-z0-9_.\-]*(?:token|secret|password|apikey|api_key)\s*[=:]\s*)[^\s,;]{6,}', r'\1REDACTED'),
    # user names printed as  username=...  user: ...
    (r'(?i)(\buser(?:name)?\s*[=:]\s*)[^\s,;]+', r'\1USER'),
    # account names in ReAuthorize's own lines:  signed in as ...
    (r'(?i)(signed in as\s+)[^\r\n]+', r'\1USER'),
    # email addresses
    (r'[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}', 'EMAIL'),
    # a 64-character id (a ReAuthorize device id is the key to its backup): keep 8, as the app shows it
    (r'\b([0-9a-fA-F]{8})[0-9a-fA-F]{56}\b', r'\1...'),
    # the user name inside a path:  C:\Users\name\...   /home/name/...
    (r'(?i)([A-Z]:\\Users\\)[^\\/\s]+', r'\1USER'),
    (r'(?<![:/\w])(/home/)[^/\s]+', r'\1USER'),
    # network shares and IP numbers
    (r'(?i)\b(?:smb|nfs|ftp|sftp|dav|davs)://[^\s\'"]+', 'NETWORK-ADDRESS'),
    (r'\b(?:\d{1,3}\.){3}\d{1,3}\b', 'IP'),
    # folders outside Kodi hold people's own files:  G:\Music\Artist\...   /storage/emulated/0/Movies/...
    (r'(?i)\b[A-Z]:\\(?![^\'"\n]*(?:kodi|addons|userdata|reauthorize))[^\'"\n]*', 'LOCAL-FOLDER'),
    (r'(?i)/(?:storage|sdcard|mnt)/(?![^\s\'"]*(?:android/data|kodi|reauthorize))[^\s\'"]*', 'LOCAL-FOLDER'),
    # any other long opaque string with both letters and digits (a token that matched nothing above)
    (r'\b(?=[A-Za-z0-9_\-]*\d)(?=[A-Za-z0-9_\-]*[A-Za-z])[A-Za-z0-9_\-]{32,}\b', 'REDACTED-TOKEN'),
)
_REDACT = [(re.compile(p), r) for p, r in REDACT]


def redact(text):
    for pattern, replacement in _REDACT:
        text = pattern.sub(replacement, text)
    return text


def _known_addons():
    ids = set(EXTRA_ADDONS)
    try:
        from reauthorize.modules import import_map
        ids.update(getattr(import_map, 'SETTINGS', {}))
        ids.update(getattr(import_map, 'DATABASES', {}))
    except Exception:
        pass
    ids.discard(ADDON_ID)
    # Longest first, so plugin.video.genocide is not cut short by a shorter id it starts with.
    return re.compile('|'.join(re.escape(i) for i in sorted(ids, key=len, reverse=True)), re.I)


def _entries(text):
    """Kodi log lines grouped into entries: a stamped line plus the lines that continue it."""
    current = None
    for line in text.splitlines():
        m = _ENTRY.match(line)
        if m:
            if current:
                yield current
            current = {'level': m.group(1).lower(), 'message': m.group(2), 'lines': [line]}
        elif current:
            current['lines'].append(line)
            current['message'] += '\n' + line.strip()
    if current:
        yield current


def _keep(entry, known):
    whole = '\n'.join(entry['lines'])
    lower = whole.lower()
    if 'reauthorize' in lower or 'accountmgr' in lower:
        return True
    if entry['message'].startswith(HEADER_STARTS):
        return True
    if any(phrase in lower for phrase in ALWAYS_KEEP):
        return True
    if any(phrase in lower for phrase in NOISE):
        return False
    if entry['level'] in ('warning', 'error', 'fatal'):
        return True
    return bool(known.search(whole)) and any(k in lower for k in KEYWORDS)


def filter_log(text, known=None):
    """The entries worth sending, with long runs of the same line counted, not repeated."""
    known = known or _known_addons()
    kept, seen = [], {}
    for entry in _entries(text):
        if not _keep(entry, known):
            continue
        key = entry['message']
        seen[key] = seen.get(key, 0) + 1
        if seen[key] <= REPEATS_KEPT:
            kept.append('\n'.join(entry['lines']))
    repeated = [(n, k) for k, n in seen.items() if n > REPEATS_KEPT]
    if repeated:
        kept.append('')
        kept.append('Repeated lines (shown %d times above, then only counted):' % REPEATS_KEPT)
        for n, k in sorted(repeated, reverse=True):
            kept.append('  %5d x  %s' % (n, k.splitlines()[0][:300]))
    return '\n'.join(kept)


def _read_tail(path):
    try:
        size = os.path.getsize(path)
        with open(path, 'rb') as f:
            if size > READ_BYTES:
                f.seek(size - READ_BYTES)
            data = f.read()
        text = data.decode('utf-8', 'replace')
        if size > READ_BYTES:
            text = text.split('\n', 1)[-1]       # drop the partial first line
        return text
    except Exception:
        return ''


def _log_files():
    base = xbmcvfs.translatePath('special://logpath/')
    return [(label, os.path.join(base, name)) for label, name in
            (('PREVIOUS KODI SESSION (kodi.old.log)', 'kodi.old.log'),
             ('THIS KODI SESSION (kodi.log)', 'kodi.log'))]


def _header():
    lines = ['ReAuthorize log report']
    def add(label, get):
        try:
            value = get()
        except Exception as e:
            value = '? (%s)' % e.__class__.__name__
        lines.append('%-22s %s' % (label + ':', value))
    add('ReAuthorize', lambda: xbmcaddon.Addon(ADDON_ID).getAddonInfo('version'))
    add('ReAuthorize Core', lambda: xbmcaddon.Addon('script.module.reauthorize-core').getAddonInfo('version'))
    add('Kodi', lambda: xbmc.getInfoLabel('System.BuildVersion'))
    add('System', lambda: xbmc.getInfoLabel('System.OSVersionInfo'))
    add('Android', lambda: 'yes' if xbmc.getCondVisibility('System.Platform.Android') else 'no')
    add('Debug logging', lambda: 'on' if xbmc.getCondVisibility('System.GetBool(debug.showloginfo)') else 'off')
    def device():
        from reauthorize.modules import device as dev
        return dev.fingerprint() or '(none yet)'
    add('Device', device)
    def store():
        from reauthorize.modules import storage
        return storage.location_label()
    add('Store', store)
    def reset_number():
        from reauthorize.modules import reset
        seen = reset._read()
        return 'none recorded' if seen is None else seen
    add('Reset number obeyed', reset_number)
    def signed_in():
        from reauthorize.modules import vault
        addon = xbmcaddon.Addon(ADDON_ID)
        names = sorted({k.split('.')[0] for k in vault.CREDENTIAL_KEYS
                        if vault.is_credential_key(k)
                        and addon.getSetting(k).strip().lower() not in ('', 'true', 'false')})
        return ', '.join(names) or 'nothing'
    add('Signed in to', signed_in)
    def sync_on():
        return xbmcaddon.Addon(ADDON_ID).getSetting('server.enabled') or '?'
    add('Server sync', sync_on)
    add('Skin', xbmc.getSkinDir)
    def free_storage():
        import shutil
        usage = shutil.disk_usage(xbmcvfs.translatePath('special://home/'))
        return '%d MB free of %d MB' % (usage.free // 1048576, usage.total // 1048576)
    add('Storage', free_storage)
    def settings_file():
        from reauthorize.modules import settings_health
        path = settings_health.settings_path()
        size = os.path.getsize(path) if os.path.isfile(path) else 0
        broken = path + settings_health.BROKEN_SUFFIX
        return '%d bytes%s' % (size, ', an older one was moved aside' if os.path.isfile(broken) else '')
    add('Settings file', settings_file)
    return '\n'.join(lines)


def _addon_section():
    """The add-ons on the box by name and version, and which are switched off. Never fails the report."""
    try:
        answer = json.loads(xbmc.executeJSONRPC(json.dumps({
            'jsonrpc': '2.0', 'id': 1, 'method': 'Addons.GetAddons',
            'params': {'properties': ['version', 'enabled']}})))
        addons = answer['result']['addons']
    except Exception as e:
        return 'Add-ons: could not be listed (%s)' % e.__class__.__name__
    wanted = [a for a in addons if a.get('addonid', '').startswith(('plugin.', 'skin.', 'service.', 'script.'))
              and not a['addonid'].startswith(('script.module.', 'script.common.'))]
    wanted.sort(key=lambda a: a['addonid'])
    off = [a['addonid'] for a in wanted if not a.get('enabled', True)]
    lines = ['Add-ons: ' + ', '.join('%s %s' % (a['addonid'], a.get('version', '?')) for a in wanted)]
    lines.append('Switched off: ' + (', '.join(off) or 'none'))
    return '\n'.join(lines)


def _signin_section():
    """
    Each sign-in, add-on by add-on: same as ReAuthorize's, different, or empty. Names and counts only,
    which is what a question like log 1007's needs (who holds an old copy?). Never fails the report.
    """
    try:
        from reauthorize.modules import importer, import_map, vault
        addon = xbmcaddon.Addon(ADDON_ID)
        collected = importer._collect()
        rows = {}
        for addon_id, held in collected.items():
            keys = set(import_map.SETTINGS.get(addon_id, {}).values())
            keys |= set((import_map.DATABASES.get(addon_id) or {}).get('keys', {}).values())
            for key in keys:
                if not key.endswith(('.token', '.api.key', '.apikey', '.session_id')) or not vault.is_credential_key(key):
                    continue
                mine = addon.getSetting(key)
                values = held.get(key) or {}
                state = 'empty' if not values else 'same' if mine and mine in values else 'different'
                rows.setdefault(key, {}).setdefault(state, []).append(addon_id.split('.')[-1])
        lines = []
        for key in sorted(rows):
            state = rows[key]
            parts = ['ReAuthorize %s' % ('holds it' if addon.getSetting(key) else 'empty'),
                     'same in %d' % len(state.get('same', []))]
            parts += ['%s: %s' % (name, ', '.join(sorted(state[name]))) for name in ('different', 'empty') if state.get(name)]
            lines.append('%s - %s' % (key, '; '.join(parts)))
        for addon_id, setting in WATCHED_SETTINGS:
            try:
                value = xbmcaddon.Addon(addon_id).getSetting(setting) or '(blank)'
                lines.append('%s %s = %s' % (addon_id.split('.')[-1], setting, value))
            except Exception:
                pass
        return '\n'.join(lines) or '(nothing to compare)'
    except Exception as e:
        return 'could not be compared (%s)' % e.__class__.__name__


def build():
    """The text that would be sent, already cleaned. Also what 'Show me' displays."""
    known = _known_addons()
    head = '\n'.join((_header(), '', _addon_section(), '',
                      '===== SIGN-INS IN THE ADD-ONS (compared, no values) =====', _signin_section()))
    parts = [head, '']
    for label, path in _log_files():
        parts.append('===== %s =====' % label)
        if not os.path.isfile(path):
            parts.append('(no such file)')
        else:
            raw = _read_tail(path)
            parts.append(filter_log(raw, known) or '(nothing relevant)')
            if label.startswith('PREVIOUS') and 'Stopping the application' not in raw:
                parts.append('(this session has no normal close: Kodi was killed, crashed or lost power)')
        parts.append('')
    text = '\n'.join(parts)
    if len(text.encode('utf-8')) > MAX_SEND:
        tail = text.encode('utf-8')[-(MAX_SEND - len(head) - 200):].decode('utf-8', 'replace')
        text = head + '\n\n(older lines left out to keep the log small)\n' + tail.split('\n', 1)[-1]
    return redact(text)


# THE FIRST LINE MUST CARRY THE WHOLE MESSAGE, in about 45 characters. Some skins show these
# dialogs as one line across the top of the screen and cut the rest off with "..." (the MQ9
# build's skin, 2026-10-02: only "Send your Kodi log to the ReAuthorize team for..." showed).
# What follows the first line is for skins that show a full box. The debug-logging tip is in
# About > How to Report an Issue.
INTRO = ('Send your log? Passwords & keys removed first.[CR]'
         'Sign-in tokens, email addresses and your own folders are removed too. '
         'Press Show me to read it before sending.')

THANKS = ('Log sent. Your reference number is [B]%d[/B].[CR][CR]'
          'Quote it when you ask for help in the group. Before it left this device, ReAuthorize '
          'removed passwords, keys, sign-in tokens, email addresses, and your own folders and '
          'network addresses.')

FAILED = {
    'busy': 'Too many logs sent this hour. Try again later.',
    'too_big': 'The log is too large to send.',
    'unreachable': 'No connection to the server. Try again later.',
    'failed': 'The log could not be sent. Try again later.',
}


def _ask(dialog):
    """'send', 'show' or 'cancel'."""
    custom = getattr(dialog, 'yesnocustom', None)
    if custom:
        answer = custom('ReAuthorize', INTRO, 'Show me', 'Cancel', 'Send')
        return {1: 'send', 2: 'show'}.get(answer, 'cancel')
    return 'send' if dialog.yesno('ReAuthorize', INTRO, nolabel='Cancel', yeslabel='Send') else 'cancel'


def _clean_notice(notice):
    text = ''.join(ch for ch in str(notice or '') if ch >= ' ')[:300].strip()
    return text


def run(viewer=None):
    """
    The button. Nothing is sent unless the user chooses Send. viewer(title, text) shows the
    preview (default.py passes ReAuthorize's own viewer, which scrolls on every skin).
    Returns the reference number, or None.
    """
    from reauthorize.modules import server
    dialog = xbmcgui.Dialog()
    show = viewer or dialog.textviewer
    text = None
    while True:
        choice = _ask(dialog)
        if choice == 'cancel':
            return None
        if text is None:
            text = build()
        if choice == 'show':
            show('ReAuthorize - what will be sent', text)
            continue
        break
    xbmc.executebuiltin('Notification(ReAuthorize, Sending the log..., 3000)')
    result, reason = server.send_log(text)
    if not result:
        xbmc.log('%s Log not sent: %s' % (LOG_TAG, reason), xbmc.LOGWARNING)
        dialog.ok('ReAuthorize', FAILED.get(reason or 'failed', FAILED['failed']))
        return None
    xbmc.log('%s Log sent, reference %d (%d bytes).' % (LOG_TAG, result['ref'], len(text)), xbmc.LOGINFO)
    message = THANKS % result['ref']
    notice = _clean_notice(result.get('notice'))
    if notice:
        message += '[CR][CR]' + notice
    dialog.ok('ReAuthorize', message)
    return result['ref']
