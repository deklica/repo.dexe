# -*- coding: utf-8 -*-
"""
    ReAuthorize - Credential Vault
    Stores a backup of all credentials in a location outside Kodi's addon_data/
    so credentials survive build installs that wipe portable_data/ or addon_data/.

    The storage location is chosen at runtime by reauthorize.modules.storage,
    which probes each candidate directory and uses the most durable one that
    genuinely accepts a write. See that module for the ordering and for why a
    hardcoded path could not work on Android 11+.

    On startup, if credentials are missing but a vault backup exists,
    credentials are silently restored before syncing begins.
"""

import os
import json
import time
import base64
import hashlib
import datetime
import xbmc
from reauthorize.modules import own_settings  # one read or write of our settings at a time
from reauthorize.modules import storage
from reauthorize.modules.device import get_device_id
from reauthorize.modules.crypto import encrypt_data, decrypt_data

ADDON_ID = 'script.module.reauthorize'
LOG_TAG  = '[ReAuthorize Vault]'


# All credential and service settings to include in the backup
CREDENTIAL_KEYS = [
    # Real-Debrid
    'realdebrid.token', 'realdebrid.refresh', 'realdebrid.secret',
    'realdebrid.client_id', 'realdebrid.username',
    # Premiumize
    'premiumize.token', 'premiumize.username',
    # All-Debrid
    'alldebrid.token', 'alldebrid.username',
    # Trakt
    'trakt.token', 'trakt.refresh', 'trakt.expires', 'trakt.username',
    'trakt.synclist',
    # TorBox
    'torbox.token', 'torbox.enabled',
    # Easy Debrid
    'easydebrid.token', 'easydebrid.enabled',
    # OffCloud
    'offcloud.token', 'offcloud.enabled',
    # Debrid-Link
    'debridlink.token', 'debridlink.enabled',
    # Linksnappy
    'linksnappy.username', 'linksnappy.password', 'linksnappy.enabled',
    # Easynews
    'easynews.username', 'easynews.password', 'easynews.enabled',
    # FilePursuit
    'filepursuit.api.key', 'filepursuit.enabled',
    # TorrentClaw (1.4.4): the user's own free key
    'torrentclaw.api.key',
    # Metadata
    'fanart.tv.api.key', 'omdb.api.key', 'mdb.api.key', 'mdb.username', 'imdb.user',
    'audiodb.api.key', 'tmdb.api.key', 'tmdb.username', 'tmdb.password',
    'tmdb.session_id',
    # YouTube - the keys, plus the sign-in itself (access_manager.json), which
    # a build install would otherwise wipe and make the user redo several times
    'youtube.api.key', 'youtube.api.id', 'youtube.api.secret', 'youtube.tokens',
    # Service / sync flags
    'sync.tk.service', 'sync.rd.service', 'sync.pm.service', 'sync.ad.service',
    'sync.torbox.service', 'sync.easyd.service', 'sync.offc.service',
    'sync.easy.service', 'sync.filep.service', 'sync.meta.service',
    'sync.yt.service', 'sync.ext.service', 'api.service',
    'sync.linksnappy.service', 'sync.debridlink.service', 'sync.lastfm.service',
    # Simkl
    'simkl.token', 'simkl.username', 'simkl.client.id',
    # MDBList account sign-in (1.3.7; the API key under Metadata is mdb.api.key)
    'mdblist.oauth.token', 'mdblist.oauth.refresh', 'mdblist.oauth.expires', 'mdblist.oauth.username',
    # PunchPlay (1.4.1). The refresh token changes at every renewal: auth/punchplay.py.
    'punchplay.token', 'punchplay.refresh', 'punchplay.expires', 'punchplay.username', 'punchplay.user.id',
    # WeTrakr (1.4.7). The refresh token changes at every renewal: auth/wetrakr.py.
    'wetrakr.token', 'wetrakr.refresh', 'wetrakr.expires', 'wetrakr.username',
    # Last.fm
    'lastfm.api.key', 'lastfm.api.secret', 'lastfm.session.key', 'lastfm.username', 'lastfm.password',
    # Debrid multi-account flag
    'debridall.enabled', 'meta.enabled',
]

# server.py backs up the same set. It used to keep its own copy, and the two
# drifted: YouTube's three keys and mdb.username lived only in the vault list,
# so they survived locally but were silently dropped from every cloud backup -
# invisible until someone restored onto a new device and found YouTube gone.
# Debrid-Link, Linksnappy and simkl.client.id were missing from BOTH lists, so
# those two services were never backed up by anything and were lost on every
# build install. One list, two consumers, so they cannot diverge again.
#
# server.api.secret is deliberately absent: it ships as a constant in
# settings.xml and is not a user credential.

# If ALL of these are empty we treat it as a credential wipe (e.g. after a build install)
PRIMARY_KEYS = [
    'realdebrid.token', 'premiumize.token', 'alldebrid.token',
    'trakt.token', 'torbox.token', 'easydebrid.token', 'simkl.token',
]


# Why the most recent backup() failed. None = it succeeded.
#   'no_credentials' - nothing authorized yet, so there is genuinely nothing to save
#   'no_location'    - the device refused every storage location we tried
#   'write_failed'   - we had a location but the write itself failed
# Callers use this to tell an empty profile apart from a blocked device. Those
# two reported identically as "Nothing to back up - no credentials found",
# which told users with a full profile that their credentials had vanished.
_LAST_ERROR = None


def last_error():
    """Reason the most recent backup() failed, or None if it succeeded."""
    return _LAST_ERROR


def blocked():
    """True if the last backup failed because the device would not let us write."""
    return _LAST_ERROR in ('no_location', 'write_failed')


def failure_message():
    """
    One plain sentence explaining the last failure, for showing to the user.
    Empty string if the last backup succeeded.

    Kept beside the reasons themselves so every screen reports a failure the
    same way, and so no caller has to guess what a False return meant.
    """
    if _LAST_ERROR == 'disabled':
        return 'Auto-Vault is switched off - turn it on under Backup & Device.'
    if _LAST_ERROR == 'no_credentials':
        return 'Nothing to back up yet - authorize a service first.'
    if _LAST_ERROR in ('no_location', 'write_failed'):
        return ('Could not save - this device is blocking storage access. '
                'See About -> Storage Report.')
    return ''


def warning_message():
    """
    Warning to show after a backup that worked but landed somewhere a build
    install will wipe. Empty string when the backup is properly durable.
    """
    if _LAST_ERROR is None and not storage.is_durable():
        return ('Saved, but only inside Kodi - a new build will erase it. '
                'See About -> Storage Report.')
    return ''


# Keys in CREDENTIAL_KEYS that are configuration, not credentials. These are
# stored so a restore brings your preferences back too, but a "backup" holding
# only these is empty in every sense that matters.
#
# This distinction is not cosmetic. Kodi returns booleans as the STRING
# 'false', which is truthy in Python, so the old emptiness check -
#     for key in CREDENTIAL_KEYS:
#         val = addon.getSetting(key)
#         if val: credentials[key] = val
#     if not credentials: return False
# could never fire: the five *.enabled flags are always present. A restore that
# recovered nothing was therefore followed by a "successful" backup that wrote
# those five flags over a perfectly good vault, destroying it permanently - and
# the same call then pushed the same wreckage to the server, taking out both
# copies at once.
_CONFIG_PREFIXES = ('sync.', 'api.', 'debridall.', 'meta.')
_CONFIG_SUFFIXES = ('.enabled', '.service')


def is_credential_key(key):
    """True if this setting is an actual credential rather than a preference."""
    return not (key.startswith(_CONFIG_PREFIXES) or key.endswith(_CONFIG_SUFFIXES))


# No real credential is ever the word "true" or "false". Checking the value as
# well as the name catches settings that are booleans in disguise: trakt.synclist
# is declared type="text" with default="false", so a name-only rule counted it as
# a credential and let a brand-new profile with nothing in it write a "backup".
_BOOLEAN_VALUES = ('', 'true', 'false')


def count_credentials(mapping):
    """
    How many real credentials (not configuration) a mapping holds.

    Judged by name AND value, because settings.xml does not reliably declare
    which is which.
    """
    return sum(1 for k, v in mapping.items()
               if is_credential_key(k)
               and str(v).strip().lower() not in _BOOLEAN_VALUES)


def _vault_file():
    """
    Current vault file path, or '' when no writable location exists.
    '' is safe to hand to os.path.isfile(), which keeps the read paths simple.
    """
    return storage.vault_path() or ''


def _legacy_decode(encoded):
    return json.loads(base64.b64decode(encoded.encode('utf-8')).decode('utf-8'))


def _now():
    return datetime.datetime.now().strftime('%Y-%m-%d  %H:%M')


def _keep_previous(path, new_credentials):
    """
    Keep one rolling copy of the outgoing vault as vault.json.bak.

    Only kept when the outgoing file holds MORE credentials than the one
    replacing it - that is the shape of an accidental loss, and it is the copy
    worth being able to fall back on. A normal backup that adds a service
    overwrites the .bak harmlessly.

    Never allowed to fail the backup itself: a missing safety net is a smaller
    problem than not saving the credentials at all.
    """
    try:
        if not os.path.isfile(path):
            return
        with open(path, 'r', encoding='utf-8') as f:
            existing = json.loads(f.read())
        version = existing.get('version', 1)
        if version >= 2:
            old = decrypt_data(existing['data'], get_device_id())
        else:
            old = _legacy_decode(existing['data'])
        if count_credentials(old) > count_credentials(new_credentials):
            import shutil
            shutil.copyfile(path, path + '.bak')
            xbmc.log('%s Previous vault held more credentials - kept a copy as '
                     'vault.json.bak.' % LOG_TAG, xbmc.LOGWARNING)
    except Exception as e:
        xbmc.log('%s Could not preserve previous vault: %s' % (LOG_TAG, e),
                 xbmc.LOGDEBUG)


# Sign-ins whose refresh token works only once (1.4.4). Every Kodi on a device shares this vault; one that
# renewed leaves the others holding a spent pair, and a backup made from one of those used to write the dead
# pair over the live one (the MQ9 build, 2026-10-17: every Kodi on the PC then got a dead Trakt sign-in).
# (name, the pair: token, refresh token, expiry, what goes with it)
PAIRED = (
    ('Trakt', ('trakt.token', 'trakt.refresh', 'trakt.expires'), ('trakt.username',)),
    ('PunchPlay', ('punchplay.token', 'punchplay.refresh', 'punchplay.expires'),
     ('punchplay.username', 'punchplay.user.id')),
    ('WeTrakr', ('wetrakr.token', 'wetrakr.refresh', 'wetrakr.expires'), ('wetrakr.username',)),
    ('MDBList', ('mdblist.oauth.token', 'mdblist.oauth.refresh', 'mdblist.oauth.expires'), ('mdblist.oauth.username',)),
)


def keep_newer_pairs(credentials, backed_up=None):
    """
    Where the vault already holds a pair that runs out LATER than the one about to be backed up (and has a
    different refresh token), keep the vault's: the outgoing one is spent. A sign-out (no pair in
    `credentials`) is left alone, so a Revoke still takes the sign-in out of the backup. Changes
    `credentials` in place; returns the names of the pairs kept.
    """
    if backed_up is None:
        backed_up = stored()
    kept = []
    for name, (token, refresh, expires), extra in PAIRED:
        mine, theirs = credentials.get(refresh), backed_up.get(refresh)
        if not (mine and credentials.get(token) and theirs and backed_up.get(token)) or mine == theirs:
            continue
        try:
            newer = float(backed_up.get(expires) or 0) > float(credentials.get(expires) or 0)
        except (TypeError, ValueError):
            continue
        if newer:
            for key in (token, refresh, expires) + extra:
                if backed_up.get(key):
                    credentials[key] = backed_up[key]
            kept.append(name)
    return kept


# -- one store for every Kodi on the device (1.4.6) -----------------------------------------------------------
#
# Every Kodi on a device shares this store, and up to 1.4.5 each backup REPLACED it. So a Kodi that lacked a
# service erased it for all of them: on the dev PC (2026-10-25) a Kodi with no Trakt, Real-Debrid or MDBList
# account wrote the store at 15:41, a builder's build (1.4.3) restored that at 17:13 and wrote it back without
# TorrentClaw (a key 1.4.3 does not know), and a fresh build then came up without Trakt. Now:
#   - a backup is MERGED per service: what this Kodi holds wins (with the newer-pair rule above), a service it
#     does not hold is kept from the store;
#   - only a deliberate Revoke drops a service: note_signed_out() leaves a marker in the store with the
#     fingerprint of the sign-in revoked; every Kodi holding that very sign-in signs that service out of itself
#     and its add-ons (modules/revokes.py), and no backup can bring it back. A different sign-in (made
#     separately, another account) is never touched, and a new sign-in after the Revoke is kept as usual
#     (the user, 2026-10-25: 'Revoke ends this sign-in everywhere it was copied'; a first version also
#     ended every value the store had ever held and any copy older than the marker, which would have signed
#     a second build or profile out of a different account);
#   - versions before 1.4.6 still replace vault.json, so the merged store is also kept in vault.keep.json,
#     which they never touch. vault.json carries the same random 'stamp' as that file; one without it was
#     written by an older version since, and is merged in like a backup from that Kodi.
# Fingerprints are the first 16 hex digits of a SHA-256 of the sign-in: enough to recognise a value, useless
# for getting it back. The record ('meta') is encrypted like the sign-ins.

# (tag, name, the settings that make up the sign-in, the ones that say it is there). A sign-in is always
# taken whole from one Kodi, never half from each. The tags are pause.py's / sync_all's where there is one.
GROUPS = (
    ('rd', 'Real-Debrid', ('realdebrid.token', 'realdebrid.refresh', 'realdebrid.secret',
                           'realdebrid.client_id', 'realdebrid.username'), ('realdebrid.token',)),
    ('pm', 'Premiumize', ('premiumize.token', 'premiumize.username'), ('premiumize.token',)),
    ('ad', 'AllDebrid', ('alldebrid.token', 'alldebrid.username'), ('alldebrid.token',)),
    ('trakt', 'Trakt', ('trakt.token', 'trakt.refresh', 'trakt.expires', 'trakt.username'), ('trakt.token',)),
    ('torbox', 'TorBox', ('torbox.token',), ('torbox.token',)),
    ('easyd', 'Easy Debrid', ('easydebrid.token',), ('easydebrid.token',)),
    ('offc', 'OffCloud', ('offcloud.token',), ('offcloud.token',)),
    ('debridlink', 'Debrid-Link', ('debridlink.token',), ('debridlink.token',)),
    ('linksnappy', 'Linksnappy', ('linksnappy.username', 'linksnappy.password'), ('linksnappy.password',)),
    ('easy', 'Easynews', ('easynews.username', 'easynews.password'), ('easynews.password',)),
    ('filep', 'FilePursuit', ('filepursuit.api.key',), ('filepursuit.api.key',)),
    ('torrentclaw', 'TorrentClaw', ('torrentclaw.api.key',), ('torrentclaw.api.key',)),
    ('fanart', 'Fanart.TV', ('fanart.tv.api.key',), ('fanart.tv.api.key',)),
    ('omdb', 'OMDb', ('omdb.api.key',), ('omdb.api.key',)),
    ('mdbkey', 'MDBList key', ('mdb.api.key', 'mdb.username'), ('mdb.api.key',)),
    ('imdb', 'IMDb', ('imdb.user',), ('imdb.user',)),
    ('audiodb', 'AudioDB', ('audiodb.api.key',), ('audiodb.api.key',)),
    ('tmdbkey', 'TMDb key', ('tmdb.api.key',), ('tmdb.api.key',)),
    # The TMDb sign-in is the session; its Revoke ends only that. The user name and password it was made with
    # stay, and are kept like any other setting.
    ('tmdb', 'TMDb account', ('tmdb.session_id',), ('tmdb.session_id',)),
    ('ytkeys', 'YouTube keys', ('youtube.api.key', 'youtube.api.id', 'youtube.api.secret'),
     ('youtube.api.key', 'youtube.api.id', 'youtube.api.secret')),
    ('yt', 'YouTube', ('youtube.tokens',), ('youtube.tokens',)),
    ('simkl', 'Simkl', ('simkl.token', 'simkl.username', 'simkl.client.id'), ('simkl.token',)),
    ('mdbo', 'MDBList', ('mdblist.oauth.token', 'mdblist.oauth.refresh', 'mdblist.oauth.expires',
                         'mdblist.oauth.username'), ('mdblist.oauth.token',)),
    ('punchplay', 'PunchPlay', ('punchplay.token', 'punchplay.refresh', 'punchplay.expires',
                                'punchplay.username', 'punchplay.user.id'), ('punchplay.token',)),
    ('wetrakr', 'WeTrakr', ('wetrakr.token', 'wetrakr.refresh', 'wetrakr.expires', 'wetrakr.username'),
     ('wetrakr.token',)),
    ('lastfm', 'Last.fm', ('lastfm.api.key', 'lastfm.api.secret', 'lastfm.session.key', 'lastfm.username',
                           'lastfm.password'), ('lastfm.password', 'lastfm.session.key')),
)
_GROUPED = set(k for g in GROUPS for k in g[2])
REVOKED_KEPT = 20                   # revoked sign-ins remembered per service
REVOKE_KEPT_SECONDS = 400 * 86400   # a marker older than this is dropped


def _empty_meta():
    return {'seen': {}, 'revoked': {}}     # 'seen' is unused since the marker matches the exact sign-in


def _has(mapping, signed):
    return any(str(mapping.get(k) or '').strip().lower() not in _BOOLEAN_VALUES for k in signed)


def fingerprint(mapping, signed):
    text = '\n'.join(str(mapping.get(k) or '') for k in signed)
    return hashlib.sha256(text.encode('utf-8')).hexdigest()[:16]


def _is_revoked(meta, tag, fp):
    return fp in meta['revoked'].get(tag, {}).get('fps', ())


def _merge(incoming, base, meta):
    """
    `incoming` (one Kodi's sign-ins) merged into `base` (the store). Per service: incoming's if it holds it and
    it is not revoked, else the store's, else nothing. Other settings: incoming's, else the store's.
    Returns (merged, names of the pairs kept from the store because they were newer).
    """
    out = {}
    for tag, _name, keys, signed in GROUPS:
        if not (_has(incoming, signed) or _has(base, signed)):
            # Nobody holds the sign-in itself: keep whatever parts are there, like any other setting, unless it was
            # revoked (its parts stay out with it). A part on its own is otherwise never dropped (found on the bench
            # 2026-10-25: a TMDb user name and password were, while the group still counted only the session).
            if tag in meta['revoked']:
                continue
            out.update((k, incoming.get(k) or base.get(k)) for k in keys if incoming.get(k) or base.get(k))
            continue
        for source in (incoming, base):
            if not _has(source, signed):
                continue
            if _is_revoked(meta, tag, fingerprint(source, signed)):
                continue
            out.update((k, source[k]) for k in keys if source.get(k))
            break
    for key in set(incoming) | set(base):
        if key not in _GROUPED and (incoming.get(key) or base.get(key)):
            out[key] = incoming.get(key) or base.get(key)
    return out, keep_newer_pairs(out, base)


def _read_file(path):
    """(sign-ins, meta or None, stamp or None) from one store file, or None when it is missing or unreadable."""
    try:
        if not path or not os.path.isfile(path):
            return None
        with open(path, 'r', encoding='utf-8') as f:
            raw = json.loads(f.read())
        if raw.get('version', 1) >= 2:
            credentials = decrypt_data(raw['data'], get_device_id())
        else:
            credentials = _legacy_decode(raw['data'])
        meta = decrypt_data(raw['meta'], get_device_id()) if raw.get('meta') else None
        if not isinstance(credentials, dict):
            return None
        if not (isinstance(meta, dict) and isinstance(meta.get('seen'), dict)
                and isinstance(meta.get('revoked'), dict)):
            meta = None
        return credentials, meta, raw.get('stamp')
    except Exception as e:
        xbmc.log('%s Could not read %s: %s' % (LOG_TAG, os.path.basename(path or ''), e), xbmc.LOGINFO)
        return None


def read_store():
    """
    (sign-ins, meta) as the store holds them now. vault.json gone means the store was cleared (an older
    version's Nuke or 'remove them'): nothing, whatever vault.keep.json still holds.
    """
    main = _read_file(_vault_file())
    if main is None:
        return {}, _empty_meta()
    keep = _read_file(storage.keep_path())
    if keep is None:
        return main[0], main[1] or _empty_meta()
    if main[2] and main[2] == keep[2]:
        return keep[0], keep[1] or _empty_meta()
    meta = keep[1] or _empty_meta()
    merged, _kept = _merge(main[0], keep[0], meta)
    return merged, meta


def _write_atomic(path, text):
    tmp = path + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        f.write(text)
    os.replace(tmp, path)


def _write_store(credentials, meta):
    """Both files, with one stamp: vault.json first, so a failure in between still reads right."""
    cutoff = time.time() - REVOKE_KEPT_SECONDS
    meta['revoked'] = dict((t, m) for t, m in meta['revoked'].items() if m.get('at', 0) > cutoff)
    device_id = get_device_id()
    text = json.dumps({
        'version': 2,                  # every version since 1.2 reads this file
        'timestamp': _now(),
        'stamp': base64.b16encode(os.urandom(8)).decode().lower(),
        'data': encrypt_data(credentials, device_id),
        'meta': encrypt_data(meta, device_id),
    })
    path = _vault_file()
    _keep_previous(path, credentials)
    _write_atomic(path, text)
    _write_atomic(storage.keep_path(), text)


def _own_settings():
    addon = own_settings.addon()
    return addon, dict((key, addon.getSetting(key)) for key in CREDENTIAL_KEYS)


def backup_set():
    """What a backup from this Kodi holds: its sign-ins merged into the store's. Writes nothing (server.py)."""
    mine = dict((k, v) for k, v in _own_settings()[1].items() if v)
    if not count_credentials(mine):
        return mine
    store, meta = read_store()
    return _merge(mine, store, meta)[0]


def backup(fresh=None):
    """
    Merge this Kodi's sign-ins into the store (see above) and write it.
    Called after a successful auth and periodically by the startup service.
    `fresh`: a pair just renewed, which the caller knows and the settings may not show yet. On the Kodi 22 bench
    (2026-11-01) a renewal's backup kept the spent pair, the MQ9 took that from the store, and PunchPlay ended the
    sign-in for every copy. Why the settings read back old was not found; a renewal no longer depends on it.
    Returns True on success; on failure see last_error() for why.
    """
    global _LAST_ERROR
    _LAST_ERROR = None
    try:
        addon, mine = _own_settings()
        credentials = dict((k, v) for k, v in mine.items() if v)
        credentials.update(fresh or {})

        # "Enable Auto-Vault" in settings. Gates new backups only, never a
        # restore of data already saved. Absent or blank counts as enabled, so
        # a fresh profile is protected before the user has touched anything.
        if addon.getSetting('vault.enabled') == 'false':
            _LAST_ERROR = 'disabled'
            xbmc.log('%s Auto-Vault is switched off - not saving.' % LOG_TAG,
                     xbmc.LOGINFO)
            return False

        # Count real credentials, not config flags - see is_credential_key().
        # A Kodi holding none has nothing to add to the store.
        if not count_credentials(credentials):
            _LAST_ERROR = 'no_credentials'
            xbmc.log('%s Nothing but preferences to save - refusing to overwrite '
                     'the existing backup.' % LOG_TAG, xbmc.LOGINFO)
            return False

        if not storage.ensure_dir():
            _LAST_ERROR = 'no_location'
            xbmc.log('%s No writable storage location - nothing was saved.'
                     % LOG_TAG, xbmc.LOGWARNING)
            return False

        store, meta = read_store()
        merged, kept_pairs = _merge(credentials, store, meta)
        for name in kept_pairs:
            xbmc.log('%s The backup already holds a newer %s sign-in than this Kodi - kept that one.'
                     % (LOG_TAG, name), xbmc.LOGWARNING)
        kept = [name for _t, name, _k, signed in GROUPS if _has(merged, signed) and not _has(credentials, signed)]
        if kept:
            xbmc.log('%s Kept from the shared backup (this Kodi does not hold them): %s.'
                     % (LOG_TAG, ', '.join(kept)), xbmc.LOGINFO)
        _write_store(merged, meta)

        # Only stamp the date once the file is actually on disk - this is what
        # the settings screen shows as "Last Backup", and a date next to a
        # backup that never happened is worse than no date at all.
        addon.setSetting('vault.last_backup', _now())
        xbmc.log('%s Credentials backed up to %s.'
                 % (LOG_TAG, storage.location_label()), xbmc.LOGINFO)
        return True
    except Exception as e:
        _LAST_ERROR = 'write_failed'
        xbmc.log('%s Backup failed: %s' % (LOG_TAG, str(e)), xbmc.LOGWARNING)
        return False


def note_signed_out(before, after=None):
    """
    A deliberate Revoke / sign-out on this Kodi: every service `before` held and `after` (default: this Kodi's
    settings now) does not is marked revoked in the store (that very sign-in), and taken out of the store when
    the store holds that same sign-in. Written even when nothing is left, so the last sign-in revoked leaves the
    backup too (until 1.4.6 it stayed). Returns the names marked.
    """
    if not before:
        return []
    if after is None:
        after = _own_settings()[1]
    gone = [g for g in GROUPS if _has(before, g[3]) and not _has(after, g[3])]
    if not gone:
        return []
    try:
        if not storage.ensure_dir():
            return []
        store, meta = read_store()
        for tag, _name, keys, signed in gone:
            fp = fingerprint(before, signed)
            fps = [f for f in meta['revoked'].get(tag, {}).get('fps', []) if f != fp] + [fp]
            meta['revoked'][tag] = {'at': time.time(), 'fps': fps[-REVOKED_KEPT:]}
            if not _has(store, signed) or fingerprint(store, signed) == fp:
                for key in keys:                       # another sign-in the store holds for it stays
                    store.pop(key, None)
        _write_store(store, meta)
        names = [g[1] for g in gone]
        xbmc.log('%s Signed out of %s: taken out of the shared backup; every Kodi on this device signs out '
                 'too.' % (LOG_TAG, ', '.join(names)), xbmc.LOGINFO)
        return names
    except Exception as e:
        xbmc.log('%s Could not record the sign-out: %s' % (LOG_TAG, e), xbmc.LOGWARNING)
        return []


def note_signed_in(before, after=None):
    """
    A deliberate sign-in on this Kodi (1.4.9): a sign-in `after` holds that `before` did not is no longer
    'revoked', even when it is the very value a Revoke marked. Found on the bench 2026-11-10: MDBList Revoke,
    then Authorize with the SAME API key typed in again, and the marker would have taken the key straight back
    out of this Kodi and its add-ons at the next five-minute look. A token is new at every sign-in, so only
    keys and passwords typed again could meet this. Returns the names cleared.
    """
    if after is None:
        after = _own_settings()[1]
    before = before or {}
    came = [g for g in GROUPS if _has(after, g[3]) and
            (not _has(before, g[3]) or fingerprint(before, g[3]) != fingerprint(after, g[3]))]
    if not came:
        return []
    try:
        store, meta = read_store()
        names = []
        for tag, name, _keys, signed in came:
            fp = fingerprint(after, signed)
            marked = meta['revoked'].get(tag)
            if not marked or fp not in marked.get('fps', ()):
                continue
            marked['fps'] = [f for f in marked['fps'] if f != fp]
            if not marked['fps']:
                meta['revoked'].pop(tag, None)
            names.append(name)
        if not names:
            return []
        if not storage.ensure_dir():
            return []
        _write_store(store, meta)
        xbmc.log('%s Signed in again to %s: no longer marked as signed out.' % (LOG_TAG, ', '.join(names)), xbmc.LOGINFO)
        return names
    except Exception as e:
        xbmc.log('%s Could not record the sign-in: %s' % (LOG_TAG, e), xbmc.LOGWARNING)
        return []


def revoked_here(current=None):
    """The services (tag, name, keys) this Kodi holds that a Revoke on another Kodi ended (revokes.py)."""
    if current is None:
        current = _own_settings()[1]
    meta = read_store()[1]
    hits = []
    for tag, name, keys, signed in GROUPS:
        if _has(current, signed) and _is_revoked(meta, tag, fingerprint(current, signed)):
            hits.append((tag, name, keys))
    return hits


def stored():
    """
    The sign-ins in the store as a dict, without writing anything ({} when there is no vault
    or it cannot be read). For a caller that wants one value from the backup, not a restore.
    """
    try:
        return read_store()[0]
    except Exception as e:
        xbmc.log('%s Could not read the vault: %s' % (LOG_TAG, str(e)), xbmc.LOGINFO)
        return {}


def restore():
    """
    Write every stored credential back into addon settings.
    Returns True on success.
    """
    try:
        if not os.path.isfile(_vault_file()):
            xbmc.log('%s No vault file found - nothing to restore.' % LOG_TAG, xbmc.LOGINFO)
            return False
        credentials = read_store()[0]
        if not credentials:
            xbmc.log('%s The vault holds nothing to restore.' % LOG_TAG, xbmc.LOGINFO)
            return False
        addon = own_settings.addon()
        for key, val in credentials.items():
            addon.setSetting(key, val)
        from reauthorize.modules import owner   # owner imports vault, so not at the top
        owner.claim()

        xbmc.log('%s Credentials restored from vault.' % LOG_TAG, xbmc.LOGINFO)
        return True
    except Exception as e:
        xbmc.log('%s Restore failed: %s' % (LOG_TAG, str(e)), xbmc.LOGWARNING)
        return False


def clear():
    """Delete the vault file and the merged copy beside it. Returns True on success."""
    try:
        path = _vault_file()
        keep = storage.keep_path()
        if keep and os.path.isfile(keep):
            os.remove(keep)
        if os.path.isfile(path):
            os.remove(path)
            own_settings.addon().setSetting('vault.last_backup', '')
            xbmc.log('%s Vault cleared.' % LOG_TAG, xbmc.LOGINFO)
        return True
    except Exception as e:
        xbmc.log('%s Clear failed: %s' % (LOG_TAG, str(e)), xbmc.LOGWARNING)
        return False


def vault_has_data():
    """Returns True if a vault backup file exists and is readable."""
    path = _vault_file()
    if not os.path.isfile(path):
        return False
    try:
        with open(path, 'r', encoding='utf-8') as f:
            data = json.loads(f.read())
        return bool(data.get('data'))
    except Exception:
        return False


def credentials_are_empty():
    """
    Returns True if all primary credential keys are blank.
    This indicates the addon_data was wiped (e.g. by a build install).
    """
    addon = own_settings.addon()
    return all(addon.getSetting(k) == '' for k in PRIMARY_KEYS)


def restore_missing_keys():
    """
    Fill in from the store what this Kodi's settings lack: each sign-in whole (never half from the
    server's copy and half from the vault), and any other setting that is empty.
    Called after server auto-restore to fill in any keys the server didn't have
    (e.g. Simkl authorized after the last server backup).
    Returns True if at least one key was filled in.
    """
    if not os.path.isfile(_vault_file()):
        return False
    try:
        credentials = read_store()[0]
        addon, current = _own_settings()
        filled = 0
        for _tag, _name, keys, signed in GROUPS:
            whole = _has(credentials, signed) and not _has(current, signed)
            parts = not _has(credentials, signed) and not _has(current, signed)
            for key in keys:
                if credentials.get(key) and (whole or (parts and not current.get(key))):
                    addon.setSetting(key, credentials[key])
                    filled += 1
        for key, val in credentials.items():
            if key not in _GROUPED and val and not current.get(key):
                addon.setSetting(key, val)
                filled += 1
        if filled:
            from reauthorize.modules import owner
            owner.claim()
            xbmc.log('%s Filled in %d missing key(s) from vault.' % (LOG_TAG, filled), xbmc.LOGINFO)
        return filled > 0
    except Exception as e:
        xbmc.log('%s restore_missing_keys failed: %s' % (LOG_TAG, str(e)), xbmc.LOGWARNING)
        return False


def auto_restore():
    """
    Called at startup before syncing.
    If credentials are missing but a vault backup exists, restore silently.
    Returns True if a restore was performed.
    Note: vault.enabled only gates new backups, not restore of existing data.
    """
    if credentials_are_empty() and vault_has_data():
        xbmc.log('%s Credential wipe detected \u2014 auto-restoring from vault...' % LOG_TAG, xbmc.LOGINFO)
        return restore()
    return False
