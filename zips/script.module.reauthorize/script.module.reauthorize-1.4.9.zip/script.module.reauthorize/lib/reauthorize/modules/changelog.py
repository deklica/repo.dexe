# -*- coding: utf-8 -*-
"""
    ReAuthorize - About -> Changelog: shows changelog.txt in ReAuthorize's text window.
"""
from reauthorize.modules.control import addonPath, addonVersion, joinPath
from reauthorize.windows.textviewer import TextViewerXML


def get():
    path = addonPath()
    try:
        with open(joinPath(path, 'changelog.txt'), 'r', encoding='utf-8', errors='ignore') as f:
            text = f.read()
    except Exception:
        text = 'No changelog available.'
    heading = '[B]ReAuthorize - v%s - Changelog[/B]' % addonVersion()
    TextViewerXML('textviewer.xml', path, heading=heading, text=text).run()
