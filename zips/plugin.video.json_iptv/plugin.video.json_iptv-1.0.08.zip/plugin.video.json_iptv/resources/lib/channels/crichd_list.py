# Made From  https://www.github.com/sabbiriptv  Added In By User Request.

channels = [
    {"title": "Astro Cricket HD", "url": "https://crichd-sabbiriptv.vercel.app/api?id=astrocric", "image": "https://upload.wikimedia.org/wikipedia/commons/b/b7/Astro_Cricket.png"},
    {"title": "Bein Sports 1 English", "url": "https://crichd-sabbiriptv.vercel.app/api?id=bein1en", "image": "https://i.postimg.cc/GpCtMcnz/Bein-Sports-HD-1.png"},
    {"title": "Bein Sports 3 English", "url": "https://crichd-sabbiriptv.vercel.app/api?id=bein3en", "image": "https://i.postimg.cc/Z5k6Szhv/Bein-Sports-HD-3.png"},
    {"title": "BT Sport 1", "url": "https://crichd-sabbiriptv.vercel.app/api?id=bbtsp1", "image": "https://i.postimg.cc/4d2Cq1qw/BT-Sports-1-HD.png"},
    {"title": "BT Sport 2", "url": "https://crichd-sabbiriptv.vercel.app/api?id=bbtsp2", "image": "https://i.postimg.cc/RZTvGwSp/BT-Sports-2-HD.png"},
    {"title": "BT Sport 3", "url": "https://crichd-sabbiriptv.vercel.app/api?id=bbtsp3", "image": "https://i.postimg.cc/Jh4MFttr/BT-Sports-3-HD.png"},
    {"title": "BT Sport 4", "url": "https://crichd-sabbiriptv.vercel.app/api?id=bbtespn", "image": "https://i.postimg.cc/K4SmpN3w/BT-Sport-4.png"},
    {"title": "EuroSport 1", "url": "https://crichd-sabbiriptv.vercel.app/api?id=eurosp1", "image": "https://i.postimg.cc/K8s3JXvH/Eurosport-1.png"},
    {"title": "EuroSport 2", "url": "https://crichd-sabbiriptv.vercel.app/api?id=eurosp2", "image": "https://i.postimg.cc/Px1LXPbg/Eurosport-2.png"},
    {"title": "Fox Cricket 501 HD", "url": "https://crichd-sabbiriptv.vercel.app/api?id=fox501", "image": "https://i.postimg.cc/Gp4ZWDPj/Fox-Cricket.png"},
    {"title": "LaLiga TV", "url": "https://crichd-sabbiriptv.vercel.app/api?id=laligauk", "image": "https://i.postimg.cc/mkMPrhYx/La-Liga-TV.png"},
    {"title": "Sky Sports Action", "url": "https://crichd-sabbiriptv.vercel.app/api?id=skysact", "image": "https://i.postimg.cc/t70T6yXK/Sky-Sports-Action.png"},
    {"title": "Sky Sports Arena", "url": "https://crichd-sabbiriptv.vercel.app/api?id=skysare", "image": "https://i.postimg.cc/PqG5FdYN/Sky-Sports-Arena.png"},
    {"title": "Sky Sports Cricket", "url": "https://crichd-sabbiriptv.vercel.app/api?id=skyscric", "image": "https://i.postimg.cc/x1J5Y37q/Sky-Sports-Cricket.png"},
    {"title": "Sky Sports F1", "url": "https://crichd-sabbiriptv.vercel.app/api?id=skysfor1", "image": "https://i.postimg.cc/63t5tzHX/Sky-Sports-F1.png"},
    {"title": "Sky Sports Football", "url": "https://crichd-sabbiriptv.vercel.app/api?id=skysfott", "image": "https://i.postimg.cc/7LPgh1tg/Sky-Sports-Football.png"},
    {"title": "Sky Sports Golf", "url": "https://crichd-sabbiriptv.vercel.app/api?id=skysgol", "image": "https://i.postimg.cc/qB1x3FHz/Sky-Sports-Golf.png"},
    {"title": "Sky Sports Main Event", "url": "https://crichd-sabbiriptv.vercel.app/api?id=skysme", "image": "https://i.postimg.cc/nr32VRp9/Sky-Sports-Main-Event.png"},
    {"title": "Sky Sports Mix", "url": "https://crichd-sabbiriptv.vercel.app/api?id=skysmixx", "image": "https://i.postimg.cc/zDdXYCKs/Sky-Sports-Mix.png"},
    {"title": "Sky Sports Premier League", "url": "https://crichd-sabbiriptv.vercel.app/api?id=skysprem", "image": "https://i.postimg.cc/85jMBpSc/Sky-Sports-Premiere-League.png"},
    {"title": "Star Sports 1 HD", "url": "https://crichd-sabbiriptv.vercel.app/api?id=star1in", "image": "https://i.postimg.cc/mD2B8h2h/Star-Sports-1-HD.png"},
    {"title": "Star Sports 1 Hindi HD", "url": "https://crichd-sabbiriptv.vercel.app/api?id=starhindi", "image": "https://i.postimg.cc/tg9j476D/Star-Sports-1-HD-Hindi.png"},
    {"title": "ViaplayXtra", "url": "https://crichd-sabbiriptv.vercel.app/api?id=viaplayextra", "image": "https://media.info/i/lf/0/1672512690/6781.png"},
    {"title": "Willow HD", "url": "https://crichd-sabbiriptv.vercel.app/api?id=willowusa", "image": "https://i.postimg.cc/XNCwDYR6/Willow.png"},
    {"title": "Willow Xtra", "url": "https://crichd-sabbiriptv.vercel.app/api?id=willowextra", "image": "https://i.postimg.cc/KvQw4fJN/Willow-Xtra.png"}
]


