
channels = [


    {"title": "88Rising", "url": "https://cdnvod.panda-os.com/livehls/5ed9a29c6986fb6bea212262/master.m3u8", "image": "https://static.panda-os.com/p/3572/sp/357200/thumbnail/entry_id/0_uz4j1z8j/version/100012/width/80/height/45/type/3/bgcolor/000000/a.jpg"},
    {"title": "Curve The Runway", "url": "https://cdnvod.panda-os.com/livehls/5f8797b06986fb5857764663/master.m3u8", "image": "https://static.panda-os.com/p/3572/sp/357200/thumbnail/entry_id/0_h6fo0x66/version/100022/width/80/height/45/type/3/bgcolor/000000/a.jpg"},
    {"title": "Dance 24x7", "url": "https://cdnvod.panda-os.com/livehls/5e945d266986fb1f2c30e082/master.m3u8", "image": "https://static.panda-os.com/p/3572/sp/357200/thumbnail/entry_id/0_t0930ej6/version/100042/width/80/height/45/type/3/bgcolor/000000/a.jpg"},
    {"title": "Freeli Live", "url": "https://cdnvod.panda-os.com/livehls/5ec5fb726986fb513c649493/master.m3u8", "image": "https://static.panda-os.com/p/3572/sp/357200/thumbnail/entry_id/0_wwsjvc7g/version/100012/width/80/height/45/type/3/bgcolor/000000/a.jpg"},
    {"title": "HollyWood TV", "url": "https://cdnvod.panda-os.com/livehls/5f23e1986986fb7a5c43ed42/master.m3u8", "image": "https://i.imgur.com/Wp71pit.jpg"},
    {"title": "Maverick Drama", "url": "https://cdnvod.panda-os.com/livehls/60c2bb08063044315955540c/master.m3u8", "image": "https://static.panda-os.com/p/3572/sp/357200/thumbnail/entry_id/0_0t5nh2rl/version/100042/width/80/height/45/type/3/bgcolor/000000/a.jpg"},
    {"title": "Maverick Hits", "url": "https://cdnvod.panda-os.com/livehls/60c2b556063044309e2091b1/master.m3u8", "image": "https://static.panda-os.com/p/3572/sp/357200/thumbnail/entry_id/0_url69ar7/version/100082/width/80/height/45/type/3/bgcolor/000000/a.jpg"},
    {"title": "Maverick Thriller", "url": "https://cdnvod.panda-os.com/livehls/60c2ba6e06304401fe28dd07/master.m3u8", "image": "https://static.panda-os.com/p/3572/sp/357200/thumbnail/entry_id/0_5af4kmv7/version/100072/width/80/height/45/type/3/bgcolor/000000/a.jpg"},
    {"title": "Maverick Women", "url": "https://cdnvod.panda-os.com/livehls/60c2bc40063044023226fb71/master.m3u8", "image": "https://static.panda-os.com/p/3572/sp/357200/thumbnail/entry_id/0_t6d19x7t/version/100042/width/80/height/45/type/3/bgcolor/000000/a.jpg"},
    {"title": "Music Video", "url": "https://cdnvod.panda-os.com/livehls/5e93c2786986fb50896c7242/master.m3u8", "image": "https://static.panda-os.com/p/3572/sp/357200/thumbnail/entry_id/0_ryt2f991/version/100032/width/80/height/45/type/3/bgcolor/000000/a.jpg"},
    {"title": "One In A Million", "url": "https://cdnvod.panda-os.com/livehls/5e9350ce6986fb05aa0813e2/master.m3u8", "image": "https://static.panda-os.com/p/3572/sp/357200/thumbnail/entry_id/0_swkn8i2t/version/100022/width/80/height/45/type/3/bgcolor/000000/a.jpg"},
    {"title": "PlugeedTV", "url": "https://cdnvod.panda-os.com/livehls/5f94a9b96986fb2fd93c2d72/master.m3u8", "image": "https://i.imgur.com/UAF5Dcs.jpg"},
    {"title": "Praise Freeli", "url": "https://cdnvod.panda-os.com/livehls/5e93c3216986fb55964665d2/master.m3u8", "image": "https://static.panda-os.com/p/3572/sp/357200/thumbnail/entry_id/0_6yc71nbm/version/100022/width/80/height/45/type/3/bgcolor/000000/a.jpg"},
    {"title": "R&B Gospel Mix", "url": "https://cdnvod.panda-os.com/livehls/5e93c19f6986fb50be3b27f3/master.m3u8", "image": "https://static.panda-os.com/p/3572/sp/357200/thumbnail/entry_id/0_psqjhulb/version/100022/width/80/height/45/type/3/bgcolor/000000/a.jpg"},
    {"title": "R&B Mix", "url": "https://cdnvod.panda-os.com/livehls/5e93c0466986fb4faf5e2473/master.m3u8", "image": "https://static.panda-os.com/p/3572/sp/357200/thumbnail/entry_id/0_w0u5eu25/version/100022/width/80/height/45/type/3/bgcolor/000000/a.jpg"},
    {"title": "She Said Yes!", "url": "https://cdnvod.panda-os.com/livehls/5e93ba336986fb4d07229e33/master.m3u8", "image": "https://static.panda-os.com/p/3572/sp/357200/thumbnail/entry_id/0_p0rdn4dr/version/100022/width/80/height/45/type/3/bgcolor/000000/a.jpg"},
    {"title": "The BeeHive", "url": "https://cdnvod.panda-os.com/livehls/5e93c1fa6986fb50c1494293/master.m3u8", "image": "https://static.panda-os.com/p/3572/sp/357200/thumbnail/entry_id/0_1cc1ld9z/version/100042/width/80/height/45/type/3/bgcolor/000000/a.jpg"},
    {"title": "The Hussle", "url": "https://cdnvod.panda-os.com/livehls/5e9356ec6986fb082929e7b2/master.m3u8", "image": "https://static.panda-os.com/p/3572/sp/357200/thumbnail/entry_id/0_4c2tqf3l/version/100022/width/80/height/45/type/3/bgcolor/000000/a.jpg"},
    {"title": "Throwback TV", "url": "https://cdnvod.panda-os.com/livehls/5e93c2c36986fb52613f54a2/master.m3u8", "image": "https://static.panda-os.com/p/3572/sp/357200/thumbnail/entry_id/0_fp8fzo9y/version/100062/width/80/height/45/type/3/bgcolor/000000/a.jpg"},
    {"title": "Trailler Park", "url": "https://cdnvod.panda-os.com/livehls/5e93a8176986fb471a4a1242/master.m3u8", "image": "https://static.panda-os.com/p/3572/sp/357200/thumbnail/entry_id/0_4nu3dwac/version/100032/width/80/height/45/type/3/bgcolor/000000/a.jpg"},
    {"title": "Watch Freeli", "url": "https://cdnvod.panda-os.com/livehls/5e1542666986fb0e5f6d0f83/master.m3u8", "image": "https://static.panda-os.com/p/3572/sp/357200/thumbnail/entry_id/0_qu9wk71m/version/100122/width/80/height/45/type/3/bgcolor/000000/a.jpg"},


]


