
channels = [


    {"title": "A8 ESports", "url": "https://stream.ads.ottera.tv/playlist.m3u8?network_id=744", "image": "https://i.imgur.com/efxLMby.jpg"},
    {"title": "AStar Entertainement", "url": "https://stream.ads.ottera.tv/playlist.m3u8?network_id=833", "image": "https://i.imgur.com/O2JAQ1U.jpg"},
    {"title": "Black Belt", "url": "https://stream.ads.ottera.tv/playlist.m3u8?network_id=749", "image": "https://i.imgur.com/5m7jsVb.jpg"},
    {"title": "Combat Go", "url": "https://stream.ads.ottera.tv/playlist.m3u8?network_id=671", "image": "https://i.imgur.com/luOs4OP.jpg"},
    {"title": "Dance Go TV", "url": "https://stream.ads.ottera.tv/playlist.m3u8?network_id=708", "image": "https://i.imgur.com/GcScQHi.jpg"},
    {"title": "ESport 24", "url": "https://stream.ads.ottera.tv/playlist.m3u8?network_id=667", "image": "https://i.imgur.com/5Yt923r.jpg"},
    {"title": "ESportz India", "url": "https://stream.ads.ottera.tv/playlist.m3u8?network_id=799", "image": "https://i.imgur.com/WVdLIJV.jpg"},
    {"title": "Face To Face", "url": "https://stream.ads.ottera.tv/playlist.m3u8?network_id=755", "image": "https://i.imgur.com/ogMyWXn.jpg"},
    {"title": "Faith And Family", "url": "https://stream.ads.ottera.tv/playlist.m3u8?network_id=838", "image": "https://i.imgur.com/lmOPCKe.jpg"},
    {"title": "Front Row Channel", "url": "https://stream.ads.ottera.tv/playlist.m3u8?network_id=837", "image": "https://i.imgur.com/DI9XWjO.jpg"},
    {"title": "Go Russia Cinema", "url": "https://stream.ads.ottera.tv/playlist.m3u8?network_id=748", "image": "https://i.imgur.com/cNUfBh1.jpg"},
    {"title": "Go Russia TV", "url": "https://stream.ads.ottera.tv/playlist.m3u8?network_id=747", "image": "https://i.imgur.com/EX1btEU.jpg"},
    {"title": "Great Animal Adventures", "url": "https://stream.ads.ottera.tv/playlist.m3u8?network_id=798", "image": "https://i.imgur.com/YvNE6au.jpg"},
    {"title": "HallyPop", "url": "https://stream.ads.ottera.tv/playlist.m3u8?network_id=670", "image": "https://i.imgur.com/7jmMhdn.jpg"},
    {"title": "HK Open TV", "url": "https://stream.ads.ottera.tv/playlist.m3u8?network_id=746", "image": "https://i.imgur.com/OZMZItN.jpg"},
    {"title": "Hoy Pinoy", "url": "https://stream.ads.ottera.tv/playlist.m3u8?network_id=709", "image": "https://i.imgur.com/fNoZoLP.jpg"},
    {"title": "Kick Flix", "url": "https://stream.ads.ottera.tv/playlist.m3u8?network_id=706", "image": "https://i.imgur.com/Ymq2zFI.jpg"},
    {"title": "ScreamFlix", "url": "https://stream.ads.ottera.tv/playlist.m3u8?network_id=864", "image": "https://i.imgur.com/BU7P9Ap.jpg"},
    {"title": "The DR.OZ Channel", "url": "https://stream.ads.ottera.tv/playlist.m3u8?network_id=834", "image": "https://i.imgur.com/sQxF7IK.jpg"},
    {"title": "Toro TV", "url": "https://stream.ads.ottera.tv/playlist.m3u8?network_id=793", "image": "https://i.imgur.com/UlAnw5s.jpg"},
    {"title": "Waah!!", "url": "https://stream.ads.ottera.tv/playlist.m3u8?network_id=832", "image": "https://i.imgur.com/nPKgjcg.jpg"},
    {"title": "WOW Mali", "url": "https://stream.ads.ottera.tv/playlist.m3u8?network_id=835", "image": "https://i.imgur.com/lHFJXYv.jpg"},


]


