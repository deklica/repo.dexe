
channels = [


    {"title": "American Classic Entertainment", "url": "https://104.143.4.5:12000/aspen.m3u8", "image": "https://www.glewed.tv/wp-content/uploads/2022/01/ACEv2-300x450.jpg"},
    {"title": "AWE Encore/Plus", "url": "https://cdn.herringnetwork.com/80A4DFF/awee_nva/AWE_Encore.m3u8", "image": "https://www.glewed.tv/wp-content/uploads/2020/08/AWE-Plus-Channel-Logo-300x450.jpg"},
    {"title": "AXS TV Now", "url": "https://stream.ads.ottera.tv/playlist.m3u8?network_id=856", "image": "https://www.glewed.tv/wp-content/uploads/2022/01/AXSTV_NOW_Poster-300x450.jpg"},
    {"title": "Biz TV", "url": "https://thegateway.app/BizAndYou/LimeLightBizTV/playlist.m3u8", "image": "https://www.glewed.tv/wp-content/uploads/2020/06/BizTVPoster-300x450.jpg"},
    {"title": "CampusLore", "url": "https://linear-235.frequency.stream/dist/glewedtv/235/hls/master/playlist.m3u8", "image": "https://www.glewed.tv/wp-content/uploads/2021/09/CampusLorePoster.jpg-300x450.png"},
    {"title": "Choppertown", "url": "https://linear-11.frequency.stream/dist/glewedtv/11/hls/master/playlist.m3u8", "image": "https://www.glewed.tv/wp-content/uploads/2021/10/choppertown-glewed-logo-v2-300x450.jpg"},
    {"title": "DeFiance Media", "url": "https://amg01529-defiancetv-defiancemedia-glewed-tre8x.amagi.tv/playlist.m3u8", "image": "None"},
    {"title": "DeFiance Media", "url": "https://linear-68.frequency.stream/dist/glewedtv/68/hls/master/playlist.m3u8", "image": "https://www.glewed.tv/wp-content/uploads/2021/05/DeFiance600x900-300x450.png"},
    {"title": "Estrella News", "url": "https://estrellanews-glewed.amagi.tv/playlist.m3u8", "image": "https://www.glewed.tv/wp-content/uploads/2020/10/en-300x450.png"},
    {"title": "Estrella TV", "url": "https://estrellatv-glewed.amagi.tv/glewed.m3u8", "image": "https://www.glewed.tv/wp-content/uploads/2020/10/etv-300x450.png"},
    {"title": "Estrella TV", "url": "https://estrellatv-glewed.amagi.tv/playlist.m3u8", "image": "None"},
    {"title": "Fite", "url": "https://cdn-cf.fite.tv/linear/fite247/playlist.m3u8", "image": "https://www.glewed.tv/wp-content/uploads/2020/06/FitePoster-300x450.jpg"},
    {"title": "Fun Roads TV", "url": "https://104.143.4.5:2080/funroads.m3u8", "image": "https://www.glewed.tv/wp-content/uploads/2020/07/FunRoadsTVPoster-300x450.jpg"},
    {"title": "Living Modern", "url": "https://2-fss-2.streamhoster.com/pl_138/amlst:201686-1312888/playlist.m3u8", "image": "https://www.glewed.tv/wp-content/uploads/2021/01/LM-GLEWED-300x450.png"},
    {"title": "Made in Hollywood", "url": "https://ov.ottera.tv/live/master.m3u8?channel=mvf_mh", "image": "https://www.glewed.tv/wp-content/uploads/2021/06/MIH-300x450.jpg"},
    {"title": "Newsy", "url": "https://content.uplynk.com/channel/cefe41803ff84cc9a2e277c61b0c6a5e.m3u8", "image": "https://www.glewed.tv/wp-content/uploads/2020/09/NewsyPosterV2-300x450.jpg"},
    {"title": "OAN Encore/Plus", "url": "https://cdn.herringnetwork.com/80A4DFF/oane_oregon/OAN_Encore.m3u8", "image": "https://www.glewed.tv/wp-content/uploads/2020/08/OAN-Plus-Channel-Logo-300x450.jpg"},
    {"title": "Pursuit UP", "url": "https://linear-205.frequency.stream/dist/glewedtv/205/hls/master/playlist.m3u8", "image": "https://www.glewed.tv/wp-content/uploads/2021/07/PursuitUpPoster-300x450.jpg"},
    {"title": "SurvivorNet TV", "url": "https://linear-178.frequency.stream/dist/glewedtv/178/hls/master/playlist.m3u8", "image": "https://www.glewed.tv/wp-content/uploads/2021/05/newSurvivorNetTV600x900-300x450.png"},
    {"title": "Swerve Sports", "url": "https://linear-253.frequency.stream/dist/glewedtv/253/hls/master/playlist.m3u8", "image": "https://www.glewed.tv/wp-content/uploads/2021/12/SwerveSports-1-300x450.jpg"},
    {"title": "The First", "url": "https://redseat-thefirst-glewedtv.amagi.tv/index.m3u8", "image": "https://www.glewed.tv/wp-content/uploads/2020/06/TheFirstPoster-300x450.jpg"},
    {"title": "The Jet Set Network", "url": "https://c.streamhoster.com/link/hls/WwsdfD/SjBk6Q5smzo/r/JETSETNET/playlist.m3u8", "image": "https://www.glewed.tv/wp-content/uploads/2021/01/JSN_GLEWED-300x450.png"},
    {"title": "True History", "url": "https://linear-188.frequency.stream/dist/glewedtv/188/hls/master/playlist.m3u8", "image": "https://www.glewed.tv/wp-content/uploads/2021/10/TrueHistory_ChannelTile-300x450.jpg"},
    {"title": "WION TV (World is One News)", "url": "https://d1tdkdc0esjoxj.cloudfront.net/out/v1/f2054baeb8e94043bfc9c8cca2a0013d/index.m3u8", "image": "https://www.glewed.tv/wp-content/uploads/2021/02/600x900-WION-Network-300x450.jpg"},
    {"title": "YouToo America", "url": "https://thegateway.app/YouToo/YTamerica/playlist.m3u8", "image": "https://www.glewed.tv/wp-content/uploads/2020/06/YouTooAmericaPoster-300x450.jpg"},


]


