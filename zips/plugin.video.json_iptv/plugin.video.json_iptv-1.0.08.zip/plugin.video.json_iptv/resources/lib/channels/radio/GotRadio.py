
channels = [


    {"title": "90s Alternative", "url": "https://pureplay.cdnstream1.com/6039_64.aac/playlist.m3u8", "image": "https://i.imgur.com/H0NrLei.jpg"},
    {"title": "Adult Alternative", "url": "https://pureplay.cdnstream1.com/6032_64.aac/playlist.m3u8", "image": "https://i.imgur.com/8wdP5Ec.jpg"},
    {"title": "Adult Hits!", "url": "https://pureplay.cdnstream1.com/6022_64.aac/playlist.m3u8", "image": "https://i.imgur.com/azRBx6v.jpg"},
    {"title": "Alternative Rock", "url": "https://pureplay.cdnstream1.com/6033_64.aac/playlist.m3u8", "image": "https://i.imgur.com/iU0I6eK.jpg"},
    {"title": "Americana", "url": "https://pureplay.cdnstream1.com/6046_64.aac/playlist.m3u8", "image": "https://i.imgur.com/D0bMzPA.jpg"},
    {"title": "Big Band Land", "url": "https://pureplay.cdnstream1.com/6004_64.aac/playlist.m3u8", "image": "https://i.imgur.com/Fg3rjfs.jpg"},
    {"title": "Bit O Blues", "url": "https://pureplay.cdnstream1.com/6019_64.aac/playlist.m3u8", "image": "https://i.imgur.com/BZT5MIp.png"},
    {"title": "Bluegrass", "url": "https://pureplay.cdnstream1.com/6000_64.aac/playlist.m3u8", "image": "https://i.imgur.com/LGvLqTQ.jpg"},
    {"title": "Classic Country", "url": "https://pureplay.cdnstream1.com/6048_64.aac/playlist.m3u8", "image": "https://i.imgur.com/0pvMjhr.jpg"},
    {"title": "Classic Rock", "url": "https://pureplay.cdnstream1.com/6012_64.aac/playlist.m3u8", "image": "https://i.imgur.com/mYV4hph.jpg"},
    {"title": "Disco", "url": "https://pureplay.cdnstream1.com/6055_64.aac/playlist.m3u8", "image": "https://i.imgur.com/GrsMAzP.jpg"},
    {"title": "Folk Lore", "url": "https://pureplay.cdnstream1.com/6001_64.aac/playlist.m3u8", "image": "https://i.imgur.com/CwhwoTV.jpg"},
    {"title": "Girl Power", "url": "https://pureplay.cdnstream1.com/6006_64.aac/playlist.m3u8", "image": "https://i.imgur.com/5V29kBS.jpg"},
    {"title": "Guitar Genius", "url": "https://pureplay.cdnstream1.com/6018_64.aac/playlist.m3u8", "image": "https://i.imgur.com/WVGQXPW.jpg"},
    {"title": "Hip Hop Stop", "url": "https://pureplay.cdnstream1.com/6041_64.aac/playlist.m3u8", "image": "https://i.imgur.com/2rwScVL.jpg"},
    {"title": "Hot Hits - Todays Hits No Rap", "url": "https://pureplay.cdnstream1.com/6026_64.aac/playlist.m3u8", "image": "https://i.imgur.com/6F1cGwL.jpg"},
    {"title": "Jazz So Smooth", "url": "https://pureplay.cdnstream1.com/6049_64.aac/playlist.m3u8", "image": "https://i.imgur.com/ingdOO6.jpg"},
    {"title": "Jazz So True", "url": "https://pureplay.cdnstream1.com/6050_64.aac/playlist.m3u8", "image": "https://i.imgur.com/rLM9SyB.jpg"},
    {"title": "Metal Madness", "url": "https://pureplay.cdnstream1.com/6014_64.aac/playlist.m3u8", "image": "https://i.imgur.com/Nib5M9b.jpg"},
    {"title": "New Age Nuance", "url": "https://pureplay.cdnstream1.com/6016_64.aac/playlist.m3u8", "image": "https://i.imgur.com/RZgR2kY.jpg"},
    {"title": "Oldies", "url": "https://pureplay.cdnstream1.com/6007_64.aac/playlist.m3u8", "image": "https://i.imgur.com/AYgF88u.jpg"},
    {"title": "Piano Perfect", "url": "https://pureplay.cdnstream1.com/6017_64.aac/playlist.m3u8", "image": "https://i.imgur.com/tkJ90DP.jpg"},
    {"title": "R&B Classics", "url": "https://pureplay.cdnstream1.com/6023_64.aac/playlist.m3u8", "image": "https://i.imgur.com/Z3vhyZP.jpg"},
    {"title": "Rockin 80s", "url": "https://pureplay.cdnstream1.com/6008_64.aac/playlist.m3u8", "image": "https://i.imgur.com/9Lv4Doo.jpg"},
    {"title": "Soft Rock Cafe", "url": "https://pureplay.cdnstream1.com/6010_64.aac/playlist.m3u8", "image": "https://i.imgur.com/VkL8uKC.jpg"},
    {"title": "Southern Rock", "url": "https://pureplay.cdnstream1.com/6057_64.aac/playlist.m3u8", "image": "https://i.imgur.com/3UUDpYT.jpg"},
    {"title": "Texas Red Dirt Music", "url": "https://pureplay.cdnstream1.com/6028_64.aac/playlist.m3u8", "image": "https://i.imgur.com/I5stJ57.jpg"},
    {"title": "The 50s", "url": "https://pureplay.cdnstream1.com/6005_64.aac/playlist.m3u8", "image": "https://i.imgur.com/7MiBhZr.jpg"},
    {"title": "The 60s", "url": "https://pureplay.cdnstream1.com/6011_64.aac/playlist.m3u8", "image": "https://i.imgur.com/ydZ89km.jpg"},
    {"title": "The 70s", "url": "https://pureplay.cdnstream1.com/6013_64.aac/playlist.m3u8", "image": "https://i.imgur.com/TD5qewT.jpg"},
    {"title": "The 80s", "url": "https://pureplay.cdnstream1.com/6009_64.aac/playlist.m3u8", "image": "https://i.imgur.com/RHMDf5O.jpg"},
    {"title": "The 90s", "url": "https://pureplay.cdnstream1.com/6052_64.aac/playlist.m3u8", "image": "https://i.imgur.com/NIhkFof.jpg"},
    {"title": "The Mix -  80s 90s & Todays Hits!", "url": "https://pureplay.cdnstream1.com/6037_64.aac/playlist.m3u8", "image": "https://i.imgur.com/CxYv7NS.jpg"},
    {"title": "The Rock", "url": "https://pureplay.cdnstream1.com/6035_64.aac/playlist.m3u8", "image": "https://i.imgur.com/5GeqlHT.jpg"},
    {"title": "Throwback Jamz", "url": "https://pureplay.cdnstream1.com/6045_64.aac/playlist.m3u8", "image": "https://i.imgur.com/Qc4TwpQ.jpg"},
    {"title": "Today's Country", "url": "https://pureplay.cdnstream1.com/6029_64.aac/playlist.m3u8", "image": "https://i.imgur.com/fcU7cLj.jpg"},
    {"title": "Top 40", "url": "https://pureplay.cdnstream1.com/6024_64.aac/playlist.m3u8", "image": "https://i.imgur.com/lpkohJd.jpg"},
    {"title": "Urban Jamz", "url": "https://pureplay.cdnstream1.com/6044_64.aac/playlist.m3u8", "image": "https://i.imgur.com/QQEaX0k.jpg"},
    {"title": "Urban Lounge", "url": "https://pureplay.cdnstream1.com/6053_64.aac/playlist.m3u8", "image": "https://i.imgur.com/MVKpfWH.jpg"}


]


