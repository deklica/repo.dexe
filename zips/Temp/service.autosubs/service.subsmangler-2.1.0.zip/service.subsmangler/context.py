from resources.lib import contextmenu

# SubsMangler's context menu entry point
if __name__ == '__main__':
    contextmenu.main()