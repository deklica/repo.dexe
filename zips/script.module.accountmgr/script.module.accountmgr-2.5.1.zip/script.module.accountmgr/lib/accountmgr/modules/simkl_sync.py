import xbmc, xbmcaddon, xbmcgui
import xbmcvfs
import os

from pathlib import Path
from libs.common import var

#Account Manager Simkl
accountmgr = xbmcaddon.Addon("script.module.accountmgr")
your_username = accountmgr.getSetting("simkl.username") 
your_token = accountmgr.getSetting("simkl.token")
          
class Auth:
    def simkl_auth(self):       
    #Umbrella
        try:
                if xbmcvfs.exists(var.chk_umb) and xbmcvfs.exists(var.chkset_umb):
                        chk_auth_umb = xbmcaddon.Addon('plugin.video.umbrella').getSetting("simkltoken")
                        if not str(var.chk_accountmgr_tk_sk) == str(chk_auth_umb) or str(chk_auth_umb) == '':

                                with open(var.path_umb_sk,'r') as f:
                                    data = f.read()

                                client = data.replace(var.umb_client_sk,var.client_am_sk)

                                with open(var.path_umb_sk,'w') as f:
                                    f.write(client)

                                addon = xbmcaddon.Addon("plugin.video.umbrella")
                                addon.setSetting("simklusername", your_username)
                                addon.setSetting("simkltoken", your_token) 
        except:
                xbmc.log('%s: Umbrella Simkl Failed!' % var.amgr, xbmc.LOGINFO)
                pass
            
    #Otaku
        try:
                if xbmcvfs.exists(var.chk_otaku) and not xbmcvfs.exists(var.otaku_ud):
                        os.mkdir(var.otaku_ud)
                        xbmcvfs.copy(os.path.join(var.otaku), os.path.join(var.chkset_otaku))
                        
                if xbmcvfs.exists(var.chk_otaku) and not xbmcvfs.exists(var.chkset_otaku):
                        xbmcvfs.copy(os.path.join(var.otaku), os.path.join(var.chkset_otaku))

                if xbmcvfs.exists(var.chk_otaku) and xbmcvfs.exists(var.chkset_otaku):
                        chk_auth_otaku = xbmcaddon.Addon('plugin.video.otaku').getSetting("simkl.token")
                        if not str(var.chk_accountmgr_tk_sk) == str(chk_auth_otaku) or str(chk_auth_otaku) == '':

                                with open(var.path_otaku1_sk,'r') as f:
                                    data1 = f.read()

                                client1 = data1.replace(var.otaku_client_sk,var.client_am_sk)

                                with open(var.path_otaku1_sk,'w') as f:
                                    f.write(client1)

                                with open(var.path_otaku2_sk,'r') as f:
                                    data2 = f.read()

                                client2 = data2.replace(var.otaku_client_sk,var.client_am_sk)

                                with open(var.path_otaku2_sk,'w') as f:
                                    f.write(client2)

                                addon = xbmcaddon.Addon("plugin.video.otaku")
                                addon.setSetting("simkl.username", your_username)
                                addon.setSetting("simkl.token", your_token)
                                addon.setSetting("simkl.enabled", 'true')
        except:
                xbmc.log('%s: Otaku Simkl Failed!' % var.amgr, xbmc.LOGINFO)
                pass

    #Simkl TV Tracker
        try:
                if xbmcvfs.exists(var.chk_simkl) and not xbmcvfs.exists(var.simkl_ud):
                        os.mkdir(var.simkl_ud)
                        xbmcvfs.copy(os.path.join(var.simkl), os.path.join(var.chkset_simkl))
                        
                if xbmcvfs.exists(var.chk_simkl) and not xbmcvfs.exists(var.chkset_simkl):
                        xbmcvfs.copy(os.path.join(var.simkl), os.path.join(var.chkset_simkl))
                
                if xbmcvfs.exists(var.chk_simkl) and xbmcvfs.exists(var.chkset_simkl):
                        
                        chk_auth_simkl = xbmcaddon.Addon('script.simkl').getSetting("token")
                        if not str(var.chk_accountmgr_tk_sk) == str(chk_auth_simkl) or str(chk_auth_simkl) == '':

                                with open(var.path_simkl_sk,'r') as f:
                                    data = f.read()

                                client = data.replace(var.simkl_client_sk,var.client_am_sk)

                                with open(var.path_simkl_sk,'w') as f:
                                    f.write(client)
                                
                                addon = xbmcaddon.Addon("script.simkl")
                                addon.setSetting("token", your_token)
        except:
                xbmc.log('%s: Simkl TV Tracker Simkl Failed!' % var.amgr, xbmc.LOGINFO)
                pass
