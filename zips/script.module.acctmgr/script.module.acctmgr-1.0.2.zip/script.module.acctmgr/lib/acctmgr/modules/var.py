import xbmc, xbmcaddon, xbmcvfs, os

amgr = 'AM Lite ERROR'
addon_id = 'script.module.acctmgr'
addon = xbmcaddon.Addon(addon_id)
translatePath = xbmcvfs.translatePath
addons = translatePath('special://home/addons/')
addon_data = translatePath('special://profile/addon_data/')
xmls = addons + translatePath('script.module.acctmgr/resources/xmls/')

# AM Lite - Trakt API Keys
client_am = 'ce7457fe1e42f09919b57171e9196109717474bad5b13b2a70959aef2f8e5624'
secret_am = '004d641c35178c7d3c5798313919bec181e9a162bc84f16a2e78dc82a37150db'

# Fen Light Database Paths
fenlt_path = addon_data + translatePath('plugin.video.fenlight/databases/')
fenlt_settings_db = fenlt_path + translatePath('settings.db')

# Gears Database Paths
gears_path = addon_data + translatePath('plugin.video.gears/databases/')
gears_settings_db = gears_path + translatePath('settings.db')

# Remake Settings & Trakt Cache Variables
fenlt_name = 'Fen Light'
fenlt_id = 'plugin.video.fenlight'
gears_name = 'Gears'
gears_id = 'plugin.video.gears'

# Trakt Sync List Paths
acctmgr_datapath = translatePath('special://profile/addon_data/script.module.acctmgr/')
tk_sync_list = translatePath(os.path.join(acctmgr_datapath, 'trakt_sync_list.json'))

# Realizer Paths
realx_path = addon_data + translatePath('plugin.video.realizerx')
realx_json_path = realx_path + translatePath('rdauth.json')

# External Scraper Root Paths
chk_sc_coco = addons + translatePath('script.module.cocoscrapers/')
chk_sc_gears = addons + translatePath('script.module.gearsscrapers/')
chk_sc_mag = addons + translatePath('script.module.magneto/')
chk_sc_viper = addons + translatePath('script.module.viperscrapers/')

# External Scraper Repo ID's
coco = 'repository.cocoscrapers'
mag = 'repository.kodifitzwell'
gears = 'repository.chainsrepo'
viper = 'repository.oldsalt'

# External Scraper Plugin ID's
coco_plugin_id = 'script.module.cocoscrapers'
gears_plugin_id = 'script.module.gearsscrapers'
mag_plugin_id = 'script.module.magneto'
viper_plugin_id = 'script.module.viperscrapers'

#External Scraper Names (Fen Light/Fen & Forks)
coco_sc_name = 'CocoScrapers Module'
gears_sc_name = 'Gears Scrapers'
mag_sc_name = 'Magneto Module'
viper_sc_name = 'Viper Scrapers'

#External Scraper Names (Umbrella & Forks)
coco_umb_name = 'cocoScrapers'
gears_umb_name = 'gearsscrapers'
mag_umb_name = 'magneto'
viper_umb_name = 'viperscrapers'

# MaxQL Variables
QL_UHD = "uhd"
QL_HD  = "hd"
QL_SD  = "sd"


# ROOT ADD-ON PATHS
# Fen Light & Forks
chk_fenlt = addons + translatePath('plugin.video.fenlight/')#--------------Fen Light
chk_gears = addons + translatePath('plugin.video.gears/')#-----------------Fork / Gears
# Uniques
chk_umb = addons + translatePath('plugin.video.umbrella/')#----------------Umbrella
chk_seren = addons + translatePath('plugin.video.seren/')#-----------------Seren
# Fen & Forks
chk_fen = addons + translatePath('plugin.video.fen/')#---------------------Fen
chk_pov = addons + translatePath('plugin.video.pov/')#---------------------Fork / POV
chk_coal = addons + translatePath('plugin.video.coalition/')#--------------Fork / Coalition
# Dradis & Forks
chk_dradis = addons + translatePath('plugin.video.dradis/')#---------------Dradis
chk_genocide = addons + translatePath('plugin.video.genocide/')#-----------Fork / Genocide
# Shadow & Forks
chk_shadow = addons + translatePath('plugin.video.shadow/')#---------------Shadow
chk_ghost = addons + translatePath('plugin.video.ghost/')#-----------------Fork / Ghost
chk_chains = addons + translatePath('plugin.video.the chains/')#-----------Fork / The Chains
# Homelander & Forks
chk_home = addons + translatePath('plugin.video.homelander/')#-------------Homelander
chk_night = addons + translatePath('plugin.video.nightwing/')#-------------Fork / Nightwing
chk_absol = addons + translatePath('plugin.video.absolution/')#------------Fork / Jokers Absolution
# Others
chk_crew = addons + translatePath('plugin.video.thecrew/')#----------------The Crew
chk_scrubs = addons + translatePath('plugin.video.scrubsv2/')#-------------Scrubs V2
chk_otaku = addons + translatePath('plugin.video.otaku/')#-----------------Otaku
chk_tmdbh = addons + translatePath('plugin.video.themoviedb.helper/')#-----TMDb Helper
chk_trakt = addons + translatePath('script.trakt/')#-----------------------Trakt
# Debrid Only
chk_realx = addons + translatePath('plugin.video.realizerx/')#-------------Realizer
chk_premx = addons + translatePath('plugin.video.premiumizerx/')#----------Premiumizer
chk_rurl= addons + translatePath('script.module.resolveurl/')#-------------ResolveURL


# USERDATA PATHS
# Uniques
umb_ud = addon_data + translatePath('plugin.video.umbrella/')
seren_ud = addon_data + translatePath('plugin.video.seren/')
# Fen & Forks
fen_ud = addon_data + translatePath('plugin.video.fen/')
pov_ud = addon_data + translatePath('plugin.video.pov/')
coal_ud = addon_data + translatePath('plugin.video.coalition/')
# Dradis & Forks
dradis_ud = addon_data + translatePath('plugin.video.dradis/')
gears_ud = addon_data + translatePath('plugin.video.gears/')
genocide_ud = addon_data + translatePath('plugin.video.genocide/')
# Shadow & Forks
shadow_ud = addon_data + translatePath('plugin.video.shadow/')
ghost_ud = addon_data + translatePath('plugin.video.ghost/')
chains_ud = addon_data + translatePath('plugin.video.thechains/')
# Homelander & Forks
home_ud = addon_data + translatePath('plugin.video.homelander/')
night_ud = addon_data + translatePath('plugin.video.nightwing/')
absol_ud = addon_data + translatePath('plugin.video.absolution/')
# Others
crew_ud = addon_data + translatePath('plugin.video.thecrew/')
scrubs_ud = addon_data + translatePath('plugin.video.scrubsv2/')
otaku_ud = addon_data + translatePath('plugin.video.otaku/')
tmdbh_ud = addon_data + translatePath('plugin.video.themoviedb.helper/')
trakt_ud = addon_data + translatePath('script.trakt/')
# Debrid Only
realx_ud = addon_data + translatePath('plugin.video.realizerx/')
premx_ud = addon_data + translatePath('plugin.video.premiumizerx/')
rurl_ud = addon_data + translatePath('script.module.resolveurl/')


# SETTINGS PATHS
# Fen Light & Forks
chkset_fenlt = addon_data + translatePath('plugin.video.fenlight/databases/settings.db')
chkset_gears = addon_data + translatePath('plugin.video.gears/databases/settings.db')
# Uniques
chkset_umb = addon_data + translatePath('plugin.video.umbrella/settings.xml')
chkset_seren = addon_data + translatePath('plugin.video.seren/settings.xml')
# Fen & Forks
chkset_fen = addon_data + translatePath('plugin.video.fen/settings.xml')
chkset_pov = addon_data + translatePath('plugin.video.pov/settings.xml')
chkset_coal = addon_data + translatePath('plugin.video.coalition/settings.xml')
# Dradis & Forks
chkset_dradis = addon_data + translatePath('plugin.video.dradis/settings.xml')
chkset_genocide = addon_data + translatePath('plugin.video.genocide/settings.xml')
# Shadow & Forks
chkset_shadow = addon_data + translatePath('plugin.video.shadow/settings.xml')
chkset_ghost = addon_data + translatePath('plugin.video.ghost/settings.xml')
chkset_chains = addon_data + translatePath('plugin.video.thechains/settings.xml')
# Homelander & Forks
chkset_home = addon_data + translatePath('plugin.video.homelander/settings.xml')
chkset_night = addon_data + translatePath('plugin.video.nightwing/settings.xml')
chkset_absol = addon_data + translatePath('plugin.video.absolution/settings.xml')
# Others
chkset_crew = addon_data + translatePath('plugin.video.thecrew/settings.xml')
chkset_scrubs = addon_data + translatePath('plugin.video.scrubsv2/settings.xml')
chkset_otaku = addon_data + translatePath('plugin.video.otaku/settings.xml')
chkset_tmdbh = addon_data + translatePath('plugin.video.themoviedb.helper/settings.xml')
chkset_trakt = addon_data + translatePath('script.trakt/settings.xml')
# Debrid Only
chkset_realx = addon_data + translatePath('plugin.video.realizerx/settings.xml')
chkset_realx_json = addon_data + translatePath('plugin.video.realizerx/rdauth.json')
chkset_premx = addon_data + translatePath('plugin.video.premiumizerx/settings.xml')
chkset_rurl = addon_data + translatePath('script.module.resolveurl/settings.xml')


# DEFAULT SETTINGS XML's
# Shadow & Forks
shadow = xmls + translatePath('plugin.video.shadow/settings.xml')
ghost = xmls + translatePath('plugin.video.ghost/settings.xml')
chains = xmls + translatePath('plugin.video.thechains/settings.xml')
# Homelander & Forks
home = xmls + translatePath('plugin.video.homelander/settings.xml')
night = xmls + translatePath('plugin.video.nightwing/settings.xml')
absol = xmls + translatePath('plugin.video.absolution/settings.xml')
# Others
crew = xmls + translatePath('plugin.video.thecrew/settings.xml')
scrubs = xmls + translatePath('plugin.video.scrubsv2/settings.xml')
otaku = xmls + translatePath('plugin.video.otaku/settings.xml')
tmdbh = xmls + translatePath('plugin.video.themoviedb.helper/settings.xml')
# Debrid Only
trakt = xmls + translatePath('script.trakt/settings.xml')
realx = xmls + translatePath('plugin.video.realizerx/settings.xml')
realx_json = xmls + translatePath('plugin.video.realizerx/rdauth.json')
premx = xmls + translatePath('plugin.video.premiumizerx/settings.xml')
rurl = xmls + translatePath('script.module.resolveurl/settings.xml')


# DEFAULT TRAKT API KEY PATHS
path_umb = addons + translatePath('plugin.video.umbrella/resources/lib/modules/trakt.py')
path_seren = addons + translatePath('plugin.video.seren/resources/lib/indexers/trakt.py')

path_fen = addons + translatePath('plugin.video.fen/resources/lib/apis/trakt_api.py')

path_shadow = addons + translatePath('plugin.video.shadow/resources/menus.py')
path_ghost = addons + translatePath('plugin.video.ghost/resources/modules/general.py')

path_crew = addons + translatePath('script.module.thecrew/lib/resources/lib/modules/trakt.py')
path_scrubs = addons + translatePath('plugin.video.scrubsv2/resources/lib/modules/trakt.py')
path_tmdbh = addons + translatePath('plugin.video.themoviedb.helper/resources/tmdbhelper/lib/api/api_keys/trakt.py')
path_trakt = addons + translatePath('script.trakt/resources/lib/traktapi.py')


# VIDEO ADD-ONS - DEFAULT TRAKT API KEYS
fenlt_client = '1038ef327e86e7f6d39d80d2eb5479bff66dd8394e813c5e0e387af0f84d89fb'
fenlt_secret = '8d27a92e1d17334dae4a0590083a4f26401cb8f721f477a79fd3f218f8534fd1'

umb_client = '87e3f055fc4d8fcfd96e61a47463327ca877c51e8597b448e132611c5a677b13'
umb_secret = '4a1957a52d5feb98fafde53193e51f692fa9bdcd0cc13cf44a5e39975539edf0'

pov_client = '6bc29124c3d9466e06a3ed19a7b5976fcb28311008401e1ce04cf08196f8b16a'
pov_secret = '99478842b17d44d7accafef45c6c1bbba235792753c195069ae149595cd3a919'

dradis_client = '19d4a08f6601d2c5d791d041a9ffadd3ce26c038500070397eb315b74b5a7550'
dradis_secret = '3ee868bacbf9edba9dd11a1b26b1abe4f5b81d0f0d90bd30ac53e127af08be39'

seren_client = '0c9a30819e4af6ffaf3b954cbeae9b54499088513863c03c02911de00ac2de79'
seren_secret = 'bf02417f27b514cee6a8d135f2ddc261a15eecfb6ed6289c36239826dcdd1842'

fen_client = '645b0f46df29d27e63c4a8d5fff158edd0bef0a6a5d32fc12c1b82388be351af'
fen_secret = '422a282ef5fe4b5c47bc60425c009ac3047ebd10a7f6af790303875419f18f98'

shadow_client = '8ed545c0b7f92cc26d1ecd6326995c6cf0053bd7596a98e962a472bee63274e6'
shadow_secret = '1ec4f37e5743e3086abace0c83444c25d9b655d1d77b793806b2c8205a510426'

ghost_client = 'a4e716b4b22b62e59b9e09454435c8710b650b3143dcce553d252b6a66ba60c8'
ghost_secret = 'c6d9aba72214a1ca3c6d45d0351e59f21bbe43df9bbac7c5b740089379f8c5cd'

crew_client = '482f9db52ee2611099ce3aa1abf9b0f7ed893c6d3c6b5face95164eac7b01f71'
crew_secret = '80a2729728b53ba1cc38137b22f21f34d590edd35454466c4b8920956513d967'

scrubs_client = '63c53edc299b7a05cc6ea2272e8a84e13aade067c18a794362ab9a4a84eafb16'
scrubs_secret = '9163ebda9d33acd06c74d017e861404b7212ee34675e09e73365d7536b84eab6'

# Chains API Keys - Coalition / Gears / Genocide
chains_client = '19849909a0f8c9dc632bc5f5c7ccafd19f3e452e2e44fee05b83fd5dc1e77675'
chains_secret = 'b5fcd7cb5d9bb963784d11bbf8535bc0d25d46225016191eb48e50792d2155c0'

tmdbh_client = 'e6fde6173adf3c6af8fd1b0694b9b84d7c519cefc24482310e1de06c6abe5467'
tmdbh_secret = '15119384341d9a61c751d8d515acbc0dd801001d4ebe85d3eef9885df80ee4d9'

trakt_client = 'd4161a7a106424551add171e5470112e4afdaf2438e6ef2fe0548edc75924868'
trakt_secret = 'b5fcd7cb5d9bb963784d11bbf8535bc0d25d46225016191eb48e50792d2155c0'
