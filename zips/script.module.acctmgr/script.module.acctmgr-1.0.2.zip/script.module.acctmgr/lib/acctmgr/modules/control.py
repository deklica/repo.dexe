# -*- coding: utf-8 -*-
import xbmc, xbmcaddon, xbmcgui, xbmcvfs
import sys
import os
import importlib
import datetime
from acctmgr.modules import var
from acctmgr.modules import log_utils

#Variables
addon = xbmcaddon.Addon
addonObject = addon('script.module.acctmgr')
addonInfo = addonObject.getAddonInfo
getLangString = xbmcaddon.Addon().getLocalizedString
condVisibility = xbmc.getCondVisibility
execute = xbmc.executebuiltin
monitor = xbmc.Monitor()
translatePath = xbmcvfs.translatePath
joinPath = os.path.join
date = str(datetime.date.today())
dialog = xbmcgui.Dialog()
window = xbmcgui.Window(10000)
progressDialog = xbmcgui.DialogProgress()
existsPath = xbmcvfs.exists
openFile = xbmcvfs.File
makeFile = xbmcvfs.mkdir
progress_line = '%s[CR]%s[CR]%s'
char_remov = ["'", ",", ")","("]

# HELPERS
def iconsPath():
	return joinPath(addonInfo('path'), 'resources', 'icons')

def getKodiVersion():
	return int(xbmc.getInfoLabel("System.BuildVersion")[:2])

def _acctmgr():
    return xbmcaddon.Addon("script.module.acctmgr")

def setting(id):
    return _acctmgr().getSetting(id)

def setSetting(id, value):
    return _acctmgr().setSetting(id, value)

def lang(language_id):
	text = getLangString(language_id)
	return text

def sleep(time):
	while time > 0 and not monitor.abortRequested():
		xbmc.sleep(min(100, time))
		time = time - 100

def addonId():
	return addonInfo('id')

def addonName():
	return 'AM Lite'

def addonVersion():
	return addonInfo('version')

def addonIcon():
	return addonInfo('icon')

def addonPath():
	try: return translatePath(addonInfo('path').decode('utf-8'))
	except: return translatePath(addonInfo('path'))

def artPath():
	return os.path.join(xbmcaddon.Addon('script.module.acctmgr').getAddonInfo('path'), 'resources', 'icons')

def openSettings(query=None, id=addonInfo('id')):
	try:
		idle()
		execute('Addon.OpenSettings(%s)' % id)
		if query is None: return
		c, f = query.split('.')
		execute('SetFocus(%i)' % (int(c) - 100))
		execute('SetFocus(%i)' % (int(f) - 80))
	except:
		return

def idle():
	if condVisibility('Window.IsActive(busydialognocancel)'):
		return execute('Dialog.Close(busydialognocancel)')
        
def yesnoDialog(line, heading=addonInfo('name'), nolabel='', yeslabel=''):
	return dialog.yesno(heading, line, nolabel, yeslabel)

def selectDialog(list, heading=addonInfo('name')):
	return dialog.select(heading, list)

def okDialog(title=None, message=None):
	if title == 'default' or title is None: title = addonName()
	if isinstance(title, int): heading = lang(title)
	else: heading = str(title)
	if isinstance(message, int): body = lang(message)
	else: body = str(message)
	return dialog.ok(heading, body)

def closeAll():
	return execute('Dialog.Close(all, true)')

def jsondate_to_datetime(jsondate_object, resformat, remove_time=False):
	import _strptime
	from datetime import datetime
	import time
	if remove_time:
		try: datetime_object = datetime.strptime(jsondate_object, resformat).date()
		except TypeError: datetime_object = datetime(*(time.strptime(jsondate_object, resformat)[0:6])).date()
	else:
		try: datetime_object = datetime.strptime(jsondate_object, resformat)
		except TypeError: datetime_object = datetime(*(time.strptime(jsondate_object, resformat)[0:6]))
	return datetime_object

def set_active_monitor():
	window.setProperty('acctmgr.active', 'true')

def release_active_monitor():
	window.clearProperty('acctmgr.active')

def function_monitor(func, query='0.0'):
	func()
	sleep(100)
	openSettings(query)
	while not condVisibility('Window.IsVisible(addonsettings)'):
		sleep(250)
	sleep(100)
	release_active_monitor()

def refresh_debugReversed():
	if window.getProperty('acctmgr.debug.reversed') != setting('debug.reversed'):
		window.setProperty('acctmgr.debug.reversed', setting('debug.reversed'))
		execute('RunScript(script.module.acctmgr, action=tools_clearLogFile)')

def delete_synclist():
    if os.path.exists(var.tk_sync_list):
        try:
            os.unlink(var.tk_sync_list)
        except FileNotFoundError:
            pass
        
def suppress_notifications(kodi_utils):
    original = getattr(kodi_utils, 'notification', None)
    kodi_utils.notification = lambda *args, **kwargs: None
    return original

# NOTIFICATIONS        
def notification(title=None, message=None, icon=None, time=3000, sound=False):
	if title == 'default' or title is None: title = addonName()
	if isinstance(title, int): heading = lang(title)
	else: heading = str(title)
	if isinstance(message, int): body = lang(message)
	else: body = str(message)
	if icon is None or icon == '' or icon == 'default': icon = addonIcon()
	elif icon == 'INFO': icon = xbmcgui.NOTIFICATION_INFO
	elif icon == 'WARNING': icon = xbmcgui.NOTIFICATION_WARNING
	elif icon == 'ERROR': icon = xbmcgui.NOTIFICATION_ERROR
	dialog.notification(heading, body, icon, time, sound=sound)

# COPY ADDON DATA (settings.xml)
def copy_addon_settings(name, chk_addon, ud_path, chk_setting, base_path):
    try:
        if not xbmcvfs.exists(chk_addon):
            return

        if not xbmcvfs.exists(ud_path):
            try:
                xbmcvfs.mkdirs(ud_path)
            except Exception:
                os.mkdir(ud_path)

        if not xbmcvfs.exists(chk_setting):
            xbmcvfs.copy(base_path, chk_setting)

    except Exception as e:
        log_utils.error(f"{name} settings bootstrap failed: {e}")
        
# CACHE HELPERS
def remake_settings(plugin_id, name):
    try:
        addon = xbmcaddon.Addon(plugin_id)
        addon_root = addon.getAddonInfo('path')

        lib_path = os.path.join(addon_root, 'resources', 'lib')
        if lib_path not in sys.path:
            sys.path.insert(0, lib_path)

        # Force correct module per addon
        module_name = 'caches.settings_cache'
        if module_name in sys.modules:
            del sys.modules[module_name]

        settings_cache = importlib.import_module(module_name)

        if not hasattr(settings_cache, 'sync_settings'):
            log_utils.error(f"{name} sync_settings not found")
            return

        settings_cache.sync_settings()
        xbmc.log(f'AM Lite: {name} settings remade', xbmc.LOGINFO)

    except Exception as e:
        log_utils.error(f"Failed to remake {name} settings: {e}")

def remake_trakt_cache(plugin_id, name):   # Fen Light & Forks
    try:
        try:
            addon = xbmcaddon.Addon(plugin_id)
        except Exception:
            log_utils.error(f"{name} not installed, skipping Trakt cache clear")
            return

        addon_root = addon.getAddonInfo('path')

        # Ensure correct addon paths take priority
        if addon_root in sys.path:
            sys.path.remove(addon_root)
        sys.path.insert(0, addon_root)

        lib_path = joinPath(addon_root, 'resources', 'lib')
        if lib_path in sys.path:
            sys.path.remove(lib_path)
        sys.path.insert(0, lib_path)

        module_name = 'resources.lib.caches.trakt_cache'

        # Force reload of the correct fork's module
        if module_name in sys.modules:
            del sys.modules[module_name]

        try:
            trakt_cache = importlib.import_module(module_name)
        except Exception as e:
            log_utils.error(f"{name} Trakt cache module import failed: {e}")
            return

        if not hasattr(trakt_cache, 'clear_all_trakt_cache_data'):
            log_utils.error(f"{name} clear_all_trakt_cache_data not found")
            return

        trakt_cache.clear_all_trakt_cache_data(silent=True)
        xbmc.log(f'AM Lite: {name} Trakt cache cleared', xbmc.LOGINFO)

    except Exception as e:
        log_utils.error(f"Failed to clear {name} Trakt cache: {e}")

def remake_fen_trakt_cache():    # Fen
    try:
        try:
            fen = xbmcaddon.Addon('plugin.video.fen')
        except Exception:
            log_utils.error("Fen not installed, skipping Trakt cache clear")
            return

        fen_root = fen.getAddonInfo('path')
        if fen_root not in sys.path:
            sys.path.append(fen_root)

        lib_path = joinPath(fen_root, 'resources', 'lib')
        if lib_path not in sys.path:
            sys.path.append(lib_path)

        try:
            trakt_api = importlib.import_module('resources.lib.apis.trakt_api')
        except Exception:
            log_utils.error("Fen Trakt module import failed")
            return

        if not hasattr(trakt_api, 'trakt_sync_activities'):
            log_utils.error("Fen trakt_sync_activities not found")
            return

        trakt_api.trakt_sync_activities(force_update=True)
        xbmc.log('AM Lite: Fen Trakt cache cleared',xbmc.LOGINFO)
    except Exception as e:
        log_utils.error(f"Failed to clear Fen Trakt cache: {e}")

def remake_pov_settings():     # POV      
    try:
        try:
            pov = xbmcaddon.Addon('plugin.video.pov')
        except Exception:
            log_utils.error("POV not installed, skip clearing settings cache")
            return

        pov_root = pov.getAddonInfo('path')
        if pov_root not in sys.path:
            sys.path.append(pov_root)

        lib_path = joinPath(pov_root, 'resources', 'lib')
        if lib_path not in sys.path:
            sys.path.append(lib_path)

        try:
            kodi_utils = importlib.import_module('resources.lib.modules.kodi_utils')
        except Exception:
            log_utils.error("POV clear settings cache module import failed")
            return

        if not hasattr(kodi_utils, 'clean_settings'):
            log_utils.error("POV clean_settings not found")
            return

        orig_notify = suppress_notifications(kodi_utils)
        try:
            kodi_utils.clean_settings()
            xbmc.log('AM Lite: POV settings cache cleared', xbmc.LOGINFO)
        finally:
            if orig_notify:
                kodi_utils.notification = orig_notify
    except Exception as e:
        log_utils.error(f"Failed to clear POV settings cache: {e}")
        
def remake_pov_trakt_cache():    # POV
    try:
        try:
            pov = xbmcaddon.Addon('plugin.video.pov')
        except Exception:
            log_utils.error("POV not installed, skipping Trakt cache clear")
            return

        pov_root = pov.getAddonInfo('path')
        if pov_root not in sys.path:
            sys.path.append(pov_root)

        lib_path = joinPath(pov_root, 'resources', 'lib')
        if lib_path not in sys.path:
            sys.path.append(lib_path)

        try:
            trakt_cache = importlib.import_module('resources.lib.caches.trakt_cache')
        except Exception:
            log_utils.error("POV Trakt cache module import failed")
            return

        if not hasattr(trakt_cache, 'clear_all_trakt_cache_data'):
            log_utils.error("POV clear_all_trakt_cache_data not found")
            return

        trakt_cache.clear_all_trakt_cache_data(refresh=True)
        xbmc.log('AM Lite: POV Trakt cache cleared',xbmc.LOGINFO)
    except Exception as e:
        log_utils.error(f"Failed to clear POV Trakt cache: {e}")
