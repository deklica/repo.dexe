# -*- coding: utf-8 -*-
import xbmc, xbmcaddon, xbmcgui, xbmcvfs
import os

from acctmgr.modules import var
from acctmgr.modules import control
from acctmgr.modules import log_utils
from acctmgr.modules.db import torbox_db
from acctmgr.modules.db import chk_auth_db
from acctmgr.modules.db import torbox_db

# Variables
joinPath = os.path.join
exists = xbmcvfs.exists

class Auth:
    def torbox_auth(self):

        # ========================= AM Lite Variables =========================
        acctmgr = xbmcaddon.Addon("script.module.acctmgr")
        your_token = acctmgr.getSetting("torbox.token")
        your_acct_id = acctmgr.getSetting("torbox.acct_id")
        your_auth_status = acctmgr.getSetting("torbox.auth_status")
        your_expires = acctmgr.getSetting("torbox.auth_expires")
        master_token = your_token

        # =================== Copy Addon Data (settings.xml) ==================
        addons = [
            ("Shadow",     var.chk_shadow, var.shadow_ud,  var.chkset_shadow,  var.shadow),
            ("Ghost",      var.chk_ghost,  var.ghost_ud,   var.chkset_ghost,   var.ghost),
            ("The Chains", var.chk_chains,   var.chains_ud,    var.chkset_chains,    var.chains),
            ("Otaku",      var.chk_otaku,  var.otaku_ud,   var.chkset_otaku,   var.otaku),
        ]

        for name, chk_addon, ud_path, chk_setting, base_path in addons:
            control.copy_addon_settings(
                name,
                chk_addon,
                ud_path,
                chk_setting,
                base_path
            )
            
        # ========================= Fen Light =========================
        try:
            if exists(var.chk_fenlt):
                if not exists(var.chkset_fenlt):
                    control.remake_settings(var.fenlt_id, var.fenlt_name)
                    xbmc.sleep(500)
                    
                if exists(var.chkset_fenlt):
                    settings_db = var.fenlt_settings_db
                    chk_auth = chk_auth_db.chk_auth(settings_db, "tb.token")
                    
                    if chk_auth != master_token:
                        torbox_db.auth(settings_db)
                        xbmc.sleep(300)
                        control.remake_settings(var.fenlt_id, var.fenlt_name)
        except Exception as e:
            log_utils.error(f"Fen Light TorBox Failed: {e}")

        # ========================= Gears =========================
        try:
            if exists(var.chk_gears):
                if not exists(var.chkset_gears):
                    control.remake_settings(var.gears_id, var.gears_name)
                    xbmc.sleep(500)
                    
                if exists(var.chkset_gears):
                    settings_db = var.gears_settings_db
                    chk_auth = chk_auth_db.chk_auth(settings_db, "tb.token")
                    
                    if chk_auth != master_token:
                        torbox_db.auth(settings_db)
                        xbmc.sleep(300)
                        control.remake_settings(var.gears_id, var.gears_name)
        except Exception as e:
            log_utils.error(f"Gears TorBox Failed: {e}")
            
        # ========================= Umbrella =========================
        try:
            if exists(var.chk_umb) and exists(var.chkset_umb):
                addon = xbmcaddon.Addon("plugin.video.umbrella")
                chk_auth = addon.getSetting("torboxtoken")
                if chk_auth != master_token:
                    for k, v in {
                        "torboxtoken": your_token,
                        "torbox.username": your_acct_id,
                        "torbox.enable": "true",
                    }.items():
                        addon.setSetting(k, v)
        except Exception as e:
            log_utils.error(f"Umbrella TorBox Failed: {e}")

        # ========================= POV =========================
        try:
            if exists(var.chk_pov) and exists(var.chkset_pov):
                addon = xbmcaddon.Addon("plugin.video.pov")
                chk_auth = addon.getSetting("tb.token")
                if chk_auth != master_token:
                    for k, v in {
                        "tb.token": your_token,
                        "tb.account_id": your_acct_id,
                        "tb.enabled": "true",
                        "tb.expires": "0",
                    }.items():
                        addon.setSetting(k, v)
        except Exception as e:
            log_utils.error(f"POV TorBox Failed: {e}")

        # =============== Dradis / Genocide ===============
        addons = [
            ("Dradis",   "plugin.video.dradis",   var.chk_dradis,   var.chkset_dradis),
            ("Genocide", "plugin.video.genocide", var.chk_genocide, var.chkset_genocide),
        ]

        for name, plugin, chk_addon, chk_setting in addons:
            try:
                if exists(chk_addon) and exists(chk_setting):
                    addon = xbmcaddon.Addon(plugin)
                    chk_auth = addon.getSetting("torbox.token")
                    if chk_auth != master_token:
                        for k, v in {
                            "torbox.token": your_token,
                            "torbox.username": your_acct_id,
                            "torbox.enable": "true",
                            "torbox.expires": "0",
                        }.items():
                            addon.setSetting(k, v)
            except Exception as e:
                log_utils.error(f"{name} TorBox Failed: {e}")

        # =============== Shadow / Ghost / The Chains ===============
        addons = [
            ("Shadow",     "plugin.video.shadow",    var.chk_shadow,  var.shadow_ud,  var.chkset_shadow,  var.shadow),
            ("Ghost",      "plugin.video.ghost",     var.chk_ghost,   var.ghost_ud,   var.chkset_ghost,   var.ghost),
            ("The Chains", "plugin.video.thechains", var.chk_chains,  var.chains_ud,  var.chkset_chains,  var.chains),
        ]

        for name, plugin, chk_addon, ud_path, chk_setting, base_path in addons:
            try:
                if exists(chk_addon):
                    addon = xbmcaddon.Addon(plugin)
                    chk_auth = addon.getSetting("torbox.token")
                    if chk_auth != master_token:
                        for k, v in {
                            "tb.token": your_token,
                            "tb.account_id": your_acct_id,
                        }.items():
                            addon.setSetting(k, v)
            except Exception as e:
                log_utils.error(f"{name} TorBox Failed: {e}")

        # ========================= Otaku =========================
        try:
            if exists(var.chk_otaku):
                addon = xbmcaddon.Addon("plugin.video.otaku")
                chk_auth = addon.getSetting("torbox.token")
                if chk_auth != master_token:
                    for k, v in {
                        "torbox.username": your_acct_id,
                        "torbox.token": your_token,
                        "torbox.auth.status": your_auth_status,
                        "torbox.enabled": "true",
                    }.items():
                        addon.setSetting(k, v)
        except Exception as e:
            log_utils.error(f"Otaku TorBox Failed: {e}")
