﻿# -*- coding: utf-8 -*-

from .common import *


def _header(dealer=None, token=None):
	accepted = 'de-DE,de;q=0.9,en;q=0.8' if dealer and dealer.startswith('APPLE') and appleRegion in ['at', 'ch', 'de', 'li'] else 'en-US,en;q=0.9,de;q=0.8'
	header = {}
	header['Cache-Control'] = 'public, max-age=300'
	if dealer in ['APPLEJAVA', 'APPLEMUSIC']:
		header['Content-Type'] = 'application/javascript' if dealer == 'APPLEJAVA' else 'application/json; charset=utf-8'
		header['Origin'] = 'https://music.apple.com'
		header['Referer'] = 'https://music.apple.com/'
	if dealer in ['DEEZER', 'YOUTUBE']:
		header['Content-Type'] = 'application/json; charset=utf-8'
		header['Referer'] = 'https://www.deezer.com/' if dealer == 'DEEZER' else 'https://www.youtube.com/'
	if dealer == 'BILLBOARD': header['Referer'] = 'https://www.billboard.com/'
	if dealer == 'DJPLAYLIST': header['Referer'] = 'https://www.deutsche-dj-playlist.de/'
	if dealer == 'OFFICIAL': header['Referer'] = 'https://www.officialcharts.com/'
	header['Accept-Language'] = accepted
	if token: header['Authorization'] = f"Bearer {token}"
	return header

class clientHelper():
	def __init__(self, *args, **kwargs):
		super(clientHelper, self).__init__()
		self.expire_public = 6*3600 # max. Token-Time (Seconds) before clear the Token and delete Token-File [6*3600 = 6 Hours]
		self.temp_apple = tempAPPLE
		self.save_apple = publicSECRET

	def genres_strong(self):
		categories = [{'ne': '140 / Deep Dubstep / Grime','slug': '140-deep-dubstep-grime','id': '95'},{'ne': 'Afro House','slug': 'afro-house','id': '89'},{'ne': 'Amapiano','slug': 'amapiano','id': '98'},
			{'ne': 'Bass / Club','slug': 'bass-club','id': '85'},{'ne': 'Bass House','slug': 'bass-house','id': '91'},{'ne': 'Brazilian Funk','slug': 'brazilian-funk','id': '101'},
			{'ne': 'Breaks / Breakbeat / UK Bass','slug': 'breaks-breakbeat-uk-bass','id': '9'},{'ne': 'Dance / Pop','slug': 'dance-pop','id': '39'},{'ne': 'Deep House','slug': 'deep-house','id': '12'},
			{'ne': 'DJ Tools / Acapellas','slug': 'dj-tools-acapellas','id': '16'},{'ne': 'Downtempo','slug': 'downtempo','id': '63'},{'ne': 'Drum & Bass','slug': 'drum-bass','id': '1'},
			{'ne': 'Dubstep','slug': 'dubstep','id': '18'},{'ne': 'Electro (Classic / Detroit / Modern)','slug': 'electro-classic-detroit-modern','id': '94'},{'ne': 'Electronica','slug': 'electronica','id': '3'},
			{'ne': 'Funky House','slug': 'funky-house','id': '81'},{'ne': 'Hard Dance / Hardcore / Neo Rave','slug': 'hard-dance-hardcore-neo-rave','id': '8'},
			{'ne': 'Hard Techno','slug': 'hard-techno','id': '2'},{'ne': 'House','slug': 'house','id': '5'},{'ne': 'Indie Dance','slug': 'indie-dance','id': '37'},
			{'ne': 'Indie Tech','slug': 'indie-tech','id': '112'},{'ne': 'Jackin House','slug': 'jackin-house','id': '97'},{'ne': 'Latin Electronic','slug': 'latin-electronic','id': '111'},
			{'ne': 'Mainstage','slug': 'mainstage','id': '96'},{'ne': 'Melodic House & Techno','slug': 'melodic-house-techno','id': '90'},
			{'ne': 'Minimal / Deep Tech','slug': 'minimal-deep-tech','id': '14'},{'ne': 'Nu Disco / Disco','slug': 'nu-disco-disco','id': '50'},{'ne': 'Organic House','slug': 'organic-house','id': '93'},
			{'ne': 'Progressive House','slug': 'progressive-house','id': '15'},{'ne': 'Psy-Trance','slug': 'psy-trance','id': '13'},{'ne': 'Tech House','slug': 'tech-house','id': '11'},
			{'ne': 'Techno (Peak Time / Driving)','slug': 'techno-peak-time-driving','id': '6'},{'ne': 'Techno (Raw / Deep / Hypnotic)','slug': 'techno-raw-deep-hypnotic','id': '92'},
			{'ne': 'Trance (Main Floor)','slug': 'trance-main-floor','id': '7'},{'ne': 'Trance (Raw / Deep / Hypnotic)','slug': 'trance-raw-deep-hypnotic','id': '99'},
			{'ne': 'Trap / Future Bass','slug': 'trap-future-bass','id': '38'},{'ne': 'UK Garage / Bassline','slug': 'uk-garage-bassline','id': '86'}]
		return categories

	def convert_epoch(self, epoch):
		cipher = datetime(1970,1,1) + timedelta(seconds=int(epoch))
		return cipher.strftime('%d.%m.%Y - %H:%M:%S')

	def check_authtoken(self, provider):
		debug_MS("(utilities.check_authtoken) -------------------------------------------------- START = check_authtoken --------------------------------------------------")
		forceRenew = authorize_ways = False
		guardia, security, times_utc = self.temp_apple, self.save_apple, time.time()
		if provider == 'APPLEMUSIC' and security is not None and os.path.isfile(security):
			try:
				token_utc = (os.path.getmtime(security) + self.expire_public)
				debug_MS(f"(utilities.check_authtoken) {provider} ### SESSION-Time (utc NOW) = {self.convert_epoch(times_utc)} || VALID until (utc SESSION) = {self.convert_epoch(token_utc)} ###")
				if times_utc < token_utc:
					debug_MS(f"(utilities.check_authtoken) ##### NOTHING CHANGED - TOKENFILE FOR *{provider}* IS OKAY #####")
					authorize_ways = preserve(security)['accessToken']
				else:
					debug_MS(f"(utilities.check_authtoken) ##### TIMEOUT FOR SESSION - DELETE *{provider}* TOKENFILE #####")
					forceRenew = True
			except:
				failing(f"(utilities.check_authtoken) XXXXX !!! ERROR = {provider}-TOKENFILE [TOKENFORMAT IS INVALID] = ERROR !!! XXXXX")
				forceRenew = True
		else:
			debug_MS(f"(utilities.check_authtoken) ##### NOTHING FOUND - CREATE TOKENFILE FOR *{provider}* #####")
			forceRenew = True
		if forceRenew:
			if xbmcvfs.exists(guardia) and os.path.exists(guardia):
				shutil.rmtree(guardia, ignore_errors=True)
			home_page = self.track_content(f"https://music.apple.com/{appleRegion}/home", 'GET', 'TEXT')
			scan_area = re.compile(r'''<script type=["']module["'] crossorigin src=["'](.*?/index.*?.js)["']''', re.S).findall(home_page)
			full_link = f"https://music.apple.com{scan_area[0]}" if scan_area and scan_area[0][:4] != 'http' else scan_area[0] if scan_area else None
			java_page = self.track_content(full_link, 'GET', 'TEXT', 'APPLEJAVA') if full_link else None
			codings = re.compile(r'''-external["'],[A-z]+=["'](eyJ[^"']+)["'],[A-z0-9]+=["']eyJ''', re.S).findall(java_page) if java_page else None
			if codings:
				debug_MS(f"(utilities.check_authtoken) ### NEW TOKENFILE FOR >>{provider}<< CREATED : {{'accessToken': {codings[0]}, 'generateUtc': {self.convert_epoch(times_utc)}}} ###")
				if not xbmcvfs.exists(guardia) and not os.path.exists(guardia):
					xbmcvfs.mkdirs(guardia)
				preserve(security, {'accessToken': codings[0], 'generateUtc': self.convert_epoch(times_utc)})
				authorize_ways = codings[0]
			else: failing(f"(utilities.check_authtoken) XXXXX !!! ERROR = {provider} - COULD NOT FIND TOKEN ON PAGE = ERROR !!! XXXXX")
		return authorize_ways

	def track_content(self, link, method='GET', queries='JSON', service=None, headers={}, redirects=True, data=None, json=None, timeout=30):
		attempts, (answer, news_code) = 0, (None for _ in range(2))
		signify = self.check_authtoken(service) if service == 'APPLEMUSIC' else None
		uncheck = ssl.create_default_context()
		uncheck.check_hostname = False
		uncheck.verify_mode = ssl.CERT_NONE
		if link.startswith('http'):
			fixation = create_scraper(browser={'browser': 'chrome', 'platform': 'windows', 'mobile': False}, ssl_context=uncheck)
			try:
				response = fixation.request(method, link, headers=_header(service, signify), allow_redirects=redirects, timeout=timeout)
				response.raise_for_status()
				answer = response.json() if queries == 'JSON' else response.text if queries == 'TEXT' else response
				debug_MS(f"(utilities.track_content[1.1]) === CALLBACK === STATUS : {response.status_code} || URL : {response.url} || HEADER : {response.request.headers} ===")
			except requests.exceptions.RequestException as exc:
				failing(f"(utilities.track_content[1.1]) ERROR - EXEPTION - ERROR ##### URL : {link} === FAILURE : {exc} #####")
				dialog.notification(translation(30521).format('URL'), translation(30523).format(exc), icon, 12000)
				return sys.exit(0)
		else:
			def track_collect(back_link, beam_token=None):
				debug_MS(f"(utilities.track_collect[1.2]) === Link_Suffix : {back_link} || Transfer_Token : {beam_token} ===")
				return API_BEAT+beam_token+back_link if beam_token else API_BEAT+addon.getSetting('beat_staticCODE')+back_link
			while not answer and attempts < 3: # 2 x repetitions for the URL request ::: as the code for the API_BEATPORT may have been changed again
				attempts += 1
				measure_headers = [('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36'), \
					('Referer', 'https://www.beatport.com/'), ('Accept', '*/*'), ('DNT', '1'), ('x-cache-internal', 'true'), ('x-nextjs-data', '1')]
				opener = build_opener(HTTPCookieProcessor(CookieJar())) # FROM: https://github.com/Catch-up-TV-and-More/plugin.video.catchuptvandmore/blob/dev/resources/lib/resolver_proxy.py#L347
				try:
					move_link = track_collect(link, news_code)
					opener.addheaders = measure_headers
					response = opener.open(move_link, timeout=12)
					answer = response.read().decode('utf-8')
					debug_MS(f"(utilities.track_content[1.2]) === CALLBACK === attempts_no : {attempts} === STATUS : {response.status} || URL : {response.url} || HEADER : {dict(measure_headers[:])} ===")
				except Exception as exc:
					failing(f"(utilities.track_content[1.2]) ERROR - CURRENT_TOKEN - ERROR ##### attempts_no : {attempts} === URL : {move_link} === FAILURE : {exc} #####")
					patching = Request(BASE_URL_BP, None, dict(measure_headers[:]))
					CookieJar().add_cookie_header(patching)
					survivals = opener.open(patching, timeout=12).read().decode('utf-8')
					scanning = re.compile(r'''</script><script src=["']/_next/static/([^/]+)/_ssgManifest.js["']''', re.S).findall(survivals)
					#scanning = re.compile(r'''["']query["']:.*?,["']buildId["']:["']([^"']+)["'],["']isFallback["']''', re.S).findall(survivals)
					if scanning:
						news_code = scanning[0]
						addon.setSetting('beat_staticCODE', news_code)
					elif attempts > 1 and not scanning:
						attempts += 2
						dialog.notification(translation(30521).format('URL'), translation(30524), icon, 12000)
						break
					time.sleep(2)
		debug_MS("═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═")
		return answer
