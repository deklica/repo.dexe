"""Normalise shared dialog colours without relying on the user's Kodi skin.

Run with --check to detect older palette values without writing files.
Kodi XML requires literal colours, so this keeps those literals consistent.
"""

from pathlib import Path
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "lib"))
import theme


def sync_buttons(root):
    changed = False
    for group in root.findall(".//control[@type='group']"):
        buttons = group.findall("control[@type='button']")
        if not buttons:
            continue
        buttons.sort(key=lambda b: int(b.findtext("left", "0")))
        right = max(int(b.findtext("left", "0")) + int(b.findtext("width", "0")) for b in buttons)
        start = right - len(buttons) * theme.BUTTON_WIDTH - (len(buttons) - 1) * theme.BUTTON_GAP
        for i, button in enumerate(buttons):
            values = {
                "left": str(start + i * (theme.BUTTON_WIDTH + theme.BUTTON_GAP)),
                "width": str(theme.BUTTON_WIDTH), "height": str(theme.BUTTON_HEIGHT),
                "font": "font12", "align": "center", "aligny": "center",
                "textcolor": theme.BUTTON_TEXT, "focusedcolor": theme.BACKGROUND,
                "disabledcolor": theme.BUTTON_DISABLED,
            }
            for tag, value in values.items():
                node = button.find(tag)
                if node is None:
                    node = ET.SubElement(button, tag)
                    changed = True
                if node.text != value:
                    node.text = value
                    changed = True
            for tag, colour in [("texturefocus", theme.ACCENT), ("texturenofocus", theme.BUTTON_SURFACE)]:
                node = button.find(tag)
                if node is None:
                    node = ET.SubElement(button, tag)
                    changed = True
                attrs = {"colordiffuse": colour, "border": "12"}
                if node.text != theme.ROUNDED_TEXTURE or node.attrib != attrs:
                    node.text = theme.ROUNDED_TEXTURE
                    node.attrib.clear()
                    node.attrib.update(attrs)
                    changed = True
    return changed


def main():
    changed = []
    for path in (ROOT / "resources/skins/Default/1080i").glob("Cartoonio*.xml"):
        original = path.read_text(encoding="utf-8")
        updated = original
        for old, new in theme.LEGACY_COLOURS.items():
            updated = updated.replace(old, new)
        root = ET.fromstring(updated)
        if sync_buttons(root):
            ET.indent(root, space="  ")
            updated = '<?xml version="1.0" encoding="UTF-8"?>\n' + ET.tostring(root, encoding="unicode") + "\n"
        if updated != original:
            changed.append(path.name)
            if "--check" not in sys.argv:
                path.write_text(updated, encoding="utf-8")
    print("Theme {}: {}".format("changes needed" if "--check" in sys.argv and changed else "synchronised", ", ".join(changed) or "all dialogs consistent"))
    return int(bool(changed) and "--check" in sys.argv)


if __name__ == "__main__":
    raise SystemExit(main())
