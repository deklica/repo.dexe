"""FunnierMoments.net catalogue and direct-MP4 resolver."""

import json
import re
import unicodedata

try:
    from html import unescape
    from urllib.parse import quote_plus, urljoin
    from urllib.request import Request, build_opener, HTTPCookieProcessor
    from urllib.error import HTTPError, URLError
    from http.cookiejar import CookieJar
except ImportError:
    from HTMLParser import HTMLParser
    unescape = HTMLParser().unescape
    from urllib import quote_plus
    from urlparse import urljoin
    from urllib2 import Request, build_opener, HTTPCookieProcessor, HTTPError, URLError
    from cookielib import CookieJar

import xbmc
import diskcache
from pagination import next_page_url


BASE_URL = "https://www.funniermoments.net"
HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    ),
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
}
_OPENER = build_opener(HTTPCookieProcessor(CookieJar()))


def _fetch(url, timeout=15):
    cached = diskcache.get("funniermoments_html", url, 1800)
    if cached is not None:
        return cached
    try:
        response = _OPENER.open(Request(url, headers=HEADERS), timeout=timeout)
        html = response.read().decode("utf-8", errors="replace")
        if html:
            diskcache.set("funniermoments_html", url, html)
        return html
    except (HTTPError, URLError) as exc:
        xbmc.log("Cartoonio FunnierMoments fetch error {}: {}".format(url, exc), xbmc.LOGWARNING)
    except Exception as exc:
        xbmc.log("Cartoonio FunnierMoments unexpected error {}: {}".format(url, exc), xbmc.LOGWARNING)
    return ""


def _normalise_title(value):
    value = unescape(re.sub(r"<[^>]+>", "", value or ""))
    value = unicodedata.normalize("NFKD", value)
    value = "".join(ch for ch in value if not unicodedata.combining(ch))
    return re.sub(r"[^a-z0-9]+", " ", value.lower()).strip()


def _article_items(html):
    """Read TrueMag video cards, excluding header and sidebar navigation."""
    items = []
    seen = set()
    blocks = re.split(r'<div\b[^>]*class=["\'][^"\']*\bvideo-item\b[^"\']*["\'][^>]*>', html, flags=re.I)[1:]
    for block in blocks:
        heading = re.search(r'<h3\b[^>]*>\s*<a\b[^>]*href=["\']([^"\']+)["\'][^>]*>(.*?)</a>', block, re.I | re.S)
        if not heading:
            continue
        url = urljoin(BASE_URL + "/", unescape(heading.group(1))).split("#", 1)[0]
        title = unescape(re.sub(r"<[^>]+>", "", heading.group(2))).strip()
        if not title or url in seen or not url.startswith(BASE_URL + "/"):
            continue
        image = re.search(r'<img\b[^>]+(?:data-src|src)=["\']([^"\']+)', block, re.I)
        seen.add(url)
        items.append({"label": title, "url": url,
                      "thumb": urljoin(BASE_URL + "/", unescape(image.group(1))) if image else "",
                      "is_folder": False})
    return items


def get_series_list():
    html = _fetch(BASE_URL + "/")
    items = []
    seen = set()
    for match in re.finditer(
        r'<a\b[^>]+href=["\'](https?://(?:www\.)?funniermoments\.net/video-series/([^/"\']+)/?)["\'][^>]*>(.*?)</a>',
        html, re.I | re.S,
    ):
        url = unescape(match.group(1))
        label = unescape(re.sub(r"<[^>]+>", "", match.group(3))).strip()
        if url in seen or not label:
            continue
        seen.add(url)
        items.append({"label": label, "url": url, "thumb": "", "is_folder": True})
    return items


def get_series_episodes(url, max_pages=50):
    items = []
    seen = set()
    for page in range(1, max_pages + 1):
        page_url = url if page == 1 else url.rstrip("/") + "/page/{}/".format(page)
        html = _fetch(page_url)
        if not html:
            break
        added = 0
        for item in _article_items(html):
            if item["url"] not in seen:
                seen.add(item["url"])
                items.append(item)
                added += 1
        if not next_page_url(html, page_url) or not added:
            break
    return {"items": items, "next_page_url": None}


def get_latest(page=1):
    url = BASE_URL + "/" if page == 1 else BASE_URL + "/page/{}/".format(page)
    html = _fetch(url)
    return {"items": _article_items(html), "next_page_url": next_page_url(html, url)}


def get_cartoons_page(page=1, url=None):
    url = re.sub(r"/page/\d+/?$", "/", url or BASE_URL + "/category/cartoons/")
    if page > 1:
        url = url.rstrip("/") + "/page/{}/".format(page)
    html = _fetch(url)
    return {"items": _article_items(html), "next_page_url": next_page_url(html, url)}


def _video_urls(html):
    urls = []
    for raw in re.findall(r'<script[^>]+type=["\']application/ld\+json["\'][^>]*>(.*?)</script>', html, re.I | re.S):
        try:
            pending = [json.loads(raw.strip())]
        except Exception:
            continue
        while pending:
            item = pending.pop(0)
            if isinstance(item, list):
                pending.extend(item)
            elif isinstance(item, dict):
                if item.get("contentUrl"):
                    urls.append(item["contentUrl"])
                pending.extend(v for v in item.values() if isinstance(v, (dict, list)))
    urls.extend(m.group(1) for m in re.finditer(r'\bfile\s*:\s*["\'](https?://[^"\']+)', html, re.I))
    return urls


def _page_title(html):
    match = re.search(r'<h1[^>]*class=["\'][^"\']*(?:post-title|video-title|entry-title)[^"\']*["\'][^>]*>(.*?)</h1>', html, re.I | re.S)
    return unescape(re.sub(r"<[^>]+>", "", match.group(1))).strip() if match else ""


def get_url_streams(page_url, html=None):
    html = _fetch(page_url) if html is None else html
    streams = []
    seen = set()
    for raw_url in _video_urls(html):
        url = urljoin(BASE_URL + "/", unescape(raw_url).replace(r"\/", "/"))
        if not re.search(r"\.mp4(?:\?|$)", url, re.I) or url in seen:
            continue
        seen.add(url)
        streams.append({"label": "FunnierMoments MP4", "url": url, "referer": page_url, "provider": "funniermoments", "user_agent": HEADERS["User-Agent"]})
    return streams


def get_episode_page(episode_title, series_title=""):
    """Return streams only when FunnierMoments has an exact-title short."""
    wanted = _normalise_title(episode_title)
    if not wanted:
        return []
    html = _fetch("{}/?s={}".format(BASE_URL, quote_plus(episode_title)))
    for item in _article_items(html):
        if _normalise_title(item["label"]) != wanted:
            continue
        page = _fetch(item["url"])
        if _normalise_title(_page_title(page)) == wanted:
            streams = get_url_streams(item["url"], page)
            if streams:
                return streams
    return []


def search(query, page=1):
    if not query:
        return {"items": [], "next_page_url": None}
    url = "{}/?s={}".format(BASE_URL, quote_plus(query))
    if page > 1:
        url += "&paged={}".format(page)
    html = _fetch(url)
    return {"items": _article_items(html), "next_page_url": next_page_url(html, url)}


def get_episode_info(page_url):
    html = _fetch(page_url)
    info = {"title": _page_title(html)}
    for prop, key in (("og:description", "plot"), ("og:image", "thumb")):
        match = re.search(r'<meta[^>]+property=["\']' + prop + r'["\'][^>]+content=["\']([^"\']+)', html, re.I)
        if match:
            info[key] = unescape(match.group(1)).strip()
    return info
