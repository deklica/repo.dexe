"""Plugin URL dispatch and legacy route aliases.

Handlers receive the running addon context explicitly.
"""

__all__ = ['router']


def router(app):
    params = app.get_params()
    mode = params.get("mode", "main")
    url = params.get("url", "")
    page = int(params.get("page", 1))
    app.diskcache.BYPASS_PROVIDER_READS = params.get("fresh") == "1"
    if mode in ("latest", "cartoons", "series_list", "series_seasons", "season_episodes", "search", "search_prompt"):
        if not any(app._provider_enabled(name) for name, _ in app.preferences.PROVIDERS):
            app.xbmcgui.Dialog().ok(app.ADDON_NAME, "All providers are disabled. Enable a provider in Settings.")
            app.end_of_directory(False)
            return

    if mode == "main":
        app.show_main_menu()
    elif mode == "changelog":
        app.show_changelog()
    elif mode == "clear_cache":
        app.clear_addon_cache(params.get("scope", "all"))
    elif mode == "cache_menu":
        app.show_cache_menu()
    elif mode == "cache_info":
        app.maintenance.show_cache_info()
    elif mode == "check_providers":
        app.maintenance.check_providers(app._provider_jobs("get_latest"))
    elif mode == "tools":
        app.show_tools()
    elif mode in ("diagnostics_menu", "misc_menu"):
        app.show_diagnostics_menu()
    elif mode == "settings":
        changed = app.settingsdialog.show(app.ADDON, app.ADDON_PATH)
        app.end_of_directory(cache_to_disc=False)
        if changed:
            app.xbmc.executebuiltin("Container.Refresh")
    elif mode == "latest":
        app.show_latest(url or "https://www.megacartoons.net", page=page,
                    offset=int(params.get("offset", 0)))
    elif mode == "cartoons":
        app.show_cartoons(url or "https://www.megacartoons.net/category/cartoons/", page=page,
                      offset=int(params.get("offset", 0)))
    elif mode == "categories":
        app.show_categories()
    elif mode == "series_list":
        app.show_series_list(page=page)
    elif mode == "series_seasons":
        app.show_series_seasons(
            url,
            page=page,
            provider=params.get("provider", "megacartoons"),
            provider_urls=app.providers.navigation_urls(params),
        )
    elif mode == "season_episodes":
        season = int(params.get("season", 1))
        app.show_season_episodes(
            url,
            season=season,
            page=page,
            provider=params.get("provider", "megacartoons"),
            provider_urls=app.providers.navigation_urls(params),
        )
    elif mode == "episode":
        app.show_episode(
            url,
            season=int(params.get("season", 0)),
            episode=int(params.get("episode", 0)),
            tmdb_season=int(params.get("tmdb_season", 0)),
            series_title=params.get("series_title", ""),
            episode_title=params.get("episode_title", ""),
        )
    elif mode == "search":
        app.do_search(params.get("query"), page=page, offset=int(params.get("offset", 0)))
    elif mode == "search_prompt":
        app.do_search(None, page=1, use_last=True)
    else:
        app.show_main_menu()
