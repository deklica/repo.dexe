"""B98.TV episode lookup used as an additional Cartoonio source."""

import json
import re
import unicodedata

try:
    from html import unescape
    from urllib.parse import quote_plus, urljoin
    from urllib.request import Request, build_opener
    from urllib.error import HTTPError, URLError
except ImportError:
    from HTMLParser import HTMLParser
    unescape = HTMLParser().unescape
    from urllib import quote_plus
    from urlparse import urljoin
    from urllib2 import Request, build_opener, HTTPError, URLError

import xbmc
import diskcache
from pagination import next_page_url

BASE_URL = "https://www.b98.tv"
HEADERS = {"User-Agent": "Mozilla/5.0 (Kodi Cartoonio)"}
_OPENER = build_opener()


def _fetch(url, timeout=15):
    cached = diskcache.get("b98_html", url, 1800)
    if cached is not None:
        return cached
    try:
        response = _OPENER.open(Request(url, headers=HEADERS), timeout=timeout)
        html = response.read().decode("utf-8", errors="replace")
        if html:
            diskcache.set("b98_html", url, html)
        return html
    except (HTTPError, URLError) as exc:
        xbmc.log("Cartoonio B98 fetch error {}: {}".format(url, exc), xbmc.LOGWARNING)
    except Exception as exc:
        xbmc.log("Cartoonio B98 unexpected error: {}".format(exc), xbmc.LOGWARNING)
    return ""


def _normalise(value):
    value = unescape(re.sub(r"<[^>]+>", "", value or ""))
    value = unicodedata.normalize("NFKD", value)
    value = "".join(ch for ch in value if not unicodedata.combining(ch))
    return re.sub(r"[^a-z0-9]+", " ", value.lower()).strip()


def _slug(value):
    return re.sub(r"[^a-z0-9]+", "-", _normalise(value)).strip("-")


def _episode_links(html):
    links = []
    seen = set()
    for match in re.finditer(r'<a\b[^>]+href=["\'](https?://(?:www\.)?b98\.tv/video/[^"\']+)["\'][^>]*>(.*?)</a>', html, re.I | re.S):
        url = unescape(match.group(1)).split("#", 1)[0]
        title = unescape(re.sub(r"<[^>]+>", "", match.group(2))).strip()
        if url not in seen and title:
            seen.add(url)
            links.append((title, url))
    return links


def _find_episode(episode_title, series_title):
    wanted = _normalise(episode_title)
    if not wanted:
        return ""
    pages = []
    if series_title and _normalise(series_title) not in ("home", "cartoons", "series"):
        pages.append("{}/videos_categories/{}/".format(BASE_URL, _slug(series_title)))
    pages.append("{}/?s={}".format(BASE_URL, quote_plus(episode_title)))
    for page_url in pages:
        html = _fetch(page_url)
        if not html:
            continue
        for title, url in _episode_links(html):
            if _normalise(title) == wanted:
                return url
    return ""


def _stream_urls(html):
    urls = []
    for raw in re.findall(r'<script[^>]+type=["\']application/ld\+json["\'][^>]*>(.*?)</script>', html, re.I | re.S):
        try:
            data = json.loads(raw.strip())
        except Exception:
            continue
        stack = data if isinstance(data, list) else [data]
        while stack:
            item = stack.pop(0)
            if isinstance(item, dict):
                for key in ("contentUrl", "embedUrl"):
                    if item.get(key):
                        urls.append(item[key])
                stack.extend(v for v in item.values() if isinstance(v, (dict, list)))
            elif isinstance(item, list):
                stack.extend(item)
    patterns = (
        r'\b(?:file|src|source|contentUrl)\s*[:=]\s*["\'](https?://[^"\']+)',
        r'<(?:video|source)[^>]+src=["\'](https?://[^"\']+)',
    )
    for pattern in patterns:
        urls.extend(re.findall(pattern, html, re.I))
    result = []
    for raw in urls:
        url = urljoin(BASE_URL + "/", unescape(raw).replace(r"\/", "/"))
        if re.search(r"\.(?:mp4|m3u8)(?:\?|$)", url, re.I) and url not in result:
            result.append(url)
    return result


def get_episode_page(episode_title, series_title=""):
    page_url = _find_episode(episode_title, series_title)
    if not page_url:
        return []
    html = _fetch(page_url)
    return [{"label": "B98 MP4" if ".mp4" in url.lower() else "B98 HLS", "url": url, "referer": page_url, "provider": "b98"}
            for url in _stream_urls(html)]


def get_url_streams(page_url):
    return [{"label": "B98 MP4" if ".mp4" in url.lower() else "B98 HLS", "url": url, "referer": page_url, "provider": "b98"}
            for url in _stream_urls(_fetch(page_url))]


def get_episode_info(page_url):
    html = _fetch(page_url)
    title = ""
    plot = ""
    image = ""
    for prop, target in (("og:title", "title"), ("og:description", "plot"), ("og:image", "image")):
        match = re.search(r'<meta[^>]+(?:property|name)=["\']{}["\'][^>]+content=["\']([^"\']+)'.format(prop), html, re.I)
        if match:
            value = unescape(match.group(1)).strip()
            if target == "title": title = value
            elif target == "plot": plot = value
            else: image = urljoin(BASE_URL + "/", value)
    return {"title": title, "plot": plot, "thumb": image, "fanart": image}


def get_latest(page=1, url=None):
    page_url = re.sub(r"/page/\d+/?$", "/", url or BASE_URL + "/videos_categories/cartoons/")
    if page > 1:
        page_url += "page/{}/".format(page)
    html = _fetch(page_url)
    return {"items": [{"label": title, "url": url, "thumb": "", "is_folder": False}
                      for title, url in _episode_links(html)],
            "next_page_url": next_page_url(html, page_url)}


def get_cartoons_page(page=1, url=None):
    return get_latest(page, url=url)


def get_series_episodes(url, max_pages=50):
    items = []
    seen = set()
    for page in range(1, max_pages + 1):
        page_url = url if page == 1 else url.rstrip("/") + "/page/{}/".format(page)
        html = _fetch(page_url)
        found = [(title, href) for title, href in _episode_links(html) if href not in seen]
        seen.update(href for _, href in found)
        if not found:
            break
        items.extend({"label": title, "url": episode_url, "thumb": "", "is_folder": False}
                     for title, episode_url in found)
        if not next_page_url(html, page_url):
            break
    return {"items": items, "next_page_url": None}


def search(query, page=1):
    """Search B98's video index and return playable episode cards."""
    if not query:
        return {"items": [], "next_page_url": None}
    url = "{}/?s={}".format(BASE_URL, quote_plus(query))
    if page > 1:
        url += "&paged={}".format(page)
    wanted = _normalise(query)
    items = []
    html = _fetch(url)
    for title, episode_url in _episode_links(html):
        if wanted in _normalise(title):
            items.append({"label": title, "url": episode_url, "thumb": "", "is_folder": False})
    category_url = "{}/videos_categories/{}/".format(BASE_URL, _slug(query))
    category_html = _fetch(category_url)
    heading = re.search(r'<h[1-4][^>]*>(.*?)</h[1-4]>', category_html, re.I | re.S)
    if page == 1 and heading and _normalise(re.sub(r"<[^>]+>", "", heading.group(1))).startswith(wanted):
        items.insert(0, {"label": query, "url": category_url, "thumb": "", "is_folder": True})
    return {"items": items, "next_page_url": next_page_url(html, url)}
