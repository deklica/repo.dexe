"""Artwork for Tools and its submenus, shared across Kodi list views."""

import os


TOOL_ICONS = {
    "settings": "settings-v1.png",
    "changelog": "changelog-v1.png",
    "cache_menu": "cache-v1.png",
    "diagnostics_menu": "diagnostics-v1.png",
    "cache_info": "cache-info-v1.png",
    "check_providers": "connections-v1.png",
    "clear_cache:all": "clear-cache-v1.png",
    "clear_cache:providers": "provider-cache-v1.png",
    "clear_cache:metadata": "metadata-cache-v1.png",
}


def tool_art(addon_path, fanart, mode, scope=""):
    key = mode + ":" + scope if mode == "clear_cache" else mode
    path = os.path.join(addon_path, "resources", TOOL_ICONS[key])
    return {"icon": path, "thumb": path, "poster": path, "fanart": fanart}
