"""Source probing and Kodi playback handoff.

Handlers receive the running addon context explicitly.
"""

__all__ = ['show_episode']


def show_episode(app, url, season=0, episode=0, tmdb_season=0, series_title="", episode_title=""):
    """Resolve stream and play."""
    import json
    import uuid
    from urllib.parse import urlsplit

    playback_id = uuid.uuid4().hex[:12]
    started = app.time.monotonic()

    def log_playback(event, **fields):
        # Structured, single-line INFO messages survive normal logging levels.
        fields.update(event=event, playback_id=playback_id,
                      elapsed_ms=int((app.time.monotonic() - started) * 1000))
        app.xbmc.log("Cartoonio playback " + json.dumps(fields, ensure_ascii=True), app.xbmc.LOGINFO)

    def stream_location(value):
        # Record only the host and extension: never signed paths, URL query
        # tokens, embedded credentials, fragments, or Kodi pipe headers.
        try:
            parts = urlsplit((value or "").split("|", 1)[0])
            extension = app.os.path.splitext(parts.path)[1].lower()
            return {"host": parts.hostname or "", "extension": extension
                    if extension in (".mp4", ".m3u8", ".webm", ".mkv") else ""}
        except ValueError:
            return {"host": "invalid", "extension": ""}

    log_playback("request", episode=episode_title, series=series_title,
                 page_host=stream_location(url)["host"])
    # Get episode page info for metadata
    try:
        ep_info = app.scraper.get_episode_info(url) if app._provider_enabled("megacartoons") and "megacartoons.net" in (url or "").lower() else {}
    except Exception as exc:
        app.xbmc.log("Cartoonio episode metadata failed: {}".format(exc), app.xbmc.LOGWARNING)
        ep_info = {}
    if episode_title:
        ep_info["title"] = episode_title
    if season:
        ep_info["season"] = int(season)
    if episode:
        ep_info["episode_num"] = int(episode)
    if tmdb_season:
        ep_info["tmdb_season"] = int(tmdb_season)
    if series_title:
        ep_info["series_title"] = series_title

    episode_title = ep_info.get("title", "")
    series_name = ep_info.get("series_title", "")
    ep_info["title"] = app._html_unescape(ep_info.get("title", ""))
    ep_info["series_title"] = app._html_unescape(ep_info.get("series_title", ""))
    episode_title = ep_info["title"]
    series_name = ep_info["series_title"]

    def _provider_streams(provider):
        if provider.name == "megacartoons":
            return app._find_megacartoons_streams(episode_title, url)
        if provider.owns(url):
            return provider.module.get_url_streams(url)
        return provider.module.get_episode_page(episode_title, series_name)

    probes = [(p.name, p.label, lambda p=p: _provider_streams(p)) for p in app.providers.REGISTRY]
    available_sources = []
    with app.ThreadPoolExecutor(max_workers=6) as executor:
        pending = [(label, executor.submit(loader)) for name, label, loader in probes if app._provider_enabled(name)]
        for label, future in pending:
            try:
                streams = future.result() or []
                clean = [s for s in streams if isinstance(s, dict)
                         and isinstance(s.get("url"), str) and s["url"].strip()]
            except Exception as exc:
                log_playback("probe_failed", provider=label, error_type=type(exc).__name__)
                clean = []
            log_playback("probe_result", provider=label, streams=len(clean))
            if clean:
                available_sources.append((label, clean))

    if not available_sources:
        log_playback("unavailable")
        app.xbmcgui.Dialog().ok(
            app.ADDON_NAME,
            "No playable sources are currently available for this episode."
        )
        app.xbmcplugin.setResolvedUrl(app.HANDLE, False, app.xbmcgui.ListItem())
        return

    selection = app.preferences.preferred_source(app.ADDON, available_sources)
    if selection is None:
        selection = app.sourcepicker.choose_source(
            app.ADDON_PATH, available_sources,
            episode=ep_info.get("title", ""),
            series=ep_info.get("series_title", ""),
            icon=ep_info.get("thumb") or app.ADDON_ICON,
        )
    if selection is None:
        log_playback("cancelled", stage="source_selection")
        app.xbmcplugin.setResolvedUrl(app.HANDLE, False, app.xbmcgui.ListItem())
        return
    source_name, selected_stream = selection
    streams = next(streams for name, streams in available_sources if name == source_name)
    stream_url = selected_stream["url"]
    log_playback("source_selected", provider=source_name, streams=len(streams))

    # Build playable item
    if not isinstance(stream_url, str) or not stream_url.strip():
        app.xbmcgui.Dialog().notification(app.ADDON_NAME, "The selected source is unavailable.", app.xbmcgui.NOTIFICATION_WARNING, 3000)
        app.xbmcplugin.setResolvedUrl(app.HANDLE, False, app.xbmcgui.ListItem())
        return
    li = app.xbmcgui.ListItem(path=stream_url)

    log_playback("stream_selected", provider=source_name,
                 episode=ep_info.get("title", ""),
                 series=ep_info.get("series_title", ""),
                 referer_present=bool(selected_stream.get("referer")),
                 **stream_location(stream_url))
    # Preserve provider referer/user-agent requirements for Kodi playback.
    if selected_stream.get("referer") and "|" not in stream_url:
        try:
            from urllib.parse import quote as _quote_header
        except ImportError:
            from urllib import quote as _quote_header
        stream_url = "{}|Referer={}&User-Agent={}".format(
            stream_url,
            _quote_header(selected_stream["referer"], safe=""),
            _quote_header(selected_stream.get("user_agent") or app.topcartoons.HEADERS["User-Agent"], safe=""),
        )
        li.setPath(stream_url)

    # Check the media URL before/around Kodi's pipe-header suffix. Once the
    # Referer is appended, a plain ``endswith('.mp4')`` check misses it and
    # the Stop/seek protection is never applied.
    stream_type = app.sourcepicker.stream_format(selected_stream)
    is_direct_mp4 = stream_type == "MP4"
    if is_direct_mp4:
        li.setMimeType("video/mp4")
        li.setContentLookup(False)
        # Remote provider MP4 endpoints can leave Kodi/FFmpeg waiting on a
        # byte-range request during Stop or seeking. Disable byte seeking for
        # every direct-MP4 provider so a bad endpoint cannot hang playback.
        # B98 serves normal range-capable media. Keep it seekable so Kodi's
        # pause/seek controls work normally; the legacy providers retain the
        # workaround for their unreliable byte-range endpoints.
        if selected_stream.get("provider") != "b98":
            li.setPath(stream_url + ("|" if "|" not in stream_url else "&") + "seekable=0")

    tag = li.getVideoInfoTag()
    tag.setTitle(ep_info.get("title", ""))
    tag.setPlot(ep_info.get("plot", ""))
    if ep_info.get("season"):
        tag.setSeason(ep_info["season"])
    if ep_info.get("episode_num"):
        tag.setEpisode(ep_info["episode_num"])
    if ep_info.get("series_title"):
        tag.setTvShowTitle(ep_info["series_title"])

    # Try TMDB enrichment for episode still
    thumb = ep_info.get("thumb", "") or app.ADDON_ICON
    fanart = app.ADDON_FANART

    poster = app.ADDON_ICON
    try:
        if app.ENABLE_TMDB and ep_info.get("series_title"):
            series_info = app.tmdb.build_tv_info(ep_info["series_title"])
            if series_info:
                tmdb_id = series_info.get("tmdb_id")
                episode_meta = app.tmdb.get_cached_episode_info(
                    tmdb_id,
                    ep_info.get("tmdb_season") or ep_info.get("season", 0),
                    ep_info.get("episode_num", 0),
                )
                tag.setPlot(
                    episode_meta.get("plot")
                    or ep_info.get("plot", "")
                    or series_info.get("plot", "")
                )
                if episode_meta.get("title"):
                    tag.setTitle(episode_meta["title"])
                if episode_meta.get("rating"):
                    tag.setRating(float(episode_meta["rating"]))
                if episode_meta.get("duration"):
                    tag.setDuration(int(episode_meta["duration"]))
                if app.ENABLE_SCREENSHOTS and tmdb_id:
                    still = episode_meta.get("still") or app.tmdb.get_episode_still(
                        tmdb_id,
                        ep_info.get("tmdb_season") or ep_info.get("season", 1),
                        ep_info.get("episode_num", 1),
                    )
                    if still:
                        thumb = still
                if series_info.get("fanart"):
                    fanart = series_info["fanart"]
                if series_info.get("poster"):
                    poster = series_info["poster"]
    except Exception as exc:
        log_playback("metadata_failed", error_type=type(exc).__name__)

    # All artwork must go via li.setArt() — not via VideoInfoTag
    li.setArt({
        "thumb":  thumb,
        "fanart": fanart,
        "icon":   thumb,
        "poster": poster,
    })
    li.setProperty("IsPlayable", "true")

    # Handle m3u8/HLS MIME type
    if stream_type == "HLS":
        li.setMimeType("application/x-mpegURL")
        li.setContentLookup(False)

    try:
        log_playback("handoff", provider=source_name,
                     episode=ep_info.get("title", ""),
                     direct_mp4=is_direct_mp4,
                     seek_disabled=is_direct_mp4 and selected_stream.get("provider") != "b98",
                     **stream_location(stream_url))
        app.xbmcplugin.setResolvedUrl(app.HANDLE, True, li)
        # This acknowledges resolution only; native player/decoder messages
        # after handoff determine whether playback actually started or crashed.
        log_playback("resolved", provider=source_name)
    except Exception as exc:
        log_playback("handoff_failed", provider=source_name, error_type=type(exc).__name__)
        try:
            app.xbmcplugin.setResolvedUrl(app.HANDLE, False, app.xbmcgui.ListItem())
        except Exception:
            pass
