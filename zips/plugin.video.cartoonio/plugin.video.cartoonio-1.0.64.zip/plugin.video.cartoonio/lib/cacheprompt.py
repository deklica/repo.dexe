"""Cartoonio's cache confirmation dialog."""

import xbmc
import xbmcgui

SCOPES = {
    "all": ("Clear the cache?", "Remove saved provider pages, cartoon listings and TMDB metadata."),
    "providers": ("Clear provider cache?", "Remove saved provider pages and cartoon listings. TMDB metadata will be kept."),
    "metadata": ("Clear metadata cache?", "Remove TMDB metadata and merged listings. Saved provider pages will be kept."),
}


class CachePrompt(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.confirmed = False
        self.ready = False
        self.icon = ""
        self.scope = "all"

    def onInit(self):
        try:
            self.setProperty("Cartoonio.Icon", self.icon)
            title, message = SCOPES[self.scope]
            self.setProperty("Cartoonio.CacheTitle", title)
            self.setProperty("Cartoonio.CacheMessage", message)
            self.setProperty("Cartoonio.CacheScope", {
                "all": "ALL CACHE", "providers": "PROVIDER CACHE", "metadata": "METADATA CACHE",
            }[self.scope])
            self.setFocusId(200)
            self.ready = True
        except Exception as exc:
            xbmc.log("Cartoonio cache prompt initialization failed: " + type(exc).__name__, xbmc.LOGWARNING)
            self.close()

    def onClick(self, control_id):
        if control_id in (200, 201):
            self.confirmed = control_id == 201
            self.close()

    def onAction(self, action):
        if action.getId() in (9, 10, 92):
            self.confirmed = False
            self.close()


def confirm(addon_path, icon, scope="all"):
    scope = scope if scope in SCOPES else "all"
    dialog = None
    try:
        dialog = CachePrompt("CartoonioClearCache.xml", addon_path, "Default", "1080i")
        dialog.icon = icon
        dialog.scope = scope
        dialog.doModal()
        if dialog.ready:
            return dialog.confirmed
    except Exception as exc:
        xbmc.log("Cartoonio cache prompt failed: " + type(exc).__name__, xbmc.LOGWARNING)
    finally:
        if dialog is not None:
            try:
                dialog.close()
            except Exception:
                pass
    title, message = SCOPES[scope]
    return xbmcgui.Dialog().yesno("Cartoonio · " + title,
        message + "\n\nYour settings will be kept. Listings may take longer to load next time.",
        nolabel="Cancel", yeslabel="Clear Cache")
