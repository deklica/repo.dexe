"""Validated settings shared by browsing, playback and maintenance."""

from providers import PROVIDERS
PAGE_SIZES = (20, 40, 60, 100)
LANGUAGES = {"English": "en-US", "French": "fr-FR", "German": "de-DE",
             "Spanish": "es-ES", "Italian": "it-IT", "Portuguese": "pt-PT",
             "Japanese": "ja-JP"}


def enabled(addon, provider):
    return addon.getSetting("enable_" + provider).strip().lower() != "false"


def page_size(addon):
    try:
        size = int(addon.getSetting("items_per_page"))
    except (ValueError, TypeError):
        return 40
    return size if size in PAGE_SIZES else 40


def language(addon, kodi):
    value = addon.getSetting("metadata_language") or "English"
    if value == "Kodi language":
        value = kodi.getLanguage(kodi.ISO_639_1, True)
        return value if value and len(value.split("-")[0]) == 2 else "en-US"
    return LANGUAGES.get(value, "en-US")


def catalogue_key(addon, key, language_code="en-US"):
    active = ",".join(name for name, _ in PROVIDERS if enabled(addon, name))
    metadata = addon.getSetting("enable_tmdb")
    return "v3:{}:{}:{}:{}".format(active, language_code, metadata, key)


def preferred_source(addon, sources):
    """Only bypass the picker when a preferred provider has one stream."""
    preferred = addon.getSetting("preferred_provider")
    for name, streams in sources:
        if name == preferred and len(streams) == 1:
            return name, streams[0]
    return None
