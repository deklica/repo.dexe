"""
MegaCartoons.net scraper for Cartoonio Kodi addon.
Uses ONLY Python stdlib (urllib + html.parser) — no requests, no bs4.
Compatible with Kodi 21 bundled Python 3.x.
"""

import re
import json
from html import unescape
import xbmc
import diskcache

try:
    from urllib.request import Request, urlopen, build_opener, HTTPCookieProcessor
    from urllib.parse import quote_plus, urljoin, urlparse
    from urllib.error import URLError, HTTPError
    from http.cookiejar import CookieJar
    from html.parser import HTMLParser
except ImportError:
    from urllib2 import Request, urlopen, build_opener, HTTPCookieProcessor, URLError, HTTPError
    from urllib import quote_plus
    from urlparse import urljoin, urlparse
    from cookielib import CookieJar
    from HTMLParser import HTMLParser

BASE_URL = "https://www.megacartoons.net"

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/120.0.0.0 Safari/537.36"
    ),
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
}

_COOKIE_JAR = CookieJar()
_OPENER = build_opener(HTTPCookieProcessor(_COOKIE_JAR))


# ---------------------------------------------------------------------------
# HTTP fetch
# ---------------------------------------------------------------------------

def _fetch(url, timeout=15):
    """Fetch a URL and return the response body as a unicode string."""
    cached = diskcache.get("megacartoons_html", url, 1800)
    if cached is not None:
        return cached
    try:
        req = Request(url, headers=HEADERS)
        resp = _OPENER.open(req, timeout=timeout)
        charset = "utf-8"
        ct = resp.headers.get("Content-Type", "")
        m = re.search(r"charset=([^\s;\"']+)", ct)
        if m:
            charset = m.group(1).strip()
        raw = resp.read()
        html = raw.decode(charset, errors="replace")
        if html:
            diskcache.set("megacartoons_html", url, html)
        return html
    except (URLError, HTTPError) as e:
        xbmc.log("Cartoonio fetch error {}: {}".format(url, str(e)), xbmc.LOGERROR)
        return ""
    except Exception as e:
        xbmc.log("Cartoonio fetch unexpected {}: {}".format(url, str(e)), xbmc.LOGERROR)
        return ""


def _with_referer(stream_url, page_url):
    """
    Append Referer and User-Agent HTTP headers to a stream URL using Kodi's
    pipe-delimited format:  url|Referer=...&User-Agent=...
    This allows the media server to accept the request as a legitimate browser.
    """
    if not stream_url or "|" in stream_url:
        return stream_url
    try:
        from urllib.parse import quote as _quote
    except ImportError:
        from urllib import quote as _quote
    referer = _quote(page_url or BASE_URL, safe="")
    ua = _quote(HEADERS["User-Agent"], safe="")
    return "{}|Referer={}&User-Agent={}".format(stream_url, referer, ua)


def _absurl(path):
    if not path:
        return ""
    if path.startswith("http"):
        return path
    if path.startswith("//"):
        return "https:" + path
    return urljoin(BASE_URL + "/", path.lstrip("/"))


# ---------------------------------------------------------------------------
# HTML parsers
# ---------------------------------------------------------------------------

class _MetaParser(HTMLParser):
    """Extract og: meta tags and <h1>."""
    def __init__(self):
        HTMLParser.__init__(self)
        self.og = {}
        self._in_h1 = False
        self._h1 = []

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag == "meta":
            prop = a.get("property", "") or a.get("name", "")
            content = a.get("content", "")
            if prop and content:
                self.og[prop] = content
        if tag == "h1":
            self._in_h1 = True
            self._h1 = []

    def handle_data(self, data):
        if self._in_h1:
            self._h1.append(data)

    def handle_endtag(self, tag):
        if tag == "h1":
            self._in_h1 = False
            self.og.setdefault("h1", "".join(self._h1).strip())


def _parse_cards(html):
    """
    Extract episode/series cards from a grid listing page.

    The old HTMLParser + depth-tracker silently dropped cards because HTML
    void elements (<img>, <br>, <input> …) increment the depth counter but
    never produce a closing tag, so the card-end comparison always missed.

    This implementation uses regex block extraction instead:
      1. <article> blocks  — never nested in WordPress themes; safe with .*?
      2. div/li grid items — 2 KB window from each card opener; avoids the
         nested-div ambiguity while still capturing all inner content.
      3. Plain <a> links   — last resort for unusual page layouts.
    """
    items = []
    seen  = set()

    # ── helpers ────────────────────────────────────────────────────────────
    _IS_FOLDER = re.compile(
        r"/category/|/tag/|/genre/|/series/|/show/|/video-serie/|/page/\d+",
        re.I
    )

    def _thumb_from_block(block):
        for attr in ("data-lazy-src", "data-src", "src"):
            m = re.search(
                r'<img\b[^>]+{}=["\']([^"\']+)["\']'.format(attr), block, re.I
            )
            if m:
                src = m.group(1).strip()
                if "data:image" not in src and re.search(
                    r'\.(jpe?g|png|webp|gif)(\?|$)', src, re.I
                ):
                    return _absurl(src)
        return ""

    def _title_from_block(block, fallback=""):
        # 1. heading tag (h2/h3/h4) – most reliable
        hm = re.search(r'<h[2-4][^>]*>(.*?)</h[2-4]>', block, re.I | re.S)
        if hm:
            t = re.sub(r"<[^>]+>", "", hm.group(1)).strip()
            if t:
                return t
        # 2. <a title="…">
        am = re.search(r'<a\b[^>]+\btitle=["\']([^"\']{2,120})["\']', block, re.I)
        if am:
            return am.group(1).strip()
        # 3. inner text of first <a> that has meaningful content
        for m in re.finditer(r'<a\b[^>]*>(.*?)</a>', block, re.I | re.S):
            t = re.sub(r"<[^>]+>", "", m.group(1)).strip()
            if len(t) > 2:
                return t
        return fallback

    # hrefs to skip in content links: JS, mailto, share buttons, CDN assets
    _SKIP_HREF = re.compile(
        r'^(?:javascript:|mailto:|#|data:)'
        r'|(?:share|tweet|facebook|pinterest|whatsapp|linkedin|reddit)',
        re.I
    )

    def _href_from_block(block):
        """Return the first internal content href found in the block."""
        for m in re.finditer(r'<a\b[^>]+href=["\']([^"\']+)["\']', block, re.I):
            raw = m.group(1).strip()
            if _SKIP_HREF.search(raw):
                continue
            h = _absurl(raw)
            if h and h not in (BASE_URL, BASE_URL + "/") and h.startswith(BASE_URL):
                return h
        return ""

    def _add(block, extra_href=""):
        href = extra_href or _href_from_block(block)
        if not href or href in seen:
            return
        title = _title_from_block(block)
        if not title:
            return
        thumb     = _thumb_from_block(block)
        is_folder = bool(_IS_FOLDER.search(href))
        seen.add(href)
        date_match = re.search(r'<time[^>]+datetime=["\']([^"\']+)', block, re.I)
        if not date_match:
            date_match = re.search(r'(?:published|post-date|entry-date)[^>]*>(.*?)<', block, re.I | re.S)
        published = re.sub(r"<[^>]+>", "", date_match.group(1)).strip() if date_match else ""
        items.append({"label": title, "url": href, "thumb": thumb,
                      "is_folder": is_folder, "published": published})

    # ── Strategy 1: <article> blocks ───────────────────────────────────────
    for block in re.findall(r'<article\b[^>]*>.*?</article>', html, re.I | re.S):
        _add(block)

    # ── Strategy 2: div / li card openers (2 KB window) ────────────────────
    if not items:
        # Do not match generic classes such as ``item`` or ``col-md-3``.
        # MegaCartoons uses ``menu-item`` for navigation entries, and the
        # generic word-boundary match used here previously treated the whole
        # navigation menu as cartoon cards.
        card_re = re.compile(
            r'<(?:div|li)\b[^>]+class=["\'][^"\']*'
            r'\b(?:video[-_]item|cartoon[-_]?item|post)\b'
            r'[^"\']*["\'][^>]*>',
            re.I
        )
        for m in card_re.finditer(html):
            block = html[m.start(): m.start() + 2048]
            _add(block)

    # ── Strategy 3: all internal <a> links (last resort) ───────────────────
    if not items:
        for m in re.finditer(
            r'<a\b[^>]+href=["\']([^"\']+)["\'][^>]*>(.*?)</a>',
            html, re.I | re.S
        ):
            raw   = m.group(1).strip()
            title = re.sub(r"<[^>]+>", "", m.group(2)).strip()
            if not title or len(title) < 3:
                continue
            if _SKIP_HREF.search(raw):
                continue
            href = _absurl(raw)
            if not href or not href.startswith(BASE_URL) or href in seen:
                continue
            seen.add(href)
            items.append({
                "label":     title,
                "url":       href,
                "thumb":     "",
                "is_folder": bool(_IS_FOLDER.search(href)),
            })

    return items


def _get_next_page(html):
    """Find next-page URL or return None."""
    patterns = [
        # MegaCartoons currently puts rel="next" before href.
        r'<link[^>]+rel=["\']next["\'][^>]+href=["\']([^"\']+)["\']',
        r'href=["\']([^"\']+)["\'][^>]*rel=["\']next["\']',
        r'<a[^>]+class=["\'][^"\']*\bnext\b[^"\']*["\'][^>]*href=["\']([^"\']+)["\']',
        r'<a[^>]+href=["\']([^"\']+)["\'][^>]*class=["\'][^"\']*\bnext\b[^"\']*["\']',
        # Search and infinite-scroll pages expose the real URL in this config.
        r'["\']nextLink["\']\s*:\s*["\']([^"\']+)["\']',
    ]
    for pat in patterns:
        m = re.search(pat, html, re.I)
        if m:
            url = _absurl(m.group(1))
            # Ignore theme controls such as href="#" and javascript links.
            if url and not url.endswith("/#") and not url.startswith("javascript:"):
                return url
    return None


# ---------------------------------------------------------------------------
# Nav / series scraping helpers
# ---------------------------------------------------------------------------

def _extract_nav_links(html):
    """
    Return all (href, label) pairs found inside <nav> or <header> elements.
    Falls back to first 12 KB of the page if no nav is found.
    """
    # Try to isolate the nav/header block
    nav_html = ""
    for tag in ("nav", "header"):
        m = re.search(
            r"<{0}[^>]*>(.*?)</{0}>".format(tag), html, re.I | re.S
        )
        if m:
            nav_html = m.group(1)
            break
    if not nav_html:
        nav_html = html[:12000]

    links = []
    seen = set()
    for m in re.finditer(
        r'<a[^>]+href=["\']([^"\'#][^"\']*)["\'][^>]*>(.*?)</a>',
        nav_html, re.I | re.S
    ):
        href = _absurl(m.group(1).strip())
        # Strip any inner HTML tags from label
        label = re.sub(r"<[^>]+>", "", m.group(2)).strip()
        if href and label and href not in seen:
            seen.add(href)
            links.append((href, label))
    return links


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def get_main_menu():
    return [
        {"label": "Latest Cartoons",  "mode": "latest",      "url": BASE_URL,
         "icon": "special://home/addons/plugin.video.cartoonio/resources/latest-v3.png",
         "info": {"plot": "Browse the newest cartoon episodes added across all available sources."}},
        {"label": "All Cartoons A-Z", "mode": "cartoons",    "url": BASE_URL + "/category/cartoons/",
         "icon": "special://home/addons/plugin.video.cartoonio/resources/az-v2.png",
         "info": {"plot": "Explore cartoons from A to Z and discover episodes from all available sources."}},
        {"label": "Series",           "mode": "series_list", "url": BASE_URL,
         "icon": "special://home/addons/plugin.video.cartoonio/resources/series-v2.png",
         "info": {"plot": "Browse complete cartoon series and explore their available seasons and episodes."}},
        {"label": "Search", "mode": "search", "url": "",
         "icon": "special://home/addons/plugin.video.cartoonio/resources/search-v1.png",
         "info": {"plot": "Search for cartoon series and episodes."}},
        {"label": "Tools",            "mode": "tools",      "url": "",
         "icon": "special://home/addons/plugin.video.cartoonio/resources/tools-v2.png",
         "info": {"plot": "Manage Cartoonio tools, view the changelog, and clear cached data."}},
    ]


def _scrape_video_serie_links(html):
    """
    Find all /video-serie/{slug}/ links in a page and return
    list of {label, url} dicts, deduped.
    """
    series = []
    seen = set()
    for m in re.finditer(
        r'<a[^>]+href=["\']([^"\']*\/video-serie\/[^"\']+)["\'][^>]*>(.*?)<\/a>',
        html, re.I | re.S
    ):
        href = _absurl(m.group(1).strip())
        label = re.sub(r"<[^>]+>", "", m.group(2)).strip()
        if href and label and href not in seen:
            seen.add(href)
            series.append({"label": label, "url": href})
    return series


def get_series_list():
    """
    Return a list of {label, url} series items, pointing at /video-serie/ pages.

    Strategy (in order):
      1. Homepage HTML — scrape all /video-serie/ hrefs (nav SERIES dropdown)
      2. Dedicated series listing page at /video-serie/ or /series/
      3. All-cartoons page /category/cartoons/ — pick out /video-serie/ links
    """
    series = []
    seen_urls = set()

    def _merge(items):
        for item in items:
            if item["url"] not in seen_urls and item["label"]:
                seen_urls.add(item["url"])
                series.append(item)

    # --- 1. Homepage HTML — SERIES nav dropdown ---
    html = _fetch(BASE_URL)
    if html:
        _merge(_scrape_video_serie_links(html))

    # --- 2. Dedicated listing pages ---
    if not series:
        for listing_url in (
            BASE_URL + "/video-serie/",
            BASE_URL + "/series/",
        ):
            html2 = _fetch(listing_url)
            if html2:
                _merge(_scrape_video_serie_links(html2))
                # Also try card links on listing page
                for card in _parse_cards(html2):
                    if "/video-serie/" in card["url"] and card["url"] not in seen_urls:
                        seen_urls.add(card["url"])
                        series.append({"label": card["label"], "url": card["url"]})
                if series:
                    break

    # --- 3. Category/cartoons page ---
    if not series:
        html3 = _fetch(BASE_URL + "/category/cartoons/")
        if html3:
            _merge(_scrape_video_serie_links(html3))

    return sorted(series, key=lambda x: x["label"].lower())


def get_categories():
    """
    Build a category list from the site.
    Tries category/tag links first; falls back to series list; then A-Z.
    """
    html = _fetch(BASE_URL)
    cats = []
    seen = set()

    if html:
        # Category/tag links anywhere on the page
        for m in re.finditer(
            r'<a[^>]+href=["\']([^"\']*(?:category|tag|genre)[^"\']*)["\'][^>]*>([^<]{1,80})</a>',
            html, re.I
        ):
            href = _absurl(m.group(1).strip())
            label = m.group(2).strip()
            if href and label and href not in seen:
                cats.append({"label": label, "url": href})
                seen.add(href)

    # Fallback: reuse series list (still useful as "browse by show" categories)
    if not cats:
        cats = get_series_list()

    # Last resort: A–Z letter browse
    if not cats:
        for ch in "ABCDEFGHIJKLMNOPQRSTUVWXYZ":
            cats.append({
                "label": ch,
                "url":   "{}/cartoons/?letter={}".format(BASE_URL, ch.lower()),
            })

    return cats


def get_cartoons_page(url, page=1):
    # Navigation may pass the previous provider's explicit page URL.
    # Rebuild from the category root rather than appending page segments.
    url = re.sub(r"/page/\d+/?$", "/", url)
    if page > 1:
        url = url.rstrip("/") + "/page/{}/".format(page)
    html = _fetch(url)
    if not html:
        return {"items": [], "next_page_url": None}
    return {"items": _parse_cards(html), "next_page_url": _get_next_page(html)}


def get_latest(url=BASE_URL, page=1):
    url = re.sub(r"/page/\d+/?$", "/", url)
    if page > 1:
        url = BASE_URL + "/page/{}/".format(page)
    html = _fetch(url)
    if not html:
        return {"items": [], "next_page_url": None}
    return {"items": _parse_cards(html), "next_page_url": _get_next_page(html)}


def _scrape_episode_links(html, series_url="", series_slug=""):
    """
    Extract episode links from a series page by scanning ALL <a href> tags.
    Layout-agnostic — works with article grids, plain lists, image galleries,
    or any other page structure.

    Filtering strategy (layered):
      1. Hard exclusions — skip known non-episode URL patterns (taxonomy, WP
         admin, social domains, pagination, bare domain).
      2. Positive slug match — if the series slug is known (e.g. "batman-beyond"),
         only accept hrefs that contain that slug.  Episode pages on
         megacartoons.net always include the series name in their URL slug.
      3. Skip the series page itself to avoid a self-link.

    Label priority:  link inner-text → img[alt] → a[title] → URL slug
    Thumb priority:  img[data-lazy-src] → img[data-src] → img[src]
    """
    seen  = set()
    items = []

    # Hard exclusion patterns — always skip
    NOT_EP = re.compile(
        r'/category/|/tag/|/video-serie/|/page/\d+'
        r'|/wp-(?:content|admin|login|json)'
        r'|(?:facebook|twitter|youtube|instagram|pinterest|t\.co)\.com'
        r'|/feed/?$|/sitemap|/about|/contact|/privacy|/terms',
        re.I
    )

    series_slug_lc = series_slug.lower()

    for m in re.finditer(r'<a\b([^>]*)>(.*?)</a>', html, re.I | re.S):
        attrs_str = m.group(1)
        inner     = m.group(2)

        # ── href ──────────────────────────────────────────────────────────
        hm = re.search(r'\bhref=["\']([^"\']+)["\']', attrs_str, re.I)
        if not hm:
            continue
        raw = hm.group(1).strip()
        if not raw or raw[0] in ('#',):
            continue
        if raw.startswith(('javascript:', 'mailto:', 'data:')):
            continue
        href = _absurl(raw)
        if not href.startswith(BASE_URL):
            continue
        if NOT_EP.search(href):
            continue

        # Positive slug filter: only accept URLs that contain the series slug
        if series_slug_lc and series_slug_lc not in href.lower():
            continue

        # Skip bare domain and the series page itself
        stripped = href.rstrip('/')
        if stripped == BASE_URL.rstrip('/'):
            continue
        if series_url and stripped == series_url.rstrip('/'):
            continue
        if href in seen:
            continue

        # ── label ─────────────────────────────────────────────────────────
        label = re.sub(r'<[^>]+>', '', inner).strip()
        if not label or len(label) < 2:
            # image-only link — use img alt
            img_m = re.search(r'<img\b[^>]+alt=["\']([^"\']+)["\']', inner, re.I)
            if img_m:
                label = img_m.group(1).strip()
        if not label or len(label) < 2:
            # a[title]
            tm = re.search(r'\btitle=["\']([^"\']+)["\']', attrs_str, re.I)
            if tm:
                label = tm.group(1).strip()
        if not label or len(label) < 2:
            # derive readable label from URL slug
            slug  = href.rstrip('/').rsplit('/', 1)[-1]
            label = slug.replace('-', ' ').replace('_', ' ').title()
        if not label or len(label) < 2:
            continue

        # ── thumbnail (from img inside the <a>) ───────────────────────────
        thumb = ""
        for attr in ("data-lazy-src", "data-src", "src"):
            im = re.search(
                r'<img\b[^>]+{}=["\']([^"\']+)["\']'.format(attr), inner, re.I
            )
            if im:
                src = im.group(1).strip()
                if "data:image" not in src:
                    thumb = _absurl(src)
                    break

        seen.add(href)
        items.append({
            "label":     label,
            "url":       href,
            "thumb":     thumb,
            "is_folder": False,
        })

    xbmc.log(
        "Cartoonio _scrape_episode_links: {} items from {}".format(len(items), series_url),
        xbmc.LOGDEBUG
    )
    return items


def get_series_episodes(url, page=1):
    """
    Return all episodes for a /video-serie/{slug}/ page.

    Primary:  _scrape_episode_links — scans all <a> tags filtered by series slug.
    Fallback: _parse_cards          — article/div card grid extraction.
    """
    # Extract series slug from the URL so the link filter can use it
    # e.g. ".../video-serie/batman-beyond/" → "batman-beyond"
    slug_m = re.search(r'/video-serie/([^/?#]+)', url)
    series_slug = slug_m.group(1).strip('/') if slug_m else ""

    page_url = url.rstrip("/")
    if page > 1:
        page_url = "{}/page/{}/".format(page_url, page)
    page_url = page_url.rstrip("/") + "/"

    html = _fetch(page_url)
    if not html:
        return {"items": [], "next_page_url": None}

    # Never allow the series page or another taxonomy page to be rendered as
    # an episode.  If one of those links leaks from a changed card layout,
    # Kodi appears to reopen the same show instead of moving forward.
    series_page = page_url.rstrip("/").lower()

    def _is_episode_item(item):
        href = (item.get("url") or "").rstrip("/").lower()
        if not href or href == series_page:
            return False
        if not href.startswith(BASE_URL.lower()):
            return False
        if re.search(
            r"/video-serie/|/category/|/tag/|/genre/|/series/|/show/"
            r"|/page/\d+/?$|/feed/?$|/sitemap",
            href,
            re.I,
        ):
            return False
        return True

    # Pass 1: card-grid extraction (primary — most precise).
    # Episode pages use <div class="video-item"> cards.  _parse_cards now
    # targets those content-card classes only, so navigation ``menu-item``
    # entries cannot leak into the episode list.
    items = [
        item for item in _parse_cards(html)
        if not item.get("is_folder") and _is_episode_item(item)
    ]
    xbmc.log(
        "Cartoonio get_series_episodes: _parse_cards={} url={}".format(
            len(items), page_url
        ),
        xbmc.LOGDEBUG
    )

    # Pass 2: slug-filtered link scan (fallback when page uses no card markup).
    # Only links whose URL contains the series slug are accepted.
    if not items and series_slug:
        xbmc.log("Cartoonio: cards empty, trying slug-filtered link scan", xbmc.LOGDEBUG)
        items = _scrape_episode_links(html, series_url=page_url, series_slug=series_slug)

    # Pass 3: unconstrained link scan (last resort — any internal episode-like link).
    if not items:
        xbmc.log("Cartoonio: slug filter empty, trying unconstrained link scan", xbmc.LOGDEBUG)
        items = _scrape_episode_links(html, series_url=page_url, series_slug="")

    # Apply the same guard to fallback results.  This also protects against
    # future site navigation links being mistaken for playable episodes.
    items = [item for item in items if _is_episode_item(item)]

    return {"items": items, "next_page_url": _get_next_page(html)}


def get_all_series_episodes(url, max_pages=50):
    """Collect every paginated episode card before the UI groups seasons.

    A season folder is a view over the complete series, not over one website
    page.  Returning pagination to the season view made the same season folders
    appear again behind a misleading ``Next Page`` item.
    """
    items = []
    seen_items = set()
    for page_number in range(1, max_pages + 1):
        result = get_series_episodes(url, page=page_number)
        added = 0
        for item in result.get("items", []):
            item_url = (item.get("url") or "").split("#", 1)[0].rstrip("/")
            if not item_url or item_url in seen_items:
                continue
            seen_items.add(item_url)
            items.append(item)
            added += 1

        # No forward link means the series is complete.  Also stop if a theme
        # emitted a bogus pagination URL but the next page added nothing.
        if not result.get("next_page_url") or not added:
            break

    return {"items": items, "next_page_url": None}


def search(query, page=1):
    encoded = quote_plus(query)
    if page > 1:
        url = "{}/page/{}/".format(BASE_URL, page) + "?s={}".format(encoded)
    else:
        url = "{}/?s={}".format(BASE_URL, encoded)
    html = _fetch(url)
    if not html:
        return {"items": [], "next_page_url": None}
    return {"items": _parse_cards(html), "next_page_url": _get_next_page(html)}


# ---------------------------------------------------------------------------
# JSON-LD extraction (primary stream + metadata source)
# ---------------------------------------------------------------------------

def _parse_jsonld(html):
    """
    Parse all <script type="application/ld+json"> blocks and return a merged
    dict of useful fields found in VideoObject / BreadcrumbList schemas.
    Keys returned: contentUrl, embedUrl, name, description, thumbnailUrl,
                   uploadDate, seriesName, seasonNumber, episodeNumber.
    """
    result = {}
    blocks = re.findall(
        r'<script[^>]+type=["\']application/ld\+json["\'][^>]*>(.*?)</script>',
        html, re.I | re.S
    )
    for raw in blocks:
        try:
            data = json.loads(raw.strip())
        except Exception:
            # Some pages have slightly malformed JSON — try cleaning it
            try:
                cleaned = re.sub(r',\s*([}\]])', r'\1', raw.strip())
                data = json.loads(cleaned)
            except Exception:
                continue

        # Normalise to a list so we handle both single objects and @graph arrays
        objects = data if isinstance(data, list) else [data]
        graph = []
        for obj in objects:
            graph.append(obj)
            if isinstance(obj, dict):
                graph.extend(obj.get("@graph", []))

        for obj in graph:
            if not isinstance(obj, dict):
                continue
            obj_type = obj.get("@type", "")
            # obj_type may be a string or a list
            obj_type_str = " ".join(obj_type) if isinstance(obj_type, list) else str(obj_type)

            # VideoObject ONLY — the stream contentUrl lives here.
            # Do NOT match on obj.get("contentUrl") alone; that would capture
            # ImageObject entries whose contentUrl is a JPEG thumbnail.
            if "VideoObject" in obj_type_str:
                if obj.get("contentUrl") and "contentUrl" not in result:
                    url_val = obj["contentUrl"].strip()
                    # Only store if it looks like a real video URL (not an image)
                    if not re.search(r'\.(jpe?g|png|gif|webp|bmp|svg)(\?|$)', url_val, re.I):
                        result["contentUrl"] = url_val
                if obj.get("embedUrl") and "embedUrl" not in result:
                    result["embedUrl"] = obj["embedUrl"].strip()
                if obj.get("name") and "name" not in result:
                    result["name"] = obj["name"].strip()
                if obj.get("description") and "description" not in result:
                    result["description"] = obj["description"].strip()
                if obj.get("thumbnailUrl") and "thumbnailUrl" not in result:
                    tn = obj["thumbnailUrl"]
                    result["thumbnailUrl"] = (tn[0] if isinstance(tn, list) else tn).strip()
                if obj.get("uploadDate") and "uploadDate" not in result:
                    result["uploadDate"] = obj["uploadDate"]

                # Series / season / episode info nested inside VideoObject
                part_of = obj.get("partOfSeason") or obj.get("partOfEpisode") or {}
                series = obj.get("partOfSeries") or (
                    part_of.get("partOfSeries") if isinstance(part_of, dict) else None
                ) or {}
                if isinstance(series, dict) and series.get("name"):
                    result.setdefault("seriesName", series["name"].strip())
                if isinstance(part_of, dict):
                    if part_of.get("seasonNumber") and "seasonNumber" not in result:
                        result["seasonNumber"] = int(part_of["seasonNumber"])
                if obj.get("episodeNumber") and "episodeNumber" not in result:
                    result["episodeNumber"] = int(obj["episodeNumber"])

            # TVSeries / TVSeason for series name
            if obj_type_str in ("TVSeries", "TVSeason") and obj.get("name"):
                result.setdefault("seriesName", obj["name"].strip())

            # BreadcrumbList — extract series name from position 2
            if "BreadcrumbList" in obj_type_str:
                items = obj.get("itemListElement", [])
                if isinstance(items, list) and len(items) >= 2:
                    crumb = items[-2] if len(items) >= 2 else {}
                    if isinstance(crumb, dict):
                        name = (crumb.get("name") or
                                (crumb.get("item") or {}).get("name", ""))
                        if name:
                            result.setdefault("seriesName", name.strip())

    return result


# ---------------------------------------------------------------------------
# Episode stream extraction
# ---------------------------------------------------------------------------

def get_episode_page(url):
    """
    Extract all playable stream URLs from an episode page.
    Priority:
      1. JSON-LD contentUrl  (direct .mp4 — most reliable)
      2. JSON-LD embedUrl
      3. <video>/<source> tags
      4. JWPlayer / VideoJS script patterns
      5. Bare mp4/m3u8 URLs in page source
      6. iframe embedded players
    """
    html = _fetch(url)
    if not html:
        return []

    streams = []
    seen = set()

    def _add(label, stream_url):
        if not stream_url:
            return
        stream_url = unescape(stream_url).replace(r"\/", "/").strip().strip("'\"")
        # JSON-LD includes Kodi headers while player scripts expose the same
        # URL without them. Compare the media URL, preserving signed queries.
        media_url = stream_url.split("|", 1)[0]
        if not media_url.startswith(("https://", "http://")):
            return
        if media_url in seen:
            # Keep the version carrying playback headers when discovered later.
            if "|" in stream_url:
                for stream in streams:
                    if stream["url"].split("|", 1)[0] == media_url and "|" not in stream["url"]:
                        stream["url"] = stream_url
                        break
            return
        seen.add(media_url)
        streams.append({"label": label, "url": stream_url})

    # 1. JSON-LD VideoObject — direct contentUrl (.mp4)
    ld = _parse_jsonld(html)
    if ld.get("contentUrl"):
        _add("MP4", _with_referer(ld["contentUrl"], url))
    if ld.get("embedUrl"):
        _add("Embed", ld["embedUrl"])

    # 2. <video src> and <source src>
    for m in re.finditer(r'<(?:video|source)[^>]+src=["\']([^"\']+)["\']', html, re.I):
        u = _absurl(m.group(1))
        if re.search(r'\.(mp4|m3u8|webm|mkv)', u, re.I):
            _add("Direct", u)

    # 3. JWPlayer / VideoJS: "file":"url"
    for m in re.finditer(r'"file"\s*:\s*"(https?://[^"]+)"', html):
        _add("JW Stream", m.group(1))
    for m in re.finditer(r"'file'\s*:\s*'(https?://[^']+)'", html):
        _add("JW Stream", m.group(1))

    # 4. Sources array: {file:"url"} or {"file":"url"}
    for m in re.finditer(
        r'\{[^}]*["\']?file["\']?\s*:\s*["\']?(https?://[^"\'}\s,]+)', html
    ):
        u = m.group(1).rstrip("'\"")
        _add("Source", u)

    # 5. Bare .mp4 / .m3u8 URLs anywhere in page source
    for m in re.finditer(r'(https?://[^\s"\'<>{}\[\]]+\.mp4(?:\?[^\s"\'<>]*)?)', html):
        _add("MP4", _with_referer(m.group(1), url))
    for m in re.finditer(r'(https?://[^\s"\'<>{}\[\]]+\.m3u8(?:\?[^\s"\'<>]*)?)', html):
        _add("HLS", _with_referer(m.group(1), url))

    # 6. iframes — resolve embedded players
    for m in re.finditer(r'<iframe[^>]+src=["\']([^"\']+)["\']', html, re.I):
        iframe_url = _absurl(m.group(1))
        if iframe_url and "megacartoons" not in iframe_url:
            _resolve_iframe(iframe_url, _add)

    return streams


def _resolve_iframe(iframe_url, add_fn):
    html = _fetch(iframe_url)
    if not html:
        return
    ld = _parse_jsonld(html)
    if ld.get("contentUrl"):
        add_fn("Embedded MP4", ld["contentUrl"])
    for m in re.finditer(r'(https?://[^\s"\'<>]+\.mp4(?:\?[^\s"\'<>]*)?)', html):
        add_fn("Embedded MP4", m.group(1))
    for m in re.finditer(r'(https?://[^\s"\'<>]+\.m3u8(?:\?[^\s"\'<>]*)?)', html):
        add_fn("Embedded HLS", m.group(1))
    for m in re.finditer(r'"file"\s*:\s*"(https?://[^"]+)"', html):
        add_fn("Embedded JW", m.group(1))


def get_episode_info(url):
    """
    Return metadata dict for an episode page.
    Tries JSON-LD first for richest data, then falls back to og: meta tags.
    """
    html = _fetch(url)
    if not html:
        return {}

    # --- JSON-LD (primary) ---
    ld = _parse_jsonld(html)

    # --- og: meta tags (fallback) ---
    mp = _MetaParser()
    try:
        mp.feed(html[:25000])
    except Exception:
        pass

    title = (
        ld.get("name")
        or mp.og.get("og:title")
        or mp.og.get("h1")
        or ""
    ).strip()
    title = re.sub(r"\s*[-|]\s*megacartoons.*$", "", title, flags=re.I).strip()

    plot = (ld.get("description") or mp.og.get("og:description") or "").strip()
    thumb = (ld.get("thumbnailUrl") or mp.og.get("og:image") or "").strip()

    # Season / episode numbers
    season  = ld.get("seasonNumber", 0)
    ep_num  = ld.get("episodeNumber", 0)
    if not season or not ep_num:
        combined = title + " " + url
        if not season:
            m = re.search(r'[Ss]eason\s*(\d+)', combined)
            if m:
                season = int(m.group(1))
        if not ep_num:
            m = re.search(r'[Ee]p(?:isode)?\s*(\d+)', combined)
            if m:
                ep_num = int(m.group(1))

    # Series name
    series_title = ld.get("seriesName", "")
    if not series_title:
        # Fallback: HTML breadcrumb
        bc_m = re.search(
            r'<(?:nav|div|ol|ul)[^>]*breadcrumb[^>]*>(.*?)</(?:nav|div|ol|ul)>',
            html, re.I | re.S
        )
        if bc_m:
            # Breadcrumbs often end with an unlinked episode title, so the
            # last link is the series; indexing [-2] incorrectly chose Home.
            for href, text in re.findall(
                r'<a\b[^>]*href=["\']([^"\']+)["\'][^>]*>(.*?)</a>',
                bc_m.group(1), re.I | re.S
            ):
                if re.search(r'/(?:video-serie|serie|series)/[^/?#]+', href, re.I):
                    series_title = re.sub(r'<[^>]+>', '', text).strip()

    return {
        "title":        title,
        "plot":         plot,
        "thumb":        thumb,
        "series_title": series_title,
        "season":       season,
        "episode_num":  ep_num,
    }
