"""TopCartoons.tv episode lookup and stream extraction."""

import json
import re
import unicodedata

try:
    from html import unescape
    from urllib.parse import quote_plus, urljoin
    from urllib.request import Request, build_opener, HTTPCookieProcessor
    from urllib.error import HTTPError, URLError
    from http.cookiejar import CookieJar
except ImportError:
    from HTMLParser import HTMLParser
    unescape = HTMLParser().unescape
    from urllib import quote_plus
    from urlparse import urljoin
    from urllib2 import Request, build_opener, HTTPCookieProcessor, HTTPError, URLError
    from cookielib import CookieJar

import xbmc
import diskcache
from pagination import next_page_url


BASE_URL = "https://www.topcartoons.tv"
HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/120.0.0.0 Safari/537.36"
    ),
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
}
_OPENER = build_opener(HTTPCookieProcessor(CookieJar()))


def _fetch(url, timeout=15):
    cached = diskcache.get("topcartoons_html", url, 1800)
    if cached is not None:
        return cached
    try:
        response = _OPENER.open(Request(url, headers=HEADERS), timeout=timeout)
        raw = response.read()
        html = raw.decode("utf-8", errors="replace")
        if html:
            diskcache.set("topcartoons_html", url, html)
        return html
    except (HTTPError, URLError) as exc:
        xbmc.log("Cartoonio TopCartoons fetch error {}: {}".format(url, exc), xbmc.LOGWARNING)
    except Exception as exc:
        xbmc.log("Cartoonio TopCartoons unexpected error {}: {}".format(url, exc), xbmc.LOGWARNING)
    return ""


def _plain(value):
    value = unescape(re.sub(r"<[^>]+>", "", value or ""))
    value = unicodedata.normalize("NFKD", value)
    value = "".join(ch for ch in value if not unicodedata.combining(ch))
    return re.sub(r"[^a-z0-9]+", " ", value.lower()).strip()


def _slug(value):
    return _plain(value).replace(" ", "-")


def _page_title(html):
    match = re.search(
        r'<meta[^>]+property=["\']og:title["\'][^>]+content=["\']([^"\']+)',
        html, re.I,
    )
    if not match:
        match = re.search(r"<title[^>]*>(.*?)</title>", html, re.I | re.S)
    return unescape(match.group(1)).strip() if match else ""


def _score_page(html, episode_title, series_title=""):
    title = _plain(_page_title(html))
    episode = _plain(episode_title)
    if not title or not episode or episode not in title:
        return 0
    score = 100 if title.startswith(episode) else 60
    if series_title and _plain(series_title) in title:
        score += 50
    return score


def _search_candidates(episode_title):
    html = _fetch("{}/?s={}".format(BASE_URL, quote_plus(episode_title)))
    if not html:
        return []
    found = []
    seen = set()
    for match in re.finditer(
        r'<a\b[^>]+href=["\'](https?://(?:www\.)?topcartoons\.tv/cartoons/[^"\']+)["\'][^>]*>',
        html, re.I,
    ):
        url = unescape(match.group(1)).split("#", 1)[0]
        if url not in seen:
            seen.add(url)
            found.append(url)
    return found[:12]


def _article_items(html, path_part):
    """Extract unique series or episode cards from TopCartoons markup."""
    items = []
    seen = set()
    pattern = (
        r'<a\b[^>]+href=["\'](https?://(?:www\.)?topcartoons\.tv/'
        + path_part
        + r'/[^"\']+)["\'][^>]*\btitle=["\']([^"\']+)["\'][^>]*>(.*?)</a>'
    )
    for match in re.finditer(pattern, html, re.I | re.S):
        url = unescape(match.group(1)).replace("&#038;", "&")
        url = url.split("#", 1)[0]
        # Query parameters identify the parent series but are not needed to play.
        if path_part == "cartoons":
            url = url.split("?", 1)[0]
        if url in seen:
            continue
        title = unescape(match.group(2)).strip()
        block = match.group(3)
        thumb_match = re.search(
            r'<img\b[^>]+(?:data-src|src)=["\']([^"\']+)["\']', block, re.I
        )
        thumb = unescape(thumb_match.group(1)) if thumb_match else ""
        if "placeholder.png" in thumb:
            lazy = re.search(r'\bdata-src=["\']([^"\']+)["\']', block, re.I)
            thumb = unescape(lazy.group(1)) if lazy else ""
        seen.add(url)
        date_match = re.search(r'<time[^>]+datetime=["\']([^"\']+)', block, re.I)
        items.append({
            "label": title,
            "url": url,
            "thumb": thumb,
            "is_folder": path_part == "serie",
            "published": date_match.group(1) if date_match else "",
        })
    return items


def get_series_list():
    """List the shows published on TopCartoons."""
    html = _fetch(BASE_URL + "/serie/")
    return _article_items(html, "serie") if html else []


def get_latest(page=1):
    """Return TopCartoons' newest episode cards."""
    url = BASE_URL + "/"
    if page > 1:
        url = BASE_URL + "/page/{}/".format(page)
    html = _fetch(url)
    return {"items": _article_items(html, "cartoons"), "next_page_url": next_page_url(html, url)}


def get_cartoons_page(page=1, url=None):
    """Return TopCartoons' all-cartoons listing."""
    url = re.sub(r"/page/\d+/?$", "/", url or BASE_URL + "/cartoons/category/cartoons/")
    if page > 1:
        url = url.rstrip("/") + "/page/{}/".format(page)
    html = _fetch(url)
    return {"items": _article_items(html, "cartoons"), "next_page_url": next_page_url(html, url)}


def get_series_episodes(url, page=1):
    """List every episode exposed on a TopCartoons series page."""
    page_url = url
    if page > 1:
        page_url = url.rstrip("/") + "/page/{}/".format(page)
    html = _fetch(page_url)
    if not html:
        return {"items": [], "next_page_url": None}
    items = _article_items(html, "cartoons")
    return {
        "items": items,
        "next_page_url": next_page_url(html, page_url),
    }


def get_all_series_episodes(url, max_pages=50):
    """Collect remote pages before the merged catalogue groups seasons."""
    items = []
    seen = set()
    for page in range(1, max_pages + 1):
        result = get_series_episodes(url, page=page)
        added = 0
        for item in result.get("items", []):
            key = item.get("url")
            if key and key not in seen:
                seen.add(key)
                items.append(item)
                added += 1
        if not added or not result.get("next_page_url"):
            break
    return {"items": items, "next_page_url": None}


def find_episode(episode_title, series_title=""):
    """Return ``(page_url, html)`` for the best matching episode page."""
    if not episode_title:
        return "", ""

    direct_url = "{}/cartoons/{}/".format(BASE_URL, _slug(episode_title))
    candidates = [direct_url] + [u for u in _search_candidates(episode_title) if u != direct_url]
    best = (0, "", "")
    for url in candidates:
        html = _fetch(url)
        if not html:
            continue
        score = _score_page(html, episode_title, series_title)
        if score > best[0]:
            best = (score, url, html)
        if score >= 150:
            break
    return best[1], best[2]


def _video_urls(html):
    urls = []

    # TopCartoons currently publishes the direct MP4 in this Open Graph tag.
    for match in re.finditer(
        r'<meta[^>]+property=["\']og:video(?::url)?["\'][^>]+content=["\']([^"\']+)',
        html, re.I,
    ):
        urls.append(unescape(match.group(1)))

    # Also parse VideoObject JSON-LD, which is less dependent on tag ordering.
    for raw in re.findall(
        r'<script[^>]+type=["\']application/ld\+json["\'][^>]*>(.*?)</script>',
        html, re.I | re.S,
    ):
        try:
            data = json.loads(raw.strip())
        except Exception:
            continue
        pending = data if isinstance(data, list) else [data]
        while pending:
            item = pending.pop(0)
            if isinstance(item, list):
                pending.extend(item)
            elif isinstance(item, dict):
                item_type = item.get("@type", "")
                types = item_type if isinstance(item_type, list) else [item_type]
                if "VideoObject" in types and item.get("contentUrl"):
                    urls.append(item["contentUrl"])
                pending.extend(v for v in item.values() if isinstance(v, (dict, list)))

    for match in re.finditer(r'https?://[^\s"\'<>]+\.mp4(?:\?[^\s"\'<>]*)?', html, re.I):
        urls.append(match.group(0).replace(r"\/", "/"))
    return urls


def get_episode_page(episode_title, series_title=""):
    """Find a TopCartoons episode and return streams in Cartoonio format."""
    page_url, html = find_episode(episode_title, series_title)
    if not html:
        return []
    streams = []
    seen = set()
    for raw_url in _video_urls(html):
        url = urljoin(BASE_URL + "/", unescape(raw_url).replace(r"\/", "/"))
        if not re.search(r"\.(mp4|m3u8)(?:\?|$)", url, re.I) or url in seen:
            continue
        seen.add(url)
        label = "TopCartoons HLS" if ".m3u8" in url.lower() else "TopCartoons MP4"
        streams.append({"label": label, "url": url, "referer": page_url})
    return streams


def get_url_streams(page_url):
    """Extract streams directly when browsing a TopCartoons episode URL."""
    html = _fetch(page_url)
    if not html:
        return []
    streams = []
    seen = set()
    for raw_url in _video_urls(html):
        url = urljoin(BASE_URL + "/", unescape(raw_url).replace(r"\/", "/"))
        if not re.search(r"\.(mp4|m3u8)(?:\?|$)", url, re.I) or url in seen:
            continue
        seen.add(url)
        label = "TopCartoons HLS" if ".m3u8" in url.lower() else "TopCartoons MP4"
        streams.append({"label": label, "url": url, "referer": page_url})
    return streams
