"""Small persistent JSON cache stored in Kodi's addon profile directory."""

import hashlib
import json
import os
import time
import threading
import re
from collections import OrderedDict

import xbmcaddon
import xbmcvfs

_MEMORY = OrderedDict()
_MEMORY_LOCK = threading.RLock()
_MEMORY_LIMIT = 256
BYPASS_PROVIDER_READS = False


def _cache_root():
    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo("profile"))
    if not profile:
        raise ValueError("Addon profile is unavailable")
    root = os.path.abspath(os.path.join(os.path.realpath(profile), "cache"))
    if os.path.normcase(os.path.realpath(root)) != os.path.normcase(root):
        raise ValueError("Cache directory redirects outside its expected path")
    return root


def _namespace_path(namespace):
    if not isinstance(namespace, str) or not re.fullmatch(r"[A-Za-z0-9_-]+", namespace):
        raise ValueError("Invalid cache namespace")
    folder = os.path.join(_cache_root(), namespace)
    if os.path.normcase(os.path.realpath(folder)) != os.path.normcase(folder):
        raise ValueError("Redirected cache namespace")
    return folder


def _cache_path(namespace, key):
    folder = _namespace_path(namespace)
    digest = hashlib.sha256(key.encode("utf-8")).hexdigest()
    return os.path.join(folder, digest + ".json")


def get(namespace, key, max_age):
    if BYPASS_PROVIDER_READS and namespace != "tmdb":
        return None
    memory_key = (namespace, key)
    now = time.time()
    with _MEMORY_LOCK:
        cached = _MEMORY.get(memory_key)
        if cached:
            created, value = cached
            if now - created <= max_age:
                _MEMORY.move_to_end(memory_key)
                return value
            _MEMORY.pop(memory_key, None)
    try:
        path = _cache_path(namespace, key)
        if not xbmcvfs.exists(path):
            return None
        handle = xbmcvfs.File(path)
        try:
            raw = handle.read()
        finally:
            handle.close()
        record = json.loads(raw)
        created = float(record.get("created", 0))
        if now - created > max_age:
            return None
        value = record.get("value")
        with _MEMORY_LOCK:
            _MEMORY[memory_key] = (created, value)
            _MEMORY.move_to_end(memory_key)
            while len(_MEMORY) > _MEMORY_LIMIT:
                _MEMORY.popitem(last=False)
        return value
    except Exception:
        return None


def set(namespace, key, value):
    memory_key = (namespace, key)
    created = time.time()
    with _MEMORY_LOCK:
        _MEMORY[memory_key] = (created, value)
        _MEMORY.move_to_end(memory_key)
        while len(_MEMORY) > _MEMORY_LIMIT:
            _MEMORY.popitem(last=False)
    try:
        path = _cache_path(namespace, key)
        xbmcvfs.mkdirs(os.path.dirname(path))
        handle = xbmcvfs.File(path, "w")
        try:
            handle.write(json.dumps({"created": created, "value": value}))
        finally:
            handle.close()
    except Exception:
        pass

def clear(namespace=None, detailed=False):
    """Clear addon caches, optionally returning file counts for user feedback."""
    report = {"removed": 0, "failed": 0, "success": True}
    try:
        root = _cache_root() if namespace is None else _namespace_path(namespace)
    except Exception:
        report.update(success=False, failed=1)
        return report if detailed else False
    with _MEMORY_LOCK:
        if namespace is None:
            _MEMORY.clear()
        else:
            for key in list(_MEMORY):
                if key[0] == namespace:
                    _MEMORY.pop(key, None)
    def remove_tree(folder):
        success = True
        try:
            # Never traverse junctions/symlinks, even inside the cache tree.
            # This also prevents redirected directories from forming cycles.
            if os.path.normcase(os.path.realpath(folder)) != os.path.normcase(os.path.abspath(folder)):
                raise ValueError("Redirected cache directory")
            if os.path.commonpath([root, os.path.abspath(folder)]) != root:
                raise ValueError("Cache path escapes cleanup root")
            dirs, files = xbmcvfs.listdir(folder)
        except Exception:
            report["failed"] += 1
            return False
        for filename in files:
            path = os.path.join(folder, filename)
            try:
                xbmcvfs.delete(path)
                if xbmcvfs.exists(path):
                    report["failed"] += 1
                    success = False
                else:
                    report["removed"] += 1
            except Exception:
                report["failed"] += 1
                success = False
        for dirname in dirs:
            if not remove_tree(os.path.join(folder, dirname)):
                success = False
        # Do not force recursive removal: verify files individually and keep
        # trying other namespaces even when one file is locked.
        try:
            xbmcvfs.rmdir(folder)
            if xbmcvfs.exists(folder.rstrip("/\\") + os.sep):
                # Count a folder failure only if its contents were removed.
                if success:
                    report["failed"] += 1
                success = False
        except Exception:
            if success:
                report["failed"] += 1
            success = False
        return success

    try:
        # Kodi distinguishes directory checks by their trailing separator.
        report["success"] = remove_tree(root) if xbmcvfs.exists(root.rstrip("/\\") + os.sep) else True
    except Exception:
        report["success"] = False
        report["failed"] += 1
    return report if detailed else report["success"]


def cache_info():
    """Count persisted cache files and bytes without reading their contents."""
    result = {"files": 0, "bytes": 0, "failed": 0, "namespaces": {}}
    try:
        root = _cache_root()
        if not xbmcvfs.exists(root.rstrip("/\\") + os.sep):
            return result
        def count(folder):
            if os.path.normcase(os.path.realpath(folder)) != os.path.normcase(os.path.abspath(folder)):
                raise ValueError("Redirected cache directory")
            files_count = size = 0
            dirs, files = xbmcvfs.listdir(folder)
            for filename in files:
                try:
                    size += xbmcvfs.Stat(os.path.join(folder, filename)).st_size()
                    files_count += 1
                except Exception:
                    result["failed"] += 1
            for dirname in dirs:
                try:
                    child_count, child_size = count(os.path.join(folder, dirname))
                    files_count += child_count
                    size += child_size
                except Exception:
                    result["failed"] += 1
            return files_count, size
        dirs, files = xbmcvfs.listdir(root)
        for namespace in dirs:
            try:
                amount, size = count(os.path.join(root, namespace))
                result["namespaces"][namespace] = {"files": amount, "bytes": size}
                result["files"] += amount
                result["bytes"] += size
            except Exception:
                result["failed"] += 1
        for filename in files:
            try:
                result["bytes"] += xbmcvfs.Stat(os.path.join(root, filename)).st_size()
                result["files"] += 1
            except Exception:
                result["failed"] += 1
    except Exception:
        result["failed"] += 1
    return result
