"""Display-only listing preferences; never alter resolver titles or cached items."""

from html import unescape
import providers


def descriptions(addon):
    return addon.getSetting("show_episode_descriptions").strip().lower() != "false"


def sort_items(addon, items):
    if addon.getSetting("default_sort") == "Provider order":
        return list(items)
    return sorted(items, key=lambda item: unescape(item.get("label", "")).casefold())


def episode_info(addon, info):
    result = dict(info)
    if not descriptions(addon):
        result.pop("plot", None)
    return result


def episode_label(addon, item, title=None):
    title = item.get("label", "") if title is None else title
    if addon.getSetting("show_provider_names").strip().lower() == "true":
        label = providers.label_for_url(item.get("url", ""))
        if label:
            return "{} [COLOR FF96AABD]· {}[/COLOR]".format(title, label)
    return title
