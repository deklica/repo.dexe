"""SuperCartoons.net catalogue and direct-stream resolver."""

import json
import re
import unicodedata

try:
    from html import unescape
    from urllib.parse import quote_plus, urljoin
    from urllib.request import Request, build_opener, HTTPCookieProcessor
    from urllib.error import HTTPError, URLError
    from http.cookiejar import CookieJar
except ImportError:
    from HTMLParser import HTMLParser
    unescape = HTMLParser().unescape
    from urllib import quote_plus
    from urlparse import urljoin
    from urllib2 import Request, build_opener, HTTPCookieProcessor, HTTPError, URLError
    from cookielib import CookieJar

import xbmc
import diskcache
from pagination import next_page_url


BASE_URL = "https://www.supercartoons.net"
HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    ),
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
}
_OPENER = build_opener(HTTPCookieProcessor(CookieJar()))


def _fetch(url, timeout=15):
    cached = diskcache.get("supercartoons_html", url, 1800)
    if cached is not None:
        return cached
    try:
        response = _OPENER.open(Request(url, headers=HEADERS), timeout=timeout)
        html = response.read().decode("utf-8", errors="replace")
        if html:
            diskcache.set("supercartoons_html", url, html)
        return html
    except (HTTPError, URLError) as exc:
        xbmc.log("Cartoonio SuperCartoons fetch error {}: {}".format(url, exc), xbmc.LOGWARNING)
    except Exception as exc:
        xbmc.log("Cartoonio SuperCartoons unexpected error {}: {}".format(url, exc), xbmc.LOGWARNING)
    return ""


def _normalise_title(value):
    value = unescape(value or "").replace("’", "").replace("‘", "")
    value = value.replace("'", "").replace("`", "")
    value = unicodedata.normalize("NFKD", value)
    value = "".join(ch for ch in value if not unicodedata.combining(ch))
    return re.sub(r'[^a-z0-9]+', ' ', value.lower()).strip()


def _title_slug(value):
    return _normalise_title(value).replace(' ', '-')


def _article_items(html):
    items = []
    seen = set()
    for block_match in re.finditer(r'<article\b[^>]*>(.*?)</article>', html, re.I | re.S):
        block = block_match.group(1)
        link = re.search(
            r'<a\b[^>]+href=["\'](https?://(?:www\.)?supercartoons\.net/cartoon/[^"\']+)',
            block, re.I,
        )
        if not link:
            continue
        url = unescape(link.group(1)).split("#", 1)[0]
        if url in seen:
            continue
        title_match = re.search(r'<h[1-4][^>]*>(.*?)</h[1-4]>', block, re.I | re.S)
        if title_match:
            title = unescape(re.sub(r'<[^>]+>', '', title_match.group(1))).strip()
        else:
            title_attr = re.search(r'\btitle=["\']([^"\']+)', block, re.I)
            title = unescape(title_attr.group(1)).strip() if title_attr else ""
        if not title:
            title = url.rstrip('/').rsplit('/', 1)[-1].replace('-', ' ').title()
        image = re.search(
            r'<img\b[^>]+(?:data-src|src)=["\']([^"\']+)', block, re.I
        )
        seen.add(url)
        date_match = re.search(r'<time[^>]+datetime=["\']([^"\']+)', block, re.I)
        items.append({
            "label": title,
            "url": url,
            "thumb": urljoin(BASE_URL + "/", unescape(image.group(1))) if image else "",
            "is_folder": False,
            "published": date_match.group(1) if date_match else "",
        })
    return items


def get_series_list():
    html = _fetch(BASE_URL + "/serie/series/")
    if not html:
        return []
    items = []
    seen = set()
    for match in re.finditer(
        r'<a\b[^>]+href=["\'](https?://(?:www\.)?supercartoons\.net/serie/(?!series/?["\'])[^"\']+)["\'][^>]*>(.*?)</a>',
        html, re.I | re.S,
    ):
        url = unescape(match.group(1)).split("#", 1)[0]
        label = unescape(re.sub(r'<[^>]+>', '', match.group(2))).strip()
        if url in seen or not label:
            continue
        seen.add(url)
        items.append({"label": label, "url": url, "thumb": "", "is_folder": True})
    return items


def get_series_episodes(url, max_pages=50):
    items = []
    seen = set()
    for page in range(1, max_pages + 1):
        page_url = url if page == 1 else url.rstrip('/') + '/page/{}/'.format(page)
        html = _fetch(page_url)
        if not html:
            break
        added = 0
        for item in _article_items(html):
            if item["url"] in seen:
                continue
            seen.add(item["url"])
            items.append(item)
            added += 1
        has_next = bool(next_page_url(html, page_url))
        if not has_next or not added:
            break
    return {"items": items, "next_page_url": None}


def get_latest(page=1):
    url = BASE_URL + "/" if page == 1 else BASE_URL + "/page/{}/".format(page)
    html = _fetch(url)
    return {"items": _article_items(html), "next_page_url": next_page_url(html, url)}


def get_cartoons_page(page=1, url=None):
    url = re.sub(r"/page/\d+/?$", "/", url or BASE_URL + "/")
    if page > 1:
        url = url.rstrip("/") + "/page/{}/".format(page)
    html = _fetch(url)
    return {"items": _article_items(html), "next_page_url": next_page_url(html, url)}


def _video_urls(html):
    urls = []
    for raw in re.findall(
        r'<script[^>]+type=["\']application/ld\+json["\'][^>]*>(.*?)</script>',
        html, re.I | re.S,
    ):
        try:
            data = json.loads(raw.strip())
        except Exception:
            continue
        pending = data if isinstance(data, list) else [data]
        while pending:
            item = pending.pop(0)
            if isinstance(item, list):
                pending.extend(item)
            elif isinstance(item, dict):
                types = item.get("@type", "")
                types = types if isinstance(types, list) else [types]
                if "VideoObject" in types and item.get("contentUrl"):
                    urls.append(item["contentUrl"])
                pending.extend(v for v in item.values() if isinstance(v, (dict, list)))
    for pattern in (
        r'\bfile\s*:\s*["\'](https?://[^"\']+)',
        r'https?://[^\s"\'<>]+\.mp4(?:\?[^\s"\'<>]*)?',
    ):
        urls.extend(match.group(1) if match.lastindex else match.group(0)
                    for match in re.finditer(pattern, html, re.I))
    return urls


def get_url_streams(page_url):
    html = _fetch(page_url)
    if not html:
        return []
    streams = []
    seen = set()
    for raw_url in _video_urls(html):
        url = urljoin(BASE_URL + "/", unescape(raw_url).replace(r"\/", "/"))
        if not re.search(r'\.mp4(?:\?|$)', url, re.I) or url in seen:
            continue
        seen.add(url)
        streams.append({"label": "SuperCartoons MP4", "url": url, "referer": page_url})
    return streams


def get_episode_page(episode_title, series_title=""):
    if not episode_title:
        return []
    wanted = _normalise_title(episode_title)
    candidates = ["{}/cartoon/{}/".format(BASE_URL, _title_slug(episode_title))]
    search_title = episode_title.replace("’", "'").replace("‘", "'")
    html = _fetch("{}/?s={}".format(BASE_URL, quote_plus(search_title)))
    for match in re.finditer(
        r'href=["\'](https?://(?:www\.)?supercartoons\.net/cartoon/[^"\']+)["\']',
        html, re.I,
    ):
        url = unescape(match.group(1))
        if url not in candidates:
            candidates.append(url)
    for url in candidates[:12]:
        page = _fetch(url)
        title_match = re.search(r'<h1[^>]*>(.*?)</h1>', page, re.I | re.S)
        title = re.sub(r'<[^>]+>', '', title_match.group(1)) if title_match else ""
        normalised = _normalise_title(title)
        if normalised == wanted:
            return get_url_streams(url)
    return []
