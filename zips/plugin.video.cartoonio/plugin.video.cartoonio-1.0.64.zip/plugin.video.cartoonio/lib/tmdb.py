"""
TMDB API integration for Cartoonio Kodi addon.
Uses ONLY Python stdlib (urllib) — no requests dependency.
Compatible with Kodi 21 bundled Python 3.x.
"""

import re
from concurrent.futures import ThreadPoolExecutor
import xbmc
import diskcache
try:
    from html import unescape as _html_unescape
except ImportError:
    try:
        from HTMLParser import HTMLParser
        _html_unescape = HTMLParser().unescape
    except Exception:
        _html_unescape = lambda value: value

try:
    from urllib.request import Request, urlopen
    from urllib.parse import urlencode
    from urllib.error import URLError, HTTPError
    import json
except ImportError:
    from urllib2 import Request, urlopen, URLError, HTTPError
    from urllib import urlencode
    import json

# Default key — overridden at runtime from addon settings in default.py
TMDB_API_KEY = "f15af109700aab95d564acda15bdcd97"
TMDB_LANGUAGE = "en-US"
TMDB_BASE_URL = "https://api.themoviedb.org/3"
TMDB_IMAGE_BASE = "https://image.tmdb.org/t/p/"

POSTER_SIZE = "w500"
FANART_SIZE = "original"
STILL_SIZE = "w300"
BACKDROP_SIZE = "w1280"

_HEADERS = {
    "User-Agent": "Cartoonio/1.0 Kodi-Addon",
    "Accept": "application/json",
}

_TV_DETAILS_CACHE = {}
_TV_SEASON_CACHE = {}
_TV_EPISODE_INDEX = {}


def clear_memory_cache():
    """Drop derived TMDB metadata when the user clears Cartoonio's cache."""
    _TV_DETAILS_CACHE.clear()
    _TV_SEASON_CACHE.clear()
    _TV_EPISODE_INDEX.clear()

# TMDB uses the short title "Spider-Man" for the 1994 animated series,
# while MegaCartoons labels it "Spider-Man: The Animated Series".  Keep this
# alias narrow so similarly named Spider-Man shows are not mixed together.
_TV_SEARCH_ALIASES = {
    "spiderman the animated series": "Spider-Man",
}

# Titles for which TMDB has multiple exact-name shows.  The provider catalogue
# uses plain "Ben 10" for the 2005 original; the 2016 edition is identified by
# an explicit Reboot label when encountered.
_TV_ID_ALIASES = {
    "ben 10": 4686,
    "ben 10 reboot": 68295,
}


def _get(endpoint, params=None):
    if params is None:
        params = {}
    params = dict(params)
    params["api_key"] = TMDB_API_KEY
    params.setdefault("language", TMDB_LANGUAGE)
    url = "{}{}?{}".format(TMDB_BASE_URL, endpoint, urlencode(params))
    cached = diskcache.get("tmdb", url, 604800)
    if cached is not None:
        return cached
    try:
        req = Request(url, headers=_HEADERS)
        resp = urlopen(req, timeout=10)
        data = resp.read()
        result = json.loads(data.decode("utf-8"))
        if result:
            diskcache.set("tmdb", url, result)
        return result
    except (URLError, HTTPError) as e:
        xbmc.log("Cartoonio TMDB HTTP error for {}: {}".format(endpoint, type(e).__name__), xbmc.LOGWARNING)
    except Exception as e:
        xbmc.log("Cartoonio TMDB error for {}: {}".format(endpoint, type(e).__name__), xbmc.LOGERROR)
    return None


def image_url(path, size=POSTER_SIZE):
    if not path:
        return ""
    return "{}{}{}".format(TMDB_IMAGE_BASE, size, path)


def _name_similarity(a, b):
    """
    Very simple word-overlap ratio.  Returns a float 0-1.
    Used to guard against TMDB returning a totally unrelated show
    as the top hit (e.g. searching "Aquaman" returning "Batman: Brave and the Bold").
    """
    def words(s):
        return set(re.sub(r"[^a-z0-9 ]", "", s.lower()).split())
    wa, wb = words(a), words(b)
    if not wa or not wb:
        return 0.0
    # Remove noise stop-words that inflate false positives
    STOP = {"the", "a", "an", "and", "of", "in", "at", "to", "is", "part"}
    wa -= STOP
    wb -= STOP
    if not wa or not wb:
        return 0.0
    overlap = len(wa & wb)
    return overlap / max(len(wa), len(wb))


def search_tv(title, min_similarity=0.4):
    """
    Search TMDB for a TV show.  Only return a result if the best match's
    name is at least min_similarity similar to the query, preventing
    false positives like "Aquaman" → "Batman: The Brave and the Bold".
    """
    compact_title = re.sub(r"[^a-z0-9 ]", "", title.lower())
    compact_title = re.sub(r"\s+", " ", compact_title).strip()
    query = _TV_SEARCH_ALIASES.get(compact_title, title)
    data = _get("/search/tv", {"query": query})
    if not data or not data.get("results"):
        return None
    forced_id = _TV_ID_ALIASES.get(compact_title)
    if forced_id:
        for result in data["results"]:
            if result.get("id") == forced_id:
                return result
    comparison_title = query if query != title else title
    normalised_query = re.sub(r"[^a-z0-9]+", "", comparison_title.lower())
    candidates = data["results"][:10]

    # Exact title wins regardless of TMDB's popularity ordering.  This keeps
    # "Tom and Jerry" from incorrectly selecting "The Tom and Jerry Show".
    for result in candidates:
        result_name = result.get("name", "")
        if re.sub(r"[^a-z0-9]+", "", result_name.lower()) == normalised_query:
            return result

    scored = [
        (_name_similarity(comparison_title, result.get("name", "")), result)
        for result in candidates
    ]
    scored.sort(key=lambda value: value[0], reverse=True)
    return scored[0][1] if scored and scored[0][0] >= min_similarity else None


def search_movie(title, min_similarity=0.4):
    """Search TMDB for a movie with name-similarity guard."""
    data = _get("/search/movie", {"query": title})
    if not data or not data.get("results"):
        return None
    for result in data["results"][:5]:
        result_name = result.get("title", "")
        if _name_similarity(title, result_name) >= min_similarity:
            return result
    return None


def get_tv_details(tmdb_id):
    if not tmdb_id:
        return None
    key = (tmdb_id, TMDB_LANGUAGE)
    if key not in _TV_DETAILS_CACHE:
        data = _get(
            "/tv/{}".format(tmdb_id), {"append_to_response": "credits"}
        )
        if data is None:
            return None
        _TV_DETAILS_CACHE[key] = data
    return _TV_DETAILS_CACHE[key]


def get_movie_details(tmdb_id):
    return _get("/movie/{}".format(tmdb_id), {"append_to_response": "credits"})


def get_episode_details(tmdb_id, season_number, episode_number):
    return _get("/tv/{}/season/{}/episode/{}".format(tmdb_id, season_number, episode_number))


def get_tv_seasons(tmdb_id):
    """Return numbered, non-empty seasons from a TMDB TV show."""
    details = get_tv_details(tmdb_id)
    if not details:
        return []
    seasons = []
    for season in details.get("seasons", []):
        try:
            number = int(season.get("season_number"))
            count = int(season.get("episode_count") or 0)
        except (TypeError, ValueError):
            continue
        # Specials (season 0) are not part of the normal season folders.
        if number > 0 and count > 0:
            seasons.append({
                "season_number": number,
                "name": season.get("name") or "Season {}".format(number),
                "episode_count": count,
                "poster": image_url(season.get("poster_path"), POSTER_SIZE),
            })
    return sorted(seasons, key=lambda value: value["season_number"])


def get_tv_season_episodes(tmdb_id, season_number):
    """Return TMDB's episode catalogue for one season."""
    key = (tmdb_id, int(season_number), TMDB_LANGUAGE)
    if key not in _TV_SEASON_CACHE:
        data = _get("/tv/{}/season/{}".format(tmdb_id, season_number))
        if data is None:
            return []
        _TV_SEASON_CACHE[key] = (data or {}).get("episodes", [])
    return _TV_SEASON_CACHE[key]


def get_season_info(tmdb_id, season_number):
    """Return TMDB metadata and poster art for a season."""
    for season in get_tv_seasons(tmdb_id):
        if season["season_number"] == int(season_number):
            return season
    return {}


def get_cached_episode_info(tmdb_id, season_number, episode_number):
    """Return display-ready episode metadata from TMDB's cached season data."""
    if not tmdb_id or not season_number or not episode_number:
        return {}
    episodes = get_tv_season_episodes(tmdb_id, season_number)
    key = (tmdb_id, int(season_number), TMDB_LANGUAGE)
    cached = _TV_EPISODE_INDEX.get(key)
    if cached is None or cached[0] is not episodes:
        index = {}
        for episode in episodes:
            number = episode.get("episode_number")
            if isinstance(number, int):
                index.setdefault(number, episode)
        cached = (episodes, index)
        _TV_EPISODE_INDEX[key] = cached
    episode = cached[1].get(int(episode_number))
    if not episode:
        return {}
    runtime = episode.get("runtime") or 0
    return {
        "title": episode.get("name") or "",
        "plot": episode.get("overview") or "",
        "rating": episode.get("vote_average") or 0,
        "duration": int(runtime) * 60 if runtime else 0,
        "still": image_url(episode.get("still_path"), STILL_SIZE),
    }


def _normalise_episode_title(value):
    value = _html_unescape(value or "").lower()
    value = re.sub(r"[^a-z0-9]+", " ", value)
    return re.sub(r"\s+", " ", value).strip()


def _episode_title_keys(value):
    """Return comparable title forms, including TMDB story-arc suffixes."""
    raw = _html_unescape(value or "").lower()
    base = _normalise_episode_title(raw)
    if not base:
        return set()

    keys = {base}
    # TMDB often prefixes a title with an arc, for example:
    # "Neogenic Nightmare: The Mutant Agenda".
    for part in re.split(r"\s*:\s*", raw)[1:]:
        suffix = _normalise_episode_title(part)
        if suffix:
            keys.add(suffix)

    # MegaCartoons uses "Part 1" while TMDB commonly uses "(1)".
    simplified = re.sub(r"\b(?:part|pt|episode|ep)\s*\d+\b", " ", base)
    simplified = re.sub(r"\b\d+\b", " ", simplified)
    simplified = re.sub(r"\s+", " ", simplified).strip()
    if simplified:
        keys.add(simplified)

    # Apply the same qualifier cleanup to an arc suffix.
    for key in list(keys):
        suffix = re.sub(r"\b(?:part|pt|episode|ep)\s*\d+\b", " ", key)
        suffix = re.sub(r"\b\d+\b", " ", suffix)
        suffix = re.sub(r"\s+", " ", suffix).strip()
        if suffix:
            keys.add(suffix)
    return set(key for key in keys if len(key) >= 3)


def _episode_part_number(value):
    """Extract a multi-part marker such as Part 1 or (1), if present."""
    raw = _html_unescape(value or "")
    match = re.search(r"\b(?:part|pt|episode|ep)\s*0*(\d+)\b", raw, re.I)
    if not match:
        match = re.search(r"\(\s*0*(\d+)\s*\)\s*$", raw)
    return int(match.group(1)) if match else None


def _episode_catalogue(tmdb_id):
    """Reuse complete matching data across folder/season plugin invocations."""
    cache_key = "episode_catalogue:v1:{}:{}".format(tmdb_id, TMDB_LANGUAGE)
    cached = diskcache.get("tmdb", cache_key, 900)
    if isinstance(cached, list) and cached:
        return cached
    tmdb_seasons = get_tv_seasons(tmdb_id)
    actual_numbers = [season["season_number"] for season in tmdb_seasons]
    # Some classic catalogues use a decade/year as TMDB's season number
    # (Tom and Jerry: 1940, 1950, 1960).  Kodi should still present those as
    # Season 1, 2, 3 while retaining the actual TMDB number for API lookups.
    if actual_numbers and any(number >= 100 for number in actual_numbers):
        display_seasons = {
            number: index + 1 for index, number in enumerate(sorted(actual_numbers))
        }
    else:
        display_seasons = {number: number for number in actual_numbers}

    def load_season(season):
        episodes = get_tv_season_episodes(tmdb_id, season["season_number"])
        available = bool(episodes)
        # Provider episode titles are English even when descriptions are localized.
        if TMDB_LANGUAGE != "en-US":
            english = _get("/tv/{}/season/{}".format(tmdb_id, season["season_number"]), {"language": "en-US"})
            english_episodes = (english or {}).get("episodes")
            available = bool(english_episodes)
            episodes = english_episodes or episodes
        return episodes, available

    # Keep catalogue order deterministic for ambiguous title matching, while
    # bounding cold-cache season requests instead of waiting for each in turn.
    catalogue = []
    with ThreadPoolExecutor(max_workers=4) as executor:
        pending = [(season, executor.submit(load_season, season)) for season in tmdb_seasons]
        loaded = []
        for season, future in pending:
            try:
                loaded.append((season, future.result()))
            except Exception as exc:
                xbmc.log("Cartoonio TMDB season lookup failed: " + type(exc).__name__, xbmc.LOGWARNING)
    complete = bool(tmdb_seasons) and len(loaded) == len(tmdb_seasons)
    for season, (episodes, available) in loaded:
        complete = complete and available
        for episode in episodes:
            title = episode.get("name") or ""
            if title:
                catalogue.append({
                    "title": title,
                    "season": season["season_number"],
                    "display_season": display_seasons[season["season_number"]],
                    "episode": episode.get("episode_number"),
                })
    if complete and catalogue:
        diskcache.set("tmdb", cache_key, catalogue)
    return catalogue


def map_episode_seasons(tmdb_id, items):
    """Attach TMDB season/episode numbers to scraped episode items.

    MegaCartoons often omits season numbers from its URLs.  Match its episode
    titles against TMDB's per-season catalogue so the add-on can present the
    correct season folders.  Unmatched items are left untouched and the UI's
    existing fallback handles them safely.
    """
    if not tmdb_id or not items:
        return items

    catalogue = _episode_catalogue(tmdb_id)
    if not catalogue:
        return items

    by_title = {}
    for entry in catalogue:
        for key in _episode_title_keys(entry["title"]):
            by_title.setdefault(key, []).append(entry)

    mapped = []
    matched = 0
    for item in items:
        copy = dict(item)
        matches = []
        seen_matches = set()
        for key in _episode_title_keys(item.get("label")):
            for entry in by_title.get(key, []):
                identity = (entry["season"], entry["episode"])
                if identity not in seen_matches:
                    seen_matches.add(identity)
                    matches.append(entry)
        if len(matches) > 1:
            part_number = _episode_part_number(item.get("label"))
            if part_number is not None:
                numbered = [
                    entry for entry in matches
                    if _episode_part_number(entry.get("title")) == part_number
                ]
                if len(numbered) == 1:
                    matches = numbered
        if len(matches) == 1:
            copy.update({
                "season": matches[0]["display_season"],
                "tmdb_season": matches[0]["season"],
                "episode": matches[0]["episode"],
            })
            matched += 1
        mapped.append(copy)

    xbmc.log(
        "Cartoonio TMDB season mapping: {}/{} episodes matched for TV {}".format(
            matched, len(items), tmdb_id
        ),
        xbmc.LOGDEBUG,
    )
    return mapped


def build_tv_info(title):
    clean = re.sub(r'\s*(season|episode|ep|s\d+e\d+)\s*\d*', '', title, flags=re.I).strip()
    clean = re.sub(r'\s+', ' ', clean).strip()
    if not clean:
        return None

    result = search_tv(clean)
    if not result:
        return None

    tmdb_id = result.get("id")
    details = get_tv_details(tmdb_id) if tmdb_id else {}

    genres, cast = [], []
    if details:
        genres = [g["name"] for g in details.get("genres", [])]
        credits = details.get("credits", {})
        cast = [c["name"] for c in credits.get("cast", [])[:10]]

    return {
        "tmdb_id":  tmdb_id,
        "type":     "tv",
        "title":    result.get("name", title),
        "plot":     result.get("overview", ""),
        "year":     (result.get("first_air_date") or "")[:4],
        "poster":   image_url(result.get("poster_path"), POSTER_SIZE),
        "fanart":   image_url(result.get("backdrop_path"), FANART_SIZE),
        "backdrop": image_url(result.get("backdrop_path"), BACKDROP_SIZE),
        "rating":   result.get("vote_average", 0),
        "genres":   genres,
        "cast":     cast,
    }


def build_movie_info(title):
    clean = re.sub(r'\s*(season|episode|ep)\s*\d*', '', title, flags=re.I).strip()
    if not clean:
        return None

    result = search_movie(clean)
    if not result:
        return None

    tmdb_id = result.get("id")
    details = get_movie_details(tmdb_id) if tmdb_id else {}

    genres, cast = [], []
    if details:
        genres = [g["name"] for g in details.get("genres", [])]
        credits = details.get("credits", {})
        cast = [c["name"] for c in credits.get("cast", [])[:10]]

    return {
        "tmdb_id": tmdb_id,
        "type":    "movie",
        "title":   result.get("title", title),
        "plot":    result.get("overview", ""),
        "year":    (result.get("release_date") or "")[:4],
        "poster":  image_url(result.get("poster_path"), POSTER_SIZE),
        "fanart":  image_url(result.get("backdrop_path"), FANART_SIZE),
        "rating":  result.get("vote_average", 0),
        "genres":  genres,
        "cast":    cast,
    }


def get_episode_still(tmdb_id, season, episode):
    """Return episode screenshot URL from TMDB, or empty string."""
    if not tmdb_id or not season or not episode:
        return ""
    data = get_episode_details(tmdb_id, season, episode)
    if not data:
        return ""
    return image_url(data.get("still_path"), STILL_SIZE)
