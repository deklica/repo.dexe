"""Bind isolated handlers to the current Kodi plugin invocation."""

from functools import partial

import catalogue_views
import playback
import routing


def bind_handlers(app):
    """Share runtime settings and UI helpers without copying mutable state."""
    for module in (catalogue_views, playback, routing):
        for name in module.__all__:
            setattr(app, name, partial(getattr(module, name), app))
