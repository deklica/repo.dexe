"""Read explicit forward navigation without mistaking previous links for next."""

from html.parser import HTMLParser
from urllib.parse import urljoin


class _NextPageParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.next_url = None
        self.anchor = None
        self.text = []

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        href = attrs.get("href", "")
        if tag not in ("a", "link") or not href:
            return
        rel = attrs.get("rel", "").lower().split()
        classes = attrs.get("class", "").lower().split()
        if "next" in rel or "next" in classes:
            self.next_url = self.next_url or href
        if tag == "a":
            self.anchor = href
            self.text = []

    def handle_data(self, data):
        if self.anchor:
            self.text.append(data)

    def handle_endtag(self, tag):
        if tag == "a" and self.anchor:
            text = " ".join("".join(self.text).lower().split()).strip(" »›→")
            if text in ("next", "next page", "older", "older posts"):
                self.next_url = self.next_url or self.anchor
            self.anchor = None


def next_page_url(html, page_url):
    parser = _NextPageParser()
    parser.feed(html)
    href = parser.next_url
    if not href or href.startswith(("#", "javascript:")):
        return None
    url = urljoin(page_url, href)
    return url if url.startswith(("https://", "http://")) and url != page_url else None
