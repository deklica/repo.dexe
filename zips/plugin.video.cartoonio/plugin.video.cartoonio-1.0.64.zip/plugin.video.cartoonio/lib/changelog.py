"""Themed release notes dialog, with a standard Kodi viewer fallback."""

import re

import xbmc
import xbmcgui
import theme


def release_colour(index):
    """Use Cartoonio's soft gold consistently across the release list."""
    return theme.ACCENT


def format_news(news):
    """Separate release headings from their descriptions for TV readability."""
    text = re.sub(r"\n[ \t]+", "\n", news.strip())
    return re.sub(
        r"(?m)^v(\d+(?:\.\d+)+)\s*-\s*",
        lambda match: "[COLOR FFE8B96A][B]VERSION {}[/B][/COLOR]\n".format(match.group(1)),
        text,
    )


def parse_releases(news):
    """Keep each version's notes together, newest first as authored."""
    text = re.sub(r"\n[ \t]+", "\n", news.strip())
    matches = list(re.finditer(r"(?m)^v(\d+(?:\.\d+)+)\s*-\s*", text))
    if not matches:
        return [("", text or "No release notes available.")]
    return [(match.group(1), text[match.end():matches[i + 1].start()
             if i + 1 < len(matches) else len(text)].strip())
            for i, match in enumerate(matches)]


def format_release(notes):
    """Give section headings breathing room without enlarging every line."""
    lines = notes.splitlines()
    formatted = []
    for i, line in enumerate(lines):
        line = line.strip()
        if line and not line.startswith("-") and i + 1 < len(lines) and lines[i + 1].strip().startswith("-"):
            formatted.append("[COLOR FFE8B96A][B]{}[/B][/COLOR]".format(line))
        elif i == 0:
            formatted.append("[B]{}[/B]".format(line))
        else:
            formatted.append("• " + line[1:].strip() if line.startswith("-") else line)
    return "\n".join(formatted)


class ChangelogDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.news = ""
        self.version = ""
        self.icon = ""
        self.ready = False
        self.releases = []
        self.selected_release = None

    def onInit(self):
        try:
            self.setProperty("Cartoonio.Icon", self.icon)
            self.setProperty("Cartoonio.Version", "Installed version  " + self.version)
            self.releases = parse_releases(self.news)
            control = self.getControl(100)
            control.reset()
            control.addItems([xbmcgui.ListItem(
                label="[COLOR {}]{}[/COLOR]".format(release_colour(i), version or "Notes"),
                label2="CURRENT" if version == self.version else "LATEST" if i == 0 else "")
                for i, (version, notes) in enumerate(self.releases)])
            self.setProperty("Cartoonio.ReleaseTotal", "{} releases".format(len(self.releases)))
            control.selectItem(0)
            self._show_release(0)
            self.setFocusId(100)
            self.ready = True
        except Exception as exc:
            xbmc.log("Cartoonio changelog initialization failed: " + type(exc).__name__, xbmc.LOGWARNING)
            self.close()

    def onClick(self, control_id):
        if control_id == 200:
            self.close()
        elif control_id == 100:
            self._show_release(self.getControl(100).getSelectedPosition())
            self.setFocusId(101)

    def onFocus(self, control_id):
        if self.ready and control_id == 101:
            self._show_release(self.getControl(100).getSelectedPosition())

    def _show_release(self, index):
        if not 0 <= index < len(self.releases) or index == self.selected_release:
            return
        version, notes = self.releases[index]
        self.setProperty("Cartoonio.ReleaseVersion", "Version " + version if version else "Release notes")
        changes = sum(line.strip().startswith("-") for line in notes.splitlines()) or 1
        status = "CURRENT RELEASE" if version == self.version else "LATEST RELEASE" if index == 0 else "FROM THE ARCHIVE"
        self.setProperty("Cartoonio.ReleaseStatus", "{}  ·  {} change{}".format(status, changes, "" if changes == 1 else "s"))
        self.setProperty("Cartoonio.ReleasePosition", "{:02d} / {:02d}".format(index + 1, len(self.releases)))
        lines = notes.splitlines()
        if len(lines) > 1 and len(lines[0]) <= 90:
            title, body = lines[0], "\n".join(lines[1:]).strip()
        else:
            title, body = "Release notes", notes
        self.setProperty("Cartoonio.ReleaseTitle", title)
        self.getControl(110).reset()
        self.getControl(110).setText(format_release(body))
        self.selected_release = index

    def onAction(self, action):
        if action.getId() in (9, 10, 92):
            if self.getFocusId() == 101:
                self.setFocusId(100)
            else:
                self.close()
        elif self.getFocusId() == 100:
            self._show_release(self.getControl(100).getSelectedPosition())


def show(addon_path, news, version, icon):
    dialog = None
    try:
        dialog = ChangelogDialog("CartoonioChangelog.xml", addon_path, "Default", "1080i")
        dialog.news, dialog.version, dialog.icon = news, version, icon
        dialog.doModal()
        if dialog.ready:
            return
    except Exception as exc:
        xbmc.log("Cartoonio changelog dialog failed: " + type(exc).__name__, xbmc.LOGWARNING)
    finally:
        if dialog is not None:
            try:
                dialog.close()
            except Exception:
                pass
    xbmcgui.Dialog().textviewer("Cartoonio Change Log", news)
