"""Schema-driven Cartoonio settings with staged Apply/Cancel changes."""

import os
import xml.etree.ElementTree as ET

import xbmc
import xbmcgui


def read_schema(path, addon):
    def label(value):
        return addon.getLocalizedString(int(value)) if value and value.isdigit() else value or ""
    categories = []
    for category in ET.parse(path).findall(".//category"):
        entries = []
        for setting in category.findall(".//setting"):
            if int(setting.findtext("level", "0")) > 3:
                continue
            entries.append({"id": setting.get("id"), "label": label(setting.get("label")),
                            "help": label(setting.get("help")), "type": setting.get("type"),
                            "default": setting.findtext("default") or "",
                            "options": [(option.text or "", label(option.get("label")))
                                        for option in setting.findall(".//options/option")],
                            "dependencies": [(d.get("setting"), d.text or "")
                                             for d in setting.findall(".//dependency")],
                            "hidden": setting.findtext("control/hidden") == "true"})
        categories.append({"label": label(category.get("label")), "help": label(category.get("help")), "entries": entries})
    return categories


class SettingsDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.categories = []
        self.values = {}
        self.original = {}
        self.category_index = 0
        self.choice = None
        self.ready = False
        self.saved = False
        self.help_key = None
        self.row_positions = {}

    def configure(self, addon, path):
        self.addon = addon
        self.categories = read_schema(os.path.join(path, "resources", "settings.xml"), addon)
        for category in self.categories:
            for entry in category["entries"]:
                value = addon.getSetting(entry["id"])
                if not value:
                    value = entry["default"]
                if entry["type"] == "boolean":
                    value = value.strip().lower()
                    if value not in ("true", "false"):
                        value = entry["default"]
                if entry["options"] and value not in [v for v, _ in entry["options"]]:
                    value = entry["default"]
                self.values[entry["id"]] = value
        self.original = dict(self.values)

    def onInit(self):
        try:
            self.setProperty("Cartoonio.Icon", self.addon.getAddonInfo("icon"))
            self.getControl(100).addItems([xbmcgui.ListItem(label=c["label"]) for c in self.categories])
            self._show_category(0)
            self.setFocusId(100)
            self.ready = True
        except Exception as exc:
            xbmc.log("Cartoonio settings initialization failed: " + type(exc).__name__, xbmc.LOGWARNING)
            self.close()

    def _enabled(self, entry):
        return all(self.values.get(key) == value for key, value in entry["dependencies"])

    def _value_label(self, entry):
        if not self._enabled(entry):
            return "Requires TMDB"
        value = self.values[entry["id"]]
        if entry["hidden"]:
            return "Personal key set" if value else "Bundled key"
        if entry["type"] == "boolean":
            return "Enabled" if value == "true" else "Disabled"
        return dict(entry["options"]).get(value, value)

    def _setting_item(self, entry):
        item = xbmcgui.ListItem(label=entry["label"], label2=self._value_label(entry))
        enabled = self._enabled(entry)
        item.setProperty("Cartoonio.Kind", "toggle" if entry["type"] == "boolean" and enabled else "value")
        item.setProperty("Cartoonio.State", self.values[entry["id"]] if entry["type"] == "boolean" else "")
        item.setProperty("Cartoonio.Changed", "true" if self.values[entry["id"]] != self.original[entry["id"]] else "false")
        item.setProperty("Cartoonio.Enabled", "true" if enabled else "false")
        return item

    def _show_category(self, index, selected=None):
        if self.ready and not self.choice:
            previous = self.getControl(110).getSelectedPosition()
            if isinstance(previous, int) and previous >= 0:
                self.row_positions[self.category_index] = previous
        self.category_index = index
        self.choice = None
        category = self.categories[index]
        self.setProperty("Cartoonio.SettingsHeading", category["label"])
        self.setProperty("Cartoonio.SettingsCategory", str(index))
        for category_index in range(len(self.categories)):
            self.getControl(100).getListItem(category_index).setProperty(
                "Cartoonio.Active", "true" if category_index == index else "false")
        control = self.getControl(110)
        control.reset()
        control.addItems([self._setting_item(e) for e in category["entries"]])
        selected = self.row_positions.get(index, 0) if selected is None else selected
        selected = max(0, min(selected, len(category["entries"]) - 1))
        control.selectItem(selected)
        self.help_key = None
        self._update_help()

    def _update_help(self):
        if self.choice:
            text = "Choose a value. Back returns without changing it."
        elif self.getFocusId() == 110:
            entries = self.categories[self.category_index]["entries"]
            index = self.getControl(110).getSelectedPosition()
            text = entries[index]["help"] if 0 <= index < len(entries) else ""
        else:
            text = self.categories[self.category_index]["help"]
        if text != self.help_key:
            self.getControl(120).setText(text)
            self.help_key = text
        changed = sum(value != self.original[key] for key, value in self.values.items())
        self.setProperty("Cartoonio.SettingsStatus", "{} pending change{}".format(changed, "" if changed == 1 else "s") if changed else "No pending changes")
        self.getControl(200).setEnabled(bool(changed))
        self.setProperty("Cartoonio.SettingsChanged", "true" if changed else "false")
        if not changed and self.getFocusId() == 200:
            self.setFocusId(201)
        entries = self.categories[self.category_index]["entries"]
        providers = [e for e in entries if e["id"].startswith("enable_") and not e["id"].startswith("enable_tmdb")]
        summary = "{} settings".format(len(entries))
        if providers:
            active = sum(self.values[e["id"]] == "true" for e in providers)
            summary = "{} of {} providers enabled".format(active, len(providers)) if active else "No providers enabled"
        self.setProperty("Cartoonio.SettingsSummary", summary)

    def _cancel_choice(self):
        if self.choice:
            index = self.choice[0]
            self._show_category(self.category_index, index)
            self.setFocusId(110)
            return True
        return False

    def _save_changes(self):
        """Detect failed writes and undo attempted changes before reporting failure."""
        attempted = []
        try:
            for key, value in self.values.items():
                if value != self.original[key]:
                    attempted.append(key)
                    if self.addon.setSetting(key, value) is False:
                        raise RuntimeError("Setting write rejected")
        except Exception:
            restored = True
            for key in reversed(attempted):
                try:
                    if self.addon.setSetting(key, self.original[key]) is False:
                        restored = False
                except Exception:
                    restored = False
            if not restored:
                xbmc.log("Cartoonio could not restore all settings after a save failure", xbmc.LOGWARNING)
            return False, restored
        return True, True

    def onClick(self, control_id):
        if control_id == 100:
            self._show_category(self.getControl(100).getSelectedPosition())
            self.setFocusId(110)
        elif control_id == 201:
            self.close()
        elif control_id == 202:
            for entry in self.categories[self.category_index]["entries"]:
                self.values[entry["id"]] = entry["default"]
            self._show_category(self.category_index)
        elif control_id == 200:
            success, restored = self._save_changes()
            if success:
                self.saved = True
                self.close()
            else:
                message = ("Settings could not be saved. Previous values were restored. Try Apply again."
                           if restored else "Some settings could not be saved or restored. Check your settings before trying again.")
                xbmcgui.Dialog().ok("Cartoonio", message)
        elif control_id == 110:
            index = self.getControl(110).getSelectedPosition()
            if self.choice:
                entry_index, entry = self.choice
                if 0 <= index < len(entry["options"]):
                    self.values[entry["id"]] = entry["options"][index][0]
                    self._show_category(self.category_index, entry_index)
                return
            entries = self.categories[self.category_index]["entries"]
            if not 0 <= index < len(entries):
                return
            entry = entries[index]
            if not self._enabled(entry):
                return
            if entry["type"] == "boolean":
                self.values[entry["id"]] = "false" if self.values[entry["id"]] == "true" else "true"
                self._show_category(self.category_index, index)
            elif entry["options"]:
                self.choice = (index, entry)
                self.setProperty("Cartoonio.SettingsHeading", entry["label"])
                control = self.getControl(110)
                control.reset()
                control.addItems([xbmcgui.ListItem(label=label, label2="Selected" if value == self.values[entry["id"]] else "") for value, label in entry["options"]])
                control.selectItem([v for v, _ in entry["options"]].index(self.values[entry["id"]]))
                self._update_help()
            else:
                keyboard = xbmc.Keyboard(self.values[entry["id"]], entry["label"], entry["hidden"])
                keyboard.doModal()
                if keyboard.isConfirmed():
                    self.values[entry["id"]] = keyboard.getText().strip()
                    self._show_category(self.category_index, index)
        self._update_help()

    def onFocus(self, control_id):
        if self.ready:
            if control_id == 100 and self.choice:
                entry_index = self.choice[0]
                self._show_category(self.category_index, entry_index)
            if control_id == 110 and not self.choice:
                index = self.getControl(100).getSelectedPosition()
                if isinstance(index, int) and 0 <= index < len(self.categories) and index != self.category_index:
                    self._show_category(index)
            self._update_help()

    def onAction(self, action):
        if action.getId() in (9, 10, 92):
            if not self._cancel_choice():
                if self.getFocusId() == 110:
                    self.setFocusId(100)
                elif self.getFocusId() in (200, 201, 202):
                    self.setFocusId(110)
                else:
                    self.close()
        else:
            if self.getFocusId() == 100:
                index = self.getControl(100).getSelectedPosition()
                if isinstance(index, int) and 0 <= index < len(self.categories) and index != self.category_index:
                    self._show_category(index)
            self._update_help()


def show(addon, path):
    dialog = None
    try:
        dialog = SettingsDialog("CartoonioSettings.xml", path, "Default", "1080i")
        dialog.configure(addon, path)
        dialog.doModal()
        if dialog.ready:
            return dialog.saved
    except Exception as exc:
        xbmc.log("Cartoonio settings dialog failed: " + type(exc).__name__, xbmc.LOGWARNING)
    finally:
        if dialog is not None:
            dialog.close()
    addon.openSettings()
    return True
