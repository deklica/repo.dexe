"""Tools actions for Cartoonio's own caches and connected providers."""

import time
from concurrent.futures import ThreadPoolExecutor
from urllib.request import Request, urlopen

import xbmc
import xbmcgui

import diskcache
import tmdb
import providers

PROVIDER_CACHES = ("cartoonio_catalogue",) + tuple(p.cache_namespace for p in providers.REGISTRY)


def clear_cache(scope):
    if scope not in ("all", "providers", "metadata"):
        raise ValueError("Unknown cache scope")
    if scope == "all":
        report = diskcache.clear(detailed=True)
    else:
        report = {"success": True, "removed": 0, "failed": 0}
        namespaces = PROVIDER_CACHES if scope == "providers" else ("tmdb",)
        for namespace in namespaces:
            part = diskcache.clear(namespace, detailed=True)
            report["success"] = report["success"] and part["success"]
            report["removed"] += part["removed"]
            report["failed"] += part["failed"]
    if scope in ("all", "metadata"):
        tmdb.clear_memory_cache()
        # Merged search results can depend on TMDB canonical names.
        if scope == "metadata":
            part = diskcache.clear("cartoonio_catalogue", detailed=True)
            report["success"] = report["success"] and part["success"]
            report["removed"] += part["removed"]
            report["failed"] += part["failed"]
    return report


def _size(value):
    return "{:.1f} MB".format(value / 1048576) if value >= 1048576 else "{:.1f} KB".format(value / 1024)


def show_cache_info():
    info = diskcache.cache_info()
    lines = ["{} cached files · {}".format(info["files"], _size(info["bytes"])), ""]
    labels = {p.cache_namespace: p.label for p in providers.REGISTRY}
    labels.update({"cartoonio_catalogue": "Merged listings", "tmdb": "TMDB metadata"})
    for name, data in sorted(info["namespaces"].items()):
        lines.append("{}: {} files · {}".format(labels.get(name, name), data["files"], _size(data["bytes"])))
    lines.extend(["", "Settings and Kodi's shared artwork cache are not included."])
    if info["failed"]:
        lines.append("Some cache information could not be read; totals may be incomplete.")
    xbmcgui.Dialog().textviewer("Cartoonio · Cache Information", "\n".join(lines))


def _probe(module):
    started = time.monotonic()
    try:
        request = Request(module.BASE_URL + "/", headers=module.HEADERS)
        with urlopen(request, timeout=10) as response:
            response.read(1024)
        return "Responding · {:.1f}s".format(time.monotonic() - started)
    except Exception as exc:
        xbmc.log("Cartoonio provider connection check failed: " + type(exc).__name__, xbmc.LOGWARNING)
        return "Unavailable ({})".format(type(exc).__name__)


def check_providers(jobs):
    if not jobs:
        xbmcgui.Dialog().ok("Cartoonio", "All providers are disabled. Enable a provider in Settings.")
        return
    progress = None
    try:
        progress = xbmcgui.DialogProgressBG()
        progress.create("Cartoonio", "Checking enabled provider websites…")
    except Exception:
        progress = None
    try:
        with ThreadPoolExecutor(max_workers=5) as executor:
            pending = [(label, executor.submit(_probe, module)) for name, label, module, loader in jobs]
            lines = ["{}: {}".format(label, future.result()) for label, future in pending]
    finally:
        if progress is not None:
            try:
                progress.close()
            except Exception:
                pass
    lines.extend(["", "Website connections only. This does not verify episode streams.", "Disabled providers were skipped."])
    xbmcgui.Dialog().textviewer("Cartoonio · Provider Connections", "\n".join(lines))
