"""Catalogue browsing and search handlers.

Handlers receive the running addon context explicitly.
"""

from urllib.parse import urlencode
import listingoptions

__all__ = ['_search_presentation', '_get_provider_episodes', '_listing_presentation', '_render_item_list', '_render_search_results', '_search_all_providers', 'do_search', 'show_cartoons', 'show_categories', 'show_latest', 'show_season_episodes', 'show_series_list', 'show_series_seasons']


def show_series_list(app, page=1):
    """Show one unified series catalogue from every working provider."""
    app.set_content("tvshows")
    cache_key = app._catalogue_key("series")
    cached_series = app.diskcache.get("cartoonio_catalogue", cache_key, app.LIST_CACHE_TTL)
    if cached_series is not None:
        series = cached_series
    else:
        series = []
        by_title = {}

        catalogue_jobs = [(name, loader) for name, label, module, loader
                          in app._provider_jobs("get_series_list")]
        with app.ThreadPoolExecutor(max_workers=6) as executor:
            pending = [(name, executor.submit(loader)) for name, loader in catalogue_jobs if app._provider_enabled(name)]
            provider_catalogues = []
            for name, future in pending:
                try:
                    provider_catalogues.append((name, future.result()))
                except Exception as exc:
                    app.xbmc.log("Cartoonio {} catalogue failed: {}".format(name, exc), app.xbmc.LOGWARNING)
        for provider_name, catalogue in provider_catalogues:
            for show in catalogue:
                key = app._normalise_source_title(show.get("label"))
                if not key or key == "home":
                    continue
                if key not in by_title:
                    entry = dict(show)
                    by_title[key] = entry
                    series.append(entry)
                else:
                    entry = by_title[key]
                    if not entry.get("thumb"):
                        entry["thumb"] = show.get("thumb", "")
                entry[provider_name + "_url"] = show["url"]
        app.diskcache.set("cartoonio_catalogue", cache_key, series)

    series = listingoptions.sort_items(app.ADDON, series)

    if not series:
        app.xbmcgui.Dialog().ok(app.ADDON_NAME, "No series found from the enabled providers. Check provider settings or connections; B98.TV supplies episode listings only.")
        app.end_of_directory(False)
        return

    per_page = app._items_per_page()
    total_pages = max(1, (len(series) + per_page - 1) // per_page)
    page = max(1, min(int(page), total_pages))
    page_series = series[(page - 1) * per_page:page * per_page]
    with app.ThreadPoolExecutor(max_workers=6) as executor:
        enriched = list(executor.map(app._enrich_item_with_tmdb, page_series))
    for s, (info, art) in zip(page_series, enriched):
        provider = next(
            name for name, label in app.preferences.PROVIDERS
            if s.get(name + "_url")
        )
        url = app.build_url(
            mode="series_seasons",
            url=s[provider + "_url"],
            provider=provider,
            **app.providers.url_parameters({name: s.get(name + "_url", "") for name, label in app.preferences.PROVIDERS}),
        )
        app.add_directory_item(s["label"], url, is_folder=True, info=info, art=art)
    if page > 1:
        app.add_directory_item("[COLOR gold]<< Previous Page (Page {}) • {} shows[/COLOR]".format(page - 1, len(page_series)), app.build_url(mode="series_list", page=page - 1), True)
    if page < total_pages:
        app.add_directory_item("[COLOR gold]>> Next Page (Page {}) • {} shows[/COLOR]".format(page + 1, len(page_series)), app.build_url(mode="series_list", page=page + 1), True)
    app.end_of_directory()


def show_cartoons(app, url, page=1, offset=0):
    app.set_content("tvshows")
    cache_key = app._catalogue_key("cartoons:{}:{}".format(url or "", page))
    result = app.diskcache.get("cartoonio_catalogue", cache_key, app.LIST_CACHE_TTL)
    if result is None:
        jobs = []
        alternate = False
        for name, label, module, loader in app._provider_jobs("get_cartoons_page"):
            if name != "megacartoons" and module.BASE_URL.split("://", 1)[-1].replace("www.", "", 1) in (url or "").lower():
                jobs = [(name, lambda loader=loader: loader(page=page, url=url))]
                alternate = True
                break
        if not alternate:
            # A provider-specific link must never become another site's catalogue.
            is_mega = "megacartoons.net" in (url or "").lower()
            if is_mega and app._provider_enabled("megacartoons"):
                jobs.append(("megacartoons", lambda: app.scraper.get_cartoons_page(url, page=page)))
            if is_mega and "/category/cartoons/" in (url or ""):
                jobs.extend((name, lambda loader=loader: loader(page=page))
                            for name, label, module, loader in app._provider_jobs("get_cartoons_page")
                            if name != "megacartoons")
        result = app._load_catalogue(jobs)
        app.diskcache.set("cartoonio_catalogue", cache_key, result)
    app._render_item_list(result, url, "cartoons", page, offset=offset)


def show_latest(app, url, page=1, offset=0):
    app.set_content("tvshows")
    cache_key = app._catalogue_key("latest:{}:{}".format(url or "", page))
    result = app.diskcache.get("cartoonio_catalogue", cache_key, app.LIST_CACHE_TTL)
    if result is None:
        jobs = []
        for name, label, module, loader in app._provider_jobs("get_latest"):
            if name == "megacartoons":
                jobs.append((name, lambda loader=loader: loader(url, page=page)))
            else:
                jobs.append((name, lambda loader=loader: loader(page=page)))
        result = app._load_catalogue(jobs)
        app.diskcache.set("cartoonio_catalogue", cache_key, result)
    result["items"] = sorted(result.get("items", []),
                             key=lambda item: item.get("published", ""), reverse=True)
    app._render_item_list(result, url, "latest", page, offset=offset)


def _get_provider_episodes(app, url, page, provider, provider_urls=None):
    """Fetch and de-duplicate episode cards from every URL for a show."""
    provider_urls = dict(provider_urls or {})
    if not provider_urls.get(provider):
        provider_urls[provider] = url
    cache_key = app._catalogue_key("episodes:" + urlencode(sorted(provider_urls.items())))
    cached = app.diskcache.get("cartoonio_catalogue", cache_key, app.LIST_CACHE_TTL)
    if cached is not None:
        return cached
    jobs = [(getattr(p.module, p.episodes), provider_urls[p.name])
            for p in app.providers.REGISTRY
            if app._provider_enabled(p.name) and provider_urls.get(p.name)]
    with app.ThreadPoolExecutor(max_workers=6) as executor:
        pending = [executor.submit(loader, provider_url) for loader, provider_url in jobs]
        results = []
        for future in pending:
            try:
                results.append(future.result())
            except Exception as exc:
                app.xbmc.log("Cartoonio episode catalogue failed: {}".format(exc), app.xbmc.LOGWARNING)
    items = []
    seen = set()
    for result in results:
        for item in result.get("items", []):
            key = app._normalise_source_title(item.get("label"))
            if not key or key in seen:
                continue
            seen.add(key)
            items.append(item)
    result = {"items": items, "next_page_url": None}
    # Do not keep a transient all-provider outage as an empty catalogue.
    if items:
        app.diskcache.set("cartoonio_catalogue", cache_key, result)
    return result


def show_series_seasons(app, url, page=1, provider="megacartoons", provider_urls=None):
    """Show a series' season folders before exposing its episodes."""
    app.set_content("seasons")
    result = app._get_provider_episodes(url, page, provider, provider_urls)
    items   = result.get("items", [])
    next_url = result.get("next_page_url")

    # Provider navigation links can leak into episode catalogues. Never allow
    # the site's Home link to become a show/season entry.
    items = [item for item in items if not app._is_navigation_home(item)]

    if not items:
        app.xbmcgui.Dialog().notification(
            app.ADDON_NAME, "No episodes found.", app.xbmcgui.NOTIFICATION_WARNING, 3000
        )
        app.end_of_directory()
        return

    series_name, series_fanart, series_poster, series_info = app._get_series_presentation(url)
    items = app._map_episodes_to_tmdb(items, series_info)
    seasons = {}
    for item in items:
        season = app._episode_season(item)
        seasons.setdefault(season, []).append(item)

    for season in sorted(seasons):
        info = dict(series_info)
        info.update({"season": season, "tvshowtitle": series_name})
        season_meta = {}
        tmdb_season = seasons[season][0].get("tmdb_season", season)
        if app.ENABLE_TMDB and series_info.get("tmdb_id"):
            season_meta = app.tmdb.get_season_info(series_info["tmdb_id"], tmdb_season)
        season_poster = season_meta.get("poster") or series_poster
        app.add_directory_item(
            "Season {}".format(season),
            app.build_url(
                mode="season_episodes",
                url=url,
                season=season,
                page=page,
                provider=provider,
                **app.providers.url_parameters(provider_urls or {}),
            ),
            is_folder=True,
            info=info,
            art={
                "thumb": season_poster,
                "poster": season_poster,
                "icon": season_poster,
                "fanart": series_fanart,
            },
        )

    if next_url:
        app.add_next_page_item(next_url, "series_seasons", {"provider": "megacartoons"})

    app.end_of_directory()


def show_season_episodes(app, url, season=1, page=1, provider="megacartoons", provider_urls=None):
    """Show the episodes belonging to one season folder."""
    app.set_content("episodes")
    result = app._get_provider_episodes(url, page, provider, provider_urls)
    raw_items = result.get("items", [])
    next_url = result.get("next_page_url")

    series_name, series_fanart, series_poster, series_info = app._get_series_presentation(url)
    raw_items = app._map_episodes_to_tmdb(raw_items, series_info)
    items = [item for item in raw_items
             if not app._is_navigation_home(item) and app._episode_season(item) == int(season)]

    if not items:
        app.xbmcgui.Dialog().notification(
            app.ADDON_NAME, "No episodes found for Season {}.".format(season),
            app.xbmcgui.NOTIFICATION_WARNING, 3000
        )
        app.end_of_directory()
        return

    per_page = app._items_per_page()
    total_pages = max(1, (len(items) + per_page - 1) // per_page)
    page = max(1, min(int(page), total_pages))
    page_items = items[(page - 1) * per_page:page * per_page]
    for item in page_items:
        episode_num = item.get("episode", 0)
        tmdb_season = item.get("tmdb_season", int(season))
        episode_meta = {}
        if app.ENABLE_TMDB and series_info.get("tmdb_id") and episode_num:
            episode_meta = app.tmdb.get_cached_episode_info(
                series_info["tmdb_id"], tmdb_season, episode_num
            )
        ep_thumb = ((episode_meta.get("still") if app.ENABLE_SCREENSHOTS else "")
                    or item.get("thumb") or series_poster)
        art = {
            "thumb": ep_thumb,
            "poster": ep_thumb,
            "icon": ep_thumb,
            "fanart": series_fanart,
        }
        info = dict(series_info)
        info.update({
            "season": int(season),
            "episode": episode_num,
            "tvshowtitle": series_name,
        })
        for key in ("plot", "rating", "duration"):
            if episode_meta.get(key):
                info[key] = episode_meta[key]
        title = episode_meta.get("title") or item["label"]
        info = listingoptions.episode_info(app.ADDON, info)
        info["title"] = title
        app.add_directory_item(
            listingoptions.episode_label(app.ADDON, item, title),
            app.build_url(
                mode="episode",
                url=item["url"],
                season=int(season),
                episode=episode_num,
                tmdb_season=tmdb_season,
                series_title=series_name,
                episode_title=item["label"],
                provider=provider,
            ),
            is_folder=False,
            info=info,
            art=art,
        )

    navigation = dict(mode="season_episodes", url=url, season=season, provider=provider)
    navigation.update({name + "_url": value for name, value in (provider_urls or {}).items()})
    if page > 1:
        app.add_directory_item("[COLOR gold]<< Previous Episodes[/COLOR]", app.build_url(page=page - 1, **navigation), True)
    if page < total_pages:
        app.add_directory_item("[COLOR gold]>> Next Episodes (Page {})[/COLOR]".format(page + 1),
                           app.build_url(page=page + 1, **navigation), True)

    app.end_of_directory()


def _listing_presentation(app, item, mode):
    """Prepare metadata off the UI thread; Kodi directory calls stay ordered."""
    if item.get("is_folder"):
        try:
            return app._enrich_item_with_tmdb(item)
        except Exception as exc:
            app.xbmc.log("Cartoonio folder metadata failed: {}".format(type(exc).__name__), app.xbmc.LOGWARNING)
            return {}, {"thumb": item.get("thumb") or app.ADDON_ICON, "fanart": app.ADDON_FANART}
    # A-Z contains episode entries. Fetch the episode page metadata so
    # Kodi's information panel can show the episode description.
    info = {}
    if mode in ("cartoons", "latest") and listingoptions.descriptions(app.ADDON):
        try:
            item_url = item.get("url", "")
            episode_info = (
                app.funniermoments.get_episode_info(item_url)
                if "funniermoments.net" in item_url.lower() else
                app.b98.get_episode_info(item_url)
                if "b98.tv" in item_url.lower()
                else app.scraper.get_episode_info(item_url)
            )
            info = {
                "plot": episode_info.get("plot", ""),
                "year": episode_info.get("year", ""),
                "rating": episode_info.get("rating", 0),
                "thumb": episode_info.get("thumb", ""),
            }
        except Exception as exc:
            app.xbmc.log("Cartoonio episode metadata failed: {}".format(exc), app.xbmc.LOGWARNING)
    tmdb_art = {}
    if app.ENABLE_TMDB and not (item.get("thumb") or info.get("thumb")):
        try:
            tmdb_art = app.tmdb.build_movie_info(item.get("label", "")) or {}
            if not tmdb_art:
                tmdb_art = app.tmdb.build_tv_info(item.get("label", "")) or {}
        except Exception as exc:
            app.xbmc.log("Cartoonio episode artwork lookup failed: {}".format(exc), app.xbmc.LOGWARNING)
    thumb = (
        item.get("thumb")
        or info.get("thumb")
        or tmdb_art.get("poster")
        or app.ADDON_ICON
    )
    art = {
        "thumb": thumb,
        "poster": thumb,
        "icon": thumb,
        "fanart": tmdb_art.get("fanart") or app.ADDON_FANART,
    }
    return info, art


def _render_item_list(app, result, url, mode, page, offset=0):
    items = result.get("items", [])
    if mode == "cartoons":
        items = listingoptions.sort_items(app.ADDON, items)
    next_url = result.get("next_page_url")
    per_page = app._items_per_page()
    total_pages = max(1, (len(items) + per_page - 1) // per_page)
    page = max(1, int(page))
    # A provider response with a next URL is already a remote page.  Slicing
    # it again would skip every item on page 2 when the configured page size
    # is larger than the provider's page size.
    if mode in ("cartoons", "latest"):
        # Display every merged item before fetching the next remote page.
        # Truncating to the first 20 used to discard alternate-provider items.
        offset = max(0, int(offset))
        page_items = items[offset:offset + per_page]
    elif next_url or page > 1:
        page_items = items
    else:
        page_items = items[(page - 1) * per_page:page * per_page]

    if not items:
        app.xbmcgui.Dialog().notification(
            app.ADDON_NAME, "No items found.", app.xbmcgui.NOTIFICATION_WARNING, 3000
        )
        app.end_of_directory()
        return

    # Limit concurrent website requests and preserve the original item order.
    with app.ThreadPoolExecutor(max_workers=6) as executor:
        presentations = list(executor.map(lambda item: app._listing_presentation(item, mode), page_items))
    for item, (info, art) in zip(page_items, presentations):
        if app._is_navigation_home(item):
            continue
        if item.get("is_folder"):
            # Taxonomy links and series links are both folders, but they need
            # different handlers.  Previously every folder was sent to the
            # series handler, so a category/navigation folder opened the wrong
            # page and could end in an empty listing.
            folder_url = item["url"]
            folder_mode = (
                "series_seasons"
                if "/video-serie/" in folder_url.lower() or "/video-series/" in folder_url.lower()
                or app.re.search(r"/(?:serie|series)/[^/]+", folder_url.lower())
                or ("b98.tv/videos_categories/" in folder_url.lower()
                    and not folder_url.rstrip("/").lower().endswith(("/cartoons", "/series")))
                else "cartoons"
            )
            folder_provider = app.providers.identify(folder_url)
            item_url = app.build_url(
                mode=folder_mode, url=folder_url,
                provider=folder_provider,
                **{"{}_url".format(folder_provider): folder_url},
            )
        else:
            item_url = app.build_url(
                mode="episode", url=item["url"], episode_title=item["label"]
            )

        label = item["label"]
        if not item.get("is_folder"):
            info = listingoptions.episode_info(app.ADDON, info)
            info["title"] = item["label"]
            label = listingoptions.episode_label(app.ADDON, item)
        app.add_directory_item(
            label,
            item_url,
            is_folder=item.get("is_folder", False),
            info=info,
            art=art,
        )

    if mode in ("cartoons", "latest") and offset:
        app.add_directory_item("[COLOR gold]<< Previous Items[/COLOR]",
                           app.build_url(mode=mode, url=url, page=page,
                                     offset=max(0, offset - per_page)), True)
    elif page > 1:
        app.add_directory_item("[COLOR gold]<< Previous Page (Page {}) • {} items[/COLOR]".format(page - 1, len(page_items)), app.build_url(mode=mode, url=url, page=page - 1), True)
    if mode in ("cartoons", "latest") and offset + per_page < len(items):
        app.add_directory_item("[COLOR gold]>> More Items[/COLOR]",
                           app.build_url(mode=mode, url=url, page=page,
                                     offset=offset + per_page), True)
    elif next_url or (mode not in ("cartoons", "latest") and page < total_pages):
        # Keep the catalogue root when advancing: a provider's next URL can
        # belong to another site and would change which catalogues are merged.
        app.add_next_page_item(url if mode in ("cartoons", "latest") else next_url or url,
                           mode, {"page": page + 1, "count": len(page_items)})

    app.end_of_directory()


def do_search(app, query=None, page=1, use_last=False, offset=0):
    if not query:
        query = app.ADDON.getSetting("last_search_query") if use_last else ""
        if not query:
            dialog = app.xbmcgui.Dialog()
            query = dialog.input("Search Cartoons", type=app.xbmcgui.INPUT_ALPHANUM)
    if not query:
        app.end_of_directory(False)
        return

    app.ADDON.setSetting("last_search_query", query)

    app.set_content("tvshows")
    cache_key = app._catalogue_key("search:{}:{}".format(query, page))
    result = app.diskcache.get("cartoonio_catalogue", cache_key, app.LIST_CACHE_TTL)
    if result is None:
        result = app._search_all_providers(query, page)
        app.diskcache.set("cartoonio_catalogue", cache_key, result)
    app._render_search_results(result, query, page, offset=offset)


def _search_all_providers(app, query, page=1):
    """Search the original site plus every provider's catalogue."""
    wanted = app._normalise_source_title(query)
    items = []
    tmdb_queries = []
    next_page = None
    mega_enabled = app._provider_enabled("megacartoons")
    # Start independent website and metadata requests together, rather than
    # waiting through separate primary, catalogue and episode-search batches.
    with app.ThreadPoolExecutor(max_workers=6) as executor:
        primary = executor.submit(app.scraper.search, query, page=page) if mega_enabled else None
        finders = [executor.submit(finder, query) for finder in
                   (app.tmdb.search_tv, app.tmdb.search_movie)] if app.ENABLE_TMDB else []
        catalogue_jobs = [(name, executor.submit(loader))
                          for name, label, module, loader in app._provider_jobs("get_series_list")
                          if name != "megacartoons"] if page == 1 else []
        searches = [(name, executor.submit(loader, query, page=page))
                    for name, label, module, loader in app._provider_jobs("search")
                    if name != "megacartoons"]
        if primary is not None:
            try:
                result = primary.result() or {}
                items.extend(result.get("items", []))
                next_page = result.get("next_page_url")
            except Exception as exc:
                app.xbmc.log("Cartoonio primary search failed: " + type(exc).__name__, app.xbmc.LOGWARNING)
        for future in finders:
            try:
                result = future.result() or {}
                name = (result.get("name") or result.get("title")) if isinstance(result, dict) else ""
                if name and app._normalise_source_title(name) != wanted and name not in tmdb_queries:
                    tmdb_queries.append(name)
            except Exception as exc:
                app.xbmc.log("Cartoonio TMDB search failed: " + type(exc).__name__, app.xbmc.LOGWARNING)
        aliases = [executor.submit(app.scraper.search, name, page=page)
                   for name in tmdb_queries] if mega_enabled else []
        for future in aliases:
            try:
                items.extend((future.result() or {}).get("items", []))
            except Exception as exc:
                app.xbmc.log("Cartoonio canonical search failed: " + type(exc).__name__, app.xbmc.LOGWARNING)
        for name, future in catalogue_jobs:
            try:
                for item in future.result() or []:
                    if wanted and wanted not in app._normalise_source_title(item.get("label")):
                        continue
                    item = dict(item)
                    if "/video/" in (item.get("url") or "").lower():
                        item["is_folder"] = False
                    items.append(item)
            except Exception as exc:
                app.xbmc.log("Cartoonio {} catalogue search failed: {}".format(name, type(exc).__name__), app.xbmc.LOGWARNING)
        for name, future in searches:
            try:
                result = future.result() or {}
                items.extend(result.get("items", []))
                next_page = next_page or result.get("next_page_url")
            except Exception as exc:
                app.xbmc.log("Cartoonio {} search failed: {}".format(name, type(exc).__name__), app.xbmc.LOGWARNING)
    merged = app._merge_catalogue_results(
        {"items": [], "next_page_url": next_page},
        {"items": items, "next_page_url": None},
    )
    # Keep exact matches first, but retain partial matches so searches for a
    # show or episode still work when a provider adds series/episode context
    # to its displayed title.
    def _search_rank(item):
        title = app._normalise_source_title(item.get("label", ""))
        accepted = [wanted] + [app._normalise_source_title(name) for name in tmdb_queries]
        if title in accepted:
            return 0
        if any(title.startswith(name) for name in accepted if name):
            return 1
        if any(name in title for name in accepted if name):
            return 2
        return 3

    # Some provider search endpoints return a broad catalogue page instead
    # of filtering server-side. Remove unrelated titles before rendering.
    merged["items"] = [
        item for item in merged.get("items", [])
        if _search_rank(item) < 3
        and not (
            item.get("is_folder")
            and app.re.search(r"/(?:category/cartoons|videos_categories/(?:cartoons|series))/?$", item.get("url", ""), app.re.I)
        )
    ]
    merged["items"] = sorted(
        enumerate(merged.get("items", [])),
        key=lambda pair: (_search_rank(pair[1]), pair[0]),
    )
    merged["items"] = [item for _, item in merged["items"]]
    return merged


def _search_presentation(app, item):
    """Fetch search display metadata without calling Kodi directory APIs."""
    if item.get("is_folder"):
        try:
            return app._enrich_item_with_tmdb(item)
        except Exception as exc:
            app.xbmc.log("Cartoonio search folder enrichment failed: " + type(exc).__name__, app.xbmc.LOGWARNING)
            return {}, {"thumb": item.get("thumb") or app.ADDON_ICON, "fanart": app.ADDON_FANART}
    info = {}
    tmdb_info = {}
    if app.ENABLE_TMDB and (listingoptions.descriptions(app.ADDON) or not item.get("thumb")):
        try:
            # Search results are usually standalone shorts, so try
            # movie metadata first and fall back to TV metadata.
            tmdb_info = app.tmdb.build_movie_info(item.get("label", "")) or {}
            if not tmdb_info:
                tmdb_info = app.tmdb.build_tv_info(item.get("label", "")) or {}
        except Exception as exc:
            app.xbmc.log("Cartoonio search TMDB lookup failed: {}".format(exc), app.xbmc.LOGWARNING)
    info = {
        key: tmdb_info[key]
        for key in ("plot", "year", "rating", "genres", "tmdb_id")
        if tmdb_info.get(key)
    }
    thumb = item.get("thumb", "") or tmdb_info.get("poster") or app.ADDON_ICON
    art = {
        "thumb": thumb,
        "poster": thumb,
        "icon": thumb,
        "fanart": tmdb_info.get("fanart") or app.ADDON_FANART,
    }
    return info, art


def _render_search_results(app, result, query, page, offset=0):
    items = result.get("items", [])
    next_url = result.get("next_page_url")
    per_page = app._items_per_page()
    page = max(1, int(page))
    offset = max(0, int(offset))
    has_more_items = offset + per_page < len(items)
    # Exhaust each merged remote page before requesting the next one.
    page_items = items[offset:offset + per_page]

    if not items:
        app.xbmcgui.Dialog().notification(
            app.ADDON_NAME, "No results found.", app.xbmcgui.NOTIFICATION_WARNING, 3000
        )
        # A filtered remote page can be empty while later pages still match.

    with app.ThreadPoolExecutor(max_workers=6) as executor:
        presentations = list(executor.map(app._search_presentation, page_items))
    for item, (info, art) in zip(page_items, presentations):
        # Search pages can include the site's navigation links alongside
        # actual cartoon results. Never show the Home link as a result.
        if app._is_navigation_home(item):
            continue
        if item.get("is_folder"):
            folder_url = item["url"]
            folder_mode = (
                "series_seasons"
                if "/video-serie/" in folder_url.lower() or "/video-series/" in folder_url.lower()
                or app.re.search(r"/(?:serie|series)/[^/]+", folder_url.lower())
                or ("b98.tv/videos_categories/" in folder_url.lower()
                    and not folder_url.rstrip("/").lower().endswith(("/cartoons", "/series")))
                else "cartoons"
            )
            provider = app.providers.identify(folder_url)
            item_url = app.build_url(mode=folder_mode, url=folder_url, provider=provider,
                                 **{provider + "_url": folder_url})
        else:
            item_url = app.build_url(
                mode="episode", url=item["url"], episode_title=item["label"]
            )
        label = item["label"]
        if not item.get("is_folder"):
            info = listingoptions.episode_info(app.ADDON, info)
            info["title"] = item["label"]
            label = listingoptions.episode_label(app.ADDON, item)
        app.add_directory_item(label, item_url, is_folder=item.get("is_folder", False),
                           info=info, art=art)

    # Next page carries the query so no re-prompt occurs
    if offset > 0 or page > 1:
        app.add_directory_item(
            "[COLOR gold]<< Previous Results • {} results shown[/COLOR]".format(len(page_items)),
            app.build_url(mode="search", query=query,
                      page=page if offset else page - 1,
                      offset=max(0, offset - per_page)),
            is_folder=True,
        )
    if has_more_items or next_url:
        url = app.build_url(mode="search", query=query,
                        page=page if has_more_items else page + 1,
                        offset=offset + per_page if has_more_items else 0)
        app.add_directory_item(
            "[COLOR gold]>> {} • {} results shown[/COLOR]".format(
                "More Results" if has_more_items else "Next Page (Page {})".format(page + 1),
                len(page_items)), url, is_folder=True,
            art={"icon": app.ADDON_ICON, "fanart": app.ADDON_FANART}
        )

    app.end_of_directory()


def show_categories(app):
    """Browse cartoons by category (scraped from nav/sidebar)."""
    app.set_content("tvshows")
    cats = app.scraper.get_categories() if app._provider_enabled("megacartoons") else []
    if not cats:
        app.xbmcgui.Dialog().notification(
            app.ADDON_NAME, "No categories found.", app.xbmcgui.NOTIFICATION_WARNING, 3000
        )
        app.end_of_directory()
        return
    for cat in cats:
        url = app.build_url(mode="cartoons", url=cat["url"])
        app.add_directory_item(
            cat["label"], url, is_folder=True,
            art={"icon": app.ADDON_ICON, "fanart": app.ADDON_FANART, "thumb": app.ADDON_ICON}
        )
    app.end_of_directory()
