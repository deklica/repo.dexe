"""Cartoonio's remote-friendly provider and stream chooser."""

import os
from urllib.parse import urlsplit

import xbmc
import xbmcgui


def stream_format(stream):
    try:
        path = urlsplit(stream["url"].split("|", 1)[0]).path.lower()
    except (KeyError, TypeError, AttributeError, ValueError):
        return "Video"
    if path.endswith(".mp4"):
        return "MP4"
    if path.endswith(".m3u8"):
        return "HLS"
    return "Video"


class SourcePicker(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.sources = []
        self.result = None
        self.provider_index = None
        self.episode = ""
        self.series = ""
        self.icon = ""
        self.ready = False
        self.list_id = 100

    def onInit(self):
        try:
            self.setProperty("Cartoonio.Episode", self.episode or "Choose a source")
            series = self.series.strip()
            if series.lower() in ("home", "cartoons", "series"):
                series = ""
            self.setProperty("Cartoonio.Series", series or "Select a provider to play")
            self.setProperty("Cartoonio.Icon", self.icon)
            self._show_providers()
            self.ready = True
        except Exception as exc:
            # Kodi invokes this callback separately from doModal; errors must
            # close the window here so the standard picker can take over.
            self.ready = False
            xbmc.log("Cartoonio picker initialization failed: " + type(exc).__name__, xbmc.LOGWARNING)
            self.close()

    def _populate(self, items):
        # Kodi calculates list page capacity from the XML layout. Changing
        # ControlList.setHeight at runtime can leave its original two-row
        # capacity behind, allowing a short list to scroll out of view.
        # Select a list whose XML viewport already fits the visible row count.
        rows = max(1, min(6, len(items)))
        list_height = rows * 82
        height = 232 + list_height + 88
        self.list_id = 99 + rows
        self.setProperty("Cartoonio.VisibleRows", str(rows))
        for control_id in range(100, 106):
            self.getControl(control_id).setVisible(control_id == self.list_id)
        self.getControl(300).setPosition(480, (1080 - height) // 2)
        self.getControl(301).setHeight(height + 4)
        self.getControl(302).setHeight(height)
        self.getControl(303).setPosition(34, 232 + list_height + 16)
        self.getControl(200).setPosition(748, 232 + list_height + 16)
        control = self.getControl(self.list_id)
        control.reset()
        control.addItems(items)
        control.selectItem(0)
        self.setFocusId(self.list_id)

    def _show_providers(self):
        self.provider_index = None
        self.setProperty("Cartoonio.CloseLabel", "Close")
        count = len(self.sources)
        self.setProperty("Cartoonio.Heading", "Choose a source · {} available".format(count))
        self.setProperty("Cartoonio.Count", "OK to play  ·  Back to close")
        items = []
        for name, streams in self.sources:
            formats = " / ".join(dict.fromkeys(stream_format(s) for s in streams))
            detail = formats if len(streams) == 1 else "{}  ·  {} streams".format(formats, len(streams))
            item = xbmcgui.ListItem(label=name, label2=detail)
            item.setProperty("Cartoonio.WideBadge", "true" if len(streams) > 1 or len(formats) > 9 else "false")
            items.append(item)
        self._populate(items)

    def onClick(self, control_id):
        if control_id == 200:
            if self.provider_index is not None:
                self._back()
            else:
                self.close()
            return
        if control_id != self.list_id:
            return
        index = self.getControl(self.list_id).getSelectedPosition()
        if self.provider_index is None:
            if not 0 <= index < len(self.sources):
                return
            name, streams = self.sources[index]
            if len(streams) == 1:
                self.result = (name, streams[0])
                self.close()
                return
            self.provider_index = index
            self.setProperty("Cartoonio.CloseLabel", "Sources")
            self.setProperty("Cartoonio.Heading", name + " · Choose a stream")
            self.setProperty("Cartoonio.Count", "Back returns to sources")
            self._populate([
                xbmcgui.ListItem(label=s.get("label") or "Stream {}".format(i + 1),
                                 label2=stream_format(s))
                for i, s in enumerate(streams)
            ])
        else:
            name, streams = self.sources[self.provider_index]
            if 0 <= index < len(streams):
                self.result = (name, streams[index])
                self.close()

    def _back(self):
        if self.provider_index is not None:
            selected = self.provider_index
            self._show_providers()
            self.getControl(self.list_id).selectItem(selected)
        else:
            self.close()

    def onAction(self, action):
        if action.getId() in (9, 10, 92):
            self._back()


def choose_source(addon_path, sources, episode="", series="", icon=""):
    """Return (provider, stream), or None on cancellation."""
    if not sources:
        return None
    dialog = None
    try:
        dialog = SourcePicker("CartoonioSources.xml", addon_path, "Default", "1080i")
        dialog.sources = sources
        dialog.episode = episode
        dialog.series = series
        dialog.icon = icon or os.path.join(addon_path, "icon.png")
        dialog.doModal()
        if dialog.ready:
            return dialog.result
    except Exception as exc:
        xbmc.log("Cartoonio source picker failed: " + type(exc).__name__, xbmc.LOGWARNING)
    finally:
        if dialog is not None:
            try:
                dialog.close()
            except Exception as exc:
                xbmc.log("Cartoonio picker cleanup failed: " + type(exc).__name__, xbmc.LOGWARNING)
    # A skin-loading failure should still leave playback accessible.
    index = xbmcgui.Dialog().select("Cartoonio · Choose Source", [s[0] for s in sources])
    if not 0 <= index < len(sources):
        return None
    name, streams = sources[index]
    if len(streams) == 1:
        return name, streams[0]
    index = xbmcgui.Dialog().select(name + " · Choose Stream", [
        s.get("label") or "Stream {}".format(i + 1) for i, s in enumerate(streams)
    ])
    return (name, streams[index]) if 0 <= index < len(streams) else None
