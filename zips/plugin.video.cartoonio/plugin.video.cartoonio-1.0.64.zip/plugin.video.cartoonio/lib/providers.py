"""Single registry of provider identities, capabilities and cache namespaces."""

from importlib import import_module
from urllib.parse import urlsplit


class Provider:
    def __init__(self, name, label, module_name, episodes="get_series_episodes"):
        self.name = name
        self.label = label
        self.module_name = module_name
        self.episodes = episodes

    @property
    def module(self):
        return import_module(self.module_name)

    @property
    def cache_namespace(self):
        return self.name + "_html"

    def owns(self, url):
        try:
            host = urlsplit(url or "").hostname or ""
            expected = urlsplit(self.module.BASE_URL).hostname or ""
            return host.lower().removeprefix("www.") == expected.lower().removeprefix("www.")
        except ValueError:
            return False


REGISTRY = (
    Provider("megacartoons", "MegaCartoons", "scraper", "get_all_series_episodes"),
    Provider("topcartoons", "TopCartoons", "topcartoons", "get_all_series_episodes"),
    Provider("supercartoons", "SuperCartoons", "supercartoons"),
    Provider("toontales", "ToonTales", "toontales"),
    Provider("b98", "B98.TV", "b98"),
    Provider("funniermoments", "FunnierMoments", "funniermoments"),
)
PROVIDERS = tuple((p.name, p.label) for p in REGISTRY)


def jobs(addon, method):
    return [(p.name, p.label, p.module, getattr(p.module, method)) for p in REGISTRY
            if addon.getSetting("enable_" + p.name).strip().lower() != "false"
            and hasattr(p.module, method)]


def identify(url):
    return next((p.name for p in REGISTRY if p.owns(url)), "megacartoons")


def label_for_url(url):
    try:
        if not urlsplit(url or "").hostname:
            return ""
    except ValueError:
        return ""
    return next((p.label for p in REGISTRY if p.owns(url)), "")


def navigation_urls(params):
    return {p.name: params.get(p.name + "_url", "") for p in REGISTRY}


def url_parameters(urls):
    return {p.name + "_url": urls.get(p.name, "") for p in REGISTRY}
