"""
Cartoonio - multi-provider cartoon browsing and playback
Kodi 21+ (Omega) compatible
"""

import sys
import os
import re
import time
from html import unescape as _html_unescape
from concurrent.futures import ThreadPoolExecutor
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

# Ensure lib folder is on path
ADDON_PATH = xbmcaddon.Addon().getAddonInfo("path")
_LIB_PATH = os.path.join(ADDON_PATH, "lib")
if _LIB_PATH not in sys.path:
    sys.path.insert(0, _LIB_PATH)

try:
    from urllib.parse import urlencode, parse_qs
except ImportError:
    from urlparse import parse_qs
    from urllib import urlencode

import scraper
import supercartoons
import topcartoons
import toontales
import b98
import funniermoments
import tmdb
import diskcache
import sourcepicker
import changelog
import cacheprompt
import preferences
import maintenance
import settingsdialog
import providers
import menuart

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")
ADDON_NAME = ADDON.getAddonInfo("name")
ADDON_ICON = ADDON.getAddonInfo("icon")
ADDON_FANART = ADDON.getAddonInfo("fanart")
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]

# Migrate values saved by the previous settings schema. Kodi keeps addon
# settings in userdata, so changing settings.xml alone does not replace blank
# or zero values already stored on the device.
if ADDON.getSetting("items_per_page") not in ("20", "40", "60", "100"):
    ADDON.setSetting("items_per_page", "40")
if ADDON.getSetting("enable_tmdb") == "":
    ADDON.setSetting("enable_tmdb", "true")
if ADDON.getSetting("enable_tmdb_screenshots") == "":
    ADDON.setSetting("enable_tmdb_screenshots", "true")

def _setting_bool(name, default=False):
    """Read settings safely across Kodi builds and fresh addon profiles."""
    # Older profiles store these as strings without a typed settings schema.
    # getSettingBool logs a native 'Invalid setting type' error for those.
    value = ADDON.getSetting(name).strip().lower()
    return value == "true" if value else default


ENABLE_TMDB = _setting_bool("enable_tmdb", True)
ENABLE_SCREENSHOTS = ENABLE_TMDB and _setting_bool("enable_tmdb_screenshots", True)


def _items_per_page():
    """Return the configured page size, with a safe Kodi/settings fallback."""
    return preferences.page_size(ADDON)


def _provider_enabled(name):
    return preferences.enabled(ADDON, name)


def _catalogue_key(key):
    return preferences.catalogue_key(ADDON, key, tmdb.TMDB_LANGUAGE)


def _provider_jobs(method):
    return providers.jobs(ADDON, method)


def _load_catalogue(jobs):
    result = {"items": [], "next_page_url": None}
    with ThreadPoolExecutor(max_workers=6) as executor:
        pending = [(name, executor.submit(loader)) for name, loader in jobs]
        for name, future in pending:
            try:
                result = _merge_catalogue_results(result, future.result())
            except Exception as exc:
                xbmc.log("Cartoonio {} listing failed: {}".format(name, type(exc).__name__), xbmc.LOGWARNING)
    return result


LIST_CACHE_TTL = 900

# Push the user-configured TMDB key into the tmdb module at load time
import tmdb as _tmdb_module
_user_key = ADDON.getSetting("tmdb_api_key").strip()
if _user_key:
    _tmdb_module.TMDB_API_KEY = _user_key
_tmdb_module.TMDB_LANGUAGE = preferences.language(ADDON, xbmc)


# ---------------------------------------------------------------------------
# URL helpers
# ---------------------------------------------------------------------------

def build_url(**kwargs):
    return "{}?{}".format(BASE_URL, urlencode(kwargs))


def get_params():
    params = {}
    if len(sys.argv) > 2 and sys.argv[2]:
        qs = sys.argv[2].lstrip("?")
        raw = parse_qs(qs)
        for k, v in raw.items():
            # parse_qs already decodes percent escapes and plus signs.
            params[k] = v[0]
    return params


# ---------------------------------------------------------------------------
# Directory listing helpers
# ---------------------------------------------------------------------------

def set_content(content_type):
    xbmcplugin.setContent(HANDLE, content_type)


def end_of_directory(succeeded=True, cache_to_disc=False):
    if HANDLE >= 0:
        xbmcplugin.endOfDirectory(HANDLE, succeeded, cacheToDisc=cache_to_disc)


def add_directory_item(label, url, is_folder=True, info=None, art=None, playable=None):
    label = _html_unescape(label or "")
    li = xbmcgui.ListItem(label)

    # Default art
    artwork = {
        "icon":   ADDON_ICON,
        "fanart": ADDON_FANART,
        "thumb":  ADDON_ICON,
        "poster": ADDON_ICON,
    }
    if art:
        artwork.update({k: v for k, v in art.items() if v})
    li.setArt(artwork)

    # Info tag
    tag = li.getVideoInfoTag()
    tag.setTitle((info or {}).get("title") or label)
    if info:
        if info.get("plot"):
            tag.setPlot(info["plot"])
        if info.get("year"):
            try:
                tag.setYear(int(info["year"]))
            except Exception:
                pass
        if info.get("rating"):
            tag.setRating(float(info["rating"]))
        if info.get("genres"):
            tag.setGenres(info["genres"])
        if info.get("cast"):
            cast_members = [xbmc.Actor(name) for name in info["cast"]]
            tag.setCast(cast_members)
        if info.get("season"):
            tag.setSeason(int(info["season"]))
        if info.get("episode"):
            tag.setEpisode(int(info["episode"]))
        if info.get("tvshowtitle"):
            tag.setTvShowTitle(info["tvshowtitle"])
        if info.get("duration"):
            tag.setDuration(int(info["duration"]))

    if playable is None:
        playable = not is_folder
    li.setProperty("IsPlayable", "true" if playable else "false")
    params = get_params()
    if params.get("mode") in ("latest", "cartoons", "series_list", "series_seasons", "season_episodes", "search"):
        params["fresh"] = "1"
        li.addContextMenuItems([("Refresh this listing", "Container.Update({},replace)".format(build_url(**params)))])
    xbmcplugin.addDirectoryItem(HANDLE, url, li, is_folder)


def add_next_page_item(next_url, mode, extra_params=None):
    params = {"mode": mode, "url": next_url}
    if extra_params:
        params.update(extra_params)
    url = build_url(**params)
    add_directory_item(
        "[COLOR gold]>> Next Page (Page {}){}[/COLOR]".format(
            params.get("page", ""),
            " • {} items shown".format(params["count"]) if params.get("count") else "",
        ),
        url,
        is_folder=True,
        art={"icon": ADDON_ICON, "fanart": ADDON_FANART},
    )


# ---------------------------------------------------------------------------
# TMDB enrichment
# ---------------------------------------------------------------------------

def _enrich_item_with_tmdb(item):
    """
    Try to find TMDB info for an item by its label.
    Returns (tmdb_info_dict, art_dict).
    """
    label = item.get("label", "")
    # Clean up label for TMDB search
    clean = re.sub(r'\s*(season|episode|ep|s\d+|e\d+)\s*\d*', '', label, flags=re.I).strip()
    clean = re.sub(r'\s+', ' ', clean).strip()

    info = {}
    art = {}

    if not ENABLE_TMDB or not clean:
        return info, art

    # Try TV first (most cartoons are series)
    tmdb_data = tmdb.build_tv_info(clean)
    if not tmdb_data:
        tmdb_data = tmdb.build_movie_info(clean)

    if tmdb_data:
        info = {
            "plot": tmdb_data.get("plot", ""),
            "year": tmdb_data.get("year", ""),
            "rating": tmdb_data.get("rating", 0),
            "genres": tmdb_data.get("genres", []),
            "cast": tmdb_data.get("cast", []),
        }
        poster = tmdb_data.get("poster", "")
        fanart = tmdb_data.get("fanart", "") or tmdb_data.get("backdrop", "")

        art = {
            "thumb":  poster or item.get("thumb", ""),
            "poster": poster or item.get("thumb", ""),
            "fanart": fanart or ADDON_FANART,
            "icon":   poster or item.get("thumb", "") or ADDON_ICON,
        }
    else:
        # Fallback: use scraped thumbnail
        art = {
            "thumb":  item.get("thumb", "") or ADDON_ICON,
            "poster": item.get("thumb", "") or ADDON_ICON,
            "fanart": ADDON_FANART,
            "icon":   item.get("thumb", "") or ADDON_ICON,
        }

    return info, art


# ---------------------------------------------------------------------------
# Mode handlers
# ---------------------------------------------------------------------------

def show_main_menu():
    set_content("tvshows")
    items = scraper.get_main_menu()
    for item in items:
        url = build_url(mode=item["mode"], url=item.get("url", ""))
        menu_icon = item.get("icon") or ADDON_ICON
        if item.get("mode") == "latest":
            menu_icon = os.path.join(ADDON_PATH, "resources", "latest-v3.png")
        elif item.get("mode") == "cartoons":
            menu_icon = os.path.join(ADDON_PATH, "resources", "az-v2.png")
        elif item.get("mode") == "series_list":
            menu_icon = os.path.join(ADDON_PATH, "resources", "series-v2.png")
        elif item.get("mode") in ("search", "search_prompt"):
            menu_icon = os.path.join(ADDON_PATH, "resources", "search-v1.png")
        elif item.get("mode") == "tools":
            menu_icon = os.path.join(ADDON_PATH, "resources", "tools-v2.png")
        add_directory_item(
            item["label"],
            url,
            is_folder=True,
            art={"icon": menu_icon,
                 "fanart": ADDON_FANART,
                 "thumb": menu_icon,
                 "poster": menu_icon},
            info=item.get("info"),
        )
    end_of_directory()


def show_changelog():
    """Display the release notes shipped with the installed addon."""
    path = os.path.join(ADDON_PATH, "addon.xml")
    try:
        with open(path, "r", encoding="utf-8") as handle:
            xml = handle.read()
        match = re.search(r"<news[^>]*>(.*?)</news>", xml, re.I | re.S)
        news = match.group(1).strip() if match else "No changelog available."
        # Keep each release on its own line in Kodi's text viewer.
        news = re.sub(r"\n[ \t]+", "\n", news)
    except Exception as exc:
        xbmc.log("Cartoonio changelog read failed: {}".format(exc), xbmc.LOGWARNING)
        news = "No changelog available."
    changelog.show(ADDON_PATH, news, ADDON.getAddonInfo("version"), ADDON_ICON)

def clear_addon_cache(scope="all"):
    dialog = xbmcgui.Dialog()
    if scope not in ("all", "providers", "metadata"):
        scope = "all"
    if not cacheprompt.confirm(ADDON_PATH, ADDON_ICON, scope):
        end_of_directory(cache_to_disc=False)
        return
    progress = None
    report = {"success": False, "removed": 0, "failed": 0}
    try:
        progress = xbmcgui.DialogProgressBG()
        progress.create(ADDON_NAME, "Clearing Cartoonio cache…")
    except Exception:
        progress = None
    try:
        report = maintenance.clear_cache(scope)
        if progress is not None:
            try:
                progress.update(100, message="Finishing cleanup…")
            except Exception:
                pass
    except Exception as exc:
        report["success"] = False
        xbmc.log("Cartoonio cache clear failed: " + type(exc).__name__, xbmc.LOGWARNING)
    finally:
        if progress is not None:
            try:
                progress.close()
            except Exception:
                pass
        end_of_directory(cache_to_disc=False)
    if report["success"]:
        xbmc.log("Cartoonio cache clear complete: {} files removed, 0 cleanup failures; scope={}.".format(
            report["removed"], scope), xbmc.LOGINFO)
        message = ("Cleared {} cached file{}.".format(report["removed"], "" if report["removed"] == 1 else "s")
                   if report["removed"] else "Cartoonio cache is already empty.")
        dialog.notification(ADDON_NAME, message, xbmcgui.NOTIFICATION_INFO, 3000)
    else:
        xbmc.log("Cartoonio cache clear incomplete: {} removed, {} cleanup failures.".format(
            report["removed"], report["failed"]), xbmc.LOGWARNING)
        dialog.notification(ADDON_NAME, "Cache partly cleared. Try Clear Cache again.", xbmcgui.NOTIFICATION_WARNING, 5000)
    # Keep the cleared cache empty until the user opens another listing.

def add_tool_item(label, mode, is_folder=False, **params):
    add_directory_item(label, build_url(mode=mode, **params), is_folder, playable=False,
                       art=menuart.tool_art(ADDON_PATH, ADDON_FANART, mode, params.get("scope", "")))


def show_tools():
    set_content("files")
    add_tool_item("Settings", "settings")
    add_tool_item("Changelog", "changelog")
    add_tool_item("Cache", "cache_menu", True)
    add_tool_item("Diagnostics", "diagnostics_menu", True)
    end_of_directory()

def show_diagnostics_menu():
    set_content("files")
    add_tool_item("Check Provider Connections", "check_providers")
    end_of_directory()

def show_cache_menu():
    set_content("files")
    add_tool_item("Cache Information", "cache_info")
    add_tool_item("Clear All Cache", "clear_cache", scope="all")
    add_tool_item("Clear Provider and Listing Cache", "clear_cache", scope="providers")
    add_tool_item("Clear TMDB Metadata Cache", "clear_cache", scope="metadata")
    end_of_directory()


def _merge_catalogue_results(primary, alternate):
    """Merge provider listings without repeating the same titled item."""
    items = []
    seen = set()
    for item in primary.get("items", []) + alternate.get("items", []):
        if _is_navigation_home(item):
            continue
        key = (
            "folder" if item.get("is_folder") else "episode",
            _normalise_source_title(item.get("label")),
        )
        if not key[1] or key in seen:
            continue
        seen.add(key)
        items.append(item)
    return {
        "items": items,
        "next_page_url": primary.get("next_page_url") or alternate.get("next_page_url"),
    }


def _series_name_from_url(url):
    """
    Derive a human-readable series name from a /video-serie/{slug}/ URL.
    Used as the TMDB search term so we never search by episode title.
    """
    m = re.search(r'/video-series?/([^/?#]+)', url)
    if m:
        slug = m.group(1).strip('/')
        return slug.replace('-', ' ').replace('_', ' ').title()
    m = re.search(r'/serie/([^/?#]+)', url)
    if m:
        return m.group(1).strip('/').replace('-', ' ').replace('_', ' ').title()
    m = re.search(r'/series/([^/?#]+)', url)
    if m:
        return m.group(1).strip('/').replace('-', ' ').replace('_', ' ').title()
    m = re.search(r'/videos_categories/([^/?#]+)', url)
    if m:
        slug = m.group(1).strip('/')
        if slug.lower() not in ("series", "cartoons"):
            return slug.replace('-', ' ').replace('_', ' ').title()
    return ""


def _episode_season(item, default=1):
    """Return a season number when the source exposes one, else Season 1."""
    if item.get("season"):
        try:
            return int(item["season"])
        except (TypeError, ValueError):
            pass

    text = "{} {}".format(item.get("label", ""), item.get("url", ""))
    for pattern in (
        r"\bS(?:eason)?\s*0*(\d+)\b",  # S01, S1, Season 2
        r"\bseason[-_\s]*0*(\d+)\b",
    ):
        match = re.search(pattern, text, re.I)
        if match:
            return int(match.group(1))
    return default


def _get_series_presentation(url):
    """Get the shared series name, metadata, and artwork for folder views."""
    series_name = _series_name_from_url(url)
    series_fanart = ADDON_FANART
    series_poster = ADDON_ICON
    series_info = {"tvshowtitle": series_name}

    if ENABLE_TMDB and series_name:
        tmdb_data = tmdb.build_tv_info(series_name)
        if not tmdb_data:
            tmdb_data = tmdb.build_movie_info(series_name)
        if tmdb_data:
            series_fanart = (
                tmdb_data.get("fanart")
                or tmdb_data.get("backdrop")
                or ADDON_FANART
            )
            series_poster = tmdb_data.get("poster") or ADDON_ICON
            series_info.update({
                "tmdb_id": tmdb_data.get("tmdb_id"),
                "plot": tmdb_data.get("plot", ""),
                "year": tmdb_data.get("year", ""),
                "rating": tmdb_data.get("rating", 0),
                "genres": tmdb_data.get("genres", []),
            })

    return series_name, series_fanart, series_poster, series_info


def _map_episodes_to_tmdb(items, series_info):
    """Add TMDB season/episode numbers when the series was identified."""
    tmdb_id = series_info.get("tmdb_id") if series_info else None
    if not ENABLE_TMDB or not tmdb_id:
        return items
    try:
        return tmdb.map_episode_seasons(tmdb_id, items)
    except Exception as exc:
        xbmc.log(
            "Cartoonio TMDB episode mapping failed: {}".format(exc),
            xbmc.LOGWARNING,
        )
        return items


def _normalise_source_title(value):
    value = _html_unescape(re.sub(r"<[^>]+>", "", value or "")).lower()
    value = re.sub(r"[^a-z0-9]+", " ", value).strip()
    value = re.sub(r"^the\s+", "", value)
    value = re.sub(r"\s+show$", "", value)
    return value.strip()


def _is_navigation_home(item):
    """Reject provider navigation links that masquerade as episodes."""
    return _normalise_source_title((item or {}).get("label", "")) == "home"


def _find_megacartoons_streams(episode_title, current_url=""):
    """Resolve MegaCartoons directly or locate the matching episode by title."""
    if "megacartoons.net" in (current_url or "").lower():
        return scraper.get_episode_page(current_url)
    wanted = _normalise_source_title(episode_title)
    if not wanted:
        return []
    result = scraper.search(episode_title)
    for item in result.get("items", []):
        if item.get("is_folder"):
            continue
        if _normalise_source_title(item.get("label")) == wanted:
            streams = scraper.get_episode_page(item.get("url", ""))
            if streams:
                return streams
    return []


# ---------------------------------------------------------------------------
# Handler registration
# ---------------------------------------------------------------------------


from application import bind_handlers
bind_handlers(sys.modules[__name__])


if __name__ == "__main__":
    router()
