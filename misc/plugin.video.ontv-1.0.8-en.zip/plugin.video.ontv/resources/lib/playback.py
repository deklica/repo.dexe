# -*- coding: utf-8 -*-
"""
OnTV — playback engine selection and ListItem construction.

Engines:
  proxy         the addon's local proxy (reconnect, buffer, HLS->TS, Range)
  direct        Kodi native (FFmpeg) — ideal for VOD (seek) and non-HTTP protocols

Used by the navigator (setResolvedUrl) and by the service (automatic fallback).
"""

import re
from urllib.parse import urlsplit, quote

import common
from common import log, log_warn, mask_url, setting_int

try:
    import xbmc
    import xbmcgui
    IN_KODI = True
except Exception:
    IN_KODI = False

_VOD_MIME = {
    'mp4': 'video/mp4', 'm4v': 'video/mp4', 'mkv': 'video/x-matroska',
    'avi': 'video/x-msvideo', 'mov': 'video/quicktime', 'ts': 'video/mp2t',
    'mpg': 'video/mpeg', 'mpeg': 'video/mpeg', 'flv': 'video/x-flv', 'wmv': 'video/x-ms-wmv',
}
_VOD_EXT = tuple('.' + e for e in ('mp4', 'm4v', 'mkv', 'avi', 'mov', 'mpg', 'mpeg', 'flv', 'wmv'))


def split_pipe(url):
    """'url|User-Agent=x&Referer=y' -> (url, {headers})."""
    if '|' not in url:
        return url, {}
    base, _, rest = url.partition('|')
    hdr = {}
    from urllib.parse import unquote_plus
    for kv in rest.split('&'):
        k, _, v = kv.partition('=')
        if k:
            hdr[k] = unquote_plus(v)
    return base, hdr


def join_pipe(url, headers):
    if not headers:
        return url
    return url + '|' + '&'.join('{}={}'.format(k, quote(str(v), safe='')) for k, v in headers.items())


def guess_kind(url):
    """'live' or 'vod' from the URL (for old items/favourites without a type)."""
    p = urlsplit(url).path.lower()
    if '/movie/' in p or '/series/' in p or p.endswith(_VOD_EXT):
        return 'vod'
    return 'live'


def decide_engine(url, kind):
    """Returns 'proxy' | 'direct'."""
    if not url.lower().startswith(('http://', 'https://')):
        return 'direct'                                    # rtmp/rtsp/udp/local files
    pref = setting_int('engine', 0)                        # 0 auto 1 proxy 2 direct (3 = old ffmpegdirect => auto)
    if kind == 'vod':
        return 'proxy' if pref == 1 else 'direct'          # VOD: Kodi native seek
    if pref == 2:
        return 'direct'
    return 'proxy'


def build(url, name='', logo='', kind=None, headers=None, stalker=None, engine=None):
    """
    Prepare the item to play.
    Returns (path, ListItem, engine_used).
    """
    url, pipe_h = split_pipe(url)
    hdrs = dict(pipe_h)
    if headers:
        hdrs.update(headers)
    kind = kind or guess_kind(url)
    engine = engine or decide_engine(url, kind)

    path = url
    if engine == 'proxy':
        import proxy
        spec = {'u': url}
        if hdrs:
            spec['h'] = hdrs
        if kind == 'live':
            spec['f'] = {0: 'ts', 1: 'auto', 2: 'hls'}.get(setting_int('live_format', 0), 'ts')
        if stalker:
            spec['st'] = stalker
        purl = proxy.build_url(spec, kind)
        if purl:
            path = purl
        else:
            log_warn('Proxy unavailable — direct playback')
            engine = 'direct'
    if engine == 'direct':
        path = common_join(url, hdrs)

    li = xbmcgui.ListItem(name, path=path)
    icon = logo or ''
    li.setArt({'thumb': icon, 'icon': icon})
    common.set_video_info(li, title=name, mediatype='movie' if kind == 'vod' else 'video')
    li.setProperty('IsPlayable', 'true')

    ext = urlsplit(url).path.rsplit('.', 1)[-1].lower() if '.' in urlsplit(url).path else ''
    if engine == 'proxy':
        if kind == 'live':
            li.setMimeType('video/mp2t')
        elif ext in _VOD_MIME:
            li.setMimeType(_VOD_MIME[ext])
        li.setContentLookup(False)
    else:                                                  # direct
        if kind == 'live':
            li.setMimeType('application/x-mpegURL' if ext == 'm3u8' else 'video/mp2t')
            li.setContentLookup(False)                     # avoids 1 extra connection (single-connection accounts)
        elif ext in _VOD_MIME:
            li.setMimeType(_VOD_MIME[ext])
            li.setContentLookup(False)
    log('Play [{}/{}] {}'.format(engine, kind, mask_url(url[:90])))
    return path, li, engine


def common_join(url, hdrs):
    return join_pipe(url, hdrs)
