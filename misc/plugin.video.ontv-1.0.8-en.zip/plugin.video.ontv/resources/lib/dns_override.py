# -*- coding: utf-8 -*-
"""
OnTV — DNS override  v1.0.4

Replaces the system resolver with custom DNS servers
(AdGuard, Cloudflare, OpenDNS, Google) to get around DNS blocks
that prevent access to IPTV servers.

Inspired by the dns.py module from Eagle TV Online, rewritten without
external dependencies (no kodi_six, no requests).

How it works:
  - Intercepts socket.getaddrinfo with a DNS-over-UDP resolver
  - On-disk cache with a 1 hour TTL
  - Enabled/disabled by the dns_provider setting
  - IPv4 only (IPTV does not need IPv6)
"""

import socket
import struct
import random
import os
import json
import time
import threading

try:
    import xbmc
    import xbmcaddon
    import xbmcvfs
    def _log(msg, level=None):
        xbmc.log('[OnTV/dns] ' + str(msg), level or xbmc.LOGINFO)
    def _profile():
        return xbmcvfs.translatePath('special://temp/')
except Exception:
    def _log(msg, level=None):
        print('[OnTV/dns] ' + msg)
    def _profile():
        return os.path.dirname(__file__)

# ── Available DNS servers ─────────────────────────────────────────────

DNS_PROVIDERS = {
    'system':     None,                        # disabled — use the OS DNS
    'adguard':    ['94.140.14.140', '94.140.14.141'],
    'cloudflare': ['1.1.1.1', '1.0.0.1'],
    'opendns':    ['208.67.222.222', '208.67.220.220'],
    'google':     ['8.8.8.8', '8.8.4.4'],
}

_CACHE_FILE = os.path.join(_profile(), 'ontv_dns_cache.json')
_CACHE_TTL  = 3600   # 1 hour
_TIMEOUT    = 3      # seconds per DNS attempt

_state = {
    'installed':           False,
    'original_getaddrinfo': None,
    'servers':             [],
    'cache':               {},
    'lock':                threading.Lock(),
}


# ── Cache persistence ──────────────────────────────────────────────────

def _load_cache():
    try:
        if os.path.exists(_CACHE_FILE):
            with open(_CACHE_FILE, 'r') as f:
                raw = json.load(f)
            # Drop expired entries
            now = time.time()
            return {k: v for k, v in raw.items() if now - v.get('ts', 0) < _CACHE_TTL}
    except Exception:
        pass
    return {}

def _save_cache():
    try:
        with _state['lock']:
            tmp = _CACHE_FILE + '.tmp'
            with open(tmp, 'w') as f:
                json.dump(_state['cache'], f)
            os.replace(tmp, _CACHE_FILE)
    except Exception:
        pass


# ── DNS-over-UDP resolver ──────────────────────────────────────────────────

def _build_query(hostname):
    """Build a type A (IPv4) DNS query packet."""
    txid   = random.randint(0, 65535)
    header = struct.pack('!HHHHHH', txid, 0x0100, 1, 0, 0, 0)
    parts  = hostname.rstrip('.').split('.')
    qname  = b''
    for p in parts:
        enc = p.encode('ascii', errors='replace')
        qname += struct.pack('!B', len(enc)) + enc
    qname  += b'\x00'
    qtype   = struct.pack('!HH', 1, 1)   # A, IN
    return header + qname + qtype, txid

def _parse_answer(data, txid):
    """Extract IPv4 addresses from a DNS response."""
    if len(data) < 12:
        return []
    rtxid, flags, qdcount, ancount = struct.unpack('!HHHH', data[:8])
    if rtxid != txid or ancount == 0:
        return []

    # Skip the question section
    pos = 12
    for _ in range(qdcount):
        while pos < len(data):
            length = data[pos]
            if length == 0:
                pos += 1
                break
            if length >= 0xC0:   # compression pointer
                pos += 2
                break
            pos += 1 + length
        pos += 4   # QTYPE + QCLASS

    ips = []
    for _ in range(ancount):
        if pos >= len(data):
            break
        # Skip the name (may be a pointer)
        if pos < len(data) and data[pos] >= 0xC0:
            pos += 2
        else:
            while pos < len(data) and data[pos] != 0:
                pos += 1 + data[pos]
            pos += 1
        if pos + 10 > len(data):
            break
        rtype, _, _, rdlen = struct.unpack('!HHIH', data[pos:pos+10])
        pos += 10
        if rtype == 1 and rdlen == 4 and pos + 4 <= len(data):
            ips.append(socket.inet_ntoa(data[pos:pos+4]))
        pos += rdlen
    return ips

def _udp_resolve(hostname, servers):
    """Query DNS servers over UDP. Returns a list of IPs or []."""
    query, txid = _build_query(hostname)
    for server in servers:
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.settimeout(_TIMEOUT)
            sock.sendto(query, (server, 53))
            data, _ = sock.recvfrom(512)
            sock.close()
            ips = _parse_answer(data, txid)
            if ips:
                return ips
        except Exception:
            try:
                sock.close()
            except Exception:
                pass
    return []


# ── socket.getaddrinfo interceptor ─────────────────────────────────────

def _custom_getaddrinfo(host, port, family=0, type=0, proto=0, flags=0):
    """Replacement for socket.getaddrinfo using custom DNS with cache."""
    # Do not intercept literal IPs or localhost
    try:
        socket.inet_aton(str(host))
        return _state['original_getaddrinfo'](host, port, family, type, proto, flags)
    except Exception:
        pass
    if str(host) in ('localhost', '127.0.0.1', '::1'):
        return _state['original_getaddrinfo'](host, port, family, type, proto, flags)

    # Check the in-memory cache
    key = str(host)
    with _state['lock']:
        entry = _state['cache'].get(key)
        if entry and time.time() - entry['ts'] < _CACHE_TTL:
            ips = entry['ips']
        else:
            ips = None

    if ips is None:
        ips = _udp_resolve(host, _state['servers'])
        if ips:
            with _state['lock']:
                _state['cache'][key] = {'ips': ips, 'ts': time.time()}
            # Save in the background so we do not block
            t = threading.Thread(target=_save_cache)
            t.daemon = True
            t.start()

    if ips and family in (0, socket.AF_INET):
        try:
            port_i = int(port or 0)
        except Exception:
            port_i = 0
        socktype = type or socket.SOCK_STREAM
        results = [(socket.AF_INET, socktype, proto, '', (ip, port_i)) for ip in ips]
        if results:
            return results

    # Fallback to the system resolver
    return _state['original_getaddrinfo'](host, port, family, type, proto, flags)


# ── Public API ────────────────────────────────────────────────────────────

def activate(provider='adguard'):
    """
    Enable the DNS override with the given provider.
    provider must be a key of DNS_PROVIDERS.
    If provider=='system', the override is disabled.
    """
    servers = DNS_PROVIDERS.get(provider)
    if not servers:
        deactivate()
        return

    _state['servers'] = servers
    _state['cache']   = _load_cache()

    if not _state['installed']:
        _state['original_getaddrinfo'] = socket.getaddrinfo
        socket.getaddrinfo = _custom_getaddrinfo
        _state['installed'] = True
        _log('DNS override enabled: {} → {}'.format(provider, servers))
    else:
        _log('DNS override already active, servers updated: {}'.format(servers))


def deactivate():
    """Restore the system DNS resolver."""
    if _state['installed'] and _state['original_getaddrinfo']:
        socket.getaddrinfo = _state['original_getaddrinfo']
        _state['installed'] = False
        _log('DNS override disabled')


def is_active():
    return _state['installed']


def current_provider():
    """Return the name of the active provider, or 'system'."""
    if not _state['installed']:
        return 'system'
    for name, servers in DNS_PROVIDERS.items():
        if servers and set(servers) == set(_state.get('servers', [])):
            return name
    return 'custom'


def clear_cache():
    """Clear the DNS cache in memory and on disk."""
    with _state['lock']:
        _state['cache'] = {}
    try:
        if os.path.exists(_CACHE_FILE):
            os.remove(_CACHE_FILE)
        _log('DNS cache cleared')
    except Exception:
        pass
