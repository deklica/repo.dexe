# -*- coding: utf-8 -*-
"""
OnTV — Navigator
Sources: Xtream Codes, Stalker/MAG (MAC), M3U / M3U_plus.

Safe for reuselanguageinvoker: does not read sys.argv at import time.
Kept: adult filter, menu structure. Categories: Serbia first, then ex-YU.
"""

import json
import math
import os
import sys
import time
from urllib.parse import urlencode, parse_qsl, quote

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs

import common
import api
from common import (is_adult, filter_adult, region_priority, set_video_info, setting_int,
                    setting_bool, mask_url, L)

ADDON = xbmcaddon.Addon()
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_PATH = ADDON.getAddonInfo('path')
ICON = os.path.join(ADDON_PATH, 'icon.png')
FANART = os.path.join(ADDON_PATH, 'fanart.png')

HANDLE = -1
BASE_URL = ''
PROP_LAST = 'ontv.last_play'


def log(msg, level=xbmc.LOGDEBUG):
    xbmc.log('[OnTV] ' + str(msg), level)


# ════════════════════════════════════════════════════════
#  UI helpers
# ════════════════════════════════════════════════════════

def url_for(params):
    return BASE_URL + '?' + urlencode(params)


def notify(msg, icon=xbmcgui.NOTIFICATION_ERROR, duration=4000):
    xbmcgui.Dialog().notification(ADDON_NAME, msg, icon, duration)


def _ttl(name):
    if name == 'm3u':
        return max(1, setting_int('cache_m3u_min', 15)) * 60
    return max(1, setting_int('cache_api_min', 5)) * 60


def servers():
    from mediacfg import load_servers
    return api.normalize_servers(load_servers())


def get_srv(idx):
    lst = servers()
    try:
        return lst[int(idx)]
    except Exception:
        return None


def _srv_or_error(idx):
    srv = get_srv(idx)
    if not srv or srv.get('type') == 'invalid':
        notify(L(30200))
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return None
    return srv


def mk_li(label, thumb='', fanart='', playable=False):
    li = xbmcgui.ListItem(label)
    t = thumb or ICON
    art = {'thumb': t, 'icon': t}
    if fanart:
        art['fanart'] = fanart
    li.setArt(art)
    if playable:
        li.setProperty('IsPlayable', 'true')
    return li


def _fanart_for(logo):
    if logo and logo != ICON and common.device_profile()['fanart']:
        return logo
    return ''


def end_dir(content='videos', ok=True):
    xbmcplugin.setContent(HANDLE, content)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(HANDLE, succeeded=ok, cacheToDisc=False)


def add_all(entries):
    if entries:
        xbmcplugin.addDirectoryItems(HANDLE, entries, len(entries))


def _page_size():
    i = setting_int('page_size', 0)
    if i == 5:
        return 0
    if i in (1, 2, 3, 4):
        return (100, 250, 500, 1000)[i - 1]
    return common.device_profile()['page']


def paginate(total, params, page):
    """(start, end, 'next page' entry or None)."""
    size = _page_size()
    if not size or total <= int(size * 1.2):
        return 0, total, None
    start = max(0, page) * size
    f = min(total, start + size)
    nxt = None
    if f < total:
        p = dict(params)
        p['page'] = str(page + 1)
        li = mk_li(L(30239).format(page + 2, int(math.ceil(total / float(size)))))
        nxt = (url_for(p), li, True)
    return start, f, nxt


def cm_fav(name, url='', logo='', media_type='video', **kw):
    p = {'action': 'fav_add', 'fav_name': name, 'fav_url': url, 'fav_logo': logo, 'fav_type': media_type}
    p.update(dict((k, v) for k, v in kw.items() if v))
    return (L(30240), 'RunPlugin({})'.format(url_for(p)))


def cm_diag(name, url, ua='', ref=''):
    p = {'action': 'diagnostic', 'url': url, 'name': name}
    if ua:
        p['ua'] = ua
    if ref:
        p['ref'] = ref
    return (L(30320), 'RunPlugin({})'.format(url_for(p)))


def action_diagnostic(p):
    import diagnostic
    import proxy
    url = p.get('url', '')
    if not url.startswith('http'):
        return
    hdr = {}
    if p.get('ua'):
        hdr['User-Agent'] = p['ua']
    if p.get('ref'):
        hdr['Referer'] = p['ref']
    proxy.stop_remote()                       # release the proxy connection (single-connection accounts)
    seconds = 20
    dp = xbmcgui.DialogProgress()
    dp.create(L(30336), L(30322))
    try:
        def _prog(sec):
            dp.update(min(99, int(sec * 100 / seconds)), L(30323).format(sec))
        r = diagnostic.measure(url, hdr or None, seconds, _prog, dp.iscanceled)
    finally:
        dp.close()
    xbmcgui.Dialog().textviewer('{} — {}'.format(L(30336), p.get('name', '')),
                                diagnostic.report(r, seconds))


def _num(v, default=0.0):
    try:
        return float(v)
    except Exception:
        return default


def _year(v):
    try:
        return int(str(v)[:4])
    except Exception:
        return 0


# ════════════════════════════════════════════════════════
#  Main menu / types
# ════════════════════════════════════════════════════════

def _server_label(srv, info):
    """'Name  | Connections 0/1' (green = free, red = full)."""
    name = srv['name']
    if not info:
        return name
    if info['status'] and info['status'].lower() not in ('active', 'ativo', 'activo'):
        return '{}  [COLOR red]| {}[/COLOR]'.format(name, L(30291))
    if info['max'] <= 0:
        return name
    color = 'red' if info['active'] >= info['max'] else 'green'
    return '{}  [COLOR {}]| {} {}/{}[/COLOR]'.format(name, color, L(30290), info['active'], info['max'])


def show_main():
    srvs = servers()
    xbmcplugin.setPluginCategory(HANDLE, 'OnTV')
    if not srvs:
        notify(L(30201))
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    ent = []
    infos = {}
    try:
        infos = api.conn_infos(srvs, budget=3.0)          # connections in use (Xtream), in parallel
    except Exception as e:
        log('conn_infos: ' + str(e))
    for i, srv in enumerate(srvs):
        li = mk_li(_server_label(srv, infos.get(i)), srv.get('icon'), FANART)
        ent.append((url_for({'action': 'types', 'srv_idx': str(i)}), li, True))
    import favourites
    ent.append((url_for({'action': 'favourites'}),
                mk_li(L(30202).format(favourites.count()), ICON, FANART), True))
    ent.append((url_for({'action': 'recents'}), mk_li(L(30203), ICON, FANART), True))
    ent.append((url_for({'action': 'tools'}), mk_li(L(30204), ICON, FANART), True))
    add_all(ent)
    xbmcplugin.setContent(HANDLE, 'videos')
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(HANDLE)


def show_types(srv_idx):
    srv = _srv_or_error(srv_idx)
    if not srv:
        return
    xbmcplugin.setPluginCategory(HANDLE, srv['name'])
    if srv['type'] == 'm3u':
        show_m3u_root(srv_idx)
        return
    ent = []
    for name, action in ((L(30205), 'live_cats'), (L(30206), 'vod_cats'),
                         (L(30207), 'series_cats'), (L(30208), 'search')):
        ent.append((url_for({'action': action, 'srv_idx': srv_idx}), mk_li(name, ICON, FANART), True))
    if srv['type'] == 'xtream':
        ent.append((url_for({'action': 'account', 'srv_idx': srv_idx}),
                    mk_li(L(30209), ICON, FANART), False))
    add_all(ent)
    end_dir()


# Account status as sent by the panel -> English for display (some panels answer in Portuguese)
_STATUS_EN = {'ativo': 'Active', 'activo': 'Active', 'inativo': 'Inactive', 'inactivo': 'Inactive',
              'expirado': 'Expired', 'banido': 'Banned', 'bloqueado': 'Blocked',
              'desativado': 'Disabled', 'desactivado': 'Disabled'}


def _status_en(value):
    s = str(value)
    return _STATUS_EN.get(s.strip().lower(), s)


def show_account(srv_idx):
    srv = get_srv(srv_idx)
    if not srv or srv['type'] != 'xtream':
        return
    t0 = time.time()
    info = api.xt_account_info(srv)
    ms = int((time.time() - t0) * 1000)
    if not info or not isinstance(info, dict) or 'user_info' not in info:
        xbmcgui.Dialog().ok(ADDON_NAME, L(30210))
        return
    u = info.get('user_info', {})
    s = info.get('server_info', {})

    def _date(v):
        try:
            return time.strftime('%d/%m/%Y', time.localtime(int(v))) if v else L(30221)
        except Exception:
            return str(v)

    lines = [
        L(30211).format(_status_en(u.get('status', '?'))),
        L(30212).format(_date(u.get('exp_date'))),
        L(30213).format(u.get('active_cons', '?'), u.get('max_connections', '?')),
        L(30214).format(L(30215) if str(u.get('is_trial', '0')) == '1' else L(30216)),
        L(30217).format(', '.join(u.get('allowed_output_formats', []) or []) or '-'),
        '',
        L(30219).format(s.get('timezone', '-')),
        L(30220).format(ms),
    ]
    xbmcgui.Dialog().textviewer(srv['name'], '\n'.join(lines))


# ════════════════════════════════════════════════════════
#  Categories
# ════════════════════════════════════════════════════════

_XT_CAT = {'live_cats': ('get_live_categories', 'live_list'),
           'vod_cats': ('get_vod_categories', 'vod_list'),
           'series_cats': ('get_series_categories', 'series_list')}
_ST_TYPE = {'live_cats': ('itv', 'stalker_live'), 'vod_cats': ('vod', 'stalker_vod'),
            'series_cats': ('series', 'stalker_series')}


def show_categories(srv_idx, cat_type):
    srv = _srv_or_error(srv_idx)
    if not srv:
        return
    xbmcplugin.setPluginCategory(HANDLE, srv['name'])
    ent = []
    if srv['type'] == 'stalker':
        st_type, action = _ST_TYPE[cat_type]
        cats = api.stalker_categories(srv['host'], srv['mac'], st_type)
        if not cats:
            notify(L(30222))
            end_dir(ok=False)
            return
        cats = [c for c in cats if not is_adult(c.get('title', c.get('name', '')))]
        cats = sorted(cats, key=lambda c: region_priority(c.get('title', c.get('name', ''))))
        for cat in cats:
            name = cat.get('title', cat.get('name', L(30283)))
            if not name or name == '0':
                continue
            cid = str(cat.get('id', cat.get('genre_id', '*')))
            ent.append((url_for({'action': action, 'srv_idx': srv_idx, 'cat_id': cid, 'cat_name': name}),
                        mk_li(name), True))
    else:
        xt_action, action = _XT_CAT[cat_type]
        data = api.xt_call(srv, xt_action, ttl=_ttl('api'))
        if not data or not isinstance(data, list):
            notify(L(30223))
            end_dir(ok=False)
            return
        data = filter_adult(data, 'category_name')
        data = sorted(data, key=lambda c: region_priority(c.get('category_name', '')))
        for cat in data:
            name = cat.get('category_name', L(30283))
            ent.append((url_for({'action': action, 'srv_idx': srv_idx,
                                  'cat_id': str(cat.get('category_id', '')), 'cat_name': name}),
                        mk_li(name), True))
    add_all(ent)
    end_dir()


# ════════════════════════════════════════════════════════
#  Xtream — item builders
# ════════════════════════════════════════════════════════

def _item_live(srv, ch, epg=None):
    name = ch.get('name', L(30286))
    sid = str(ch.get('stream_id', ''))
    logo = (ch.get('stream_icon', '') or '').replace(' ', '%20')
    ext = ch.get('container_extension', '') or 'ts'
    surl = api.xt_stream_url(srv, 'live', sid, ext)
    label, plot, tagline = name, '', ''
    if epg:
        hours, tit = epg['hours'], epg['title']
        label = '{} — {} {}'.format(name, hours, tit).replace('  ', ' ') if hours else '{} — {}'.format(name, tit)
        tagline = '{} {}'.format(hours, tit).strip()
        plot = '[B]{}[/B]  {}'.format(hours, tit) if hours else '[B]{}[/B]'.format(tit)
        if epg.get('description'):
            plot += '\n' + epg['description']
        if epg.get('next_title'):
            plot += '\n\n' + L(30232).format(epg['next_title'])
    li = mk_li(label, logo, _fanart_for(logo), True)
    set_video_info(li, title=name, plot=plot, tagline=tagline)
    cms = [cm_fav(name, surl, logo, 'video', k='live'), cm_diag(name, surl)]
    if str(ch.get('tv_archive', '0')) == '1':
        cms.append((L(30233), 'Container.Update({})'.format(
            url_for({'action': 'catchup', 'srv_idx': srv['_idx'], 'stream_id': sid, 'name': name}))))
    li.addContextMenuItems(cms)
    return (url_for({'action': 'play', 'url': surl, 'name': name, 'logo': logo, 'k': 'live'}), li, False)


def _item_vod(srv, it):
    name = it.get('name', L(30285))
    sid = str(it.get('stream_id', ''))
    logo = (it.get('stream_icon', '') or '').replace(' ', '%20')
    ext = it.get('container_extension', '') or 'mp4'
    surl = api.xt_stream_url(srv, 'movie', sid, ext)
    li = mk_li(name, logo, '', True)
    r = _num(it.get('rating'))
    set_video_info(li, title=name, mediatype='movie', rating=r if r <= 10 else 0)
    li.addContextMenuItems([cm_fav(name, surl, logo, 'movie', k='vod')])
    return (url_for({'action': 'play', 'url': surl, 'name': name, 'logo': logo, 'k': 'vod'}), li, False)


def _item_series(srv_idx, s):
    name = s.get('name', L(30284))
    sid = str(s.get('series_id', ''))
    logo = s.get('cover', '') or ''
    back = s.get('backdrop_path')
    fan = back[0] if isinstance(back, list) and back else (logo if common.device_profile()['fanart'] else '')
    li = mk_li(name, logo, fan)
    r = _num(s.get('rating'))
    set_video_info(li, title=name, mediatype='tvshow', plot=s.get('plot', '') or '',
                   year=_year(s.get('releaseDate') or s.get('release_date')),
                   rating=r if r <= 10 else 0, genre=s.get('genre', '') or '',
                   director=s.get('director', '') or '')
    li.addContextMenuItems([cm_fav(name, '', logo, 'tvshow', srv_idx=srv_idx, series_id=sid)])
    return (url_for({'action': 'series_seasons', 'srv_idx': srv_idx, 'series_id': sid, 'series_name': name}), li, True)


def _with_idx(srv, idx):
    srv = dict(srv)
    srv['_idx'] = str(idx)
    return srv


# ════════════════════════════════════════════════════════
#  Xtream — lists
# ════════════════════════════════════════════════════════

def show_live(srv_idx, cat_id, cat_name, page=0):
    srv = _srv_or_error(srv_idx)
    if not srv:
        return
    srv = _with_idx(srv, srv_idx)
    data = api.xt_call(srv, 'get_live_streams', ttl=_ttl('api'), category_id=cat_id)
    if not data or not isinstance(data, list):
        notify(L(30224))
        end_dir(ok=False)
        return
    data = [c for c in data if not is_adult(c.get('name', '')) and int(c.get('stream_id', 0) or 0) > 0]
    params = {'action': 'live_list', 'srv_idx': srv_idx, 'cat_id': cat_id, 'cat_name': cat_name}
    start, f, nxt = paginate(len(data), params, page)
    vis = data[start:f]

    epg = {}
    prof = common.device_profile()
    max_epg = setting_int('epg_max', 0)
    if max_epg <= 0:
        max_epg = prof['epg_max']
    if setting_bool('epg_lists', True):
        epg = api.xt_epg_bulk(srv, [str(c.get('stream_id')) for c in vis], max_items=max_epg,
                              budget=8.0, workers=prof['workers'])

    xbmcplugin.setPluginCategory(HANDLE, cat_name)
    ent = [_item_live(srv, c, epg.get(str(c.get('stream_id')))) for c in vis]
    if nxt:
        ent.append(nxt)
    add_all(ent)
    end_dir()


def show_vod(srv_idx, cat_id, cat_name, page=0):
    srv = _srv_or_error(srv_idx)
    if not srv:
        return
    data = api.xt_call(srv, 'get_vod_streams', ttl=_ttl('api'), category_id=cat_id)
    if not data or not isinstance(data, list):
        notify(L(30225))
        end_dir(ok=False)
        return
    data = [i for i in data if not is_adult(i.get('name', '')) and int(i.get('stream_id', 0) or 0) > 0]
    params = {'action': 'vod_list', 'srv_idx': srv_idx, 'cat_id': cat_id, 'cat_name': cat_name}
    start, f, nxt = paginate(len(data), params, page)
    xbmcplugin.setPluginCategory(HANDLE, cat_name)
    ent = [_item_vod(srv, i) for i in data[start:f]]
    if nxt:
        ent.append(nxt)
    add_all(ent)
    end_dir('movies')


def show_series(srv_idx, cat_id, cat_name, page=0):
    srv = _srv_or_error(srv_idx)
    if not srv:
        return
    data = api.xt_call(srv, 'get_series', ttl=_ttl('api'), category_id=cat_id)
    if not data or not isinstance(data, list):
        notify(L(30226))
        end_dir(ok=False)
        return
    params = {'action': 'series_list', 'srv_idx': srv_idx, 'cat_id': cat_id, 'cat_name': cat_name}
    start, f, nxt = paginate(len(data), params, page)
    xbmcplugin.setPluginCategory(HANDLE, cat_name)
    ent = [_item_series(srv_idx, s) for s in data[start:f]]
    if nxt:
        ent.append(nxt)
    add_all(ent)
    end_dir('tvshows')


def _ep_key(x):
    return int(x) if str(x).isdigit() else 0


def show_seasons(srv_idx, series_id, series_name):
    srv = _srv_or_error(srv_idx)
    if not srv:
        return
    data = api.xt_call(srv, 'get_series_info', ttl=_ttl('api'), series_id=series_id)
    if not data or not isinstance(data, dict):
        notify(L(30226))
        end_dir(ok=False)
        return
    episodes = data.get('episodes', {})
    if isinstance(episodes, list):                          # some panels return a list
        episodes = dict((str(i + 1), v) for i, v in enumerate(episodes))
    seasons = sorted(episodes.keys(), key=_ep_key)
    if len(seasons) == 1:
        _episodes(srv, srv_idx, series_name, seasons[0], data)
        return
    info = data.get('info', {})
    cover = info.get('cover', '') or ICON
    xbmcplugin.setPluginCategory(HANDLE, series_name)
    ent = []
    for sn in seasons:
        label = L(30229).format(_ep_key(sn), len(episodes[sn]))
        li = mk_li(label, cover, cover if common.device_profile()['fanart'] else '')
        set_video_info(li, title=label, mediatype='season', season=_ep_key(sn), showtitle=series_name)
        ent.append((url_for({'action': 'series_eps', 'srv_idx': srv_idx, 'series_id': series_id,
                              'series_name': series_name, 'season': str(sn)}), li, True))
    add_all(ent)
    end_dir('seasons')


def show_episodes(srv_idx, series_id, series_name, season=None):
    srv = _srv_or_error(srv_idx)
    if not srv:
        return
    data = api.xt_call(srv, 'get_series_info', ttl=_ttl('api'), series_id=series_id)
    if not data or not isinstance(data, dict):
        notify(L(30228))
        end_dir(ok=False)
        return
    _episodes(srv, srv_idx, series_name, season, data)


def _episodes(srv, srv_idx, series_name, season, data):
    episodes = data.get('episodes', {})
    if isinstance(episodes, list):
        episodes = dict((str(i + 1), v) for i, v in enumerate(episodes))
    seasons = [str(season)] if season is not None else sorted(episodes.keys(), key=_ep_key)
    title = series_name + (' — S{:02d}'.format(_ep_key(season)) if season is not None else '')
    xbmcplugin.setPluginCategory(HANDLE, title)
    ent = []
    for sn in seasons:
        for ep in episodes.get(sn, []):
            num = ep.get('episode_num', '')
            name = 'S{}E{} — {}'.format(str(sn).zfill(2), str(num).zfill(2), ep.get('title', L(30230)))
            info = ep.get('info', {}) or {}
            logo = info.get('movie_image', '') or ''
            surl = api.xt_stream_url(srv, 'series', str(ep.get('id', '')), ep.get('container_extension', '') or 'mp4')
            li = mk_li(name, logo, '', True)
            r = _num(info.get('rating'))
            set_video_info(li, title=name, mediatype='episode', plot=info.get('plot', '') or '',
                           season=_ep_key(sn), episode=_ep_key(num), showtitle=series_name,
                           duration=int(_num(info.get('duration_secs'))), rating=r if r <= 10 else 0)
            li.addContextMenuItems([cm_fav(name, surl, logo, 'video', k='vod')])
            ent.append((url_for({'action': 'play', 'url': surl, 'name': name, 'logo': logo, 'k': 'vod'}), li, False))
    add_all(ent)
    end_dir('episodes')


def show_catchup(srv_idx, stream_id, name):
    srv = _srv_or_error(srv_idx)
    if not srv:
        return
    lst = api.xt_catchup_listings(srv, stream_id)
    xbmcplugin.setPluginCategory(HANDLE, L(30236) + name)
    if not lst:
        notify(L(30234), xbmcgui.NOTIFICATION_INFO)
        end_dir(ok=False)
        return
    ent = []
    for p in lst:
        when = time.strftime('%d/%m %H:%M', time.localtime(p['start_ts']))
        label = '{}  {}'.format(when, p['title'])
        url = api.xt_catchup_url(srv, stream_id, p['start'], p['start_ts'], p['end_ts'])
        li = mk_li(label, '', '', True)
        set_video_info(li, title=p['title'], plot=p['description'], duration=p['end_ts'] - p['start_ts'])
        ent.append((url_for({'action': 'play', 'url': url, 'name': p['title'], 'k': 'vod'}), li, False))
    add_all(ent)
    end_dir()


# ════════════════════════════════════════════════════════
#  Stalker / MAG
# ════════════════════════════════════════════════════════

def show_stalker_items(srv_idx, st_type, cat_id, cat_name, page=0):
    srv = _srv_or_error(srv_idx)
    if not srv:
        return
    bg = [None]

    def _prog(i, n):
        if bg[0] is None:
            bg[0] = xbmcgui.DialogProgressBG()
            bg[0].create(ADDON_NAME, L(30237))
        bg[0].update(int(i * 100 / max(n, 1)), ADDON_NAME, '{} / {}'.format(i, n))

    try:
        raw_items = api.stalker_channels(srv['host'], srv['mac'], st_type, cat_id, progress=_prog)
    finally:
        if bg[0]:
            bg[0].close()
    if not raw_items:
        notify(L(30238))
        end_dir(ok=False)
        return

    items = []
    for it in raw_items:
        name = it.get('name', '') or it.get('o_name', '')
        if not name or is_adult(name):
            continue
        cmd = (it.get('cmd') or '').strip()
        eps = it.get('series')
        if st_type == 'itv':
            if not cmd or 'http' not in cmd.lower():       # separators
                continue
        elif not cmd and not eps:
            continue
        items.append(it)

    params = {'action': {'itv': 'stalker_live', 'vod': 'stalker_vod', 'series': 'stalker_series'}[st_type],
              'srv_idx': srv_idx, 'cat_id': cat_id, 'cat_name': cat_name}
    start, f, nxt = paginate(len(items), params, page)
    xbmcplugin.setPluginCategory(HANDLE, cat_name)
    ent = []
    for it in items[start:f]:
        name = it.get('name', '') or it.get('o_name', '')
        cmd = (it.get('cmd') or '').strip()
        logo = api.stalker_abs(srv['host'], it.get('logo') or it.get('screenshot_uri') or '')
        eps = it.get('series')
        plot = it.get('description', '') or ''
        if isinstance(eps, list) and eps:
            li = mk_li(name, logo, '')
            set_video_info(li, title=name, mediatype='tvshow', plot=plot, year=_year(it.get('year')),
                           genre=it.get('genres_str', '') or '')
            ent.append((url_for({'action': 'stalker_eps', 'srv_idx': srv_idx, 'stalker_type': 'vod',
                                  'cmd': cmd, 'name': name, 'logo': logo,
                                  'eps': ','.join(str(e) for e in eps)}), li, True))
            continue
        li = mk_li(name, logo, _fanart_for(logo) if st_type == 'itv' else '', True)
        set_video_info(li, title=name, plot=plot, mediatype='video' if st_type == 'itv' else 'movie',
                       year=_year(it.get('year')), genre=it.get('genres_str', '') or '')
        kind = 'live' if st_type == 'itv' else 'vod'
        li.addContextMenuItems([cm_fav(name, '', logo, 'video', srv_idx=srv_idx, cmd=cmd,
                                       stalker_type=st_type, k=kind)])
        ent.append((url_for({'action': 'stalker_play', 'srv_idx': srv_idx, 'stalker_type': st_type,
                              'cmd': cmd, 'name': name, 'logo': logo}), li, False))
    if nxt:
        ent.append(nxt)
    add_all(ent)
    end_dir('videos' if st_type == 'itv' else 'movies')


def show_stalker_episodes(srv_idx, st_type, cmd, name, logo, eps):
    xbmcplugin.setPluginCategory(HANDLE, name)
    ent = []
    for n in [e for e in eps.split(',') if e]:
        label = L(30231).format(name, n)
        li = mk_li(label, logo, '', True)
        set_video_info(li, title=label, mediatype='episode', episode=_ep_key(n), showtitle=name)
        ent.append((url_for({'action': 'stalker_play', 'srv_idx': srv_idx, 'stalker_type': st_type,
                              'cmd': cmd, 'name': label, 'logo': logo, 'series': n}), li, False))
    add_all(ent)
    end_dir('episodes')


# ════════════════════════════════════════════════════════
#  M3U / M3U_plus
# ════════════════════════════════════════════════════════

_KIND_LABEL = {'l': 30205, 'm': 30206, 's': 30207}


def _m3u_store(srv, force=False):
    """Playlist index (downloads/indexes if needed). None on error."""
    st = api.M3UStore(srv['url'])
    if not force and st.is_fresh(_ttl('m3u')):
        return st
    dp = xbmcgui.DialogProgress()
    dp.create(ADDON_NAME, L(30241))

    def _cb(total):
        mb = total / 1048576.0
        dp.update(min(90, int(mb * 4)), L(30242).format(mb))
        if dp.iscanceled():
            raise IOError('cancelled')

    try:
        st.build(_cb)
        dp.update(100, L(30243))
        return st
    except Exception as e:
        log('M3U error: ' + str(e), xbmc.LOGWARNING)
        if st.meta().get('groups') and os.path.exists(st.data_path):
            notify(L(30244), xbmcgui.NOTIFICATION_WARNING)
            return st
        notify(L(30245))
        return None
    finally:
        dp.close()


def show_m3u_root(srv_idx, force=False):
    srv = _srv_or_error(srv_idx)
    if not srv:
        return
    st = _m3u_store(srv, force)
    if not st:
        end_dir(ok=False)
        return
    kinds = st.kinds()
    if len(kinds) > 1:
        ent = []
        for k in ('l', 'm', 's'):
            if k in kinds:
                ent.append((url_for({'action': 'm3u_groups', 'srv_idx': srv_idx, 'kind': k}),
                            mk_li(L(_KIND_LABEL[k]), ICON, FANART), True))
        ent.append((url_for({'action': 'search', 'srv_idx': srv_idx}), mk_li(L(30208), ICON, FANART), True))
        ent.append((url_for({'action': 'm3u_refresh', 'srv_idx': srv_idx}), mk_li(L(30246), ICON, FANART), True))
        add_all(ent)
        end_dir()
    else:
        _list_groups(srv_idx, st, kinds[0] if kinds else 'l', extras=True)


def show_m3u_groups(srv_idx, kind='l'):
    srv = _srv_or_error(srv_idx)
    if not srv:
        return
    st = _m3u_store(srv)
    if not st:
        end_dir(ok=False)
        return
    _list_groups(srv_idx, st, kind)


def _list_groups(srv_idx, st, kind, extras=False):
    groups = sorted(st.groups(kind), key=lambda g: region_priority(g['n']))
    ent = []
    for g in groups:
        li = mk_li(g['n'], g.get('l') or ICON, '')
        ent.append((url_for({'action': 'm3u_channels', 'srv_idx': srv_idx, 'group': g['n'], 'kind': g['k']}), li, True))
    if extras:
        ent.append((url_for({'action': 'search', 'srv_idx': srv_idx}), mk_li(L(30208), ICON, FANART), True))
        ent.append((url_for({'action': 'm3u_refresh', 'srv_idx': srv_idx}), mk_li(L(30246), ICON, FANART), True))
    add_all(ent)
    end_dir()


def _item_m3u(e):
    logo = e.get('l') or ''
    kind = 'live' if e.get('k', 'l') == 'l' else 'vod'
    li = mk_li(e['n'], logo, _fanart_for(logo) if kind == 'live' else '', True)
    set_video_info(li, title=e['n'], mediatype='video' if kind == 'live' else 'movie')
    cms = [cm_fav(e['n'], e['u'], logo, 'video', k=kind, ua=e.get('ua', ''), ref=e.get('ref', ''))]
    if kind == 'live':
        cms.append(cm_diag(e['n'], e['u'], e.get('ua', ''), e.get('ref', '')))
    li.addContextMenuItems(cms)
    p = {'action': 'play', 'url': e['u'], 'name': e['n'], 'logo': logo, 'k': kind}
    if e.get('ua'):
        p['ua'] = e['ua']
    if e.get('ref'):
        p['ref'] = e['ref']
    return (url_for(p), li, False)


def show_m3u_channels(srv_idx, group, kind='l', page=0):
    srv = _srv_or_error(srv_idx)
    if not srv:
        return
    st = _m3u_store(srv)
    if not st:
        end_dir(ok=False)
        return
    ents = list(st.entries(kind, group))
    params = {'action': 'm3u_channels', 'srv_idx': srv_idx, 'group': group, 'kind': kind}
    start, f, nxt = paginate(len(ents), params, page)
    xbmcplugin.setPluginCategory(HANDLE, group)
    ent = [_item_m3u(e) for e in ents[start:f]]
    if nxt:
        ent.append(nxt)
    add_all(ent)
    end_dir('videos' if kind == 'l' else 'movies')


def m3u_refresh(srv_idx):
    show_m3u_root(srv_idx, force=True)


# ════════════════════════════════════════════════════════
#  Search
# ════════════════════════════════════════════════════════

def search(srv_idx, q=None, page=0):
    srv = _srv_or_error(srv_idx)
    if not srv:
        return
    if not q:
        kb = xbmc.Keyboard('', L(30247).format(srv['name']))
        kb.doModal()
        if not kb.isConfirmed() or not kb.getText().strip():
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            return
        q = kb.getText().strip()
    term = q.lower()

    dp = xbmcgui.DialogProgress()
    dp.create(ADDON_NAME, L(30248).format(q))
    items = []                                  # entries (url, li, folder)
    try:
        if srv['type'] == 'xtream':
            srv = _with_idx(srv, srv_idx)
            dp.update(20, L(30249))
            for ch in api.xt_call(srv, 'get_live_streams', ttl=_ttl('api')) or []:
                n = ch.get('name', '')
                if term in n.lower() and not is_adult(n) and int(ch.get('stream_id', 0) or 0) > 0:
                    items.append(_item_live(srv, ch))
            dp.update(50, L(30250))
            for it in api.xt_call(srv, 'get_vod_streams', ttl=_ttl('api')) or []:
                n = it.get('name', '')
                if term in n.lower() and not is_adult(n) and int(it.get('stream_id', 0) or 0) > 0:
                    items.append(_item_vod(srv, it))
            dp.update(80, L(30251))
            for s in api.xt_call(srv, 'get_series', ttl=_ttl('api')) or []:
                if term in s.get('name', '').lower():
                    items.append(_item_series(srv_idx, s))
        elif srv['type'] == 'stalker':
            for st_type, pct, lab in (('itv', 20, L(30249)), ('vod', 55, L(30250))):
                dp.update(pct, lab)
                found = api.stalker_channels(srv['host'], srv['mac'], st_type, '*', search=q) or []
                if not found:
                    found = [c for c in api.stalker_channels(srv['host'], srv['mac'], st_type, '*')
                             if term in c.get('name', '').lower()]
                for it in found:
                    name = it.get('name', '')
                    cmd = (it.get('cmd') or '').strip()
                    if not name or term not in name.lower() or is_adult(name) or not cmd:
                        continue
                    if st_type == 'itv' and 'http' not in cmd.lower():
                        continue
                    logo = api.stalker_abs(srv['host'], it.get('logo') or it.get('screenshot_uri') or '')
                    eps = it.get('series')
                    if isinstance(eps, list) and eps:
                        li = mk_li(name, logo, '')
                        items.append((url_for({'action': 'stalker_eps', 'srv_idx': srv_idx, 'stalker_type': 'vod',
                                                'cmd': cmd, 'name': name, 'logo': logo,
                                                'eps': ','.join(str(e) for e in eps)}), li, True))
                        continue
                    li = mk_li(name, logo, '', True)
                    set_video_info(li, title=name)
                    items.append((url_for({'action': 'stalker_play', 'srv_idx': srv_idx, 'stalker_type': st_type,
                                            'cmd': cmd, 'name': name, 'logo': logo}), li, False))
        else:
            dp.update(40, L(30252))
            st = _m3u_store(srv)
            if st:
                for e in st.search(term):
                    items.append(_item_m3u(e))
    finally:
        dp.close()

    if not items:
        notify(L(30253).format(q), xbmcgui.NOTIFICATION_INFO)
        end_dir(ok=False)
        return
    params = {'action': 'search', 'srv_idx': srv_idx, 'q': q}
    start, f, nxt = paginate(len(items), params, page)
    xbmcplugin.setPluginCategory(HANDLE, L(30254).format(q))
    ent = items[start:f]
    if nxt:
        ent.append(nxt)
    add_all(ent)
    end_dir()


# ════════════════════════════════════════════════════════
#  Playback
# ════════════════════════════════════════════════════════

def _add_recent(name, logo, play_params):
    try:
        import favourites
        import hashlib
        key = play_params.get('url') or (play_params.get('cmd', '') + play_params.get('series', ''))
        favourites.hist_add({'id': hashlib.md5((name + key).encode('utf-8')).hexdigest()[:12],
                             'name': name, 'logo': logo, 'play': play_params})
    except Exception as e:
        log('recents: ' + str(e))


def _resolve(url, name, logo, kind, headers=None, stalker=None, rec=None):
    import playback
    try:
        path, li, engine = playback.build(url, name, logo, kind=kind, headers=headers, stalker=stalker)
    except Exception as e:
        log('playback.build: ' + str(e), xbmc.LOGWARNING)
        notify(L(30256))
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    try:                                        # for the service's automatic fallback
        xbmcgui.Window(10000).setProperty(PROP_LAST, json.dumps(
            {'url': url, 'name': name, 'logo': logo, 'kind': kind, 'engine': engine, 'h': headers or {}}))
    except Exception:
        pass
    if rec:
        _add_recent(name, logo, rec)
    xbmcplugin.setResolvedUrl(HANDLE, True, li)


def play(params):
    url = params.get('url', '')
    if not url:
        notify(L(30255))
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    import playback
    kind = params.get('k') or playback.guess_kind(url.split('|')[0])
    hdr = {}
    if params.get('ua'):
        hdr['User-Agent'] = params['ua']
    if params.get('ref'):
        hdr['Referer'] = params['ref']
    name, logo = params.get('name', ''), params.get('logo', '')
    rec = dict((k, v) for k, v in params.items() if k in ('action', 'url', 'name', 'logo', 'k', 'ua', 'ref'))
    _resolve(url, name, logo, kind, hdr or None, None, rec)


def play_stalker(srv_idx, st_type, cmd, name='', logo='', series=''):
    srv = get_srv(srv_idx)
    if not srv:
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    url = api.stalker_create_link(srv['host'], srv['mac'], st_type, cmd, series)
    if not url:
        notify(L(30257))
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    kind = 'live' if st_type == 'itv' else 'vod'
    renew = {'host': srv['host'], 'mac': srv['mac'], 't': st_type, 'cmd': cmd, 's': series}
    rec = {'action': 'stalker_play', 'srv_idx': srv_idx, 'stalker_type': st_type, 'cmd': cmd,
           'name': name, 'logo': logo}
    if series:
        rec['series'] = series
    _resolve(url, name, logo, kind, None, renew, rec)


# ════════════════════════════════════════════════════════
#  Favourites / Recents
# ════════════════════════════════════════════════════════

def show_favourites():
    import favourites
    favs = favourites.list_all()
    xbmcplugin.setPluginCategory(HANDLE, L(30202).format(len(favs)))
    if not favs:
        notify(L(30258), xbmcgui.NOTIFICATION_INFO)
        end_dir(ok=False)
        return
    ent = []
    for fav in favs:
        name = fav.get('name', L(30260))
        logo = fav.get('logo', '') or ''
        media_type = fav.get('type', 'video')
        kind = fav.get('k') or ''
        cm = [(L(30259), 'RunPlugin({})'.format(
            url_for({'action': 'fav_remove', 'fav_id': fav.get('id', '')})))]
        if media_type == 'tvshow':
            li = mk_li(name, logo, '')
            set_video_info(li, title=name, mediatype='tvshow')
            li.addContextMenuItems(cm)
            ent.append((url_for({'action': 'series_seasons', 'srv_idx': fav.get('srv_idx', '0'),
                                  'series_id': fav.get('series_id', ''), 'series_name': name}), li, True))
        elif fav.get('cmd'):
            li = mk_li(name, logo, '', True)
            set_video_info(li, title=name)
            li.addContextMenuItems(cm)
            ent.append((url_for({'action': 'stalker_play', 'srv_idx': fav.get('srv_idx', '0'),
                                  'stalker_type': fav.get('stalker_type', 'itv'), 'cmd': fav['cmd'],
                                  'name': name, 'logo': logo}), li, False))
        else:
            li = mk_li(name, logo, '', True)
            set_video_info(li, title=name, mediatype='movie' if media_type == 'movie' else 'video')
            li.addContextMenuItems(cm)
            p = {'action': 'play', 'url': fav.get('url', ''), 'name': name, 'logo': logo}
            if kind:
                p['k'] = kind
            if fav.get('ua'):
                p['ua'] = fav['ua']
            if fav.get('ref'):
                p['ref'] = fav['ref']
            ent.append((url_for(p), li, False))
    add_all(ent)
    end_dir()


def show_recents():
    import favourites
    hist = favourites.hist_list()
    xbmcplugin.setPluginCategory(HANDLE, L(30203))
    if not hist:
        notify(L(30264), xbmcgui.NOTIFICATION_INFO)
        end_dir(ok=False)
        return
    ent = [(url_for({'action': 'recents_clear'}), mk_li(L(30265), ICON, ''), False)]
    for h in hist:
        li = mk_li(h.get('name', ''), h.get('logo', ''), '', True)
        set_video_info(li, title=h.get('name', ''))
        ent.append((url_for(h.get('play', {})), li, False))
    add_all(ent)
    end_dir()


def action_fav_add(p):
    import favourites
    extras = dict((k, p.get(k, '')) for k in ('srv_idx', 'series_id', 'cmd', 'stalker_type', 'k', 'ua', 'ref'))
    ok = favourites.add(p.get('fav_name', ''), p.get('fav_url', ''), p.get('fav_logo', ''),
                              p.get('fav_type', 'video'), **extras)
    notify(L(30261) if ok else L(30262), xbmcgui.NOTIFICATION_INFO)


def action_fav_remove(fid):
    import favourites
    favourites.remove(fid)
    notify(L(30263), xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin('Container.Refresh')


# ════════════════════════════════════════════════════════
#  DNS / Tools
# ════════════════════════════════════════════════════════

def _dns():
    try:
        import dns_override
        return dns_override
    except Exception:
        return None


def action_dns(provider):
    dns = _dns()
    if dns is None:
        notify(L(30266))
        return
    if provider == 'system':
        dns.deactivate()
        notify(L(30267), xbmcgui.NOTIFICATION_INFO)
    else:
        dns.activate(provider)
        notify(L(30268).format(provider.upper()), xbmcgui.NOTIFICATION_INFO)
    try:
        common.atomic_write(os.path.join(common.profile_dir(), 'ontv_dns_provider.txt'), provider)
    except Exception:
        pass
    xbmc.executebuiltin('Container.Refresh')


def show_dns_chooser():
    dns = _dns()
    current = dns.current_provider() if dns else 'system'
    xbmcplugin.setPluginCategory(HANDLE, L(30269))
    labels = [('system', L(30270)), ('adguard', L(30271)), ('cloudflare', L(30272)),
              ('opendns', L(30273)), ('google', L(30274))]
    ent = []
    for key, label in labels:
        li = mk_li(('✅  ' if key == current else '   ') + label, ICON, '')
        ent.append((url_for({'action': 'dns_set', 'dns_provider': key}), li, False))
    add_all(ent)
    end_dir()


def show_tools():
    dns = _dns()
    active = dns.current_provider() if dns else 'system'
    import favourites
    xbmcplugin.setPluginCategory(HANDLE, L(30204))
    entries = [
        (L(30275), 'settings', False),
        (L(30276).format(active.upper()), 'dns_choose', True),
        (L(30277), 'speed_test', False),
        (L(30278), 'clear_cache', False),
        (L(30279), 'clear_dns_cache', False),
        (L(30202).format(favourites.count()), 'favourites', True),
        (L(30203), 'recents', True),
    ]
    ent = [(url_for({'action': a}), mk_li(n, ICON, ''), is_folder) for n, a, is_folder in entries]
    add_all(ent)
    end_dir()


def action_speed_test():
    try:
        import speedtest
        speedtest.show_result(None)
    except Exception as e:
        notify(L(30280).format(e))


def action_clear_cache():
    n = common.cache_clear()
    try:
        from mediacfg import invalidate_cache
        invalidate_cache()
    except Exception:
        pass
    notify(L(30281).format(n), xbmcgui.NOTIFICATION_INFO)


def action_clear_dns_cache():
    dns = _dns()
    if dns:
        dns.clear_cache()
        notify(L(30282), xbmcgui.NOTIFICATION_INFO)


# ════════════════════════════════════════════════════════
#  Backward compatibility
# ════════════════════════════════════════════════════════
#  plugin:// URLs stored by builds that used Portuguese parameter names (Kodi
#  favourites, widgets, the "Recent" list) are mapped to the current names, so
#  they keep working. This block can be deleted if no such saved items exist.

_LEGACY_PARAMS = {
    'acao': 'action', 'nome': 'name', 'cat_nome': 'cat_name', 'serie_nome': 'series_name',
    'temporada': 'season', 'stalker_tipo': 'stalker_type', 'grupo': 'group', 'pag': 'page',
    'fav_nome': 'fav_name', 'fav_tipo': 'fav_type',
}
_LEGACY_ACTIONS = {
    'tipos': 'types', 'live_canais': 'live_list', 'vod_canais': 'vod_list', 'series_canais': 'series_list',
    'series_temps': 'series_seasons', 'conta': 'account', 'pesquisa': 'search', 'favoritos': 'favourites',
    'recentes': 'recents', 'recentes_limpar': 'recents_clear', 'diagnostico': 'diagnostic',
    'fav_remover': 'fav_remove', 'ferramentas': 'tools', 'definicoes': 'settings',
    'dns_escolher': 'dns_choose', 'dns_activar': 'dns_set', 'limpar_cache': 'clear_cache',
    'limpar_cache_dns': 'clear_dns_cache', 'm3u_grupos': 'm3u_groups', 'm3u_canais': 'm3u_channels',
}


def _upgrade_params(p):
    out = dict((_LEGACY_PARAMS.get(k, k), v) for k, v in p.items())
    if 'action' in out:
        out['action'] = _LEGACY_ACTIONS.get(out['action'], out['action'])
    if out.get('dns_provider') == 'sistema':
        out['dns_provider'] = 'system'
    return out


# ════════════════════════════════════════════════════════
#  Router
# ════════════════════════════════════════════════════════

_ALLOWED_DURING_PLAY = ('play', 'stalker_play', 'search', 'fav_add', 'fav_remove', 'dns_set',
                        'speed_test', 'clear_cache', 'clear_dns_cache', 'settings', 'account', 'diagnostic',
                        'recents_clear')


def run():
    global HANDLE, BASE_URL
    BASE_URL = sys.argv[0]
    HANDLE = int(sys.argv[1])
    P = _upgrade_params(dict(parse_qsl(sys.argv[2][1:])))
    action = P.get('action', 'main')
    log('Action=' + action)

    if action not in _ALLOWED_DURING_PLAY:
        try:
            if xbmc.Player().isPlaying():
                xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
                return
        except Exception:
            pass

    s = P.get('srv_idx', '')
    cid, cnm = P.get('cat_id', ''), P.get('cat_name', '')
    page = int(P.get('page', '0') or 0)

    if action == 'main':              show_main()
    elif action == 'types':           show_types(s)
    elif action in ('live_cats', 'vod_cats', 'series_cats'):
        show_categories(s, action)
    elif action == 'live_list':       show_live(s, cid, cnm, page)
    elif action == 'vod_list':        show_vod(s, cid, cnm, page)
    elif action == 'series_list':     show_series(s, cid, cnm, page)
    elif action == 'series_seasons':  show_seasons(s, P.get('series_id', ''), P.get('series_name', ''))
    elif action == 'series_eps':      show_episodes(s, P.get('series_id', ''), P.get('series_name', ''), P.get('season'))
    elif action == 'catchup':         show_catchup(s, P.get('stream_id', ''), P.get('name', ''))
    elif action == 'account':
        show_account(s)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
    elif action == 'stalker_live':    show_stalker_items(s, 'itv', cid or '*', cnm, page)
    elif action == 'stalker_vod':     show_stalker_items(s, 'vod', cid or '*', cnm, page)
    elif action == 'stalker_series':  show_stalker_items(s, 'series', cid or '*', cnm, page)
    elif action == 'stalker_eps':
        show_stalker_episodes(s, P.get('stalker_type', 'vod'), P.get('cmd', ''), P.get('name', ''),
                              P.get('logo', ''), P.get('eps', ''))
    elif action == 'stalker_play':
        play_stalker(s, P.get('stalker_type', 'itv'), P.get('cmd', ''), P.get('name', ''),
                     P.get('logo', ''), P.get('series', ''))
    elif action == 'm3u_groups':      show_m3u_groups(s, P.get('kind', 'l'))
    elif action == 'm3u_channels':    show_m3u_channels(s, P.get('group', ''), P.get('kind', 'l'), page)
    elif action == 'm3u_refresh':     m3u_refresh(s)
    elif action == 'search':          search(s, P.get('q'), page)
    elif action == 'play':            play(P)
    elif action == 'favourites':      show_favourites()
    elif action == 'recents':         show_recents()
    elif action == 'recents_clear':
        import favourites
        favourites.hist_clear()
        xbmc.executebuiltin('Container.Refresh')
    elif action == 'diagnostic':      action_diagnostic(P)
    elif action == 'fav_add':         action_fav_add(P)
    elif action == 'fav_remove':      action_fav_remove(P.get('fav_id', ''))
    elif action == 'tools':           show_tools()
    elif action == 'settings':        ADDON.openSettings()
    elif action == 'dns_choose':      show_dns_chooser()
    elif action == 'dns_set':         action_dns(P.get('dns_provider', 'system'))
    elif action == 'speed_test':      action_speed_test()
    elif action == 'clear_cache':     action_clear_cache()
    elif action == 'clear_dns_cache': action_clear_dns_cache()
    else:                             show_main()
