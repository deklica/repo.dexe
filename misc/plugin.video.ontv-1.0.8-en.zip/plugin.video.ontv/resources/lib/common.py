# -*- coding: utf-8 -*-
"""
OnTV — common utilities (no dependency on the plugin HANDLE).

Can be imported by both the plugin and the service (different Kodi
processes) and also outside Kodi (tests).

Contents:
  - settings with safe default values
  - paths (profile / temp)
  - device profile (low / mid / high) by RAM
  - on-disk cache, one file per key (no full rewrite on every request)
  - HTTP (urllib, gzip, configurable SSL)
  - adult filter and regional (Serbia / ex-YU) category priority
"""

import gzip
import hashlib
import io
import json
import os
import re
import ssl
import sys
import tempfile
import threading
import time
from collections import OrderedDict
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit
from urllib.request import Request, build_opener, HTTPSHandler

try:
    import xbmc
    import xbmcaddon
    import xbmcvfs
    IN_KODI = True
except Exception:          # outside Kodi (tests)
    IN_KODI = False

ADDON_ID = 'plugin.video.ontv'

UA_VLC     = 'VLC/3.0.20 LibVLC/3.0.20'
UA_CHROME  = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
              '(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36')
UA_STB     = ('Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 '
              '(KHTML, like Gecko) MAG200 stb mergnat/1.1 Safari/533.3')
UA_EXO     = 'ExoPlayerLib/2.18.7'
UA_LAVF    = 'Lavf/60.3.100'


# ════════════════════════════════════════════════════════
#  Logging
# ════════════════════════════════════════════════════════

_TEST_SETTINGS = {}


def log(msg, level=None):
    if IN_KODI:
        if level is None:
            level = xbmc.LOGINFO if setting_bool('debug_log', False) else xbmc.LOGDEBUG
        xbmc.log('[OnTV] ' + str(msg), level)
    else:
        print('[OnTV] ' + str(msg))


def log_warn(msg):
    log(msg, xbmc.LOGWARNING if IN_KODI else None)


def mask_url(url):
    """Strip credentials from URLs (query and Xtream path) for the logs."""
    s = str(url)
    s = re.sub(r'(username|password|token|mac)=([^&\s]+)', r'\1=***', s, flags=re.I)
    s = re.sub(r'/(live|movie|series|timeshift)/([^/\s]+)/([^/\s]+)/', r'/\1/***/***/', s)
    return s


# ════════════════════════════════════════════════════════
#  Settings
# ════════════════════════════════════════════════════════

def setting(key, default=''):
    if not IN_KODI:
        return _TEST_SETTINGS.get(key, default)
    try:
        v = xbmcaddon.Addon(ADDON_ID).getSetting(key)
        return v if v != '' else default
    except Exception:
        return default


def setting_bool(key, default=False):
    v = setting(key, '')
    if v == '':
        return default
    return str(v).lower() == 'true'


def setting_int(key, default=0):
    v = setting(key, '')
    try:
        return int(float(v))
    except Exception:
        return default


# ════════════════════════════════════════════════════════
#  Localized strings (English by default; PT-PT/PT-BR in Portuguese)
# ════════════════════════════════════════════════════════

_L_CACHE = {}
_EMOJI_LEAD = re.compile(r'^[\u2100-\u214F\u2190-\u2BFF\u2600-\u27BF\U0001F000-\U0001FAFF\uFE0F\u200d\s]+')
_TEST_L = {}


def L(sid):
    """Localized string (strings.po). With 'emoji' off, strips the leading icon."""
    s = _L_CACHE.get(sid)
    if s is None:
        if IN_KODI:
            try:
                s = xbmcaddon.Addon(ADDON_ID).getLocalizedString(sid)
            except Exception:
                s = ''
        else:
            s = _TEST_L.get(sid, '')
        if not s:
            s = '#{}'.format(sid)
        else:
            _L_CACHE[sid] = s
    if not setting_bool('emoji', True):
        s = _EMOJI_LEAD.sub('', s)
    return s


# ════════════════════════════════════════════════════════
#  Paths
# ════════════════════════════════════════════════════════

def _mk(path):
    try:
        os.makedirs(path)
    except OSError:
        pass
    return path


def _translate(p):
    if IN_KODI:
        return xbmcvfs.translatePath(p)
    base = os.path.join(tempfile.gettempdir(), 'ontv_test')
    return os.path.join(base, p.replace('special://', '').replace('/', os.sep))


def profile_dir(sub=''):
    """Persistent data (favourites, state). NOT cleared by Kodi."""
    p = _translate('special://profile/addon_data/{}/'.format(ADDON_ID))
    if sub:
        p = os.path.join(p, sub)
    return _mk(p)


def temp_dir(sub=''):
    """Disposable caches."""
    p = _translate('special://temp/')
    if sub:
        p = os.path.join(p, sub)
    return _mk(p)


def atomic_write(path, data, mode='w'):
    """Write to a .tmp and replace — never leaves half-written files."""
    tmp = path + '.tmp{}'.format(threading.get_ident())
    if 'b' in mode:
        with open(tmp, mode) as f:
            f.write(data)
    else:
        with io.open(tmp, mode, encoding='utf-8') as f:
            f.write(data)
    os.replace(tmp, path)


# ════════════════════════════════════════════════════════
#  Device profile
# ════════════════════════════════════════════════════════

_PROFILES = {
    'low':  dict(chunk=32768,  queue_mb=4,  page=300,  epg_max=30,  workers=3, fanart=False, cache_mb=20),
    'mid':  dict(chunk=65536,  queue_mb=8,  page=600,  epg_max=60,  workers=5, fanart=True,  cache_mb=60),
    'high': dict(chunk=131072, queue_mb=16, page=1500, epg_max=100, workers=8, fanart=True,  cache_mb=150),
}
_ram_cache = [None]


def ram_mb():
    if _ram_cache[0] is not None:
        return _ram_cache[0]
    val = 0
    try:                                     # Linux / Android / CoreELEC / LibreELEC
        with open('/proc/meminfo', 'r') as f:
            for line in f:
                if line.startswith('MemTotal:'):
                    val = int(line.split()[1]) // 1024
                    break
    except Exception:
        pass
    if not val and os.name == 'nt':          # Windows
        try:
            import ctypes

            class _MS(ctypes.Structure):
                _fields_ = [('dwLength', ctypes.c_ulong), ('dwMemoryLoad', ctypes.c_ulong),
                            ('ullTotalPhys', ctypes.c_ulonglong), ('ullAvailPhys', ctypes.c_ulonglong),
                            ('ullTotalPageFile', ctypes.c_ulonglong), ('ullAvailPageFile', ctypes.c_ulonglong),
                            ('ullTotalVirtual', ctypes.c_ulonglong), ('ullAvailVirtual', ctypes.c_ulonglong),
                            ('sullAvailExtendedVirtual', ctypes.c_ulonglong)]
            ms = _MS()
            ms.dwLength = ctypes.sizeof(_MS)
            ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(ms))
            val = int(ms.ullTotalPhys // (1024 * 1024))
        except Exception:
            pass
    if not val and IN_KODI:                  # macOS / iOS / others: Kodi info label
        try:
            s = xbmc.getInfoLabel('System.Memory(total)').strip().upper()
            m = re.search(r'([\d.,]+)\s*(GB|MB|KB)?', s)
            if m:
                n = float(m.group(1).replace(',', '.'))
                u = m.group(2) or 'MB'
                val = int(n * 1024) if u == 'GB' else int(n / 1024) if u == 'KB' else int(n)
        except Exception:
            pass
    _ram_cache[0] = val or 2048
    return _ram_cache[0]


def device_tier():
    ov = setting_int('device_profile', 0)       # 0 auto, 1 low, 2 mid, 3 high
    if ov in (1, 2, 3):
        return {1: 'low', 2: 'mid', 3: 'high'}[ov]
    r = ram_mb()
    if r < 1400:
        return 'low'
    if r < 3500:
        return 'mid'
    return 'high'


def device_profile():
    return dict(_PROFILES[device_tier()])


# ════════════════════════════════════════════════════════
#  On-disk cache (1 file per key)
# ════════════════════════════════════════════════════════

_MEM = OrderedDict()
_MEM_MAX_ITEMS = 6
_MEM_MAX_BYTES = 2 * 1024 * 1024
_mem_lock = threading.Lock()


def _ckey(key):
    return hashlib.sha1(key.encode('utf-8')).hexdigest()


def _cache_path(key):
    return os.path.join(temp_dir('ontv_cache'), _ckey(key) + '.cache')


def cache_get(key, ttl):
    """Cached text if younger than 'ttl' seconds; otherwise None."""
    now = time.time()
    h = _ckey(key)
    with _mem_lock:
        e = _MEM.get(h)
        if e and now - e[0] < ttl:
            _MEM.move_to_end(h)
            return e[1]
    p = _cache_path(key)
    try:
        st = os.stat(p)
        if now - st.st_mtime < ttl:
            with io.open(p, 'r', encoding='utf-8') as f:
                data = f.read()
            _mem_put(h, st.st_mtime, data)
            return data
    except Exception:
        pass
    return None


def _mem_put(h, ts, data):
    if len(data) > _MEM_MAX_BYTES:
        return
    with _mem_lock:
        _MEM[h] = (ts, data)
        _MEM.move_to_end(h)
        while len(_MEM) > _MEM_MAX_ITEMS:
            _MEM.popitem(last=False)


def cache_set(key, data):
    try:
        atomic_write(_cache_path(key), data)
        _mem_put(_ckey(key), time.time(), data)
    except Exception as e:
        log('cache_set: ' + str(e))


def cache_del(key):
    with _mem_lock:
        _MEM.pop(_ckey(key), None)
    try:
        os.remove(_cache_path(key))
    except Exception:
        pass


def cache_clear():
    with _mem_lock:
        _MEM.clear()
    n = 0
    for sub in ('ontv_cache', 'ontv_m3u'):
        base = temp_dir(sub)
        for root, dirs, files in os.walk(base, topdown=False):
            for fn in files:
                try:
                    os.remove(os.path.join(root, fn))
                    n += 1
                except Exception:
                    pass
            for d in dirs:
                try:
                    os.rmdir(os.path.join(root, d))
                except Exception:
                    pass
    return n


def cache_prune(max_mb=None, max_age=86400 * 2):
    """Delete old files and keep the cache below max_mb."""
    if max_mb is None:
        max_mb = device_profile()['cache_mb']
    files = []
    for sub in ('ontv_cache', 'ontv_m3u'):
        for root, _d, fs in os.walk(temp_dir(sub)):
            for fn in fs:
                p = os.path.join(root, fn)
                try:
                    st = os.stat(p)
                    files.append((st.st_mtime, st.st_size, p))
                except Exception:
                    pass
    now = time.time()
    total = sum(f[1] for f in files)
    limit = max_mb * 1024 * 1024
    for mt, sz, p in sorted(files):
        if now - mt > max_age or total > limit:
            try:
                os.remove(p)
                total -= sz
            except Exception:
                pass


# ════════════════════════════════════════════════════════
#  HTTP
# ════════════════════════════════════════════════════════

_opener_cache = {}


def _opener():
    verify = setting_bool('ssl_verify', False)
    op = _opener_cache.get(verify)
    if op is None:
        try:
            ctx = ssl.create_default_context()
            if not verify:
                ctx.check_hostname = False
                ctx.verify_mode = ssl.CERT_NONE
        except Exception:
            ctx = None
        op = build_opener(HTTPSHandler(context=ctx)) if ctx else build_opener()
        _opener_cache[verify] = op
    return op


def open_url(url, headers=None, timeout=20, method=None, data=None):
    """Open a URL and return the response object (the caller closes it)."""
    h = {'User-Agent': UA_CHROME, 'Accept': '*/*', 'Accept-Encoding': 'identity'}
    if headers:
        low = dict((k.lower(), k) for k in h)
        for k, v in headers.items():
            if k.lower() in low:
                h.pop(low[k.lower()], None)
            h[k] = v
    req = Request(url, headers=h, data=data, method=method)
    return _opener().open(req, timeout=timeout)


def _decode(raw):
    if raw[:2] == b'\x1f\x8b':
        try:
            raw = gzip.decompress(raw)
        except Exception:
            pass
    for enc in ('utf-8-sig', 'latin-1'):
        try:
            return raw.decode(enc)
        except Exception:
            continue
    return raw.decode('utf-8', errors='replace')


def fetch_text(url, headers=None, timeout=20, tries=2):
    """Plain GET (no cache). None on error."""
    h = {'Accept-Encoding': 'gzip, identity'}
    if headers:
        h.update(headers)
    last = None
    for i in range(tries):
        try:
            resp = open_url(url, h, timeout=timeout)
            try:
                raw = resp.read()
            finally:
                resp.close()
            return _decode(raw)
        except HTTPError as e:
            last = e
            if e.code in (401, 403, 404, 458, 459):
                break
        except (URLError, OSError, ValueError) as e:
            last = e
        time.sleep(0.4)
    log_warn('HTTP ERROR: {} | {}'.format(last, mask_url(url)))
    return None


def http_get(url, headers=None, ttl=None, force=False, timeout=20):
    """GET with on-disk cache. ttl=None => 5 min."""
    if ttl is None:
        ttl = 300
    if not force and ttl:
        c = cache_get(url, ttl)
        if c is not None:
            return c
    data = fetch_text(url, headers, timeout)
    if data and ttl:
        cache_set(url, data)
    return data


def http_get_json(url, headers=None, ttl=None, force=False, timeout=20, tries=2):
    """GET JSON with cache; only valid JSON responses are cached."""
    if ttl is None:
        ttl = 300
    if not force and ttl:
        c = cache_get(url, ttl)
        if c is not None:
            try:
                return json.loads(c)
            except Exception:
                cache_del(url)
    data = fetch_text(url, headers, timeout, tries)
    if not data:
        return None
    try:
        obj = json.loads(data)
    except Exception:
        i = data.find('{')
        j = data.find('[')
        k = min([x for x in (i, j) if x >= 0] or [-1])
        try:
            if k < 0:
                raise ValueError('no json')
            obj = json.loads(data[k:])
            data = data[k:]
        except Exception:
            log_warn('JSON ERROR: ' + mask_url(url))
            return None
    if ttl:
        cache_set(url, data)
    return obj


# ════════════════════════════════════════════════════════
#  Adult filter (behaviour preserved + fixes)
# ════════════════════════════════════════════════════════
#  Fixes compared to v1.0.7:
#   - '18+' never matched (there is no \b after '+')
#   - 'erotico/erótico' (no trailing 'c', and with accent) is now caught
#   - 'porno/pornô/sexo' covered
#  Also covers the ex-YU terms 'odrasli/za odrasle' and 'erotika/erotski'.

_RE_ADULT = re.compile(
    r'(?i)(?:\b(?:'
    r'a[\.\-_]?d[\.\-_]?u[\.\-_]?l[\.\-_]?t[os]?'
    r'|x{2,}'
    r'|p[\.\-_]?o[\.\-_]?r[\.\-_]?n[oôo]?s?'
    r'|s[\.\-_]?e[\.\-_]?x[\.\-_]?[yo]?'
    r'|er[o0óô]t[i1í]c[oa]s?'
    r'|x[\.\-_]?rat[e3]d'
    r'|h[e3]nt[a@]i'
    r'|playboy'
    r'|nud[e3]?'
    r'|nak[e3]d'
    r'|adulte?[os]?'
    r'|odrasl[ie]'
    r'|erotik[ae]|erotsk[iaeo]'
    r')\b|(?<![\d])18\s*\+|\+\s*18(?!\d))'
)
_adult_memo = {}


def _normalize(name):
    return re.sub(r'^[^a-zA-Z0-9]+', '', name).strip().upper()


def is_adult(name):
    if not name:
        return False
    r = _adult_memo.get(name)
    if r is not None:
        return r
    r = bool(_RE_ADULT.search(name) or _RE_ADULT.search(_normalize(name)))
    if len(_adult_memo) > 20000:
        _adult_memo.clear()
    _adult_memo[name] = r
    return r


def filter_adult(items, field='category_name'):
    return [i for i in items if not is_adult(i.get(field, ''))]


# ════════════════════════════════════════════════════════
#  Regional priority (category order): Serbia first, then the rest of ex-YU
# ════════════════════════════════════════════════════════

_RE_SERBIA = re.compile(r'(?<![A-Z0-9])(?:RS|SRB|SERBIAN?|SRBIJA|СРБИЈА)(?![A-Z0-9])')
_RE_EXYU = re.compile(
    r'(?<![A-Z0-9])(?:'
    r'EX[\s\-_]?YU|YU|BALKANS?'
    r'|HR|CRO|CROATIAN?|HRVATSKA'
    r'|BIH|BA|BOSNIAN?|BOSNA'
    r'|MNE|MONTENEGRO|CRNA\s+GORA'
    r'|MK|MKD|MACEDONIAN?|MAKEDONIJA'
    r'|SLO|SLOVENIAN?|SLOVENIJA'
    r')(?![A-Z0-9])')


def region_priority(raw_name):
    """0 = Serbia (top), 1 = rest of ex-YU, 2 = everything else.

    sorted() is stable: within each tier the server order is kept.
    """
    n = (raw_name or '').upper()
    if _RE_SERBIA.search(n):
        return 0
    if _RE_EXYU.search(n):
        return 1
    return 2


# ════════════════════════════════════════════════════════
#  ListItem: info tag (Kodi 20+) with fallback to setInfo
# ════════════════════════════════════════════════════════

def set_video_info(li, title='', plot='', mediatype='video', year=0, rating=0.0,
                   genre='', season=-1, episode=-1, showtitle='', duration=0,
                   tagline='', director='', cast=None, premiered=''):
    try:
        tag = li.getVideoInfoTag()
        tag.setTitle(title)
        tag.setMediaType(mediatype)
        if plot:
            tag.setPlot(plot)
        if tagline:
            tag.setTagLine(tagline)
        if year:
            tag.setYear(int(year))
        if rating:
            tag.setRating(float(rating))
        if genre:
            tag.setGenres([g.strip() for g in genre.split(',') if g.strip()])
        if season >= 0:
            tag.setSeason(int(season))
        if episode >= 0:
            tag.setEpisode(int(episode))
        if showtitle:
            tag.setTvShowTitle(showtitle)
        if duration:
            tag.setDuration(int(duration))
        if director:
            tag.setDirectors([d.strip() for d in director.split(',') if d.strip()])
        if premiered:
            tag.setPremiered(premiered)
        return
    except AttributeError:
        pass
    except Exception as e:
        log('infoTag: ' + str(e))
    info = {'title': title, 'mediatype': mediatype}
    if plot:
        info['plot'] = plot
    if tagline:
        info['tagline'] = tagline
    if year:
        info['year'] = int(year)
    if rating:
        info['rating'] = float(rating)
    if genre:
        info['genre'] = genre
    if season >= 0:
        info['season'] = int(season)
    if episode >= 0:
        info['episode'] = int(episode)
    if showtitle:
        info['tvshowtitle'] = showtitle
    if duration:
        info['duration'] = int(duration)
    try:
        li.setInfo('video', info)
    except Exception:
        pass
