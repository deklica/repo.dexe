# -*- coding: utf-8 -*-
"""
OnTV — local streaming engine (proxy)  v2

Runs in the addon SERVICE (always alive); the plugin only requests URLs like
http://127.0.0.1:<port>/live.ts?s=<spec>. If the service is not running, the
plugin starts the same server in its own process (fallback).

What it does (idea: an "embedded VLC" for Kodi):
  LIVE  - producer/consumer with a bounded buffer (jitter buffer): one thread
          reads from the server, another writes to Kodi. Reconnects by itself (backoff),
          realigns MPEG-TS to 188-byte packets after every reconnect,
          detects HLS playlists even without a .m3u8 extension.
  HLS   - converts HLS (master/variants) into a continuous MPEG-TS stream for
          Kodi (no rollback, no mimetype issues). If the playlist uses
          fMP4/AES, it serves the rewritten playlist (segments via /seg).
  VOD   - passthrough with Range support (seek, duration, resume).
  Xtream- tries HLS and remembers per host if it is not supported (TS fallback).
  Stalker - renews the link (create_link) on 401/403/404/458 or failures.
  Single-connection accounts: a new channel cancels the previous one; on stop, the
          server connection is closed immediately.
"""

import base64
import json
import os
import queue
import re
import socket
import threading
import time
from http.server import BaseHTTPRequestHandler, HTTPServer
from socketserver import ThreadingMixIn
from urllib.error import HTTPError
from urllib.parse import urljoin, urlsplit

import common
from common import log, log_warn, mask_url, open_url

HOST = '127.0.0.1'
PORT_PREF = 52315
PROP_PORT = 'ontv.proxy.port'

_UA_ROT = [common.UA_CHROME, common.UA_EXO,
           'Mozilla/5.0 (Linux; Android 11; SHIELD Android TV) AppleWebKit/537.36 Chrome/120.0 Safari/537.36',
           common.UA_LAVF]
_UA_FIXED = {1: common.UA_VLC, 2: common.UA_CHROME, 3: common.UA_STB, 4: common.UA_EXO}

_RENEW_CODES = (401, 403, 404, 410, 458, 459)
_XT_LIVE = re.compile(r'/live/[^/]+/[^/]+/\d+\.(?:ts|m3u8)$', re.I)


# ════════════════════════════════════════════════════════
#  Spec (travels base64-encoded in the proxy URL)
# ════════════════════════════════════════════════════════

def encode_spec(spec):
    raw = json.dumps(spec, separators=(',', ':'), ensure_ascii=False).encode('utf-8')
    return base64.urlsafe_b64encode(raw).decode('ascii').rstrip('=')


def decode_spec(s):
    return json.loads(base64.urlsafe_b64decode(s + '=' * (-len(s) % 4)).decode('utf-8'))


def _ext_of(url):
    p = urlsplit(url).path.lower()
    e = p.rsplit('.', 1)[-1] if '.' in p else ''
    return e if 1 <= len(e) <= 5 else ''


# ════════════════════════════════════════════════════════
#  Configuration (read for every stream => settings apply without a restart)
# ════════════════════════════════════════════════════════

def _cfg():
    prof = common.device_profile()
    buf_mb = common.setting_int('buffer_mb', 0)
    qmb = buf_mb if buf_mb > 0 else prof['queue_mb']
    chunk = prof['chunk']
    return {
        'chunk': chunk,
        'qchunks': max(8, int(qmb * 1024 * 1024 // chunk)),
        'stall': max(15, common.setting_int('stall_timeout', 60)),
        'ua_mode': common.setting_int('user_agent', 0),
        'ua_custom': common.setting('user_agent_custom', '').strip(),
        'hls_variant': common.setting_int('hls_variant', 0),
    }


def _retry_delay(kind, n):
    n = max(1, n)
    if kind == 'timeout':
        return min(1.0, 0.20 * n)
    if kind == 'connection':
        return min(0.8, 0.16 * n)
    return min(0.75, 0.14 * n)


# ════════════════════════════════════════════════════════
#  Registry of active streams
# ════════════════════════════════════════════════════════

_ACTIVE = set()
_alock = threading.Lock()
_hls_hosts = {}            # host -> (supports_hls, ts)
_HLS_TTL_OK, _HLS_TTL_NO = 3600, 600


class _SwitchToHls(Exception):
    pass


class _HlsIncompatible(Exception):
    pass


class Stream(object):
    def __init__(self, spec, kind):
        self.spec = spec
        self.kind = kind
        self.url = spec.get('u', '')
        self.cfg = _cfg()
        self.cancel = threading.Event()
        self.done = threading.Event()
        self.q = queue.Queue(maxsize=self.cfg['qchunks'])
        self.t0 = time.time()
        self.bytes = 0
        self.http_status = None
        self._resp = None
        self._rlock = threading.Lock()
        self._last_renew = 0
        self.error = ''

    # -- upstream connection (so it can be closed from another thread) ---
    def set_resp(self, resp):
        with self._rlock:
            self._resp = resp

    def abort(self):
        self.cancel.set()
        with self._rlock:
            r, self._resp = self._resp, None
        _force_close(r)

    # -- buffer ----------------------------------------------------------
    def put(self, chunk):
        while not self.cancel.is_set():
            try:
                self.q.put(chunk, timeout=0.5)
                self.bytes += len(chunk)
                return True
            except queue.Full:
                continue
        return False

    # -- headers ---------------------------------------------------------
    def headers(self, attempt=0):
        h = dict(self.spec.get('h') or {})
        low = dict((k.lower(), k) for k in h)
        if 'user-agent' not in low:
            mode, cust = self.cfg['ua_mode'], self.cfg['ua_custom']
            if mode == 5 and cust:
                h['User-Agent'] = cust
            elif mode in _UA_FIXED:
                h['User-Agent'] = _UA_FIXED[mode]
            else:                                   # auto: rotate the UA if there are failures
                h['User-Agent'] = _UA_ROT[min(attempt // 2, len(_UA_ROT) - 1)]
        h.setdefault('Accept', '*/*')
        h.setdefault('Accept-Encoding', 'identity')
        return h

    # -- Stalker: renew link --------------------------------------------
    def renew(self):
        st = self.spec.get('st')
        if not st or time.time() - self._last_renew < 2.5:
            return False
        self._last_renew = time.time()
        try:
            import api
            new = api.stalker_create_link(st['host'], st['mac'], st['t'], st['cmd'], st.get('s', ''))
            if new and new.startswith('http'):
                self.url = new
                log('Stalker: link renewed')
                return True
        except Exception as e:
            log_warn('Stalker renew: ' + str(e))
        return False


def _read(resp, n):
    """read1: returns as soon as there is data (read(n) would block until n bytes are filled on live)."""
    r1 = getattr(resp, 'read1', None)
    return r1(n) if r1 else resp.read(n)


def _force_close(resp):
    if resp is None:
        return
    try:
        raw = getattr(getattr(resp, 'fp', None), 'raw', None)
        sock = getattr(raw, '_sock', None)
        if sock is not None:
            sock.shutdown(socket.SHUT_RDWR)
    except Exception:
        pass
    try:
        resp.close()
    except Exception:
        pass


def _register(st):
    with _alock:
        if st.kind == 'live':                       # single-connection accounts
            for o in list(_ACTIVE):
                if o.kind == 'live':
                    o.abort()
        _ACTIVE.add(st)


def _unregister(st):
    with _alock:
        _ACTIVE.discard(st)


def cancel_all(older_than=None):
    """Cancel streams (only those started before 'older_than', epoch)."""
    with _alock:
        lst = list(_ACTIVE)
    for s in lst:
        if older_than is None or s.t0 < older_than:
            s.abort()


# ════════════════════════════════════════════════════════
#  MPEG-TS: alignment to 188-byte packets
# ════════════════════════════════════════════════════════

def _find_sync(buf):
    n = len(buf)
    i = 0
    while i + 376 < n:
        i = buf.find(b'\x47', i)
        if i < 0 or i + 376 >= n:
            return -1
        if buf[i + 188] == 0x47 and buf[i + 376] == 0x47:
            return i
        i += 1
    return -1


class _TsAligner(object):
    """Emits only multiples of 188 bytes; after a reconnect it looks for the new packet start."""

    def __init__(self):
        self.carry = b''
        self.aligning = False

    def reconnect(self):
        self.carry = b''
        self.aligning = True

    def feed(self, chunk):
        buf = self.carry + chunk
        if self.aligning:
            i = _find_sync(buf)
            if i < 0:
                self.carry = buf[-564:]
                return b''
            buf = buf[i:]
            self.aligning = False
        n = len(buf) - (len(buf) % 188)
        self.carry = buf[n:]
        return buf[:n]


def _looks_ts(chunk):
    return len(chunk) > 188 and chunk[0] == 0x47 and chunk[188] == 0x47


# ════════════════════════════════════════════════════════
#  Producer: LIVE TS
# ════════════════════════════════════════════════════════

def _produce_ts(st):
    cfg = st.cfg
    fails = 0              # consecutive failures (only counted before any data arrives)
    reconnects = 0         # consecutive attempts (backoff / UA rotation)
    got = False
    need_align = False
    last_data = time.time()
    is_ts = None
    aligner = _TsAligner()
    while not st.cancel.is_set():
        resp = None
        try:
            resp = open_url(st.url, st.headers(reconnects), timeout=12)
            st.set_resp(resp)
            st.http_status = getattr(resp, 'status', 200)
            first = True
            while not st.cancel.is_set():
                chunk = _read(resp, cfg['chunk'])
                if not chunk:
                    break                                   # EOF => reconnect
                if first:
                    first = False
                    if chunk[:7] == b'#EXTM3U':
                        raise _SwitchToHls()
                    if is_ts is None:
                        is_ts = _looks_ts(chunk)
                    if need_align and is_ts:
                        aligner.reconnect()
                        need_align = False
                if is_ts:
                    chunk = aligner.feed(chunk)
                if chunk:
                    if not st.put(chunk):
                        return
                    got = True
                    fails = 0
                    reconnects = 0
                    last_data = time.time()
            reconnects += 1                                 # clean EOF
            if not got:
                fails += 1
        except _SwitchToHls:
            raise
        except HTTPError as e:
            st.http_status = e.code
            reconnects += 1
            fails += 1
            log_warn('TS HTTP {} ({})'.format(e.code, mask_url(st.url[:70])))
            if e.code in _RENEW_CODES and st.renew():
                reconnects = 0
                fails = 0
            elif e.code in (404, 410) and not st.spec.get('st') and not got and fails >= 3:
                st.error = 'HTTP {}'.format(e.code)
                return
        except Exception as e:
            if st.cancel.is_set():
                return
            reconnects += 1
            fails += 1
            log('TS exception: ' + str(e)[:100])
            if not got and fails == 4:
                st.renew()
        finally:
            _force_close(resp)
            st.set_resp(None)
        need_align = True

        if st.cancel.is_set():
            return
        if not got and fails >= 8:
            st.error = 'no data ({} failures)'.format(fails)
            log_warn('TS: ' + st.error)
            return
        if got and time.time() - last_data > cfg['stall']:
            st.error = 'no data for {}s'.format(cfg['stall'])
            log_warn('TS: ' + st.error)
            return
        st.cancel.wait(_retry_delay('connection', reconnects))


# ════════════════════════════════════════════════════════
#  HLS
# ════════════════════════════════════════════════════════

_RE_BW = re.compile(r'BANDWIDTH=(\d+)', re.I)


def _hls_get(url, headers, timeout=8):
    resp = open_url(url, headers, timeout=timeout)
    try:
        raw = resp.read(2 * 1024 * 1024)
        final = resp.geturl() if hasattr(resp, 'geturl') else url
    finally:
        resp.close()
    return raw.decode('utf-8', errors='replace'), final


def _hls_pick_variant(text, base, prefer_lowest):
    best = None
    lines = text.splitlines()
    for i, ln in enumerate(lines):
        if ln.startswith('#EXT-X-STREAM-INF'):
            m = _RE_BW.search(ln)
            bw = int(m.group(1)) if m else 0
            if 'CODECS="' in ln and 'avc' not in ln.lower() and 'hvc' not in ln.lower() \
                    and 'hev' not in ln.lower() and 'mp4a' in ln.lower():
                continue                                    # audio only
            for nx in lines[i + 1:i + 4]:
                nx = nx.strip()
                if nx and not nx.startswith('#'):
                    if best is None or (bw < best[0] if prefer_lowest else bw > best[0]):
                        best = (bw, urljoin(base, nx))
                    break
    return best[1] if best else None


def _hls_parse_media(text, base):
    segs, seq, target, endlist, incompatible, dur = [], 0, 6.0, False, False, None
    for ln in text.splitlines():
        ln = ln.strip()
        if not ln:
            continue
        if ln.startswith('#EXT-X-MEDIA-SEQUENCE:'):
            try:
                seq = int(ln.split(':', 1)[1])
            except Exception:
                pass
        elif ln.startswith('#EXT-X-TARGETDURATION:'):
            try:
                target = float(ln.split(':', 1)[1])
            except Exception:
                pass
        elif ln.startswith('#EXT-X-ENDLIST'):
            endlist = True
        elif ln.startswith('#EXT-X-MAP'):
            incompatible = True
        elif ln.startswith('#EXT-X-KEY'):
            if 'METHOD=NONE' not in ln.upper():
                incompatible = True
        elif ln.startswith('#EXTINF'):
            dur = ln
        elif not ln.startswith('#'):
            segs.append((seq + len(segs), urljoin(base, ln)))
            dur = None
    return {'segs': segs, 'target': target, 'end': endlist, 'bad': incompatible}


def _hls_segment(st, url, headers):
    """Download 1 segment into the buffer. Returns bytes sent."""
    sent = 0
    for attempt in range(3):
        resp = None
        try:
            resp = open_url(url, headers, timeout=12)
            st.set_resp(resp)
            while not st.cancel.is_set():
                chunk = _read(resp, st.cfg['chunk'])
                if not chunk:
                    return sent
                if not st.put(chunk):
                    return sent
                sent += len(chunk)
            return sent
        except Exception as e:
            if st.cancel.is_set():
                return sent
            if sent:                                    # part already sent: do not retry (would duplicate data)
                log('HLS segment truncated: ' + str(e)[:80])
                return sent
            if isinstance(e, HTTPError) and e.code in _RENEW_CODES:
                st.renew()
            st.cancel.wait(0.3 * (attempt + 1))
        finally:
            _force_close(resp)
            st.set_resp(None)
    return sent


def _produce_hls(st):
    headers = st.headers()
    text, final = _hls_get(st.url, headers)
    if '#EXTM3U' not in text:
        raise _HlsIncompatible('not HLS')
    media_url = final
    if '#EXT-X-STREAM-INF' in text:
        v = _hls_pick_variant(text, final, st.cfg['hls_variant'] == 1)
        if not v:
            raise _HlsIncompatible('no variants')
        media_url = v
        log('HLS variant: ' + mask_url(v[:80]))

    last_seq = None
    last_ok = time.time()
    fails = 0
    while not st.cancel.is_set():
        try:
            text, final = _hls_get(media_url, st.headers())
            pl = _hls_parse_media(text, final)
            fails = 0
        except Exception as e:
            fails += 1
            if isinstance(e, HTTPError) and e.code in _RENEW_CODES and st.renew():
                media_url = st.url
            if time.time() - last_ok > st.cfg['stall'] or (fails >= 8 and last_seq is None):
                st.error = 'HLS no response'
                return
            st.cancel.wait(_retry_delay('connection', fails))
            continue
        if pl['bad']:
            raise _HlsIncompatible('fMP4/AES')
        segs = pl['segs']
        new = [s for s in segs if last_seq is None or s[0] > last_seq]
        if last_seq is None and not pl['end']:
            new = new[-3:]                                  # live edge
        for seq, surl in new:
            if st.cancel.is_set():
                return
            if _hls_segment(st, surl, st.headers()):
                last_ok = time.time()
            last_seq = seq
        if pl['end']:                                       # final playlist: nothing more will come
            return
        if not new:
            if time.time() - last_ok > st.cfg['stall']:
                st.error = 'HLS no new segments'
                return
            st.cancel.wait(max(0.4, min(pl['target'] / 2.0, 3.0)))


def _hls_supported(host):
    e = _hls_hosts.get(host)
    if not e:
        return None
    ok, ts = e
    if time.time() - ts > (_HLS_TTL_OK if ok else _HLS_TTL_NO):
        return None
    return ok


def _probe_hls(st, hurl):
    host = urlsplit(hurl).netloc
    try:
        resp = open_url(hurl, st.headers(), timeout=4)
        try:
            head = resp.read(1024)
        finally:
            resp.close()
        ok = b'#EXTM3U' in head
    except Exception as e:
        log('HLS probe failed: ' + str(e)[:80])
        ok = False
    _hls_hosts[host] = (ok, time.time())
    return ok


def _producer_main(st):
    try:
        mode = st.spec.get('_mode', 'ts')
        while not st.cancel.is_set():
            try:
                if mode == 'hls':
                    _produce_hls(st)
                else:
                    _produce_ts(st)
                break
            except _SwitchToHls:
                mode = 'hls'
                log('Stream is HLS — converting to TS')
            except _HlsIncompatible as e:
                log('HLS not compatible with conversion ({}) — rewritten playlist'.format(e))
                st.error = 'rewrite'
                break
    except Exception as e:
        st.error = str(e)[:120]
        log_warn('Producer: ' + st.error)
    finally:
        st.done.set()
        try:
            st.q.put_nowait(None)
        except queue.Full:
            pass


# ════════════════════════════════════════════════════════
#  HTTP server
# ════════════════════════════════════════════════════════

class _Server(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = (os.name != 'nt')
    request_queue_size = 16


class _Handler(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.0'

    def log_message(self, fmt, *args):
        pass

    def handle(self):
        try:
            BaseHTTPRequestHandler.handle(self)
        except (ConnectionError, OSError):
            pass

    def finish(self):
        try:
            BaseHTTPRequestHandler.finish(self)
        except (ConnectionError, OSError):
            pass

    def _plain(self, code):
        try:
            self.send_response(code)
            self.send_header('Content-Length', '0')
            self.end_headers()
        except Exception:
            pass

    def _spec(self):
        m = re.search(r'[?&]s=([^&]+)', self.path)
        if not m:
            return None
        try:
            return decode_spec(m.group(1))
        except Exception:
            return None

    def do_HEAD(self):
        path = self.path.split('?', 1)[0]
        if path.startswith('/live'):
            self.send_response(200)
            self.send_header('Content-Type', 'video/mp2t')
            self.end_headers()
        elif path.startswith('/vod') or path.startswith('/seg'):
            spec = self._spec()
            if spec:
                self._passthrough(spec, head=True)
            else:
                self._plain(400)
        else:
            self._plain(200 if path == '/check' else 404)

    def do_GET(self):
        path = self.path.split('?', 1)[0]
        if path == '/check':
            return self._plain(200)
        if path == '/stop':
            cancel_all()
            return self._plain(200)
        spec = self._spec()
        if not spec or not str(spec.get('u', '')).startswith('http'):
            return self._plain(400)
        try:
            self.request.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        except Exception:
            pass
        if path.startswith('/live'):
            self._live(spec)
        elif path.startswith('/hls'):
            self._hls_playlist(spec)
        elif path.startswith('/vod') or path.startswith('/seg'):
            self._passthrough(spec)
        else:
            self._plain(404)

    # ── LIVE ────────────────────────────────────────────
    def _live(self, spec):
        st = Stream(spec, 'live')
        url = st.url
        sp = urlsplit(url)
        fmt = spec.get('f', 'auto')                   # auto | ts | hls
        mode = 'ts'
        if _XT_LIVE.search(sp.path) and fmt == 'ts':
            if sp.path.lower().endswith('.m3u8'):                 # panel gave .m3u8 but the user wants TS
                st.url = re.sub(r'\.m3u8', '.ts', url, count=1, flags=re.I)
        elif re.search(r'\.m3u8$', sp.path, re.I) or ('/hls' in sp.path.lower() and not sp.path.endswith('.ts')):
            mode = 'hls'
        elif _XT_LIVE.search(sp.path) and fmt != 'ts':
            hurl = re.sub(r'\.ts$', '.m3u8', url, flags=re.I)
            sup = _hls_supported(sp.netloc)
            if fmt == 'hls' or (fmt == 'auto' and sup is not False):
                if sup is True or _probe_hls(st, hurl):
                    st.url, mode = hurl, 'hls'
        st.spec = dict(spec, _mode=mode)
        _register(st)
        t = threading.Thread(target=_producer_main, args=(st,))
        t.daemon = True
        t.start()
        log('LIVE {} ({}) buffer={}ch'.format(mode.upper(), mask_url(st.url[:60]), st.cfg['qchunks']))
        try:
            started = self._pump(st)
            if not started:
                if st.error == 'rewrite':
                    st.cancel.set()
                    self._hls_playlist(dict(spec, u=st.url))
                else:
                    self._plain(504 if st.error and 'no response' in st.error else 502)
        finally:
            st.abort()
            _unregister(st)

    def _pump(self, st):
        started = False
        while True:
            try:
                chunk = st.q.get(timeout=1.0)
            except queue.Empty:
                if st.cancel.is_set() or (st.done.is_set() and st.q.empty()):
                    break
                continue
            if chunk is None:
                break
            try:
                if not started:
                    self.send_response(200)
                    self.send_header('Content-Type', 'video/mp2t')
                    self.send_header('Cache-Control', 'no-cache')
                    self.end_headers()
                    started = True
                self.wfile.write(chunk)
            except Exception:
                break
        return started

    # ── Rewritten HLS (fallback) ────────────────────────
    def _rewrite_uri(self, abs_url, spec):
        route = '/hls' if re.search(r'\.m3u8(\?|$)', abs_url, re.I) else '/seg'
        s = dict(spec, u=abs_url)
        s.pop('_mode', None)
        return 'http://{}:{}{}?s={}'.format(HOST, _SRV['port'], route, encode_spec(s))

    def _hls_playlist(self, spec):
        st = Stream(spec, 'hls')
        try:
            text, final = _hls_get(spec['u'], st.headers())
        except HTTPError as e:
            if e.code in _RENEW_CODES and st.renew():
                try:
                    text, final = _hls_get(st.url, st.headers())
                except Exception:
                    return self._plain(502)
            else:
                return self._plain(e.code)
        except Exception:
            return self._plain(502)
        if '#EXTM3U' not in text:
            return self._plain(502)

        def _line(m):
            return 'URI="{}"'.format(self._rewrite_uri(urljoin(final, m.group(1)), spec))

        out = []
        for ln in text.splitlines():
            s = ln.strip()
            if not s:
                out.append(ln)
            elif s.startswith('#'):
                out.append(re.sub(r'URI="([^"]+)"', _line, ln))
            else:
                out.append(self._rewrite_uri(urljoin(final, s), spec))
        body = ('\n'.join(out) + '\n').encode('utf-8')
        try:
            self.send_response(200)
            self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        except Exception:
            pass

    # ── Passthrough (VOD with Range / segments) ────
    def _passthrough(self, spec, head=False):
        st = Stream(spec, 'vod')
        hdrs = st.headers()
        rng = self.headers.get('Range')
        if rng:
            hdrs['Range'] = rng
        resp = None
        for attempt in range(2):
            try:
                resp = open_url(st.url, hdrs, timeout=20, method='HEAD' if head else None)
                break
            except HTTPError as e:
                if attempt == 0 and e.code in _RENEW_CODES and st.renew():
                    continue
                return self._plain(e.code)
            except Exception as e:
                log_warn('VOD connection: ' + str(e)[:100])
                return self._plain(502)
        _register(st)
        st.set_resp(resp)
        try:
            self.send_response(getattr(resp, 'status', 200))
            for h in ('Content-Type', 'Content-Length', 'Content-Range', 'Accept-Ranges', 'Last-Modified'):
                v = resp.headers.get(h)
                if v:
                    self.send_header(h, v)
            self.end_headers()
            if head:
                return
            n = st.cfg['chunk']
            while not st.cancel.is_set():
                chunk = _read(resp, n)
                if not chunk:
                    break
                self.wfile.write(chunk)
        except Exception:
            pass
        finally:
            st.abort()
            _unregister(st)


# ════════════════════════════════════════════════════════
#  Server management
# ════════════════════════════════════════════════════════

_SRV = {'httpd': None, 'thread': None, 'port': 0}
_srv_lock = threading.Lock()


def _set_prop(port):
    try:
        import xbmcgui
        xbmcgui.Window(10000).setProperty(PROP_PORT, str(port) if port else '')
    except Exception:
        pass


def _get_prop():
    try:
        import xbmcgui
        v = xbmcgui.Window(10000).getProperty(PROP_PORT)
        return int(v) if v else 0
    except Exception:
        return 0


def _alive(port):
    s = None
    try:
        s = socket.create_connection((HOST, port), timeout=0.6)
        s.sendall(b'GET /check HTTP/1.0\r\n\r\n')
        return s.recv(16).startswith(b'HTTP/')
    except Exception:
        return False
    finally:
        if s:
            try:
                s.close()
            except Exception:
                pass


def start_server():
    """Start the server (idempotent). Returns the port."""
    with _srv_lock:
        if _SRV['httpd'] and _SRV['thread'] and _SRV['thread'].is_alive():
            return _SRV['port']
        httpd = None
        for port in (PORT_PREF, 0):
            try:
                httpd = _Server((HOST, port), _Handler)
                break
            except OSError as e:
                log('Port {} unavailable: {}'.format(port, e))
        if httpd is None:
            return 0
        _SRV['httpd'] = httpd
        _SRV['port'] = httpd.server_address[1]
        t = threading.Thread(target=httpd.serve_forever, kwargs={'poll_interval': 0.5})
        t.daemon = True
        t.start()
        _SRV['thread'] = t
        _set_prop(_SRV['port'])
        log('Proxy listening on {}:{}'.format(HOST, _SRV['port']), None)
        return _SRV['port']


def stop_server():
    with _srv_lock:
        cancel_all()
        h = _SRV['httpd']
        _SRV.update(httpd=None, thread=None, port=0)
    _set_prop(0)
    if h:
        try:
            h.shutdown()
            h.server_close()
        except Exception:
            pass


def stop_remote():
    """Ask the proxy (wherever it runs) to close all server connections."""
    port = _get_prop() or _SRV['port'] or PORT_PREF
    s = None
    try:
        s = socket.create_connection((HOST, port), timeout=0.8)
        s.sendall(b'GET /stop HTTP/1.0\r\n\r\n')
        s.recv(16)
    except Exception:
        pass
    finally:
        if s:
            try:
                s.close()
            except Exception:
                pass


def get_port():
    return _SRV['port']


def ensure_running():
    """Port of a live proxy (the service's or one started here). 0 if impossible."""
    port = _get_prop()
    if port and _alive(port):
        return port
    if _SRV['port'] and _alive(_SRV['port']):
        return _SRV['port']
    if _alive(PORT_PREF):
        return PORT_PREF
    return start_server()


def build_url(spec, kind='live'):
    """Proxy URL for a spec {u, h, f, st}. None if the proxy is not available."""
    port = ensure_running()
    if not port:
        return None
    ext = _ext_of(spec.get('u', '')) if kind == 'vod' else 'ts'
    return 'http://{}:{}/{}.{}?s={}'.format(HOST, port, kind, ext or 'bin', encode_spec(spec))
