# -*- coding: utf-8 -*-
"""
OnTV — stream diagnostics.

Connects DIRECTLY to the stream (no proxy, no Kodi) for a few seconds and
measures: HTTP status, time to first data, average / minimum bitrate and whether
the server closes the connection. Tells you whether the dropouts come from the server.
"""

import time
from urllib.error import HTTPError

import common
from common import L, open_url


def _ua():
    m = common.setting_int('user_agent', 0)
    if m == 5 and common.setting('user_agent_custom', '').strip():
        return common.setting('user_agent_custom').strip()
    return {1: common.UA_VLC, 2: common.UA_CHROME, 3: common.UA_STB, 4: common.UA_EXO}.get(m, common.UA_VLC)


def measure(url, headers=None, seconds=20, progress=None, cancelled=None):
    """Return a dict with the measurements (see keys below)."""
    r = {'status': None, 'error': '', 'ttfb_ms': None, 'bytes': 0, 'dur': 0.0,
         'closed_at': None, 'ctype': '', 'min_mbps': None, 'avg_mbps': 0.0, 'buckets': []}
    h = {'User-Agent': _ua()}
    if headers:
        h.update(headers)
    t0 = time.time()
    resp = None
    try:
        resp = open_url(url, h, timeout=10)
        r['status'] = getattr(resp, 'status', 200)
        r['ctype'] = resp.headers.get('Content-Type', '') or ''
        read = getattr(resp, 'read1', None) or resp.read
        buckets = {}
        t_first = None
        while True:
            if cancelled and cancelled():
                break
            now = time.time()
            if t_first is not None and now - t_first >= seconds:
                break
            if now - t0 > seconds + 12:                     # never received any data
                break
            chunk = read(65536)
            now = time.time()
            if not chunk:
                r['closed_at'] = round(now - (t_first or t0), 1)
                break
            if t_first is None:
                t_first = now
                r['ttfb_ms'] = int((now - t0) * 1000)
            sec = int(now - t_first)
            buckets[sec] = buckets.get(sec, 0) + len(chunk)
            r['bytes'] += len(chunk)
            if progress:
                progress(sec)
        end = time.time()
        if t_first is not None:
            r['dur'] = max(0.1, end - t_first)
            r['avg_mbps'] = r['bytes'] * 8 / r['dur'] / 1e6
            full = int(r['dur'])                              # whole seconds only
            if full >= 2:
                r['buckets'] = [buckets.get(i, 0) for i in range(full)]
                r['min_mbps'] = min(r['buckets']) * 8 / 1e6
    except HTTPError as e:
        r['status'] = e.code
        r['error'] = 'HTTP {}'.format(e.code)
    except Exception as e:
        r['error'] = str(e)[:120] or e.__class__.__name__
    finally:
        try:
            if resp:
                resp.close()
        except Exception:
            pass
    return r


def report(r, seconds=20):
    """Human-readable text + verdict."""
    ln = []
    if r['status'] is not None and r['status'] >= 400:
        ln.append(L(30337).format(r['status']))
        ln.append('')
        ln.append(L(30332))
        return '\n'.join(ln)
    if r['error'] and not r['bytes']:
        ln.append(L(30331).format(r['error']))
        return '\n'.join(ln)
    ln.append(L(30325).format(r['status']))
    if r['ctype']:
        ln.append(L(30335).format(r['ctype']))
    if r['ttfb_ms'] is not None:
        ln.append(L(30326).format(r['ttfb_ms']))
    ln.append(L(30327).format(r['bytes'] / 1048576.0, int(round(r['dur'])), r['avg_mbps']))
    if r['min_mbps'] is not None:
        ln.append(L(30328).format(r['min_mbps']))
    if r['closed_at'] is not None and r['closed_at'] < seconds - 1:
        ln.append(L(30329).format(r['closed_at']))
        verdict = L(30332)
    elif r['min_mbps'] is not None and (r['min_mbps'] == 0 or r['min_mbps'] < r['avg_mbps'] * 0.25):
        ln.append(L(30330).format(int(round(r['dur']))))
        verdict = L(30334)
    else:
        ln.append(L(30330).format(int(round(r['dur']))))
        verdict = L(30333)
    ln.append('')
    ln.append(verdict)
    return '\n'.join(ln)
