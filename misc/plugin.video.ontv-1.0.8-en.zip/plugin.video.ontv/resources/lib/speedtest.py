# -*- coding: utf-8 -*-
"""
OnTV — Speed Test  v1.0.4

Measures the download speed and latency of an IPTV server (or a generic URL).
No external dependencies — uses the Python stdlib only.

Inspired by the approach of Eagle TV Online (speedtest.py), but simpler
and focused on IPTV servers rather than dedicated speedtest servers.
"""

import time
import threading

from common import L

try:
    from urllib.request import urlopen, Request
    from urllib.error   import URLError
except ImportError:
    from urllib2 import urlopen, Request, URLError  # type: ignore

try:
    import xbmc
    import xbmcgui
    import xbmcaddon
    _ADDON_NAME = xbmcaddon.Addon().getAddonInfo('name')
    def _log(msg):
        xbmc.log('[OnTV/speedtest] ' + str(msg), xbmc.LOGINFO)
except Exception:
    _ADDON_NAME = 'OnTV'
    def _log(msg):
        print('[OnTV/speedtest] ' + str(msg))

UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
      'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36')

# Reference URLs for the generic test (~1MB files on public CDNs)
_TEST_URLS = [
    'http://speedtest.tele2.net/1MB.zip',
    'http://ipv4.download.thinkbroadband.com/1MB.zip',
]

_CHUNK     = 65536   # 64 KB per read iteration
_DURATION  = 5       # maximum download seconds per test
_TIMEOUT   = 8       # connection timeout


def _measure_latency(host, port=80):
    """Measure the TCP connect time to host:port in ms."""
    import socket
    try:
        t0 = time.time()
        s  = socket.create_connection((host, port), timeout=5)
        ms = (time.time() - t0) * 1000
        s.close()
        return round(ms, 1)
    except Exception:
        return None


def _measure_download(url, duration=_DURATION):
    """
    Partially download url for 'duration' seconds.
    Returns (speed_Mbps, bytes_received) or (None, 0) on error.
    """
    try:
        req  = Request(url, headers={'User-Agent': UA, 'Accept-Encoding': 'identity'})
        resp = urlopen(req, timeout=_TIMEOUT)
        total = 0
        t0    = time.time()
        while True:
            elapsed = time.time() - t0
            if elapsed >= duration:
                break
            chunk = resp.read(_CHUNK)
            if not chunk:
                break
            total += len(chunk)
        resp.close()
        elapsed = max(time.time() - t0, 0.001)
        mbps    = round((total * 8) / (elapsed * 1_000_000), 2)
        return mbps, total
    except Exception as e:
        _log('Download error: ' + str(e))
        return None, 0


def test_server(stream_url):
    """
    Test the latency and speed of an IPTV stream URL.
    Returns dict: {'latency_ms': float|None, 'speed_mbps': float|None, 'error': str|None}
    """
    try:
        from urllib.parse import urlparse
    except ImportError:
        from urlparse import urlparse  # type: ignore

    parsed = urlparse(stream_url)
    host   = parsed.hostname
    port  = parsed.port or (443 if parsed.scheme == 'https' else 80)

    _log('Server test: {}:{}'.format(host, port))
    result = {'latency_ms': None, 'speed_mbps': None, 'error': None}

    # Latency
    result['latency_ms'] = _measure_latency(host, port)
    _log('Latency: {}ms'.format(result['latency_ms']))

    # Speed (using the stream URL itself for _DURATION seconds)
    mbps, total = _measure_download(stream_url)
    result['speed_mbps'] = mbps
    _log('Speed: {} Mbps ({} bytes)'.format(mbps, total))

    return result


def test_connection(callback=None):
    """
    Test the connection speed against public reference URLs.
    callback(partial_mbps) is called during the test if provided.
    Returns the average speed in Mbps or None.
    """
    results = []
    for url in _TEST_URLS:
        mbps, _ = _measure_download(url)
        if mbps is not None:
            results.append(mbps)
            if callback:
                try:
                    callback(mbps)
                except Exception:
                    pass
    if results:
        return round(sum(results) / len(results), 2)
    return None


def show_result(stream_url=None):
    """
    Run the test and show the result in a Kodi dialog.
    stream_url: URL of the stream to test, or None for the generic connection test.
    """
    try:
        dp = xbmcgui.DialogProgress()
        dp.create(_ADDON_NAME, L(30300))
        dp.update(10, L(30301))

        if stream_url:
            result = test_server(stream_url)
            dp.update(80, L(30302))
            dp.close()

            lat  = result.get('latency_ms')
            mbps = result.get('speed_mbps')

            lat_txt  = '{}ms'.format(round(lat)) if lat is not None else L(30304)
            mbps_txt = '{} Mbps'.format(mbps)    if mbps is not None else L(30304)

            xbmcgui.Dialog().ok(
                _ADDON_NAME,
                L(30303).format(lat_txt, mbps_txt)
            )
        else:
            def _cb(m):
                dp.update(50, L(30305).format(m))
            avg = test_connection(callback=_cb)
            dp.close()
            txt = '{} Mbps'.format(avg) if avg is not None else L(30306)
            xbmcgui.Dialog().ok(_ADDON_NAME, L(30307).format(txt))

    except Exception as e:
        try:
            dp.close()
        except Exception:
            pass
        xbmcgui.Dialog().ok(_ADDON_NAME, L(30308).format(e))
