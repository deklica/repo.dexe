# -*- coding: utf-8 -*-
"""
OnTV — source APIs: Xtream Codes, Stalker/MAG (MAC) and M3U/M3U_plus.

Does not depend on the plugin HANDLE, so it can be used by the proxy
(which runs in the service) to renew Stalker links.
"""

import base64
import hashlib
import io
import gzip
import json
import math
import os
import re
import shutil
import threading
import time
from collections import OrderedDict
from concurrent.futures import ThreadPoolExecutor, wait as futures_wait
from urllib.parse import urlencode, quote, urlsplit, parse_qsl

import common
from common import (log, log_warn, mask_url, http_get_json, fetch_text, open_url,
                    cache_get, cache_set, is_adult, temp_dir, device_profile,
                    setting_int, UA_STB)


# ════════════════════════════════════════════════════════
#  Server normalization (field and type aliases)
# ════════════════════════════════════════════════════════

_TYPES = {
    'xtream': 'xtream', 'xc': 'xtream', 'xtreamcodes': 'xtream', 'xtream_codes': 'xtream',
    'xtream-codes': 'xtream', 'xtream codes': 'xtream', 'iptv': 'xtream',
    'stalker': 'stalker', 'portal': 'stalker', 'mag': 'stalker', 'stb': 'stalker',
    'mac': 'stalker', 'ministra': 'stalker', 'stalker_portal': 'stalker', 'mag/stb': 'stalker',
    'm3u': 'm3u', 'm3u8': 'm3u', 'm3u_plus': 'm3u', 'm3uplus': 'm3u', 'm3u-plus': 'm3u',
    'playlist': 'm3u', 'list': 'm3u', 'url': 'm3u',
}


def _pick(s, *keys):
    for k in keys:
        v = s.get(k)
        if v is not None and str(v).strip() != '':
            return str(v).strip()
    return ''


def _norm_mac(m):
    hexs = re.sub(r'[^0-9A-Fa-f]', '', m)
    if len(hexs) == 12:
        return ':'.join(hexs[i:i + 2] for i in range(0, 12, 2)).upper()
    return m.strip().upper()


def _add_scheme(h):
    h = h.strip()
    if not re.match(r'^[a-z][a-z0-9+.\-]*://', h, re.I):
        h = 'http://' + h
    return h


def _norm_xt_host(h):
    h = _add_scheme(h)
    sp = urlsplit(h)
    path = sp.path
    for _ in range(3):
        path = re.sub(r'/(?:player_api\.php|get\.php|panel_api\.php|xmltv\.php|c)/?$', '', path)
    return '{}://{}{}'.format(sp.scheme, sp.netloc, path.rstrip('/'))


# Server lists often name entries 'Servidor 1', 'Servidor 2'...: show that word in the
# interface language (string 30292: 'Server' in English, 'Servidor' in Portuguese).
_RE_SRV_WORD = re.compile(r'^\s*servidor\b', re.I)


def normalize_server(s):
    """Accepts alternative field names (English or Portuguese) and infers the type if missing."""
    out = dict(s)
    out['name'] = _RE_SRV_WORD.sub(common.L(30292), _pick(s, 'nome', 'name', 'title', 'label'),
                                   count=1) or common.L(30292)
    host = _pick(s, 'host', 'server', 'portal', 'portal_url', 'dns', 'base_url')
    user = _pick(s, 'username', 'user', 'login', 'usr')
    pw = _pick(s, 'password', 'pass', 'pwd')
    mac = _pick(s, 'mac', 'mac_address', 'stb_mac', 'macaddress')
    url = _pick(s, 'url', 'm3u', 'm3u_url', 'playlist', 'link', 'list')
    icon = _pick(s, 'icon', 'logo', 'thumb')

    srv_type = _TYPES.get(_pick(s, 'tipo', 'type', 'kind', 'mode').lower())
    if not srv_type:
        if mac and (host or url):
            srv_type = 'stalker'
        elif user and pw and (host or url):
            srv_type = 'xtream'
        elif url:
            srv_type = 'm3u'
        else:
            srv_type = 'invalid'

    if srv_type == 'xtream':
        if (not host or not user) and url:           # URL get.php?username=..&password=..
            m_u = re.search(r'[?&]username=([^&]+)', url)
            m_p = re.search(r'[?&]password=([^&]+)', url)
            if m_u and m_p:
                user = user or m_u.group(1)
                pw = pw or m_p.group(1)
                host = host or url
        if not (host and user and pw):
            srv_type = 'invalid'
        else:
            host = _norm_xt_host(host)
    elif srv_type == 'stalker':
        host = host or url
        if not (host and mac):
            srv_type = 'invalid'
        else:
            host = _add_scheme(host).rstrip('/')
            mac = _norm_mac(mac)
    elif srv_type == 'm3u':
        url = url or host
        if not url:
            srv_type = 'invalid'

    out.update(type=srv_type, host=host, username=user, password=pw, mac=mac, url=url, icon=icon)
    return out


def normalize_servers(servers):
    res = []
    for s in (servers or []):
        try:
            res.append(normalize_server(s))
        except Exception as e:
            log_warn('Invalid server ignored: ' + str(e))
            res.append({'name': common.L(30292), 'type': 'invalid'})
    return res


# ════════════════════════════════════════════════════════
#  XTREAM CODES
# ════════════════════════════════════════════════════════

def xt_api_url(srv, action=None, **params):
    q = [('username', srv['username']), ('password', srv['password'])]
    if action:
        q.append(('action', action))
    q.extend(params.items())
    return '{}/player_api.php?{}'.format(srv['host'], urlencode(q))


def xt_call(srv, action=None, ttl=300, force=False, **params):
    return http_get_json(xt_api_url(srv, action, **params), ttl=ttl, force=force)


def xt_stream_url(srv, kind, stream_id, ext):
    return '{}/{}/{}/{}/{}.{}'.format(srv['host'], kind,
                                      quote(srv['username'], safe=''),
                                      quote(srv['password'], safe=''), stream_id, ext)


def xt_from_m3u_url(url):
    """Xtream credentials from a get.php?username=..&password=.. URL (None if it is not one)."""
    m = re.match(r'^(https?://[^?#]+?)/(?:get|player_api|panel_api)\.php\?(.*)$', url or '', re.I)
    if not m:
        return None
    q = dict(parse_qsl(m.group(2)))
    if q.get('username') and q.get('password'):
        return {'host': m.group(1).rstrip('/'), 'username': q['username'], 'password': q['password']}
    return None


def conn_info(srv, ttl=10, timeout=3.0):
    """{'active','max','status'} of the Xtream account (or M3U with Xtream credentials); None if unknown."""
    xt = srv if srv.get('type') == 'xtream' else xt_from_m3u_url(srv.get('url', ''))
    if not xt:
        return None
    data = http_get_json(xt_api_url(xt), ttl=ttl, timeout=timeout, tries=1)
    ui = (data or {}).get('user_info') if isinstance(data, dict) else None
    if not isinstance(ui, dict):
        return None
    try:
        return {'active': int(ui.get('active_cons') or 0), 'max': int(ui.get('max_connections') or 0),
                'status': str(ui.get('status', ''))}
    except Exception:
        return None


def conn_infos(servers, budget=3.0):
    """Fetch connection info for all servers in parallel, never blocking for more than 'budget' s."""
    out = {}
    ex = ThreadPoolExecutor(max_workers=max(1, min(8, len(servers))))
    futs = {}
    for i, srv in enumerate(servers):
        if srv.get('type') in ('xtream', 'm3u'):
            futs[ex.submit(conn_info, srv, 10, budget)] = i
    done, _ = futures_wait(list(futs), timeout=budget)
    for f in done:
        try:
            r = f.result()
            if r:
                out[futs[f]] = r
        except Exception:
            pass
    ex.shutdown(wait=False)
    return out


def xt_account_info(srv):
    """player_api without action: account info (status, expiry, connections)."""
    return xt_call(srv, None, ttl=0, force=True)


def _b64_maybe(s):
    """Xtream EPG titles/descriptions usually come base64-encoded."""
    if not s or not isinstance(s, str):
        return s or ''
    t = s.strip()
    if len(t) < 4 or len(t) % 4 or not re.match(r'^[A-Za-z0-9+/]+={0,2}$', t):
        return s
    try:
        txt = base64.b64decode(t, validate=True).decode('utf-8')
    except Exception:
        return s
    if not txt or any(ord(c) < 32 and c not in '\r\n\t' for c in txt):
        return s
    return txt


def _ts(v):
    try:
        return int(v)
    except Exception:
        return 0


def _hhmm(epoch):
    return time.strftime('%H:%M', time.localtime(epoch))


def xt_epg_short(srv, stream_id, limit=3):
    data = xt_call(srv, 'get_short_epg', ttl=300, stream_id=stream_id, limit=limit)
    if not data:
        return None
    try:
        listings = data.get('epg_listings', [])
        if not listings:
            return None
        a = listings[0]
        title = _b64_maybe(a.get('title', '') or a.get('name', ''))
        if not title:
            return None
        desc = _b64_maybe(a.get('description', '') or a.get('plot', ''))
        start_ts = _ts(a.get('start_timestamp'))
        end_ts = _ts(a.get('stop_timestamp'))
        hours = ''
        if start_ts and end_ts:                       # timestamps (epoch) instead of text in the server timezone
            hours = '{}-{}'.format(_hhmm(start_ts), _hhmm(end_ts))
        else:
            s, e = str(a.get('start', '')), str(a.get('end', ''))
            if len(s) >= 16 and len(e) >= 16:
                hours = '{}-{}'.format(s[11:16], e[11:16])
        next_title = ''
        if len(listings) > 1:
            next_title = _b64_maybe(listings[1].get('title', '') or listings[1].get('name', ''))
        return {'title': title, 'description': desc, 'hours': hours, 'next_title': next_title}
    except Exception as e:
        log('EPG parse: ' + str(e))
    return None


def xt_epg_bulk(srv, stream_ids, max_items=60, budget=8.0, workers=5):
    """
    EPG for several channels in parallel, capped by item count and total time.
    Returns {stream_id: epg}. Channels beyond the limit/time get no EPG.
    """
    res = {}
    ids = list(stream_ids)[:max_items]
    if not ids:
        return res
    t_end = time.time() + budget

    def _one(sid):
        if time.time() > t_end:
            return sid, None
        return sid, xt_epg_short(srv, sid)

    with ThreadPoolExecutor(max_workers=max(1, workers)) as ex:
        for sid, epg in ex.map(_one, ids):
            if epg:
                res[sid] = epg
    return res


def xt_catchup_listings(srv, stream_id):
    """Finished programmes with archive (catch-up), most recent first."""
    data = xt_call(srv, 'get_simple_data_table', ttl=120, stream_id=stream_id)
    out = []
    now = time.time()
    for a in (data or {}).get('epg_listings', []):
        try:
            if str(a.get('has_archive', '0')) != '1':
                continue
            start_ts, end_ts = _ts(a.get('start_timestamp')), _ts(a.get('stop_timestamp'))
            if not start_ts or not end_ts or end_ts > now:
                continue
            out.append({'title': _b64_maybe(a.get('title', '')) or common.L(30235),
                        'description': _b64_maybe(a.get('description', '')),
                        'start': str(a.get('start', '')), 'start_ts': start_ts, 'end_ts': end_ts})
        except Exception:
            continue
    out.sort(key=lambda x: -x['start_ts'])
    return out


def xt_catchup_url(srv, stream_id, start_str, start_ts, end_ts):
    """/timeshift/user/pass/<minutes>/<YYYY-MM-DD:HH-MM>/<id>.ts (time in the server timezone)."""
    dur = max(1, int(math.ceil((end_ts - start_ts) / 60.0)))
    if len(start_str) >= 16:
        stamp = '{}:{}-{}'.format(start_str[:10], start_str[11:13], start_str[14:16])
    else:
        stamp = time.strftime('%Y-%m-%d:%H-%M', time.localtime(start_ts))
    return '{}/timeshift/{}/{}/{}/{}/{}.ts'.format(
        srv['host'], quote(srv['username'], safe=''), quote(srv['password'], safe=''),
        dur, stamp, stream_id)


# ════════════════════════════════════════════════════════
#  STALKER / MAG (MAC)
# ════════════════════════════════════════════════════════

_ST = {}                 # state per portal+mac: endpoint, token, ts
_st_lock = threading.Lock()
_TOKEN_TTL = 1500


def _st_key(host, mac):
    return host.strip().rstrip('/') + '|' + mac.upper()


def stalker_base(host):
    """Portal root without '/c' (compatible with the previous version)."""
    base = host.rstrip('/')
    if base.endswith('/c'):
        base = base[:-2]
    return base


def _st_endpoints(host):
    h = host.strip().rstrip('/')
    if re.search(r'\.php$', h):
        return [h]
    b = re.sub(r'/c$', '', h)
    eps = [b + '/server/load.php', b + '/portal.php']
    if 'stalker_portal' not in b:
        eps.append(b + '/stalker_portal/server/load.php')
    return eps


def stalker_headers(mac, host=None, token=None):
    base = stalker_base(host) if host else 'http://localhost'
    h = {
        'User-Agent':   UA_STB,
        'X-User-Agent': 'Model: MAG250; Link: WiFi',
        'Cookie':       'mac={}; stb_lang=en; timezone=Europe/Belgrade'.format(mac),
        'Referer':      base + '/c/',
        'Accept':       '*/*',
    }
    if token:
        h['Authorization'] = 'Bearer ' + token
    return h


def _st_json(url, headers, timeout=15):
    txt = fetch_text(url, headers, timeout=timeout, tries=1)
    if not txt:
        return None
    try:
        return json.loads(txt)
    except Exception:
        i = txt.find('{')
        if i >= 0:
            try:
                return json.loads(txt[i:])
            except Exception:
                pass
    return None


def _st_profile(host, mac, ep, token):
    """Activate the STB profile (required by several portals after the handshake)."""
    try:
        sn = hashlib.md5(mac.encode()).hexdigest()[:13].upper()
        dev = hashlib.sha256(mac.encode()).hexdigest().upper()
        dev2 = hashlib.sha256(sn.encode()).hexdigest().upper()
        q = urlencode([
            ('type', 'stb'), ('action', 'get_profile'), ('hd', '1'),
            ('ver', 'ImageDescription: 0.2.18-r14-pub-250; ImageDate: Fri Jan 15 15:20:44 EET 2016; '
                    'PORTAL version: 5.5.0; API Version: JS API version: 328; STB API version: 134; '
                    'Player Engine version: 0x566'),
            ('num_banks', '2'), ('sn', sn), ('stb_type', 'MAG250'), ('client_type', 'STB'),
            ('image_version', '218'), ('video_out', 'hdmi'), ('device_id', dev), ('device_id2', dev2),
            ('signature', ''), ('auth_second_step', '1'), ('hw_version', '1.7-BD-00'),
            ('not_valid_token', '0'), ('hw_version_2', hashlib.sha1(mac.encode()).hexdigest()),
            ('api_signature', '262'), ('prehash', ''), ('JsHttpRequest', '1-xml'),
        ])
        _st_json(ep + '?' + q, stalker_headers(mac, host, token))
    except Exception as e:
        log('Stalker get_profile: ' + str(e))


def stalker_token(host, mac, force=False):
    """Portal token (with endpoint discovery and profile activation)."""
    key = _st_key(host, mac)
    with _st_lock:
        st = _ST.setdefault(key, {})
        if not force and st.get('token') and time.time() - st.get('ts', 0) < _TOKEN_TTL:
            return st['token']
        eps = _st_endpoints(host)
        if st.get('ep') in eps:
            eps.remove(st['ep'])
            eps.insert(0, st['ep'])
        for ep in eps:
            data = _st_json(ep + '?type=stb&action=handshake&token=&prehash=0&JsHttpRequest=1-xml',
                            stalker_headers(mac, host))
            js = (data or {}).get('js')
            token = js.get('token', '') if isinstance(js, dict) else ''
            if token:
                st.update(ep=ep, token=token, ts=time.time())
                _st_profile(host, mac, ep, token)
                log('Stalker token {} ({})'.format('renewed' if force else 'obtained', mask_url(ep)))
                return token
        log_warn('Stalker handshake failed')
        st.pop('token', None)
        return None


def _st_auth_error(data):
    if not data:
        return True
    js = data.get('js') if isinstance(data, dict) else None
    if isinstance(js, dict):
        err = str(js.get('error', '') or js.get('err', ''))
        if '458' in err or '459' in err or 'token' in err.lower() or 'author' in err.lower():
            return True
    return False


def stalker_call(host, mac, params, ttl=0, attempt=0):
    """
    Portal call. params: dict (or string 'a=b&c=d').
    ttl>0 => on-disk cache (never for create_link/handshake).
    Renews the token once on an authentication error.
    """
    token = stalker_token(host, mac, force=(attempt > 0))
    if not token:
        return None
    ep = _ST[_st_key(host, mac)]['ep']
    qs = params if isinstance(params, str) else urlencode(list(params.items()))
    ckey = None
    if ttl and attempt == 0:
        ckey = 'st|{}|{}|{}'.format(_st_key(host, mac), ep, qs)
        c = cache_get(ckey, ttl)
        if c is not None:
            try:
                return json.loads(c)
            except Exception:
                pass
    url = '{}?{}&token={}&JsHttpRequest=1-xml'.format(ep, qs, quote(token, safe=''))
    data = _st_json(url, stalker_headers(mac, host, token))
    if _st_auth_error(data) and attempt == 0:
        log_warn('Stalker: invalid/expired token — renewing')
        return stalker_call(host, mac, params, ttl=ttl, attempt=1)
    if data and ckey:
        cache_set(ckey, json.dumps(data, ensure_ascii=False))
    return data


def stalker_categories(host, mac, st_type):
    if st_type == 'itv':
        data = stalker_call(host, mac, {'type': 'itv', 'action': 'get_genres'}, ttl=600)
    else:
        data = stalker_call(host, mac, {'type': st_type, 'action': 'get_categories'}, ttl=600)
    if not data:
        return []
    cats = data.get('js', [])
    if isinstance(cats, dict):
        cats = list(cats.values())
    return [c for c in cats if isinstance(c, dict) and (c.get('title') or c.get('name'))]


def stalker_all_itv(host, mac):
    """All channels in a single call (much faster than paging). None if not supported."""
    data = stalker_call(host, mac, {'type': 'itv', 'action': 'get_all_channels'}, ttl=600)
    js = (data or {}).get('js')
    items = js.get('data') if isinstance(js, dict) else js
    if isinstance(items, list) and items:
        return items
    return None


def _st_page(host, mac, st_type, cat_id, page, extra=None):
    key = 'genre' if st_type == 'itv' else 'category'
    p = [('type', st_type), ('action', 'get_ordered_list'), (key, cat_id), ('p', page)]
    if st_type == 'itv':
        p.append(('sortby', 'number'))
    if extra:
        p.extend(extra.items())
    data = stalker_call(host, mac, dict(p), ttl=300)
    js = (data or {}).get('js')
    return js if isinstance(js, dict) else None


def stalker_channels(host, mac, st_type, cat_id, progress=None, search=None):
    """
    Items of a category. For itv it tries get_all_channels (1 request);
    otherwise it pages — the 1st page serially and the rest in parallel.
    """
    if st_type == 'itv' and not search:
        allc = stalker_all_itv(host, mac)
        if allc:
            if cat_id in ('*', '', None):
                return allc
            if any('tv_genre_id' in c for c in allc[:50]):
                sel = [c for c in allc if str(c.get('tv_genre_id', '')) == str(cat_id)]
                log('Stalker all_channels: {} in genre {}'.format(len(sel), cat_id))
                return sel

    extra = {'search': search} if search else None
    js = _st_page(host, mac, st_type, cat_id, 1, extra)
    if not js:
        return []
    items = list(js.get('data', []) or [])
    total = int(js.get('total_items', 0) or 0)
    per = int(js.get('max_page_items', 0) or 0) or len(items) or 14
    if not items or total <= len(items):
        return items
    pages = min(int(math.ceil(total / float(per))), 300)
    if progress:
        progress(1, pages)
    remaining = list(range(2, pages + 1))
    workers = device_profile()['workers']

    def _get(p):
        j = _st_page(host, mac, st_type, cat_id, p, extra)
        return (j or {}).get('data', []) or []

    done = 1
    with ThreadPoolExecutor(max_workers=workers) as ex:
        for batch in ex.map(_get, remaining):
            items.extend(batch)
            done += 1
            if progress:
                progress(done, pages)
    log('Stalker {}: {} items ({} pages)'.format(st_type, len(items), pages))
    return items


def _extract_stream_id(cmd):
    m = re.search(r'[&?]stream=(\d+)', cmd)
    return m.group(1) if m else ''


def _fix_empty_stream(url, orig_cmd):
    if 'stream=&' in url or url.endswith('stream='):
        sid = _extract_stream_id(orig_cmd)
        if sid:
            url = url + sid if url.endswith('stream=') else url.replace('stream=&', 'stream=' + sid + '&')
    return url


_RE_CMD_PREFIX = re.compile(r'^(?:ffmpeg|ffrt\d?|auto|rtp|rtsp)\s+(?=\S)', re.I)


def _clean_cmd(cmd):
    cmd = (cmd or '').strip()
    cmd = _RE_CMD_PREFIX.sub('', cmd, count=1).strip()
    if ' ' in cmd:
        parts = cmd.split('?', 1)
        if len(parts) == 2:
            cmd = parts[0].replace(' ', '%20') + '?' + parts[1].replace(' ', '%20')
        else:
            cmd = cmd.replace(' ', '%20')
    return cmd


def _is_local(u):
    return 'localhost' in u or '127.0.0.1' in u


def stalker_create_link(host, mac, st_type, cmd, series=''):
    """
    Resolve the final link of a channel/movie/episode.
    If cmd is already a direct URL (not localhost) it is returned as is; otherwise
    create_link is called (mandatory for VOD and for 'localhost/ch/ID').
    """
    clean_cmd = _fix_empty_stream(_clean_cmd(cmd), cmd)
    if clean_cmd.startswith('http') and not _is_local(clean_cmd) and not series:
        return clean_cmd

    token = stalker_token(host, mac)
    if not token:
        return clean_cmd if clean_cmd.startswith('http') else None
    ep = _ST[_st_key(host, mac)]['ep']

    def _try(tok):
        q = urlencode([('type', st_type), ('action', 'create_link'), ('cmd', cmd),
                       ('series', str(series or '')), ('forced_storage', 'undefined'),
                       ('disable_ad', '0'), ('download', '0'),
                       ('token', tok), ('JsHttpRequest', '1-xml')])
        return _st_json(ep + '?' + q, stalker_headers(mac, host, tok))

    data = _try(token)
    if _st_auth_error(data):
        token = stalker_token(host, mac, force=True)
        data = _try(token) if token else None
    js = (data or {}).get('js', {})
    url = (js.get('url', '') or js.get('cmd', '')) if isinstance(js, dict) else ''
    url = _fix_empty_stream(_clean_cmd(url), cmd) if url else ''
    if url and not _is_local(url):
        log('Stalker create_link OK: ' + mask_url(url[:80]))
        return url
    log_warn('Stalker create_link failed')
    return clean_cmd if clean_cmd.startswith('http') and not _is_local(clean_cmd) else None


def stalker_abs(host, path):
    """Relative portal logos/posters -> absolute URL."""
    if not path:
        return ''
    p = path.strip().replace(' ', '%20')
    if p.startswith(('http://', 'https://')):
        return p
    sp = urlsplit(_add_scheme(host))
    if p.startswith('/'):
        return '{}://{}{}'.format(sp.scheme, sp.netloc, p)
    return '{}://{}/{}'.format(sp.scheme, sp.netloc, p)


# ════════════════════════════════════════════════════════
#  M3U / M3U_plus  — on-disk index (groups + offsets)
# ════════════════════════════════════════════════════════
#
#  The playlist is downloaded to disk, parsed as a stream and stored in
#  'entries.jsonl' (1 entry per line). Only the per-group offsets are kept in
#  memory. Opening a group reads just that group's lines => low RAM usage
#  even with playlists of 100k+ entries (old Android boxes).

_RE_ATTR = re.compile(r'([A-Za-z0-9_\-\.]+)\s*=\s*(?:"([^"]*)"|\'([^\']*)\'|([^\s,"\']+))')


def _kind_from(url, group):
    u = url.lower().split('?', 1)[0].split('|', 1)[0]
    if '/series/' in u:
        return 's'
    if '/movie/' in u:
        return 'm'
    if u.endswith(('.mp4', '.mkv', '.avi', '.mov', '.wmv', '.flv', '.mpg', '.mpeg', '.m4v')):
        return 'm'
    return 'l'


def iter_m3u(lines):
    """Yields dicts {n,u,l,g,i,k,ua,ref} from M3U/M3U_plus lines."""
    pend = {}
    opts = {}
    for raw in lines:
        line = raw.strip()
        if not line:
            continue
        if line.startswith('#EXTINF'):
            rest = line[8:] if line.startswith('#EXTINF:') else line[7:]
            attrs = {}
            last_end = 0
            for m in _RE_ATTR.finditer(rest):
                attrs[m.group(1).lower()] = (m.group(2) if m.group(2) is not None
                                             else m.group(3) if m.group(3) is not None
                                             else m.group(4) or '')
                last_end = m.end()
            i = rest.find(',', last_end)
            name = rest[i + 1:].strip() if i >= 0 else ''
            pend = {'n': name or attrs.get('tvg-name', '') or common.L(30286),
                    'l': attrs.get('tvg-logo', '') or attrs.get('logo', ''),
                    'g': (attrs.get('group-title', '') or '').strip(),
                    'i': attrs.get('tvg-id', '')}
            opts = {}
        elif line.startswith('#EXTGRP:'):
            pend['g'] = pend.get('g') or line[8:].strip()
        elif line.startswith('#EXTVLCOPT:'):
            k, _, v = line[11:].partition('=')
            k = k.strip().lower()
            if k == 'http-user-agent':
                opts['ua'] = v.strip()
            elif k in ('http-referrer', 'http-referer'):
                opts['ref'] = v.strip()
        elif line.startswith('#'):
            continue
        else:
            if not pend:
                pend = {'n': line.rsplit('/', 1)[-1] or common.L(30286), 'l': '', 'g': '', 'i': ''}
            pend['u'] = line
            pend['g'] = pend.get('g') or common.L(30289)
            pend['k'] = _kind_from(line, pend['g'])
            pend.update(opts)
            yield pend
            pend, opts = {}, {}


class M3UStore(object):
    """Persistent index of an M3U playlist (http(s) URL, local file or special://)."""

    def __init__(self, src):
        self.src = src
        self.dir = temp_dir('ontv_m3u/' + hashlib.sha1(src.encode('utf-8')).hexdigest()[:16])
        self.meta_path = os.path.join(self.dir, 'meta.json')
        self.data_path = os.path.join(self.dir, 'entries.jsonl')
        self._meta = None

    # ── state ────────────────────────────────────────
    def meta(self):
        if self._meta is None:
            try:
                with io.open(self.meta_path, 'r', encoding='utf-8') as f:
                    self._meta = json.load(f)
            except Exception:
                self._meta = {}
        return self._meta

    def is_fresh(self, ttl):
        m = self.meta()
        return bool(m.get('groups') is not None and m.get('ts') and time.time() - m['ts'] < ttl
                    and os.path.exists(self.data_path))

    # ── build ────────────────────────────────────────
    def _download(self, dest, progress=None):
        src = self.src
        if not src.lower().startswith(('http://', 'https://')):
            if common.IN_KODI:
                import xbmcvfs
                if not xbmcvfs.copy(src, dest):
                    raise IOError('Could not read ' + src)
            else:
                shutil.copyfile(src.replace('file://', ''), dest)
            return
        url, _, hdr = src.partition('|')
        headers = {'Accept-Encoding': 'gzip, identity'}
        if hdr:
            for kv in hdr.split('&'):
                k, _, v = kv.partition('=')
                if k:
                    headers[k] = v
        resp = open_url(url, headers, timeout=30)
        try:
            first = resp.read(2)
            stream = io.BufferedReader(_Chain(first, resp)) if first else resp
            if first == b'\x1f\x8b':
                stream = gzip.GzipFile(fileobj=stream)
            total = 0
            with open(dest, 'wb') as out:
                while True:
                    chunk = stream.read(262144)
                    if not chunk:
                        break
                    out.write(chunk)
                    total += len(chunk)
                    if progress:
                        progress(total)
        finally:
            resp.close()

    def build(self, progress=None):
        """Download + parse + index. Raises an exception on network error."""
        raw = os.path.join(self.dir, 'raw.m3u')
        self._download(raw, progress)

        groups = OrderedDict()
        total = 0
        adult_g = {}
        tmp_data = self.data_path + '.new'
        with io.open(raw, 'r', encoding='utf-8-sig', errors='replace') as src, \
                open(tmp_data, 'wb') as out:
            for e in iter_m3u(src):
                g = e['g']
                ag = adult_g.get(g)
                if ag is None:
                    ag = adult_g[g] = is_adult(g)
                if ag or is_adult(e['n']):
                    continue
                off = out.tell()
                out.write((json.dumps(e, ensure_ascii=False, separators=(',', ':')) + '\n').encode('utf-8'))
                key = (e['k'], g)
                gr = groups.get(key)
                if gr is None:
                    gr = groups[key] = {'n': g, 'k': e['k'], 'c': 0, 'l': e.get('l', ''), 'o': []}
                if not gr['l'] and e.get('l'):
                    gr['l'] = e['l']
                gr['c'] += 1
                gr['o'].append(off)
                total += 1
        try:
            os.remove(raw)
        except Exception:
            pass
        if not total:
            try:
                os.remove(tmp_data)
            except Exception:
                pass
            raise ValueError('Empty or invalid M3U playlist')
        os.replace(tmp_data, self.data_path)
        meta = {'ts': time.time(), 'src': mask_url(self.src), 'total': total,
                'groups': list(groups.values())}
        common.atomic_write(self.meta_path, json.dumps(meta, ensure_ascii=False, separators=(',', ':')))
        self._meta = meta
        log('M3U indexed: {} entries, {} groups'.format(total, len(groups)))
        return meta

    # ── query ───────────────────────────────────────
    def kinds(self):
        return sorted(set(g['k'] for g in self.meta().get('groups', [])))

    def groups(self, kind=None):
        gs = self.meta().get('groups', [])
        return [g for g in gs if kind is None or g['k'] == kind]

    def entries(self, kind, group):
        for g in self.meta().get('groups', []):
            if g['k'] == kind and g['n'] == group:
                with open(self.data_path, 'rb') as f:
                    for off in g['o']:
                        f.seek(off)
                        try:
                            yield json.loads(f.readline().decode('utf-8'))
                        except Exception:
                            continue
                return

    def search(self, term, limit=500):
        term = term.lower()
        t_b = term.encode('utf-8')
        out = []
        with open(self.data_path, 'rb') as f:
            for line in f:
                if t_b in line.lower():
                    try:
                        e = json.loads(line.decode('utf-8'))
                    except Exception:
                        continue
                    if term in e.get('n', '').lower():
                        out.append(e)
                        if len(out) >= limit:
                            break
        return out


class _Chain(io.RawIOBase):
    """Rebuilds a stream after its beginning has been read (to detect gzip)."""

    def __init__(self, first, resp):
        self._first = first
        self._resp = resp

    def readable(self):
        return True

    def readinto(self, b):
        if self._first:
            n = min(len(b), len(self._first))
            b[:n] = self._first[:n]
            self._first = self._first[n:]
            return n
        data = self._resp.read(len(b))
        n = len(data)
        b[:n] = data
        return n

