# -*- coding: utf-8 -*-
"""
OnTV — persistent Favourites and Recents.

Stored in addon_data (NOT in special://temp, which Kodi/Android may wipe).
Automatically migrates the old file from special://temp.
Atomic writes; reads use an in-memory cache (validated against the file's mtime,
so it works with reuselanguageinvoker).
"""
import hashlib
import json
import os
import time

import common

_FAV = 'ontv_favourites.json'
_HIST = 'ontv_history.json'
_HIST_MAX = 30
_mem = {}

# Entries saved by older builds used Portuguese keys; they are upgraded on load.
_LEGACY_KEYS = {'nome': 'name', 'tipo': 'type', 'stalker_tipo': 'stalker_type'}


def _upgrade(entry):
    if isinstance(entry, dict):
        for old_key, new_key in _LEGACY_KEYS.items():
            if old_key in entry and new_key not in entry:
                entry[new_key] = entry.pop(old_key)
    return entry


def _path(name):
    return os.path.join(common.profile_dir(), name)


def _load(name):
    p = _path(name)
    try:
        mt = os.path.getmtime(p)
    except OSError:
        mt = None
    c = _mem.get(name)
    if c and c[0] == mt:
        return c[1]
    data = []
    if mt is not None:
        try:
            with open(p, 'r', encoding='utf-8') as f:
                data = [_upgrade(e) for e in json.load(f)]
        except Exception:
            data = []
    _mem[name] = (mt, data)
    return data


def _save(name, data):
    try:
        common.atomic_write(_path(name), json.dumps(data, ensure_ascii=False, indent=1))
        _mem[name] = (os.path.getmtime(_path(name)), data)
    except Exception as e:
        common.log('favourites: error saving: ' + str(e))


def migrate_legacy():
    """Copy favourites from special://temp (versions <= 1.0.7) if not yet present in the profile."""
    try:
        new = _path(_FAV)
        old = os.path.join(common.temp_dir(), 'ontv_favourites.json')
        if not os.path.exists(new) and os.path.exists(old):
            with open(old, 'r', encoding='utf-8') as f:
                data = json.load(f)
            if data:
                _save(_FAV, data)
                common.log('Favourites migrated: {}'.format(len(data)), None)
    except Exception as e:
        common.log('migrate favourites: ' + str(e))


def _make_id(name, url):
    return hashlib.md5((name + (url or '')).encode('utf-8')).hexdigest()[:12]


# ── Favourites ───────────────────────────────────────────────
def list_all():
    return sorted(_load(_FAV), key=lambda x: x.get('name', '').lower())


def add(name, url='', logo='', media_type='video', **kwargs):
    favs = list(_load(_FAV))
    fid = _make_id(name, url or kwargs.get('cmd', '') or kwargs.get('series_id', ''))
    if any(f['id'] == fid for f in favs):
        return False
    fav = {'id': fid, 'name': name, 'url': url, 'logo': logo, 'type': media_type, 'ts': time.time()}
    fav.update({k: v for k, v in kwargs.items() if v})
    favs.append(fav)
    _save(_FAV, favs)
    return True


def remove(fid):
    favs = _load(_FAV)
    new = [f for f in favs if f['id'] != fid]
    if len(new) < len(favs):
        _save(_FAV, new)
        return True
    return False


def exists(name, url=''):
    fid = _make_id(name, url)
    return any(f['id'] == fid for f in _load(_FAV))


def count():
    return len(_load(_FAV))


# ── Recents ────────────────────────────────────────────────
def hist_add(entry):
    """entry: dict with name, logo, type and the fields needed to play it again (url | srv_idx+cmd...)."""
    h = [e for e in _load(_HIST) if e.get('id') != entry.get('id')]
    entry = dict(entry, ts=time.time())
    h.insert(0, entry)
    _save(_HIST, h[:_HIST_MAX])


def hist_list():
    return list(_load(_HIST))


def hist_clear():
    _save(_HIST, [])
