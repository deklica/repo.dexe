# -*- coding: utf-8 -*-
# OnTV — background service
#
#  - Hosts the local streaming engine (proxy) in an always-running process
#  - Proxy watchdog
#  - Releases the server connection as soon as playback stops (single-connection accounts)
#  - Automatic fallback to direct playback if the proxy fails when a channel starts
#  - Restores DNS, migrates favourites, prunes old caches

import os
import sys
import threading
import time

import xbmc
import xbmcaddon
import xbmcgui

ADDON = xbmcaddon.Addon()
_LIB = os.path.join(ADDON.getAddonInfo('path'), 'resources', 'lib')
if _LIB not in sys.path:
    sys.path.insert(0, _LIB)

import common
import proxy
from common import L

PROP_LAST = 'ontv.last_play'      # JSON of the last playback request (for the fallback)


def log(msg, level=xbmc.LOGINFO):
    xbmc.log('[OnTV Service] ' + str(msg), level)


def _activate_dns():
    """Restore the chosen DNS (file in the profile; also reads the old location in temp)."""
    try:
        provider = ''
        for p in (os.path.join(common.profile_dir(), 'ontv_dns_provider.txt'),
                  os.path.join(common.temp_dir(), 'ontv_dns_provider.txt')):
            if os.path.exists(p):
                with open(p, 'r') as f:
                    provider = f.read().strip()
                break
        if provider and provider not in ('system', 'sistema'):     # 'sistema': value saved by older builds
            import dns_override
            dns_override.activate(provider)
            log('DNS enabled: ' + provider)
    except Exception as e:
        log('DNS warning: ' + str(e), xbmc.LOGWARNING)


def _maintenance():
    try:
        import favourites
        favourites.migrate_legacy()
    except Exception as e:
        log('Favourites warning: ' + str(e), xbmc.LOGWARNING)
    try:
        common.cache_prune()
    except Exception as e:
        log('Cache warning: ' + str(e), xbmc.LOGWARNING)
    try:
        from mediacfg import invalidate_cache
        invalidate_cache()
    except Exception as e:
        log('Servers warning: ' + str(e), xbmc.LOGWARNING)


class OnTVPlayer(xbmc.Player):
    def __init__(self):
        xbmc.Player.__init__(self)
        self._t_start = 0
        self._via_proxy = False
        self._retried = False

    def _is_ours(self):
        try:
            f = self.getPlayingFile()
        except Exception:
            return False
        self._via_proxy = f.startswith('http://127.0.0.1:') and ('/live.' in f or '/vod.' in f)
        return self._via_proxy

    def onAVStarted(self):
        self._t_start = time.time()
        self._is_ours()

    def onPlayBackStarted(self):
        self._t_start = time.time()
        self._retried = False

    def _release(self):
        # Only cancel connections older than 2s: protects a new channel that has just started
        proxy.cancel_all(older_than=time.time() - 2.0)
        t = threading.Timer(3.0, lambda: proxy.cancel_all(older_than=time.time() - 2.0))
        t.daemon = True
        t.start()

    def onPlayBackStopped(self):
        self._release()

    def onPlayBackEnded(self):
        self._release()

    def onPlayBackError(self):
        log('Playback error reported by Kodi', xbmc.LOGWARNING)
        self._release()
        self._fallback()

    def _fallback(self):
        """If the proxy failed, try direct playback once (Auto engine only)."""
        if self._retried or common.setting_int('engine', 0) != 0:
            self._warn()
            return
        self._retried = True
        try:
            import json
            raw = xbmcgui.Window(10000).getProperty(PROP_LAST)
            if not raw:
                return self._warn()
            d = json.loads(raw)
            if d.get('engine') != 'proxy' or d.get('kind') != 'live':
                return self._warn()
            import playback
            path, li, eng = playback.build(d['url'], d.get('name', ''), d.get('logo', ''),
                                           kind='live', headers=d.get('h'), engine='direct')
            log('Fallback: proxy failed — trying direct playback')
            xbmcgui.Dialog().notification('OnTV', L(30287),
                                          xbmcgui.NOTIFICATION_INFO, 2500)
            self.play(path, li)
        except Exception as e:
            log('Fallback failed: ' + str(e), xbmc.LOGWARNING)

    def _warn(self):
        xbmcgui.Dialog().notification(
            'OnTV', L(30288),
            xbmcgui.NOTIFICATION_WARNING, 5000)


class OnTVMonitor(xbmc.Monitor):
    def onSettingsChanged(self):
        log('Settings changed')


def run():
    log('Service started (RAM={}MB, profile={})'.format(common.ram_mb(), common.device_tier()))
    monitor = OnTVMonitor()
    _activate_dns()
    port = proxy.start_server()
    log('Proxy on port {}'.format(port))
    threading.Thread(target=_maintenance, daemon=True).start()
    player = OnTVPlayer()                                   # keep a live reference

    n = 0
    while not monitor.waitForAbort(5):
        n += 1
        if not proxy._alive(proxy.get_port()):
            log('Proxy not responding — restarting', xbmc.LOGWARNING)
            proxy.stop_server()
            port = proxy.start_server()
        if n % 720 == 0:                                    # ~1h
            try:
                common.cache_prune()
            except Exception:
                pass

    proxy.stop_server()
    log('Service stopped')


if __name__ == '__main__':
    run()
