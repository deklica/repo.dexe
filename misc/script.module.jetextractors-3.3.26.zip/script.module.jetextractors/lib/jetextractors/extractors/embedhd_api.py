from ..models import *
from .._core import fetch_page, get_session, get_headers, find_m3u8
from ..util.stream_proxy import get_stream_proxy
from ..util import embedsportstop
from typing import Optional, List, Tuple
import requests
import time
import xbmc
import re
import base64
from ..tools import debug_log
from datetime import datetime
from urllib.parse import urljoin, urlparse


def _ffmpegdirect_live() -> JetInputstreamFFmpegDirect:
    """inputstream.ffmpegdirect in stream_mode='live' (NOT the 'timeshift' default).

    Streams served on strmd.st (lb{1-19}.*) use fresh rotation tokens per
    manifest. In stream_mode='timeshift' (what JetInputstreamFFmpegDirect.default()
    uses) FFmpeg's read thread blocks and the CDN 403s segment fetches through
    the proxy (see ISSUE_FREEZE.md / streamed.py). Live mode keeps segment
    requests flowing and mirrors the working StreamedExtractor config.
    """
    return JetInputstreamFFmpegDirect(manifest_type="hls", is_realtime_stream=True, stream_mode="live")


_STREAMED_TV_UA = (
    "Mozilla/5.0 (SMART-TV; Linux; Tizen 6.0) AppleWebKit/537.36 "
    "(KHTML, like Gecko) SamsungBrowser/16.0 TV Safari/537.36"
)

class EmbedHDApi(JetExtractor):
    def __init__(self) -> None:
        self.domains = ["https://rockystream.st"]
        self.name = "EmbedHD API"
        self.timeout = 15
        self.api_url = "https://rockystream.st/api-event.php"
        self.events_cache: List[dict] = []
        self.last_refresh: float = 0.0
        self._proxy = None
        self.user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"

    def _get_session_headers(self, referer: str = "https://rockystream.st/", origin: str = "https://rockystream.st") -> dict:
        return {
            "User-Agent": self.user_agent,
            "Referer": referer,
            "Origin": origin,
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        }

    def _get_proxy(self):
        if self._proxy is None:
            manifest_headers = {
                "User-Agent": _STREAMED_TV_UA,
                "Referer": "https://embed.st/",
                "Origin": "https://embed.st",
            }
            self._proxy = get_stream_proxy(
                "embedhd_api",
                manifest_headers,
                options={
                    "cache_manifest": False,
                    "proxy_absolute_urls": True,
                    # strmd.st (lb{1-19}) rejects Chrome desktop UA + close-per-request
                    # segment fetches with 403. Mirror streamed.py: Samsung TV UA and
                    # reuse upstream connections + prefetch so segment requests look
                    # like a real TV player.
                    "user_agent": _STREAMED_TV_UA,
                    "upstream_keep_alive": True,
                    "prefetch_segments": True,
                    "keep_alive": False,
                },
            )
        return self._proxy

    def _fetch_events(self) -> bool:
        now = time.time()
        if self.events_cache and (now - self.last_refresh) < 45:
            return True
        try:
            headers = self._get_session_headers()
            r = get_session().get(
                 self.api_url,
                 headers=headers,
                 timeout=self.timeout,
                 verify=False,
             )
            if r.status_code == 200:
                data = r.json()
                matches = data.get("matches", [])
                if matches:
                    self.events_cache = matches
                    self.last_refresh = now
                    debug_log(f"[EmbedHDApi] Loaded {len(matches)} events from API", xbmc.LOGINFO)
                    return True
        except Exception as e:
            debug_log(f"[EmbedHDApi] Failed to fetch events: {e}", xbmc.LOGWARNING)
        return False

    def _get_category_label(self, category: str) -> str:
        category_map = {
            "baseball": "MLB",
            "american-football": "NFL",
            "football": "Soccer",
            "motor-sports": "Motorsport",
            "fight": "UFC/Fight",
        }
        return category_map.get(category, category.upper())

    def _follow_iframe_to_m3u8(self, start_url: str) -> Tuple[Optional[str], Optional[str]]:
        session = requests.Session()
        session.headers.update({
            "User-Agent": self.user_agent,
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.9",
            "DNT": "1",
            "Connection": "keep-alive",
            "Upgrade-Insecure-Requests": "1",
            "Sec-Fetch-Dest": "document",
            "Sec-Fetch-Mode": "navigate",
            "Sec-Fetch-Site": "none",
            "Sec-Fetch-User": "?1",
        })
        session.verify = False
        current_url = start_url
        visited = set()
        
        for depth in range(5):
            if current_url in visited:
                break
            visited.add(current_url)

            embed_hosts = ("embed.st", "embedsports.top", "pooembed", "embedindia")
            if any(h in urlparse(current_url).netloc for h in embed_hosts):
                try:
                    stream_url = embedsportstop.get_embedsportstop_stream(current_url)
                    if stream_url:
                        cookies = "; ".join(f"{c.name}={c.value}" for c in session.cookies)
                        debug_log(f"[EmbedHDApi] Resolved via embedsportstop: {stream_url[:100]}", xbmc.LOGINFO)
                        return stream_url, cookies
                except Exception as e:
                    debug_log(f"[EmbedHDApi] embedsportstop failed: {e}", xbmc.LOGDEBUG)
            
            try:
                req_headers = session.headers.copy()
                parsed = urlparse(current_url)
                req_headers["Referer"] = current_url
                req_headers["Origin"] = f"{parsed.scheme}://{parsed.netloc}"
                
                r = session.get(current_url, headers=req_headers, timeout=self.timeout)
                if r.status_code != 200:
                    debug_log(f"[EmbedHDApi] Chain depth {depth} returned {r.status_code}: {current_url}", xbmc.LOGDEBUG)
                    return None, None
                
                html = r.text
                
                m3u8_match = re.search(r'["\'](https?://[^"\']+\.m3u8(?:\?[^"\']*)?)["\']', html)
                if m3u8_match:
                    cookies = "; ".join(f"{c.name}={c.value}" for c in session.cookies)
                    return m3u8_match.group(1), cookies
                
                m3u8_found = find_m3u8(html, current_url)
                if m3u8_found:
                    cookies = "; ".join(f"{c.name}={c.value}" for c in session.cookies)
                    debug_log(f"[EmbedHDApi] Extracted m3u8 via find_m3u8: {m3u8_found[:100]}", xbmc.LOGINFO)
                    return m3u8_found, cookies
                
                return_match = re.search(r'return\(\[([^\]]+)\]', html)
                if return_match:
                    try:
                        m3u8 = "".join(eval("[" + return_match.group(1) + "]")).replace("\\", "").replace("////", "//")
                        if m3u8 and ".m3u8" in m3u8:
                            cookies = "; ".join(f"{c.name}={c.value}" for c in session.cookies)
                            debug_log(f"[EmbedHDApi] Extracted m3u8 from return([...]): {m3u8[:100]}", xbmc.LOGINFO)
                            return m3u8, cookies
                    except Exception:
                        pass

                atob_match = re.search(r'atob\(\s*["\']([A-Za-z0-9+/=]+)["\']\s*\)', html)
                if atob_match:
                    try:
                        decoded = base64.b64decode(atob_match.group(1)).decode("utf-8")
                    except Exception:
                        decoded = None
                    if decoded and decoded.startswith("http"):
                        current_url = decoded.split("#", 1)[0]
                        debug_log(f"[EmbedHDApi] Decoded atob iframe: {current_url[:100]}", xbmc.LOGINFO)
                        continue
                
                fid_match = re.search(r'window\.fid=["\']([^"\']+)["\']', html)
                if fid_match:
                    fid = fid_match.group(1)
                    embed_url = f"https://exposestrat.com/maestrohd1.php?player=desktop&live={fid}"
                    if embed_url not in visited:
                        current_url = embed_url
                        debug_log(f"[EmbedHDApi] Found fid={fid}, following to {embed_url}", xbmc.LOGINFO)
                        continue
                
                iframe_match = re.search(r'<iframe[^>]+src=["\']([^"\']+)["\']', html, re.IGNORECASE)
                if iframe_match:
                    next_url = iframe_match.group(1)
                    if not next_url.startswith("http"):
                        next_url = urljoin(current_url, next_url)
                    current_url = next_url
                    continue
                
                ref_id_match = re.search(r'window\.[a-zA-Z_]+\.src=[\'"]([^"\']+)[\'"]', html)
                if ref_id_match:
                    cookies = "; ".join(f"{c.name}={c.value}" for c in session.cookies)
                    return ref_id_match.group(1), cookies
                
                cdn_url = self._extract_cdn_url(html)
                if cdn_url:
                    cookies = "; ".join(f"{c.name}={c.value}" for c in session.cookies)
                    debug_log(f"[EmbedHDApi] Constructed CDN URL from page: {cdn_url[:100]}", xbmc.LOGINFO)
                    return cdn_url, cookies
                
                break
            
            except Exception as e:
                debug_log(f"[EmbedHDApi] Chain error: {e}", xbmc.LOGDEBUG)
                return None, None
        
        return None, None

    def _extract_cdn_url(self, html: str) -> Optional[str]:
        channel_match = re.search(r"channelId\s*:\s*['\"]([^'\"]+)['\"]", html)
        if channel_match:
            channel = channel_match.group(1)
            return f"https://{channel}.m3u8"
        fid_match = re.search(r'window\.fid=["\']([^"\']+)["\']', html)
        if fid_match:
            fid = fid_match.group(1)
            return f"https://cdn11.zohanayaan.com:1686/hls/{fid}.m3u8"
        return None

    def _proxy_link(self, stream_url: str, cookies: Optional[str] = None, refresh_callback: Optional[callable] = None) -> JetLink:
        proxy = self._get_proxy()
        headers = {
            "User-Agent": _STREAMED_TV_UA,
            "Referer": "https://embed.st/",
            "Origin": "https://embed.st",
        }
        if cookies:
            headers["Cookie"] = cookies
        proxy_url = proxy.get_proxy_url(stream_url, headers, refresh_callback=refresh_callback)
        debug_log(f"[EmbedHDApi] Proxy URL: {proxy_url}", xbmc.LOGINFO)
        return JetLink(
            address=proxy_url,
            inputstream=_ffmpegdirect_live(),
        )

    def get_items(self, params: Optional[dict] = None, progress: Optional[JetExtractorProgress] = None) -> List[JetItem]:
        items: List[JetItem] = []
        if self.progress_init(progress, items):
            return items

        if not self._fetch_events():
            return items

        for event in self.events_cache:
            title = event.get("title", "")
            if not title:
                continue

            status = event.get("status", "")
            category = event.get("category", "")
            league = event.get("league", "")
            ts_et = event.get("ts_et", 0)
            
            starttime = None
            if ts_et and ts_et > 0:
                try:
                    starttime = datetime.fromtimestamp(ts_et)
                except Exception:
                    pass

            streams = event.get("streams", [])
            if not streams:
                continue

            for s in streams:
                if not isinstance(s, dict):
                    continue
                stream_url = s.get("link")
                if not stream_url:
                    continue
                
                link = JetLink(address=stream_url)
                
                item = JetItem(
                    title=title,
                    links=[link],
                    starttime=starttime,
                    status=status,
                    league=league or self._get_category_label(category),
                )
                items.append(item)
                break

        debug_log(f"[EmbedHDApi] Total items: {len(items)}", xbmc.LOGINFO)
        return items

    def get_link(self, url: JetLink) -> JetLink:
        source_address = url.address

        def _refresh_callback():
            fresh_url, fresh_cookies = self._follow_iframe_to_m3u8(source_address)
            if not fresh_url:
                return None
            headers = {
                "User-Agent": _STREAMED_TV_UA,
                "Referer": "https://embed.st/",
                "Origin": "https://embed.st",
            }
            if fresh_cookies:
                headers["Cookie"] = fresh_cookies
            return {"url": fresh_url, "headers": headers}

        cdn_url, cookies = self._follow_iframe_to_m3u8(url.address)
        if not cdn_url:
            debug_log("[EmbedHDApi] Failed to resolve m3u8 from chain", xbmc.LOGWARNING)
            return JetLink(address=url.address)
        debug_log(f"[EmbedHDApi] Resolved m3u8: {cdn_url[:100]}", xbmc.LOGINFO)
        return self._proxy_link(cdn_url, cookies, refresh_callback=_refresh_callback)