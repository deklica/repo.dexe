# -*- coding: utf-8 -*-
# OnTV — entry point (compativel com reuselanguageinvoker)
import os
import sys

import xbmcaddon

_LIB = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'lib')
if _LIB not in sys.path:
    sys.path.insert(0, _LIB)

import navigator

if __name__ == '__main__':
    navigator.run()
