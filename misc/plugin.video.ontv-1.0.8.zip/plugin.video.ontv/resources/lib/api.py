# -*- coding: utf-8 -*-
"""
OnTV — API de fontes: Xtream Codes, Stalker/MAG (MAC) e M3U/M3U_plus.

Nao depende do HANDLE do plugin, por isso pode ser usado pelo proxy
(que corre no servico) para renovar links Stalker.
"""

import base64
import hashlib
import io
import gzip
import json
import math
import os
import re
import shutil
import threading
import time
from collections import OrderedDict
from concurrent.futures import ThreadPoolExecutor, wait as futures_wait
from urllib.parse import urlencode, quote, urlsplit, parse_qsl

import common
from common import (log, log_warn, mascarar, http_get_json, fetch_text, open_url,
                    cache_get, cache_set, e_adulto, temp_dir, device_profile,
                    setting_int, UA_STB)


# ════════════════════════════════════════════════════════
#  Normalizacao de servidores (aliases de campos e tipos)
# ════════════════════════════════════════════════════════

_TIPOS = {
    'xtream': 'xtream', 'xc': 'xtream', 'xtreamcodes': 'xtream', 'xtream_codes': 'xtream',
    'xtream-codes': 'xtream', 'xtream codes': 'xtream', 'iptv': 'xtream',
    'stalker': 'stalker', 'portal': 'stalker', 'mag': 'stalker', 'stb': 'stalker',
    'mac': 'stalker', 'ministra': 'stalker', 'stalker_portal': 'stalker', 'mag/stb': 'stalker',
    'm3u': 'm3u', 'm3u8': 'm3u', 'm3u_plus': 'm3u', 'm3uplus': 'm3u', 'm3u-plus': 'm3u',
    'playlist': 'm3u', 'list': 'm3u', 'url': 'm3u',
}


def _pick(s, *keys):
    for k in keys:
        v = s.get(k)
        if v is not None and str(v).strip() != '':
            return str(v).strip()
    return ''


def _norm_mac(m):
    hexs = re.sub(r'[^0-9A-Fa-f]', '', m)
    if len(hexs) == 12:
        return ':'.join(hexs[i:i + 2] for i in range(0, 12, 2)).upper()
    return m.strip().upper()


def _add_scheme(h):
    h = h.strip()
    if not re.match(r'^[a-z][a-z0-9+.\-]*://', h, re.I):
        h = 'http://' + h
    return h


def _norm_xt_host(h):
    h = _add_scheme(h)
    sp = urlsplit(h)
    path = sp.path
    for _ in range(3):
        path = re.sub(r'/(?:player_api\.php|get\.php|panel_api\.php|xmltv\.php|c)/?$', '', path)
    return '{}://{}{}'.format(sp.scheme, sp.netloc, path.rstrip('/'))


def normalizar_servidor(s):
    """Aceita nomes de campos alternativos e infere o tipo se faltar."""
    out = dict(s)
    out['nome'] = _pick(s, 'nome', 'name', 'title', 'label') or common.L(30292)
    host = _pick(s, 'host', 'server', 'portal', 'portal_url', 'dns', 'base_url')
    user = _pick(s, 'username', 'user', 'login', 'usr')
    pw = _pick(s, 'password', 'pass', 'pwd')
    mac = _pick(s, 'mac', 'mac_address', 'stb_mac', 'macaddress')
    url = _pick(s, 'url', 'm3u', 'm3u_url', 'playlist', 'link', 'list')
    icon = _pick(s, 'icon', 'logo', 'thumb')

    tipo = _TIPOS.get(_pick(s, 'tipo', 'type', 'kind', 'mode').lower())
    if not tipo:
        if mac and (host or url):
            tipo = 'stalker'
        elif user and pw and (host or url):
            tipo = 'xtream'
        elif url:
            tipo = 'm3u'
        else:
            tipo = 'invalido'

    if tipo == 'xtream':
        if (not host or not user) and url:           # URL get.php?username=..&password=..
            m_u = re.search(r'[?&]username=([^&]+)', url)
            m_p = re.search(r'[?&]password=([^&]+)', url)
            if m_u and m_p:
                user = user or m_u.group(1)
                pw = pw or m_p.group(1)
                host = host or url
        if not (host and user and pw):
            tipo = 'invalido'
        else:
            host = _norm_xt_host(host)
    elif tipo == 'stalker':
        host = host or url
        if not (host and mac):
            tipo = 'invalido'
        else:
            host = _add_scheme(host).rstrip('/')
            mac = _norm_mac(mac)
    elif tipo == 'm3u':
        url = url or host
        if not url:
            tipo = 'invalido'

    out.update(tipo=tipo, host=host, username=user, password=pw, mac=mac, url=url, icon=icon)
    return out


def normalizar_servidores(lista):
    res = []
    for s in (lista or []):
        try:
            res.append(normalizar_servidor(s))
        except Exception as e:
            log_warn('Servidor invalido ignorado: ' + str(e))
            res.append({'nome': common.L(30292), 'tipo': 'invalido'})
    return res


# ════════════════════════════════════════════════════════
#  XTREAM CODES
# ════════════════════════════════════════════════════════

def xt_api_url(srv, action=None, **params):
    q = [('username', srv['username']), ('password', srv['password'])]
    if action:
        q.append(('action', action))
    q.extend(params.items())
    return '{}/player_api.php?{}'.format(srv['host'], urlencode(q))


def xt_call(srv, action=None, ttl=300, forcar=False, **params):
    return http_get_json(xt_api_url(srv, action, **params), ttl=ttl, forcar=forcar)


def xt_stream_url(srv, kind, stream_id, ext):
    return '{}/{}/{}/{}/{}.{}'.format(srv['host'], kind,
                                      quote(srv['username'], safe=''),
                                      quote(srv['password'], safe=''), stream_id, ext)


def xt_from_m3u_url(url):
    """Credenciais Xtream de um URL get.php?username=..&password=.. (None se nao for)."""
    m = re.match(r'^(https?://[^?#]+?)/(?:get|player_api|panel_api)\.php\?(.*)$', url or '', re.I)
    if not m:
        return None
    q = dict(parse_qsl(m.group(2)))
    if q.get('username') and q.get('password'):
        return {'host': m.group(1).rstrip('/'), 'username': q['username'], 'password': q['password']}
    return None


def conn_info(srv, ttl=10, timeout=3.0):
    """{'active','max','status'} da conta Xtream (ou M3U com credenciais Xtream); None se desconhecido."""
    xt = srv if srv.get('tipo') == 'xtream' else xt_from_m3u_url(srv.get('url', ''))
    if not xt:
        return None
    data = http_get_json(xt_api_url(xt), ttl=ttl, timeout=timeout, tries=1)
    ui = (data or {}).get('user_info') if isinstance(data, dict) else None
    if not isinstance(ui, dict):
        return None
    try:
        return {'active': int(ui.get('active_cons') or 0), 'max': int(ui.get('max_connections') or 0),
                'status': str(ui.get('status', ''))}
    except Exception:
        return None


def conn_infos(servers, budget=3.0):
    """Pede a info de ligacoes de todos os servidores em paralelo, sem nunca bloquear mais de 'budget' s."""
    out = {}
    ex = ThreadPoolExecutor(max_workers=max(1, min(8, len(servers))))
    futs = {}
    for i, srv in enumerate(servers):
        if srv.get('tipo') in ('xtream', 'm3u'):
            futs[ex.submit(conn_info, srv, 10, budget)] = i
    done, _ = futures_wait(list(futs), timeout=budget)
    for f in done:
        try:
            r = f.result()
            if r:
                out[futs[f]] = r
        except Exception:
            pass
    ex.shutdown(wait=False)
    return out


def xt_account_info(srv):
    """player_api sem action: info da conta (estado, expiracao, ligacoes)."""
    return xt_call(srv, None, ttl=0, forcar=True)


def _b64_maybe(s):
    """Os titulos/descricoes de EPG Xtream costumam vir em base64."""
    if not s or not isinstance(s, str):
        return s or ''
    t = s.strip()
    if len(t) < 4 or len(t) % 4 or not re.match(r'^[A-Za-z0-9+/]+={0,2}$', t):
        return s
    try:
        txt = base64.b64decode(t, validate=True).decode('utf-8')
    except Exception:
        return s
    if not txt or any(ord(c) < 32 and c not in '\r\n\t' for c in txt):
        return s
    return txt


def _ts(v):
    try:
        return int(v)
    except Exception:
        return 0


def _hhmm(epoch):
    return time.strftime('%H:%M', time.localtime(epoch))


def xt_epg_short(srv, stream_id, limit=3):
    data = xt_call(srv, 'get_short_epg', ttl=300, stream_id=stream_id, limit=limit)
    if not data:
        return None
    try:
        lista = data.get('epg_listings', [])
        if not lista:
            return None
        a = lista[0]
        titulo = _b64_maybe(a.get('title', '') or a.get('name', ''))
        if not titulo:
            return None
        desc = _b64_maybe(a.get('description', '') or a.get('plot', ''))
        ini = _ts(a.get('start_timestamp'))
        fim = _ts(a.get('stop_timestamp'))
        horas = ''
        if ini and fim:                       # timestamps (epoch) em vez do texto no fuso do servidor
            horas = '{}-{}'.format(_hhmm(ini), _hhmm(fim))
        else:
            s, e = str(a.get('start', '')), str(a.get('end', ''))
            if len(s) >= 16 and len(e) >= 16:
                horas = '{}-{}'.format(s[11:16], e[11:16])
        proximo = ''
        if len(lista) > 1:
            proximo = _b64_maybe(lista[1].get('title', '') or lista[1].get('name', ''))
        return {'titulo': titulo, 'descricao': desc, 'horas': horas, 'proximo': proximo}
    except Exception as e:
        log('EPG parse: ' + str(e))
    return None


def xt_epg_bulk(srv, stream_ids, max_items=60, budget=8.0, workers=5):
    """
    EPG de varios canais em paralelo, com limite de itens e de tempo total.
    Devolve {stream_id: epg}. Canais fora do limite/tempo ficam sem EPG.
    """
    res = {}
    ids = list(stream_ids)[:max_items]
    if not ids:
        return res
    t_end = time.time() + budget

    def _one(sid):
        if time.time() > t_end:
            return sid, None
        return sid, xt_epg_short(srv, sid)

    with ThreadPoolExecutor(max_workers=max(1, workers)) as ex:
        for sid, epg in ex.map(_one, ids):
            if epg:
                res[sid] = epg
    return res


def xt_catchup_listings(srv, stream_id):
    """Programas com arquivo (catch-up) ja terminados, mais recentes primeiro."""
    data = xt_call(srv, 'get_simple_data_table', ttl=120, stream_id=stream_id)
    out = []
    now = time.time()
    for a in (data or {}).get('epg_listings', []):
        try:
            if str(a.get('has_archive', '0')) != '1':
                continue
            ini, fim = _ts(a.get('start_timestamp')), _ts(a.get('stop_timestamp'))
            if not ini or not fim or fim > now:
                continue
            out.append({'titulo': _b64_maybe(a.get('title', '')) or common.L(30235),
                        'descricao': _b64_maybe(a.get('description', '')),
                        'start': str(a.get('start', '')), 'ini': ini, 'fim': fim})
        except Exception:
            continue
    out.sort(key=lambda x: -x['ini'])
    return out


def xt_catchup_url(srv, stream_id, start_str, ini, fim):
    """/timeshift/user/pass/<minutos>/<YYYY-MM-DD:HH-MM>/<id>.ts (hora no fuso do servidor)."""
    dur = max(1, int(math.ceil((fim - ini) / 60.0)))
    if len(start_str) >= 16:
        stamp = '{}:{}-{}'.format(start_str[:10], start_str[11:13], start_str[14:16])
    else:
        stamp = time.strftime('%Y-%m-%d:%H-%M', time.localtime(ini))
    return '{}/timeshift/{}/{}/{}/{}/{}.ts'.format(
        srv['host'], quote(srv['username'], safe=''), quote(srv['password'], safe=''),
        dur, stamp, stream_id)


# ════════════════════════════════════════════════════════
#  STALKER / MAG (MAC)
# ════════════════════════════════════════════════════════

_ST = {}                 # estado por portal+mac: endpoint, token, ts
_st_lock = threading.Lock()
_TOKEN_TTL = 1500


def _st_key(host, mac):
    return host.strip().rstrip('/') + '|' + mac.upper()


def stalker_base(host):
    """Raiz do portal sem '/c' (compativel com a versao anterior)."""
    base = host.rstrip('/')
    if base.endswith('/c'):
        base = base[:-2]
    return base


def _st_endpoints(host):
    h = host.strip().rstrip('/')
    if re.search(r'\.php$', h):
        return [h]
    b = re.sub(r'/c$', '', h)
    eps = [b + '/server/load.php', b + '/portal.php']
    if 'stalker_portal' not in b:
        eps.append(b + '/stalker_portal/server/load.php')
    return eps


def stalker_headers(mac, host=None, token=None):
    base = stalker_base(host) if host else 'http://localhost'
    h = {
        'User-Agent':   UA_STB,
        'X-User-Agent': 'Model: MAG250; Link: WiFi',
        'Cookie':       'mac={}; stb_lang=en; timezone=Europe/Lisbon'.format(mac),
        'Referer':      base + '/c/',
        'Accept':       '*/*',
    }
    if token:
        h['Authorization'] = 'Bearer ' + token
    return h


def _st_json(url, headers, timeout=15):
    txt = fetch_text(url, headers, timeout=timeout, tries=1)
    if not txt:
        return None
    try:
        return json.loads(txt)
    except Exception:
        i = txt.find('{')
        if i >= 0:
            try:
                return json.loads(txt[i:])
            except Exception:
                pass
    return None


def _st_profile(host, mac, ep, token):
    """Activa o perfil do STB (necessario em varios portais apos o handshake)."""
    try:
        sn = hashlib.md5(mac.encode()).hexdigest()[:13].upper()
        dev = hashlib.sha256(mac.encode()).hexdigest().upper()
        dev2 = hashlib.sha256(sn.encode()).hexdigest().upper()
        q = urlencode([
            ('type', 'stb'), ('action', 'get_profile'), ('hd', '1'),
            ('ver', 'ImageDescription: 0.2.18-r14-pub-250; ImageDate: Fri Jan 15 15:20:44 EET 2016; '
                    'PORTAL version: 5.5.0; API Version: JS API version: 328; STB API version: 134; '
                    'Player Engine version: 0x566'),
            ('num_banks', '2'), ('sn', sn), ('stb_type', 'MAG250'), ('client_type', 'STB'),
            ('image_version', '218'), ('video_out', 'hdmi'), ('device_id', dev), ('device_id2', dev2),
            ('signature', ''), ('auth_second_step', '1'), ('hw_version', '1.7-BD-00'),
            ('not_valid_token', '0'), ('hw_version_2', hashlib.sha1(mac.encode()).hexdigest()),
            ('api_signature', '262'), ('prehash', ''), ('JsHttpRequest', '1-xml'),
        ])
        _st_json(ep + '?' + q, stalker_headers(mac, host, token))
    except Exception as e:
        log('Stalker get_profile: ' + str(e))


def stalker_token(host, mac, forcar=False):
    """Token do portal (com descoberta do endpoint e activacao do perfil)."""
    key = _st_key(host, mac)
    with _st_lock:
        st = _ST.setdefault(key, {})
        if not forcar and st.get('token') and time.time() - st.get('ts', 0) < _TOKEN_TTL:
            return st['token']
        eps = _st_endpoints(host)
        if st.get('ep') in eps:
            eps.remove(st['ep'])
            eps.insert(0, st['ep'])
        for ep in eps:
            data = _st_json(ep + '?type=stb&action=handshake&token=&prehash=0&JsHttpRequest=1-xml',
                            stalker_headers(mac, host))
            js = (data or {}).get('js')
            token = js.get('token', '') if isinstance(js, dict) else ''
            if token:
                st.update(ep=ep, token=token, ts=time.time())
                _st_profile(host, mac, ep, token)
                log('Stalker token {} ({})'.format('renovado' if forcar else 'obtido', mascarar(ep)))
                return token
        log_warn('Stalker handshake falhou')
        st.pop('token', None)
        return None


def _st_auth_error(data):
    if not data:
        return True
    js = data.get('js') if isinstance(data, dict) else None
    if isinstance(js, dict):
        err = str(js.get('error', '') or js.get('err', ''))
        if '458' in err or '459' in err or 'token' in err.lower() or 'author' in err.lower():
            return True
    return False


def stalker_call(host, mac, params, ttl=0, tentativa=0):
    """
    Chamada ao portal. params: dict (ou string 'a=b&c=d').
    ttl>0 => cache em disco (nunca para create_link/handshake).
    Renova o token uma vez em caso de erro de autenticacao.
    """
    token = stalker_token(host, mac, forcar=(tentativa > 0))
    if not token:
        return None
    ep = _ST[_st_key(host, mac)]['ep']
    qs = params if isinstance(params, str) else urlencode(list(params.items()))
    ckey = None
    if ttl and tentativa == 0:
        ckey = 'st|{}|{}|{}'.format(_st_key(host, mac), ep, qs)
        c = cache_get(ckey, ttl)
        if c is not None:
            try:
                return json.loads(c)
            except Exception:
                pass
    url = '{}?{}&token={}&JsHttpRequest=1-xml'.format(ep, qs, quote(token, safe=''))
    data = _st_json(url, stalker_headers(mac, host, token))
    if _st_auth_error(data) and tentativa == 0:
        log_warn('Stalker: token invalido/expirado — a renovar')
        return stalker_call(host, mac, params, ttl=ttl, tentativa=1)
    if data and ckey:
        cache_set(ckey, json.dumps(data, ensure_ascii=False))
    return data


def stalker_categorias(host, mac, tipo):
    if tipo == 'itv':
        data = stalker_call(host, mac, {'type': 'itv', 'action': 'get_genres'}, ttl=600)
    else:
        data = stalker_call(host, mac, {'type': tipo, 'action': 'get_categories'}, ttl=600)
    if not data:
        return []
    cats = data.get('js', [])
    if isinstance(cats, dict):
        cats = list(cats.values())
    return [c for c in cats if isinstance(c, dict) and (c.get('title') or c.get('name'))]


def stalker_all_itv(host, mac):
    """Todos os canais numa unica chamada (muito mais rapido que paginar). None se nao suportado."""
    data = stalker_call(host, mac, {'type': 'itv', 'action': 'get_all_channels'}, ttl=600)
    js = (data or {}).get('js')
    items = js.get('data') if isinstance(js, dict) else js
    if isinstance(items, list) and items:
        return items
    return None


def _st_page(host, mac, tipo, cat_id, pagina, extra=None):
    chave = 'genre' if tipo == 'itv' else 'category'
    p = [('type', tipo), ('action', 'get_ordered_list'), (chave, cat_id), ('p', pagina)]
    if tipo == 'itv':
        p.append(('sortby', 'number'))
    if extra:
        p.extend(extra.items())
    data = stalker_call(host, mac, dict(p), ttl=300)
    js = (data or {}).get('js')
    return js if isinstance(js, dict) else None


def stalker_canais(host, mac, tipo, cat_id, progress=None, search=None):
    """
    Itens de uma categoria. Para itv tenta get_all_channels (1 pedido);
    senao pagina — a 1.a pagina em serie e as restantes em paralelo.
    """
    if tipo == 'itv' and not search:
        allc = stalker_all_itv(host, mac)
        if allc:
            if cat_id in ('*', '', None):
                return allc
            if any('tv_genre_id' in c for c in allc[:50]):
                sel = [c for c in allc if str(c.get('tv_genre_id', '')) == str(cat_id)]
                log('Stalker all_channels: {} em genero {}'.format(len(sel), cat_id))
                return sel

    extra = {'search': search} if search else None
    js = _st_page(host, mac, tipo, cat_id, 1, extra)
    if not js:
        return []
    items = list(js.get('data', []) or [])
    total = int(js.get('total_items', 0) or 0)
    per = int(js.get('max_page_items', 0) or 0) or len(items) or 14
    if not items or total <= len(items):
        return items
    paginas = min(int(math.ceil(total / float(per))), 300)
    if progress:
        progress(1, paginas)
    restantes = list(range(2, paginas + 1))
    workers = device_profile()['workers']

    def _get(p):
        j = _st_page(host, mac, tipo, cat_id, p, extra)
        return (j or {}).get('data', []) or []

    done = 1
    with ThreadPoolExecutor(max_workers=workers) as ex:
        for lote in ex.map(_get, restantes):
            items.extend(lote)
            done += 1
            if progress:
                progress(done, paginas)
    log('Stalker {}: {} itens ({} pag.)'.format(tipo, len(items), paginas))
    return items


def _extrair_stream_id(cmd):
    m = re.search(r'[&?]stream=(\d+)', cmd)
    return m.group(1) if m else ''


def _corrigir_stream_vazio(url, cmd_original):
    if 'stream=&' in url or url.endswith('stream='):
        sid = _extrair_stream_id(cmd_original)
        if sid:
            url = url + sid if url.endswith('stream=') else url.replace('stream=&', 'stream=' + sid + '&')
    return url


_RE_CMD_PREFIX = re.compile(r'^(?:ffmpeg|ffrt\d?|auto|rtp|rtsp)\s+(?=\S)', re.I)


def _limpar_cmd(cmd):
    cmd = (cmd or '').strip()
    cmd = _RE_CMD_PREFIX.sub('', cmd, count=1).strip()
    if ' ' in cmd:
        parts = cmd.split('?', 1)
        if len(parts) == 2:
            cmd = parts[0].replace(' ', '%20') + '?' + parts[1].replace(' ', '%20')
        else:
            cmd = cmd.replace(' ', '%20')
    return cmd


def _e_local(u):
    return 'localhost' in u or '127.0.0.1' in u


def stalker_create_link(host, mac, tipo, cmd, series=''):
    """
    Resolve o link final de um canal/filme/episodio.
    Se o cmd ja for um URL directo (nao localhost) devolve-o; caso contrario
    chama create_link (obrigatorio para VOD e para 'localhost/ch/ID').
    """
    cmd_limpo = _corrigir_stream_vazio(_limpar_cmd(cmd), cmd)
    if cmd_limpo.startswith('http') and not _e_local(cmd_limpo) and not series:
        return cmd_limpo

    token = stalker_token(host, mac)
    if not token:
        return cmd_limpo if cmd_limpo.startswith('http') else None
    ep = _ST[_st_key(host, mac)]['ep']

    def _try(tok):
        q = urlencode([('type', tipo), ('action', 'create_link'), ('cmd', cmd),
                       ('series', str(series or '')), ('forced_storage', 'undefined'),
                       ('disable_ad', '0'), ('download', '0'),
                       ('token', tok), ('JsHttpRequest', '1-xml')])
        return _st_json(ep + '?' + q, stalker_headers(mac, host, tok))

    data = _try(token)
    if _st_auth_error(data):
        token = stalker_token(host, mac, forcar=True)
        data = _try(token) if token else None
    js = (data or {}).get('js', {})
    url = (js.get('url', '') or js.get('cmd', '')) if isinstance(js, dict) else ''
    url = _corrigir_stream_vazio(_limpar_cmd(url), cmd) if url else ''
    if url and not _e_local(url):
        log('Stalker create_link OK: ' + mascarar(url[:80]))
        return url
    log_warn('Stalker create_link falhou')
    return cmd_limpo if cmd_limpo.startswith('http') and not _e_local(cmd_limpo) else None


def stalker_abs(host, path):
    """Logos/posters relativos do portal -> URL absoluto."""
    if not path:
        return ''
    p = path.strip().replace(' ', '%20')
    if p.startswith(('http://', 'https://')):
        return p
    sp = urlsplit(_add_scheme(host))
    if p.startswith('/'):
        return '{}://{}{}'.format(sp.scheme, sp.netloc, p)
    return '{}://{}/{}'.format(sp.scheme, sp.netloc, p)


# ════════════════════════════════════════════════════════
#  M3U / M3U_plus  — indice em disco (grupos + offsets)
# ════════════════════════════════════════════════════════
#
#  A lista e descarregada para disco, analisada em streaming e guardada em
#  'entries.jsonl' (1 entrada por linha). Em memoria so ficam os offsets por
#  grupo. Abrir um grupo le apenas as linhas desse grupo => baixo consumo de
#  RAM mesmo com listas de 100k+ entradas (box Android antigas).

_RE_ATTR = re.compile(r'([A-Za-z0-9_\-\.]+)\s*=\s*(?:"([^"]*)"|\'([^\']*)\'|([^\s,"\']+))')


def _kind_from(url, group):
    u = url.lower().split('?', 1)[0].split('|', 1)[0]
    if '/series/' in u:
        return 's'
    if '/movie/' in u:
        return 'm'
    if u.endswith(('.mp4', '.mkv', '.avi', '.mov', '.wmv', '.flv', '.mpg', '.mpeg', '.m4v')):
        return 'm'
    return 'l'


def iter_m3u(lines):
    """Gera dicts {n,u,l,g,i,k,ua,ref} a partir de linhas M3U/M3U_plus."""
    pend = {}
    opts = {}
    for raw in lines:
        line = raw.strip()
        if not line:
            continue
        if line.startswith('#EXTINF'):
            rest = line[8:] if line.startswith('#EXTINF:') else line[7:]
            attrs = {}
            last_end = 0
            for m in _RE_ATTR.finditer(rest):
                attrs[m.group(1).lower()] = (m.group(2) if m.group(2) is not None
                                             else m.group(3) if m.group(3) is not None
                                             else m.group(4) or '')
                last_end = m.end()
            i = rest.find(',', last_end)
            nome = rest[i + 1:].strip() if i >= 0 else ''
            pend = {'n': nome or attrs.get('tvg-name', '') or common.L(30286),
                    'l': attrs.get('tvg-logo', '') or attrs.get('logo', ''),
                    'g': (attrs.get('group-title', '') or '').strip(),
                    'i': attrs.get('tvg-id', '')}
            opts = {}
        elif line.startswith('#EXTGRP:'):
            pend['g'] = pend.get('g') or line[8:].strip()
        elif line.startswith('#EXTVLCOPT:'):
            k, _, v = line[11:].partition('=')
            k = k.strip().lower()
            if k == 'http-user-agent':
                opts['ua'] = v.strip()
            elif k in ('http-referrer', 'http-referer'):
                opts['ref'] = v.strip()
        elif line.startswith('#'):
            continue
        else:
            if not pend:
                pend = {'n': line.rsplit('/', 1)[-1] or common.L(30286), 'l': '', 'g': '', 'i': ''}
            pend['u'] = line
            pend['g'] = pend.get('g') or common.L(30289)
            pend['k'] = _kind_from(line, pend['g'])
            pend.update(opts)
            yield pend
            pend, opts = {}, {}


class M3UStore(object):
    """Indice persistente de uma lista M3U (URL http(s), ficheiro local ou special://)."""

    def __init__(self, src):
        self.src = src
        self.dir = temp_dir('ontv_m3u/' + hashlib.sha1(src.encode('utf-8')).hexdigest()[:16])
        self.meta_path = os.path.join(self.dir, 'meta.json')
        self.data_path = os.path.join(self.dir, 'entries.jsonl')
        self._meta = None

    # ── estado ───────────────────────────────────────
    def meta(self):
        if self._meta is None:
            try:
                with io.open(self.meta_path, 'r', encoding='utf-8') as f:
                    self._meta = json.load(f)
            except Exception:
                self._meta = {}
        return self._meta

    def fresca(self, ttl):
        m = self.meta()
        return bool(m.get('groups') is not None and m.get('ts') and time.time() - m['ts'] < ttl
                    and os.path.exists(self.data_path))

    # ── construcao ───────────────────────────────────
    def _descarregar(self, dest, progress=None):
        src = self.src
        if not src.lower().startswith(('http://', 'https://')):
            if common.IN_KODI:
                import xbmcvfs
                if not xbmcvfs.copy(src, dest):
                    raise IOError('Nao foi possivel ler ' + src)
            else:
                shutil.copyfile(src.replace('file://', ''), dest)
            return
        url, _, hdr = src.partition('|')
        headers = {'Accept-Encoding': 'gzip, identity'}
        if hdr:
            for kv in hdr.split('&'):
                k, _, v = kv.partition('=')
                if k:
                    headers[k] = v
        resp = open_url(url, headers, timeout=30)
        try:
            first = resp.read(2)
            stream = io.BufferedReader(_Chain(first, resp)) if first else resp
            if first == b'\x1f\x8b':
                stream = gzip.GzipFile(fileobj=stream)
            total = 0
            with open(dest, 'wb') as out:
                while True:
                    chunk = stream.read(262144)
                    if not chunk:
                        break
                    out.write(chunk)
                    total += len(chunk)
                    if progress:
                        progress(total)
        finally:
            resp.close()

    def construir(self, progress=None):
        """Descarrega + analisa + indexa. Levanta excepcao em erro de rede."""
        raw = os.path.join(self.dir, 'raw.m3u')
        self._descarregar(raw, progress)

        groups = OrderedDict()
        total = 0
        adult_g = {}
        tmp_data = self.data_path + '.new'
        with io.open(raw, 'r', encoding='utf-8-sig', errors='replace') as src, \
                open(tmp_data, 'wb') as out:
            for e in iter_m3u(src):
                g = e['g']
                ag = adult_g.get(g)
                if ag is None:
                    ag = adult_g[g] = e_adulto(g)
                if ag or e_adulto(e['n']):
                    continue
                off = out.tell()
                out.write((json.dumps(e, ensure_ascii=False, separators=(',', ':')) + '\n').encode('utf-8'))
                key = (e['k'], g)
                gr = groups.get(key)
                if gr is None:
                    gr = groups[key] = {'n': g, 'k': e['k'], 'c': 0, 'l': e.get('l', ''), 'o': []}
                if not gr['l'] and e.get('l'):
                    gr['l'] = e['l']
                gr['c'] += 1
                gr['o'].append(off)
                total += 1
        try:
            os.remove(raw)
        except Exception:
            pass
        if not total:
            try:
                os.remove(tmp_data)
            except Exception:
                pass
            raise ValueError('Lista M3U vazia ou invalida')
        os.replace(tmp_data, self.data_path)
        meta = {'ts': time.time(), 'src': mascarar(self.src), 'total': total,
                'groups': list(groups.values())}
        common.atomic_write(self.meta_path, json.dumps(meta, ensure_ascii=False, separators=(',', ':')))
        self._meta = meta
        log('M3U indexada: {} entradas, {} grupos'.format(total, len(groups)))
        return meta

    # ── consulta ─────────────────────────────────────
    def kinds(self):
        return sorted(set(g['k'] for g in self.meta().get('groups', [])))

    def groups(self, kind=None):
        gs = self.meta().get('groups', [])
        return [g for g in gs if kind is None or g['k'] == kind]

    def entries(self, kind, group):
        for g in self.meta().get('groups', []):
            if g['k'] == kind and g['n'] == group:
                with open(self.data_path, 'rb') as f:
                    for off in g['o']:
                        f.seek(off)
                        try:
                            yield json.loads(f.readline().decode('utf-8'))
                        except Exception:
                            continue
                return

    def search(self, termo, limite=500):
        termo = termo.lower()
        t_b = termo.encode('utf-8')
        out = []
        with open(self.data_path, 'rb') as f:
            for line in f:
                if t_b in line.lower():
                    try:
                        e = json.loads(line.decode('utf-8'))
                    except Exception:
                        continue
                    if termo in e.get('n', '').lower():
                        out.append(e)
                        if len(out) >= limite:
                            break
        return out


class _Chain(io.RawIOBase):
    """Reconstitui um fluxo depois de se ter lido o inicio (para detectar gzip)."""

    def __init__(self, first, resp):
        self._first = first
        self._resp = resp

    def readable(self):
        return True

    def readinto(self, b):
        if self._first:
            n = min(len(b), len(self._first))
            b[:n] = self._first[:n]
            self._first = self._first[n:]
            return n
        data = self._resp.read(len(b))
        n = len(data)
        b[:n] = data
        return n

