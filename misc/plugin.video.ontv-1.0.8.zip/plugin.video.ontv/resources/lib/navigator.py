# -*- coding: utf-8 -*-
"""
OnTV — Navigator
Fontes: Xtream Codes, Stalker/MAG (MAC), M3U / M3U_plus.

Seguro para reuselanguageinvoker: nao le sys.argv em tempo de import.
Mantidos: filtro adulto, prioridade PT nas categorias, estrutura de menus.
"""

import json
import math
import os
import sys
import time
from urllib.parse import urlencode, parse_qsl, quote

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs

import common
import api
from common import (e_adulto, filtrar_adulto, prioridade_pt, set_video_info, setting_int,
                    setting_bool, mascarar, L)

ADDON = xbmcaddon.Addon()
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_PATH = ADDON.getAddonInfo('path')
ICON = os.path.join(ADDON_PATH, 'icon.png')
FANART = os.path.join(ADDON_PATH, 'fanart.png')

HANDLE = -1
BASE_URL = ''
PROP_LAST = 'ontv.last_play'


def log(msg, level=xbmc.LOGDEBUG):
    xbmc.log('[OnTV] ' + str(msg), level)


# ════════════════════════════════════════════════════════
#  Helpers de UI
# ════════════════════════════════════════════════════════

def url_para(params):
    return BASE_URL + '?' + urlencode(params)


def notificar(msg, tipo=xbmcgui.NOTIFICATION_ERROR, duracao=4000):
    xbmcgui.Dialog().notification(ADDON_NAME, msg, tipo, duracao)


def _ttl(nome):
    if nome == 'm3u':
        return max(1, setting_int('cache_m3u_min', 15)) * 60
    return max(1, setting_int('cache_api_min', 5)) * 60


def servidores():
    from mediacfg import carregar_servidores
    return api.normalizar_servidores(carregar_servidores())


def get_srv(idx):
    lst = servidores()
    try:
        return lst[int(idx)]
    except Exception:
        return None


def _srv_ou_erro(idx):
    srv = get_srv(idx)
    if not srv or srv.get('tipo') == 'invalido':
        notificar(L(30200))
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return None
    return srv


def mk_li(label, thumb='', fanart='', playable=False):
    li = xbmcgui.ListItem(label)
    t = thumb or ICON
    art = {'thumb': t, 'icon': t}
    if fanart:
        art['fanart'] = fanart
    li.setArt(art)
    if playable:
        li.setProperty('IsPlayable', 'true')
    return li


def _fanart_de(logo):
    if logo and logo != ICON and common.device_profile()['fanart']:
        return logo
    return ''


def fim(content='videos', ok=True):
    xbmcplugin.setContent(HANDLE, content)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(HANDLE, succeeded=ok, cacheToDisc=False)


def add_all(entries):
    if entries:
        xbmcplugin.addDirectoryItems(HANDLE, entries, len(entries))


def _page_size():
    i = setting_int('page_size', 0)
    if i == 5:
        return 0
    if i in (1, 2, 3, 4):
        return (100, 250, 500, 1000)[i - 1]
    return common.device_profile()['page']


def pagina(total, params, pag):
    """(ini, fim, entrada 'seguinte' ou None)."""
    size = _page_size()
    if not size or total <= int(size * 1.2):
        return 0, total, None
    ini = max(0, pag) * size
    f = min(total, ini + size)
    nxt = None
    if f < total:
        p = dict(params)
        p['pag'] = str(pag + 1)
        li = mk_li(L(30239).format(pag + 2, int(math.ceil(total / float(size)))))
        nxt = (url_para(p), li, True)
    return ini, f, nxt


def cm_fav(nome, url='', logo='', tipo='video', **kw):
    p = {'acao': 'fav_add', 'fav_nome': nome, 'fav_url': url, 'fav_logo': logo, 'fav_tipo': tipo}
    p.update(dict((k, v) for k, v in kw.items() if v))
    return (L(30240), 'RunPlugin({})'.format(url_para(p)))


def cm_diag(nome, url, ua='', ref=''):
    p = {'acao': 'diagnostico', 'url': url, 'nome': nome}
    if ua:
        p['ua'] = ua
    if ref:
        p['ref'] = ref
    return (L(30320), 'RunPlugin({})'.format(url_para(p)))


def acao_diagnostico(p):
    import diagnostic
    import proxy
    url = p.get('url', '')
    if not url.startswith('http'):
        return
    hdr = {}
    if p.get('ua'):
        hdr['User-Agent'] = p['ua']
    if p.get('ref'):
        hdr['Referer'] = p['ref']
    proxy.stop_remote()                       # liberta a ligacao do proxy (contas de 1 ligacao)
    segundos = 20
    dp = xbmcgui.DialogProgress()
    dp.create(L(30336), L(30322))
    try:
        def _prog(sec):
            dp.update(min(99, int(sec * 100 / segundos)), L(30323).format(sec))
        r = diagnostic.medir(url, hdr or None, segundos, _prog, dp.iscanceled)
    finally:
        dp.close()
    xbmcgui.Dialog().textviewer('{} — {}'.format(L(30336), p.get('nome', '')),
                                diagnostic.relatorio(r, segundos))


def _num(v, default=0.0):
    try:
        return float(v)
    except Exception:
        return default


def _ano(v):
    try:
        return int(str(v)[:4])
    except Exception:
        return 0


# ════════════════════════════════════════════════════════
#  Menu principal / tipos
# ════════════════════════════════════════════════════════

def _label_servidor(srv, info):
    """'Nome  | Ligacoes 0/1' (verde = livre, vermelho = esgotado)."""
    nome = srv['nome']
    if not info:
        return nome
    if info['status'] and info['status'].lower() not in ('active', 'ativo', 'activo'):
        return '{}  [COLOR red]| {}[/COLOR]'.format(nome, L(30291))
    if info['max'] <= 0:
        return nome
    cor = 'red' if info['active'] >= info['max'] else 'green'
    return '{}  [COLOR {}]| {} {}/{}[/COLOR]'.format(nome, cor, L(30290), info['active'], info['max'])


def mostrar_principal():
    srvs = servidores()
    xbmcplugin.setPluginCategory(HANDLE, 'OnTV')
    if not srvs:
        notificar(L(30201))
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    ent = []
    infos = {}
    try:
        infos = api.conn_infos(srvs, budget=3.0)          # ligacoes em uso (Xtream), em paralelo
    except Exception as e:
        log('conn_infos: ' + str(e))
    for i, srv in enumerate(srvs):
        li = mk_li(_label_servidor(srv, infos.get(i)), srv.get('icon'), FANART)
        ent.append((url_para({'acao': 'tipos', 'srv_idx': str(i)}), li, True))
    import favourites
    ent.append((url_para({'acao': 'favoritos'}),
                mk_li(L(30202).format(favourites.contar()), ICON, FANART), True))
    ent.append((url_para({'acao': 'recentes'}), mk_li(L(30203), ICON, FANART), True))
    ent.append((url_para({'acao': 'ferramentas'}), mk_li(L(30204), ICON, FANART), True))
    add_all(ent)
    xbmcplugin.setContent(HANDLE, 'videos')
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(HANDLE)


def mostrar_tipos(srv_idx):
    srv = _srv_ou_erro(srv_idx)
    if not srv:
        return
    xbmcplugin.setPluginCategory(HANDLE, srv['nome'])
    if srv['tipo'] == 'm3u':
        mostrar_m3u_raiz(srv_idx)
        return
    ent = []
    for nome, acao in ((L(30205), 'live_cats'), (L(30206), 'vod_cats'),
                       (L(30207), 'series_cats'), (L(30208), 'pesquisa')):
        ent.append((url_para({'acao': acao, 'srv_idx': srv_idx}), mk_li(nome, ICON, FANART), True))
    if srv['tipo'] == 'xtream':
        ent.append((url_para({'acao': 'conta', 'srv_idx': srv_idx}),
                    mk_li(L(30209), ICON, FANART), False))
    add_all(ent)
    fim()


def mostrar_conta(srv_idx):
    srv = get_srv(srv_idx)
    if not srv or srv['tipo'] != 'xtream':
        return
    t0 = time.time()
    info = api.xt_account_info(srv)
    ms = int((time.time() - t0) * 1000)
    if not info or not isinstance(info, dict) or 'user_info' not in info:
        xbmcgui.Dialog().ok(ADDON_NAME, L(30210))
        return
    u = info.get('user_info', {})
    s = info.get('server_info', {})

    def _data(v):
        try:
            return time.strftime('%d/%m/%Y', time.localtime(int(v))) if v else L(30221)
        except Exception:
            return str(v)

    linhas = [
        L(30211).format(u.get('status', '?')),
        L(30212).format(_data(u.get('exp_date'))),
        L(30213).format(u.get('active_cons', '?'), u.get('max_connections', '?')),
        L(30214).format(L(30215) if str(u.get('is_trial', '0')) == '1' else L(30216)),
        L(30217).format(', '.join(u.get('allowed_output_formats', []) or []) or '-'),
        '',
        L(30219).format(s.get('timezone', '-')),
        L(30220).format(ms),
    ]
    xbmcgui.Dialog().textviewer(srv['nome'], '\n'.join(linhas))


# ════════════════════════════════════════════════════════
#  Categorias
# ════════════════════════════════════════════════════════

_XT_CAT = {'live_cats': ('get_live_categories', 'live_canais'),
           'vod_cats': ('get_vod_categories', 'vod_canais'),
           'series_cats': ('get_series_categories', 'series_canais')}
_ST_TIPO = {'live_cats': ('itv', 'stalker_live'), 'vod_cats': ('vod', 'stalker_vod'),
            'series_cats': ('series', 'stalker_series')}


def mostrar_categorias(srv_idx, tipo_cat):
    srv = _srv_ou_erro(srv_idx)
    if not srv:
        return
    xbmcplugin.setPluginCategory(HANDLE, srv['nome'])
    ent = []
    if srv['tipo'] == 'stalker':
        st_tipo, acao = _ST_TIPO[tipo_cat]
        cats = api.stalker_categorias(srv['host'], srv['mac'], st_tipo)
        if not cats:
            notificar(L(30222))
            fim(ok=False)
            return
        cats = [c for c in cats if not e_adulto(c.get('title', c.get('name', '')))]
        cats = sorted(cats, key=lambda c: prioridade_pt(c.get('title', c.get('name', ''))))
        for cat in cats:
            nome = cat.get('title', cat.get('name', L(30283)))
            if not nome or nome == '0':
                continue
            cid = str(cat.get('id', cat.get('genre_id', '*')))
            ent.append((url_para({'acao': acao, 'srv_idx': srv_idx, 'cat_id': cid, 'cat_nome': nome}),
                        mk_li(nome), True))
    else:
        action, acao = _XT_CAT[tipo_cat]
        data = api.xt_call(srv, action, ttl=_ttl('api'))
        if not data or not isinstance(data, list):
            notificar(L(30223))
            fim(ok=False)
            return
        data = filtrar_adulto(data, 'category_name')
        data = sorted(data, key=lambda c: prioridade_pt(c.get('category_name', '')))
        for cat in data:
            nome = cat.get('category_name', L(30283))
            ent.append((url_para({'acao': acao, 'srv_idx': srv_idx,
                                  'cat_id': str(cat.get('category_id', '')), 'cat_nome': nome}),
                        mk_li(nome), True))
    add_all(ent)
    fim()


# ════════════════════════════════════════════════════════
#  Xtream — construtores de itens
# ════════════════════════════════════════════════════════

def _item_live(srv, ch, epg=None):
    nome = ch.get('name', L(30286))
    sid = str(ch.get('stream_id', ''))
    logo = (ch.get('stream_icon', '') or '').replace(' ', '%20')
    ext = ch.get('container_extension', '') or 'ts'
    surl = api.xt_stream_url(srv, 'live', sid, ext)
    label, plot, tagline = nome, '', ''
    if epg:
        horas, tit = epg['horas'], epg['titulo']
        label = '{} — {} {}'.format(nome, horas, tit).replace('  ', ' ') if horas else '{} — {}'.format(nome, tit)
        tagline = '{} {}'.format(horas, tit).strip()
        plot = '[B]{}[/B]  {}'.format(horas, tit) if horas else '[B]{}[/B]'.format(tit)
        if epg.get('descricao'):
            plot += '\n' + epg['descricao']
        if epg.get('proximo'):
            plot += '\n\n' + L(30232).format(epg['proximo'])
    li = mk_li(label, logo, _fanart_de(logo), True)
    set_video_info(li, title=nome, plot=plot, tagline=tagline)
    cms = [cm_fav(nome, surl, logo, 'video', k='live'), cm_diag(nome, surl)]
    if str(ch.get('tv_archive', '0')) == '1':
        cms.append((L(30233), 'Container.Update({})'.format(
            url_para({'acao': 'catchup', 'srv_idx': srv['_idx'], 'stream_id': sid, 'nome': nome}))))
    li.addContextMenuItems(cms)
    return (url_para({'acao': 'play', 'url': surl, 'nome': nome, 'logo': logo, 'k': 'live'}), li, False)


def _item_vod(srv, it):
    nome = it.get('name', L(30285))
    sid = str(it.get('stream_id', ''))
    logo = (it.get('stream_icon', '') or '').replace(' ', '%20')
    ext = it.get('container_extension', '') or 'mp4'
    surl = api.xt_stream_url(srv, 'movie', sid, ext)
    li = mk_li(nome, logo, '', True)
    r = _num(it.get('rating'))
    set_video_info(li, title=nome, mediatype='movie', rating=r if r <= 10 else 0)
    li.addContextMenuItems([cm_fav(nome, surl, logo, 'movie', k='vod')])
    return (url_para({'acao': 'play', 'url': surl, 'nome': nome, 'logo': logo, 'k': 'vod'}), li, False)


def _item_serie(srv_idx, s):
    nome = s.get('name', L(30284))
    sid = str(s.get('series_id', ''))
    logo = s.get('cover', '') or ''
    back = s.get('backdrop_path')
    fan = back[0] if isinstance(back, list) and back else (logo if common.device_profile()['fanart'] else '')
    li = mk_li(nome, logo, fan)
    r = _num(s.get('rating'))
    set_video_info(li, title=nome, mediatype='tvshow', plot=s.get('plot', '') or '',
                   year=_ano(s.get('releaseDate') or s.get('release_date')),
                   rating=r if r <= 10 else 0, genre=s.get('genre', '') or '',
                   director=s.get('director', '') or '')
    li.addContextMenuItems([cm_fav(nome, '', logo, 'tvshow', srv_idx=srv_idx, series_id=sid)])
    return (url_para({'acao': 'series_temps', 'srv_idx': srv_idx, 'series_id': sid, 'serie_nome': nome}), li, True)


def _com_idx(srv, idx):
    srv = dict(srv)
    srv['_idx'] = str(idx)
    return srv


# ════════════════════════════════════════════════════════
#  Xtream — listas
# ════════════════════════════════════════════════════════

def mostrar_live(srv_idx, cat_id, cat_nome, pag=0):
    srv = _srv_ou_erro(srv_idx)
    if not srv:
        return
    srv = _com_idx(srv, srv_idx)
    data = api.xt_call(srv, 'get_live_streams', ttl=_ttl('api'), category_id=cat_id)
    if not data or not isinstance(data, list):
        notificar(L(30224))
        fim(ok=False)
        return
    data = [c for c in data if not e_adulto(c.get('name', '')) and int(c.get('stream_id', 0) or 0) > 0]
    params = {'acao': 'live_canais', 'srv_idx': srv_idx, 'cat_id': cat_id, 'cat_nome': cat_nome}
    ini, f, nxt = pagina(len(data), params, pag)
    vis = data[ini:f]

    epg = {}
    prof = common.device_profile()
    max_epg = setting_int('epg_max', 0)
    if max_epg <= 0:
        max_epg = prof['epg_max']
    if setting_bool('epg_listas', True):
        epg = api.xt_epg_bulk(srv, [str(c.get('stream_id')) for c in vis], max_items=max_epg,
                              budget=8.0, workers=prof['workers'])

    xbmcplugin.setPluginCategory(HANDLE, cat_nome)
    ent = [_item_live(srv, c, epg.get(str(c.get('stream_id')))) for c in vis]
    if nxt:
        ent.append(nxt)
    add_all(ent)
    fim()


def mostrar_vod(srv_idx, cat_id, cat_nome, pag=0):
    srv = _srv_ou_erro(srv_idx)
    if not srv:
        return
    data = api.xt_call(srv, 'get_vod_streams', ttl=_ttl('api'), category_id=cat_id)
    if not data or not isinstance(data, list):
        notificar(L(30225))
        fim(ok=False)
        return
    data = [i for i in data if not e_adulto(i.get('name', '')) and int(i.get('stream_id', 0) or 0) > 0]
    params = {'acao': 'vod_canais', 'srv_idx': srv_idx, 'cat_id': cat_id, 'cat_nome': cat_nome}
    ini, f, nxt = pagina(len(data), params, pag)
    xbmcplugin.setPluginCategory(HANDLE, cat_nome)
    ent = [_item_vod(srv, i) for i in data[ini:f]]
    if nxt:
        ent.append(nxt)
    add_all(ent)
    fim('movies')


def mostrar_series(srv_idx, cat_id, cat_nome, pag=0):
    srv = _srv_ou_erro(srv_idx)
    if not srv:
        return
    data = api.xt_call(srv, 'get_series', ttl=_ttl('api'), category_id=cat_id)
    if not data or not isinstance(data, list):
        notificar(L(30226))
        fim(ok=False)
        return
    params = {'acao': 'series_canais', 'srv_idx': srv_idx, 'cat_id': cat_id, 'cat_nome': cat_nome}
    ini, f, nxt = pagina(len(data), params, pag)
    xbmcplugin.setPluginCategory(HANDLE, cat_nome)
    ent = [_item_serie(srv_idx, s) for s in data[ini:f]]
    if nxt:
        ent.append(nxt)
    add_all(ent)
    fim('tvshows')


def _ep_key(x):
    return int(x) if str(x).isdigit() else 0


def mostrar_temporadas(srv_idx, series_id, serie_nome):
    srv = _srv_ou_erro(srv_idx)
    if not srv:
        return
    data = api.xt_call(srv, 'get_series_info', ttl=_ttl('api'), series_id=series_id)
    if not data or not isinstance(data, dict):
        notificar(L(30226))
        fim(ok=False)
        return
    episodes = data.get('episodes', {})
    if isinstance(episodes, list):                          # alguns paineis devolvem lista
        episodes = dict((str(i + 1), v) for i, v in enumerate(episodes))
    temporadas = sorted(episodes.keys(), key=_ep_key)
    if len(temporadas) == 1:
        _episodios(srv, srv_idx, serie_nome, temporadas[0], data)
        return
    info = data.get('info', {})
    capa = info.get('cover', '') or ICON
    xbmcplugin.setPluginCategory(HANDLE, serie_nome)
    ent = []
    for sn in temporadas:
        label = L(30229).format(_ep_key(sn), len(episodes[sn]))
        li = mk_li(label, capa, capa if common.device_profile()['fanart'] else '')
        set_video_info(li, title=label, mediatype='season', season=_ep_key(sn), showtitle=serie_nome)
        ent.append((url_para({'acao': 'series_eps', 'srv_idx': srv_idx, 'series_id': series_id,
                              'serie_nome': serie_nome, 'temporada': str(sn)}), li, True))
    add_all(ent)
    fim('seasons')


def mostrar_episodios(srv_idx, series_id, serie_nome, temporada=None):
    srv = _srv_ou_erro(srv_idx)
    if not srv:
        return
    data = api.xt_call(srv, 'get_series_info', ttl=_ttl('api'), series_id=series_id)
    if not data or not isinstance(data, dict):
        notificar(L(30228))
        fim(ok=False)
        return
    _episodios(srv, srv_idx, serie_nome, temporada, data)


def _episodios(srv, srv_idx, serie_nome, temporada, data):
    episodes = data.get('episodes', {})
    if isinstance(episodes, list):
        episodes = dict((str(i + 1), v) for i, v in enumerate(episodes))
    seasons = [str(temporada)] if temporada is not None else sorted(episodes.keys(), key=_ep_key)
    titulo = serie_nome + (' — T{:02d}'.format(_ep_key(temporada)) if temporada is not None else '')
    xbmcplugin.setPluginCategory(HANDLE, titulo)
    ent = []
    for sn in seasons:
        for ep in episodes.get(sn, []):
            num = ep.get('episode_num', '')
            nome = 'S{}E{} — {}'.format(str(sn).zfill(2), str(num).zfill(2), ep.get('title', L(30230)))
            info = ep.get('info', {}) or {}
            logo = info.get('movie_image', '') or ''
            surl = api.xt_stream_url(srv, 'series', str(ep.get('id', '')), ep.get('container_extension', '') or 'mp4')
            li = mk_li(nome, logo, '', True)
            r = _num(info.get('rating'))
            set_video_info(li, title=nome, mediatype='episode', plot=info.get('plot', '') or '',
                           season=_ep_key(sn), episode=_ep_key(num), showtitle=serie_nome,
                           duration=int(_num(info.get('duration_secs'))), rating=r if r <= 10 else 0)
            li.addContextMenuItems([cm_fav(nome, surl, logo, 'video', k='vod')])
            ent.append((url_para({'acao': 'play', 'url': surl, 'nome': nome, 'logo': logo, 'k': 'vod'}), li, False))
    add_all(ent)
    fim('episodes')


def mostrar_catchup(srv_idx, stream_id, nome):
    srv = _srv_ou_erro(srv_idx)
    if not srv:
        return
    lst = api.xt_catchup_listings(srv, stream_id)
    xbmcplugin.setPluginCategory(HANDLE, L(30236) + nome)
    if not lst:
        notificar(L(30234), xbmcgui.NOTIFICATION_INFO)
        fim(ok=False)
        return
    ent = []
    for p in lst:
        quando = time.strftime('%d/%m %H:%M', time.localtime(p['ini']))
        label = '{}  {}'.format(quando, p['titulo'])
        url = api.xt_catchup_url(srv, stream_id, p['start'], p['ini'], p['fim'])
        li = mk_li(label, '', '', True)
        set_video_info(li, title=p['titulo'], plot=p['descricao'], duration=p['fim'] - p['ini'])
        ent.append((url_para({'acao': 'play', 'url': url, 'nome': p['titulo'], 'k': 'vod'}), li, False))
    add_all(ent)
    fim()


# ════════════════════════════════════════════════════════
#  Stalker / MAG
# ════════════════════════════════════════════════════════

def mostrar_canais_stalker(srv_idx, st_tipo, cat_id, cat_nome, pag=0):
    srv = _srv_ou_erro(srv_idx)
    if not srv:
        return
    bg = [None]

    def _prog(i, n):
        if bg[0] is None:
            bg[0] = xbmcgui.DialogProgressBG()
            bg[0].create(ADDON_NAME, L(30237))
        bg[0].update(int(i * 100 / max(n, 1)), ADDON_NAME, '{} / {}'.format(i, n))

    try:
        itens = api.stalker_canais(srv['host'], srv['mac'], st_tipo, cat_id, progress=_prog)
    finally:
        if bg[0]:
            bg[0].close()
    if not itens:
        notificar(L(30238))
        fim(ok=False)
        return

    lista = []
    for it in itens:
        nome = it.get('name', '') or it.get('o_name', '')
        if not nome or e_adulto(nome):
            continue
        cmd = (it.get('cmd') or '').strip()
        eps = it.get('series')
        if st_tipo == 'itv':
            if not cmd or 'http' not in cmd.lower():       # separadores
                continue
        elif not cmd and not eps:
            continue
        lista.append(it)

    params = {'acao': {'itv': 'stalker_live', 'vod': 'stalker_vod', 'series': 'stalker_series'}[st_tipo],
              'srv_idx': srv_idx, 'cat_id': cat_id, 'cat_nome': cat_nome}
    ini, f, nxt = pagina(len(lista), params, pag)
    xbmcplugin.setPluginCategory(HANDLE, cat_nome)
    ent = []
    for it in lista[ini:f]:
        nome = it.get('name', '') or it.get('o_name', '')
        cmd = (it.get('cmd') or '').strip()
        logo = api.stalker_abs(srv['host'], it.get('logo') or it.get('screenshot_uri') or '')
        eps = it.get('series')
        plot = it.get('description', '') or ''
        if isinstance(eps, list) and eps:
            li = mk_li(nome, logo, '')
            set_video_info(li, title=nome, mediatype='tvshow', plot=plot, year=_ano(it.get('year')),
                           genre=it.get('genres_str', '') or '')
            ent.append((url_para({'acao': 'stalker_eps', 'srv_idx': srv_idx, 'stalker_tipo': 'vod',
                                  'cmd': cmd, 'nome': nome, 'logo': logo,
                                  'eps': ','.join(str(e) for e in eps)}), li, True))
            continue
        li = mk_li(nome, logo, _fanart_de(logo) if st_tipo == 'itv' else '', True)
        set_video_info(li, title=nome, plot=plot, mediatype='video' if st_tipo == 'itv' else 'movie',
                       year=_ano(it.get('year')), genre=it.get('genres_str', '') or '')
        kind = 'live' if st_tipo == 'itv' else 'vod'
        li.addContextMenuItems([cm_fav(nome, '', logo, 'video', srv_idx=srv_idx, cmd=cmd,
                                       stalker_tipo=st_tipo, k=kind)])
        ent.append((url_para({'acao': 'stalker_play', 'srv_idx': srv_idx, 'stalker_tipo': st_tipo,
                              'cmd': cmd, 'nome': nome, 'logo': logo}), li, False))
    if nxt:
        ent.append(nxt)
    add_all(ent)
    fim('videos' if st_tipo == 'itv' else 'movies')


def mostrar_episodios_stalker(srv_idx, st_tipo, cmd, nome, logo, eps):
    xbmcplugin.setPluginCategory(HANDLE, nome)
    ent = []
    for n in [e for e in eps.split(',') if e]:
        label = L(30231).format(nome, n)
        li = mk_li(label, logo, '', True)
        set_video_info(li, title=label, mediatype='episode', episode=_ep_key(n), showtitle=nome)
        ent.append((url_para({'acao': 'stalker_play', 'srv_idx': srv_idx, 'stalker_tipo': st_tipo,
                              'cmd': cmd, 'nome': label, 'logo': logo, 'series': n}), li, False))
    add_all(ent)
    fim('episodes')


# ════════════════════════════════════════════════════════
#  M3U / M3U_plus
# ════════════════════════════════════════════════════════

_KIND_NOME = {'l': 30205, 'm': 30206, 's': 30207}


def _m3u_store(srv, forcar=False):
    """Indice da lista (descarrega/indexa se necessario). None em erro."""
    st = api.M3UStore(srv['url'])
    if not forcar and st.fresca(_ttl('m3u')):
        return st
    dp = xbmcgui.DialogProgress()
    dp.create(ADDON_NAME, L(30241))

    def _cb(total):
        mb = total / 1048576.0
        dp.update(min(90, int(mb * 4)), L(30242).format(mb))
        if dp.iscanceled():
            raise IOError('cancelado')

    try:
        st.construir(_cb)
        dp.update(100, L(30243))
        return st
    except Exception as e:
        log('M3U erro: ' + str(e), xbmc.LOGWARNING)
        if st.meta().get('groups') and os.path.exists(st.data_path):
            notificar(L(30244), xbmcgui.NOTIFICATION_WARNING)
            return st
        notificar(L(30245))
        return None
    finally:
        dp.close()


def mostrar_m3u_raiz(srv_idx, forcar=False):
    srv = _srv_ou_erro(srv_idx)
    if not srv:
        return
    st = _m3u_store(srv, forcar)
    if not st:
        fim(ok=False)
        return
    kinds = st.kinds()
    if len(kinds) > 1:
        ent = []
        for k in ('l', 'm', 's'):
            if k in kinds:
                ent.append((url_para({'acao': 'm3u_grupos', 'srv_idx': srv_idx, 'kind': k}),
                            mk_li(L(_KIND_NOME[k]), ICON, FANART), True))
        ent.append((url_para({'acao': 'pesquisa', 'srv_idx': srv_idx}), mk_li(L(30208), ICON, FANART), True))
        ent.append((url_para({'acao': 'm3u_refresh', 'srv_idx': srv_idx}), mk_li(L(30246), ICON, FANART), True))
        add_all(ent)
        fim()
    else:
        _listar_grupos(srv_idx, st, kinds[0] if kinds else 'l', extras=True)


def mostrar_grupos_m3u(srv_idx, kind='l'):
    srv = _srv_ou_erro(srv_idx)
    if not srv:
        return
    st = _m3u_store(srv)
    if not st:
        fim(ok=False)
        return
    _listar_grupos(srv_idx, st, kind)


def _listar_grupos(srv_idx, st, kind, extras=False):
    grupos = sorted(st.groups(kind), key=lambda g: prioridade_pt(g['n']))
    ent = []
    for g in grupos:
        li = mk_li(g['n'], g.get('l') or ICON, '')
        ent.append((url_para({'acao': 'm3u_canais', 'srv_idx': srv_idx, 'grupo': g['n'], 'kind': g['k']}), li, True))
    if extras:
        ent.append((url_para({'acao': 'pesquisa', 'srv_idx': srv_idx}), mk_li(L(30208), ICON, FANART), True))
        ent.append((url_para({'acao': 'm3u_refresh', 'srv_idx': srv_idx}), mk_li(L(30246), ICON, FANART), True))
    add_all(ent)
    fim()


def _item_m3u(e):
    logo = e.get('l') or ''
    kind = 'live' if e.get('k', 'l') == 'l' else 'vod'
    li = mk_li(e['n'], logo, _fanart_de(logo) if kind == 'live' else '', True)
    set_video_info(li, title=e['n'], mediatype='video' if kind == 'live' else 'movie')
    cms = [cm_fav(e['n'], e['u'], logo, 'video', k=kind, ua=e.get('ua', ''), ref=e.get('ref', ''))]
    if kind == 'live':
        cms.append(cm_diag(e['n'], e['u'], e.get('ua', ''), e.get('ref', '')))
    li.addContextMenuItems(cms)
    p = {'acao': 'play', 'url': e['u'], 'nome': e['n'], 'logo': logo, 'k': kind}
    if e.get('ua'):
        p['ua'] = e['ua']
    if e.get('ref'):
        p['ref'] = e['ref']
    return (url_para(p), li, False)


def mostrar_canais_m3u(srv_idx, grupo, kind='l', pag=0):
    srv = _srv_ou_erro(srv_idx)
    if not srv:
        return
    st = _m3u_store(srv)
    if not st:
        fim(ok=False)
        return
    ents = list(st.entries(kind, grupo))
    params = {'acao': 'm3u_canais', 'srv_idx': srv_idx, 'grupo': grupo, 'kind': kind}
    ini, f, nxt = pagina(len(ents), params, pag)
    xbmcplugin.setPluginCategory(HANDLE, grupo)
    ent = [_item_m3u(e) for e in ents[ini:f]]
    if nxt:
        ent.append(nxt)
    add_all(ent)
    fim('videos' if kind == 'l' else 'movies')


def m3u_refresh(srv_idx):
    mostrar_m3u_raiz(srv_idx, forcar=True)


# ════════════════════════════════════════════════════════
#  Pesquisa
# ════════════════════════════════════════════════════════

def pesquisar(srv_idx, q=None, pag=0):
    srv = _srv_ou_erro(srv_idx)
    if not srv:
        return
    if not q:
        kb = xbmc.Keyboard('', L(30247).format(srv['nome']))
        kb.doModal()
        if not kb.isConfirmed() or not kb.getText().strip():
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            return
        q = kb.getText().strip()
    termo = q.lower()

    dp = xbmcgui.DialogProgress()
    dp.create(ADDON_NAME, L(30248).format(q))
    items = []                                  # entradas (url, li, folder)
    try:
        if srv['tipo'] == 'xtream':
            srv = _com_idx(srv, srv_idx)
            dp.update(20, L(30249))
            for ch in api.xt_call(srv, 'get_live_streams', ttl=_ttl('api')) or []:
                n = ch.get('name', '')
                if termo in n.lower() and not e_adulto(n) and int(ch.get('stream_id', 0) or 0) > 0:
                    items.append(_item_live(srv, ch))
            dp.update(50, L(30250))
            for it in api.xt_call(srv, 'get_vod_streams', ttl=_ttl('api')) or []:
                n = it.get('name', '')
                if termo in n.lower() and not e_adulto(n) and int(it.get('stream_id', 0) or 0) > 0:
                    items.append(_item_vod(srv, it))
            dp.update(80, L(30251))
            for s in api.xt_call(srv, 'get_series', ttl=_ttl('api')) or []:
                if termo in s.get('name', '').lower():
                    items.append(_item_serie(srv_idx, s))
        elif srv['tipo'] == 'stalker':
            for st_tipo, pct, lab in (('itv', 20, L(30249)), ('vod', 55, L(30250))):
                dp.update(pct, lab)
                todos = api.stalker_canais(srv['host'], srv['mac'], st_tipo, '*', search=q) or []
                if not todos:
                    todos = [c for c in api.stalker_canais(srv['host'], srv['mac'], st_tipo, '*')
                             if termo in c.get('name', '').lower()]
                for it in todos:
                    nome = it.get('name', '')
                    cmd = (it.get('cmd') or '').strip()
                    if not nome or termo not in nome.lower() or e_adulto(nome) or not cmd:
                        continue
                    if st_tipo == 'itv' and 'http' not in cmd.lower():
                        continue
                    logo = api.stalker_abs(srv['host'], it.get('logo') or it.get('screenshot_uri') or '')
                    eps = it.get('series')
                    if isinstance(eps, list) and eps:
                        li = mk_li(nome, logo, '')
                        items.append((url_para({'acao': 'stalker_eps', 'srv_idx': srv_idx, 'stalker_tipo': 'vod',
                                                'cmd': cmd, 'nome': nome, 'logo': logo,
                                                'eps': ','.join(str(e) for e in eps)}), li, True))
                        continue
                    li = mk_li(nome, logo, '', True)
                    set_video_info(li, title=nome)
                    items.append((url_para({'acao': 'stalker_play', 'srv_idx': srv_idx, 'stalker_tipo': st_tipo,
                                            'cmd': cmd, 'nome': nome, 'logo': logo}), li, False))
        else:
            dp.update(40, L(30252))
            st = _m3u_store(srv)
            if st:
                for e in st.search(termo):
                    items.append(_item_m3u(e))
    finally:
        dp.close()

    if not items:
        notificar(L(30253).format(q), xbmcgui.NOTIFICATION_INFO)
        fim(ok=False)
        return
    params = {'acao': 'pesquisa', 'srv_idx': srv_idx, 'q': q}
    ini, f, nxt = pagina(len(items), params, pag)
    xbmcplugin.setPluginCategory(HANDLE, L(30254).format(q))
    ent = items[ini:f]
    if nxt:
        ent.append(nxt)
    add_all(ent)
    fim()


# ════════════════════════════════════════════════════════
#  Reproducao
# ════════════════════════════════════════════════════════

def _registar_recente(nome, logo, play_params):
    try:
        import favourites
        import hashlib
        key = play_params.get('url') or (play_params.get('cmd', '') + play_params.get('series', ''))
        favourites.hist_add({'id': hashlib.md5((nome + key).encode('utf-8')).hexdigest()[:12],
                             'nome': nome, 'logo': logo, 'play': play_params})
    except Exception as e:
        log('recentes: ' + str(e))


def _resolver(url, nome, logo, kind, headers=None, stalker=None, rec=None):
    import playback
    try:
        path, li, engine = playback.build(url, nome, logo, kind=kind, headers=headers, stalker=stalker)
    except Exception as e:
        log('playback.build: ' + str(e), xbmc.LOGWARNING)
        notificar(L(30256))
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    try:                                        # para o fallback automatico do servico
        xbmcgui.Window(10000).setProperty(PROP_LAST, json.dumps(
            {'url': url, 'nome': nome, 'logo': logo, 'kind': kind, 'engine': engine, 'h': headers or {}}))
    except Exception:
        pass
    if rec:
        _registar_recente(nome, logo, rec)
    xbmcplugin.setResolvedUrl(HANDLE, True, li)


def reproduzir(params):
    url = params.get('url', '')
    if not url:
        notificar(L(30255))
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    import playback
    kind = params.get('k') or playback.guess_kind(url.split('|')[0])
    hdr = {}
    if params.get('ua'):
        hdr['User-Agent'] = params['ua']
    if params.get('ref'):
        hdr['Referer'] = params['ref']
    nome, logo = params.get('nome', ''), params.get('logo', '')
    rec = dict((k, v) for k, v in params.items() if k in ('acao', 'url', 'nome', 'logo', 'k', 'ua', 'ref'))
    _resolver(url, nome, logo, kind, hdr or None, None, rec)


def reproduzir_stalker(srv_idx, st_tipo, cmd, nome='', logo='', series=''):
    srv = get_srv(srv_idx)
    if not srv:
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    url = api.stalker_create_link(srv['host'], srv['mac'], st_tipo, cmd, series)
    if not url:
        notificar(L(30257))
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    kind = 'live' if st_tipo == 'itv' else 'vod'
    renew = {'host': srv['host'], 'mac': srv['mac'], 't': st_tipo, 'cmd': cmd, 's': series}
    rec = {'acao': 'stalker_play', 'srv_idx': srv_idx, 'stalker_tipo': st_tipo, 'cmd': cmd,
           'nome': nome, 'logo': logo}
    if series:
        rec['series'] = series
    _resolver(url, nome, logo, kind, None, renew, rec)


# ════════════════════════════════════════════════════════
#  Favoritos / Recentes
# ════════════════════════════════════════════════════════

def mostrar_favoritos():
    import favourites
    favs = favourites.listar()
    xbmcplugin.setPluginCategory(HANDLE, L(30202).format(len(favs)))
    if not favs:
        notificar(L(30258), xbmcgui.NOTIFICATION_INFO)
        fim(ok=False)
        return
    ent = []
    for fav in favs:
        nome = fav.get('nome', L(30260))
        logo = fav.get('logo', '') or ''
        tipo = fav.get('tipo', 'video')
        kind = fav.get('k') or ''
        cm = [(L(30259), 'RunPlugin({})'.format(
            url_para({'acao': 'fav_remover', 'fav_id': fav.get('id', '')})))]
        if tipo == 'tvshow':
            li = mk_li(nome, logo, '')
            set_video_info(li, title=nome, mediatype='tvshow')
            li.addContextMenuItems(cm)
            ent.append((url_para({'acao': 'series_temps', 'srv_idx': fav.get('srv_idx', '0'),
                                  'series_id': fav.get('series_id', ''), 'serie_nome': nome}), li, True))
        elif fav.get('cmd'):
            li = mk_li(nome, logo, '', True)
            set_video_info(li, title=nome)
            li.addContextMenuItems(cm)
            ent.append((url_para({'acao': 'stalker_play', 'srv_idx': fav.get('srv_idx', '0'),
                                  'stalker_tipo': fav.get('stalker_tipo', 'itv'), 'cmd': fav['cmd'],
                                  'nome': nome, 'logo': logo}), li, False))
        else:
            li = mk_li(nome, logo, '', True)
            set_video_info(li, title=nome, mediatype='movie' if tipo == 'movie' else 'video')
            li.addContextMenuItems(cm)
            p = {'acao': 'play', 'url': fav.get('url', ''), 'nome': nome, 'logo': logo}
            if kind:
                p['k'] = kind
            if fav.get('ua'):
                p['ua'] = fav['ua']
            if fav.get('ref'):
                p['ref'] = fav['ref']
            ent.append((url_para(p), li, False))
    add_all(ent)
    fim()


def mostrar_recentes():
    import favourites
    hist = favourites.hist_listar()
    xbmcplugin.setPluginCategory(HANDLE, L(30203))
    if not hist:
        notificar(L(30264), xbmcgui.NOTIFICATION_INFO)
        fim(ok=False)
        return
    ent = [(url_para({'acao': 'recentes_limpar'}), mk_li(L(30265), ICON, ''), False)]
    for h in hist:
        li = mk_li(h.get('nome', ''), h.get('logo', ''), '', True)
        set_video_info(li, title=h.get('nome', ''))
        ent.append((url_para(h.get('play', {})), li, False))
    add_all(ent)
    fim()


def acao_fav_adicionar(p):
    import favourites
    extras = dict((k, p.get(k, '')) for k in ('srv_idx', 'series_id', 'cmd', 'stalker_tipo', 'k', 'ua', 'ref'))
    ok = favourites.adicionar(p.get('fav_nome', ''), p.get('fav_url', ''), p.get('fav_logo', ''),
                              p.get('fav_tipo', 'video'), **extras)
    notificar(L(30261) if ok else L(30262), xbmcgui.NOTIFICATION_INFO)


def acao_fav_remover(fid):
    import favourites
    favourites.remover(fid)
    notificar(L(30263), xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin('Container.Refresh')


# ════════════════════════════════════════════════════════
#  DNS / Ferramentas
# ════════════════════════════════════════════════════════

def _dns():
    try:
        import dns_override
        return dns_override
    except Exception:
        return None


def acao_dns(provider):
    dns = _dns()
    if dns is None:
        notificar(L(30266))
        return
    if provider == 'sistema':
        dns.deactivate()
        notificar(L(30267), xbmcgui.NOTIFICATION_INFO)
    else:
        dns.activate(provider)
        notificar(L(30268).format(provider.upper()), xbmcgui.NOTIFICATION_INFO)
    try:
        common.atomic_write(os.path.join(common.profile_dir(), 'ontv_dns_provider.txt'), provider)
    except Exception:
        pass
    xbmc.executebuiltin('Container.Refresh')


def mostrar_dns_escolher():
    dns = _dns()
    actual = dns.current_provider() if dns else 'sistema'
    xbmcplugin.setPluginCategory(HANDLE, L(30269))
    labels = [('sistema', L(30270)), ('adguard', L(30271)), ('cloudflare', L(30272)),
              ('opendns', L(30273)), ('google', L(30274))]
    ent = []
    for key, label in labels:
        li = mk_li(('✅  ' if key == actual else '   ') + label, ICON, '')
        ent.append((url_para({'acao': 'dns_activar', 'dns_provider': key}), li, False))
    add_all(ent)
    fim()


def mostrar_ferramentas():
    dns = _dns()
    activo = dns.current_provider() if dns else 'sistema'
    import favourites
    xbmcplugin.setPluginCategory(HANDLE, L(30204))
    entradas = [
        (L(30275), 'definicoes', False),
        (L(30276).format(activo.upper()), 'dns_escolher', True),
        (L(30277), 'speed_test', False),
        (L(30278), 'limpar_cache', False),
        (L(30279), 'limpar_cache_dns', False),
        (L(30202).format(favourites.contar()), 'favoritos', True),
        (L(30203), 'recentes', True),
    ]
    ent = [(url_para({'acao': a}), mk_li(n, ICON, ''), pasta) for n, a, pasta in entradas]
    add_all(ent)
    fim()


def acao_speed_test():
    try:
        import speedtest
        speedtest.mostrar_resultado_kodi(None)
    except Exception as e:
        notificar(L(30280).format(e))


def acao_limpar_cache():
    n = common.cache_clear()
    try:
        from mediacfg import invalidar_cache
        invalidar_cache()
    except Exception:
        pass
    notificar(L(30281).format(n), xbmcgui.NOTIFICATION_INFO)


def acao_limpar_cache_dns():
    dns = _dns()
    if dns:
        dns.clear_cache()
        notificar(L(30282), xbmcgui.NOTIFICATION_INFO)


# ════════════════════════════════════════════════════════
#  Router
# ════════════════════════════════════════════════════════

_LIVRES_DURANTE_PLAY = ('play', 'stalker_play', 'pesquisa', 'fav_add', 'fav_remover', 'dns_activar',
                        'speed_test', 'limpar_cache', 'limpar_cache_dns', 'definicoes', 'conta', 'diagnostico',
                        'recentes_limpar')


def run():
    global HANDLE, BASE_URL
    BASE_URL = sys.argv[0]
    HANDLE = int(sys.argv[1])
    P = dict(parse_qsl(sys.argv[2][1:]))
    acao = P.get('acao', 'main')
    log('Acao=' + acao)

    if acao not in _LIVRES_DURANTE_PLAY:
        try:
            if xbmc.Player().isPlaying():
                xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
                return
        except Exception:
            pass

    s = P.get('srv_idx', '')
    cid, cnm = P.get('cat_id', ''), P.get('cat_nome', '')
    pag = int(P.get('pag', '0') or 0)

    if acao == 'main':               mostrar_principal()
    elif acao == 'tipos':            mostrar_tipos(s)
    elif acao in ('live_cats', 'vod_cats', 'series_cats'):
        mostrar_categorias(s, acao)
    elif acao == 'live_canais':      mostrar_live(s, cid, cnm, pag)
    elif acao == 'vod_canais':       mostrar_vod(s, cid, cnm, pag)
    elif acao == 'series_canais':    mostrar_series(s, cid, cnm, pag)
    elif acao == 'series_temps':     mostrar_temporadas(s, P.get('series_id', ''), P.get('serie_nome', ''))
    elif acao == 'series_eps':       mostrar_episodios(s, P.get('series_id', ''), P.get('serie_nome', ''), P.get('temporada'))
    elif acao == 'catchup':          mostrar_catchup(s, P.get('stream_id', ''), P.get('nome', ''))
    elif acao == 'conta':
        mostrar_conta(s)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
    elif acao == 'stalker_live':     mostrar_canais_stalker(s, 'itv', cid or '*', cnm, pag)
    elif acao == 'stalker_vod':      mostrar_canais_stalker(s, 'vod', cid or '*', cnm, pag)
    elif acao == 'stalker_series':   mostrar_canais_stalker(s, 'series', cid or '*', cnm, pag)
    elif acao == 'stalker_eps':
        mostrar_episodios_stalker(s, P.get('stalker_tipo', 'vod'), P.get('cmd', ''), P.get('nome', ''),
                                  P.get('logo', ''), P.get('eps', ''))
    elif acao == 'stalker_play':
        reproduzir_stalker(s, P.get('stalker_tipo', 'itv'), P.get('cmd', ''), P.get('nome', ''),
                           P.get('logo', ''), P.get('series', ''))
    elif acao == 'm3u_grupos':       mostrar_grupos_m3u(s, P.get('kind', 'l'))
    elif acao == 'm3u_canais':       mostrar_canais_m3u(s, P.get('grupo', ''), P.get('kind', 'l'), pag)
    elif acao == 'm3u_refresh':      m3u_refresh(s)
    elif acao == 'pesquisa':         pesquisar(s, P.get('q'), pag)
    elif acao == 'play':             reproduzir(P)
    elif acao == 'favoritos':        mostrar_favoritos()
    elif acao == 'recentes':         mostrar_recentes()
    elif acao == 'recentes_limpar':
        import favourites
        favourites.hist_limpar()
        xbmc.executebuiltin('Container.Refresh')
    elif acao == 'diagnostico':      acao_diagnostico(P)
    elif acao == 'fav_add':          acao_fav_adicionar(P)
    elif acao == 'fav_remover':      acao_fav_remover(P.get('fav_id', ''))
    elif acao == 'ferramentas':      mostrar_ferramentas()
    elif acao == 'definicoes':       ADDON.openSettings()
    elif acao == 'dns_escolher':     mostrar_dns_escolher()
    elif acao == 'dns_activar':      acao_dns(P.get('dns_provider', 'sistema'))
    elif acao == 'speed_test':       acao_speed_test()
    elif acao == 'limpar_cache':     acao_limpar_cache()
    elif acao == 'limpar_cache_dns': acao_limpar_cache_dns()
    else:                            mostrar_principal()
