from ..models import *
from typing import Optional, List
import re
import json
import base64
import requests
from urllib.parse import urlparse, parse_qs, unquote, quote, urljoin, urlunparse
from ..tools import debug_log
from .._core import get_session
from ..util import embedsportstop
from ..util import taifood_mint
from ..util.hunter import hunter
from ..util.stream_proxy import get_stream_proxy
import xbmc


def _ffmpegdirect_live() -> JetInputstreamFFmpegDirect:
    """inputstream.ffmpegdirect in stream_mode='live' (NOT the 'timeshift' default)."""
    return JetInputstreamFFmpegDirect(manifest_type="hls", is_realtime_stream=True, stream_mode="live")


class ReedStreams(JetExtractor):
    # Hosts with dedicated resolvers below; skip the reachability probe for
    # these and for any new/unknown host only include it when the page is
    # actually reachable from this network.
    KNOWN_SOURCE_HOSTS = (
        "watchthematch.online",
        "sportsembed",
        "taifood-blog.asia",
        "strmfree.st",
        "streamfree.top",
        "justpasstheball.online",
        "embed.st",
        "embedsports.top",
        "embedindia",
        "viloud.tv",
        "edgesport.cfd",
    )
    # Hosts whose player page can load but whose HLS master resets every
    # Python/requests connection (browser-only TLS). Showing them only
    # produces a guaranteed dead option in the picker.
    UNSUPPORTED_SOURCE_HOSTS = ("click.blossomz.store",)

    def __init__(self) -> None:
        self.domains = [
            "reedstreams.to",
            "api.reedstreams.link",
            # Provider embeds returned in the match API (direct ?urls= support).
            "watchthematch.online",
            "sportsembed.store",
            "sportsembed.su",
            "justpasstheball.online",
            "strmfree.st",
            "streamfree.top",
            "click.blossomz.store:8443",
        ]
        self.name = "ReedStreams"
        self.short_name = "REED"
        self.timeout = 15
        self.user_agent = (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
        )
        self.player_ua = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36"
        self.smart_tv_ua = "Mozilla/5.0 (SMART-TV; Linux; Tizen 6.0) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/16.0 TV Safari/537.36"

    def _session(self) -> requests.Session:
        s = requests.Session()
        s.verify = False
        s.headers.update({
            "User-Agent": self.user_agent,
            "Accept": "application/json, text/plain, */*",
            "Accept-Language": "en-US,en;q=0.9",
        })
        return s

    def _proxy_url(self, embed_url: str, name: str) -> str:
        """Create a proxy URL that points back to this extractor for resolution."""
        return f"https://{self.domains[0]}/jetextractor/reedstreams?url={quote(embed_url, safe='')}&name={quote(name, safe='')}"

    @staticmethod
    def _as_match_url(address: str) -> str:
        """Map the site's /watch/<slug> page to the JSON API /match/<slug>."""
        try:
            parsed = urlparse(address)
        except Exception:
            return address
        if parsed.netloc.lower().endswith("reedstreams.to") and parsed.path.startswith("/watch/"):
            return urlunparse(parsed._replace(path="/match/" + parsed.path[len("/watch/"):]))
        return address

    def _decode_proxy(self, address: str) -> str:
        """Extract the original embed URL from a proxy URL."""
        parsed = urlparse(address)
        if parsed.path == "/jetextractor/reedstreams" and parsed.netloc in self.domains:
            return parse_qs(parsed.query).get("url", [""])[0]
        return address

    def _select_variant(self, session: requests.Session, master_url: str, headers: dict) -> str:
        """Fetch master playlist and pick a real HLS variant, preferring highest quality."""
        try:
            fetch_headers = dict(headers)
            fetch_headers.setdefault("Accept", "*/*")
            fetch_headers.setdefault("Connection", "close")
            fetch_headers.setdefault("Icy-MetaData", "1")

            r = session.get(master_url, headers=fetch_headers, timeout=self.timeout, verify=False)
            text = r.text
            debug_log(f"[ReedStreams] Master playlist ({len(text)} chars):\n{text[:2000]}", xbmc.LOGINFO)
            if "#EXTM3U" not in text:
                debug_log("[ReedStreams] Master fetch failed, retrying with Chrome/143 UA", xbmc.LOGWARNING)
                fetch_headers["User-Agent"] = self.player_ua
                r = session.get(master_url, headers=fetch_headers, timeout=self.timeout, verify=False)
                text = r.text
                debug_log(f"[ReedStreams] Retry master playlist ({len(text)} chars):\n{text[:2000]}", xbmc.LOGINFO)
                if "#EXTM3U" not in text:
                    debug_log("[ReedStreams] Upstream did not return a valid M3U8", xbmc.LOGERROR)
                    return ""

            lines = [line.strip() for line in text.splitlines() if line.strip()]
            variants = []
            for i, line in enumerate(lines):
                if line.upper().startswith("#EXT-X-STREAM-INF"):
                    bw = 0
                    m = re.search(r'BANDWIDTH=(\d+)', line)
                    if m:
                        bw = int(m.group(1))
                    for j in range(i + 1, len(lines)):
                        if not lines[j].startswith("#"):
                            variants.append((bw, lines[j]))
                            break
            if not variants:
                debug_log("[ReedStreams] No variants found, using master URL", xbmc.LOGINFO)
                return master_url

            debug_log(f"[ReedStreams] Found {len(variants)} variant(s): {variants}", xbmc.LOGINFO)
            if len(variants) == 1:
                return urljoin(master_url, variants[0][1])

            # Always prefer the highest bandwidth variant
            variants.sort(key=lambda x: x[0], reverse=True)
            return urljoin(master_url, variants[0][1])
        except Exception as e:
            debug_log(f"[ReedStreams] _select_variant error: {e}", xbmc.LOGERROR)
            return master_url

    def _hunt_m3u8(self, html: str, base_url: str) -> Optional[str]:
        """Decode an eval(function(h,u,n,t,e,r)...) packed player and pull the m3u8.

        sportsembed.store pages ship a hunter-packed videojs player whose
        decoded JS contains player.src({src: "<m3u8>"}).
        """
        m = re.search(
            r'eval\(function\(h,u,n,t,e,r\).*?\}\("([^"]+)",(\d+),"([^"]+)",(\d+),(\d+),(\d+)\)\)',
            html, re.S)
        if not m:
            return None
        try:
            decoded = hunter(
                h=m.group(1), u=int(m.group(2)), n=m.group(3),
                t=int(m.group(4)), e=int(m.group(5)), r=int(m.group(6)))
        except Exception as e:
            debug_log(f"[ReedStreams] hunter decode failed: {e}", xbmc.LOGWARNING)
            return None
        urls = re.findall(r'(?:https?:)?//[^\s"\'<>]+\.m3u8[^\s"\'<>]*', decoded)
        if not urls:
            debug_log("[ReedStreams] hunter decoded but found no m3u8", xbmc.LOGWARNING)
            return None
        stream_url = urls[0]
        if stream_url.startswith("//"):
            stream_url = "https:" + stream_url
        elif not stream_url.startswith("http"):
            stream_url = urljoin(base_url, stream_url)
        debug_log(f"[ReedStreams] hunter m3u8: {stream_url}", xbmc.LOGINFO)
        return stream_url

    def _unwrap_watchthematch(self, embed_url: str) -> Optional[str]:
        """watchthematch.online /embed/<id> wraps the real embed URL as base64.

        The old /v1/channel/<id>/index.m3u8 construction now returns 402;
        decode the token and resolve the inner URL instead.
        """
        m = re.search(r'/embed/([^/?]+)', embed_url)
        if not m:
            return None
        token = m.group(1)
        try:
            pad = "=" * ((4 - len(token) % 4) % 4)
            decoded = base64.b64decode(token + pad).decode("utf-8")
            if decoded.startswith("http"):
                debug_log(f"[ReedStreams] watchthematch token unwrapped to: {decoded}", xbmc.LOGINFO)
                return decoded
        except Exception as e:
            debug_log(f"[ReedStreams] watchthematch base64 decode failed: {e}", xbmc.LOGDEBUG)
        return None

    def _resolve_taifood(self, embed_url: str) -> Optional[JetLink]:
        """Mint a fresh indianservers playlist for a taifood admin embed.

        Same shared-issuer path as Embedsport2/EmbedHDApi (util/taifood_mint).
        Tokens are short-window: re-mint on the proxy refresh callback.
        """
        uri_name = taifood_mint.uri_name_from_iframe(embed_url)
        if not uri_name:
            debug_log(f"[ReedStreams] No /embed/ path in taifood URL: {embed_url}", xbmc.LOGERROR)
            return None

        def _refresh_callback():
            fresh = taifood_mint.mint(uri_name)
            if not fresh:
                return None
            return {"url": fresh, "headers": taifood_mint.stream_headers()}

        stream_url = taifood_mint.mint(uri_name)
        if stream_url and not taifood_mint.verify_m3u8(stream_url):
            debug_log(f"[ReedStreams] Taifood mint verify failed for {uri_name}, re-minting once", xbmc.LOGWARNING)
            stream_url = taifood_mint.mint(uri_name)
        if not stream_url or not taifood_mint.verify_m3u8(stream_url):
            debug_log(f"[ReedStreams] Failed to mint playable taifood stream for {uri_name}", xbmc.LOGWARNING)
            return None

        headers = taifood_mint.stream_headers()
        proxy = get_stream_proxy(
            "reedstreams",
            headers,
            options={
                "cache_manifest": False,
                "proxy_absolute_urls": True,
                # indianservers segments are WebP-wrapped MPEG-TS.
                "strip_png": True,
                # indianservers.st rejects Chrome desktop UA + close-per-request fetches.
                "user_agent": taifood_mint.STREAMED_TV_UA,
                "upstream_keep_alive": True,
                "prefetch_segments": True,
                "prefetch_depth": 3,
                "keep_alive": False,
            },
        )
        proxy_url = proxy.get_proxy_url(stream_url, headers, refresh_callback=_refresh_callback)
        debug_log(f"[ReedStreams] Taifood mint OK for {uri_name}: {stream_url[:100]}", xbmc.LOGINFO)
        return JetLink(
            address=proxy_url,
            headers=headers,
            inputstream=taifood_mint.ffmpegdirect_live(),
            resolveurl=False,
        )

    def _resolve_strmfree(self, embed_url: str, headers: dict) -> Optional[str]:
        """Resolve a strmfree.st embed via its get-stream-key API.

        The embed page carries QUALITY/VARIANT/token-map JS; the API returns
        either an external_url or a server_name used to build the HLS path.
        """
        session = self._session()
        try:
            resp = session.get(embed_url, timeout=self.timeout)
            if resp.status_code != 200:
                debug_log(f"[ReedStreams] strmfree embed returned {resp.status_code}", xbmc.LOGWARNING)
                return None
            html = resp.text

            qm = re.search(r"const\s+QUALITY\s*=\s*'([^']+)'", html)
            sm = re.search(r"const\s+VARIANT\s*=\s*'([^']+)'\s*\+\s*QUALITY", html)
            km = re.search(r"get-stream-key/([^'\"]+)", html)
            tm = re.search(r"const\s+_0x\s*=\s*(\{.*?\});", html, re.S)
            sm_suffix = re.search(r"const\s+SOURCE_SUFFIX\s*=\s*'([^']*)'", html)
            if not (qm and sm and km):
                debug_log("[ReedStreams] strmfree page missing VARIANT/QUALITY/get-stream-key", xbmc.LOGWARNING)
                return None

            quality = qm.group(1)
            slug = km.group(1)
            # VARIANT = "<base>" + QUALITY + SOURCE_SUFFIX (e.g. "...1080p2");
            # the stream key API returns only the base, so the suffix must be
            # appended or the CDN answers 403.
            variant = sm.group(1) + quality + (sm_suffix.group(1) if sm_suffix else "")
            tokens = {}
            if tm:
                try:
                    tokens = json.loads(tm.group(1))
                except Exception:
                    tokens = {}

            origin = f"https://{urlparse(embed_url).netloc}"
            kresp = session.get(f"{origin}/get-stream-key/{slug}", timeout=self.timeout)
            if kresp.status_code != 200:
                debug_log(f"[ReedStreams] strmfree get-stream-key returned {kresp.status_code}", xbmc.LOGWARNING)
                return None
            data = kresp.json()

            if data.get("is_external") and data.get("external_url"):
                stream_url = data["external_url"]
            else:
                server = data.get("server_name") or "origin"
                if server == "externalcdn":
                    path = f"/live-externalcdn/{variant}/index.m3u8"
                elif server != "origin":
                    path = f"/live-cdn/{variant}/index.m3u8"
                else:
                    path = f"/live/{variant}/index.m3u8"
                tok = tokens.get(quality)
                if tok:
                    path += f"?_t={tok['_t']}&_e={tok['_e']}&_n={tok['_n']}"
                stream_url = origin + path

            headers["Referer"] = embed_url
            headers["Origin"] = origin
            debug_log(f"[ReedStreams] strmfree stream: {stream_url}", xbmc.LOGINFO)
            return stream_url
        except Exception as e:
            debug_log(f"[ReedStreams] strmfree resolve error: {e}", xbmc.LOGERROR)
            import traceback
            debug_log(traceback.format_exc(), xbmc.LOGERROR)
            return None

    def get_items(self, params: Optional[dict] = None, progress: Optional[JetExtractorProgress] = None) -> List[JetItem]:
        items = []
        if self.progress_init(progress, items):
            return items

        session = self._session()
        api_url = "https://api.reedstreams.link/api/matches/all"
        
        try:
            debug_log(f"[ReedStreams] Fetching matches from {api_url}", xbmc.LOGINFO)
            resp = session.get(api_url, timeout=self.timeout)
            if resp.status_code != 200:
                debug_log(f"[ReedStreams] API returned status {resp.status_code}", xbmc.LOGWARNING)
                return items
            
            matches = resp.json()
            debug_log(f"[ReedStreams] Got {len(matches)} matches", xbmc.LOGINFO)
            
            for match in matches:
                match_id = match.get("id", "")
                title = match.get("title", "Unknown Match")
                category = match.get("category", "Sports")
                date_ts = match.get("date", 0)
                
                # Build match page URL
                match_url = f"https://reedstreams.to/match/{match_id}"
                
                # Create JetLink to match page (will be resolved in get_links)
                link = JetLink(
                    address=match_url,
                    name=title,
                    links=True,  # This will trigger get_links()
                )
                
                item = JetItem(
                    title=title,
                    links=[link],
                    league=category,
                )
                
                if date_ts:
                    from datetime import datetime
                    item.starttime = datetime.fromtimestamp(date_ts / 1000)
                
                items.append(item)
                
        except Exception as e:
            debug_log(f"[ReedStreams] Error fetching matches: {e}", xbmc.LOGERROR)
            import traceback
            debug_log(traceback.format_exc(), xbmc.LOGERROR)
        
        return items

    def get_links(self, url: JetLink) -> List[JetLink]:
        links = []
        match_url = self._as_match_url(url.address)

        debug_log(f"[ReedStreams] get_links called for: {match_url}", xbmc.LOGINFO)
        
        # Extract match ID from URL
        match_id_match = re.search(r'/match/([^/?]+)', match_url)
        if not match_id_match:
            embed_url = self._decode_proxy(match_url)
            debug_log(f"[ReedStreams] get_links passed a non-match URL: {embed_url}", xbmc.LOGINFO)
            if embed_url:
                return [JetLink(
                    address=embed_url,
                    name=url.name or "Stream",
                    resolveurl=True,
                    extractor=self.name,
                )]
            return links
        
        match_id = match_id_match.group(1)
        
        # Fetch match page JSON with retry logic
        session = self._session()
        max_retries = 3
        sources = []
        for attempt in range(max_retries):
            try:
                debug_log(f"[ReedStreams] Fetching match data for {match_id} (attempt {attempt+1}/{max_retries})", xbmc.LOGINFO)
                resp = session.get(match_url, timeout=self.timeout)
                if resp.status_code != 200:
                    debug_log(f"[ReedStreams] Match page returned status {resp.status_code}", xbmc.LOGWARNING)
                    return links
                
                match_data = resp.json()
                sources = match_data.get("sources", [])
                debug_log(f"[ReedStreams] Got {len(sources)} sources", xbmc.LOGINFO)
                break  # Success, exit retry loop
                
            except requests.exceptions.Timeout:
                debug_log(f"[ReedStreams] Timeout on attempt {attempt+1}/{max_retries}", xbmc.LOGWARNING)
                if attempt < max_retries - 1:
                    import time
                    time.sleep(2 ** attempt)  # Exponential backoff
                    continue
                else:
                    debug_log(f"[ReedStreams] All {max_retries} attempts timed out", xbmc.LOGERROR)
                    return links
            except Exception as e:
                debug_log(f"[ReedStreams] Error fetching match data: {e}", xbmc.LOGERROR)
                import traceback
                debug_log(traceback.format_exc(), xbmc.LOGERROR)
                return links
        
        # Process sources
        try:
            for source in sources:
                source_name = source.get("sourceName", source.get("source", "Unknown"))
                embed_url = source.get("embedUrl", "")
                provider = source.get("provider", "")
                quality = source.get("quality", "")
                language = source.get("language", "")
                hd = source.get("hd", False)
                
                if not embed_url:
                    continue

                source_host = urlparse(embed_url).netloc.lower()
                if any(k in source_host for k in self.UNSUPPORTED_SOURCE_HOSTS):
                    debug_log(f"[ReedStreams] Skipping unsupported source {source_name} ({source_host}): browser-only TLS", xbmc.LOGWARNING)
                    continue
                if not any(k in source_host for k in self.KNOWN_SOURCE_HOSTS):
                    try:
                        probe = self._session().get(embed_url, timeout=(3, 3), stream=True)
                        probe.close()
                    except Exception as e:
                        debug_log(f"[ReedStreams] Skipping unreachable source {source_name} ({source_host}): {e}", xbmc.LOGWARNING)
                        continue
                
                # Build display name without parentheses: the consumer's
                # link_dialog treats the last "(...)" group as the label.
                name_parts = [source_name]
                if quality:
                    name_parts.append(quality)
                if language:
                    name_parts.append(language)
                display_name = " | ".join(p for p in name_parts if p)
                
                # Create JetLink with proxy URL that points back to this extractor
                proxy_url = self._proxy_url(embed_url, display_name)
                link = JetLink(
                    address=proxy_url,
                    name=display_name,
                )
                links.append(link)
                
                debug_log(f"[ReedStreams] Added source: {display_name} -> {embed_url}", xbmc.LOGDEBUG)
                
        except Exception as e:
            debug_log(f"[ReedStreams] Error processing sources: {e}", xbmc.LOGERROR)
            import traceback
            debug_log(traceback.format_exc(), xbmc.LOGERROR)
        
        return links

    def get_link(self, url: JetLink) -> JetLink:
        # Decode proxy URL to get the original embed URL
        embed_url = self._decode_proxy(url.address)
        if not embed_url:
            embed_url = url.address

        # Direct match/watch-page URL: resolve the source list and try each
        # source in site order until one produces a playable link.
        match_url = self._as_match_url(embed_url)
        parsed_embed = urlparse(match_url)
        if "/match/" in parsed_embed.path and "reedstreams.to" in parsed_embed.netloc.lower():
            debug_log(f"[ReedStreams] Direct match page: {match_url}", xbmc.LOGINFO)
            for candidate in self.get_links(JetLink(address=match_url)):
                resolved = self.get_link(candidate)
                if resolved is None:
                    continue
                if resolved.direct or resolved.inputstream is not None:
                    return resolved
                if ".m3u8" in resolved.address or ".mpd" in resolved.address:
                    return resolved
            debug_log(f"[ReedStreams] No playable source for match page: {match_url}", xbmc.LOGWARNING)
            return None

        debug_log(f"[ReedStreams] get_link called for: {embed_url}", xbmc.LOGINFO)
        
        stream_url = None
        headers = {"User-Agent": self.user_agent}
        
        try:
            parsed = urlparse(embed_url)
            host = parsed.netloc.lower()
            
            # Handle watchthematch.online (krishna provider).
            # The /embed/<id> token is base64 of the REAL embed URL; the old
            # /v1/channel/<id>/index.m3u8 construction returns 402 now.
            # Unwrap and re-resolve the inner URL via this same method.
            if "watchthematch.online" in host:
                inner = self._unwrap_watchthematch(embed_url)
                # Re-resolve the inner URL, but never recurse into another
                # watchthematch wrapper (guards against crafted loops).
                if inner and "watchthematch.online" not in urlparse(inner).netloc.lower():
                    return self.get_link(JetLink(address=inner))
                # Legacy fallback: raw channel id (non-base64) on /v1/channel/
                path_match = re.search(r'/embed/([^/?]+)', embed_url)
                if path_match:
                    channel_id = path_match.group(1)
                    stream_url = f"https://watchthematch.online/v1/channel/{channel_id}/index.m3u8"
                    debug_log(f"[ReedStreams] Constructed legacy stream URL: {stream_url}", xbmc.LOGINFO)
                    headers["Referer"] = "https://watchthematch.online/"
                    headers["Origin"] = "https://watchthematch.online"
                else:
                    debug_log(f"[ReedStreams] Could not extract channel ID from {embed_url}", xbmc.LOGWARNING)
                    return None
            
            # Handle taifood-blog.asia admin embeds - shared indianservers mint
            elif taifood_mint.is_taifood_url(embed_url):
                debug_log(f"[ReedStreams] Resolving taifood admin embed via mint", xbmc.LOGINFO)
                return self._resolve_taifood(embed_url)
            
            # Handle strmfree.st (Reed 2 sources) - get-stream-key API
            elif "strmfree.st" in host or "streamfree.top" in host:
                debug_log(f"[ReedStreams] Resolving strmfree.st embed", xbmc.LOGINFO)
                stream_url = self._resolve_strmfree(embed_url, headers)
                if not stream_url:
                    return None
            
            # Handle sportsembed.* (store = hunter-packed player, su = embedindia iframe)
            elif "sportsembed" in host:
                debug_log(f"[ReedStreams] Resolving sportsembed page: {embed_url}", xbmc.LOGINFO)
                session = self._session()
                try:
                    resp = session.get(embed_url, timeout=20)
                    if resp.status_code != 200:
                        debug_log(f"[ReedStreams] sportsembed returned status {resp.status_code}", xbmc.LOGWARNING)
                        return None
                    # sportsembed.store ships a hunter-packed videojs player with the m3u8 inline.
                    stream_url = self._hunt_m3u8(resp.text, embed_url)
                    if stream_url:
                        headers["Referer"] = f"https://{host}/"
                        headers["Origin"] = f"https://{host}"
                    else:
                        # sportsembed.su legacy layout: iframe to embedindia.st
                        iframe_match = re.search(r'<iframe[^>]+src=["\']([^"\']+)["\']', resp.text, re.I)
                        if iframe_match:
                            iframe_url = iframe_match.group(1)
                            if iframe_url.startswith("//"):
                                iframe_url = "https:" + iframe_url
                            debug_log(f"[ReedStreams] Found iframe: {iframe_url}", xbmc.LOGINFO)
                            if "embedindia" in iframe_url:
                                stream_url = embedsportstop.get_embedsportstop_stream(iframe_url)
                                iframe_host = urlparse(iframe_url).netloc
                                headers["Referer"] = f"https://{iframe_host}/"
                                headers["Origin"] = f"https://{iframe_host}"
                        else:
                            debug_log("[ReedStreams] No hunter m3u8 and no iframe in sportsembed page", xbmc.LOGWARNING)
                except requests.exceptions.Timeout:
                    debug_log("[ReedStreams] Timeout fetching sportsembed", xbmc.LOGWARNING)
                    return None
                except Exception as e:
                    debug_log(f"[ReedStreams] Error resolving sportsembed: {e}", xbmc.LOGWARNING)
                    return None
            
            # Handle embed.st sources (admin, delta, echo, golf)
            elif "embed.st" in host:
                debug_log(f"[ReedStreams] Resolving embed.st URL via embedsportstop", xbmc.LOGINFO)
                stream_url = embedsportstop.get_embedsportstop_stream(embed_url)
                headers["Referer"] = f"https://{host}/"
                headers["Origin"] = f"https://{host}"
            
            # Handle embedsports.top sources (foxtrot, etc.)
            elif "embedsports.top" in host:
                debug_log(f"[ReedStreams] Resolving embedsports.top URL via embedsportstop", xbmc.LOGINFO)
                try:
                    stream_url = embedsportstop.get_embedsportstop_stream(embed_url)
                    headers["Referer"] = f"https://{host}/"
                    headers["Origin"] = f"https://{host}"
                except Exception as e:
                    debug_log(f"[ReedStreams] Error resolving embedsports.top: {e}", xbmc.LOGWARNING)
                    return None
            
            # Handle viloud.tv (m3u8 in URL parameter)
            elif "viloud.tv" in host:
                debug_log(f"[ReedStreams] Resolving viloud.tv (extracting URL param)", xbmc.LOGINFO)
                qs = parse_qs(parsed.query)
                url_param = qs.get("url", [None])[0]
                if url_param:
                    stream_url = unquote(url_param)
                    debug_log(f"[ReedStreams] Extracted m3u8 from URL param: {stream_url}", xbmc.LOGINFO)
                    headers["Referer"] = "https://player.viloud.tv/"
                    headers["Origin"] = "https://player.viloud.tv"
            
            # Handle embedindia.st directly
            elif "embedindia" in host:
                debug_log(f"[ReedStreams] Resolving embedindia URL via embedsportstop", xbmc.LOGINFO)
                stream_url = embedsportstop.get_embedsportstop_stream(embed_url)
                headers["Referer"] = f"https://{host}/"
                headers["Origin"] = f"https://{host}"

            # Handle justpasstheball.online (oreo provider). The watch page
            # builds /live/<id>.m3u8 (AES-128 + absolute segment hosts), while
            # /live-local.m3u8 is a stale local test playlist with 404 segments.
            elif "justpasstheball.online" in host:
                qs = parse_qs(parsed.query)
                stream_id = (qs.get("id") or qs.get("stream") or [None])[0]
                custom = (qs.get("url") or qs.get("src") or [None])[0]
                source_kind = (qs.get("source") or [""])[0]
                if custom:
                    stream_url = custom if custom.startswith("http") else urljoin(embed_url, custom)
                elif stream_id:
                    prefix = "/live-local/" if source_kind in ("local", "direct") else "/live/"
                    stream_url = f"https://{host}{prefix}{quote(stream_id)}.m3u8"
                else:
                    stream_url = f"https://{host}/live.m3u8"
                headers["Referer"] = embed_url
                headers["Origin"] = f"https://{host}"
                debug_log(f"[ReedStreams] justpasstheball stream: {stream_url}", xbmc.LOGINFO)

            # Handle edgesport.cfd (complex obfuscation - best effort)
            elif "edgesport.cfd" in host:
                debug_log(f"[ReedStreams] edgesport.cfd requires complex deobfuscation - skipping", xbmc.LOGWARNING)
                # This source type has multi-layer obfuscation that's difficult to decode
                # Return None to skip this source
                return None
            
            else:
                debug_log(f"[ReedStreams] Unknown host: {host} - attempting generic resolution", xbmc.LOGWARNING)
                # Try generic iframe/m3u8 scanning
                from .._core import find_iframes, find_m3u8
                session = self._session()
                resp = session.get(embed_url, timeout=self.timeout)
                if resp.status_code == 200:
                    # Try to find m3u8 directly
                    m3u8 = find_m3u8(resp.text, embed_url)
                    if m3u8:
                        stream_url = m3u8
                    else:
                        # Try iframes
                        iframes = find_iframes(resp.text, embed_url)
                        if iframes:
                            debug_log(f"[ReedStreams] Found iframes: {iframes}", xbmc.LOGDEBUG)
                            # Try to resolve first iframe
                            for iframe_url in iframes:
                                if "embedindia" in iframe_url or "embed.st" in iframe_url:
                                    stream_url = embedsportstop.get_embedsportstop_stream(iframe_url)
                                    break
            
            if not stream_url:
                debug_log(f"[ReedStreams] Could not resolve stream URL from {embed_url}", xbmc.LOGWARNING)
                return None
            
            debug_log(f"[ReedStreams] Resolved stream URL: {stream_url}", xbmc.LOGINFO)
            
            # Select best variant from master playlist
            session = self._session()
            stream_url = self._select_variant(session, stream_url, headers)
            if not stream_url:
                debug_log("[ReedStreams] Could not select a valid variant", xbmc.LOGERROR)
                return None
            debug_log(f"[ReedStreams] Selected variant URL: {stream_url}", xbmc.LOGINFO)
            
            # Route through stream proxy with Smart TV User-Agent
            proxy = get_stream_proxy(
                "reedstreams",
                headers,
                options={
                    "strip_png": True,
                    "manifest_png_to_ts": True,
                    "proxy_absolute_urls": True,
                    "upstream_keep_alive": True,
                    "prefetch_segments": True,
                    "keep_alive": False,
                    "user_agent": self.smart_tv_ua,
                },
            )
            proxy_url = proxy.get_proxy_url(stream_url, headers)
            debug_log(f"[ReedStreams] Proxy URL: {proxy_url}", xbmc.LOGINFO)
            
            return JetLink(
                proxy_url,
                headers=headers,
                inputstream=_ffmpegdirect_live()
            )
            
        except Exception as e:
            debug_log(f"[ReedStreams] Error resolving {embed_url}: {e}", xbmc.LOGERROR)
            import traceback
            debug_log(traceback.format_exc(), xbmc.LOGERROR)
            return None
