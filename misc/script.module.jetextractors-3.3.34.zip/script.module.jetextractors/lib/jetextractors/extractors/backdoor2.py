from ..models import *
import requests
import re
import json
import base64
from typing import Optional, List, Union, Tuple
import xbmc
import time
import random
import traceback
from urllib.parse import urlparse, urljoin, unquote, quote
from bs4 import BeautifulSoup
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
from ..tools import debug_log
from ..util import backdoor2_store
from ..util.stream_proxy import build_proxy_url, get_stream_proxy
from .._core import get_session

_tls_session = None
try:
    import ssl
    from requests.adapters import HTTPAdapter
    _ctx = ssl.create_default_context()
    _ctx.set_ciphers("DEFAULT:@SECLEVEL=1")
    _ctx.check_hostname = False
    _ctx.verify_mode = ssl.CERT_NONE
    class _LowSecAdapter(HTTPAdapter):
        def init_poolmanager(self, *a, **kw):
            kw['ssl_context'] = _ctx
            super().init_poolmanager(*a, **kw)
    _tls_session = requests.Session()
    _tls_session.mount("https://", _LowSecAdapter())
    _tls_session.mount("http://", _LowSecAdapter())
except Exception:
    _tls_session = None

_module_last_request_time = 0
_events_cache = None
_events_cache_time = 0
_EVENTS_CACHE_TTL = 300

# token -> k (AES key for edge playlist segment-URI encryption). Populated by
# _fetch_playlist_token(); bounded FIFO so a long Kodi session can't grow it.
_play_keys = {}
_PLAY_KEYS_MAX = 32

# edge origin -> (TICKET, captured_at). The dembed player page mints TICKET
# server-side (`const TICKET = "..."` before daddy.min.js) and the edge token
# API rejects requests without `&tk=` (daddy.min.js >= v1794214445, added
# 2026-11-09 together with the page's reloadForTicket()).
_page_tickets = {}
_PAGE_TICKETS_MAX = 8

# dembed netloc -> fetched_at when the page carried no `const TICKET` (it now
# serves a straight `const CHAL` Turnstile flow). Re-fetching the same page
# cannot produce a ticket, so skip the extra rate-limited page load in
# _mint_page_ticket() for a while.
_page_no_ticket = {}
_PAGE_NO_TICKET_TTL = 300

# get_link resolution lifecycle (module-level: read/written from the
# resolution helpers on the same thread).
# _resolution_active: while True, every upstream fetch resets the proxy's
# idle timer (touch_stream_proxies) so the watchdog cannot finalize the
# listener mid-ladder — otherwise a long retry/sibling ladder (>15s without
# any local proxy request) kills the proxy and the final "best effort" URL
# points at a dead port ("connection refused" on OpenFile).
# _offair_detected/_offair_url: edge 404 "unknown channel" marker — retrying
# the same dembed/edge resolution is pointless, so get_link breaks its retry
# ladder immediately and known-offair URLs are skipped without re-fetching.
_offair_detected = False
_offair_url = ""
# Edge 403 'forbidden' on the token/manifest routes: the host WAF requires a
# browser TLS fingerprint (JA3/h2) that pure python cannot produce — retries
# and sibling dembed players all hit the same wall, so break the ladder fast
# and let non-edge siblings (matchora etc.) take over.
_edge_blocked = False
# Sticky WAF memory: the JA3 gate is a property of the Kodi client, not the
# channel, so once it has fired every dembed-backed player is dead for this
# session. Keep the marker for hours instead of re-burning ~30s per open.
_edge_waf_ts = 0.0
_EDGE_WAF_TTL = 6 * 3600
# channel id -> player page that last resolved with a fresh manifest. The
# site's player set rotates per channel but is stable within a session, so the
# next open (of any of that channel's 7 buttons) can jump straight to the one
# that works instead of walking the ladder.
_player_pref = {}
_PLAYER_PREF_TTL = 1800
_PLAYER_PREF_MAX = 64
# dembed.st-backed buttons: all resolve to the same JA3-gated edge host.
_DEMBED_BACKED_RE = re.compile(r'/(?:stream|watch|hub)/stream-\d+\.php')


def _channel_id(url: str) -> str:
    m = re.search(r'/stream-(\d+)\.php', url or '')
    if not m:
        m = re.search(r'[?&]id=(\d+)', url or '')
    return m.group(1) if m else ""


def _remember_player(channel_id: str, address: str) -> None:
    if not channel_id or not address:
        return
    _player_pref.pop(channel_id, None)
    _player_pref[channel_id] = (address, time.time())
    while len(_player_pref) > _PLAYER_PREF_MAX:
        _player_pref.pop(next(iter(_player_pref)), None)


def _preferred_player(channel_id: str) -> Optional[str]:
    entry = _player_pref.get(channel_id)
    if not entry:
        return None
    if (time.time() - entry[1]) > _PLAYER_PREF_TTL:
        _player_pref.pop(channel_id, None)
        return None
    return entry[0]



def _norm_stream_url(url: str) -> str:
    try:
        p = urlparse(url)
        return f"{p.scheme}://{p.netloc}{p.path}"
    except Exception:
        return url or ""


def _note_offair(resp, stream_url: str) -> None:
    """Record edge 404 'unknown channel' responses (channel no longer hosted).

    Retrying the same dembed/edge flow cannot succeed (observed on
    premium8: page/SRC present, edge answers 404 unknown channel), and the
    same-channel siblings resolve to the identical edge URL.
    """
    global _offair_detected, _offair_url
    try:
        if resp is not None and resp.status_code == 404 and \
                b"unknown channel" in (resp.content or b"")[:128]:
            _offair_detected = True
            _offair_url = _norm_stream_url(stream_url)
            debug_log(f"[BkDr2] edge has no such channel (unknown channel): "
                      f"{stream_url[:100]}", xbmc.LOGWARNING)
    except Exception:
        pass


def _note_edge_blocked(resp, stream_url: str) -> None:
    """Record edge 403 'forbidden' on token/manifest routes (TLS-fingerprint WAF).

    Pure python (Kodi) can never pass this gate; retries burn ~40s each and
    dembed siblings resolve to the same edge host. Break the ladder and let
    non-edge sibling players (matchora /api/play etc.) win instead.
    """
    global _edge_blocked, _edge_waf_ts
    try:
        if resp is not None and resp.status_code == 403 and \
                (resp.content or b"")[:64].strip() == b"forbidden":
            _edge_blocked = True
            _edge_waf_ts = time.time()
            debug_log(f"[BkDr2] edge WAF forbidden (browser-TLS gate), "
                      f"not retrying: {stream_url[:100]}", xbmc.LOGWARNING)
    except Exception:
        pass


def _capture_page_ticket(body: bytes, page_url: str = "") -> None:
    """Store const TICKET/EDGE from a dembed-style player page body.

    Called for every successful page response (see BckDr2._do_request);
    a no-op for bodies without the literal `const TICKET` (manifests, JSON).
    The page URL is kept because the edge validates the token request's
    Referer/Origin against the player host — a cross-origin referrer gets
    403 forbidden even with a valid ticket.
    """
    if b"const TICKET" not in body:
        return
    try:
        text = body.decode("utf-8", "replace")
        tk = re.search(r'const\s+TICKET\s*=\s*["\']([^"\']+)["\']', text)
        if not tk:
            return
        edge = re.search(r'const\s+EDGE\s*=\s*["\']([^"\']+)["\']', text)
        origin = edge.group(1).rstrip("/") if edge else ""
        _page_tickets.pop(origin, None)
        _page_tickets[origin] = (tk.group(1), page_url, time.time())
        while len(_page_tickets) > _PAGE_TICKETS_MAX:
            # pop(..., None): eviction races must not raise.
            _page_tickets.pop(next(iter(_page_tickets)), None)
    except Exception:
        pass


def _page_ticket_url(origin: str) -> Optional[str]:
    entry = _page_tickets.get(origin)
    if entry is None and _page_tickets:
        entry = next(reversed(list(_page_tickets.values())))
    return entry[1] if entry and len(entry) > 1 else None


def _get_page_ticket(origin: str) -> Optional[str]:
    entry = _page_tickets.get(origin)
    if entry is None and _page_tickets:
        # Ticket is viewer-IP-bound (server mints expiry.ip.sig); if the page's
        # EDGE const host differs from the stream host (mid-session rotation),
        # the newest captured ticket is still the right one.
        entry = next(reversed(list(_page_tickets.values())))
    return entry[0] if entry else None


def _b64url_decode(data: str) -> bytes:
    data = data.strip().replace('-', '+').replace('_', '/')
    data += '=' * (-len(data) % 4)
    return base64.b64decode(data)


def _aes_ctr_decrypt(key: bytes, iv: bytes, data: bytes) -> bytes:
    try:
        from Crypto.Cipher import AES
        # WebCrypto AES-CTR with length=64: high 64 bits of the counter block
        # (iv[:8]) fixed, low 64 bits (iv[8:]) big-endian counter.
        cipher = AES.new(key, AES.MODE_CTR, nonce=iv[:8],
                         initial_value=int.from_bytes(iv[8:], 'big'))
        return cipher.decrypt(data)
    except ImportError:
        from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
        # modes.CTR increments the full 128-bit block big-endian; identical to
        # length=64 until a 2^64-block overflow (never reached for playlists).
        dec = Cipher(algorithms.AES(key), modes.CTR(iv)).decryptor()
        return dec.update(data) + dec.finalize()


def decrypt_edge_playlist(body: str, url: str) -> str:
    """Decrypt AES-CTR-sealed segment URIs in edge.* playlists (Backdoor2).

    The dembed player (daddy.min.js openPlaylist()) base64url-decodes each
    non-comment playlist line and AES-CTR-decrypts it with the `k` returned by
    /api/playlist-token for the token in `?t=`; the counter IV is 8 zero bytes
    plus the big-endian EXT-X-MEDIA-SEQUENCE (incremented per segment line).
    The plaintext is the real absolute segment URL (TikTok-CDN PNG-wrapped TS).

    No-op unless `url` carries a token we fetched a `k` for, so it is safe to
    attach to every manifest path (hls.st, hundxvision, dl-token hosts never
    populate _play_keys). Self-idempotent: decrypted URLs contain ':' and '/'
    and never match the base64url line pattern again.
    """
    if not body or '#EXTM3U' not in body:
        return body
    m = re.search(r'[?&]t=([^&]+)', url or '')
    if not m:
        return body
    k_b64 = _play_keys.get(unquote(m.group(1)))
    if not k_b64:
        return body
    try:
        key = _b64url_decode(k_b64)
        if len(key) not in (16, 24, 32):
            return body
    except Exception:
        return body

    seq = 0
    out = []
    changed = False
    for line in body.split('\n'):
        stripped = line.strip()
        if not stripped:
            out.append(line)
            continue
        if stripped.startswith('#'):
            if stripped.startswith('#EXT-X-MEDIA-SEQUENCE:'):
                try:
                    seq = int(stripped.split(':', 1)[1].strip())
                except ValueError:
                    pass
            out.append(line)
            continue
        # Encrypted URIs are long base64url blobs (with possible '=' padding);
        # plaintext URLs/paths contain ':', '/' or '.', so they are never
        # misidentified.
        if re.fullmatch(r'[A-Za-z0-9_=-]{40,}', stripped):
            try:
                pt = _aes_ctr_decrypt(key, b'\x00' * 8 + seq.to_bytes(8, 'big'),
                                      _b64url_decode(stripped))
                txt = pt.decode('utf-8')
                if txt.startswith(('http://', 'https://', '//')) and '\x00' not in txt:
                    out.append(txt)
                    changed = True
                    seq += 1
                    continue
            except Exception:
                pass
        out.append(line)
        seq += 1
    return '\n'.join(out) if changed else body

_AD_IFRAME_PATTERNS = ("getbanner", "ad.html", "doubleclick", "googlesyndication", "adskeeper", "ad4.")
_IFRAME_BLACKLIST = ('chatango', 'adserv', 'live_chat', 'ad4', 'cloudfront', 'image/svg',
                     'getbanner.php', '/ads', 'ads.', 'min.js', '.jpg', '.png', 'mail.ru', 'googleusercontent')

# The site's "player" rotation hides some embeds behind a JS-only wrapper (no
# <iframe src> at all): a blogspot page that only carries one base64 payload and
# evals it, e.g.
#   zdec="<b64>";eval(atob(zdec));        -> drawIFR2(atob('<b64>'))
#   <iframe id="player" data-encoded="<b64>">
#   encodeStreamUrl(): 5-char prefix + btoa(url) + 5-char suffix
# All resolve to base64 -> (optional nested atob) -> absolute player URL, so
# decode every blob found and keep the http(s) URLs they yield.
_JS_EMBED_MAX_DEPTH = 3
_JS_EMBED_URL_RE = re.compile(r'https?://[^\s"\'<>()]+')
_JS_ATOB_RE = re.compile(r'atob\(\s*[\'"]([A-Za-z0-9+/=_-]{16,})[\'"](?:\s*,\s*[\'"]base64[\'"])?\s*\)')
_JS_EMBED_BLOCK = tuple(_AD_IFRAME_PATTERNS) + tuple(_IFRAME_BLACKLIST) + (
    'javascript:', 'data:', 'about:', '/p/u.html', 'facebook.com', 'twitter.com',
)


def _b64_text(blob: str) -> Optional[str]:
    """Lenient base64 decode (padding/base64url tolerant); None on failure."""
    try:
        raw = base64.b64decode(blob.strip().replace('-', '+').replace('_', '/')
                               + '=' * (-len(blob.strip()) % 4), validate=False)
    except Exception:
        return None
    if not raw:
        return None
    try:
        return raw.decode('utf-8')
    except UnicodeDecodeError:
        return raw.decode('latin-1', 'replace')


def _js_embed_urls(html: str) -> List[str]:
    """Collect player URLs hidden in base64/atob wrappers (see block above)."""
    blobs = re.findall(r'zdec\s*=\s*"([^"]+)"', html)
    blobs += re.findall(r'data-encoded\s*=\s*"([^"]+)"', html)
    blobs += [m.group(1) for m in _JS_ATOB_RE.finditer(html)]

    urls: List[str] = []

    def walk(blob: str, depth: int) -> None:
        if depth > _JS_EMBED_MAX_DEPTH or not blob or len(blob) < 16:
            return
        text = _b64_text(blob)
        if text is None and len(blob) > 12:
            # encodeStreamUrl(): 5-char timestamp prefix + payload + 5-char suffix
            text = _b64_text(blob[5:-5])
        if not text:
            return
        for m in _JS_ATOB_RE.finditer(text):
            walk(m.group(1), depth + 1)
        for m in _JS_EMBED_URL_RE.finditer(text):
            urls.append(m.group(0).replace('\\/', '/').rstrip('\\;,'))

    for blob in blobs:
        walk(blob, 0)
    return urls


class BckDr2(JetExtractor):
    def __init__(self) -> None:
        self.domains = ["thedaddy.li","thedaddy.pk","dlive.sx","dlhd.pk", "dlhd.st"]
        self.name = "BckDr2"
        

        self.user_agents = [
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        ]

        self.ott_agents = [
            "VLC/3.0.18 LibVLC/3.0.18",
            "TiviMate/4.7.0 (Android)",
            "iMPlayer/3.9.5 (Linux;Android 14) AndroidXMedia3/1.8.0",
            "OTT-IPTV/1.0 (Linux, Android 10; BR) XtreamPlayer/5.0"
        ]

        self.min_request_interval = 3

    def _do_request(self, method: str, url: str, headers=None, timeout: Union[int, Tuple[int, int]] = 15, **kwargs):
        resp = None
        if _tls_session is not None:
            try:
                resp = _tls_session.request(
                    method, url, headers=headers, timeout=timeout,
                    verify=False, **kwargs,
                )
            except Exception:
                resp = None
        if resp is None:
            resp = get_session().request(
                method, url, headers=headers, timeout=timeout,
                verify=False, **kwargs,
            )
        # Every dembed/player page fetch funnels through here — remember the
        # page-minted TICKET the edge token API now requires as &tk=.
        try:
            if resp.status_code == 200 and resp.content:
                _capture_page_ticket(resp.content, resp.url or url)
                body = resp.content or b""
                if b"const TICKET" not in body and (
                        b"const CHAL" in body or b"daddy.min.js" in body
                        or b"premiumtv" in body):
                    # Turnstile-era player page: no ticket exists to capture,
                    # so a second fetch for one is wasted.
                    _page_no_ticket[urlparse(resp.url or url).netloc] = time.time()
        except Exception:
            pass
        return resp

    def get_items(self, params: Optional[dict] = None, progress: Optional[JetExtractorProgress] = None) -> List[JetItem]:
        items = []
        if self.progress_init(progress, items):
            return items

        events = self._fetch_events()
        items.extend(events)

        debug_log(f"[Backdr2] Total items: {len(items)}", xbmc.LOGINFO)
        return items

    def _fetch_events(self) -> List[JetItem]:
        global _events_cache, _events_cache_time

        if _events_cache is not None and (time.time() - _events_cache_time) < _EVENTS_CACHE_TTL:
            debug_log(f"[Backdr2] Returning {len(_events_cache)} cached events", xbmc.LOGINFO)
            return list(_events_cache)

        items = []
        max_retries = 4

        for attempt in range(max_retries + 1):
            try:
                self._rate_limit()

                headers = {
                    'User-Agent': random.choice(self.user_agents),
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'Accept-Language': 'en-US,en;q=0.5',
                    'Origin': 'https://thedaddy.li',
                    'Referer': 'https://thedaddy.li/',
                }

                debug_log(f"[Backdr2] Fetching events from thedaddy.li (attempt {attempt + 1}/{max_retries + 1})", xbmc.LOGINFO)

                try:
                    r = self._do_request('get', "https://thedaddy.li", headers=headers, timeout=(8, 20))
                    body = r.content[:2 * 1024 * 1024]
                except Exception as e:
                    debug_log(f"[Backdr2] Events request failed: {type(e).__name__}: {str(e)[:60]}", xbmc.LOGWARNING)
                    self._update_last_request_time()
                    if attempt < max_retries:
                        backoff = (2 ** attempt) + random.uniform(1, 2)
                        time.sleep(backoff)
                        continue
                    break

                self._update_last_request_time()

                if r.status_code != 200:
                    debug_log(f"[Backdr2] HTTP Error {r.status_code}", xbmc.LOGWARNING)
                    if attempt < max_retries:
                        backoff = (2 ** attempt) + random.uniform(1, 2)
                        time.sleep(backoff)
                        continue
                    break

                html = body.decode('utf-8', errors='replace')
                soup = BeautifulSoup(html, 'html.parser')

                for schedule in soup.select("div#schedule > div.schedule__day"):
                    header_el = schedule.select_one("div.schedule__dayTitle")
                    header = header_el.text.strip() if header_el else "Unknown"

                    for category in schedule.select("div.schedule__category"):
                        category_el = category.select_one("div.card__meta")
                        category_name = category_el.text.strip() if category_el else header

                        for event in category.select("div.schedule__event"):
                            title_el = event.select_one("span.schedule__eventTitle")
                            title = title_el.text.strip() if title_el else ""

                            starttime_el = event.select_one("span.schedule__time")
                            starttime = starttime_el.get("data-time", "") if starttime_el else ""

                            display_title = title
                            if starttime:
                                display_title = f"{title} ({starttime})"

                            channels = event.select("div.schedule__channels > a")
                            links = []
                            for a in channels:
                                href = a.get("href", "")
                                if href:
                                    ch_name = a.get("title", "").strip()
                                    if not ch_name:
                                        ch_id = href.split("=")[-1] if "=" in href else ""
                                        ch_name = f"CH-{ch_id}" if ch_id else "Player"
                                    link = "https://thedaddy.li" + href
                                    links.append(JetLink(link, name=ch_name, links=True))

                            if links:
                                items.append(JetItem(
                                    display_title, links,
                                    league=category_name,
                                    icon=self._get_icon(f"{category_name} {title}"),
                                ))

                debug_log(f"[BkDr2] Found {len(items)} events from dlive.sx", xbmc.LOGINFO)

                try:
                    self._rate_limit()
                    channels_r = self._do_request('get', "https://thedaddy.li/24-7-channels.php", headers=headers, timeout=(8, 20))
                    self._update_last_request_time()
                    if channels_r.status_code == 200:
                        soup_channels = BeautifulSoup(channels_r.text, 'html.parser')
                        for channel in soup_channels.select("div.grid > a.card"):
                            href = channel.get("href", "")
                            if not href:
                                continue
                            ch_url = "https://thedaddy.li" + href if not href.startswith("http") else href
                            title_el = channel.select_one("div.card__title")
                            title = title_el.text.strip() if title_el else ""
                            if not title or "18+" in title:
                                continue
                            channel_id = ch_url.split("=")[-1] if "=" in ch_url else ""
                            items.append(JetItem(
                                title,
                                links=[JetLink(ch_url, name=f"{title} [CH-{channel_id}]", links=True)],
                                league="24/7 Channels",
                                icon=self._get_icon("24/7 Channels"),
                            ))
                        debug_log(f"[BkDr2] Found 24/7 channels", xbmc.LOGINFO)

                        if backdoor2_store.is_stale():
                            try:
                                store_rows = []
                                for ch_item in items:
                                    if ch_item.league == "24/7 Channels" and ch_item.links:
                                        embed_url = ch_item.links[0].address if hasattr(ch_item.links[0], "address") else ""
                                        channel_id = embed_url.split("=")[-1] if "=" in embed_url else ""
                                        store_rows.append({
                                            "name": ch_item.title,
                                            "embed_url": embed_url,
                                            "channel_id": channel_id,
                                        })
                                if store_rows:
                                    backdoor2_store.add_channels(store_rows)
                                    backdoor2_store.set_last_refresh_ts(time.time())
                                    debug_log(f"[BkDr2] Saved {len(store_rows)} 24/7 channels to DB", xbmc.LOGINFO)
                            except Exception as e:
                                debug_log(f"[BkDr2] Failed to save 24/7 channels to DB: {e}", xbmc.LOGWARNING)
                except Exception as e:
                    debug_log(f"[BkDr2] Failed to fetch 24/7 channels: {e}", xbmc.LOGWARNING)

                _events_cache = list(items)
                _events_cache_time = time.time()
                break

            except Exception as e:
                debug_log(f"[BkDr2] Error fetching events: {str(e)}", xbmc.LOGERROR)
                debug_log(f"[BkDr2] Traceback: {traceback.format_exc()}", xbmc.LOGERROR)
                if attempt < max_retries:
                    backoff = (2 ** attempt) + random.uniform(1, 2)
                    time.sleep(backoff)
                else:
                    break

        return items

    def get_links(self, url: JetLink) -> List[JetLink]:
        debug_log(f"[BkDr2] get_links START: {url.address}", xbmc.LOGINFO)

        try:
            candidate_links = self._get_player_candidates(url.address)

            if not candidate_links:
                debug_log(f"[BkDr2] No player buttons found", xbmc.LOGWARNING)
                return []

            debug_log(f"[BkDr2] Found {len(candidate_links)} candidate links", xbmc.LOGINFO)
            debug_log(f"[BkDr2] Returning {len(candidate_links)} player links", xbmc.LOGINFO)
            return candidate_links

        except Exception as e:

            debug_log(f"[BkDr2] get_links EXCEPTION: {type(e).__name__}: {str(e)}", xbmc.LOGERROR)
            debug_log(f"[BkDr2] Traceback: {traceback.format_exc()}", xbmc.LOGERROR)
            return []

    def _get_player_candidates(self, page_url: str) -> List[JetLink]:
        """Fetch a thedaddy.li stream/watch page and return its player buttons.

        The site currently exposes 7 players (stream/cast/watch/plus/casting/
        player/hub). Only the dembed.st-backed ones (stream/watch/hub) are
        reliably resolvable, but the button set rotates - return them all and
        let get_link's sibling fallback skip the dead ones.
        """
        self._rate_limit()

        headers = {
            'User-Agent': random.choice(self.user_agents),
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Origin': 'https://thedaddy.li',
            'Referer': 'https://thedaddy.li/',
        }

        r = self._do_request('get', page_url, headers=headers, timeout=15)
        if r.status_code != 200:
            debug_log(f"[BkDr2] Page returned status {r.status_code}", xbmc.LOGWARNING)
            return []

        soup = BeautifulSoup(r.text, 'html.parser')
        candidate_links = []

        for btn in soup.select("button.player-btn"):
            btn_url = btn.get("data-url", "")
            btn_title = btn.get_text(strip=True)
            if btn_url:
                if btn_url.startswith('//'):
                    btn_url = 'https:' + btn_url
                candidate_links.append(JetLink(btn_url, name=btn_title, headers={"Referer": r.url}))

        if not candidate_links:
            for a in soup.select("center > a"):
                href = a.get("href", "")
                if href:
                    full_url = "https://thedaddy.li" + href if not href.startswith("http") else href
                    ch_name = f"Player {len(candidate_links) + 1}"
                    candidate_links.append(JetLink(full_url, name=ch_name, headers={"Referer": r.url}))

        # Put the player that worked last time first so the consumer's link
        # dialog opens on the playable choice (names keep their site order).
        pref = _preferred_player(_channel_id(page_url))
        if pref:
            pref_norm = _norm_stream_url(pref)
            for i, l in enumerate(candidate_links):
                if _norm_stream_url(l.address) == pref_norm:
                    candidate_links.insert(0, candidate_links.pop(i))
                    break

        return candidate_links

    def _resolve_stream(self, stream_url: str, base_headers: dict) -> List[JetLink]:
        """Try multiple methods to resolve a stream URL to an m3u8."""
        r, final_url, final_headers = self._follow_iframes(stream_url, base_headers)

        if r and r.status_code == 200:
            result = self._extract_stream(r.text, final_url, final_headers)
            if result:
                return result

        return []

    def _extract_stream(self, html: str, url: str, headers: dict) -> List[JetLink]:
        """Try multiple extraction methods on a page's HTML."""
        parsed = urlparse(url)
        domain = f"https://{parsed.netloc}"

        stream_url = self._scan_m3u8(html, url)
        if stream_url:
            debug_log(f"[BkDr2] Found m3u8 via scan: {stream_url[:120]}", xbmc.LOGINFO)
            if self._should_route_through_proxy(stream_url):
                premium_result = self._extract_premium_hls(html, url, headers)
                if premium_result:
                    return [premium_result]
            return [JetLink(
                address=stream_url,
                headers={"Referer": url, "User-Agent": headers.get('User-Agent', self.user_agents[0]), "Origin": domain},
                inputstream=JetInputstreamFFmpegDirect.default(),
            )]

        stream_url = self._decode_array(html, url)
        if stream_url:
            debug_log(f"[BkDr2] Found stream via char array: {stream_url[:120]}", xbmc.LOGINFO)
            return [JetLink(
                address=stream_url,
                headers={"Referer": url, "User-Agent": headers.get('User-Agent', self.user_agents[0]), "Origin": domain},
                inputstream=JetInputstreamFFmpegDirect.default(),
            )]

        stream_url = self._decode_hex_source(html)
        if stream_url:
            debug_log(f"[BkDr2] Found stream via hex decode: {stream_url[:120]}", xbmc.LOGINFO)
            return [JetLink(
                address=stream_url,
                headers={"Referer": url, "User-Agent": headers.get('User-Agent', self.user_agents[0]), "Origin": domain},
                inputstream=JetInputstreamFFmpegDirect.default(),
            )]

        stream_url = self._decode_atob(html)
        if stream_url:
            debug_log(f"[BkDr2] Found stream via atob: {stream_url[:120]}", xbmc.LOGINFO)
            return [JetLink(
                address=stream_url,
                headers={"Referer": url, "User-Agent": headers.get('User-Agent', self.user_agents[0]), "Origin": domain},
                inputstream=JetInputstreamFFmpegDirect.default(),
            )]

        stream_url = self._decode_xor_array(html)
        if stream_url:
            debug_log(f"[BkDr2] Found stream via XOR decode: {stream_url[:120]}", xbmc.LOGINFO)
            xheaders = {"Referer": url, "User-Agent": headers.get('User-Agent', self.user_agents[0]), "Origin": domain}
            if self._should_route_through_proxy(stream_url):
                xopts = {
                    "browser_tls": True, "proxy_absolute_urls": True,
                    "strip_png": True, "segment_strip_origin": True,
                    "cache_manifest": True, "manifest_ttl": 10.0,
                    "upstream_keep_alive": True, "prefetch_segments": True,
                    "add_icy_metadata": False,
                }
                proxy = get_stream_proxy("backdoor2", xheaders, xopts)
                purl = None
                stream_url = self._tokenize_manifest_url(stream_url, xheaders)
                try:
                    self._rate_limit()
                    self._update_last_request_time()
                    mr = self._do_request('get', stream_url, headers=xheaders, timeout=15)
                    if mr.status_code == 200:
                        purl = proxy.cache_manifest_bytes(mr.content, stream_url, xheaders,
                                                          manifest_decoder=decrypt_edge_playlist)
                except Exception:
                    pass
                if purl is None:
                    purl = build_proxy_url("backdoor2", stream_url, xheaders, options=xopts,
                                           manifest_decoder=decrypt_edge_playlist)
                debug_log(f"[BkDr2] XOR stream routed through proxy: {purl}", xbmc.LOGINFO)
                return [JetLink(address=purl, headers=xheaders, inputstream=JetInputstreamFFmpegDirect.default())]
            return [JetLink(
                address=stream_url,
                headers=xheaders,
                inputstream=JetInputstreamFFmpegDirect.default(),
            )]

        econfig_result = self._decode_econgfig(html, url)
        if econfig_result:
            return econfig_result

        token_result = self._dl_token(html, headers, domain)
        if token_result:
            return token_result

        premium_result = self._extract_premium_hls(html, url, headers)
        if premium_result:
            return [premium_result]

        return []

    def _follow_iframes(self, url: str, base_headers: dict, max_depth: int = 8, timeout=None):
        """Follow iframes (and JS-only embeds) from a URL, skipping ads.

        Some players hide the next hop in JS instead of an iframe (blogspot
        wrapper -> wideiptv), so when no <iframe src> matches, the decoded
        base64/atob payload is followed as if it were one.
        """
        headers = dict(base_headers)
        r = None
        current_url = url
        visited = {_norm_stream_url(url)}
        if timeout is None:
            timeout = 15

        for depth in range(max_depth):
            try:
                r = self._do_request('get', current_url, headers=headers, timeout=timeout)
            except Exception as e:
                debug_log(f"[BkDr2] Failed to fetch iframe {current_url}: {e}", xbmc.LOGWARNING)
                break

            if r.status_code != 200:
                break

            m3u8 = self._scan_m3u8(r.text, current_url)
            if m3u8:
                break

            iframe_src = self._find_iframe(r.text, current_url)
            if not iframe_src or iframe_src == current_url:
                iframe_src = self._find_js_embed(r.text, current_url)
            if not iframe_src or iframe_src == current_url or _norm_stream_url(iframe_src) in visited:
                break

            debug_log(f"[BkDr2] Following iframe depth {depth}: {iframe_src[:120]}", xbmc.LOGINFO)
            visited.add(_norm_stream_url(iframe_src))
            headers = {
                "Referer": current_url,
                "User-Agent": base_headers.get('User-Agent', self.user_agents[0]),
            }
            current_url = iframe_src

        return r, current_url, headers

    def _find_iframe(self, html: str, base_url: str) -> Optional[str]:
        """Find the first non-ad iframe URL in the HTML."""
        for match in re.finditer(r'<iframe\b[^>]*\bsrc=["\']([^"\']+)["\']', html, re.IGNORECASE):
            src = match.group(1)
            if any(p in src.lower() for p in _AD_IFRAME_PATTERNS):
                continue
            if any(b in src.lower() for b in _IFRAME_BLACKLIST):
                continue
            if not src.startswith('http'):
                src = urljoin(base_url, src)
            return src
        return None

    def _find_js_embed(self, html: str, base_url: str) -> Optional[str]:
        """Find a player URL emitted by a JS-only embed wrapper."""
        for cand in _js_embed_urls(html):
            low = cand.lower()
            if any(p in low for p in _JS_EMBED_BLOCK):
                continue
            if not cand.startswith('http'):
                cand = urljoin(base_url, cand)
            c, b = urlparse(cand), urlparse(base_url)
            if c.netloc and c.netloc == b.netloc and c.path == b.path:
                continue
            return cand
        return None

    def _scan_m3u8(self, html: str, url: str) -> Optional[str]:
        """Scan HTML for m3u8 URLs using multiple patterns."""
        html = html.replace('\\/', '/')

        patterns = [
            r'(?:const|var|let)\s+(?:SRC|STREAM_URL|source|file)\s*[:=]\s*["\']([^"\']+\.m3u8[^"\']*)["\']',
            r'source\s*[:=]\s*["\']([^"\']+\.m3u8[^"\']*)["\']',
            r'file\s*[:=]\s*["\']([^"\']+\.m3u8[^"\']*)["\']',
            r'source src="([^"]+\.m3u8[^"]*)"',
            r'["\']([^"\']*\.m3u8[^"\']*)["\']',
            r'(https?://[^\s"\'<>]+\.m3u8[^\s"\'<>]*)',
        ]
        for pattern in patterns:
            match = re.search(pattern, html, re.IGNORECASE)
            if match:
                candidate = match.group(1)
                candidate = re.sub(r'\\u([0-9a-fA-F]{4})', lambda m: chr(int(m.group(1), 16)), candidate)
                if '<' not in candidate and '%3c' not in candidate.lower():
                    if not candidate.startswith('http'):
                        candidate = urljoin(url, candidate)
                    return candidate

        b64_match = re.findall(r'atob\(["\']((?:aHR|Ly)[^"\']+)["\']', html)
        for match in b64_match:
            try:
                decoded = base64.b64decode(match).decode('ascii', errors='ignore')
                if '.m3u8' in decoded:
                    url_match = re.search(r'(https?://[^\s"\'<>]+\.m3u8[^\s"\'<>]*)', decoded)
                    if url_match:
                        return url_match.group(1)
                    if decoded.startswith('http') and '.m3u8' in decoded:
                        return decoded
            except Exception:
                continue

        return None

    def _decode_array(self, html: str, url: str) -> Optional[str]:
        """Decode char array pattern like ['h','t','t','p',...].join('')"""
        match = re.search(r'(\["h","t","t","p",.+?\])\.\s*join\s*\(\s*["\']["\']\s*\)', html, re.IGNORECASE | re.DOTALL)
        if not match:
            return None
        try:
            char_array = json.loads(match.group(1))
            decoded = "".join(char_array)
            if decoded.startswith('//'):
                decoded = 'https:' + decoded
            elif not decoded.startswith('http'):
                decoded = urljoin(url, decoded)
            return decoded
        except Exception:
            return None

    def _decode_hex_source(self, html: str) -> Optional[str]:
        """Decode hexEncoded variable."""
        match = re.search(r'hexEncoded\s*=\s*"([0-9a-fA-F]{16,})"', html)
        if not match:
            return None
        try:
            decoded = bytes.fromhex(match.group(1)).decode('utf-8', 'ignore')
            if '://' in decoded:
                return decoded
        except Exception:
            pass
        return None

    def _decode_xor_array(self, html: str) -> Optional[str]:
        """Decode XOR-encoded script containing SIGNED_URL (exmxbxe.cfd / timst.cfd pattern).

        The page embeds a self-executing script that XOR-decodes a byte array
        and evals the result. Variable names change per load, but the pattern is:
            var ARRAY=[nums],KEY=N,OFFSET=N,...String.fromCharCode(((ARRAY[i]^KEY)-OFFSET+256)%256)
        The decoded JS contains:
            var SIGNED_URL = "https://.../.m3u8";
        """
        match = re.search(
            r'var\s+\w+\s*=\s*\[([0-9,]+)\]\s*,\s*\w+\s*=\s*(\d+)\s*,\s*\w+\s*=\s*(\d+)',
            html, re.DOTALL,
        )
        if not match:
            return None
        try:
            nums = [int(x) for x in match.group(1).split(',') if x.strip()]
            key = int(match.group(2))
            offset = int(match.group(3))
            decoded = ''.join(chr(((n ^ key) - offset + 256) % 256) for n in nums)
            url_match = re.search(r'var\s+SIGNED_URL\s*=\s*["\']([^"\']+\.m3u8[^"\']*)["\']', decoded)
            if url_match:
                return url_match.group(1)
        except Exception:
            pass
        return None

    def _decode_atob(self, html: str) -> Optional[str]:
        """Decode base64-encoded URLs from atob() calls."""
        atob_matches = re.findall(r'(?:window\.)?atob\(\s*[\'"]([A-Za-z0-9+/=]+)[\'"]\s*\)', html)
        for match in atob_matches:
            try:
                decoded = base64.b64decode(match).decode('ascii', errors='ignore')
                if '.m3u8' in decoded or '.ts' in decoded or 'load-playlist' in decoded:
                    url_match = re.search(r'(https?://[^\s"\'<>]+(?:\.m3u8|\.ts|\.css|\.js)[^\s"\'<>]*)', decoded)
                    if url_match:
                        return url_match.group(1)
                    if decoded.startswith('http'):
                        return decoded
            except Exception:
                continue
        return None

    def _should_route_through_proxy(self, url: str) -> bool:
        """Check if a stream URL should be routed through StreamProxy for PNG stripping.

        Matches legacy premium.hls.st, edge.* CDN hosts regardless of TLD
        (edge.*.sbs migrated to edge.*.top on 2026-10-29 - the TLD rotates,
        so match the 'edge.' first label + /premium path instead), and
        hundxvision.co.uk used by various DaddyLive embed chains.
        """
        if "hls.st" in url:
            return True
        parsed = urlparse(url)
        netloc = parsed.netloc.lower()
        path = parsed.path.lower()
        if netloc.startswith("edge.") and "premium" in path:
            return True
        if ".sbs" in netloc and "premium" in path:
            return True
        if "hundxvision" in netloc:
            return True
        return False

    def _mint_page_ticket(self, origin: str, slug: str, headers: dict) -> Optional[str]:
        """Fetch a dembed player page for *slug* to capture its TICKET.

        Needed only when the token API is hit before any player-page fetch
        (e.g. a constructed URL reached from a non-dembed player). Tries the
        Referer when it points at a player page, then the canonical
        premiumtv/daddy.php URL derived from the slug.
        """
        candidates = []
        ref = (headers.get("Referer") or "").split("?")[0].rstrip("/")
        for host in ("dembed.st", urlparse(ref).netloc):
            if host and (time.time() - _page_no_ticket.get(host, 0)) < _PAGE_NO_TICKET_TTL:
                debug_log("[BkDr2] player page served no TICKET recently, "
                          "not re-fetching for one", xbmc.LOGDEBUG)
                return None
        if "dembed.st" in ref and "/premiumtv" in ref:
            candidates.append(ref + ("?id=" + slug[len("premium"):] if slug.startswith("premium") and slug[len("premium"):].isdigit() else ""))
        m = re.fullmatch(r"premium(\d+)", slug)
        if m:
            candidates.append(f"https://dembed.st/premiumtv/daddy.php?id={m.group(1)}")
        for page_url in candidates:
            try:
                self._rate_limit()
                self._update_last_request_time()
                r = self._do_request(
                    'get', page_url,
                    headers={'User-Agent': headers.get('User-Agent', self.user_agents[0])},
                    timeout=12,
                )
                if r.status_code == 200:
                    ticket = _get_page_ticket(origin)
                    if ticket:
                        return ticket
            except Exception as e:
                debug_log(f"[BkDr2] ticket page fetch failed: {e}", xbmc.LOGDEBUG)
        return None

    def _fetch_playlist_token(self, stream_url: str, headers: dict) -> Optional[str]:
        """Fetch the short-lived edge playlist token required for manifest loads.

        The dembed.st player script fetches
            <edge>/api/playlist-token?slug=<channel>&tk=<TICKET>
        with the embed page as Referer/Origin and gets {"token": "...", "ttl": 120}.
        Since daddy.min.js v1794214445 (2026-11-09) the API rejects requests
        without &tk= (403 {"error":"ticket","reason":"missing"}); TICKET is
        minted server-side in the player page HTML (`const TICKET = "..."`)
        and captured by _do_request. On 403 with a stored ticket (expired or
        rotated) reload the player page once for a fresh one — the same
        recovery the page's own reloadForTicket() performs — then retry.
        The manifest itself must then be requested with ?t=<token>&_=<ts>.
        Returns None on any failure (caller falls back to the bare URL).
        """
        try:
            parsed = urlparse(stream_url)
            parts = [p for p in parsed.path.split('/') if p]
            if not parsed.netloc or not parts:
                return None
            slug = parts[0]
            origin = f"https://{parsed.netloc}"
            is_edge = parsed.netloc.lower().startswith("edge.")
            if is_edge and _edge_blocked:
                # WAF already proven this session: no ticket/page/token call
                # can pass the JA3 gate, so do not spend rate-limit time on it.
                return None
            token_headers = {
                'User-Agent': headers.get('User-Agent', self.user_agents[0]),
                'Accept': '*/*',
                'Referer': headers.get('Referer', origin + '/'),
                'Origin': headers.get('Origin', origin),
            }

            def _token_request(ticket: Optional[str], hdrs: dict = None):
                qs = f"&tk={quote(ticket)}" if ticket else ""
                self._rate_limit()
                self._update_last_request_time()
                return self._do_request(
                    'get', f"{origin}/api/playlist-token?slug={quote(slug)}{qs}",
                    headers=hdrs or token_headers, timeout=10,
                )

            ticket = _get_page_ticket(origin) if is_edge else None
            if is_edge and not ticket:
                ticket = self._mint_page_ticket(origin, slug, headers)
                debug_log(f"[BkDr2] minted edge ticket: {'yes' if ticket else 'no'}", xbmc.LOGDEBUG)

            r = _token_request(ticket)
            if r.status_code == 403 and is_edge and not r.headers.get("Retry-After"):
                if (r.content or b"")[:16].strip().lower() == b"forbidden":
                    # The JA3/h2 WAF, not a stale ticket: every retry (fresh
                    # ticket, page referrer, manifest pre-fetch) hits the same
                    # wall, so record it immediately and stop the ladder.
                    _note_edge_blocked(r, f"{origin}/api/playlist-token")
                    return None
                # Two distinct 403s from the edge:
                #   {"error":"ticket",...} (missing/expired ticket)
                #       -> reload the player page for a fresh TICKET (the
                #          page's own reloadForTicket() equivalent);
                #   other rejection -> retry with the minting page's
                #          URL/origin as Referer/Origin.
                body = (r.text or "").lower()
                page_url = _page_ticket_url(origin)
                # Only re-mint when the ticket itself is the problem (or we
                # never captured a page); a referrer-only rejection just needs
                # the existing page's URL/origin as headers.
                fresh = self._mint_page_ticket(origin, slug, headers) \
                    if ("ticket" in body or not page_url) else None
                page_url = page_url or _page_ticket_url(origin)
                hdrs = None
                if page_url:
                    p = urlparse(page_url)
                    hdrs = dict(token_headers)
                    hdrs["Referer"] = page_url
                    hdrs["Origin"] = f"{p.scheme}://{p.netloc}"
                debug_log(f"[BkDr2] Playlist token 403 ({body[:60].strip()}), retrying with "
                          f"{'fresh ' if fresh else ''}ticket + player-page referrer",
                          xbmc.LOGDEBUG)
                r = _token_request(fresh or ticket, hdrs)
            if r.status_code != 200:
                debug_log(f"[BkDr2] Playlist token request returned {r.status_code}", xbmc.LOGDEBUG)
                return None
            data = r.json()
            token = data.get("token")
            k = data.get("k")
            if token and k:
                _play_keys[token] = k
                while len(_play_keys) > _PLAY_KEYS_MAX:
                    # pop(..., None): eviction races with a concurrent token
                    # fetch must not raise out of this helper.
                    _play_keys.pop(next(iter(_play_keys)), None)
            if token:
                debug_log(f"[BkDr2] Got playlist token for {slug} (ttl {data.get('ttl')})", xbmc.LOGINFO)
            return token or None
        except Exception as e:
            debug_log(f"[BkDr2] Playlist token fetch failed: {e}", xbmc.LOGDEBUG)
            return None

    def _tokenize_manifest_url(self, stream_url: str, headers: dict) -> str:
        """Append ?t=<token>&_=<ts> to a token-gated edge manifest URL.

        Returns the original URL when the host does not expose the token API
        (legacy premium.hls.st, hundxvision, etc.) or when the fetch fails.
        """
        if not self._should_route_through_proxy(stream_url):
            return stream_url
        token = self._fetch_playlist_token(stream_url, headers)
        if not token:
            return stream_url
        sep = '&' if '?' in stream_url else '?'
        return f"{stream_url}{sep}t={quote(token)}&_={int(time.time() * 1000)}"

    def _extract_premium_hls(self, html: str, url: str, headers: dict) -> Tuple[Optional[JetLink], bool]:
        """Extract or construct a premium m3u8 stream URL.

        The iframe page (daddyliveplayer.st / iplayer.is premiumtv) embeds the
        stream via a var STREAM_URL or an m3u8 URL in the HTML:
            var STREAM_URL = "https:\\/\\/edge.cowedd4855ws.sbs\\/premium51\\/index.m3u8"
        or the legacy form:
            var STREAM_URL = "https:\\/\\/premium.hls.st\\/playlist\\/premium44.m3u8"
        with JSON-escaped forward slashes. If the URL is absent from the HTML,
        fall back to constructing it from the channel id in the query string.

        Segments are PNG-wrapped (TikTok-style), so the URL is routed through
        StreamProxy with strip_png=True, browser_tls=True, and
        segment_strip_origin=True (segments often live on tiktokcdn-us.com,
        a different origin than the manifest).

        Returns (JetLink, pre_fetch_ok) where pre_fetch_ok indicates if
        manifest pre-fetch succeeded.
        """
        stream_url = self._scan_m3u8(html, url)

        if not stream_url:
            id_match = re.search(r'[?&]id=(\d+)', url)
            if not id_match:
                id_match = re.search(r'/-(\d+)\.php', url)
            if id_match:
                channel_id = id_match.group(1)
                sbs_match = re.search(
                    r'https?://edge\.[a-z0-9.-]+/premium' + channel_id + r'/[^\s"\'<>]+\.m3u8',
                    html, re.IGNORECASE,
                )
                if not sbs_match:
                    sbs_match = re.search(
                        r'https?://[a-z0-9.-]+\.sbs/premium' + channel_id + r'/[^\s"\'<>]+\.m3u8',
                        html, re.IGNORECASE,
                    )
                if sbs_match:
                    stream_url = sbs_match.group(0).replace('\\/', '/')
                else:
                    edge_match = re.search(
                        r'const\s+SRC\s*=\s*["\']([^"\']+\.m3u8[^"\']*)["\']',
                        html, re.IGNORECASE,
                    )
                    if edge_match:
                        stream_url = edge_match.group(1).replace('\\/', '/')
                    else:
                        # No SRC in page: build from the page's EDGE const, else
                        # the newest edge origin we've seen this session (edge
                        # hosts rotate; the old hardcoded .sbs host no longer
                        # resolves), else the current known host.
                        edge_const = re.search(
                            r'const\s+EDGE\s*=\s*["\'](https://edge\.[^"\']+)["\']',
                            html, re.IGNORECASE,
                        )
                        if edge_const:
                            edge_origin = edge_const.group(1).rstrip('/')
                        else:
                            known = [o for o in _page_tickets if o.startswith("https://edge.")]
                            edge_origin = known[-1] if known else "https://edge.wedd48c.top"
                        stream_url = f"{edge_origin}/premium{channel_id}/index.m3u8"
                debug_log(f"[BkDr2] Constructed premium HLS URL from channel ID {channel_id}: {stream_url[:120]}", xbmc.LOGINFO)

        if not stream_url:
            return None, False

        if not self._should_route_through_proxy(stream_url):
            return None, False

        parsed = urlparse(url)
        domain = f"https://{parsed.netloc}"

        proxy_headers = {
            "Referer": url,
            "User-Agent": headers.get('User-Agent', self.user_agents[0]),
            "Origin": domain,
        }
        proxy_options = {
            "browser_tls": True,
            "proxy_absolute_urls": True,
            "strip_png": True,
            "segment_strip_origin": True,
            "cache_manifest": True,
            "manifest_ttl": 10.0,
            "upstream_keep_alive": True,
            "prefetch_segments": True,
            "add_icy_metadata": False,
        }

        def _refresh_premium_url():
            try:
                self._rate_limit()
                self._update_last_request_time()
                r = self._do_request('get', url, headers=proxy_headers, timeout=15)
                if r.status_code == 200:
                    new_stream_url = self._scan_m3u8(r.text, url)
                    if new_stream_url and self._should_route_through_proxy(new_stream_url):
                        new_stream_url = self._tokenize_manifest_url(new_stream_url, proxy_headers)
                        debug_log(f"[BkDr2] Premium refresh_callback: got fresh URL {new_stream_url[:120]}", xbmc.LOGINFO)
                        return {"url": new_stream_url, "headers": proxy_headers}
            except Exception as e:
                debug_log(f"[BkDr2] Premium refresh_callback failed: {e}", xbmc.WARNING)
            return None

        proxy = get_stream_proxy("backdoor2", proxy_headers, proxy_options)
        proxy_url = None
        pre_fetch_ok = False

        if not _edge_blocked:
            stream_url = self._tokenize_manifest_url(stream_url, proxy_headers)
        if _edge_blocked:
            # WAF proven (possibly by the token request just now): skip the
            # manifest pre-fetch (another wasted 403 round-trip) and hand out
            # the proxy URL as best effort only.
            debug_log("[BkDr2] edge WAF cached, skipping premium pre-fetch", xbmc.LOGINFO)
        else:
            try:
                self._rate_limit()
                self._update_last_request_time()
                manifest_resp = self._do_request('get', stream_url, headers=proxy_headers, timeout=15)
                if manifest_resp.status_code == 200:
                    proxy_url = proxy.cache_manifest_bytes(
                        manifest_resp.content,
                        stream_url,
                        proxy_headers,
                        refresh_callback=_refresh_premium_url,
                        manifest_decoder=decrypt_edge_playlist,
                    )
                    debug_log(f"[BkDr2] Pre-fetched premium manifest: {stream_url[:120]}", xbmc.LOGINFO)
                    pre_fetch_ok = True
                else:
                    _note_offair(manifest_resp, stream_url)
                    _note_edge_blocked(manifest_resp, stream_url)
                    debug_log(f"[BkDr2] Premium pre-fetch returned {manifest_resp.status_code}, using build_proxy_url", xbmc.LOGWARNING)
            except Exception as e:
                debug_log(f"[BkDr2] Premium pre-fetch error: {e}, using build_proxy_url", xbmc.LOGWARNING)

        if proxy_url is None:
            proxy_url = build_proxy_url(
                "backdoor2", stream_url, proxy_headers,
                options=proxy_options,
                refresh_callback=_refresh_premium_url,
                manifest_decoder=decrypt_edge_playlist,
            )

        debug_log(f"[BkDr2] Premium HLS routed through proxy: {proxy_url}", xbmc.LOGINFO)
        return JetLink(
            address=proxy_url,
            headers=proxy_headers,
            inputstream=JetInputstreamFFmpegDirect.default(),
        ), pre_fetch_ok

    def _decode_econgfig_url(self, html: str) -> Optional[str]:
        """Extract the m3u8 stream URL from window._econfig (multi-layer base64)."""
        m = re.search(r"window\._econfig\s*=\s*['\"]([^'\"]+)['\"]", html)
        if not m:
            return None
        try:
            encoded = m.group(1)
            d1 = base64.b64decode(encoded).decode('latin-1')
            chunk_size = len(d1) // 4
            parts = [d1[i * chunk_size : i * chunk_size + chunk_size] for i in range(4)]

            reorder = [2, 0, 3, 1]
            decoded_parts = [None, None, None, None]
            for i in range(4):
                modified = parts[i][0:3] + parts[i][4:]
                padding = (4 - len(modified) % 4) % 4
                if padding < 4:
                    modified += '=' * padding
                decoded_bytes = base64.b64decode(modified.encode('latin-1'))
                decoded_parts[reorder[i]] = decoded_bytes.decode('utf-8', errors='replace')

            joined = ''.join(decoded_parts)
            padding = (4 - len(joined) % 4) % 4
            if padding < 4:
                joined += '=' * padding
            final = base64.b64decode(joined.encode('latin-1')).decode('utf-8', errors='replace')
            config = json.loads(final)

            stream_url = config.get('stream_url_nop2p') or config.get('stream_url')
            if not stream_url:
                return None
            if stream_url.startswith('//'):
                stream_url = 'https:' + stream_url
            return stream_url
        except Exception as e:
            debug_log(f"[BkDr2] _decode_econgfig_url failed: {type(e).__name__}: {str(e)[:80]}", xbmc.LOGWARNING)
            return None

    def _decode_econgfig(self, html: str, url: str) -> Tuple[List[JetLink], bool]:
        """Extract stream URL from window._econfig (assetrage.net multi-layer base64).
        
        Returns (links, pre_fetch_ok) where pre_fetch_ok indicates if manifest pre-fetch succeeded.
        """
        m = re.search(r"window\._econfig\s*=\s*['\"]([^'\"]+)['\"]", html)
        if not m:
            return [], False

        try:
            stream_url = self._decode_econgfig_url(html)
            if not stream_url:
                debug_log(f"[BkDr2] _decode_econgfig: no stream_url in config", xbmc.LOGWARNING)
                return [], False

            parsed = urlparse(url)
            domain = f"https://{parsed.netloc}"

            debug_log(f"[BkDr2] Found m3u8 via _econfig: {stream_url[:120]}", xbmc.LOGINFO)
            proxy_headers = {"Referer": url, "User-Agent": self.user_agents[0], "Origin": domain}
            proxy_options = {
                "browser_tls": True,
                "proxy_absolute_urls": True,
                "strip_png": True,
                "segment_strip_origin": True,
                "cache_manifest": True,
                "manifest_ttl": 10.0,
                "upstream_keep_alive": True,
                "prefetch_segments": True,
                "add_icy_metadata": False,
            }

            def _refresh_econgfig_url():
                try:
                    self._rate_limit()
                    self._update_last_request_time()
                    r = self._do_request('get', url, headers=proxy_headers, timeout=15)
                    if r.status_code == 200:
                        new_stream_url = self._decode_econgfig_url(r.text)
                        if new_stream_url:
                            new_stream_url = self._tokenize_manifest_url(new_stream_url, proxy_headers)
                            debug_log(f"[BkDr2] econfig refresh_callback: got fresh URL {new_stream_url[:120]}", xbmc.LOGINFO)
                            return {"url": new_stream_url, "headers": proxy_headers}
                except Exception as e:
                    debug_log(f"[BkDr2] econfig refresh_callback failed: {e}", xbmc.WARNING)
                return None

            stream_url = self._tokenize_manifest_url(stream_url, proxy_headers)
            proxy = get_stream_proxy("backdoor2", proxy_headers, proxy_options)
            proxy_url = None
            pre_fetch_ok = False

            try:
                self._rate_limit()
                self._update_last_request_time()
                manifest_resp = self._do_request('get', stream_url, headers=proxy_headers, timeout=15)
                if manifest_resp.status_code == 200:
                    proxy_url = proxy.cache_manifest_bytes(
                        manifest_resp.content,
                        stream_url,
                        proxy_headers,
                        refresh_callback=_refresh_econgfig_url,
                        manifest_decoder=decrypt_edge_playlist,
                    )
                    debug_log(f"[BkDr2] Pre-fetched manifest via _econfig", xbmc.LOGINFO)
                    pre_fetch_ok = True
                else:
                    debug_log(f"[BkDr2] Pre-fetch returned {manifest_resp.status_code}, using build_proxy_url", xbmc.LOGWARNING)
            except Exception as e:
                debug_log(f"[BkDr2] Pre-fetch error: {e}, using build_proxy_url", xbmc.LOGWARNING)

            if proxy_url is None:
                proxy_url = build_proxy_url(
                    "backdoor2", stream_url, proxy_headers,
                    options=proxy_options,
                    refresh_callback=_refresh_econgfig_url,
                    manifest_decoder=decrypt_edge_playlist,
                )

            return [JetLink(
                address=proxy_url,
                headers=proxy_headers,
                inputstream=JetInputstreamFFmpegDirect.default(),
            )], pre_fetch_ok
        except Exception as e:
            debug_log(f"[BkDr2] _decode_econgfig failed: {type(e).__name__}: {str(e)[:80]}", xbmc.LOGWARNING)
            return [], False

    def _dl_token(self, html: str, headers: dict, domain: str) -> List[JetLink]:
        """Extract stream via CHANNEL_KEY / M3U8_SERVER token method, or SRC fallback."""
        str_pattern = r'const\s+([A-Z0-9_]+)\s*=\s*([\'"])(.*?)\2'
        array_pattern = r'const\s+([A-Z0-9_]+)\s*=\s*\[(.*?)\]'
        str_matches = re.findall(str_pattern, html, re.DOTALL)
        strs = {name: value for name, _, value in str_matches}
        array_matches = re.findall(array_pattern, html, re.DOTALL)
        arrays = {name: re.findall(r'[\'"]([^\'"]+)[\'"]', value) for name, value in array_matches}

        channel_key = strs.get("CHANNEL_KEY")
        m3u8_server = strs.get("M3U8_SERVER")
        auth_token = strs.get("AUTH_TOKEN")

        if not m3u8_server:
            m3u8_servers = arrays.get("M3U8_SERVERS", [])
            if m3u8_servers:
                m3u8_server = m3u8_servers[0]

        if not channel_key or not m3u8_server:
            src_url = strs.get("SRC", "")
            if src_url and ".m3u8" in src_url:
                if src_url.startswith("//"):
                    src_url = "https:" + src_url
                debug_log(f"[BkDr2] _dl_token: no CHANNEL_KEY/M3U8_SERVER, using SRC: {src_url[:120]}", xbmc.LOGINFO)
                if self._should_route_through_proxy(src_url):
                    proxy_headers = {"Referer": domain + "/", "User-Agent": headers.get('User-Agent', self.user_agents[0]), "Origin": domain}
                    proxy_options = {
                        "browser_tls": True,
                        "proxy_absolute_urls": True,
                        "strip_png": True,
                        "segment_strip_origin": True,
                        "cache_manifest": True,
                        "manifest_ttl": 10.0,
                        "upstream_keep_alive": True,
                        "prefetch_segments": True,
                        "add_icy_metadata": False,
                    }
                    # Edge hosts require ?t=<token> on the manifest itself,
                    # not just for segment-URI decryption.
                    src_url = self._tokenize_manifest_url(src_url, proxy_headers)
                    proxy = get_stream_proxy("backdoor2", proxy_headers, proxy_options)
                    proxy_url = None
                    try:
                        self._rate_limit()
                        self._update_last_request_time()
                        manifest_resp = self._do_request('get', src_url, headers=proxy_headers, timeout=15)
                        if manifest_resp.status_code == 200:
                            proxy_url = proxy.cache_manifest_bytes(manifest_resp.content, src_url, proxy_headers,
                                                                   manifest_decoder=decrypt_edge_playlist)
                    except Exception:
                        pass
                    if proxy_url is None:
                        proxy_url = build_proxy_url("backdoor2", src_url, proxy_headers, options=proxy_options,
                                                    manifest_decoder=decrypt_edge_playlist)
                    debug_log(f"[BkDr2] _dl_token SRC routed through proxy: {proxy_url}", xbmc.LOGINFO)
                    return [JetLink(address=proxy_url, headers=proxy_headers, inputstream=JetInputstreamFFmpegDirect.default())]
                return [JetLink(
                    address=src_url,
                    headers={"Referer": domain + "/", "User-Agent": headers.get('User-Agent', self.user_agents[0]), "Origin": domain},
                    inputstream=JetInputstreamFFmpegDirect.default(),
                )]
            debug_log(f"[BkDr2] _dl_token: missing CHANNEL_KEY or M3U8_SERVER (found keys: {list(strs.keys())}, arrays: {list(arrays.keys())})", xbmc.LOGWARNING)
            return []

    def _matchora_stream(self, embed_url: str, embed_html: str, headers: dict) -> Tuple[List[JetLink], bool]:
        """Resolve matchora.to embeds via their /api/play/<ch> endpoint.

        matchora does not expose CHANNEL_KEY/M3U8_SERVER (its embed page
        carries `var PP="<pass>"` and fetches /api/play/<channel>?pp=<pass>
        with same-origin CORS headers). The answer is a *state*, not a link:
        {"ready":bool,"reason":...,"url":...,"pp":next-pass,"expires_in":600}.
        `url` is present while the channel is still warming and answers
        `404 warming` until `ready` flips - the page itself polls every
        0.6-2.5s and only loads the URL once ready. `reason` values mean:
            pass    - page pass stale: reload the embed for a fresh PP and retry
            verify  - Cloudflare Turnstile needed (cannot be solved here)
            capacity/limit/unknown/premium/dead - terminal for this channel
        So poll (bounded) until ready, then pre-fetch the manifest through
        StreamProxy. Never hand a warming URL to Kodi: it 404s on open.
        """
        try:
            m = re.search(r'/embed/channel/(\d+)', embed_url)
            ch = m.group(1) if m else None
            if not ch:
                return [], False
            pp_m = re.search(r'var\s+PP\s*=\s*"([^"]+)"', embed_html)
            pp = pp_m.group(1) if pp_m else ""
            parsed = urlparse(embed_url)
            origin = f"{parsed.scheme}://{parsed.netloc}"
            api_headers = {
                'User-Agent': headers.get('User-Agent', self.user_agents[0]),
                'Referer': embed_url,
                'Origin': origin,
                'Accept': '*/*',
                'Sec-Fetch-Site': 'same-origin',
                'Sec-Fetch-Mode': 'cors',
                'Sec-Fetch-Dest': 'empty',
            }
            stream_headers = {
                'User-Agent': api_headers['User-Agent'],
                'Referer': embed_url,
                'Origin': origin,
            }

            def _api_request():
                qs = f"?pp={quote(pp)}" if pp and not pp.startswith('_') else ""
                self._rate_limit()
                self._update_last_request_time()
                return self._do_request('get', f"{origin}/api/play/{ch}{qs}",
                                        headers=api_headers, timeout=15)

            def _api_json(resp):
                try:
                    data = resp.json()
                except Exception:
                    return None
                return data if isinstance(data, dict) else None

            def _renew_page_pass():
                # The page itself re-reads location.href for a new `var PP`.
                try:
                    pr = self._do_request('get', embed_url,
                                          headers={'User-Agent': api_headers['User-Agent'],
                                                   'Referer': headers.get('Referer', origin + '/')},
                                          timeout=15)
                    if pr.status_code == 200:
                        nm = re.search(r'var\s+PP\s*=\s*"([^"_][^"]*)"', pr.text)
                        if nm:
                            return nm.group(1)
                except Exception as e:
                    debug_log(f"[BkDr2] matchora page pass reload failed: {e}",
                              xbmc.LOGDEBUG)
                return None

            deadline = time.time() + 20.0
            attempt = 0
            stream = None
            resp = _api_request()
            while True:
                data = _api_json(resp)
                if data is None:
                    debug_log(f"[BkDr2] matchora play api returned {resp.status_code}: "
                              f"{(resp.text or '')[:80]}", xbmc.LOGWARNING)
                    return [], False
                if data.get('pp'):
                    pp = data['pp']
                reason = str(data.get('reason') or '').lower()
                url = data.get('url') or ''
                if data.get('ready') and url:
                    try:
                        self._rate_limit()
                        self._update_last_request_time()
                        mr = self._do_request('get', url, headers=stream_headers, timeout=15)
                    except Exception as e:
                        debug_log(f"[BkDr2] matchora manifest fetch error: {e}",
                                  xbmc.LOGWARNING)
                        mr = None
                    if mr is not None and mr.status_code == 200 \
                            and b'#EXTM3U' in (mr.content or b'')[:128]:
                        stream = url
                        manifest_body = mr.content
                        break
                    debug_log(f"[BkDr2] matchora ready but manifest answered "
                              f"{getattr(mr, 'status_code', 'error')}", xbmc.LOGINFO)
                elif reason == 'pass':
                    fresh = _renew_page_pass()
                    if not fresh:
                        debug_log("[BkDr2] matchora rejected page pass (needs a "
                                  "browser)", xbmc.LOGWARNING)
                        return [], False
                    pp = fresh
                    attempt = 0
                elif reason in ('capacity', 'limit', 'unknown', 'premium',
                                'dead', 'verify'):
                    debug_log(f"[BkDr2] matchora channel {ch} unavailable "
                              f"(reason={reason})", xbmc.LOGWARNING)
                    return [], False
                if time.time() >= deadline:
                    debug_log(f"[BkDr2] matchora not ready after 20s "
                              f"(reason={data.get('reason') or 'warming'})",
                              xbmc.LOGWARNING)
                    return [], False
                time.sleep(min(2.5, 0.8 + 0.4 * attempt))
                attempt += 1
                resp = _api_request()

            debug_log(f"[BkDr2] matchora stream: {stream[:120]}", xbmc.LOGINFO)
            proxy_options = {
                "browser_tls": True, "proxy_absolute_urls": True,
                "strip_png": True, "segment_strip_origin": True,
                "cache_manifest": True, "manifest_ttl": 10.0,
                "upstream_keep_alive": True, "prefetch_segments": True,
                "add_icy_metadata": False,
            }

            def _refresh_matchora():
                try:
                    rr = _api_request()
                    if rr.status_code in (200, 403):
                        fresh = _api_json(rr) or {}
                        if fresh.get('ready') and fresh.get('url'):
                            debug_log(f"[BkDr2] matchora refresh: "
                                      f"{fresh['url'][:120]}", xbmc.LOGINFO)
                            return {"url": fresh['url'], "headers": stream_headers}
                except Exception as e:
                    debug_log(f"[BkDr2] matchora refresh failed: {e}", xbmc.LOGWARNING)
                return None

            proxy = get_stream_proxy("backdoor2", stream_headers, proxy_options)
            proxy_url = proxy.cache_manifest_bytes(
                manifest_body, stream, stream_headers,
                refresh_callback=_refresh_matchora,
            )
            debug_log(f"[BkDr2] matchora manifest pre-fetched", xbmc.LOGINFO)
            return [JetLink(address=proxy_url, headers=stream_headers,
                            inputstream=JetInputstreamFFmpegDirect.default())], True
        except Exception as e:
            debug_log(f"[BkDr2] _matchora_stream failed: {type(e).__name__}: {e}",
                      xbmc.LOGWARNING)
            return [], False

    def _hdm1_stream(self, player_url: str, player_html: str,
                     headers: dict) -> Tuple[List[JetLink], bool]:
        """Resolve wideiptv.top -> cdn.hdm1.net token-gated HLS.

        The player page embeds `const config = {streamUrl: "...token=...",
        channelSlug: "..."}` with a 300s token. Route through StreamProxy and
        renew the token via POST <origin>/api/refresh_token.php
        {channel, current_token} -> {success, token, expires_in: 300} in the
        refresh_callback so Kodi never sees an aged/expired token URL.
        """
        try:
            m = re.search(r'streamUrl\s*:\s*["\']([^"\']+)["\']', player_html)
            if not m:
                return [], False
            stream = m.group(1).replace('\\/', '/')
            if 'cdn.hdm1.net' not in stream:
                return [], False
            slug_m = re.search(r'channelSlug\s*:\s*["\']([^"\']+)["\']', player_html)
            channel = slug_m.group(1) if slug_m else None
            parsed = urlparse(player_url)
            origin = f"{parsed.scheme}://{parsed.netloc}"
            stream_headers = {
                'User-Agent': headers.get('User-Agent', self.user_agents[0]),
                'Referer': player_url,
                'Origin': origin,
            }
            proxy_options = {
                "browser_tls": True, "proxy_absolute_urls": True,
                "strip_png": True, "segment_strip_origin": True,
                "cache_manifest": True, "manifest_ttl": 6.0,
                "upstream_keep_alive": True, "prefetch_segments": True,
                "add_icy_metadata": False,
                # cdn.hdm1.net intermittently blackholes new TCP connections
                # (~5s connect timeout) on this client; the proxy default (3,8)
                # / idle (2,3) budget turned that into failed refreshes and
                # "stream stalled". One connect retry + longer budgets absorb it.
                "request_timeout": (6, 20),
                "idle_timeout": (6, 12),
                "segment_timeout": (5, 25),
            }

            def _renew_hdm1_token():
                try:
                    cur = re.search(r'token=([^&]+)', stream)
                    if not channel or not cur:
                        return None
                    self._rate_limit()
                    self._update_last_request_time()
                    rr = self._do_request(
                        'post', f"{origin}/api/refresh_token.php",
                        headers={
                            'User-Agent': stream_headers['User-Agent'],
                            'Referer': player_url,
                            'Origin': origin,
                            'Content-Type': 'application/json',
                        },
                        json={'channel': channel, 'current_token': cur.group(1)},
                        timeout=12,
                    )
                    if rr.status_code == 200:
                        data = rr.json()
                        new_tok = data.get('token')
                        if data.get('success') and new_tok:
                            fresh = re.sub(r'token=[^&]+', 'token=' + new_tok, stream)
                            debug_log(f"[BkDr2] hdm1 token renewed "
                                      f"(expires_in {data.get('expires_in')})",
                                      xbmc.LOGINFO)
                            return {"url": fresh, "headers": stream_headers}
                except Exception as e:
                    debug_log(f"[BkDr2] hdm1 token renew failed: {e}",
                              xbmc.LOGWARNING)
                return None

            debug_log(f"[BkDr2] hdm1 stream: {stream[:120]}", xbmc.LOGINFO)
            proxy = get_stream_proxy("backdoor2", stream_headers, proxy_options)
            proxy_url = None
            pre_ok = False
            try:
                self._rate_limit()
                self._update_last_request_time()
                manifest_resp = self._do_request('get', stream,
                                                 headers=stream_headers, timeout=15)
                if manifest_resp.status_code == 200:
                    proxy_url = proxy.cache_manifest_bytes(
                        manifest_resp.content, stream, stream_headers,
                        refresh_callback=_renew_hdm1_token,
                    )
                    pre_ok = True
                    debug_log(f"[BkDr2] hdm1 manifest pre-fetched", xbmc.LOGINFO)
                else:
                    debug_log(f"[BkDr2] hdm1 manifest pre-fetch "
                              f"{manifest_resp.status_code}, using build_proxy_url",
                              xbmc.LOGWARNING)
            except Exception as e:
                debug_log(f"[BkDr2] hdm1 manifest pre-fetch error: {e}",
                          xbmc.LOGWARNING)
            if proxy_url is None:
                proxy_url = build_proxy_url("backdoor2", stream, stream_headers,
                                            options=proxy_options,
                                            refresh_callback=_renew_hdm1_token)
            return [JetLink(address=proxy_url, headers=stream_headers,
                            inputstream=JetInputstreamFFmpegDirect.default())], pre_ok
        except Exception as e:
            debug_log(f"[BkDr2] _hdm1_stream failed: {type(e).__name__}: {e}",
                      xbmc.LOGWARNING)
            return [], False

        # --- _dl_token continued: CHANNEL_KEY / M3U8_SERVER flow ---
        req_headers = dict(headers)
        req_headers.update({
            "Connection": "Keep-Alive",
            "X-Channel-Key": channel_key,
            "Accept": "application/json"
        })
        if auth_token:
            req_headers["Authorization"] = f"Bearer {auth_token}"

        try:
            server_lookup = f"https://{m3u8_server}/server_lookup?channel_id={channel_key}"
            r = self._do_request('get', server_lookup, headers=req_headers, timeout=15)
            data = r.json()
            server_key = data["server_key"]
        except Exception as e:
            debug_log(f"[BkDr2] Server lookup failed: {e}", xbmc.LOGWARNING)
            return []

        url = f"https://{m3u8_server}/proxy/{server_key}/{channel_key}/mono.css"
        stream_headers = {
            "User-Agent": headers.get('User-Agent', self.user_agents[0]),
            "Referer": domain + "/",
            "Origin": domain
        }

        return [JetLink(
            address=url,
            headers=stream_headers,
            inputstream=JetInputstreamFFmpegDirect.default(),
        )]

    def get_link(self, url: JetLink) -> JetLink:
        global _edge_blocked, _offair_detected
        debug_log(f"[BkDr2] get_link START: {url.address}", xbmc.LOGINFO)
        # Sticky WAF marker: the edge JA3 gate is a property of the Kodi
        # client, not of this channel, so a fresh call must not re-burn the
        # ~30s dembed ladder. _note_edge_blocked() refreshes the timestamp.
        _edge_blocked = (time.time() - _edge_waf_ts) < _EDGE_WAF_TTL
        _offair_detected = False

        channel_id = _channel_id(url.address)
        preferred = _preferred_player(channel_id)
        if preferred and _norm_stream_url(preferred) != _norm_stream_url(url.address):
            debug_log(f"[BkDr2] trying last known-good player first: {preferred}",
                      xbmc.LOGINFO)
            plink = JetLink(preferred, name=url.name, links=False)
            try:
                presult, pre_ok = self._get_link_once(plink)
                if pre_ok and self._is_resolved(presult, plink):
                    debug_log(f"[BkDr2] known-good player resolved: "
                              f"{presult.address[:120]}", xbmc.LOGINFO)
                    return presult
            except Exception as e:
                debug_log(f"[BkDr2] known-good player failed: "
                          f"{type(e).__name__}: {e}", xbmc.LOGWARNING)

        max_attempts = 4
        result = url
        pre_fetch_ok = False
        for attempt in range(max_attempts):
            if attempt > 0:
                debug_log(f"[BkDr2] get_link retry attempt {attempt + 1}/{max_attempts}", xbmc.LOGINFO)
                time.sleep(1.0 + random.uniform(0.5, 1.5))
                # time.sleep(1.0)

            result, pre_fetch_ok = self._get_link_once(url)
            if pre_fetch_ok or attempt == max_attempts - 1:
                break
            if _edge_blocked or _offair_detected:
                debug_log(f"[BkDr2] terminal edge response "
                          f"({'WAF' if _edge_blocked else 'offair'}), "
                          f"skipping remaining retries", xbmc.LOGWARNING)
                break

        if self._is_resolved(result, url) and pre_fetch_ok:
            _remember_player(channel_id, url.address)
            return result

        # The chosen player is dead: it never resolved to a stream (cast/plus
        # embeds our chain cannot follow) or its manifest never pre-fetched
        # (ksohls daddyhd - dead upstream). Walk the other player buttons on
        # the watch page, primary (stream-*) first, and return the first that
        # resolves with a fresh manifest.
        debug_log(f"[BkDr2] get_link: {url.address} failed (resolved={self._is_resolved(result, url)}, "
                  f"pre_fetch_ok={pre_fetch_ok}), trying sibling players", xbmc.LOGWARNING)
        fallback = self._try_sibling_players(url)
        if fallback is not None:
            return fallback
        return result

    def _is_resolved(self, link: JetLink, original: JetLink) -> bool:
        """Did a resolution attempt produce a NEW playable link?

        _get_link_once returns the input JetLink object itself on failure
        (unresolved page URL, exception), so identity plus address/inputstream
        checks distinguish success from "still pointing at the PHP page".
        """
        if link is None or link is original:
            return False
        if link.inputstream is not None:
            return True
        return bool(link.address) and link.address != original.address

    def _try_sibling_players(self, chosen: JetLink) -> Optional[JetLink]:
        """Walk the other player buttons on the watch page until one resolves.

        Single resolution attempt per candidate (no 4x retry burn) - dead
        players like ksohls would otherwise cost ~40s each. A candidate must
        resolve AND pre-fetch its manifest to win; a resolved-but-unfetched
        candidate is kept as best effort only when nothing better is found.
        """
        m = re.search(r'/stream-(\d+)\.php', chosen.address)
        if not m:
            m = re.search(r'[?&]id=(\d+)', chosen.address)
        if not m:
            return None
        channel_id = m.group(1)
        page_url = f"https://thedaddy.li/watch.php?id={channel_id}"

        try:
            candidates = self._get_player_candidates(page_url)
        except Exception as e:
            debug_log(f"[BkDr2] get_link fallback: failed to list players: {e}", xbmc.LOGWARNING)
            return None
        if not candidates:
            return None

        # Order the walk by yield: wideiptv/player (works from plain python) ->
        # casting (matchora) -> cast -> plus -> dembed-backed (all edge/WAF).
        def _rank(link):
            addr = link.address
            if '/player/' in addr:
                return 0
            if '/casting/' in addr:
                return 1
            if '/cast/' in addr:
                return 2
            if '/plus/' in addr:
                return 3
            return 4

        candidates = sorted(candidates, key=_rank)

        # dembed-backed buttons (stream/watch/hub) all resolve to the same
        # edge host the WAF just rejected - skip them entirely once fired so
        # the walk goes straight to the working non-edge siblings.
        dembed_backed = _DEMBED_BACKED_RE
        best_unfetched = None
        for link in candidates:
            if link.address == chosen.address:
                continue
            if _edge_blocked and dembed_backed.search(link.address):
                debug_log(f"[BkDr2] get_link fallback: skipping {link.name or link.address} "
                          f"(edge WAF already fired)", xbmc.LOGDEBUG)
                continue
            debug_log(f"[BkDr2] get_link fallback: trying {link.name or link.address}: {link.address}", xbmc.LOGINFO)
            try:
                result, pre_fetch_ok = self._get_link_once(link)
            except Exception as e:
                debug_log(f"[BkDr2] get_link fallback: {link.address} raised {type(e).__name__}: {e}", xbmc.LOGWARNING)
                continue
            if self._is_resolved(result, link):
                if pre_fetch_ok:
                    _remember_player(channel_id, link.address)
                    debug_log(f"[BkDr2] get_link fallback: using {link.address} -> {result.address[:120]}", xbmc.LOGINFO)
                    return result
                if best_unfetched is None:
                    best_unfetched = result

        if best_unfetched is not None:
            debug_log(f"[BkDr2] get_link fallback: no candidate pre-fetched cleanly, using best effort: "
                      f"{best_unfetched.address[:120]}", xbmc.LOGWARNING)
        return best_unfetched

    def _get_link_once(self, url: JetLink) -> Tuple[JetLink, bool]:
        """Single attempt at resolving a link. Returns (JetLink, pre_fetch_ok)."""
        try:
            self._rate_limit()

            headers = {
                'User-Agent': random.choice(self.user_agents),
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.5',
                'Origin': 'https://thedaddy.li',
                'Referer': 'https://thedaddy.li/',
            }

            stream_url = url.address
            if stream_url.startswith('//'):
                stream_url = 'https:' + stream_url

            if _edge_blocked and _DEMBED_BACKED_RE.search(stream_url):
                # dembed-backed player + known JA3 WAF: fetching the page,
                # iframe, ticket and token would all end at the same 403.
                debug_log(f"[BkDr2] edge WAF cached, skipping dembed-backed "
                          f"player {stream_url}", xbmc.LOGINFO)
                return url, False

            r, final_url, final_headers = self._follow_iframes(stream_url, headers)
            if r and r.status_code == 200:
                parsed = urlparse(final_url)
                domain = f"https://{parsed.netloc}"

                stream_url_found = self._scan_m3u8(r.text, final_url)
                if stream_url_found:
                    debug_log(f"[BkDr2] Found m3u8: {stream_url_found[:120]}", xbmc.LOGINFO)
                    if self._should_route_through_proxy(stream_url_found):
                        proxy_headers = {"Referer": final_url, "User-Agent": headers['User-Agent'], "Origin": domain}
                        proxy_options = {
                            "browser_tls": True,
                            "proxy_absolute_urls": True,
                            "strip_png": True,
                            "segment_strip_origin": True,
                            "cache_manifest": True,
                            "manifest_ttl": 10.0,
                            "upstream_keep_alive": True,
                            "prefetch_segments": True,
                            "add_icy_metadata": False,
                        }

                        def _refresh_hls_url():
                            try:
                                self._rate_limit()
                                self._update_last_request_time()
                                r = self._do_request('get', final_url, headers=proxy_headers, timeout=15)
                                if r.status_code == 200:
                                    new_stream_url = self._scan_m3u8(r.text, final_url)
                                    if new_stream_url and self._should_route_through_proxy(new_stream_url):
                                        new_stream_url = self._tokenize_manifest_url(new_stream_url, proxy_headers)
                                        debug_log(f"[BkDr2] refresh_callback: got fresh URL {new_stream_url[:120]}", xbmc.LOGINFO)
                                        return {"url": new_stream_url, "headers": proxy_headers}
                            except Exception as e:
                                debug_log(f"[BkDr2] refresh_callback failed: {e}", xbmc.WARNING)
                            return None

                        if not _edge_blocked:
                            stream_url_found = self._tokenize_manifest_url(stream_url_found, proxy_headers)
                        proxy = get_stream_proxy("backdoor2", proxy_headers, proxy_options)
                        proxy_url = None
                        hls_pre_fetch_ok = False
                        if _edge_blocked:
                            # WAF proven (possibly by the token request just
                            # now): a manifest pre-fetch would be the same 403.
                            debug_log("[BkDr2] edge WAF cached, skipping premium pre-fetch", xbmc.LOGINFO)
                        else:
                            try:
                                self._rate_limit()
                                self._update_last_request_time()
                                manifest_resp = self._do_request('get', stream_url_found, headers=proxy_headers, timeout=15)
                                if manifest_resp.status_code == 200:
                                    proxy_url = proxy.cache_manifest_bytes(
                                        manifest_resp.content,
                                        stream_url_found,
                                        proxy_headers,
                                        refresh_callback=_refresh_hls_url,
                                        manifest_decoder=decrypt_edge_playlist,
                                    )
                                    debug_log(f"[BkDr2] Pre-fetched premium manifest: {stream_url_found[:120]}", xbmc.LOGINFO)
                                    hls_pre_fetch_ok = True
                                else:
                                    _note_offair(manifest_resp, stream_url_found)
                                    _note_edge_blocked(manifest_resp, stream_url_found)
                                    debug_log(f"[BkDr2] Premium pre-fetch returned {manifest_resp.status_code}, using build_proxy_url", xbmc.LOGWARNING)
                            except Exception as e:
                                debug_log(f"[BkDr2] Premium pre-fetch error: {e}, using build_proxy_url", xbmc.LOGWARNING)

                        if proxy_url is None:
                            proxy_url = build_proxy_url(
                                "backdoor2", stream_url_found, proxy_headers,
                                options=proxy_options,
                                refresh_callback=_refresh_hls_url,
                                manifest_decoder=decrypt_edge_playlist,
                            )

                        return JetLink(
                            address=proxy_url,
                            headers=proxy_headers,
                            inputstream=JetInputstreamFFmpegDirect.default(),
                        ), hls_pre_fetch_ok
                    if 'hdm1.net' in stream_url_found or 'wideiptv' in final_url:
                        hdm1_result, hdm1_ok = self._hdm1_stream(
                            final_url, r.text, headers)
                        if hdm1_result:
                            return hdm1_result[0], hdm1_ok
                    return JetLink(
                        address=stream_url_found,
                        headers={"Referer": final_url, "User-Agent": headers['User-Agent'], "Origin": domain},
                        inputstream=JetInputstreamFFmpegDirect.default(),
                    ), True

                stream_url_found = self._decode_array(r.text, final_url)
                if stream_url_found:
                    debug_log(f"[BkDr2] Found char array stream: {stream_url_found[:120]}", xbmc.LOGINFO)
                    return JetLink(
                        address=stream_url_found,
                        headers={"Referer": final_url, "User-Agent": headers['User-Agent'], "Origin": domain},
                        inputstream=JetInputstreamFFmpegDirect.default(),
                    ), True

                stream_url_found = self._decode_hex_source(r.text)
                if stream_url_found:
                    debug_log(f"[BkDr2] Found hex stream: {stream_url_found[:120]}", xbmc.LOGINFO)
                    return JetLink(
                        address=stream_url_found,
                        headers={"Referer": final_url, "User-Agent": headers['User-Agent'], "Origin": domain},
                        inputstream=JetInputstreamFFmpegDirect.default(),
                    ), True

                stream_url_found = self._decode_atob(r.text)
                if stream_url_found:
                    debug_log(f"[BkDr2] Found atob stream: {stream_url_found[:120]}", xbmc.LOGINFO)
                    return JetLink(
                        address=stream_url_found,
                        headers={"Referer": final_url, "User-Agent": headers['User-Agent'], "Origin": domain},
                        inputstream=JetInputstreamFFmpegDirect.default(),
                    ), True

                stream_url_found = self._decode_xor_array(r.text)
                if stream_url_found:
                    debug_log(f"[BkDr2] Found XOR stream: {stream_url_found[:120]}", xbmc.LOGINFO)
                    xor_headers = {"Referer": final_url, "User-Agent": headers['User-Agent'], "Origin": domain}
                    if self._should_route_through_proxy(stream_url_found):
                        xor_options = {
                            "browser_tls": True, "proxy_absolute_urls": True,
                            "strip_png": True, "segment_strip_origin": True,
                            "cache_manifest": True, "manifest_ttl": 10.0,
                            "upstream_keep_alive": True, "prefetch_segments": True,
                            "add_icy_metadata": False,
                        }
                        xor_proxy = get_stream_proxy("backdoor2", xor_headers, xor_options)
                        xor_proxy_url = None
                        if not _edge_blocked:
                            stream_url_found = self._tokenize_manifest_url(stream_url_found, xor_headers)
                        try:
                            if _edge_blocked:
                                raise RuntimeError("edge WAF cached")
                            self._rate_limit()
                            self._update_last_request_time()
                            mr = self._do_request('get', stream_url_found, headers=xor_headers, timeout=15)
                            if mr.status_code == 200:
                                xor_proxy_url = xor_proxy.cache_manifest_bytes(mr.content, stream_url_found, xor_headers,
                                                                               manifest_decoder=decrypt_edge_playlist)
                        except Exception:
                            pass
                        if xor_proxy_url is None:
                            xor_proxy_url = build_proxy_url("backdoor2", stream_url_found, xor_headers, options=xor_options,
                                                            manifest_decoder=decrypt_edge_playlist)
                        debug_log(f"[BkDr2] XOR stream routed through proxy: {xor_proxy_url}", xbmc.LOGINFO)
                        return JetLink(address=xor_proxy_url, headers=xor_headers, inputstream=JetInputstreamFFmpegDirect.default()), True
                    return JetLink(
                        address=stream_url_found,
                        headers=xor_headers,
                        inputstream=JetInputstreamFFmpegDirect.default(),
                    ), True

                econfig_result, econfig_pre_fetch_ok = self._decode_econgfig(r.text, final_url)
                if econfig_result:
                    return econfig_result[0], econfig_pre_fetch_ok

                # matchora.to embeds (Player 5 "casting") resolve via their
                # own /api/play API - try BEFORE _dl_token (which only knows
                # CHANNEL_KEY/M3U8_SERVER and always misses here).
                if 'matchora' in final_url:
                    matchora_result, matchora_ok = self._matchora_stream(
                        final_url, r.text, headers)
                    if matchora_result:
                        return matchora_result[0], matchora_ok

                result = self._dl_token(r.text, headers, domain)
                if result:
                    return result[0], True

                premium_result, premium_pre_fetch_ok = self._extract_premium_hls(r.text, final_url, headers)
                if premium_result:
                    return premium_result, premium_pre_fetch_ok

            premium_result, premium_pre_fetch_ok = self._extract_premium_hls("", stream_url, headers)
            if premium_result:
                return premium_result, premium_pre_fetch_ok

            return url, True

        except Exception as e:
            debug_log(f"[BkDr2] Error in get_link: {str(e)}", xbmc.LOGERROR)
            debug_log(f"[BkDr2] Traceback: {traceback.format_exc()}", xbmc.LOGERROR)
            return url, True

    def _get_icon(self, title: str) -> Optional[str]:
        from ..icons import icons
        title_lower = (title or "").lower()
        for key, icon in icons.items():
            if key.lower() in title_lower:
                return icon
        return None

    def _rate_limit(self):
        global _module_last_request_time
        elapsed = time.time() - _module_last_request_time
        if elapsed < self.min_request_interval:
            wait_time = self.min_request_interval - elapsed + random.uniform(1.0, 3.0)
            debug_log(f"[BkDr2] Rate limiting: waiting {wait_time:.1f}s", xbmc.LOGINFO)
            time.sleep(wait_time)

    def _update_last_request_time(self):
        global _module_last_request_time
        _module_last_request_time = time.time()
