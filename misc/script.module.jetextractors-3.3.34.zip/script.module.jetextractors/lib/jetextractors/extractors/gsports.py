import base64
import html as html_lib
import json
import re
import zlib
import xbmc
from html.parser import HTMLParser
from typing import List, Optional
from urllib.parse import urljoin, urlparse, unquote
from urllib.request import Request, urlopen

from .._core import fetch_page
from ..models import (
    JetExtractor,
    JetExtractorProgress,
    JetInputstreamAdaptive,
    JetItem,
    JetLink,
)
from ..tools import debug_log
from ..util.stream_proxy import get_stream_proxy
from ..util import embedsportstop

_STREAMED_TV_UA = (
    "Mozilla/5.0 (SMART-TV; Linux; Tizen 6.0) AppleWebKit/537.36 "
    "(KHTML, like Gecko) SamsungBrowser/16.0 TV Safari/537.36"
)


class _ScheduleParser(HTMLParser):
    """Read the new blogs.st/meth/ game-card schedule without extra packages."""

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.events = []
        self._div_depth = 0
        self._category = None
        self._category_depth = None
        self._card = None
        self._field = None

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        classes = (attrs.get("class") or "").split()
        if tag == "div":
            self._div_depth += 1
            if "cat-section" in classes:
                self._category = (attrs.get("data-cat") or "").upper() or None
                self._category_depth = self._div_depth
        elif tag == "a" and "game-card" in classes:
            self._card = {
                "url": attrs.get("href") or "",
                "title": "",
                "league": self._category,
            }
        elif tag == "span" and self._card is not None:
            if "game-name" in classes:
                self._field = "title"

    def handle_data(self, data):
        if self._card is not None and self._field == "title":
            self._card["title"] += data

    def handle_endtag(self, tag):
        if tag == "span":
            self._field = None
        elif tag == "a" and self._card is not None:
            self._card["title"] = " ".join(self._card["title"].split())
            if self._card["url"] and self._card["title"]:
                self.events.append(self._card)
            self._card = None
            self._field = None
        elif tag == "div":
            if self._category_depth == self._div_depth:
                self._category = None
                self._category_depth = None
            self._div_depth = max(0, self._div_depth - 1)


def _adaptive_live(headers: dict) -> JetInputstreamAdaptive:
    """Pass GSports HTTP headers through Adaptive, not the URL pipe suffix."""
    adaptive = JetInputstreamAdaptive.hls()
    # JetExtractors models.py supports these two fields.  Kodi 22 uses
    # manifest_headers for playlists and stream_headers for TS segments.
    adaptive.manifest_headers = dict(headers)
    adaptive.stream_headers = dict(headers)
    return adaptive


class GSports(JetExtractor):
    def __init__(self) -> None:
        self.domains = ["blogs.st", "www.blogs.st"]
        self.name = "GSports"
        self.short_name = "GS"
        self.base_url = "https://blogs.st/meth"
        self.site_origin = "https://blogs.st"
        self.headers = {
            "User-Agent": _STREAMED_TV_UA,
            "Referer": f"{self.base_url}/",
            "Origin": self.site_origin,
        }
        self._proxy = None

    @staticmethod
    def _is_site_page(address: str) -> bool:
        if not isinstance(address, str):
            return False
        parsed = urlparse(address)
        if parsed.scheme not in ("http", "https"):
            return False
        if parsed.hostname not in ("blogs.st", "www.blogs.st"):
            return False
        # New event URLs are /ms/<id>/, NOT /meth/games/.
        return parsed.path.startswith(("/ms/", "/meth/", "/games/"))

    def _get_proxy(self):
        if self._proxy is None:
            self._proxy = get_stream_proxy(
                "gsports",
                self.headers,
                options={
                    # Preserve the known upstream connection and prefetch behaviour.
                    "user_agent": _STREAMED_TV_UA,
                    "upstream_keep_alive": True,
                    "prefetch_segments": True,
                    # GSports /list streams use image-suffixed media URLs which may be wrapped.
                    # The existing StreamProxy sniffs PNG/WebP payloads and
                    # unwraps them to TS before Kodi's decoder receives them.
                    "strip_png": True,
                    "keep_alive": False,
                    "proxy_absolute_urls": True,
                },
            )
        return self._proxy

    def _create_items(self, records):
        items = []
        seen_urls = set()
        for event in records:
            if not isinstance(event, dict):
                continue
            title = str(event.get("title") or "").strip()
            address = urljoin(self.site_origin + "/", str(event.get("url") or "").strip())
            if not title or not self._is_site_page(address) or address in seen_urls:
                continue
            seen_urls.add(address)
            league = event.get("category") or event.get("league")
            status = event.get("status")
            if status and str(status).strip().lower() == "ended":
                continue
            items.append(
                JetItem(
                    title=title,
                    links=[JetLink(address, links=True)],
                    status=str(status).upper() if status else None,
                    league=str(league).upper() if league else None,
                )
            )
        return items

    def get_items(
        self,
        params: Optional[dict] = None,
        progress: Optional[JetExtractorProgress] = None,
    ) -> List[JetItem]:
        items: List[JetItem] = []
        if self.progress_init(progress, items):
            return items
        if progress:
            self.progress_update(progress, "Fetching schedule...")

        # Site advertises its schedule as JSON at /meth?api.
        api_text = fetch_page(f"{self.base_url}?api", referer=f"{self.base_url}/")
        if api_text:
            try:
                payload = json.loads(api_text)
                events = payload.get("events", []) if isinstance(payload, dict) else []
                if isinstance(events, list):
                    items = self._create_items(events)
            except (ValueError, TypeError):
                pass  # If the API serves HTML/error output, parse the public schedule.

        if not items:
            html = fetch_page(f"{self.base_url}/", referer=f"{self.base_url}/")
            if html:
                parser = _ScheduleParser()
                parser.feed(html)
                items = self._create_items(parser.events)
            else:
                debug_log("[GSports] No schedule returned by blogs.st/meth/", xbmc.LOGWARNING)

        debug_log(f"[GSports] Returning {len(items)} events", xbmc.LOGINFO)
        return items

    def get_links(self, url: JetLink) -> List[JetLink]:
        address = url.address if isinstance(url, JetLink) else url
        if not self._is_site_page(address):
            return []
        return [
            JetLink(
                address=address,
                name="Stream",
                headers={"Referer": f"{self.base_url}/"},
                resolveurl=True,
                extractor=self.name,
            )
        ]

    @staticmethod
    def _find_hls_urls(text: str):
        """Find literal .m3u8 HLS URLs without executing JS."""
        # Support JSON/JavaScript-escaped URL strings and HTML-escaped query strings.
        text = html_lib.unescape(text).replace(r"\/", "/")
        text = re.sub(r"\\u0026", "&", text, flags=re.IGNORECASE)
        text = re.sub(r"\\u003d", "=", text, flags=re.IGNORECASE)
        text = re.sub(r"\\u002f", "/", text, flags=re.IGNORECASE)
        found = []
        for value in re.findall(r"https?://[^\s\"'<>\\()]+", text, flags=re.IGNORECASE):
            value = value.rstrip(".,;]}")
            check = urlparse(value)
            if check.scheme in ("http", "https") and check.hostname and ".m3u8" in check.path.lower():
                if value not in found:
                    found.append(value)
        return found

    @staticmethod
    def _find_player_stream_urls(text: str):
        """Read literal HLS sources, including extensionless URLs used by Clappr.

        The current /ms/ player assigns the HLS source to `const streamUrl`.
        Do not execute JavaScript or assume that HLS URLs end in .m3u8.
        """
        if not text:
            return []
        clean = html_lib.unescape(text).replace(r"\/", "/")
        clean = re.sub(r"\\u002f", "/", clean, flags=re.IGNORECASE)
        clean = re.sub(r"\\u0026", "&", clean, flags=re.IGNORECASE)
        matches = []
        # Explicit player setting is preferable to unrelated .m3u8 strings.
        for match in re.finditer(
            r"""\b(?:const|let|var)\s+streamUrl\s*=\s*(["'`])(https?://[^"'`\s<>]+)\1""",
            clean,
            flags=re.IGNORECASE,
        ):
            matches.append(match.group(2))
        # Preserve support for conventional embedded HLS URLs.
        matches.extend(GSports._find_hls_urls(clean))
        result = []
        for value in matches:
            value = value.rstrip(".,;]}")
            parsed = urlparse(value)
            if parsed.scheme not in ("https", "http") or not parsed.hostname:
                continue
            if parsed.username or parsed.password:
                continue
            if value not in result:
                result.append(value)
        return result

    @staticmethod
    def _decode_bootstrap(html: str):
        """Decode only the small inline stage-one loader as *text* (do not execute)."""
        if "new Function(Array.from(atob(d)" not in html:
            return None
        # This is the stage-one inline bootstrap (base64 text XOR one byte).
        match = re.search(r'\("([A-Za-z0-9+/=]{100,})",(\d+)\)', html)
        if not match:
            return None
        try:
            encoded = base64.b64decode(match.group(1), validate=True)
            key = int(match.group(2))
            return "".join(chr(b ^ key) for b in encoded)
        except (ValueError, TypeError):
            return None

    def _fetch_second_stage(self, page_url: str, html: str):
        """Fetch and decode the site's disguised font payload using standard library."""
        loader = self._decode_bootstrap(html)
        if not loader:
            debug_log("[GSports] No recognisable player bootstrap", xbmc.LOGWARNING)
            return None
        # Accept fetch('?v=font.woff2', {cache:'default'}) as well as fetch('?v=font.woff2').
        # Only match a literal quoted font URL. Existing same-origin validation remains.
        asset_match = re.search(r"\bfetch\s*\(\s*([\"'])((?:[^\"']+)\.woff2(?:[?#][^\"']*)?)\1", loader)
        key_match = re.search(r"\bk\s*=\s*['\"]([^'\"]+)['\"]", loader)
        if not asset_match or not key_match:
            debug_log("[GSports] Player bootstrap uses an unknown asset or key", xbmc.LOGWARNING)
            return None
        asset_url = urljoin(page_url, asset_match.group(2))
        key_bytes = key_match.group(1).encode("utf-8")
        if not key_bytes or urlparse(asset_url).hostname != urlparse(page_url).hostname:
            return None
        headers = dict(self.headers)
        # A plain browser User-Agent fetched the provided player payload.
        # Use it for the font-disguised JS download only; keep the existing
        # Samsung-TV User-Agent for stream requests and StreamProxy.
        headers.update({"User-Agent": "Mozilla/5.0", "Referer": page_url, "Accept": "*/*"})
        try:
            request = Request(asset_url, headers=headers)
            with urlopen(request, timeout=15) as response:
                payload = response.read(1024 * 1024 + 1)
            if not payload or len(payload) > 1024 * 1024:
                debug_log("[GSports] Player payload missing or too large", xbmc.LOGWARNING)
                return None
            xored = bytes(b ^ key_bytes[i % len(key_bytes)] for i, b in enumerate(payload))
            decomp = zlib.decompressobj(-zlib.MAX_WBITS)
            decoded = decomp.decompress(xored, 3 * 1024 * 1024 + 1)
            if len(decoded) > 3 * 1024 * 1024:
                debug_log("[GSports] Decoded player script too large", xbmc.LOGWARNING)
                return None
            if not decomp.eof:
                debug_log("[GSports] Incomplete or oversized decoded player script", xbmc.LOGWARNING)
                return None
            decoded += decomp.flush()
            if len(decoded) > 3 * 1024 * 1024:
                return None
            return decoded.decode("utf-8", errors="replace")
        except Exception as exc:
            debug_log(f"[GSports] Could not download/decode player payload: {type(exc).__name__}: {exc}", xbmc.LOGWARNING)
            return None

    def _resolve_embed(self, page_url: str):
        """Resolve the Clappr source or the legacy embed.st player."""
        html = fetch_page(page_url, referer=f"{self.base_url}/")
        if not html:
            return None, None

        # Older pages can still use the embed.st player.
        for raw_src in re.findall(
            r"""<iframe\b[^>]*\bsrc\s*=\s*[\"']([^\"']+)[\"']""",
            html,
            re.IGNORECASE,
        ):
            embed_url = urljoin(page_url, raw_src)
            if urlparse(embed_url).hostname in ("embed.st", "www.embed.st"):
                stream = embedsportstop.get_embedsportstop_stream(embed_url)
                if stream:
                    return stream, embed_url

        # New blogs.st/ms player: a small inline bootstrap fetches ?v=font.woff2,
        # XORs it with "gs99" and inflates raw DEFLATE data into its player code.
        # The second-stage JavaScript sets `const streamUrl` to an HLS source,
        # which may be extensionless (e.g. a /list2 endpoint).
        urls = self._find_player_stream_urls(html)
        if not urls:
            decoded_script = self._fetch_second_stage(page_url, html)
            if decoded_script:
                urls = self._find_player_stream_urls(decoded_script)
                if not urls:
                    debug_log(
                        "[GSports] Decoded player but no direct streamUrl/HLS address found",
                        xbmc.LOGWARNING,
                    )
        if urls:
            debug_log("[GSports] Found HLS source in player configuration", xbmc.LOGINFO)
            return urls[0], page_url
        return None, None

    def get_link(self, url: JetLink) -> JetLink:
        page_url = url.address if isinstance(url, JetLink) else url
        if not self._is_site_page(page_url):
            return None

        try:
            stream, embed_url = self._resolve_embed(page_url)
        except Exception as e:
            debug_log(f"[GSports] Player resolution error: {e}", xbmc.LOGWARNING)
            return None
        if not stream:
            return None
        debug_log(f"[GSports] Resolved: {stream[:110]}", xbmc.LOGINFO)
        # The site's extensionless /list playlists contain TikTok CDN '.image'
        # segments. Kodi may fetch them without decoding image-wrapped TS.
        # Only route this source through GSports' already-present StreamProxy;
        # keep Adaptive as player and leave all other GSports sources untouched.
        stream_headers = dict(self.headers)
        stream_headers["Referer"] = page_url
        parsed = urlparse(stream)
        if parsed.hostname in ("mixedshop.pw", "www.mixedshop.pw") and re.fullmatch(r"/list\d+/?", parsed.path):
            try:
                local_url = self._get_proxy().get_proxy_url(stream, stream_headers)
                debug_log("[GSports] Opening mixedshop HLS through image-unwrapping StreamProxy", xbmc.LOGINFO)
                return JetLink(local_url, inputstream=_adaptive_live({}))
            except Exception as exc:
                # A proxy start failure must not block the previous direct path.
                debug_log(f"[GSports] StreamProxy unavailable; falling back to direct Adaptive: {type(exc).__name__}: {exc}", xbmc.LOGWARNING)
        debug_log("[GSports] Opening upstream HLS with Adaptive HTTP headers", xbmc.LOGINFO)
        return JetLink(stream, inputstream=_adaptive_live(stream_headers))
