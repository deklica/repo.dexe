import re
import xbmc
from urllib.parse import quote, urljoin, urlparse

from bs4 import BeautifulSoup as bs

from ..models import *
from .._core import fetch_page, find_m3u8, find_iframes
from ..tools import debug_log
from ..util.stream_proxy import get_stream_proxy


class FawaNews(JetExtractor):
    def __init__(self) -> None:
        self.domains = ["www.fawanews.sc", "fawanews.sc"]
        self.name = "FawaNews"
        self.short_name = "FW"
        self.base_url = "http://www.fawanews.sc"
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
            "Referer": f"{self.base_url}/",
        }
        self._proxy = None

    def _get_proxy(self):
        if self._proxy is None:
            self._proxy = get_stream_proxy(
                "fawanews",
                self.headers,
                options={
                    "strip_png": False,
                    "prefetch_segments": True,
                    "upstream_keep_alive": True,
                    "keep_alive": False,
                },
            )
        return self._proxy

    def get_items(self, params: Optional[dict] = None, progress: Optional[JetExtractorProgress] = None) -> List[JetItem]:
        items = []
        if self.progress_init(progress, items):
            return items

        html = fetch_page(f"{self.base_url}/", referer=self.base_url)
        if not html:
            return items

        soup = bs(html, "html.parser")
        seen = set()
        for card in soup.select("div.user-item"):
            name_el = card.select_one(".user-item__name")
            if not name_el:
                continue
            title = name_el.get_text(strip=True)
            if not title or title in seen:
                continue

            a_el = card.find("a", href=True)
            if not a_el:
                continue
            href = a_el["href"].strip()
            if not href or href.startswith(("http://", "https://", "//")):
                continue
            href = href.split("#")[0].split("?")[0].strip()
            if not href:
                continue
            seen.add(title)

            icon = ""
            img_el = card.select_one(".user-item__avatar img") or card.find("img")
            if img_el and img_el.get("src"):
                icon = img_el["src"].strip()

            league = None
            status = None
            playing_el = card.select_one(".user-item__playing")
            if playing_el:
                playing = playing_el.get_text(" ", strip=True)
                m = re.match(r"^(.*?)\s+((?:\d{1,2}:\d{2})|--:--)$", playing)
                if m:
                    league = m.group(1).strip() or None
                    status = m.group(2)
                elif playing:
                    league = playing

            # Event pages live at the site root; quote spaces/specials in filename.
            link = f"{self.base_url}/{quote(href)}"
            items.append(JetItem(title=title, links=[JetLink(link, links=True)], icon=icon, league=league, status=status))

        return items

    @staticmethod
    def _js_string(html: str, name: str) -> Optional[str]:
        m = re.search(r'(?:(?:var|let|const)\s+)?%s\s*=\s*["\']([^"\']*)["\']' % re.escape(name), html)
        return m.group(1) if m else None

    def _extract_streams(self, html: str) -> List[str]:
        streams = []

        # Legacy player vars: var d1="..."; var d2="..."; var d3="..."
        parts = re.findall(r'var\s+d\d+\s*=\s*["\']([^"\']*)["\']', html)
        if len(parts) >= 3:
            streams.append("".join(parts))

        # Current player vars: var S1=[...]; var S2="token"; var S3=".m3u8"
        bases_m = re.search(r'\bS1\s*=\s*\[(.*?)\]', html, re.S)
        if bases_m:
            bases = re.findall(r'["\']([^"\']+)["\']', bases_m.group(1))
        else:
            s1 = self._js_string(html, "S1")
            bases = [s1] if s1 else []
        s2 = self._js_string(html, "S2")
        s3 = self._js_string(html, "S3")
        if bases and s2 is not None and s3 is not None:
            for base in bases:
                streams.append(base + s2 + s3)

        # Explicit Clappr source / absolute m3u8 in the page.
        m = re.search(r'source\s*:\s*["\']([^"\']+\.m3u8[^"\']*)["\']', html)
        if m:
            streams.append(m.group(1))
        fallback = find_m3u8(html, self.base_url)
        if fallback:
            streams.append(fallback)

        out, seen = [], set()
        for stream in streams:
            stream = (stream or "").strip()
            if not stream:
                continue
            if not stream.startswith(("http://", "https://")):
                stream = urljoin(self.base_url + "/", stream)
            parsed = urlparse(stream)
            name = (parsed.path or "").rsplit("/", 1)[-1]
            # Reject bare placeholders such as ".m3u8" (S3) or page-root URLs.
            if parsed.scheme not in ("http", "https") or not parsed.netloc:
                continue
            if not name or name in (".m3u8", ".mpd"):
                continue
            if stream not in seen:
                seen.add(stream)
                out.append(stream)
        return out

    def get_links(self, url: JetLink) -> List[JetLink]:
        links = []
        html = fetch_page(url.address, referer=self.base_url)
        if not html:
            return links

        for stream in self._extract_streams(html):
            name = f"Stream {len(links) + 1}"
            try:
                proxy_url = self._get_proxy().get_proxy_url(stream, self.headers)
                links.append(JetLink(
                    proxy_url,
                    name=name,
                    headers=self.headers,
                    inputstream=JetInputstreamFFmpegDirect.default(),
                ))
            except Exception as e:
                debug_log(f"[FawaNews] Proxy failed for {stream}: {e}", xbmc.LOGWARNING)
                links.append(JetLink(
                    stream,
                    name=name,
                    headers=self.headers,
                    inputstream=JetInputstreamAdaptive.hls(),
                ))

        if not links:
            for iframe_url in find_iframes(html, url.address):
                links.append(JetLink(iframe_url, resolveurl=True, name="Embed"))

        return links

    def get_link(self, url: JetLink) -> Optional[JetLink]:
        if not url or not url.address:
            return None
        for link in self.get_links(url):
            if link is None:
                continue
            if link.direct or link.inputstream is not None:
                return link
            if ".m3u8" in link.address or ".mp4" in link.address:
                return link
        return None
