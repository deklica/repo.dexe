from ..models import JetExtractor, JetItem, JetLink, JetExtractorProgress, JetInputstreamAdaptive, JetInputstreamFFmpegDirect
from .._core import get_headers, get_session, find_m3u8, find_iframes, make_link, fetch_json
from ..util.stream_proxy import get_stream_proxy
from ..tools import debug_log
import base64
import re
import time
import xbmc
from urllib.parse import urlparse, parse_qs, quote, unquote
from typing import Optional, List, Dict, Any

_TV_UA = "Mozilla/5.0 (SMART-TV; Linux; Tizen 6.0) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/16.0 TV Safari/537.36"

# Live TV: only these countries are listed (site country codes from /data/dlhd-channels.json
# and the name-based detector used for PPV always-live channels).
LIVETV_ALLOWED_COUNTRIES = {"us", "uk", "ca", "au", "za"}
LIVETV_COUNTRY_NAMES = {
    "us": "United States",
    "uk": "United Kingdom",
    "ca": "Canada",
    "au": "Australia",
    "za": "South Africa",
}
_LIVETV_HLS_TOKEN = "https://ondemand.st/papi/hls-token"
_LIVETV_TV_LIST = "https://ondemand.st/papi/tv-list"


def _is_valid_m3u8_url(url: str) -> bool:
    if not url or not url.startswith("http"):
        return False
    if any(c in url for c in " \t\n\r(){}[];"):
        return False
    if url.count("://") != 1:
        return False
    parsed = urlparse(url)
    if not parsed.netloc or "." not in parsed.netloc:
        return False
    # Path only: `player/jw/?url=%2Fc%2F4.m3u8` has .m3u8 in the query but
    # is an HTML player page (inputstream then fails "Cannot detect manifest").
    return ".m3u8" in parsed.path


def _detect_channel_country(name: str) -> str:
    n = (name or "").lower()
    if re.search(r"\bfox (footy|league|cricket|sports)|kayo|channel 7|channel 9|\bafl\b|\bnrl\b", n):
        return "au"
    if re.search(r"sky sports|tnt sport|\bbbc\b|\bitv\b|premier sports", n):
        return "uk"
    if re.search(r"nfl|nba|mlb|nhl|espn|fox sports [12]|willow|cbs|nbc|usa|south park|family guy|simpsons|tennis channel", n):
        return "us"
    return "intl"

class OnDemand(JetExtractor):
    def __init__(self) -> None:
        self.domains = ["ondemand.st", "damitv.st", "messi.damitv.st"]
        self.name = "OnDemand"
        self.short_name = "OD"
        self.api_url = "https://ondemand.st/papi/api/streams"
        self.extract_url_api = "https://ondemand.st/papi/extract-url"
        self.base_url = "https://ondemand.st"
        self._cache: List[dict] = []
        self._cache_time: float = 0.0
        self._cache_duration: int = 120
        self._ltv_cache: List[Dict[str, Any]] = []
        self._ltv_cache_time: float = 0.0

    def _normalize_iframe_url(self, iframe: str) -> str:
        if not iframe:
            return iframe
        if iframe.startswith("//"):
            return "https:" + iframe
        if not iframe.startswith("http"):
            if iframe.startswith("/"):
                return f"https://messi.damitv.st{iframe}"
            return f"https://messi.damitv.st/{iframe}"
        if "damitv.st" in iframe and "messi.damitv.st" not in iframe:
            iframe = iframe.replace("damitv.st", "messi.damitv.st")
        return iframe

    def _build_resolver_url(self, iframe_url: str) -> str:
        return f"{self.base_url}/jetextractor/embed?url={quote(iframe_url, safe='')}"

    def _fetch_streams(self) -> List[dict]:
        now = time.time()
        if self._cache and (now - self._cache_time) < self._cache_duration:
            debug_log(f"[OnDemand] Using cached data", xbmc.LOGINFO)
            return self._cache

        try:
            data = fetch_json(self.api_url)
            if data is None:
                debug_log("[OnDemand] API returned no data", xbmc.LOGWARNING)
                return []
            if not data.get("success"):
                debug_log("[OnDemand] API indicated failure", xbmc.LOGWARNING)
                return []
            streams = data.get("streams", [])
            self._cache = streams
            self._cache_time = now
            debug_log(f"[OnDemand] Fetched {len(streams)} categories", xbmc.LOGINFO)
            return streams
        except Exception as e:
            debug_log(f"[OnDemand] Fetch failed: {e}", xbmc.LOGWARNING)
            return []

    def _get_category_label(self, category: str) -> str:
        category_map = {
            "football": "Soccer",
            "basketball": "NBA",
            "american-football": "NFL",
            "baseball": "MLB",
            "hockey": "NHL",
            "combat": "MMA / Boxing",
            "golf": "Golf",
            "tennis": "Tennis",
        }
        return category_map.get(category.lower(), category.upper())

    def _get_status(self, starts_at: int, ends_at: int) -> Optional[str]:
        now = time.time()
        if starts_at:
            if now < starts_at:
                return "Upcoming"
            elif ends_at and now > ends_at:
                return "Ended"
        return "LIVE"

    def _extract_stream_id(self, iframe_url: str) -> Optional[str]:
        parsed = urlparse(iframe_url)
        params = parse_qs(parsed.query)
        stream_id = params.get("id", [None])[0]
        if stream_id:
            return unquote(stream_id)
        if parsed.path.startswith("/embed/"):
            parts = parsed.path.replace("/embed/", "").split("/")
            return "/".join(parts) if parts[0] else None
        return None

    def _is_dlhd(self, url: str) -> bool:
        if not url:
            return False
        parsed = urlparse(url)
        params = parse_qs(parsed.query)
        sid = params.get("id", [""])[0]
        return unquote(sid).startswith("dlhd-")

    def _try_extract_api(self, stream_id: str) -> Optional[dict]:
        api_endpoint = f"{self.extract_url_api}/{stream_id}"
        
        try:
            headers = get_headers(referer="https://ondemand.st/", origin="https://ondemand.st/")
            resp = get_session().get(api_endpoint, headers=headers, timeout=self.timeout)
            
            if resp.status_code == 200:
                data = resp.json()
                return data
            
            elif resp.status_code == 404 or "no sources" in resp.text.lower():
                debug_log(f"[OnDemand] No sources for stream: {stream_id}", xbmc.LOGWARNING)
        except Exception as e:
            debug_log(f"[OnDemand] Extract API failed: {e}", xbmc.LOGWARNING)
        
        return None

    def _fetch_livetv_channels(self) -> List[Dict[str, Any]]:
        now = time.time()
        if self._ltv_cache and (now - self._ltv_cache_time) < self._cache_duration:
            return self._ltv_cache

        channels: List[Dict[str, Any]] = []
        seen_names = set()

        def _norm(n: str) -> str:
            return re.sub(r"\s*\(.*?\)\s*", " ", (n or "")).lower().strip()

        def _abs_url(u: str) -> str:
            if u.startswith("/"):
                return self.base_url + u
            return u

        # 1) Country channels from /papi/tv-list. Each row carries an explicit
        #    `country` code (us/uk/ca/au/za/…). These play via /dl/<id>.m3u8
        #    with the short-lived /papi/hls-token (kind=dlhd).
        try:
            data = fetch_json(_LIVETV_TV_LIST, referer=f"{self.base_url}/livetv")
            for c in (data or {}).get("channels") or []:
                if not isinstance(c, dict) or not c.get("id") or not c.get("name"):
                    continue
                cc = str(c.get("country") or "").lower()
                if cc not in LIVETV_ALLOWED_COUNTRIES:
                    continue
                key = _norm(c["name"])
                if key in seen_names:
                    continue
                seen_names.add(key)
                channels.append({
                    "kind": "dlhd",
                    "id": str(c["id"]),
                    "name": str(c["name"]).strip(),
                    "country": cc,
                    "image": _abs_url(c.get("image") or "") or None,
                })
        except Exception as e:
            debug_log(f"[OnDemand] LiveTV tv-list fetch failed: {e}", xbmc.LOGWARNING)

        # 2) 24/7 always-live channels (the site also lists these on /livetv).
        #    They resolve via /livetv/ppv/<id> -> /papi/extract-url/<id>
        #    (kind=ppv); country is inferred from the channel name.
        for category in self._fetch_streams() or []:
            if not isinstance(category, dict) or str(category.get("category", "")).lower() != "24/7-streams":
                continue
            for s in category.get("streams") or []:
                if not isinstance(s, dict) or not s.get("id") or not s.get("name"):
                    continue
                name = re.sub(r"^24/7\s*", "", str(s.get("name", "") or ""), flags=re.I)
                name = re.sub(r"^[A-Z]{2}\s*\|\s*", "", name).strip() or "Channel"
                cc = _detect_channel_country(name)
                if cc not in LIVETV_ALLOWED_COUNTRIES:
                    continue
                key = _norm(name)
                if key in seen_names:
                    continue
                seen_names.add(key)
                channels.append({
                    "kind": "ppv",
                    "id": str(s["id"]),
                    "name": name,
                    "country": cc,
                    "image": _abs_url(s.get("poster") or "") or None,
                })

        debug_log(f"[OnDemand] LiveTV channels kept: {len(channels)}", xbmc.LOGINFO)
        self._ltv_cache = channels
        self._ltv_cache_time = now
        return channels

    def _mint_hls_token(self, referer: Optional[str] = None) -> Optional[Dict[str, Any]]:
        try:
            data = fetch_json(_LIVETV_HLS_TOKEN, referer=referer or f"{self.base_url}/livetv")
            if isinstance(data, dict) and data.get("tk"):
                return data
        except Exception as e:
            debug_log(f"[OnDemand] hls-token failed: {e}", xbmc.LOGWARNING)
        return None

    def _resolve_dlhd_channel(self, channel_id: str, name: str) -> Optional[JetLink]:
        token = self._mint_hls_token()
        if not token:
            debug_log(f"[OnDemand] No hls-token for dlhd-{channel_id}", xbmc.LOGWARNING)
            return None
        m3u8_url = f"{self.base_url}/dl/{channel_id}.m3u8?tk={quote(str(token['tk']))}&e={token.get('e', '')}"
        headers = {
            "User-Agent": _TV_UA,
            "Referer": f"{self.base_url}/livetv",
            "Origin": self.base_url,
        }

        def _refresh() -> Optional[dict]:
            t = self._mint_hls_token()
            if not t:
                return None
            return {
                "url": f"{self.base_url}/dl/{channel_id}.m3u8?tk={quote(str(t['tk']))}&e={t.get('e', '')}",
                "headers": headers,
            }

        try:
            proxy = get_stream_proxy(
                "ondemand",
                headers,
                options={"cache_manifest": False, "keep_alive": True, "strip_png": True, "segment_strip_origin": True, "upstream_keep_alive": True, "prefetch_segments": True},
            )
            proxy_url = proxy.get_proxy_url(m3u8_url, headers, refresh_callback=_refresh)
            debug_log(f"[OnDemand] DLHD proxy ({name}): {proxy_url[:120]}", xbmc.LOGINFO)
            return JetLink(
                address=proxy_url,
                name=name,
                inputstream=JetInputstreamFFmpegDirect(manifest_type="hls", is_realtime_stream=True, stream_mode="live"),
            )
        except Exception as e:
            debug_log(f"[OnDemand] DLHD proxy failed for {name}: {e}", xbmc.LOGWARNING)
            return None

    def _livetv_link_url(self, ch: Dict[str, Any]) -> str:
        if ch.get("kind") == "dlhd":
            return f"{self.base_url}/livetv/dlhd/{ch['id']}"
        return f"{self.base_url}/livetv/ppv/{quote(str(ch['id']), safe='')}"

    def get_items(self, params: Optional[dict] = None, progress: Optional[JetExtractorProgress] = None) -> List[JetItem]:
        items: List[JetItem] = []
        if self.progress_init(progress, items):
            return items

        categories = self._fetch_streams()

        for category in categories or []:
            if not isinstance(category, dict):
                continue
            category_name = str(category.get("category", "Events")).strip()
            if category_name.lower() == "24/7-streams":
                continue
            streams = category.get("streams", [])
            if not isinstance(streams, list):
                continue

            for stream in streams:
                if not isinstance(stream, dict):
                    continue
                name = stream.get("name", "Stream").strip()
                poster = stream.get("poster")
                iframe_url = self._normalize_iframe_url(stream.get("embed") or stream.get("iframe"))
                if not iframe_url:
                    continue

                sources = stream.get("sources", [])
                if isinstance(sources, list):
                    sources = [s for s in sources if isinstance(s, dict) and not self._is_dlhd(s.get("embed", ""))]

                starts_at = stream.get("starts_at", 0)
                ends_at = stream.get("ends_at", 0)
                if not isinstance(starts_at, (int, float)):
                    starts_at = 0
                if not isinstance(ends_at, (int, float)):
                    ends_at = 0

                api_status = str(stream.get("status") or "").lower()
                if api_status in ("live", "upcoming", "ended", "finished"):
                    status = {"live": "LIVE", "upcoming": "Upcoming", "ended": "Ended", "finished": "Ended"}[api_status]
                else:
                    status = self._get_status(starts_at, ends_at)
                league = stream.get("league") or category_name
                if league:
                    league = self._get_category_label(str(league))

                title = name
                if status:
                    title = f"[{status}] {name}"

                resolver_url = self._build_resolver_url(iframe_url)
                links = [JetLink(resolver_url, links=True, name=f"Main")]

                if isinstance(sources, list):
                    for source in sources:
                        if isinstance(source, dict):
                            source_embed = self._normalize_iframe_url(source.get("embed"))
                            source_name = source.get("name", "Source")
                            if source_embed and source_embed != iframe_url:
                                source_resolver = self._build_resolver_url(source_embed)
                                links.append(
                                    JetLink(source_resolver, links=True, name=source_name)
                                )

                item = JetItem(
                    title=title,
                    league=league,
                    links=links,
                    icon=poster if poster else None,
                )
                items.append(item)

        for ch in self._fetch_livetv_channels():
            cc = ch.get("country", "intl")
            country_label = LIVETV_COUNTRY_NAMES.get(cc, cc.upper())
            link_url = self._livetv_link_url(ch)
            items.append(JetItem(
                title=ch.get("name", "Channel"),
                league=f"Live TV - {country_label}",
                links=[JetLink(link_url, links=True, name="Main")],
                icon=ch.get("image"),
            ))

        debug_log(f"[OnDemand] Total items: {len(items)}", xbmc.LOGINFO)
        return items

    def _proxy_m3u8(self, m3u8_url: str, name: str, referer: str = None, origin: str = None) -> Optional[JetLink]:
        try:
            headers = {
                "User-Agent": _TV_UA,
            }
            if referer:
                headers["Referer"] = referer
            if origin:
                headers["Origin"] = origin
            proxy = get_stream_proxy("ondemand", headers, options={"cache_manifest": False, "keep_alive": True, "strip_png": True, "upstream_keep_alive": True, "prefetch_segments": True})
            proxy_url = proxy.get_proxy_url(m3u8_url, headers)
            debug_log(f"[OnDemand] Proxy URL ({name}): {proxy_url[:120]}", xbmc.LOGINFO)
            return JetLink(
                address=proxy_url,
                name=name,
                inputstream=JetInputstreamFFmpegDirect(manifest_type="hls", is_realtime_stream=True, stream_mode="live"),
            )
        except Exception as e:
            debug_log(f"[OnDemand] Proxy failed for {name}: {e}", xbmc.LOGWARNING)
            return None

    def _decode_enc(self, value: Any) -> Optional[str]:
        """extract-url returns some URLs as `enc:<b64>` (base64 + reversed
        plaintext, e.g. enc:OHUzbS4uLi06c3B0dGg= -> https://...m3u8)."""
        if not isinstance(value, str) or not value:
            return None
        if not value.startswith("enc:"):
            return value
        try:
            raw = base64.b64decode(value[4:]).decode("utf-8", "ignore")
            return raw[::-1].strip() or None
        except Exception:
            return None

    def _resolve_embedst(self, embed_url: str, name: str) -> Optional[JetLink]:
        try:
            from ..util import taifood_mint
            if taifood_mint.is_taifood_url(embed_url):
                return self._resolve_taifood(embed_url, name)
        except Exception as e:
            debug_log(f"[OnDemand] taifood import/route failed for {name}: {e}", xbmc.LOGWARNING)
        try:
            from ..util import embedsportstop
            stream_url = embedsportstop.get_embedsportstop_stream(embed_url)
            if stream_url and stream_url.startswith("http"):
                debug_log(f"[OnDemand] Resolved {name} via embedsportstop: {stream_url[:80]}", xbmc.LOGINFO)
                link = self._proxy_m3u8(stream_url, name, referer="https://embed.st/", origin="https://embed.st")
                if link:
                    return link
                return JetLink(
                    address=stream_url,
                    name=name,
                    inputstream=JetInputstreamFFmpegDirect(manifest_type="hls", is_realtime_stream=True, stream_mode="live"),
                )
        except Exception as e:
            debug_log(f"[OnDemand] embedsportstop resolution failed for {name}: {e}", xbmc.LOGWARNING)
        return None

    def _resolve_taifood(self, iframe_url: str, name: str) -> Optional[JetLink]:
        """Mint a fresh indianservers playlist for a taifood embed (same
        issuer/embed flow as embedsport2); re-mint on proxy refresh."""
        try:
            from ..util import taifood_mint
        except Exception as e:
            debug_log(f"[OnDemand] taifood_mint unavailable for {name}: {e}", xbmc.LOGWARNING)
            return None

        uri_name = taifood_mint.uri_name_from_iframe(iframe_url)
        if not uri_name:
            debug_log(f"[OnDemand] No /embed/ path in taifood URL: {iframe_url}", xbmc.LOGWARNING)
            return None

        def _refresh_callback():
            fresh = taifood_mint.mint(uri_name)
            if not fresh:
                return None
            return {"url": fresh, "headers": taifood_mint.stream_headers()}

        stream_url = taifood_mint.mint(uri_name)
        if stream_url and not taifood_mint.verify_m3u8(stream_url):
            debug_log(f"[OnDemand] Mint verify failed for {uri_name}, re-minting once", xbmc.LOGWARNING)
            stream_url = taifood_mint.mint(uri_name)
        if not stream_url or not taifood_mint.verify_m3u8(stream_url):
            debug_log(f"[OnDemand] Failed to mint playable stream for {uri_name}", xbmc.LOGWARNING)
            return None

        headers = taifood_mint.stream_headers()
        proxy = get_stream_proxy(
            "ondemand",
            headers,
            options={
                "cache_manifest": False,
                "proxy_absolute_urls": True,
                "strip_png": True,
                "user_agent": taifood_mint.STREAMED_TV_UA,
                "upstream_keep_alive": True,
                "prefetch_segments": True,
                "prefetch_depth": 3,
                "keep_alive": False,
            },
        )
        proxy_url = proxy.get_proxy_url(stream_url, headers, refresh_callback=_refresh_callback)
        debug_log(f"[OnDemand] Taifood mint OK for {uri_name}: {stream_url[:100]}", xbmc.LOGINFO)
        return JetLink(
            address=proxy_url,
            name=name,
            inputstream=taifood_mint.ffmpegdirect_live(),
            resolveurl=False,
        )

    def _resolve_jw_player(self, jw_url: str, name: str) -> Optional[JetLink]:
        """`/player/jw/?url=<playlist>&name=<label>` sources.

        The jw page is a JS shim that just redirects to the obfuscated
        `/player/hls/` player, so resolve the `url` param directly:
        - `enc:<b64>`  -> decoded absolute playlist (admin2.formaturamaxi…)
        - `/c/N.m3u8`  -> playlist gated by a short-lived `/papi/hls-token`
          (same token scheme as DLHD `/dl/`). The playlist is usually on the
          `messi.` CDN host while the player page is on `damitv.st`, so the
          token applies to any damitv-CDN playlist path (`/c/`, `/alfa/`).
          Segments are TikTok-CDN PNG-wrapped TS -> strip_png + refresh
          re-mint; cross-origin segments need their Origin/Referer stripped
          (`segment_strip_origin`).
        """
        try:
            parsed = urlparse(jw_url)
            origin = f"{parsed.scheme}://{parsed.netloc}"
            target = (parse_qs(parsed.query).get("url", [""])[0] or "").strip()
            if not target:
                return None
            label = (parse_qs(parsed.query).get("name", [""])[0] or "").strip() or name or "Source"

            if target.startswith("enc:"):
                target = self._decode_enc(target) or ""
            if not target.startswith("http"):
                if target.startswith("/"):
                    target = origin + target
                elif target.startswith("//"):
                    target = "https:" + target
                else:
                    target = f"{origin}/{target}"
            if not _is_valid_m3u8_url(target):
                debug_log(f"[OnDemand] jw source not a playlist: {target[:80]}", xbmc.LOGWARNING)
                return None

            parsed_target = urlparse(target)
            target_origin = f"{parsed_target.scheme}://{parsed_target.netloc}"
            # Token-gated CDN playlists live on the damitv host family
            # (damitv.st / messi.damitv.st), which is NOT the player page host.
            # Gate by CDN host + playlist path prefix, not the page host.
            is_damitv_cdn = parsed_target.netloc == "damitv.st" or parsed_target.netloc.endswith(".damitv.st")
            is_gated_path = parsed_target.path.startswith("/c/") or parsed_target.path.startswith("/alfa/")
            if is_damitv_cdn and is_gated_path:
                player_referer = f"{target_origin}/player/hls/"
                token = self._mint_hls_token(referer=player_referer)
                if not token:
                    debug_log(f"[OnDemand] No hls-token for jw channel {target}", xbmc.LOGWARNING)
                    return None
                sep = "&" if "?" in target else "?"
                m3u8_url = f"{target}{sep}tk={quote(str(token['tk']))}&e={token.get('e', '')}"
                headers = {"User-Agent": _TV_UA, "Referer": player_referer, "Origin": target_origin}

                def _refresh() -> Optional[dict]:
                    t = self._mint_hls_token(referer=player_referer)
                    if not t:
                        return None
                    return {
                        "url": f"{target}{sep}tk={quote(str(t['tk']))}&e={t.get('e', '')}",
                        "headers": headers,
                    }
            else:
                m3u8_url = target
                headers = {"User-Agent": _TV_UA, "Referer": target_origin + "/", "Origin": target_origin}

                def _refresh() -> Optional[dict]:
                    return {"url": m3u8_url, "headers": headers}

            proxy = get_stream_proxy(
                "ondemand",
                headers,
                options={"cache_manifest": False, "keep_alive": True, "strip_png": True, "segment_strip_origin": True, "upstream_keep_alive": True, "prefetch_segments": True},
            )
            proxy_url = proxy.get_proxy_url(m3u8_url, headers, refresh_callback=_refresh)
            debug_log(f"[OnDemand] jw source ({label}): {proxy_url[:120]}", xbmc.LOGINFO)
            return JetLink(
                address=proxy_url,
                name=label,
                inputstream=JetInputstreamFFmpegDirect(manifest_type="hls", is_realtime_stream=True, stream_mode="live"),
            )
        except Exception as e:
            debug_log(f"[OnDemand] jw source resolve failed for {name}: {e}", xbmc.LOGWARNING)
            return None

    def _find_event_by_stream_id(self, stream_id: str) -> Optional[dict]:
        """Locate the API event row for an embed stream id (m401909905 …)
        so its `sources[]` can be used when extract-url reports no sources."""
        needle = f"id={stream_id}"
        for category in self._fetch_streams() or []:
            if not isinstance(category, dict):
                continue
            for s in category.get("streams") or []:
                if not isinstance(s, dict):
                    continue
                if s.get("id") == stream_id or needle in str(s.get("embed") or ""):
                    return s
                for src in s.get("sources") or []:
                    if isinstance(src, dict) and needle in str(src.get("embed") or ""):
                        return s
        return None

    def _event_source_links(self, event: dict, skip_embed: Optional[str] = None) -> List[JetLink]:
        """Resolve an event's own sources[] (jw channel players, embeds)."""
        links: List[JetLink] = []
        for src in event.get("sources") or []:
            if not isinstance(src, dict):
                continue
            emb = self._normalize_iframe_url(src.get("embed"))
            if not emb or emb == skip_embed:
                continue
            src_name = str(src.get("name") or "Source").strip()
            if "/player/jw/" in urlparse(emb).path or "/player/hls/" in urlparse(emb).path:
                link = self._resolve_jw_player(emb, src_name)
                if link:
                    links.append(link)
                    continue
            if "/embed/" in urlparse(emb).path:
                resolved = self._resolve_embedst(emb, src_name)
                if resolved:
                    links.append(resolved)
                    continue
            links.append(JetLink(emb, name=src_name, resolveurl=True))
        return links

    def get_links(self, url: JetLink) -> List[JetLink]:
        links: List[JetLink] = []
        url_address = url.address

        parsed = urlparse(url_address)

        if "ondemand.st" in parsed.netloc and parsed.path.startswith("/livetv/dlhd/"):
            channel_id = parsed.path.rstrip("/").split("/")[-1]
            if re.fullmatch(r"[a-zA-Z0-9_-]+", channel_id or ""):
                link = self._resolve_dlhd_channel(channel_id, f"DLHD {channel_id}")
                if link:
                    links.append(link)
            return links

        if "ondemand.st" in parsed.netloc and parsed.path.startswith("/livetv/ppv/"):
            stream_id = unquote(parsed.path.rstrip("/").split("/")[-1])
            if not stream_id:
                return links
            iframe_url = f"https://messi.damitv.st/embed/?id={quote(stream_id, safe='')}"
        else:
            is_resolver = "/jetextractor/embed" in url_address
            is_embed = ("damitv.st" in parsed.netloc or "messi.damitv.st" in parsed.netloc or "embedindia.st" in parsed.netloc) and ("/embed/" in parsed.path or parsed.path == "/embed")
            is_player = ("damitv.st" in parsed.netloc or "messi.damitv.st" in parsed.netloc) and parsed.path.startswith("/player/")
            is_watch_page = "ondemand.st" in parsed.netloc and "/watch/" in parsed.path

            if not (is_resolver or is_embed or is_watch_page or is_player):
                return links

            if is_resolver:
                params = parse_qs(parsed.query)
                iframe_url = params.get("url", [None])[0]
            else:
                iframe_url = url_address

        if not iframe_url:
            return links

        iframe_url = self._normalize_iframe_url(iframe_url)

        _iframe_path = urlparse(iframe_url).path
        if _iframe_path.startswith("/player/jw/") or _iframe_path.startswith("/player/hls/"):
            _pname = parse_qs(urlparse(iframe_url).query).get("name", [""])[0] or "Source"
            link = self._resolve_jw_player(iframe_url, _pname)
            if link:
                links.append(link)
            return links

        try:
            stream_id = self._extract_stream_id(iframe_url)
            
            if stream_id:
                api_data = self._try_extract_api(stream_id)
                if api_data:
                    embed_referrer = f"https://messi.damitv.st/embed/?id={stream_id}"

                    hls_url = self._decode_enc(api_data.get("hlsUrl"))
                    if hls_url and isinstance(hls_url, str) and hls_url.startswith(("http://", "https://")) and ".m3u8" in hls_url:
                        debug_log(f"[OnDemand] Found m3u8 via API: {hls_url[:80]}", xbmc.LOGINFO)
                        link = self._proxy_m3u8(hls_url, "HD", referer=embed_referrer, origin="https://messi.damitv.st")
                        if link:
                            links.append(link)
                        else:
                            links.append(JetLink(
                                hls_url,
                                name="HD",
                                headers=get_headers(referer=embed_referrer, origin="https://messi.damitv.st"),
                                inputstream=JetInputstreamAdaptive.hls(),
                            ))

                    sd_url = self._decode_enc(api_data.get("sdUrl"))
                    if sd_url and isinstance(sd_url, str) and sd_url.startswith(("http://", "https://")) and ".m3u8" in sd_url and sd_url != hls_url:
                        debug_log(f"[OnDemand] Found SD m3u8: {sd_url[:80]}", xbmc.LOGINFO)
                        link = self._proxy_m3u8(sd_url, "SD", referer=embed_referrer, origin="https://messi.damitv.st")
                        if link:
                            links.append(link)
                        else:
                            links.append(JetLink(
                                sd_url,
                                name="SD",
                                headers=get_headers(referer=embed_referrer, origin="https://messi.damitv.st"),
                                inputstream=JetInputstreamAdaptive.hls(),
                            ))

                    # sdStreams + hdStreams: named alternates, URLs may be
                    # plain http or enc:<b64-reversed>.
                    for stream_list in (api_data.get("sdStreams", []), api_data.get("hdStreams", [])):
                        if not isinstance(stream_list, list):
                            continue
                        for idx, sds in enumerate(stream_list):
                            if not isinstance(sds, dict):
                                continue
                            sds_url = self._decode_enc(sds.get("url"))
                            sds_name = sds.get("name") or f"Source {idx + 1}"
                            sds_hd = sds.get("hd", False)
                            if not sds_url or not isinstance(sds_url, str):
                                continue
                            if not sds_url.startswith("http"):
                                sds_url = "https:" + sds_url if sds_url.startswith("//") else f"https://{sds_url}"
                            label = f"{sds_name} (HD)" if sds_hd else sds_name
                            if ".m3u8" in sds_url:
                                debug_log(f"[OnDemand] Resolving named stream: {label} -> {sds_url[:80]}", xbmc.LOGINFO)
                                link = self._proxy_m3u8(sds_url, label, referer=embed_referrer, origin="https://messi.damitv.st")
                                if link:
                                    links.append(link)
                                    continue
                            resolved = self._resolve_embedst(sds_url, label)
                            if resolved:
                                links.append(resolved)
                            else:
                                links.append(JetLink(sds_url, name=label, resolveurl=True))

                    # substreams: direct embed iframes (taifood / pooembed / ...)
                    substreams = api_data.get("substreams", [])
                    if isinstance(substreams, list):
                        for idx, sub in enumerate(substreams):
                            if not isinstance(sub, dict):
                                continue
                            sub_url = self._decode_enc(sub.get("iframe") or sub.get("url"))
                            if not sub_url or not isinstance(sub_url, str) or not sub_url.startswith("http"):
                                continue
                            sub_name = str(sub.get("name") or sub.get("tag") or f"Sub {idx + 1}").strip()
                            debug_log(f"[OnDemand] Resolving substream: {sub_name} -> {sub_url[:80]}", xbmc.LOGINFO)
                            resolved = self._resolve_embedst(sub_url, sub_name)
                            if resolved:
                                links.append(resolved)
                            else:
                                links.append(JetLink(sub_url, name=sub_name, resolveurl=True))

                    embed_url = self._decode_enc(api_data.get("embedUrl"))
                    if embed_url and isinstance(embed_url, str) and embed_url.startswith("http"):
                        debug_log(f"[OnDemand] Resolving embed: {embed_url[:80]}", xbmc.LOGINFO)
                        resolved = self._resolve_embedst(embed_url, "Embed")
                        if resolved:
                            links.append(resolved)
                        else:
                            links.append(JetLink(embed_url, name="Embed", resolveurl=True))

                    if links:
                        return links

                # extract-url can report {"success":false,"error":"no sources"}
                # for live events - fall back to the event's own sources[]
                # from /papi/api/streams (jw channel players, embeds).
                event = self._find_event_by_stream_id(stream_id)
                if event:
                    debug_log(f"[OnDemand] extract-url empty for {stream_id}, trying event sources[]", xbmc.LOGINFO)
                    links.extend(self._event_source_links(event, skip_embed=iframe_url))
                if links:
                    return links

                debug_log(f"[OnDemand] No m3u8 for stream_id={stream_id}, skipping", xbmc.LOGINFO)
                return links

            html = ""
            _parsed_iframe = urlparse(iframe_url)
            _iframe_origin = f"{_parsed_iframe.scheme}://{_parsed_iframe.netloc}"
            session = get_session(referer=iframe_url, origin=_iframe_origin)
            resp = session.get(iframe_url, timeout=self.timeout, allow_redirects=True)
            if resp.status_code != 200:
                debug_log(f"[OnDemand] Embed page returned {resp.status_code}", xbmc.LOGWARNING)
                return links

            html = resp.text
            final_url = resp.url
            if ".m3u8" in final_url and _is_valid_m3u8_url(final_url):
                debug_log(f"[OnDemand] Found m3u8 via redirect: {final_url[:80]}", xbmc.LOGINFO)
                links.append(JetLink(
                    final_url,
                    inputstream=JetInputstreamAdaptive.hls(),
                ))
                return links

            m3u8_url = find_m3u8(html, final_url)
            if m3u8_url and _is_valid_m3u8_url(m3u8_url):
                _parsed_final = urlparse(final_url)
                _final_origin = f"{_parsed_final.scheme}://{_parsed_final.netloc}"
                debug_log(f"[OnDemand] Found m3u8 in HTML: {m3u8_url[:80]}", xbmc.LOGINFO)
                links.append(JetLink(
                    m3u8_url,
                    headers=get_headers(referer=final_url, origin=_final_origin),
                    inputstream=JetInputstreamAdaptive.hls(),
                ))
                return links

            iframes = find_iframes(html, final_url)
            for iframe_src in iframes[:2]:
                if "javascript:" not in iframe_src:
                    links.append(JetLink(iframe_src, resolveurl=True))

        except Exception as e:
            debug_log(f"[OnDemand] get_links failed: {e}", xbmc.LOGWARNING)

        return links

    def get_link(self, url: JetLink) -> JetLink:
        links = self.get_links(url)
        if links:
            return links[0]
        return JetLink(url.address)