"""Extractor implementations; importing this package requires an authorized consumer."""

# These modules are also imported directly by several consumer addons, bypassing
# extractor.get_extractors(). Enforce the same whitelist before loading them.
from ..config import get_config as _get_authorized_config
_get_authorized_config()
del _get_authorized_config

import os
import importlib
import traceback
import xbmc
from ..tools import debug_log

package_dir = os.path.dirname(__file__)
__all__ = []
for filename in os.listdir(package_dir):
    if filename.endswith(".py") and not filename.startswith("__"):
        __all__.append(filename[:-3])

for module in __all__:
    try:
        importlib.import_module(f".{module}", package=__name__)
    except ImportError:
        debug_log(
            f"Warning: Could not import {module}\n{traceback.format_exc()}",
            xbmc.LOGERROR,
        )
        xbmc.log(f"[JetExtractors] Import failed: {module}\n{traceback.format_exc()}", xbmc.LOGERROR)
    except Exception:
        debug_log(
            f"Error while importing {module}\n{traceback.format_exc()}",
            xbmc.LOGERROR,
        )
        xbmc.log(f"[JetExtractors] Import error: {module}\n{traceback.format_exc()}", xbmc.LOGERROR)
