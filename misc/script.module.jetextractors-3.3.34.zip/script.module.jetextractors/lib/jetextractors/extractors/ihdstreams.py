import re
import json
import math
import base64
import xbmc
from datetime import datetime
from urllib.parse import urlparse, parse_qs, urlencode, urlunparse
from ..models import *
from .._core import fetch_page, get_session
from ..icons import icons
from ..util.resolver import UniversalResolver
from ..util.stream_proxy import get_stream_proxy
from ..tools import debug_log

SPORTS = ["NFL", "NBA", "UFC", "Boxing", "NHL", "MLB", "WWE", "F1", "NCAAB", "CFB", "WNBA", "Soccer"]
LEAGUE_ICONS = {
    "NFL": "nfl", "NBA": "nba", "UFC": "mma", "Boxing": "boxing", "NHL": "nhl",
    "MLB": "mlb", "WWE": "wwe", "F1": "f1", "NCAAB": "ncaa men", "CFB": "cfb",
    "WNBA": "wnba", "Soccer": "soccer",
}


class IHDStreams(JetExtractor):
    def __init__(self) -> None:
        self.domains = ["ihdstreams.top", "www.ihdstreams.top"]
        self.name = "iHDStreams"
        self.short_name = "IHD"
        self.resolver = UniversalResolver(self.user_agent, "[iHDStreams]")

    def _decode_url(self, raw: str, key: str) -> str:
        d = base64.b64decode(raw + "=" * (-len(raw) % 4))
        xd = bytes(b ^ ord(key[i % len(key)]) for i, b in enumerate(d))
        half = len(xd) // 2
        p1 = base64.b64encode(xd[:half])
        p2 = base64.b64encode(xd[half:])
        j = base64.b64decode(p1 + b"==") + base64.b64decode(p2 + b"==")
        u = bytes(b ^ ord(key[i % len(key)]) for i, b in enumerate(j))
        return u.decode()

    def get_items(self, params: Optional[dict] = None, progress: Optional[JetExtractorProgress] = None) -> List[JetItem]:
        items = []
        if self.progress_init(progress, items):
            return items
        params = params or {}
        sports = [params["league"]] if params.get("league") else SPORTS
        for idx, sport in enumerate(sports):
            if progress is not None and self.progress_update(progress, f"Fetching {sport} ({idx + 1}/{len(sports)})..."):
                return items
            try:
                html = fetch_page(f"https://{self.domains[0]}/index.php?sport={sport}", referer=f"https://{self.domains[0]}/")
            except Exception:
                continue
            if not html:
                continue
            league = sport.upper()
            for block in re.findall(r'<article class="game-card[^"]*"(.*?)</article>', html, re.S):
                href_m = re.search(r'href="(?:https?://[^"/]+)?/?watch/([^"]+)"', block)
                name_m = re.search(r'itemprop="name" content="([^"]+)"', block)
                if not href_m or not name_m:
                    continue
                title = " ".join(name_m.group(1).split())
                live = 'class="game-card is-live"' in block or "LIVE NOW" in block
                starttime = None
                ts_m = re.search(r'data-event-time="(\d+)"', block)
                if ts_m:
                    try:
                        starttime = datetime.fromtimestamp(int(ts_m.group(1)) / 1000.0)
                    except Exception:
                        starttime = None
                icon_key = LEAGUE_ICONS.get(league, "")
                items.append(JetItem(
                    title,
                    [JetLink(f"https://{self.domains[0]}/watch/{href_m.group(1)}", links=True)],
                    starttime,
                    status="LIVE" if live else None,
                    league=league,
                    icon=icons[icon_key] if icon_key in icons else None,
                ))
        return items

    def get_links(self, event_url) -> List[JetLink]:
        if isinstance(event_url, JetLink):
            event_url = event_url.address
        if "ihdstreams.top" not in event_url:
            return []
        return [JetLink(event_url, name="Stream", headers={"Referer": f"https://{self.domains[0]}/"}, resolveurl=True, extractor=self.name)]

    @staticmethod
    def _grant_url(page_url: str) -> str:
        parsed = urlparse(page_url)
        qs = parse_qs(parsed.query)
        qs["grant"] = ["1"]
        query = urlencode({k: v[0] for k, v in qs.items()}, doseq=True)
        return urlunparse(parsed._replace(query=query))

    def _edgestream_proxy(self, page_url: str, stream_url: str) -> Optional[str]:
        """Serve edgestream HLS through StreamProxy.

        edgestream does not serve its advertised playlist URL to normal
        clients (403). The embed page exposes a signed grant JSON instead:
          page?grant=1 -> {"url": "<signed json>"}
          <signed json> -> {"sequence": N, "segments": [{duration, url}]}
        Segments are TikTok-CDN PNG-wrapped MPEG-TS, so the proxy must
        rewrite absolute segment URLs and strip the PNG wrapper.
        """
        grant_url = self._grant_url(page_url)
        parsed_page = urlparse(page_url)
        origin = f"{parsed_page.scheme}://{parsed_page.netloc}"
        headers = {
            "User-Agent": self.user_agent,
            "Referer": page_url,
            "Origin": origin,
            "Accept": "*/*",
        }

        def _decode(body: str, _url: str) -> str:
            if not body:
                return ""
            # Called again on already-built media playlists (nested pass).
            if body.lstrip().startswith("#EXTM3U"):
                return body
            try:
                data = json.loads(body)
            except Exception:
                return ""
            if not isinstance(data, dict):
                return ""
            if not data.get("segments") and data.get("url"):
                try:
                    resp = get_session().get(data["url"], headers=headers, timeout=12, verify=False)
                    if resp.status_code != 200:
                        debug_log(f"[iHDStreams] grant JSON HTTP {resp.status_code}", xbmc.LOGWARNING)
                        return ""
                    data = resp.json()
                except Exception as e:
                    debug_log(f"[iHDStreams] grant JSON fetch failed: {e}", xbmc.LOGWARNING)
                    return ""
            segments = data.get("segments")
            if not isinstance(segments, list) or not segments:
                return ""
            durations = []
            for seg in segments:
                try:
                    durations.append(float(seg.get("duration") or 0))
                except Exception:
                    pass
            target = max(2, int(math.ceil(max(durations) if durations else 4)))
            try:
                sequence = int(data.get("sequence") or 0)
            except Exception:
                sequence = 0
            lines = [
                "#EXTM3U",
                "#EXT-X-VERSION:3",
                f"#EXT-X-TARGETDURATION:{target}",
                f"#EXT-X-MEDIA-SEQUENCE:{sequence}",
                "#EXT-X-INDEPENDENT-SEGMENTS",
            ]
            for seg in segments:
                seg_url = seg.get("url")
                if not seg_url:
                    continue
                lines.append(f"#EXTINF:{seg.get('duration') or target},")
                lines.append(seg_url)
            return "\n".join(lines) + "\n"

        try:
            proxy = get_stream_proxy(
                "ihdstreams",
                headers,
                options={
                    "strip_png": True,
                    "proxy_absolute_urls": True,
                    "cache_manifest": True,
                    "manifest_ttl": 1.0,
                    "prefetch_segments": True,
                    "prefetch_depth": 2,
                    "upstream_keep_alive": True,
                },
            )
            return proxy.get_proxy_url(grant_url, headers, manifest_decoder=_decode)
        except Exception as e:
            debug_log(f"[iHDStreams] edgestream proxy setup failed: {e}", xbmc.LOGERROR)
            return None

    def get_link(self, url: JetLink) -> JetLink:
        target = url.address if isinstance(url, JetLink) else url
        referer = f"https://{self.domains[0]}/"
        if "ihdstreams.top" not in urlparse(target).netloc:
            return None
        try:
            html = fetch_page(target, referer=referer)
        except Exception:
            return None
        if not html:
            return None
        key_m = re.search(r'_k\s*=\s*"([^"]+)"', html)
        raw_m = re.search(r'_e1\s*=\s*"([^"]+)"', html)
        if not (key_m and raw_m):
            return None
        try:
            embed_path = self._decode_url(raw_m.group(1), key_m.group(1))
        except Exception:
            return None
        if not embed_path:
            return None
        embed_url = embed_path if embed_path.startswith("http") else f"https://{self.domains[0]}{embed_path}"
        try:
            inner = fetch_page(embed_url, referer=target)
        except Exception:
            return None
        if not inner:
            return None
        frame_m = re.search(r'<iframe[^>]+src=["\']([^"\']+)["\']', inner)
        if not frame_m:
            return None
        frame_url = frame_m.group(1)
        if frame_url.startswith("//"):
            frame_url = "https:" + frame_url
        elif frame_url.startswith("/"):
            frame_url = f"https://{self.domains[0]}{frame_url}"
        from ..util.resolver import UniversalResolver
        try:
            stream = self.resolver.resolve_url(frame_url, embed_url)
        except Exception:
            return None
        if not stream:
            return None
        stream_referer = getattr(self.resolver, "stream_referer", None) or embed_url
        if "edgestream" in urlparse(stream).netloc and "hls_co.php" in (stream_referer or ""):
            proxy_url = self._edgestream_proxy(stream_referer, stream)
            if proxy_url:
                debug_log(f"[iHDStreams] edgestream proxied: {proxy_url}", xbmc.LOGINFO)
                return JetLink(proxy_url, inputstream=JetInputstreamFFmpegDirect.default())
            debug_log("[iHDStreams] edgestream proxy failed; falling back to direct stream", xbmc.LOGWARNING)
        headers = {"User-Agent": self.user_agent, "Referer": stream_referer}
        origin = getattr(self.resolver, "stream_origin", None)
        if origin:
            headers["Origin"] = origin
        return JetLink(stream, headers=headers, inputstream=JetInputstreamFFmpegDirect.default())
