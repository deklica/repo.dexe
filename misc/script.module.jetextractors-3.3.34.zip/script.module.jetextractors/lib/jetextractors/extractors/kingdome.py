

import json
import re
from typing import List, Optional, Tuple
from urllib.parse import parse_qs, urlparse

import urllib3
import xbmc

from .._core import fetch_page, get_session
from ..models import (
    JetExtractor,
    JetExtractorProgress,
    JetInputstreamFFmpegDirect,
    JetItem,
    JetLink,
)
from ..tools import debug_log
from ..util.stream_proxy import get_stream_proxy

try:
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
except Exception:
    pass


_SITE_ORIGIN = "https://kingdome.li"
_CATALOG_URL = _SITE_ORIGIN + "/api/matches"
_PLAYLIST_ORIGIN = "https://avalin.sytes.net"
_PLAYER_HOST = "jollydaisy967.ddns.net"

_BROWSER_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
)

_CHANNEL_RE = re.compile(r"^[A-Za-z0-9_-]{1,64}$")
_TOKEN_RE = re.compile(r"^[A-Za-z0-9._~-]{1,128}$")


class Kingdome(JetExtractor):
    """Kingdome.li event listing and direct HLS resolution."""

    def __init__(self) -> None:
        # Register the customer domain, the iframe host and the playlist API:
        # raw links from any of them must dispatch here (see Agents2.md §3.1).
        self.domains = [
            "kingdome.li",
            "www.kingdome.li",
            _PLAYER_HOST,
            "avalin.sytes.net",
            "www.avalin.sytes.net",
        ]
        self.name = "Kingdome"
        self.short_name = "KD"
        self.timeout = 12
        self._proxy = None

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    @staticmethod
    def _headers() -> dict:
        
        return {
            "User-Agent": _BROWSER_UA,
            "Origin": _SITE_ORIGIN,
            "Referer": _SITE_ORIGIN + "/",
            "Accept": "application/vnd.apple.mpegurl,application/json;q=0.9,*/*;q=0.8",
        }

    @staticmethod
    def _channel_from_address(address: str) -> Tuple[Optional[str], Optional[str]]:
        """Return (channel, token) parsed from any supported URL shape."""
        if not isinstance(address, str) or not address:
            return None, None
        try:
            parsed = urlparse(address.strip())
        except Exception:
            return None, None
        if parsed.scheme not in ("http", "https"):
            return None, None

        host = (parsed.hostname or "").lower()
        query = parse_qs(parsed.query or "")
        channel = (query.get("ch") or [None])[0]
        token = (query.get("token") or [None])[0]
        parts = [part for part in parsed.path.split("/") if part]

        if host in ("avalin.sytes.net", "www.avalin.sytes.net"):
            if not channel and parts:
                channel = parts[0]
        elif host == _PLAYER_HOST or host.endswith(".ddns.net"):
            if not channel:
                web = re.search(r"/web/([^/]+)(?:/([^/?#]+))?", parsed.path, re.IGNORECASE)
                if web:
                    channel = "web" + re.sub(r"\D", "", web.group(1))
                    if not token and web.group(2):
                        token = web.group(2)
                elif parts:
                    channel = parts[-1]
                    if channel.lower() == "index.php" and len(parts) > 1:
                        channel = parts[-2]
        elif host in ("kingdome.li", "www.kingdome.li"):
            if not channel:
                match = re.search(
                    r"/(?:new-stream-embed|embed|stream|watch)/([^/?#]+)",
                    parsed.path,
                    re.IGNORECASE,
                )
                if match:
                    channel = match.group(1)
                elif parts:
                    channel = parts[-1]
        else:
            return None, None

        # The player sanitises with /[^A-Za-z0-9_-]/g; mirror that here.
        channel = re.sub(r"[^A-Za-z0-9_-]", "", channel or "")
        if not _CHANNEL_RE.fullmatch(channel):
            return None, None
        if token and not _TOKEN_RE.fullmatch(token):
            token = None
        return channel, token or None

    @staticmethod
    def _playlist_url(channel: str, token: Optional[str] = None) -> str:
        url = f"{_PLAYLIST_ORIGIN}/{channel}"
        if token:
            url += "?token=" + token
        return url

    def _get_proxy(self):
        if self._proxy is None:
            self._proxy = get_stream_proxy(
                "kingdome",
                self._headers(),
                options={
                    # Segments arrive as PNG/WebP-wrapped MPEG-TS (TIKTIKPX,
                    # iTXt payload chunks, WebP) - strip them in the proxy.
                    "strip_png": True,
                    "proxy_absolute_urls": True,
                    # The upstream playlist rotates every ~2s; never serve a
                    # cached copy with expired segment tokens.
                    "cache_manifest": False,
                    "manifest_ttl": 2.0,
                    # Unwrapping a ~2 MB PNG per segment is expensive; keep a
                    # small read-ahead so the decoder never starves.
                    "prefetch_segments": True,
                    "prefetch_depth": 3,
                    "upstream_keep_alive": True,
                    # Origin/Referer are required on the playlist host but
                    # must not leak to the unrelated segment CDNs.
                    "segment_strip_origin": True,
                    "user_agent": _BROWSER_UA,
                },
            )
        return self._proxy

    def _fetch_playlist(self, url: str) -> bool:
        """Check that the playlist host actually has a live HLS feed."""
        try:
            session = get_session(origin=_SITE_ORIGIN, referer=_SITE_ORIGIN + "/")
            response = session.get(
                url,
                headers=self._headers(),
                timeout=(5, self.timeout),
                verify=False,
            )
            body = response.text or ""
            ok = response.status_code == 200 and "#EXTM3U" in body
            if ok and not any(line.strip().startswith("http") for line in body.splitlines()):
                ok = False
            if not ok:
                debug_log(
                    f"[Kingdome] No HLS playlist at {url}: HTTP {response.status_code} {body[:80]!r}",
                    xbmc.LOGWARNING,
                )
            return ok
        except Exception as exc:
            debug_log(f"[Kingdome] Playlist check failed for {url}: {exc}", xbmc.LOGWARNING)
            return False

    @staticmethod
    def _ffmpegdirect_live() -> Optional[JetInputstreamFFmpegDirect]:
        if xbmc.getCondVisibility("System.Platform.IOS"):
            return None
        return JetInputstreamFFmpegDirect(manifest_type="hls", is_realtime_stream=True)

    def _resolve(self, address: str) -> Optional[JetLink]:
        channel, token = self._channel_from_address(address)
        if not channel:
            return None
        upstream = self._playlist_url(channel, token)
        if not self._fetch_playlist(upstream):
            return None
        proxy_url = self._get_proxy().get_proxy_url(upstream, self._headers())
        if not proxy_url:
            return None
        return JetLink(
            address=proxy_url,
            name="Stream",
            headers=self._headers(),
            inputstream=self._ffmpegdirect_live(),
            direct=True,
            extractor=self.name,
        )

    
    def get_items(
        self,
        params: Optional[dict] = None,
        progress: Optional[JetExtractorProgress] = None,
    ) -> List[JetItem]:
        items: List[JetItem] = []
        if self.progress_init(progress, items):
            return items
        if progress:
            self.progress_update(progress, "Fetching Kingdome schedule...")

        raw = fetch_page(_CATALOG_URL, referer=_SITE_ORIGIN + "/")
        if not raw:
            raw = fetch_page(_SITE_ORIGIN + "/", referer=_SITE_ORIGIN + "/")
        if not raw:
            debug_log("[Kingdome] Empty response from matches API", xbmc.LOGWARNING)
            return items

        try:
            data = json.loads(raw)
        except (ValueError, TypeError):
            debug_log("[Kingdome] Matches API did not return JSON", xbmc.LOGWARNING)
            return items

        groups = data if isinstance(data, list) else (
            data.get("categories") or data.get("events") or data.get("matches") or []
        )
        seen = set()
        for group in groups:
            if not isinstance(group, dict):
                continue
            category = str(group.get("category") or group.get("name") or "").strip().upper() or None
            matches = group.get("matches")
            if matches is None:
                matches = group.get("events") or ([group] if group.get("url") else [])
            if not isinstance(matches, list):
                continue
            for match in matches:
                if not isinstance(match, dict):
                    continue
                title = str(match.get("match") or match.get("title") or "").strip()
                url = str(match.get("url") or "").strip()
                if not title or not url or url in seen:
                    continue
                if not self._channel_from_address(url)[0]:
                    continue
                seen.add(url)
                items.append(
                    JetItem(
                        title=title,
                        links=[JetLink(url, links=True)],
                        status="LIVE",
                        league=category,
                        extractor=self.name,
                    )
                )

        debug_log(f"[Kingdome] Returning {len(items)} events", xbmc.LOGINFO)
        return items

    def get_link(self, url: JetLink) -> Optional[JetLink]:
        address = url.address if isinstance(url, JetLink) else url
        try:
            return self._resolve(address)
        except Exception as exc:
            debug_log(f"[Kingdome] get_link failed for {address}: {exc}", xbmc.LOGERROR)
            return None

    def get_links(self, url: JetLink) -> List[JetLink]:
        link = self.get_link(url)
        return [link] if link is not None else []
