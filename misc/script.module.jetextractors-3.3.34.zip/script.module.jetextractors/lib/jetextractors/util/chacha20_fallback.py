"""Small portable RFC 8439 ChaCha20-Poly1305 decryption fallback.

Pure Python / standard library only; used only when the installed crypto
backends cannot import (e.g. Kodi 22 Python subinterpreters). The payload
being decrypted is a short stream-URL token, not HLS media segments.
"""
import hmac
import struct

_MASK32 = 0xffffffff
_P1305 = (1 << 130) - 5
_R_CLAMP = 0x0ffffffc0ffffffc0ffffffc0fffffff


def _rol32(x, bits):
    return ((x << bits) | (x >> (32 - bits))) & _MASK32


def _quarter(a, i, j, k, l):
    a[i] = (a[i] + a[j]) & _MASK32
    a[l] = _rol32(a[l] ^ a[i], 16)
    a[k] = (a[k] + a[l]) & _MASK32
    a[j] = _rol32(a[j] ^ a[k], 12)
    a[i] = (a[i] + a[j]) & _MASK32
    a[l] = _rol32(a[l] ^ a[i], 8)
    a[k] = (a[k] + a[l]) & _MASK32
    a[j] = _rol32(a[j] ^ a[k], 7)


def _block(key, nonce, counter):
    state = list(struct.unpack('<4I', b'expand 32-byte k'))
    state += list(struct.unpack('<8I', key))
    state += [counter]
    state += list(struct.unpack('<3I', nonce))
    working = state[:]
    for _ in range(10):
        _quarter(working, 0, 4, 8, 12)
        _quarter(working, 1, 5, 9, 13)
        _quarter(working, 2, 6, 10, 14)
        _quarter(working, 3, 7, 11, 15)
        _quarter(working, 0, 5, 10, 15)
        _quarter(working, 1, 6, 11, 12)
        _quarter(working, 2, 7, 8, 13)
        _quarter(working, 3, 4, 9, 14)
    return struct.pack('<16I', *((working[i] + state[i]) & _MASK32 for i in range(16)))


def _poly1305(message, one_time_key):
    r = int.from_bytes(one_time_key[:16], 'little') & _R_CLAMP
    s = int.from_bytes(one_time_key[16:], 'little')
    a = 0
    for start in range(0, len(message), 16):
        chunk = message[start:start + 16]
        n = int.from_bytes(chunk + b'\x01', 'little')
        a = ((a + n) * r) % _P1305
    return ((a + s) & ((1 << 128) - 1)).to_bytes(16, 'little')


def _padding(data):
    return b'\x00' * ((-len(data)) % 16)


def decrypt_chacha20poly1305(key, nonce, ciphertext_and_tag, aad=b''):
    """IETF ChaCha20-Poly1305 authenticated decryption, RFC 8439 §2.8."""
    key = bytes(key)
    nonce = bytes(nonce)
    ciphertext_and_tag = bytes(ciphertext_and_tag)
    aad = bytes(aad)
    if len(key) != 32 or len(nonce) != 12 or len(ciphertext_and_tag) < 16:
        raise ValueError('Invalid ChaCha20-Poly1305 key, nonce, or ciphertext/tag')
    ciphertext, tag = ciphertext_and_tag[:-16], ciphertext_and_tag[-16:]
    poly_key = _block(key, nonce, 0)[:32]
    mac_body = (aad + _padding(aad) + ciphertext + _padding(ciphertext)
                + struct.pack('<QQ', len(aad), len(ciphertext)))
    expected = _poly1305(mac_body, poly_key)
    if not hmac.compare_digest(expected, tag):
        raise ValueError('ChaCha20-Poly1305 authentication failed')
    plaintext = bytearray(len(ciphertext))
    for offset in range(0, len(ciphertext), 64):
        counter = (offset // 64) + 1
        if counter > _MASK32:
            raise ValueError('ChaCha20 counter exhausted')
        mask = _block(key, nonce, counter)
        part = ciphertext[offset:offset + 64]
        for i, value in enumerate(part):
            plaintext[offset + i] = value ^ mask[i]
    return bytes(plaintext)
