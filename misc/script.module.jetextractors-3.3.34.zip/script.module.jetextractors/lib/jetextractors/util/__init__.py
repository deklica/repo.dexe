"""Utility modules; importing this package requires an authorized consumer."""

# Consumers import utility submodules directly, so guard the package boundary too.
from ..config import get_config as _get_authorized_config
_get_authorized_config()
del _get_authorized_config
