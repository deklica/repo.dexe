# -*- coding: utf-8 -*-
"""Parse public site menu HTML, or show labelled builtin category paths.

The builtin paths are a contingency when live site menus are inaccessible;
replay items are *never* synthesized or read from local HTML snapshots.
"""
from urllib.parse import urljoin, urlparse
from bs4 import BeautifulSoup

_BROWSE = {
    'mlblive.net': (('2026 MLB Replays', '/2026-mlb-full-game-replays'), ('2025', '/2025-mlb-full-game-replays'), ('2024', '/mlb-2024-full-game-replays'), ('2023', '/mlb-2023-full-game-replays'), ('2022', '/mlb-2022-full-game-replays'), ('2021', '/mlb-2021-full-game-replays'), ('Arizona Diamondbacks', '/arizona-diamondbacks-full-game-replay'), ('Atlanta Braves', '/atlanta-braves-full-game-replay'), ('Baltimore Orioles', '/baltimore-orioles-full-game-replay'), ('Boston Red Sox', '/boston-red-sox-full-game-replay'), ('Chicago Cubs', '/chicago-cubs-full-game-replay'), ('Chicago White Sox', '/chicago-white-sox-full-game-replay'), ('Cincinnati Reds', '/cincinnati-reds-full-game-replay'), ('Cleveland Guardians', '/cleveland-guardians-full-game-replay'), ('Colorado Rockies', '/colorado-rockies-full-game-replay'), ('Detroit Tigers', '/detroit-tigers-full-game-replay'), ('Houston Astros', '/houston-astros-full-game-replay'), ('Kansas City Royals', '/kansas-city-royals-full-game-replay'), ('Los Angeles Angels', '/los-angeles-angels-full-game-replay'), ('Los Angeles Dodgers', '/los-angeles-dodgers-full-game-replay'), ('Miami Marlins', '/miami-marlins-full-game-replay'), ('Milwaukee Brewers', '/milwaukee-brewers-full-game-replay'), ('Minnesota Twins', '/minnesota-twins-full-game-replay'), ('New York Mets', '/new-york-mets-full-game-replay'), ('New York Yankees', '/new-york-yankees-full-game-replay'), ('Oakland Athletics', '/oakland-athletics-full-game-replay'), ('Philadelphia Phillies', '/philadelphia-phillies-full-game-replay'), ('Pittsburgh Pirates', '/pittsburgh-pirates-full-game-replay'), ('San Diego Padres', '/san-diego-padres-full-game-replay'), ('San Francisco Giants', '/san-francisco-giants-full-game-replay'), ('Seattle Mariners', '/seattle-mariners-full-game-replay'), ('St. Louis Cardinals', '/st-louis-cardinals-full-game-replay'), ('Tampa Bay Rays', '/tampa-bay-rays-full-game-replay'), ('Texas Rangers', '/texas-rangers-full-game-replay'), ('Toronto Blue Jays', '/toronto-blue-jays-full-game-replay'), ('Washington Nationals', '/washington-nationals-full-game-replay'), ('TV Shows', '/tv-shows'), ('MLB World Series Replays', '/world-series-replays'), ('World Baseball Classic', '/world-baseball-classic')),
    'fullraces.com': (('F1 2026', '/2026'), ('Formula 1 Seasons', '/f1-race-replays'), ('Formula 1 2025', '/2025'), ('Formula 1 2024', '/watch/formula_1/formula_1_2024/21'), ('Formula 1 2023', '/f1-2023'), ('Formula 1 2022', '/formula1-2022'), ('Formula 1 2021', '/formula1-2021'), ('Formula 1 2020', '/f1-2020'), ('Formula 1 2019', '/f1-2019'), ('F1 Archive Races 2000-2018', '/f1-archive-races'), ('NASCAR', '/nascar'), ('Indycar', '/indycar'), ('WSBK', '/wsbk'), ('WRC', '/wrc'), ('Formula 2', '/f2-full-races'), ('Formula 3', '/f3-full-races'), ('Formula E', '/formula-e'), ('F1 Academy', '/f1-academy')),
}


def categories_from_html(html, domain):
    if domain not in _BROWSE or not html:
        return []
    nav = BeautifulSoup(html, 'html.parser').select_one('ul#list_cat')
    if nav is None:
        return []
    result, seen = [], set()
    for a in nav.select('a[href]'):
        href = (a.get('href') or '').strip()
        label = a.get_text(' ', strip=True)
        if not label or not href or href.startswith(('#', 'javascript:', 'mailto:')):
            continue
        parsed = urlparse(urljoin('https://' + domain + '/', href))
        host = (parsed.hostname or '').lower()
        if host not in (domain, 'www.' + domain) or parsed.scheme not in ('http', 'https'):
            continue
        path = parsed.path or '/'
        if path == '/' or path.startswith('/content-policy-') or path in seen:
            continue
        seen.add(path)
        result.append((label, path))
    return result


def default_categories(domain):
    return list(_BROWSE.get(domain, ()))
