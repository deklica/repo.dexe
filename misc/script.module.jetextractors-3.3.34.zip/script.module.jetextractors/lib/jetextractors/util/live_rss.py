# -*- coding: utf-8 -*-
"""Live, public RSS listing retrieval for MLB Live and FullRaces.

Only the two explicitly approved domains and their /publ/rss endpoints are
queried. No saved HTML, browser cookies or challenge handling is involved.
Does not modify any playback or Go transport configuration.
"""
import re
from html import unescape
from urllib.parse import urljoin, urlparse
import xml.etree.ElementTree as ET

try:
    import xbmc
except ImportError:
    xbmc = None

_ALLOWED = {'mlblive.net', 'fullraces.com'}
_MAX_BYTES = 2 * 1024 * 1024
_MAX_ENTRIES = 150
_RSS_PATH = '/publ/rss'


def _log(message, level=None):
    if xbmc is not None:
        xbmc.log('[JetLiveRSS] ' + message,
                 level if level is not None else xbmc.LOGINFO)


def _approved_url(url, domain, allow_feed_redirect=False):
    try:
        p = urlparse(url)
        host = (p.hostname or '').lower().removeprefix('www.')
        if host != domain or p.scheme not in ('https', 'http') or p.username or p.password or p.port not in (None, 80, 443):
            return False
        if allow_feed_redirect and (p.path.rstrip('/') != _RSS_PATH or p.query):
            return False
        return True
    except (ValueError, AttributeError, TypeError):
        return False


def _text(node, tag):
    element = node.find(tag)
    return ''.join(element.itertext()).strip() if element is not None else ''


def parse_rss(xml_bytes, domain):
    """Parse bounded RSS/Atom data into safe replay listings; no network."""
    if domain not in _ALLOWED:
        raise ValueError('Unapproved RSS domain')
    if isinstance(xml_bytes, str):
        data = xml_bytes.encode('utf-8')
    else:
        data = bytes(xml_bytes or b'')
    if not data or len(data) > _MAX_BYTES:
        raise ValueError('RSS feed empty or too large')
    # Reject declarations not needed by RSS; avoids DTD expansion entirely.
    if re.search(br'<!\s*(?:DOCTYPE|ENTITY)\b', data, re.I):
        raise ValueError('DTD/ENTITY not permitted in RSS')
    root = ET.fromstring(data)
    channel_items = root.findall('./channel/item')
    is_atom = root.tag.lower().endswith('}feed') or root.tag.lower() == 'feed'
    if not channel_items and is_atom:
        namespace = root.tag.split('}', 1)[0] + '}' if '}' in root.tag else ''
        channel_items = root.findall(namespace + 'entry')
    entries = []
    seen = set()
    for item in channel_items[:_MAX_ENTRIES]:
        title = unescape(_text(item, 'title') or _text(item, '{http://www.w3.org/2005/Atom}title')).strip()
        address = _text(item, 'link')
        if is_atom:
            for a in item.findall('{http://www.w3.org/2005/Atom}link') + item.findall('link'):
                if a.attrib.get('rel', 'alternate') == 'alternate':
                    address = a.attrib.get('href', '')
                    if address:
                        break
        address = urljoin('https://' + domain + '/', unescape(address))
        if not title or not _approved_url(address, domain):
            continue
        parsed = urlparse(address)
        if parsed.path.rstrip('/') in ('', _RSS_PATH) or address in seen:
            continue
        # Site posts link to plain HTTP in their HTML/RSS. Use HTTPS for
        # replay resolution as verified by the user's Linux Go playback test.
        address = parsed._replace(scheme='https', netloc=domain, fragment='').geturl()
        if address in seen:
            continue
        seen.add(address)
        categories = []
        for cat in list(item):
            if cat.tag.split('}')[-1].lower() == 'category':
                value = (cat.attrib.get('term') or cat.text or '').strip()
                if value:
                    categories.append(value)
        content_html = (_text(item, 'description') or
                        _text(item, '{http://purl.org/rss/1.0/modules/content/}encoded') or
                        _text(item, '{http://www.w3.org/2005/Atom}summary') or
                        _text(item, '{http://www.w3.org/2005/Atom}content'))
        # Prefer structured media thumbnail/enclosure, then image in description.
        image = ''
        for child in item.iter():
            local_name = child.tag.split('}')[-1].lower()
            if local_name in ('thumbnail', 'content', 'enclosure'):
                candidate = child.attrib.get('url', '')
                media_type = child.attrib.get('type', '').lower()
                if candidate and (local_name == 'thumbnail' or 'image' in media_type or
                                  re.search(r'\.(png|jpe?g|webp)(?:\?|$)', candidate, re.I)):
                    image = candidate
                    break
        if not image and content_html:
            try:
                from bs4 import BeautifulSoup
                img = BeautifulSoup(content_html, 'html.parser').find('img')
                if img:
                    image = img.get('data-src') or img.get('src') or ''
            except ImportError:
                match = re.search(r'<img[^>]+src=["\']([^"\']+)', content_html, re.I)
                image = match.group(1) if match else ''
        image = urljoin('https://' + domain + '/', unescape(image)) if image else ''
        if image and urlparse(image).scheme not in ('http', 'https'):
            image = ''
        entries.append({'title': re.sub(r'\s+', ' ', title), 'url': address,
                        'icon': image, 'categories': categories})
    return entries


def _requests_fetch(domain, timeout):
    """Read only public feed; follow at most two same-host feed redirects."""
    import requests
    url = 'https://' + domain + _RSS_PATH
    headers = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36',
               'Accept': 'application/rss+xml, application/xml, text/xml;q=0.9, */*;q=0.5'}
    for redirect in range(3):
        if not _approved_url(url, domain, allow_feed_redirect=True):
            raise ValueError('RSS redirect rejected')
        response = requests.get(url, headers=headers, timeout=(4, timeout),
                                allow_redirects=False)
        status = response.status_code
        if status in (301, 302, 303, 307, 308):
            target = urljoin(url, response.headers.get('Location', ''))
            if not _approved_url(target, domain, allow_feed_redirect=True):
                raise ValueError('RSS redirect leaves approved domain or endpoint')
            if urlparse(target).scheme == 'http':
                _log(domain + ' RSS redirects to HTTP (public feed only)', xbmc.LOGWARNING if xbmc else None)
            url = target
            continue
        _log('{} requests status={} final_scheme={}'.format(domain, status, urlparse(url).scheme))
        if status != 200:
            return None
        data = response.content
        if not data or len(data) > _MAX_BYTES:
            raise ValueError('RSS response empty or over size limit')
        return data
    raise ValueError('Too many RSS redirects')


def _go_fetch(domain, timeout):
    """Best-effort fallback through already-installed Go 1.0.5. No changes."""
    try:
        from goclient import get as go_get
    except ImportError:
        import os, sys, xbmcaddon, xbmcvfs
        root = xbmcvfs.translatePath(xbmcaddon.Addon('script.module.go').getAddonInfo('path'))
        path = os.path.join(root, 'lib')
        if path not in sys.path:
            sys.path.insert(0, path)
        from goclient import get as go_get
    response = go_get('https://' + domain + _RSS_PATH, profile='chrome133', timeout=timeout)
    error = getattr(response, 'error', '') or ''
    status = getattr(response, 'status_code', 0)
    text = getattr(response, 'text', '') or ''
    _log('{} Go status={} error={}'.format(domain, status, type(error).__name__ if error else 'none'))
    if status == 200 and not error:
        return text.encode('utf-8')
    return None


def fetch_live_rss(domain, timeout=12):
    """Return list of live feed posts, or None on failure. Never read snapshots."""
    if domain not in _ALLOWED:
        return None
    try:
        data = _requests_fetch(domain, timeout)
        if data is not None:
            result = parse_rss(data, domain)
            _log('{} LIVE RSS parsed={} entries'.format(domain, len(result)))
            return result
    except Exception as exc:
        _log('{} RSS requests: {}'.format(domain, type(exc).__name__), xbmc.LOGWARNING if xbmc else None)
    try:
        data = _go_fetch(domain, timeout)
        if data is not None:
            result = parse_rss(data, domain)
            _log('{} LIVE Go RSS parsed={} entries'.format(domain, len(result)))
            return result
    except Exception as exc:
        _log('{} RSS Go: {}'.format(domain, type(exc).__name__), xbmc.LOGWARNING if xbmc else None)
    _log('{} live RSS unavailable; no local HTML used'.format(domain), xbmc.LOGWARNING if xbmc else None)
    return None
