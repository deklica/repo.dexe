import base64
import json
import re
import socket
import requests, time, xbmc, xbmcaddon
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs, quote, urljoin, parse_qsl, unquote_plus
from threading import Thread, Event, Lock
from requests.exceptions import ConnectionError, Timeout, ChunkedEncodingError
from urllib3.exceptions import ProtocolError
from http.client import RemoteDisconnected

base_url = ""
domain = ""
x = 0

IP_CACHE_TS = {}
IP_CACHE_MP4 = {}

DEFAULT_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/120.0.0.0 Safari/537.36"
)

CHUNK_SIZE = 256 * 1024

# Never forward these to upstream — they confuse origin servers / load balancers.
HOP_BY_HOP = {
    "connection", "keep-alive", "proxy-authenticate", "proxy-authorization",
    "te", "trailers", "transfer-encoding", "upgrade", "host", "content-length",
}

# Brief playlist cache to collapse duplicate ffmpeg manifest probes.
# Keep very short: live playlists rotate/discontinuity frequently.
_PLAYLIST_CACHE = {}
_PLAYLIST_CACHE_TTL = 0.5

# URLs that404'd / were declared dead — fail fast, don't hammer the portal.
_DEAD_STREAMS = {}
_DEAD_STREAM_TTL = 60.0

_session = None

_HLS_URI_RE = re.compile(r'URI="([^"]+)"', re.IGNORECASE)
_EXT_X_START_RE = re.compile(r'^\s*#EXT-X-START\b', re.IGNORECASE)
_EXT_X_PDT_RE = re.compile(r'^\s*#EXT-X-PROGRAM-DATE-TIME\b', re.IGNORECASE)
_LOGGED_PLAYLISTS = set()


def _looks_like_mpegts(raw: bytes) -> bool:
    if not raw:
        return False
    if raw[:1] == b"\x47":
        return True
    for off in (188, 376, 564):
        if len(raw) > off and raw[off] == 0x47:
            return True
    return False


def _looks_like_playlist(raw: bytes, content_type: str, url: str) -> bool:
    ct = (content_type or "").lower()
    if "mpegurl" in ct or "m3u8" in ct:
        return True
    head = raw[:32].lstrip()
    if head.startswith(b"#EXTM3U") or head.startswith(b"#EXT-X-"):
        return True
    path = (url or "").lower().split("?", 1)[0]
    if path.endswith(".m3u8"):
        # Text-ish body for an .m3u8 URL → treat as playlist
        if head[:1] in (b"#", b"h", b"H") or b"http" in head[:80].lower():
            return True
    return False

# --- Stall watchdog / stream health -----------------------------------------
# Two layers:
#  1) Per-request: kill a hung proxied connection (ffmpeg blocked on us).
#  2) Global media health: if the player is playing but NO media bytes have
#     been proxied for stall_timeout seconds, stop the Kodi player. This
#     catches ffmpegdirect timeshift getting stuck without HTTP traffic.
_active_lock = Lock()
_active_streams = {}  # id(handler) -> {"last": float, "label": str, "handler": obj}
_watchdog_stop = Event()
_watchdog_thread = None
_last_stall_notify_ts = 0.0
_last_stop_ts = 0.0

DEFAULT_STALL_TIMEOUT = 25

_media_lock = Lock()
_media_state = {
    "label": "",
    "last_media_ts": 0.0,   # last mp2t/octet bytes written to a client
    "last_activity_ts": 0.0,  # any successful client write
}


def _get_stall_timeout() -> int:
    try:
        addon = xbmcaddon.Addon(id="plugin.video.jetproxy")
        val = int(addon.getSetting("stall_timeout") or DEFAULT_STALL_TIMEOUT)
        return val if val > 0 else DEFAULT_STALL_TIMEOUT
    except Exception:
        return DEFAULT_STALL_TIMEOUT


def _register_stream(handler, label: str):
    with _active_lock:
        _active_streams[id(handler)] = {
            "last": time.time(),
            "label": label or "",
            "handler": handler,
        }
    _note_activity(label, media=False)


def _touch_stream(handler):
    with _active_lock:
        entry = _active_streams.get(id(handler))
        if entry:
            entry["last"] = time.time()


def _unregister_stream(handler):
    with _active_lock:
        _active_streams.pop(id(handler), None)


def _note_activity(label: str = "", media: bool = False):
    """Record that we delivered bytes for a stream label."""
    now = time.time()
    with _media_lock:
        if label:
            if label != _media_state["label"]:
                # New stream: grant a grace period so we don't kill it mid-buffer.
                _media_state["label"] = label
                if media:
                    _media_state["last_media_ts"] = now
                else:
                    _media_state["last_media_ts"] = now
            elif media:
                _media_state["last_media_ts"] = now
        elif media:
            _media_state["last_media_ts"] = now
        _media_state["last_activity_ts"] = now


def _clear_media_state():
    with _media_lock:
        _media_state["label"] = ""
        _media_state["last_media_ts"] = 0.0
        _media_state["last_activity_ts"] = 0.0


def _mark_stream_dead(url: str, reason: str):
    _DEAD_STREAMS[url] = (time.time(), reason)
    # Drop any cached playlist for this URL
    dead_keys = [k for k in _PLAYLIST_CACHE if isinstance(k, tuple) and len(k) >= 2 and k[1] == url]
    for k in dead_keys:
        _PLAYLIST_CACHE.pop(k, None)
    # Expire old entries
    now = time.time()
    for k in list(_DEAD_STREAMS.keys()):
        if now - _DEAD_STREAMS[k][0] > _DEAD_STREAM_TTL:
            _DEAD_STREAMS.pop(k, None)


def _stream_is_dead(url: str) -> bool:
    entry = _DEAD_STREAMS.get(url)
    if not entry:
        return False
    if time.time() - entry[0] > _DEAD_STREAM_TTL:
        _DEAD_STREAMS.pop(url, None)
        return False
    return True


def _stop_player_reason(reason: str):
    """Stop Kodi playback so a dead stream does not sit stalled forever."""
    global _last_stop_ts
    now = time.time()
    if now - _last_stop_ts < 3:
        return
    _last_stop_ts = now
    xbmc.log(f"JetProxy: STOPPING PLAYER — {reason}", xbmc.LOGINFO)
    try:
        import xbmcgui
        xbmcgui.Dialog().notification(
            "JetProxy",
            "Stream ended — source stopped sending data",
            xbmcgui.NOTIFICATION_WARNING,
            4000,
        )
    except Exception:
        pass
    try:
        if xbmc.Player().isPlaying():
            xbmc.Player().stop()
    except Exception as e:
        xbmc.log(f"JetProxy: player stop failed: {type(e).__name__}: {e}", xbmc.LOGDEBUG)
    _clear_media_state()


def _notify_stall(label: str):
    global _last_stall_notify_ts
    now = time.time()
    if now - _last_stall_notify_ts < 10:
        return
    _last_stall_notify_ts = now
    try:
        import xbmcgui
        xbmcgui.Dialog().notification(
            "JetProxy",
            "Stream stalled — source stopped sending data",
            xbmcgui.NOTIFICATION_WARNING,
            4000,
        )
    except Exception:
        pass


def _watchdog_loop():
    while not _watchdog_stop.wait(2.0):
        try:
            timeout = _get_stall_timeout()
        except Exception:
            timeout = DEFAULT_STALL_TIMEOUT
        if timeout <= 0:
            continue
        now = time.time()

        # Layer 1: hung in-flight proxied requests (client waiting on us)
        victims = []
        with _active_lock:
            for hid, entry in list(_active_streams.items()):
                if (now - entry["last"]) >= timeout:
                    victims.append(entry)
                    _active_streams.pop(hid, None)
        for entry in victims:
            handler = entry.get("handler")
            label = entry.get("label", "")
            xbmc.log(
                f"JetProxy: STALL WATCHDOG killing connection after {timeout}s no data: {label[:140]}",
                xbmc.LOGINFO,
            )
            try:
                if handler is not None:
                    handler.close_connection = True
                    try:
                        handler.connection.shutdown(socket.SHUT_RDWR)
                    except Exception:
                        pass
                    try:
                        handler.connection.close()
                    except Exception:
                        pass
            except Exception as e:
                xbmc.log(f"JetProxy: watchdog kill error: {type(e).__name__}: {e}", xbmc.LOGDEBUG)
            _notify_stall(label)

        # Layer 2: player is running but no media bytes have flowed for timeout.
        # Catches ffmpegdirect timeshift stuck without generating HTTP requests.
        try:
            with _media_lock:
                label = _media_state["label"]
                last_media = _media_state["last_media_ts"]
            if not label or not last_media:
                continue
            playing = False
            try:
                playing = xbmc.Player().isPlaying()
            except Exception:
                playing = False
            if not playing:
                continue
            media_age = now - last_media
            # No media bytes for timeout seconds while player is running.
            # New streams get a grace period via label-change reset in _note_activity.
            if media_age >= timeout:
                _stop_player_reason(
                    f"no media for {int(media_age)}s (stream={label[:80]})"
                )
        except Exception as e:
            xbmc.log(f"JetProxy: media-health check error: {type(e).__name__}: {e}", xbmc.LOGDEBUG)


def start_watchdog():
    global _watchdog_thread
    if _watchdog_thread is not None and _watchdog_thread.is_alive():
        return
    _watchdog_stop.clear()
    _watchdog_thread = Thread(target=_watchdog_loop, daemon=True)
    _watchdog_thread.start()
    xbmc.log(
        f"JetProxy: stall watchdog started (kill after {_get_stall_timeout()}s without data; stop player on dead streams)",
        xbmc.LOGINFO,
    )


def _get_session():
    global _session
    if _session is None:
        _session = requests.Session()
        adapter = requests.adapters.HTTPAdapter(
            pool_connections=32,
            pool_maxsize=32,
            max_retries=0,
        )
        _session.mount("http://", adapter)
        _session.mount("https://", adapter)
    return _session


def get_cache_key(url):
    return url


def _decode_h_param(raw):
    if not raw:
        return {}
    try:
        data = json.loads(base64.urlsafe_b64decode(raw.encode()).decode())
        return data if isinstance(data, dict) else {}
    except Exception as e:
        xbmc.log(f"JetProxy: failed to decode h param: {e}", xbmc.LOGWARNING)
        return {}


def _encode_h_param(headers):
    if not headers:
        return ""
    return base64.urlsafe_b64encode(
        json.dumps(headers, separators=(",", ":")).encode()
    ).decode()


def _split_legacy_headers(url):
    headers = {}
    if "|" in url:
        url, hdr_part = url.split("|", 1)
        for k, v in parse_qsl(hdr_part, keep_blank_values=True):
            headers[k] = unquote_plus(v)
    return url, headers


def _is_manifest_url(url: str) -> bool:
    low = (url or "").lower()
    path = low.split("?", 1)[0]
    return path.endswith(".m3u8") or ".m3u8" in path


def _is_segment_url(url: str) -> bool:
    low = (url or "").lower()
    path = low.split("?", 1)[0]
    return (
        path.endswith(".ts")
        or path.endswith(".mp4")
        or "/hls/" in path
        or "/live/" in path and not _is_manifest_url(url)
    )


def _strip_hop_by_hop(headers: dict) -> dict:
    return {k: v for k, v in headers.items() if k.lower() not in HOP_BY_HOP}


class MyServer(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    daemon_threads = True
    timeout = 60

    def handle(self):
        try:
            BaseHTTPRequestHandler.handle(self)
        except (ConnectionAbortedError, ConnectionResetError, BrokenPipeError, TimeoutError, OSError) as e:
            xbmc.log(f"JetProxy: client connection dropped ({type(e).__name__})", xbmc.LOGDEBUG)

    def log_message(self, fmt, *args):
        try:
            xbmc.log(f"JetProxy: {self.address_string()} {fmt % args}", xbmc.LOGDEBUG)
        except Exception:
            pass

    def _client_headers(self):
        headers = dict(self.headers)
        headers.pop("Host", None)
        return headers

    def _resolve_headers(self, query, url, for_manifest=False):
        """Return (clean_url, upstream_headers, header_b64_for_rewrite)."""
        custom = {}
        if "h" in query:
            custom.update(_decode_h_param(query.get("h", [""])[0]))

        url, legacy = _split_legacy_headers(url)
        for k, v in legacy.items():
            custom.setdefault(k, v)

        # Start from inbound headers but drop hop-by-hop noise.
        headers = _strip_hop_by_hop(self._client_headers())

        if custom:
            headers.update(custom)
        else:
            headers["User-Agent"] = DEFAULT_UA

        headers["Accept"] = "*/*"
        # Range on playlists makes some Xtream portals return odd/empty bodies.
        if for_manifest:
            headers.pop("Range", None)
            headers.pop("range", None)

        referer = headers.get("Referer") or headers.get("referer")
        if not referer:
            parsed = urlparse(url)
            if parsed.scheme and parsed.netloc:
                headers["Referer"] = f"{parsed.scheme}://{parsed.netloc}/"
            else:
                headers.pop("Referer", None)
                headers.pop("referer", None)

        hdr_b64 = _encode_h_param(custom) if custom else ""
        return url, headers, hdr_b64

    def _proxy_url_for(self, abs_url, hdr_b64):
        proxied = f"http://127.0.0.1:49777/?url={quote(abs_url, safe='')}"
        if hdr_b64:
            proxied += f"&h={quote(hdr_b64, safe='')}"
        return proxied

    def _safe_write(self, data):
        try:
            self.wfile.write(data)
            _touch_stream(self)
            return True
        except (BrokenPipeError, ConnectionResetError, TimeoutError, OSError) as e:
            xbmc.log(f"JetProxy: client disconnected during write: {type(e).__name__}", xbmc.LOGDEBUG)
            return False

    def _send_body(self, status, header_items, body: bytes, close: bool = False):
        self.send_response(status)
        has_cl = False
        for key, value in header_items:
            kl = key.lower()
            if kl in ("server", "date", "connection", "transfer-encoding"):
                continue
            if kl == "content-length":
                has_cl = True
            self.send_header(key, value)
        if not has_cl:
            self.send_header("Content-Length", str(len(body)))
        if close or status >= 400:
            # Errors: force close so ffmpeg notices the failure immediately
            # instead of keep-alive waiting on a dead stream.
            self.send_header("Connection", "close")
            self.close_connection = True
        else:
            self.send_header("Connection", "keep-alive")
        self.end_headers()
        _touch_stream(self)
        _note_activity(media=False)
        self._safe_write(body)

    def _stream_response(self, status, r, label: str = ""):
        """Stream an upstream response to the client, framing correctly."""
        self.send_response(status)
        content_length = r.headers.get("Content-Length")
        for key, value in r.headers.items():
            kl = key.lower()
            if kl in ("server", "date", "connection", "transfer-encoding"):
                continue
            self.send_header(key, value)
        if content_length:
            self.send_header("Content-Length", content_length)
            self.send_header("Connection", "keep-alive")
        else:
            self.send_header("Connection", "close")
            self.close_connection = True
        self.end_headers()
        _touch_stream(self)

        wrote_media = False
        try:
            for chunk in r.iter_content(chunk_size=CHUNK_SIZE):
                if not chunk:
                    continue
                if not self._safe_write(chunk):
                    return False
                # Segment/binary payloads are real media for health tracking.
                _note_activity(label=label, media=True)
                wrote_media = True
            return True
        except (BrokenPipeError, ConnectionResetError, ChunkedEncodingError, ProtocolError, RemoteDisconnected, OSError) as e:
            xbmc.log(f"JetProxy: upstream/client stream error: {type(e).__name__}: {e}", xbmc.LOGDEBUG)
            return False

    def _upstream_request(self, method, url, headers, stream=False, timeout=15):
        sess = _get_session()
        if method == "HEAD":
            return sess.head(url, headers=headers, timeout=timeout, allow_redirects=True)
        return sess.get(url, headers=headers, stream=stream, timeout=timeout)

    def m3u8(self, req_type: str):
        global domain
        global base_url
        global x

        parse = urlparse(self.path)
        query = parse_qs(parse.query)
        if "url" not in query:
            self._send_body(400, [], b"missing url")
            return

        raw_url = query["url"][0]
        is_manifest = _is_manifest_url(raw_url) or req_type == "HEAD"
        url, headers, hdr_b64 = self._resolve_headers(query, raw_url, for_manifest=is_manifest)
        domain = urlparse(url).netloc
        _addon = xbmcaddon.Addon(id="plugin.video.jetproxy")

        # Fail fast for streams already declared dead (portal 404 / player stopped).
        if is_manifest and req_type == "GET" and _stream_is_dead(url):
            xbmc.log(f"JetProxy: skip dead stream {url[:120]}", xbmc.LOGDEBUG)
            self._send_body(404, [], b"stream dead", close=True)
            return

        # Short playlist cache: collapse duplicate ffmpeg probes / double refreshes.
        cache_key = ("m3u8", url, hdr_b64)
        if req_type == "GET" and is_manifest:
            now = time.time()
            cached = _PLAYLIST_CACHE.get(cache_key)
            if cached and (now - cached[0]) < _PLAYLIST_CACHE_TTL:
                xbmc.log(f"JetProxy: playlist cache hit {url[:100]}", xbmc.LOGDEBUG)
                self._send_body(200, [("Content-Type", "application/vnd.apple.mpegurl")], cached[1])
                return

        # Retry policy:
        #  - manifests: short retries (portal blips); 404 usually means stream ended
        #  - segments: fail fast so ffmpeg re-fetches the playlist for fresh tokens
        if is_manifest:
            retry_attempts = min(int(_addon.getSetting("retry_attempts") or 20), 4)
            retry_sleep = 0.4
        else:
            retry_attempts = 1
            retry_sleep = 0.0

        xbmc.log(
            f"JetProxy: {req_type} manifest={is_manifest} {url[:140]}",
            xbmc.LOGDEBUG,
        )

        r = None
        last_status = None
        retry_count = 0
        while retry_count < retry_attempts:
            try:
                r = self._upstream_request(req_type, url, headers, stream=(req_type == "GET"), timeout=12)
                if r.status_code in (403, 404):
                    last_status = r.status_code
                    retry_count += 1
                    xbmc.log(
                        f"JetProxy: upstream {r.status_code} for {url[:140]} "
                        f"(attempt {retry_count}/{retry_attempts})",
                        xbmc.LOGINFO,
                    )
                    if retry_count >= retry_attempts:
                        break
                    # Rotate UA only for manifest retries; segments should fail fast.
                    if is_manifest:
                        headers = dict(headers)
                        headers["User-Agent"] = headers.get("User-Agent", DEFAULT_UA) + str(x)
                        x += 1
                        time.sleep(retry_sleep)
                        continue
                    break
                last_status = None
                break
            except (ConnectionError, Timeout, ProtocolError, RemoteDisconnected) as e:
                retry_count += 1
                xbmc.log(
                    f"JetProxy: connection error ({type(e).__name__}) for {url[:100]} "
                    f"(attempt {retry_count}/{retry_attempts})",
                    xbmc.LOGWARNING,
                )
                if retry_count >= retry_attempts:
                    break
                time.sleep(retry_sleep if retry_sleep else 0.3)

        if r is None or last_status:
            code = 502 if r is None else (r.status_code if r.status_code < 500 else 502)
            msg = b"upstream unreachable" if r is None else f"upstream {last_status}".encode()
            if last_status == 404 and is_manifest:
                xbmc.log(
                    f"JetProxy: manifest 404 — portal ended/killed the stream, stopping player: {url[:140]}",
                    xbmc.LOGINFO,
                )
                _mark_stream_dead(url, "manifest404")
                self._send_body(code, [], msg, close=True)
                _stop_player_reason(f"manifest 404: {url[:80]}")
                return
            self._send_body(code, [], msg, close=True)
            return

        if r.status_code >= 500:
            self._send_body(r.status_code, [], b"upstream server error", close=True)
            return

        r_parse = urlparse(r.url)
        base_url = "http://" + r_parse.netloc
        content_type = (r.headers.get("Content-Type") or "").lower()

        # HEAD probe
        if req_type == "HEAD":
            self.send_response(r.status_code)
            for key, value in r.headers.items():
                if key.lower() in ("server", "date", "connection", "content-length", "transfer-encoding"):
                    continue
                self.send_header(key, value)
            self.send_header("Content-Length", "0")
            self.send_header("Connection", "keep-alive")
            self.end_headers()
            r.close()
            return

        # Non-HLS payload (block page / login wall)
        if "text/html" in content_type or "application/json" in content_type:
            try:
                peek = r.content[:400]
            except Exception:
                peek = b""
            xbmc.log(
                f"JetProxy: upstream non-HLS content-type={content_type!r} url={url[:120]} body={peek[:200]!r}",
                xbmc.LOGERROR,
            )
            r.close()
            self._send_body(502, [("Content-Type", "text/plain")], b"JetProxy: upstream returned non-HLS content", close=True)
            return

        # Read body first so we can classify binary vs playlist reliably.
        # Some portals send wrong/missing Content-Type on segments.
        try:
            raw = r.content
        except Exception as e:
            xbmc.log(f"JetProxy: failed reading upstream body: {e}", xbmc.LOGERROR)
            self._send_body(502, [], b"upstream read failed", close=True)
            return
        finally:
            try:
                r.close()
            except Exception:
                pass

        # Binary media (MPEG-TS etc.) — stream through even if Content-Type is wrong.
        if (
            "mp2t" in content_type
            or "octet-stream" in content_type
            or "mp2e" in content_type
            or _looks_like_mpegts(raw)
        ):
            # Re-open as stream for chunked passthrough when possible; else write raw.
            try:
                r2 = self._upstream_request("GET", url, headers, stream=True, timeout=15)
                if r2 is not None and r2.status_code < 400:
                    ok = self._stream_response(r2.status_code, r2, label=url)
                    r2.close()
                    return
            except Exception:
                pass
            # Fallback: write buffered bytes
            self.send_response(200)
            self.send_header("Content-Type", content_type or "video/mp2t")
            if r.headers.get("Content-Length"):
                self.send_header("Content-Length", r.headers.get("Content-Length"))
            else:
                self.send_header("Content-Length", str(len(raw)))
            self.send_header("Connection", "keep-alive")
            self.end_headers()
            _touch_stream(self)
            _note_activity(label=url, media=True)
            self._safe_write(raw)
            return

        # Playlist body
        final_url = r.url
        try:
            text = raw.decode("utf-8", errors="replace")
        except Exception:
            text = raw.decode("latin-1", errors="replace")

        if not _looks_like_playlist(raw, content_type, url) and not is_manifest:
            # Not a playlist and not binary we recognize — pass through as-is.
            xbmc.log(
                f"JetProxy: unrecognized payload content-type={content_type!r} url={url[:100]}, passing through",
                xbmc.LOGWARNING,
            )
            self.send_response(200)
            self.send_header("Content-Type", content_type or "application/octet-stream")
            self.send_header("Content-Length", str(len(raw)))
            self.send_header("Connection", "keep-alive")
            self.end_headers()
            _touch_stream(self)
            self._safe_write(raw)
            return

        new_lines = []
        stripped_start = False
        stripped_pdt = False
        for line in text.splitlines():
            stripped = line.strip()
            if not stripped:
                new_lines.append(line)
                continue
            # EXT-X-START / EXT-X-PROGRAM-DATE-TIME make ffmpeg compute a huge
            # start time (e.g. start: 6732) from live PTS/PDT. Audio then sits
            # hundreds of seconds "behind" video → ActiveAE mute/desync.
            if _EXT_X_START_RE.match(stripped):
                stripped_start = True
                xbmc.log(f"JetProxy: stripped EXT-X-START: {stripped[:100]}", xbmc.LOGINFO)
                continue
            if _EXT_X_PDT_RE.match(stripped):
                stripped_pdt = True
                xbmc.log(f"JetProxy: stripped EXT-X-PROGRAM-DATE-TIME: {stripped[:100]}", xbmc.LOGINFO)
                continue
            if stripped.startswith("#"):
                # Rewrite URI="..." inside HLS tags (EXT-X-MEDIA audio renditions,
                # EXT-X-MAP, EXT-X-I-FRAME-STREAM-INF) so they also go through
                # the proxy — otherwise ffmpeg requests them directly and audio
                # fails while proxied video segments play.
                if "URI=" in stripped:
                    def _uri_repl(m, _base=final_url, _h=hdr_b64):
                        u = m.group(1)
                        if u.startswith("http://") or u.startswith("https://"):
                            abs_u = u
                        else:
                            abs_u = urljoin(_base, u)
                        return 'URI="%s"' % self._proxy_url_for(abs_u, _h)
                    new_lines.append(_HLS_URI_RE.sub(_uri_repl, stripped))
                else:
                    new_lines.append(line)
                continue
            if stripped.startswith("http://") or stripped.startswith("https://"):
                abs_url = stripped
            else:
                abs_url = urljoin(final_url, stripped)
            new_lines.append(self._proxy_url_for(abs_url, hdr_b64))
        body = ("\n".join(new_lines) + "\n").encode("utf-8")

        if is_manifest and url not in _LOGGED_PLAYLISTS:
            _LOGGED_PLAYLISTS.add(url)
            if len(_LOGGED_PLAYLISTS) > 64:
                _LOGGED_PLAYLISTS.clear()
                _LOGGED_PLAYLISTS.add(url)
            # One INFO dump of the upstream playlist so we can see tags (PDT, MEDIA, DISCONTINUITY).
            xbmc.log(
                f"JetProxy: upstream playlist for {url[:120]} "
                f"(stripped START={stripped_start} PDT={stripped_pdt}):\n{text[:900]}",
                xbmc.LOGINFO,
            )

        out_headers = []
        for key, value in r.headers.items():
            kl = key.lower()
            if kl in ("server", "date", "connection", "content-length", "content-encoding", "transfer-encoding"):
                continue
            out_headers.append((key, value))
        out_headers.append(("Content-Type", "application/vnd.apple.mpegurl"))
        out_headers.append(("Cache-Control", "no-cache, no-store, must-revalidate"))

        if is_manifest:
            _PLAYLIST_CACHE[cache_key] = (time.time(), body)
            # Keep cache small
            if len(_PLAYLIST_CACHE) > 32:
                for k in list(_PLAYLIST_CACHE.keys())[:16]:
                    _PLAYLIST_CACHE.pop(k, None)

        self._send_body(200, out_headers, body)

    def ts(self, req_type: str):
        global domain
        global base_url
        global x

        parse = urlparse(self.path)
        query = parse_qs(parse.query)
        if "url" not in query:
            url = base_url + self.path
            headers = _strip_hop_by_hop(self._client_headers())
            headers["User-Agent"] = DEFAULT_UA
            headers["Accept"] = "*/*"
        else:
            raw_url = query["url"][0]
            url, headers, _hdr_b64 = self._resolve_headers(query, raw_url, for_manifest=False)
            domain = urlparse(url).netloc

        # Segments: fail fast. Retrying an expired token404s forever and stalls playback.
        r = None
        last_status = None
        try:
            r = self._upstream_request(req_type, url, headers, stream=(req_type == "GET"))
            if r.status_code in (403, 404):
                last_status = r.status_code
                xbmc.log(
                    f"JetProxy: segment upstream {r.status_code} {url[:140]}",
                    xbmc.LOGINFO,
                )
        except (ConnectionError, Timeout, ProtocolError, RemoteDisconnected) as e:
            xbmc.log(f"JetProxy: segment connection error {type(e).__name__} {url[:100]}", xbmc.LOGWARNING)

        if r is None or last_status:
            code = 502 if r is None else (r.status_code if r.status_code < 500 else 502)
            self._send_body(code, [], b"segment unavailable", close=True)
            return

        if r.status_code >= 500:
            self._send_body(r.status_code, [], b"upstream server error", close=True)
            return

        if req_type == "HEAD":
            self.send_response(r.status_code)
            for key, value in r.headers.items():
                if key.lower() in ("server", "date", "connection", "content-length", "transfer-encoding"):
                    continue
                self.send_header(key, value)
            self.send_header("Content-Length", "0")
            self.send_header("Connection", "keep-alive")
            self.end_headers()
            r.close()
            return

        self._stream_response(r.status_code, r, label=url)
        r.close()

    def do_HEAD(self):
        if "index.bdm" in self.path.lower() or "video_ts.ifo" in self.path.lower():
            self._send_body(404, [], b"")
            return
        label = self.path[:180]
        _register_stream(self, label)
        try:
            if ".m3u8" in self.path.lower() or "url=" in self.path.lower():
                self.m3u8("HEAD")
            elif self.path.endswith(".ts"):
                self.ts("HEAD")
            else:
                self.m3u8("HEAD")
        finally:
            _unregister_stream(self)

    def do_GET(self):
        if "index.bdm" in self.path.lower() or "video_ts.ifo" in self.path.lower():
            self._send_body(404, [], b"")
            return
        if self.path == "/stop":
            self._send_body(200, [], b"")

            def shutdown(server):
                server.shutdown()
            thread = Thread(target=shutdown, args=(self.server,))
            thread.setDaemon(True)
            thread.start()
            return

        query = parse_qs(urlparse(self.path).query)
        url_val = query.get("url", [""])[0]
        label = url_val[:180] or self.path[:180]
        _register_stream(self, label)
        try:
            if _is_segment_url(url_val) and not _is_manifest_url(url_val):
                self.ts("GET")
            else:
                self.m3u8("GET")
        finally:
            _unregister_stream(self)


class JetProxyServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True
    request_queue_size = 128


if __name__ == "__main__":
    start_watchdog()
    webServer = JetProxyServer(("127.0.0.1", 49777), MyServer)
    try:
        webServer.serve_forever()
    except KeyboardInterrupt:
        webServer.server_close()
