# JetProxy Changelog

All notable changes to `plugin.video.jetproxy`.  
Format loosely follows [Keep a Changelog](https://keepachangelog.com/).

---

## [1.1.0] — 2026-10-04

Major reliability pass for IPTV live HLS (Xtream-style streams via JetExtractors).

### Added

- **Custom upstream headers** — headers travel as base64url JSON (`?h=...`) on the plugin URL; legacy `|Key=Value` suffixes still merged
- **Chrome default UA** + portal Referer when no headers supplied (never blank Referer)
- **Stall watchdog**
  - Per-request: close hung proxied connections after N seconds with no client data
  - Global: stop the Kodi player if the player is running but no media bytes flowed for N seconds
  - Setting: *Kill stream after N seconds with no data* (default 25)
- **Dead-stream cache** — manifest404 marks the URL dead for 60s; follow-ups fail fast
- **Player stopped on dead streams** — manifest404 / media-health stop calls `xbmc.Player().stop()` + notification instead of leaving a frozen frame
- **Player engine setting** — `ffmpegdirect` | `adaptive` | `none` (for live audio/PTS issues try `adaptive`)
- **HLS stream mode setting** — `realtime` (default) | `timeshift` for ffmpegdirect
- **Playlist normalization**
  - Strip `#EXT-X-START` and `#EXT-X-PROGRAM-DATE-TIME` (huge ffmpeg `start:` / ActiveAE desync)
  - Rewrite `URI="..."` in `#EXT-X-MEDIA` / `#EXT-X-MAP` / I-frame tags through the proxy (audio renditions)
  - One INFO dump of the upstream playlist per URL for diagnosis
- **Robust payload classification** — Content-Type + `#EXTM3U` + MPEG-TS `0x47` sniffing; wrong Content-Type on segments no longer parsed as m3u8
- Threading HTTP server (`ThreadingHTTPServer`) + HTTP/1.1 keep-alive + `requests.Session` pooling
- `docs/README.md` and this changelog

### Changed

- Manifest retries capped at **4 × 0.4s** (was 20 × 2–3s) —404 on live m3u8 usually means the portal killed the stream
- Segment requests **fail fast** (1 attempt) so ffmpeg re-fetches the playlist for fresh tokens
- Error responses use `Connection: close`
- Upstream HTTP timeout 30s → 12–15s
- Hop-by-hop headers and `Range` on manifests not forwarded upstream
- Playlist cache TTL 1.5s → **0.5s**
- Request header logs at DEBUG (less noise under load)
- Client disconnect / broken pipe handled quietly (no traceback spam)
- `xbmcaddon.Addon(id="plugin.video.jetproxy")` for settings reads

### Fixed

- JetProxy hardcoded Firefox UA + blank Referer → many Xtream servers returned HTML instead of m3u8 (video failed in Kodi while VLC worked)
- `jetproxy://` links created with `headers=None` — extractors now attach Chrome UA + portal Referer/Origin
- Single-threaded proxy blocked playlist refreshes during large segment downloads → stalls after 10–30s
- ffmpegdirect timeshift left the player open on dead streams
- No-audio / huge `ActiveAE - large audio sync error` on some live IPTV (partial — some sources have broken audio PTS that require a different portal)

---

## [1.0.7] — prior

Baseline JetProxy as shipped by t4ils:

- Local proxy on `127.0.0.1:49777`
- `plugin://plugin.video.jetproxy/play/<url>` routing
- inputstream.ffmpegdirect integration (`Always On` / `Always Off` / `Always Ask`)
- Basic m3u8 URL rewrite through the proxy
- Hardcoded Firefox UA + blank Referer on upstream requests
- Retry slider for 403/404 (default 20)

---

## Upgrade notes

1. Restart Kodi (or disable/enable JetProxy) after updating so `server.py` / `main.py` reload.
2. First run writes no extra profile files; settings live under the addon’s settings.xml.
3. If audio breaks on a stream that used to work, set **Player engine → adaptive**.
4. Watchdog kill timeout is configurable; set `0` equivalent by choosing the lowest slider value only if you must disable early stops — prefer fixing the source instead.
