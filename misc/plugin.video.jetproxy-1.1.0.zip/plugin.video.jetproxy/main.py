from http.server import ThreadingHTTPServer
from player import ProxyPlayer
import base64
import json
import routing, xbmc, xbmcgui, xbmcaddon
from threading import Thread
from urllib.parse import quote, parse_qsl, unquote_plus
from xbmcgui import ListItem
import xbmcplugin
from xbmcplugin import addDirectoryItem, endOfDirectory


import sys

from server import MyServer, JetProxyServer, start_watchdog

plugin = routing.Plugin()


def _decode_h_param(raw):
    if not raw:
        return {}
    try:
        data = json.loads(base64.urlsafe_b64decode(raw.encode()).decode())
        return data if isinstance(data, dict) else {}
    except Exception as e:
        xbmc.log(f"JetProxy: failed to decode h param: {e}", xbmc.LOGWARNING)
        return {}


def _split_legacy_headers(url):
    """Split Kodi-style |Key=Value&Key2=Value2 suffix from a stream URL."""
    headers = {}
    if "|" in url:
        url, hdr_part = url.split("|", 1)
        for k, v in parse_qsl(hdr_part, keep_blank_values=True):
            headers[k] = unquote_plus(v)
    return url, headers


def startProxy():
    def serve_forever(httpd):
        with httpd:
            httpd.serve_forever()

    start_watchdog()
    webServer = JetProxyServer(("127.0.0.1", 49777), MyServer)

    xbmc.log("JetProxy: starting threaded server at http://127.0.0.1:49777", xbmc.LOGINFO)
    webServer.server_activate()
    thread = Thread(target=serve_forever, args=(webServer,))
    thread.setDaemon(True)
    thread.start()
    xbmc.log("JetProxy: server started!", xbmc.LOGINFO)

    return webServer

@plugin.route('/')
def index():
    addDirectoryItem(plugin.handle, plugin.url_for(play, "http://oscartv.mine.nu:25461/live/jmr1234/jmr1234/6139.m3u8"), ListItem("Example link"), False)
    addDirectoryItem(plugin.handle, plugin.url_for(test), ListItem("Test link"), False)
    endOfDirectory(plugin.handle)

@plugin.route("/test")
def test():
    link = xbmcgui.Dialog().input("Enter link")
    if not link:
        return
    play(link)

@plugin.route('/play/<path:url>')
def play(url):
    headers = {}
    try:
        headers.update(_decode_h_param(plugin.query.get('h', [None])[0]))
    except Exception:
        pass

    url, legacy_headers = _split_legacy_headers(url)
    for k, v in legacy_headers.items():
        headers.setdefault(k, v)

    try:
        proxy = startProxy()
    except Exception:
        proxy = None

    stream_url = "http://127.0.0.1:49777/?url=" + quote(url, safe='')
    if headers:
        h_b64 = base64.urlsafe_b64encode(
            json.dumps(headers, separators=(",", ":")).encode()
        ).decode()
        stream_url += "&h=" + quote(h_b64, safe='')

    addon = xbmcaddon.Addon()
    behavior = addon.getSettingString("inputstream_behavior")

    xbmc.log(f"JetProxy: inputstream_behavior setting value is '{behavior}'", xbmc.LOGINFO)
    xbmc.log(f"JetProxy: local stream_url={stream_url[:180]} headers={list(headers.keys())}", xbmc.LOGINFO)
    if behavior == "Always On":
        use_inputstream = True  # Always On
    elif behavior == "Always Off":
        use_inputstream = False  # Always Off
    elif behavior == "Always Ask":
        use_inputstream = xbmcgui.Dialog().yesno("JetProxy", "Use inputstream.ffmpegdirect for playback?\n\nIf you want to change this settings to be always [COLOR aqua]ON[/COLOR] or [COLOR aqua]OFF[/COLOR] go to settings in [COLOR yellow]JetProxy addon[/COLOR].")
    else:
        use_inputstream = xbmcgui.Dialog().yesno("JetProxy", "Use inputstream.ffmpegdirect for playback?\n\nIf you want to change this settings to be always [COLOR aqua]ON[/COLOR] or [COLOR aqua]OFF[/COLOR] go to settings in [COLOR yellow]JetProxy addon[/COLOR].")

    item = ListItem("JetProxy Stream", path=stream_url)
    item.setInfo('video', {'plot': "JetProxy Stream"})
    if use_inputstream:
        engine = addon.getSettingString("player_engine") or "ffmpegdirect"
        if engine not in ("ffmpegdirect", "adaptive", "none"):
            engine = "ffmpegdirect"
        xbmc.log(f"JetProxy: player_engine={engine}", xbmc.LOGINFO)

        if engine == "none":
            # Let Kodi's default player handle the m3u8.
            item.setMimeType('application/x-mpegURL')
        elif engine == "adaptive":
            # inputstream.adaptive handles live HLS PTS / discontinuities better
            # than ffmpegdirect on some IPTV sources (no-audio / huge sync errors).
            item.setProperty('inputstream', 'inputstream.adaptive')
            item.setMimeType('application/x-mpegURL')
            item.setProperty('inputstream.adaptive.manifest_type', 'hls')
            item.setProperty('inputstream.adaptive.play_timeshift_buffer', 'false')
        else:
            item.setProperty('inputstream', 'inputstream.ffmpegdirect')
            item.setMimeType('application/x-mpegURL')
            item.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'true')
            # timeshift helps DVR/catchup but causes huge ActiveAE audio sync errors
            # on live IPTV playlists with odd PTS (video ok, no audio).
            mode = addon.getSettingString("stream_mode") or "realtime"
            if mode not in ("timeshift", "realtime"):
                mode = "realtime"
            if mode == "timeshift":
                item.setProperty('inputstream.ffmpegdirect.stream_mode', 'timeshift')
            xbmc.log(f"JetProxy: stream_mode={mode}", xbmc.LOGINFO)
            item.setProperty('inputstream.ffmpegdirect.manifest_type', 'hls')
    xbmcplugin.setResolvedUrl(plugin.handle, True, item)
    xbmc.Player().play(stream_url, listitem=item)
    return True

if __name__ == '__main__':
    plugin.run()
