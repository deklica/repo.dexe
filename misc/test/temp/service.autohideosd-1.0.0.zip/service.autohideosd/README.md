# AutoHideOSD KODI service
A service to automatically hide OSD in KODI

# How it works
Once installed, whenever you bring up the Kodi OSD, the service will gracefully close it if idle for 5 seconds. Very convenient, no more fumbling with the back button


# License
AutoHideOSD is [GPLv3 licensed](https://github.com/osumoclement/service.autohideosd/blob/main/LICENSE). You may use, distribute and copy it under the license terms.
