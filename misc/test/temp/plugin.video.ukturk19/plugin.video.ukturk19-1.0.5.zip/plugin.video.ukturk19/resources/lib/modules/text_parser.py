import re
from .functions import addDir
from .http import http
from addonvar import addon_icon, addon_fanart

class Text:
	def __init__(self, url):
		self.url = url
	
	def get_list(self):
		h = http(self.url)
		page = h.get_session()
		if '060105' in page:
			return self.decode(page)
		else:
			return page
	
	def decode(self, page):
	   return ''.join(chr(int(val)) for val in [page[ i : i + 3] for i in range(0, len(page), 3)])
	
	def get_main(self):
		return re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)"',re.DOTALL).findall(self.get_list())
	
	def get_items(self):
		return re.compile('<item>(.+?)</item>',re.DOTALL).findall(self.get_list())
	
	def get_content(self):
		for item in self.get_items():
			links=re.compile('<link>(.+?)</link>').findall(item)
			if len(links)==1:
				name = re.compile('<title>(.+?)</title>').findall(item)[0]
				url = links[0]
				icon = re.compile('<thumbnail>(.+?)</thumbnail>').findall(item)[0]
				if icon=='ImageHere':
					icon = addon_icon
				addDir(name ,url,3,icon,addon_fanart,'Test Directory',isFolder=False)
					
			else:
				name = re.compile('<title>(.+?)</title>').findall(item)[0]
				url = self.url + '/MULTILINK'
				icon = re.compile('<thumbnail>(.+?)</thumbnail>').findall(item)[0]
				if icon=='ImageHere':
					icon = addon_icon
				addDir(name ,url,3,icon,addon_fanart,'Test Directory',isFolder=False)