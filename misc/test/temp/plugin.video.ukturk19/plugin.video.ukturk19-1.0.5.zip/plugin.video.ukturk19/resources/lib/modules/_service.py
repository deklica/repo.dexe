class Startup:
	
	def run_startup(self):
		pass

s = Startup()