import xbmc, xbmcgui
import re
import resolveurl
from .text_parser import Text

class Player:
	def __init__(self, title, link, thumb, description):
		self.title = title
		self.link = link
		self.thumb = thumb
		self.description = description
	
	def play_link(self):
		if 'MULTILINK' in self.link:
			link = self.get_multilink()
		elif '|||' in self.link:
			link = self.get_multilink2()
		else:
			link = self.link
		liz = xbmcgui.ListItem(self.title)
		liz.setInfo('video', {'Title': self.title, 'plot': self.description})
		liz.setArt({'thumb': self.thumb, 'icon': self.thumb, 'poster': self.thumb})
		liz.setProperty('IsPlayable', 'true')
		if resolveurl.HostedMediaFile(link).valid_url():
			url = resolveurl.HostedMediaFile(link).resolve()
			xbmc.Player().play(url,liz)
		else:
			xbmc.Player().play(link,liz)
	
	def get_multilink2(self):
		links = self.link.split('|||')
		labels = []
		counter = 1
		for x in links:
			if x.strip().endswith(')'):
				label = 'Link ' + str(counter) + ' ' + x.split('(')[-1].replace(')', '')
			else:
				label = 'Link ' + str(counter)
			labels.append(label)
			counter += 1
		dialog = xbmcgui.Dialog()
		ret = dialog.select('Choose a Link', labels)
		if ret < 0:
			return
		if links[ret].strip().endswith(')'):
			return links[ret].rsplit('(')[0].strip()
		else:
			return links[ret]

	def get_multilink(self):
		url = self.link.replace('/MULTILINK','')
		t = Text(url)
		link = t.get_list()
		urls = re.compile('<title>'+re.escape(self.title)+'</title>(.+?)</item>',re.DOTALL).findall(link)[0]
		links=[]
		if '<link>' in urls:
			sublinks=re.compile('<link>(.+?)</link>').findall(urls)
			xbmc.log('sublinks = ' + str(sublinks), xbmc.LOGINFO)
			for sublink in sublinks:
				if 'youtube.com/watch' in sublink:
					sublink = sublink.replace('watch?v=','embed/')
				links.append(sublink)
		labels = []
		counter = 1
		for x in links:
			if x.strip().endswith(')'):
				label = x.split('(')[-1].replace(')', '')
			else:
				label = 'Link ' + str(counter)
			labels.append(label)
			counter += 1
		dialog = xbmcgui.Dialog()
		ret = dialog.select('Choose a Link', labels)
		if ret < 0:
			return
		if links[ret].strip().endswith(')'):
			return links[ret].rsplit('(')[0].strip()
		else:
			return links[ret]