import xbmc
import os
from .functions import addDir, adult_set, adult_check, item_check, content_check
from .text_parser import Text
from addonvar import addon_icon, addon_fanart, searchlist, userdata, setting_set, search_icon, highlights_icon, fb_highlights_icon

def main():
	if not os.path.exists(userdata):
			os.mkdir(userdata)
	t = Text(searchlist)
	for name, url, icon in t.get_main():
		if not 'XXX' in name:
			addDir(name ,url,1,icon,addon_fanart,name,addcontext=False)
		if 'XXX' in name:
			adult_set(name,url,icon)
	
	addDir('Sports Replays','https://fullmatchtv.com',20,highlights_icon,addon_fanart,'Sports Replays',addcontext=False)
	addDir('Football Replays','',14,fb_highlights_icon,addon_fanart,'Football Replays',addcontext=False)
	addDir('Search','',17,search_icon,addon_fanart,'Turk Search',addcontext=False)
	addDir('UK Turks Favourites','',13,addon_icon,addon_fanart,'Open Addon Favourites',addcontext=False)
	addDir('Settings','',2,addon_icon,addon_fanart,'Open the Settings Menu',addcontext=False,isFolder=False)
	xbmc.executebuiltin('Container.SetViewMode(500)')

def sub_menu(name,url,icon,fanart):
	setting_set('fav','no')
	content_check(url,fanart)
	t = Text(url)
	if 'Index' in url:
		for name, url, icon in t.get_main():
			if name[0]=='0':
				name=name[1:] + '[COLOR gold]   (New)[/COLOR]'
			addDir(name ,url,1,icon,addon_fanart,name,isFolder=True)
	if 'XXX' in name: 
		adult_check()
	item_check(url,t.get_list(),icon)