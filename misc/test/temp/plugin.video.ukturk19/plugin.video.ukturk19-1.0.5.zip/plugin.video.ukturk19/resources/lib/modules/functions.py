import xbmc, xbmcgui, xbmcplugin
import os, sys, re
from urllib.parse import quote_plus
from addonvar import addon_fanart, dialog, setting, setting_set, adultopt, adultpass, userdata, nextpage, uktfavs, addon_id

def is_new(name):
	if name[0]=='0':
		name=name[1:] + '[COLOR gold]   (New)[/COLOR]'

def addDir(name,url,mode,icon,fanart,description, addcontext=True,hls=False,isFolder=True):
	u=sys.argv[0]+"?url="+quote_plus(url)+"&mode="+str(mode)+"&name="+quote_plus(name)+"&icon="+quote_plus(icon) +"&fanart="+quote_plus(fanart)+"&description="+quote_plus(description)
	liz=xbmcgui.ListItem(name)
	liz.setArt({'fanart':fanart,'icon':'DefaultFolder.png','thumb':icon})
	liz.setInfo(type="Video", infoLabels={ "Title": name, "Plot": description,})
	if hls is True:
		liz.setProperty('inputstream', 'inputstream.adaptive')
		liz.setProperty('inputstream.adaptive.manifest_type', 'hls')
		liz.setMimeType('application/vnd.apple.mpegurl')
		liz.setContentLookup(False)
	if addcontext:
		contextMenu = []
		if setting('fav')=='yes':
			contextMenu.append(('[COLOR red]Remove from UK Turk Favourites[/COLOR]','RunPlugin(%s?mode=12&name=%s&url=%s&icon=%s)'% (sys.argv[0],name,url,icon)))
		if setting('fav')=='no':
			contextMenu.append(('[COLOR white]Add to UK Turk Favourites[/COLOR]','RunPlugin(%s?mode=11&name=%s&url=%s&icon=%s)'% (sys.argv[0],name,url,icon)))
		liz.addContextMenuItems(contextMenu)
	xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=isFolder)

def open_url(url):
	from .http import http
	h = http(url)
	return h.get_session()

def get_soup(url):
	from bs4 import BeautifulSoup as bs
	from .http import http
	h = http(url)
	page = h.get_session()
	return bs(page, 'html.parser')

def content_check(url,fanart):
	if '/tvshows/Indexx.txt' in url:
		setting_set('fav','no')
		addDir('Catch Up TV','',4,'https://ukturks.app/api/Images/Uk%20turk%20thumbnails%20Catch%20Up%20Tv.jpg',fanart,description='')
		addDir('Browse TV Shows','',8,'https://i.imgur.com/a6iPUTh.jpg',fanart,description='')
	
def item_check(url,link,icon):
	match= re.compile('<item>(.+?)</item>',re.DOTALL).findall(link)
	count=str(len(match))
	setting_set('count',count)
	setting_set('fav','no')
	for item in match:
		try:
			if '<Image>'in item:
				IMAGE(item)
			else:
				GETCONTENT(item,url,icon)
		except:
			pass

def GETCONTENT(item,url,icon):
	baseicon=icon
	base=url
	links=re.compile('<link>(.+?)</link>').findall(item)
	if len(links)==1:
		name=re.compile('<title>(.+?)</title>').findall(item)[0]
		url=re.compile('<link>(.+?)</link>').findall(item)[0]
		if 'youtube.com/watch' in url:
			url = url.replace('watch?v=','embed/')
		icon=re.compile('<thumbnail>(.+?)</thumbnail>').findall(item)[0]
		if icon=='ImageHere':
			icon=baseicon
		if 'movies' in base:
			addDir(name,url,3,icon,addon_fanart,description='',isFolder=False)
		else:
			addDir(name,url,3,icon,addon_fanart,description='',isFolder=False)
			
	elif len(links)>1:
		name=re.compile('<title>(.+?)</title>').findall(item)[0]
		icon=re.compile('<thumbnail>(.+?)</thumbnail>').findall(item)[0]
		if icon=='ImageHere':
			icon=baseicon
		if '.ts' in url:addDir(name,url,16,icon,addon_fanart,description='')
		elif 'movies' in base:
			addDir(name,url+'/MULTILINK',3,icon,addon_fanart,description='',isFolder=False)
		else:
			addDir(name,url+'/MULTILINK',3,icon,addon_fanart,description='',isFolder=False)

def adult_set(name,url,icon):
	if adultopt == 'true':
		if adultpass == '':
			ret = dialog.yesno('Adult Content', 'You have opted to show adult content.\nPlease set a password to prevent accidental access','Cancel','Lets Go')
			if ret:
				keyb = xbmc.Keyboard('', 'Set Password')
				keyb.doModal()
				if (keyb.isConfirmed()):
					passw = keyb.getText()
					setting_set('password',passw)
					addDir(name,url,1,icon,addon_fanart, 'Adult Content')
	if adultopt == 'true':
		if adultpass != '':
			addDir(name,url,1,icon,addon_fanart, 'Adult Content')

def adult_check():
	if adultpass == '':
		ret = dialog.yesno('Adult Content', 'You have opted to show adult content.\nPlease set a password to prevent accidental access','Cancel','OK')
		if ret == 1:
			keyb = xbmc.Keyboard('', 'Set Password')
			keyb.doModal()
			if (keyb.isConfirmed()):
			    passw = keyb.getText()
			    setting_set('password',passw)
			else:
				quit()
	elif adultpass != '':
		ret = dialog.yesno('Adult Content', 'Please enter the password you set\nto continue.','Cancel','OK')
		if ret == 1:    
			keyb = xbmc.Keyboard('', 'Enter Password')
			keyb.doModal()
			if (keyb.isConfirmed()):
				passw = keyb.getText()
			if passw != adultpass:
				dialog.ok('Access Denied', 'Invalid Password')
				quit()
		else:
			quit()

def IMAGE(item):
	images=re.compile('<Image>(.+?)</Image>').findall(item)
	if len(images)==1:
		name=re.compile('<title>(.+?)</title>').findall(item)[0]
		icon=re.compile('<thumbnail>(.+?)</thumbnail>').findall(item)[0]
		image=re.compile('<Image>(.+?)</Image>').findall(item)[0]
		icon = image.replace('http://imgur.com/','http://i.imgur.com/')+'.jpg'
		image = image.replace('http://imgur.com/','http://i.imgur.com/')+'.jpg'
		addDir(name,image,7,icon,addon_fanart,description='',isFolder=False)
	elif len(images)>1:
		name=re.compile('<title>(.+?)</title>').findall(item)[0]
		icon=re.compile('<thumbnail>(.+?)</thumbnail>').findall(item)[0]
		store=''
		for image in images:
			icon = image.replace('http://imgur.com/','http://i.imgur.com/')+'.jpg'
			image = image.replace('http://imgur.com/','http://i.imgur.com/')+'.jpg'
			store=store+'<Image>'+image+'</Image>'
		path = userdata
		name=removetags(name) 
		comparefile = os.path.join(os.path.join(path,''), name+'.txt')
		if not os.path.exists(comparefile):
			open(comparefile, 'w').close()
		text_file = open(comparefile, "w")
		text_file.write(store)
		text_file.close()
		addDir(name,'image',7,icon,addon_fanart,description='')

def removetags(string):
	tags=re.compile('\[(.+?)\]').findall(string)
	for tag in tags:
		string=string.replace(tag,'').replace('[/]','').replace('[]','')
		return string

def SHOWIMAGE(url):
    string = "ShowPicture(%s)" %url
    xbmc.executebuiltin(string)

def BSHOWS(url):
	from . import best_series as best
	for x in best.get_latest(url)[:-1]:
		addDir(x.get('name'), x.get('url'), 6, x.get('icon'), x.get('fanart'),'')
	addDir('Next Page', best.get_latest(url)[-1], 5, nextpage, '', 'Next Page')

def BSHOWS2(url):
	from . import best_series as best
	for x in best.get_links(url):
		addDir(x.get('name'), x.get('url'), 3, '', '', '', isFolder=False)

def BSHOWS_SERIES(url):
	from . import best_series as best
	for x in best.browse_shows(url)[:-1]:
		addDir(x.get('name'), x.get('url'), 10, x.get('icon'), addon_fanart,'')
	addDir('Next Page', best.browse_shows(url)[-1], 9, nextpage, '', 'Next Page')

def BSHOWS_EPISODES(url):
	from . import best_series as best
	for x in best.all_episodes(url):
		addDir(x.get('name'), x.get('url'), 6, x.get('icon'), addon_fanart,'')

def GETFAVS():
	setting_set('fav','yes')
	filedata = None
	file = open(uktfavs, 'r')
	filedata = file.read()
	match=re.compile("<item>(.+?)</item>",re.DOTALL).findall(filedata)
	for item in match:
		data=re.compile('<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>',re.DOTALL).findall(item)
		for name,url,iconimage in data:
			if url.endswith('.txt') or url.endswith('.xml'):
				addDir(name,url,1,iconimage,addon_fanart, '')
			elif 'bstsrs.one' in url:
				if '/season/' in url:
					addDir(name,url,6,iconimage,addon_fanart, '')
				else:
					addDir(name,url,10,iconimage,addon_fanart, '')
			elif name=='Catch Up TV':
				addDir(name,url,4,iconimage,addon_fanart, '')
			elif name=='Browse TV Shows':
				addDir(name,url,8,iconimage,addon_fanart, '')
			else:
				addDir(name,url,3,iconimage,addon_fanart, '', isFolder=False)
                        
def ADDTOFAVS(name,url,iconimage):
	if url:
		url=url.replace(' ','%20')
	else:
		url = 'None'
	if iconimage:
		iconimage=iconimage.replace(' ','%20')
	else:
		iconimage = 'None'
	string='<FAV><item>\n<title>'+name+'</title>\n<link>'+url+'</link>\n'+'<thumbnail>'+iconimage+'</thumbnail>\n</item></FAV>\n'
	favsdb = open(uktfavs,'a')
	favsdb.write(string)
	favsdb.close()
	
def REMFAVS(name):
	filedata = None
	file = open(uktfavs, 'r')
	filedata = file.read()
	newlist=''
	match=re.compile('<item>(.+?)</item>',re.DOTALL).findall(filedata)
	for data in match:
		if name in data:
			continue
		string='\n<FAV><item>\n'+data+'</item>\n'
		newlist=newlist+string
	file = open(uktfavs, 'w')
	file.truncate()
	file.write(newlist)
	file.close()
	xbmc.executebuiltin('Container.Refresh')