import xbmc
import xbmcvfs
import xbmcgui
import requests
import re
import json
from base64 import b64decode
from resources.lib.modules.functions import addDir
from resources.lib.modules.plugin import Myaddon

addon = Myaddon()
searchlist = b64decode('aHR0cHM6Ly91a3R1cmtzLmFwcC9hcGkvQWRkb24vQWRkb24vTUFJTlhNTC50eHQ=').decode('utf-8')
categories = ['Movies', 'TV Shows', 'Cartoons', 'Documentaries', 'Stand-up Comedy', 'Turkish TV', 'Turkish Movies', 'Live TV', 'Sports', 'Concerts', 'Radio', 'CCTV', 'Fitness', 'FoodPorn']
search_history = addon.downloads_path / 'search.json'

class Search():
	
	def __init__(self):
		self.user_agent = 'Vm0wd2VFNUdXWGxXYmxKV1lUSlNXVmxVU2xOWFJteHlWbFJHVjFac1NsaFdiR2hyVlVaV1ZVMUVhejA9'
		self.headers = {'User-Agent': self.user_agent}
		self.session = requests.Session()
	
	def get_page(self, url):
		page = self.session.get(url, headers=self.headers).text
		if '060105' in page:
			return self.decode(page)
		return page
	
	def decode(self, page):
	   return ''.join(chr(int(val)) for val in [page[ i : i + 3] for i in range(0, len(page), 3)])
	
	def get_category_url(self, url, cat=None):
		index = None
		if cat is None:
		    index = self.get_multilink(categories)
		else:
		    index = cat
		if index is None:
			return
		page = self.get_page(url)
		for item in self.parse_txt(page):
		    if index.lower() == item[0].lower():
		        return (item[1], index)
	
	def get_multilink(self, cats:list):
		dialog = xbmcgui.Dialog()
		ret = dialog.select('Which Category Would You Like to Search?', cats)
		if ret > -1:
			return cats[ret]
		return None

	def from_keyboard(self, default_text='', header='Search'):
		kb = xbmc.Keyboard(default_text, header, False)
		kb.doModal()
		if (kb.isConfirmed()):
			if kb.getText() == '':
				return None
			return kb.getText()
		return None
	
	def parse_txt(self, page):
		return re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)"',re.DOTALL).findall(page)
	
	def parse_xml(self, page):
		item_list = []
		items = re.compile('<item>(.+?)</item>', re.DOTALL).findall(page)
		for item in items:
		    try:
		        title = re.findall('<title>(.+?)</title>', item)[0]
		    except IndexError:
		        continue
		    link = re.findall('<link>(.+?)</link>', item)
		    try:
		        thumbnail= re.findall('<thumbnail>(.+?)</thumbnail>', item)[0]
		    except IndexError:
		        thumbnail = ''
		    item_list.append((title, link, thumbnail))
		return item_list
	
	def search_query(self):
		return input('Enter Search Query: ')
	
	def search_txt(self, page, query):
		if query is None:
			return
		item_list =[]
		for item in self.parse_txt(page):
			if query.lower() in item[0].lower():
				item_list.append(item)
		return item_list
	
	def search_xml(self, page, query):
		item_list =[]
		for item in self.parse_xml(page):
			if query.lower() in item[0].lower():
				item_list.append(item)
		return item_list
	
	def get_search_history(self, icon):
	    with open(search_history, 'r', encoding='utf-8') as f:
	        items = json.loads(f.read())['items']
	    for query, category in items:
	        addDir(f'{category} | {query}', '', 18, icon, addon.addon_fanart, '')
	        
	def save_search_history(self, cat, query):
	    if cat is None:
	    	return
	    if query is None:
	    	return
	    items = []
	    if search_history.exists():
	        with open(search_history, 'r', encoding='utf-8') as f:
	            items = json.loads(f.read())['items']
	    item = [query, cat]
	    if not item in items:
	    	items.append(item)
	    addon.write_json(str(search_history), items)
	
	def search_main(self, icon):
	    if not addon.downloads_path.exists():
	        xbmcvfs.mkdirs(str(addon.downloads_path))
	    addDir('New Search', '', 19, icon, '', '')
	    if search_history.exists():
	        self.get_search_history(icon)
	  
	def get_results(self, cat=None, query=None):
		if cat is None:
		    cat1 = self.get_category_url(searchlist)
		    if cat1 is None:
		    	return
		    cat_url = cat1[0]
		    cat = cat1[1]
		else:
		    cat1 = self.get_category_url(searchlist, cat=cat)
		    cat_url = cat1[0]
		    cat = cat1[1]
		if query is None:
		    query = self.from_keyboard()
		
		self.save_search_history(cat, query)
		item_list = []
		page = self.get_page(cat_url)
		if '<item>' in page:
			found = self.search_xml(page, query)
			if len(found) > 0:
				for item in found:
				    item_list.append(item)
		else:
			found = self.search_txt(page, query)
			if found is None:
				return
			if len(found) > 0:
			    for item in found:
			        item_list.append(item)
			for item in self.parse_txt(page):
			    if not 'youtube' in item[1]:
			        page = self.get_page(item[1])
			        if '<item>' in page:
			            found = self.search_xml(page, query)
			            if len(found) > 0:
			                for x in found:
			                    item_list.append(x)
			        else:
			            found = self.search_txt(page, query)
			            if len(found) > 0:
			                for x in found:
			                    item_list.append(x)
			            if not '/tvshows/' in item[1]:
			                for _item in self.parse_txt(page):
			                    page = self.get_page(_item[1])
			                    found = self.search_xml(page, query)
			                    if len(found) > 0:
			                        for y in found:
			                            item_list.append(y)
		
		for title, link, thumbnail in item_list:
		    if isinstance(link, list):
		        if len(link) == 1:
		            link = link[0]
		        elif len(link) > 1:
		            link = '|||'.join(link)
		        else:
		            link = ''
		    if link.endswith('.txt'):
		        addDir(title, link, 1, thumbnail, thumbnail, title)
		    else:
		        addDir(title, link, 3, thumbnail, thumbnail, title, isFolder=False)
