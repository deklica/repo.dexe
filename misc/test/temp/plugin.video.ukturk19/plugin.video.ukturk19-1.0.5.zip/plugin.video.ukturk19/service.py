if __name__ == '__main__':
	from resources.lib.modules._service import s
	s.run_startup()