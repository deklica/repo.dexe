import sys
import re
import json
from urllib.parse import quote_plus, urljoin, urlencode
from base64 import b64decode
import xbmc
import xbmcplugin
import xbmcgui
import requests
from bs4 import BeautifulSoup
from .plugin2 import m


BASE_URL = 'https://dlhd.so'
SCHEDULE = urljoin(BASE_URL, '/schedule/schedule-generated.json')
EXTRA = urljoin(BASE_URL, '/schedule/schedule-extra-generated.json')
CHANNELS = f'{BASE_URL}/24-7-channels.php'
USER_AGENT = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'
HEADERS = {
    'User-Agent': USER_AGENT,
    'Referer': f'{BASE_URL}/'
}
SOURCE = re.compile("source: '(.+?)',")
KODI_VER = float(xbmc.getInfoLabel("System.BuildVersion")[:4])


def main():
    xbmcplugin.setPluginCategory(int(sys.argv[1]), 'Live Sports')
    schedule = requests.get(SCHEDULE, headers=HEADERS, timeout=10).json()
    extra = requests.get(EXTRA, headers=HEADERS, timeout=10).json()
    schedule.update(extra)
    for key in schedule.keys():
        m.add_dir(key.split(' -')[0], json.dumps(schedule[key]), 'live_categories', m.addon_icon, m.addon_fanart, key.split(' -')[0])

def live_categories(url: str):
    categories = json.loads(url)
    for cat in categories.keys():
        m.add_dir(cat, json.dumps(categories[cat]), 'live_submenu', m.addon_icon, m.addon_fanart, cat)

def submenu(name: str, url: str):
    xbmcplugin.setPluginCategory(int(sys.argv[1]), name)
    events = json.loads(url)
    for event in events:
        m.add_dir(event.get('event', ''), json.dumps([[channel.get('channel_name'), f"{BASE_URL}/stream/stream-{channel.get('channel_id')}.php"] for channel in event.get('channels')]), 'live_links', m.addon_icon, m.addon_fanart, event.get('event', ''), isFolder=False)

def get_channels():
    xbmcplugin.setPluginCategory(int(sys.argv[1]), 'Live Channels')
    response = requests.get(CHANNELS, headers=HEADERS, timeout=10)
    soup = BeautifulSoup(response.text, 'html.parser')
    password = m.get_setting('adult_pw')
    channels = []
    for a in soup.find_all('a')[8:]:
        title = a.text
        link = f"{BASE_URL}{a['href']}"
        if '18+' in title and password != 'xxXXxx':
            continue
        if not link in channels:
            channels.append(link)
            m.add_dir(title, link, 'live_links', m.addon_icon, m.addon_fanart, title, isFolder=False)

def hls(liz: xbmcgui.ListItem, headers: str='') -> None:
    liz.setMimeType('application/xml+dash')
    liz.setContentLookup(False)
    liz.setProperty('inputstream', 'inputstream.adaptive')
    liz.setProperty('inputstream.adaptive.manifest_headers', headers)
    liz.setProperty('inputstream.adaptive.stream_headers', headers)
    if KODI_VER < 21:
        liz.setProperty('inputstream.adaptive.manifest_type', 'hls') # Deprecated on Kodi 21
    liz.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
    
    license_headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/109.0',
        'Referer': REFERER,
        'Origin': REFERER
    }
    
    license_config = {
        'headers': urlencode(license_headers)
    }
    license_key = f"|{'|'.join(license_config.values())}"
    liz.setProperty('inputstream.adaptive.license_key', license_key)
    

def ffmpeg(liz: xbmcgui.ListItem) -> None:
    liz.setProperty('inputstream', 'inputstream.ffmpegdirect')
    liz.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'true')
    liz.setProperty('inputstream.ffmpegdirect.stream_mode', 'timeshift')
    if KODI_VER < 21:
        liz.setProperty('inputstream.adaptive.manifest_type', 'hls') # Deprecated on Kodi 21
    liz.setMimeType('application/x-mpegURL')

def __duf(d,e,f):
    _0xce1e="0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ+/"
    g = list(_0xce1e)
    h = g[0:e]
    i = g[0:f]
    d = list(d)[::-1]
    j = 0
    for c,b in enumerate(d):
        if b in h:
            j = j + h.index(b)*e**c
 
    k = ""
    while j > 0:
        k = i[j%f] + k
        j = (j - (j%f))//f
 
    return int(k) or 0

def hunter(h,u,n,t,e,r):
    r = ""
    i = 0
    while i < len(h):
        j = 0
        s = ""
        while h[i] is not n[e]:
            s = ''.join([s,h[i]])
            i = i + 1
 
        while j < len(n):
            s = s.replace(n[j],str(j))
            j = j + 1
 
        r = ''.join([r,''.join(map(chr, [__duf(s,e,10) - t]))])
        i = i + 1
 
    return r

def decode_url(text: str) -> str:
    pattern =  'decodeURIComponent\(.+?"(.+?)",(.+?),"(.+?)",(.+?),(.+?),(.+?)\)'
    x = re.findall(pattern, text)
    if not x:
        return False
    x = x[0]
    y = hunter(x[0], int(x[1]), x[2], int(x[3]), int(x[4]), int(x[5]))
    z = re.findall("'(.+?)';", y)[0]
    link = b64decode(z).decode()
    return link

def get_links(name, url: str):
    if url.startswith('['):
        url = json.loads(url)
        if isinstance(url, list):
            if len(url) > 1:
                url = m.get_multilink(url)
                if not url:
                    sys.exit()
            else:
                url = url[0][1]
    response = requests.get(url, headers=HEADERS, timeout=10)
    soup = BeautifulSoup(response.text, 'html.parser')
    iframe = soup.find('iframe', attrs={'id': 'thatframe'})
    if not iframe:
        sys.exit()
    url2 = iframe.get('src')
    if not url2:
        sys.exit()
    HEADERS['Referer'] = url
    response2 = requests.get(url2, headers=HEADERS, timeout=10)
    link = re.findall(SOURCE, response2.text)
    if not link:
        sys.exit()
    link = link[0]
    splitted = url2.split('/')
    referer = f"{quote_plus('/'.join(splitted[:3]))}"
    user_agent = quote_plus(USER_AGENT)
    headers_ = f'Referer={referer}/&Origin={referer}&User-Agent={user_agent}'
    link = f'{link}|{headers_}'
    m.log(f'link= {link}')
    liz = xbmcgui.ListItem(name, path=link)
    #hls(liz, headers_)
    ffmpeg(liz)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)

def runner(p: dict):
    name = p.get('name', '')
    url = p.get('url', '')
    mode = p.get('mode')
    
    if mode == 'live_main':
        main()
    
    elif mode == 'live_categories':
        live_categories(url)
    
    elif mode == 'live_submenu':
        submenu(name, url)
    
    elif mode == 'live_channels_main':
        get_channels()
    
    elif mode == 'live_channels':
        get_channels()
    
    elif mode == 'live_links':
        get_links(name, url)
    
   