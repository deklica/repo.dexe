import sys
import re
from urllib.parse import urljoin
from base64 import b64decode
from requests.sessions import Session
from bs4 import BeautifulSoup
import xbmcgui
import xbmcplugin
from .plugin2 import m


BASE_URL = 'https://vumoo.mx/'
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.90 Safari/537.36'
HEADERS = {"User-Agent": USER_AGENT, "Referer": BASE_URL}
SESSION = Session()
SESSION.headers = HEADERS

def main():
    m.add_dir('Movies', urljoin(BASE_URL, 'cinema-movies.html'), 'vu_submenu', m.addon_icon, m.addon_fanart, 'Movies')

def sub_menu(url: str):
    response = SESSION.get(url, timeout=10)
    soup = BeautifulSoup(response.text, 'html.parser')
    for item in soup.find_all(class_='shortItem listItem')[1:]:
        title = item.find(class_='title').text
        link = item.a['href']
        thumbnail = item.a.img['src']
        m.add_dir(title, link, 'vu_links', thumbnail, m.addon_fanart, title, isFolder=False)
        
    for page in soup.find_all(class_='pagelink'):
        title = page.text
        link = page['href']
        m.add_dir(f'Page {title}', link, 'vu_submenu', m.addon_icon, m.addon_fanart, f'Page {title}')
        

def get_links(url: str):
    response = SESSION.get(url, timeout=10)
    soup = BeautifulSoup(response.text, 'html.parser')
    servers = soup.find_all(class_='server_servername')
    links = []
    for server in servers:
        title = re.sub(r'Server | Link.+?$', '', server.text)
        link = server.a['href']
        links.append([title, link])
    return links

def play_video(name, url, icon):
    links = get_links(url)
    link = m.get_multilink(links)
    if not link:
        sys.exit()
    response = SESSION.get(url, timeout=10).text
    link = re.findall('decode\("(.+?)"', response)
    if not link:
        xbmcgui.Dialog().ok(m.addon_name, 'Unable to play selection')
        sys.exit()
    link = b64decode(link[0]).decode()
    link = re.findall('src="(.+?)"', link)
    if not link:
        xbmcgui.Dialog().ok(m.addon_name, 'Unable to play selection')
        sys.exit()
    link = link[0]
    try:
        import resolveurl
        hmf = resolveurl.HostedMediaFile(link)
        if hmf:
            link = hmf.resolve()
    except:
        pass
    liz = xbmcgui.ListItem(name, path=link)
    liz.setInfo('video', {'title': name, 'plot':name})
    liz.setArt({'thumb': icon, 'icon': icon, 'poster': icon})
    liz.setProperty('IsPlayable', 'true')
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, liz)
    return True
    

def runner(p: dict):
    name = p.get('name', '')
    url = p.get('url', '')
    mode = p.get('mode', p.get('action'))
    icon = p.get('icon', m.addon_icon)
    description = p.get('description', '')
    page = p.get('page', '')
    if page: page = int(page)
    
    m.set_content('movies')
    
    if mode == 'vu_main':
        main()
    elif mode == 'vu_submenu':
        sub_menu(url)
    elif mode == 'vu_links':
        play_video(name, url, icon)
    m.end_directory()

