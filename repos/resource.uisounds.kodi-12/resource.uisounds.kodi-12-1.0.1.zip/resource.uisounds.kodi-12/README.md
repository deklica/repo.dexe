# resource.uisounds.kodi-12
 Kodi UI sounds reduced by 12 dB
