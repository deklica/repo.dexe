# -*- coding: utf-8 -*-
"""
Data layer for the Altus search-widget manager.

Owns ``search_config.db`` — a single ``search_widget`` table holding the
ordered list of widgets shown in the search results window. No section
concept (search has no sections), no submenus.

Schema:
    search_widget(
        id              INTEGER PK AUTOINCREMENT,
        position        INTEGER NOT NULL,           -- 1-based, gap-free
        label           TEXT    NOT NULL,           -- "[SOURCE] Kind"
        kind            TEXT    NOT NULL,           -- filter / catalog grouping
        source_addon_id TEXT,                       -- NULL = library
        url_template    TEXT    NOT NULL,           -- raw $INFO[...] embedded
        display_type    TEXT    NOT NULL,           -- WidgetListXxx include
        target          TEXT    NOT NULL,           -- "videos" | "music"
        visible         INTEGER NOT NULL DEFAULT 1,
        is_stacked      INTEGER NOT NULL DEFAULT 0,
        stacked_type    TEXT                        -- child include base name
    )

Profiles are resolved in ``_get_db_path()``; all callers go through it, so the
active profile selects the file at connect time. See that function for why this
side is path-based while widget config is copy-based.
"""

import sqlite3
import xbmcvfs


_ADDON_DATA = "special://profile/addon_data/script.altus.helper/"
_DEFAULT_DB = _ADDON_DATA + "search_config.db"


def profile_db_path(profile):
    """Path to a named profile's search config, or the unnamed default."""
    if profile:
        return xbmcvfs.translatePath("%ssearch_config(%s).db" % (_ADDON_DATA, profile))
    return xbmcvfs.translatePath(_DEFAULT_DB)


def _get_db_path(profile=None):
    """Returns the resolved path to the active search_config DB.

    Profiles are path-based here, not copy-based like widget config: the active
    profile name selects which file to open, so nothing is copied on a switch
    and there is no window in which a half-applied switch could mix two
    profiles' widgets. One profile covers home widgets, search widgets and
    search history; widget_config is the spine that defines which profiles
    exist, so the name comes from there rather than a second skin string.

    ``profile`` overrides the lookup and must be passed by any route that has
    just called Skin.SetString. That builtin is async, so reading the string
    back immediately still returns the OLD profile and every DB access would
    land in the wrong file. Same reason widget_manager's generate_and_reload
    takes active_config.
    """
    if not xbmcvfs.exists(_ADDON_DATA):
        xbmcvfs.mkdir(_ADDON_DATA)
    return profile_db_path(_active_profile() if profile is None else profile)


def _active_profile():
    """Active profile name, or "" when running the unnamed default config.

    Imported inside the function: widget_manager.config_manager is the profile
    spine and importing it at module scope would create a cycle.
    """
    try:
        from modules.widget_manager.config_manager import get_active_config

        return get_active_config()
    except Exception:
        return ""


def _connect(profile=None):
    con = sqlite3.connect(_get_db_path(profile), timeout=20)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys = ON")
    return con


def _ensure_schema(con):
    con.execute(
        """
        CREATE TABLE IF NOT EXISTS search_widget (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            position        INTEGER NOT NULL,
            label           TEXT    NOT NULL,
            kind            TEXT    NOT NULL,
            source_addon_id TEXT,
            url_template    TEXT    NOT NULL,
            display_type    TEXT    NOT NULL,
            target          TEXT    NOT NULL,
            visible         INTEGER NOT NULL DEFAULT 1,
            is_stacked      INTEGER NOT NULL DEFAULT 0,
            stacked_type    TEXT
        )
        """
    )
    _convert_flix_types(con)
    con.commit()


# Flix rows were removed from the skin. The generator writes a widget's
# display_type (and a stacked widget's child type) straight into an include
# name, so a saved Flix type would point at an include that no longer exists.
# Each maps to the same row without the Flix treatment.
_FLIX_TYPES = {
    "WidgetListSmallPosterFlix": "WidgetListSmallPoster",
    "WidgetListLandscapeFlix": "WidgetListLandscape",
    "WidgetListSmallLandscapeFlix": "WidgetListSmallLandscape",
    "WidgetListSmallPosterFlixStacked": "WidgetListSmallPosterStacked",
    "WidgetListLandscapeFlixStacked": "WidgetListLandscapeStacked",
    "WidgetListSmallLandscapeFlixStacked": "WidgetListSmallLandscapeStacked",
}


def _convert_flix_types(con):
    """Rewrite saved Flix display and child types to their plain rows.

    Runs whenever a search config is opened, so every profile's file converts
    the first time it's used; with nothing left to convert it's two no-op
    updates.
    """
    for column in ("display_type", "stacked_type"):
        con.executemany(
            "UPDATE search_widget SET %s = ? WHERE %s = ?" % (column, column),
            [(new, old) for old, new in _FLIX_TYPES.items()],
        )


class ConfigManager:
    """CRUD + ordering for search widgets.

    Lifecycle: create on demand, call ``close()`` when done. The manager
    window holds one instance for its session; one-shot routes (XML
    regenerate, catalog add) instantiate, mutate, close.
    """

    def __init__(self, profile=None):
        # profile: explicit override for routes that just called Skin.SetString
        # (async — see _get_db_path). Leave None for normal use.
        self.con = _connect(profile)
        _ensure_schema(self.con)
        self.cur = self.con.cursor()

    def close(self):
        try:
            self.con.close()
        except Exception:
            pass

    # ------------------------------------------------------------------ reads

    def get_all_widgets(self):
        rows = self.cur.execute(
            "SELECT * FROM search_widget ORDER BY position ASC"
        ).fetchall()
        return [dict(r) for r in rows]

    def get_widget(self, widget_id):
        row = self.cur.execute(
            "SELECT * FROM search_widget WHERE id = ?", (widget_id,)
        ).fetchone()
        return dict(row) if row else None

    def get_widget_count(self):
        return self.cur.execute(
            "SELECT COUNT(*) FROM search_widget"
        ).fetchone()[0]

    def is_empty(self):
        return self.get_widget_count() == 0

    def get_distinct_visible_kinds(self):
        """Distinct kinds across visible widgets, in widget-position order
        (so the filter panel preserves the same flow as the results list)."""
        rows = self.cur.execute(
            "SELECT kind FROM search_widget WHERE visible=1 ORDER BY position"
        ).fetchall()
        seen = []
        for r in rows:
            k = r["kind"]
            if k and k not in seen:
                seen.append(k)
        return seen

    # ----------------------------------------------------------------- writes

    def add_widget(self, label, kind, url_template, display_type, target,
                   source_addon_id=None, is_stacked=0, stacked_type=None,
                   visible=1):
        position = self.get_widget_count() + 1
        self.cur.execute(
            """
            INSERT INTO search_widget
                (position, label, kind, source_addon_id, url_template,
                 display_type, target, visible, is_stacked, stacked_type)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (position, label, kind, source_addon_id, url_template,
             display_type, target, visible, is_stacked, stacked_type),
        )
        self.con.commit()
        return self.cur.lastrowid

    def add_widget_from_catalog(self, entry):
        """Convenience: insert a row from a catalog.py CATALOG entry dict."""
        return self.add_widget(
            label=entry["label"],
            kind=entry["kind"],
            url_template=entry["url_template"],
            display_type=entry["display_type"],
            target=entry["target"],
            source_addon_id=entry.get("source_addon_id"),
            is_stacked=entry.get("is_stacked", 0),
            stacked_type=entry.get("stacked_type"),
            visible=1,
        )

    def update_widget(self, widget_id, **fields):
        """Partial update. Only known column names are honored."""
        allowed = {
            "label", "kind", "source_addon_id", "url_template",
            "display_type", "target", "visible", "is_stacked", "stacked_type",
        }
        sets = {k: v for k, v in fields.items() if k in allowed}
        if not sets:
            return
        cols = ", ".join("%s = ?" % k for k in sets)
        params = list(sets.values()) + [widget_id]
        self.cur.execute(
            "UPDATE search_widget SET %s WHERE id = ?" % cols, params,
        )
        self.con.commit()

    def set_visible(self, widget_id, visible):
        self.update_widget(widget_id, visible=1 if visible else 0)

    def toggle_visible(self, widget_id):
        w = self.get_widget(widget_id)
        if w is None:
            return None
        new_val = 0 if w["visible"] else 1
        self.set_visible(widget_id, new_val)
        return new_val

    def delete_widget(self, widget_id):
        w = self.get_widget(widget_id)
        if w is None:
            return
        self.cur.execute("DELETE FROM search_widget WHERE id = ?", (widget_id,))
        self.con.commit()
        self._reorder()

    def delete_all_widgets(self):
        """Empty the config so ensure_search_config() will reseed it.

        Used by the Reset route: ensure_search_config() only seeds when the DB
        is empty, so a reset has to clear first. No _reorder() — there is
        nothing left to renumber.
        """
        self.cur.execute("DELETE FROM search_widget")
        self.con.commit()

    # ----------------------------------------------------------------- order

    def move_widget(self, widget_id, direction):
        """Move a widget up/down by one slot, wrapping at the ends.

        ``direction`` is "up" or "down". Returns the new position, or None if
        the widget doesn't exist.
        """
        w = self.get_widget(widget_id)
        if w is None:
            return None
        total = self.get_widget_count()
        if total <= 1:
            return w["position"]
        cur_pos = w["position"]
        if direction == "up":
            new_pos = total if cur_pos == 1 else cur_pos - 1
        elif direction == "down":
            new_pos = 1 if cur_pos == total else cur_pos + 1
        else:
            return cur_pos
        self._move_to_position(widget_id, new_pos)
        return new_pos

    def _move_to_position(self, widget_id, new_position):
        w = self.get_widget(widget_id)
        if w is None:
            return
        cur_pos = w["position"]
        if cur_pos == new_position:
            return
        # Park the moving row at 0, shift the band, then drop the row in.
        self.cur.execute(
            "UPDATE search_widget SET position = 0 WHERE id = ?",
            (widget_id,),
        )
        if new_position < cur_pos:
            self.cur.execute(
                """UPDATE search_widget
                   SET position = position + 1
                   WHERE position >= ? AND position < ?""",
                (new_position, cur_pos),
            )
        else:
            self.cur.execute(
                """UPDATE search_widget
                   SET position = position - 1
                   WHERE position > ? AND position <= ?""",
                (cur_pos, new_position),
            )
        self.cur.execute(
            "UPDATE search_widget SET position = ? WHERE id = ?",
            (new_position, widget_id),
        )
        self.con.commit()

    def _reorder(self):
        """Compact positions to be 1..N gap-free, preserving current order."""
        rows = self.cur.execute(
            "SELECT id FROM search_widget ORDER BY position ASC"
        ).fetchall()
        for new_pos, row in enumerate(rows, start=1):
            self.cur.execute(
                "UPDATE search_widget SET position = ? WHERE id = ?",
                (new_pos, row["id"]),
            )
        self.con.commit()
