# -*- coding: utf-8 -*-
"""
Entry point for both of the helper's extensions (addon.xml):

- xbmc.python.library - RunScript(script.nimbus.helper,mode=...) calls from
  the skin, handled by modules.router.
- xbmc.python.pluginsource - plugin://script.nimbus.helper/ calls. The only
  real one is the widget bridge below.

Widget bridge: load another add-on's widget without going through its reused
Python process. Add-ons with reuselanguageinvoker=true serve every call from
ONE reused interpreter, so when Home (or the search window) asks several of
that add-on's widgets for content at once, the requests queue up behind each
other (rows fill one at a time) or race for that interpreter, which can crash
Kodi - typically right after playback stops, when Kodi reloads every widget
together. This add-on does NOT reuse its interpreter, so each widget routed
here gets a fresh interpreter in which the target add-on's own plugin code is
run directly. Its directory items are added straight to this listing and
still point at the target add-on, so opening or playing them goes back
through the real add-on (and keeps its fast reused interpreter for browsing).

Path format (the target path is passed raw after "&&", so it needs no extra
encoding):
    plugin://script.nimbus.helper/?info=widget_bridge&&plugin://plugin.video.example/?mode=list&page=1
The skin builds these with $VAR[NimbusWidgetBridgeVar] (Variables.xml), which
is empty when the bridge is turned off in Skin Settings, leaving the plain
add-on path.

The bridge lives in this file, and nothing from our own "modules" package is
imported on the plugin path, because the bridged add-on then runs in this
same interpreter and many add-ons (Fen Light, Red Light, ...) have a
top-level package called "modules" too. Importing ours first would leave it
in sys.modules and the add-on would get our code instead of its own.
"""
import os
import sys
import time
import traceback
import xml.etree.ElementTree as ET
from urllib.parse import urlsplit

import xbmc
import xbmcaddon
import xbmcplugin
import xbmcvfs

LOG_PREFIX = '[script.nimbus.helper] widget_bridge: '
HELPER_ID = 'script.nimbus.helper'


def log(msg, level=xbmc.LOGDEBUG):
    xbmc.log(f'{LOG_PREFIX}{msg}', level)


def get_target(paramstring):
    """ '?info=widget_bridge&&plugin://x/?a=1&b=2' -> 'plugin://x/?a=1&b=2' """
    return paramstring.partition('&&')[2]


def get_addon_root(addon_id):
    path = xbmcaddon.Addon(addon_id).getAddonInfo('path')
    path = xbmcvfs.translatePath(path)
    return ET.parse(os.path.join(path, 'addon.xml')).getroot(), path


def get_entry_point(root, path):
    for ext in root.findall('extension'):
        if ext.get('point') == 'xbmc.python.pluginsource' and ext.get('library'):
            return os.path.join(path, ext.get('library'))


def get_module_paths(addon_id, seen=None):
    """ Library folders of an add-on's python module dependencies, the same ones Kodi would put on sys.path """
    seen = set() if seen is None else seen
    if not addon_id or addon_id in seen or addon_id.startswith('xbmc.') or addon_id.startswith('kodi.'):
        return []
    seen.add(addon_id)
    try:
        root, path = get_addon_root(addon_id)
    except Exception:  # Not installed / unreadable: Kodi would refuse to run the target anyway
        return []
    paths = [
        os.path.join(path, ext.get('library') or 'lib')
        for ext in root.findall('extension') if ext.get('point') == 'xbmc.python.module']
    for imp in root.findall('requires/import'):
        paths += get_module_paths(imp.get('addon'), seen)
    return paths


def run(handle, paramstring):
    target = get_target(paramstring)

    # Nothing after "&&" (e.g. a search row before anything was typed): an empty, successful listing, not an error
    if not target:
        return xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)

    url = urlsplit(target)
    addon_id = url.netloc

    if url.scheme != 'plugin' or not addon_id or addon_id == HELPER_ID:
        log(f'not a bridgeable add-on path: {target}', xbmc.LOGWARNING)
        return xbmcplugin.endOfDirectory(handle, succeeded=False)

    try:
        root, addon_path = get_addon_root(addon_id)
        entry = get_entry_point(root, addon_path)
        if not entry or not os.path.isfile(entry):
            raise ValueError(f'no plugin entry point for {addon_id}')
        dep_paths = get_module_paths(addon_id)
    except Exception as exc:
        log(f'cannot load {addon_id}: {exc}', xbmc.LOGWARNING)
        return xbmcplugin.endOfDirectory(handle, succeeded=False)

    # Look like a normal Kodi call to the target: its folder first on sys.path, then its dependencies, none of ours
    helper_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    entry_dir = os.path.dirname(entry)
    sys.path[:] = [entry_dir] + dep_paths + [
        p for p in sys.path if p and not os.path.abspath(p).startswith(helper_root)]
    # No os.chdir() into the target's folder: the working directory belongs to the whole Kodi process, not this script,
    # and Kodi never sets it for add-ons. Left pointing into an add-on folder, Windows refuses to move that folder, so
    # Kodi's update of that add-on fails ("Failed to move old addon files") and the add-on disappears until restored.
    sys.argv = [f'plugin://{addon_id}{url.path or "/"}', str(handle), f'?{url.query}' if url.query else '', 'resume:false']

    # xbmcaddon.Addon() with no id would resolve to this helper (the running add-on); point it at the target instead
    real_addon = xbmcaddon.Addon

    def bridged_addon(id=None, *args, **kwargs):
        return real_addon(id or addon_id, *args, **kwargs)

    xbmcaddon.Addon = bridged_addon

    # Make sure the widget always gets an answer, even if the target errors out before finishing its directory
    real_end = xbmcplugin.endOfDirectory
    finished = []

    def bridged_end(*args, **kwargs):
        succeeded = kwargs.get('succeeded', args[1] if len(args) > 1 else True)
        finished.append(succeeded)
        return real_end(*args, **kwargs)

    xbmcplugin.endOfDirectory = bridged_end

    # Count what the target adds, for the one-line summary logged when it's done
    real_add_one, real_add_many = xbmcplugin.addDirectoryItem, xbmcplugin.addDirectoryItems
    added = [0]

    def bridged_add_one(*args, **kwargs):
        added[0] += 1
        return real_add_one(*args, **kwargs)

    def bridged_add_many(*args, **kwargs):
        items = kwargs.get('items', args[1] if len(args) > 1 else [])
        try:
            added[0] += len(items)
        except TypeError:
            pass
        return real_add_many(*args, **kwargs)

    xbmcplugin.addDirectoryItem, xbmcplugin.addDirectoryItems = bridged_add_one, bridged_add_many

    started = time.time()
    try:
        # Not runpy.run_path: it replaces sys.argv[0] (the plugin:// base the add-on builds its item URLs from)
        with open(entry, 'rb') as f:
            code = compile(f.read(), entry, 'exec')
        exec(code, {'__name__': '__main__', '__file__': entry, '__builtins__': __builtins__})
    except SystemExit:
        pass
    except Exception:
        log(f'{addon_id} raised while building the widget:\n{traceback.format_exc()}', xbmc.LOGERROR)
    finally:
        if not finished:
            real_end(handle, succeeded=False)
        log(f'{addon_id}: {added[0]} items in {time.time() - started:.1f}s'
            f'{"" if finished else " (never finished its directory)"}'
            f'{" (reported failure)" if finished and finished[0] is False else ""} <- {target}', xbmc.LOGINFO)


if sys.argv[0].startswith("plugin://"):
    if len(sys.argv) > 2 and sys.argv[2].startswith("?info=widget_bridge"):
        run(int(sys.argv[1]), sys.argv[2])
    else:
        # Opened from the add-ons list, or any other plugin call: nothing to browse
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=True, cacheToDisc=False)
else:
    from modules.router import routing

    routing()
