## Third party software and other assets

### fanart.jpg
- based on 'Photo by David Dibert from Pexels'

### icon.png
- based on font
  - M+-1m-bold
