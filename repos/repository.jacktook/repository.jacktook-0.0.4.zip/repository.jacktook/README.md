# Kodi Repository for [Jacktook](https://github.com/Sam-Max/plugin.video.jacktook)


## Installation

Get the repository from [latest release](https://github.com/Sam-Max/repository.jacktook/releases/latest) or use the link: [repository.jacktook ](https://sam-max.github.io/repository.jacktook)

Then, [install from zip](https://kodi.wiki/view/Add-on_manager#How_to_install_from_a_ZIP_file) within [Kodi](https://kodi.tv/).

