# -*- coding: utf-8 -*-

import xbmc
import xbmcgui

try:
    are_you_sure = xbmcgui.Dialog().yesno("A Confluence ZEITGEIST","[COLOR=firebrick]Warning![/COLOR]  Resetting all skin settings to default.[CR][CR]Are you really sure to continue?")
    if are_you_sure :
        xbmc.executebuiltin("Skin.ResetSettings()")
        xbmc.sleep(2500)
        xbmc.executebuiltin('Notification(Skin Settings,Skin settings have been reset to default values.,5000,DefaultIconWarning.png)')
except:
    pass